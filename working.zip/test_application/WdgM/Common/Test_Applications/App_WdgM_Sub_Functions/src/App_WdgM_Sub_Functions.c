/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: App_WdgM_Sub_Functions.c                                      **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Watchdog Manager Module                               **
**                                                                            **
**  PURPOSE   : This application file is used to test the Functionality of    **
**              the WdgM module.       	                                      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

/*******************************************************************************
**                     Include Section                                        **
*******************************************************************************/
#include "App_WdgM_Sub_Functions.h"
#include "BswM.h"
#include "WdgM.h"
#include "WdgM_Ram.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                         App_WdgMTestCaseSetUp()                           **
*******************************************************************************/
void App_WdgMTestCaseSetUp(void)
{
  TestBswM_DefaultBehavior();
  TestWdgIf_DefaultBehavior();
  TestWdgM_McuDefaultBehavior();
  TestDem_DefaultBehavior();
  #if (WDGM_DEV_ERROR_DETECT == STD_ON)
  TestDet_DefaultBehavior();
  #endif
  App_GddTestStepId = 0;
}

/*******************************************************************************
**                         App_WDGM_ETC_002()                                  **
*******************************************************************************/
uint8 App_WDGM_ETC_002 (void)
{
  Std_ReturnType LenReturnVal;
	WdgM_LocalStatusType LddLocalStatus;
	WdgM_GlobalStatusType LddGlobalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/
	/* Set the Det stub behavior to Disable the Error Logging */
  App_WdgMTestCaseSetUp();
  App_GddTestStepId = 0;

  /* Test Description - 01 */
  WdgM_Init(NULL_PTR);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  #if (WDGM_DEV_ERROR_DETECT == STD_ON)
  if(!(WdgM_GblModuleInitStatus == WDGM_INITIALIZED))
  {
    return(APP_TC_FAILED);
  }
  #endif

  /* Test Description - 02 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if(LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if(!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_GetLocalStatus(20, &LddLocalStatus);

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if(LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if(!(LddLocalStatus == WDGM_LOCAL_STATUS_DEACTIVATED))
  {
    return(APP_TC_FAILED);
  }

	/* Test Description - 04 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if(LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

	/* Expected Result - 07 */
  App_GddTestStepId++;
  if(!(LddGlobalStatus == WDGM_GLOBAL_STATUS_OK))
	{
    return(APP_TC_FAILED);
  }

return(APP_TC_PASSED);
} /* End App_WDGM_ETC_002() */

/*******************************************************************************
**                            TestWdgM_MainFunction()                        **
*******************************************************************************/
void App_TestWdgM_MainFunction(uint16 LusMainFuncCount)
{
  uint16 LusMainFuncIdx;

  for(LusMainFuncIdx = 0; LusMainFuncIdx < LusMainFuncCount; LusMainFuncIdx++)
  {
    WdgM_MainFunction();
  }
} /* End TestWdgM_MainFunction() */

/******************************************************************************
**                          END OF FILE                                      **
******************************************************************************/
