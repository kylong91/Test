/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: App_WdgM_Sub_Functions.h                                      **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Watchdog Manager Module                               **
**                                                                            **
**  PURPOSE   : C header for App_WdgM_Sub_Functions.c                         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef APP_WDGM_SUB_FUNCTIONS_H
#define APP_WDGM_SUB_FUNCTIONS_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
#include "WdgM.h"
#include "WdgM_Ram.h"
#include "WdgM_Types.h"
#include "WdgIf.h"
#include "BswM_WdgM.h"
#include "SchM_WdgM.h"
#if(WDGM_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif
#include "Mcu.h"

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/
#define WDGM_TWO 0x02

#define WDGM_ALIVE_SUPREFCYCLE0                      0x06
#define WDGM_ALIVE_SUPREFCYCLE1                      0x04
#define WDGM_ALIVE_SUPREFCYCLE2                      0x08
#define WDGM_LOGICAL_EXPIREDTOLPLUSONE               0x04
#define WDGM_ALLDEADLINE_COUNT1                      0x01
#define WDGM_ALLDEADLINE_ADDCOUNT1                   0x06
#define WDGM_ALL_SUPREFCYCLE0                        0x02
#define WDGM_ALL_SUPREFCYCLE1                        0x03
#define WDGM_ALL_SUPREFCYCLE2                        0x04
#define WDGM_DEADLINE_COUNT2                         0x01
#define WDGM_DEADLINE_ADDCOUNT2                      0x3B
#define WDGM_DEADLINE_SUPREFCYCLE0                   0x03
#define WDGM_DEADLINE_SUPREFCYCLE1                   0x04
#define WDGM_DEADLINE_SUPREFCYCLE2                   0x05
#define WDGM_DEADLINE_SUPREFCYCLE3                   0x02

#define WDGM_INVALID_MODE                        (WdgM_ModeType)3
#define WDGM_INVALID_SEID                        (WdgM_SupervisedEntityIdType)22
#define WDGM_INVALID_CHCKPTID                    (WdgM_CheckpointIdType)3
#define WDGM_EXPIRED_SEID                        (WdgM_SupervisedEntityIdType)10
#define WDGM_IMPROPER_CALLER                     (uint16)102

#define BSWM_MODULE_ID                           (uint16)42

typedef struct STag_WdgMTestSECPArrayType
{
  /* Supervised entity to be supervised */
  WdgM_SupervisedEntityIdType ddSEId;
  /* Final Checkpoint to be supervised */
  WdgM_CheckpointIdType ddCheckpoint;
}WdgMTestSECPArrayType;

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void App_TestWdgM_MainFunction(uint16 LusMainFuncCount);
extern void App_WdgMTestCaseSetUp(void);
extern uint8 App_WDGM_ETC_002(void);

#endif /* End of App_WdgM_Sub_Functions.h */
/*******************************************************************************
**                       End of File                                          **
*******************************************************************************/
