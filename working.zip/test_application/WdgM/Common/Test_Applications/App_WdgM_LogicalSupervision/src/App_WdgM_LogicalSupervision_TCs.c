/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: App_WdgM_LogicalSupervision_TCs.c                             **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Watchdog Manager Module                               **
**                                                                            **
**  PURPOSE   : This application file is used to test the Functionality       **
**              of the WdgM module when Logical supervision is configured.    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

/*******************************************************************************
**                     Include Section                                        **
*******************************************************************************/
#include "App_WdgM_LogicalSupervision_Tcs.h"
#include "WdgM.h"
#include "WdgIf.h"
#include "Rte_WdgM.h"
#include "SchM_WdgM.h"

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                            WDGM_ETC_012()                                  **
*******************************************************************************/
uint8 WDGM_ETC_012 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_Init(NULL_PTR);

  /* Test Description - 02 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_CheckpointReached(10, 6);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    != WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  WdgM_MainFunction();

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_ALIVESUPERVISION_CORRECT)
    == WDGM_ALIVESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_012() */

/*******************************************************************************
**                            WDGM_ETC_013()                                  **
*******************************************************************************/
uint8 WDGM_ETC_013 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_GlobalStatusType LddGlobalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_DeInit();

  /* Test Description - 02 */
  WdgM_Init(NULL_PTR);

  /* Test Description - 03 */
  App_WdgMTestCaseSetUp();

  /* Test Description - 04 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddGlobalStatus == WDGM_GLOBAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  LenReturnVal = WdgM_CheckpointReached(10, 7);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    != WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  WdgM_MainFunction();

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_STOPPED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(S_VALIDATE, 1, 0)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_013() */

/*******************************************************************************
**                            WDGM_ETC_014()                                  **
*******************************************************************************/
uint8 WDGM_ETC_014 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_GlobalStatusType LddGlobalStatus;
  WdgM_ModeType LddMode;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_DeInit();

  /* Test Description - 02 */
  WdgM_Init(NULL_PTR);

  /* Test Description - 03 */
  App_WdgMTestCaseSetUp();

  /* Test Description - 04 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddGlobalStatus == WDGM_GLOBAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  LenReturnVal = WdgM_SetMode(1);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetMode(S_VALIDATE, 1, WDGIF_OFF_MODE)))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    == WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  LenReturnVal = WdgM_CheckpointReached(20, 0);

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[1] & WDGM_LGSUPERVISION_CORRECT)
    == WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 08 */
  LenReturnVal = WdgM_CheckpointReached(20, 2);

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[1] & WDGM_LGSUPERVISION_CORRECT)
    != WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 09 */
  WdgM_MainFunction();

  /* Expected Result - 11 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[1] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 12 */
  App_GddTestStepId++;
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 13 */
  App_GddTestStepId++;
  if (!(TestRte_Switch_globalMode_currentMode(M_VALIDATE,
    WDGM_GLOBAL_STATUS_EXPIRED)))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 10 */
  LenReturnVal = WdgM_GetMode(&LddMode);

  /* Expected Result - 14 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 15 */
  App_GddTestStepId++;
  if (!(LddMode == (WdgM_ModeType)WDGM_ONE))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_014() */

/*******************************************************************************
**                            WDGM_ETC_015()                                  **
*******************************************************************************/
uint8 WDGM_ETC_015 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;
  WdgM_GlobalStatusType LddGlobalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (!(WDGM_ETC_014() == APP_TC_PASSED))
  {
    return(APP_PC_FAILED);
  }

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  App_WdgMTestCaseSetUp();

  /* Test Description - 02 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddGlobalStatus == WDGM_GLOBAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_GetLocalStatus(20, &LddLocalStatus);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  WdgM_MainFunction();

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_015() */

/*******************************************************************************
**                            WDGM_ETC_016()                                  **
*******************************************************************************/
uint8 WDGM_ETC_016 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;
  WdgM_GlobalStatusType LddGlobalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (!(WDGM_ETC_014() == APP_TC_PASSED))
  {
    return(APP_PC_FAILED);
  }

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  App_WdgMTestCaseSetUp();

  /* Test Description - 02 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddGlobalStatus == WDGM_GLOBAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_GetLocalStatus(20, &LddLocalStatus);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  App_TestWdgM_MainFunction(WDGM_LOGICAL_EXPIREDTOLPLUSONE);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_STOPPED))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_016() */

/*******************************************************************************
**                             WDGM_ETC_017()                                 **
*******************************************************************************/
uint8 WDGM_ETC_017 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
    /* Test Description - 01 */
  WdgM_DeInit();
  WdgM_Init(NULL_PTR);

  /* Test Description - 02 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_CheckpointReached(10, 5);

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    == WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_CheckpointReached(10, 6);

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    == WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_CheckpointReached(10, 7);

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    == WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  WdgM_MainFunction();

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  LenReturnVal = WdgM_CheckpointReached(10, 7);

  /* Expected Result - 11 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 12 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    != WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  WdgM_MainFunction();

  /* Expected Result - 13 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_017() */

/*******************************************************************************
**                             WDGM_ETC_049()                                 **
*******************************************************************************/
uint8 WDGM_ETC_049 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_DeInit();
  WdgM_Init(NULL_PTR);

  /* Test Description - 02 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_CheckpointReached(10, 5);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    == WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (!((WdgM_GaaIntLogicalSupervisionStatus[0].blActivityFlag & WDGM_TRUE)
    == WDGM_TRUE))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_CheckpointReached(10, 6);

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    == WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_CheckpointReached(10, 7);

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    == WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (!((WdgM_GaaIntLogicalSupervisionStatus[0].blActivityFlag & WDGM_FALSE)
    == WDGM_FALSE))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_049() */

/*******************************************************************************
**                             WDGM_ETC_018()                                 **
*******************************************************************************/
uint8 WDGM_ETC_018 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;
  uint8 LucIndex;
  WdgMTestSECPArrayType LaaSECPArray1[4] =
    {{10, 9}, {20, 4}, {20, 5}, {10, 10}};
  uint8 LaaSEArrayIndex[4] = {0, 1, 1, 0};


  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_DeInit();

  /* Test Description - 02 */
  WdgM_Init(NULL_PTR);

  /* Test Description - 03 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 - 07 */
  for(LucIndex = 0; LucIndex < 4; LucIndex++)
  {
    LenReturnVal = WdgM_CheckpointReached(LaaSECPArray1[LucIndex].ddSEId,
      LaaSECPArray1[LucIndex].ddCheckpoint);
    /* Expected Result - 03 - 09 */
    App_GddTestStepId++;
    if (LenReturnVal == E_NOT_OK)
    {
      return(APP_TC_FAILED);
    }

    /* Expected Result - 04 - 10 */
    App_GddTestStepId++;
    if (!((WdgM_GaaSEStatus[LaaSEArrayIndex[LucIndex]]
      & WDGM_LGSUPERVISION_CORRECT) == WDGM_LGSUPERVISION_CORRECT))
    {
      return(APP_TC_FAILED);
    }
  }

  /* Test Description - 08 */
  WdgM_MainFunction();

  /* Expected Result - 11 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_018() */

/*******************************************************************************
**                             WDGM_ETC_019()                                 **
*******************************************************************************/
uint8 WDGM_ETC_019 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;
  uint8 LucIndex;
  WdgMTestSECPArrayType LaaSECPArray1[9] = {{10, 9}, {20, 4}, {20, 5},
    {10, 10}, {10, 9}, {20, 4}, {20, 6}, {10, 11}, {10, 9}};
  uint8 LaaSEArrayIndex[9] = {0, 1, 1, 0, 0, 1, 1, 0, 0};

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_DeInit();
  WdgM_Init(NULL_PTR);

  /* Test Description - 02 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 - 11 */
  for(LucIndex = 0; LucIndex < 9; LucIndex++)
  {
    LenReturnVal = WdgM_CheckpointReached(LaaSECPArray1[LucIndex].ddSEId,
      LaaSECPArray1[LucIndex].ddCheckpoint);
    /* Expected Result - 03 - 19 */
    App_GddTestStepId++;
    if (LenReturnVal == E_NOT_OK)
    {
      return(APP_TC_FAILED);
    }

    /* Expected Result - 04 - 20 */
    App_GddTestStepId++;
    if (!((WdgM_GaaSEStatus[LaaSEArrayIndex[LucIndex]]
      & WDGM_LGSUPERVISION_CORRECT) == WDGM_LGSUPERVISION_CORRECT))
    {
      return(APP_TC_FAILED);
    }
  }

  /* Test Description - 12 */
  WdgM_MainFunction();

  /* Expected Result - 21 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_019() */

/*******************************************************************************
**                             WDGM_ETC_020()                                 **
*******************************************************************************/
uint8 WDGM_ETC_020 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;
  uint8 LucIndex;
  WdgMTestSECPArrayType LaaSECPArray1[4] = {{10, 2}, {20, 2}, {20, 3}, {10, 3}};
  uint8 LaaSEArrayIndex[5] = {0, 0, 1, 1, 0};

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_DeInit();
  WdgM_Init(NULL_PTR);

  /* Test Description - 02 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
   App_GddTestStepId++;
   if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    == WDGM_LGSUPERVISION_CORRECT))
   {
     return(APP_TC_FAILED);
   }

  /* Test Description - 03 - 07 */
  for(LucIndex = 0; LucIndex < 4; LucIndex++)
  {
    WdgM_CheckpointReached(LaaSECPArray1[LucIndex].ddSEId,
      LaaSECPArray1[LucIndex].ddCheckpoint);

    /* Expected Result - 05 - 13 */
    App_GddTestStepId++;
    if (!((WdgM_GaaSEStatus[LaaSEArrayIndex[LucIndex]]
      & WDGM_LGSUPERVISION_CORRECT) == WDGM_LGSUPERVISION_CORRECT))
    {
      return(APP_TC_FAILED);
    }
  }

  /* Test Description - 08 */
  WdgM_MainFunction();

  /* Expected Result - 14 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 09 */
  LenReturnVal = WdgM_CheckpointReached(20, 2);

  /* Expected Result - 15 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 16 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[1] & WDGM_LGSUPERVISION_CORRECT)
    != WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 10 */
  WdgM_MainFunction();

  /* Expected Result - 17 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[1] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_020() */

/*******************************************************************************
**                            WDGM_ETC_021()                                  **
*******************************************************************************/
uint8 WDGM_ETC_021 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;
  WdgM_SupervisedEntityIdType LddSEID;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_DeInit();
  WdgM_Init(NULL_PTR);

  /* Test Description - 02 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_GetLocalStatus(22, &LddLocalStatus);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_CheckpointReached(22, 1);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[2] & WDGM_LGSUPERVISION_CORRECT)
    != WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  WdgM_MainFunction();

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[2] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  LenReturnVal = WdgM_CheckpointReached(10, 6);

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    != WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  WdgM_MainFunction();

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 08 */
  WdgM_DeInit();

  /* Test Description - 09 */
  LenReturnVal = WdgM_GetFirstExpiredSEID(&LddSEID);

  /* Expected Result - 11 */
  App_GddTestStepId++;
  if (LenReturnVal != E_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 12 */
  App_GddTestStepId++;
  if (!(LddSEID == WDGM_EXPIRED_SEID))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_021() */

/*******************************************************************************
**                            WDGM_ETC_050()                                  **
*******************************************************************************/
uint8 WDGM_ETC_050 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;
  WdgM_SupervisedEntityIdType LddSEID;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_DeInit();
  WdgM_Init(NULL_PTR);

  /* Test Description - 02 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_GetLocalStatus(22, &LddLocalStatus);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_CheckpointReached(22, 1);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[2] & WDGM_LGSUPERVISION_CORRECT)
    != WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  WdgM_MainFunction();

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[2] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  LenReturnVal = WdgM_CheckpointReached(10, 6);

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    != WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  WdgM_MainFunction();

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 08 */
  WdgM_DeInit();

  /* Test Description - 09 */
  LenReturnVal = WdgM_GetFirstExpiredSEID(&LddSEID);

  /* Expected Result - 11 */
  App_GddTestStepId++;
  if (LenReturnVal != E_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 12 */
  App_GddTestStepId++;
  if (!(WdgM_GddFirstExpiredSEID == 0x000A))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 13 */
  App_GddTestStepId++;
  if (!(WdgM_GddInvFirstExpiredSEID  == 0xFFF5))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_050() */

/*******************************************************************************
**                             WDGM_ETC_051()                                 **
*******************************************************************************/
uint8 WDGM_ETC_051 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_Init(NULL_PTR);

  /* Test Description - 02 */
  LenReturnVal = WdgM_GetLocalStatus(229, &LddLocalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_CheckpointReached(229, 1);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[5] & WDGM_LGSUPERVISION_CORRECT)
    != WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_CheckpointReached(229, 2);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[5] & WDGM_LGSUPERVISION_CORRECT)
    != WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!((WdgM_GaaIntLogicalSupervisionStatus[2].blActivityFlag & WDGM_TRUE)
    != WDGM_TRUE))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  LenReturnVal = WdgM_CheckpointReached(229, 0);

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[5] & WDGM_LGSUPERVISION_CORRECT)
    != WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  LenReturnVal = WdgM_CheckpointReached(229, 1);

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 11 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[5] & WDGM_LGSUPERVISION_CORRECT)
    != WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  WdgM_MainFunction();

  /* Expected Result - 12 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[5] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_051() */

/*******************************************************************************
**                             WDGM_ETC_052()                                 **
*******************************************************************************/
uint8 WDGM_ETC_052 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_DeInit();
  WdgM_Init(NULL_PTR);

  /* Test Description - 02 */
  LenReturnVal = WdgM_GetLocalStatus(229, &LddLocalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_CheckpointReached(229, 0);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[5] & WDGM_LGSUPERVISION_CORRECT)
    == WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_CheckpointReached(229, 1);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[5] & WDGM_LGSUPERVISION_CORRECT)
    == WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!((WdgM_GaaIntLogicalSupervisionStatus[2].blActivityFlag & WDGM_TRUE)
    == WDGM_TRUE))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  LenReturnVal = WdgM_CheckpointReached(229, 3);

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[5] & WDGM_LGSUPERVISION_CORRECT)
    != WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  LenReturnVal = WdgM_CheckpointReached(229, 2);

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 11 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[5] & WDGM_LGSUPERVISION_CORRECT)
    != WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  WdgM_MainFunction();

  /* Expected Result - 12 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[5] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_052() */

/*******************************************************************************
**                           END OF FILE                                      **
*******************************************************************************/
