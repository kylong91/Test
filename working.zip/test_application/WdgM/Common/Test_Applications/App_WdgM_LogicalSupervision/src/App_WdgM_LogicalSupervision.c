/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: App_WdgM_LogicalSupervision.c                                 **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Watchdog Manager Module                               **
**                                                                            **
**  PURPOSE   : This application file is used to test the Functionality       **
**              of the WdgM module when Logical supervision is configured.    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

/*******************************************************************************
**                     Include Section                                        **
*******************************************************************************/
#include "App_WdgM_LogicalSupervision.h"

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
uint16 WdgM_GaaTCIdList[] = {12, 13, 14, 15, 16, 17, 49, 18, 19, 20, 21, 50, 51
                             ,52};
App_TCResultType App_GstTCReport[NUMBER_OF_TEST_CASES];
TCFunctionPtr WdgM_GaaTCs[] =
{
  WDGM_ETC_012, /* TC list Index 0 */
  WDGM_ETC_013, /* TC list Index 1 */
  WDGM_ETC_014, /* TC list Index 2 */
  WDGM_ETC_015, /* TC list Index 3 */
  WDGM_ETC_016, /* TC list Index 4 */
  WDGM_ETC_017, /* TC list Index 5 */
  WDGM_ETC_049, /* TC list Index 6 */
  WDGM_ETC_018, /* TC list Index 7 */
  WDGM_ETC_019, /* TC list Index 8 */
  WDGM_ETC_020, /* TC list Index 9 */
  WDGM_ETC_021, /* TC list Index 10 */
  WDGM_ETC_050,  /* TC list Index 11 */
  WDGM_ETC_051,  /* TC list Index 12 */
  WDGM_ETC_052  /* TC list Index 13 */
};

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
  **                     Main()                                               **
*******************************************************************************/
int main(void)
{
  uint8 LucTestResult;

  App_GucTestIndex = 0;

  /* Loading the test report with defualt values */
  App_TestSetUp(App_GstTCReport, WdgM_GaaTCIdList, NUMBER_OF_TEST_CASES);

  /* Loop for all the testcases in this test case file */
  while(App_GucTestIndex < NUMBER_OF_TEST_CASES)
  {
    /* Pre Ample function to load the stubs with default value */
    App_WdgMTestCaseSetUp();

    /* Set the Det stub behavior to Disable the Error Logging */
    TestSetDet_ReportErrorLogEnable(FALSE);

    LucTestResult = (WdgM_GaaTCs[App_GucTestIndex])();
    App_LogTestResult(LucTestResult);
    App_GucTestIndex++;
  }

  #ifdef APP_LOG_TEST_RESULT_TO_FILE
  App_LogTestResultToFile();
  #endif

  return(0);
} /* End main() */

/******************************************************************************
**                          END OF FILE                                      **
******************************************************************************/
