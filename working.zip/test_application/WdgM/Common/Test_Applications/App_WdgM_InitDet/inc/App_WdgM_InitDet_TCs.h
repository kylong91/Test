/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: App_WdgM_InitDet_TCs.h                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Watchdog Manager Module                               **
**                                                                            **
**  PURPOSE   : C header for App_WdgM_InitDet_TCs.c                           **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef APP_WDGM_INITDET_TCS_H
#define APP_WDGM_INITDET_TCS_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "App_WdgM_Sub_Functions.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern uint8 WDGM_ETC_042(void);
extern uint8 WDGM_ETC_043(void);

#endif /* End of APP_WDGM_INITDET_TCS_H */
/*******************************************************************************
**                       End of File                                          **
*******************************************************************************/
