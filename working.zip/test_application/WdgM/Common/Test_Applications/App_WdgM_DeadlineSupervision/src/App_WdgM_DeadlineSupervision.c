/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: App_WdgM_DeadlineSupervision.c                                **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Watchdog Manager Module                               **
**                                                                            **
**  PURPOSE   : This application file is used to test the Functionality       **
**              of the WdgM module when Deadline supervision is configured.   **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

/*******************************************************************************
**                     Include Section                                        **
*******************************************************************************/
#include "App_WdgM_DeadlineSupervision.h"

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
uint16 WdgM_GaaTCIdList[] = {22, 23, 24, 25, 26};
App_TCResultType App_GstTCReport[NUMBER_OF_TEST_CASES];
TCFunctionPtr WdgM_GaaTCs[] =
{
  WDGM_ETC_022,  /* TC list Index 0 */
  WDGM_ETC_023,  /* TC list Index 1 */
  WDGM_ETC_024,  /* TC list Index 2 */
  WDGM_ETC_025,  /* TC list Index 4 */
  WDGM_ETC_026   /* TC list Index 5 */
};

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
  **                     Main()                                               **
*******************************************************************************/
int main(void)
{
  uint8 LucTestResult;

  App_GucTestIndex = 0;

  /* Loading the test report with default values */
  App_TestSetUp(App_GstTCReport, WdgM_GaaTCIdList, NUMBER_OF_TEST_CASES);

  /* Loop for all the testcases in this test case file */
  while(App_GucTestIndex < NUMBER_OF_TEST_CASES)
  {
    /* Pre Ample function to load the stubs with default value */
    App_WdgMTestCaseSetUp();

    LucTestResult = (WdgM_GaaTCs[App_GucTestIndex])();
    App_LogTestResult(LucTestResult);
    App_GucTestIndex++;
  }

  #ifdef APP_LOG_TEST_RESULT_TO_FILE
  App_LogTestResultToFile();
  #endif

  return(0);
} /* End main() */

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
