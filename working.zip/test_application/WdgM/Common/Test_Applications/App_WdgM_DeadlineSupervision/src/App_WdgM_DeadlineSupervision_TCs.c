/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: App_WdgM_DeadlineSupervision_TCs.c                            **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Watchdog Manager Module                               **
**                                                                            **
**  PURPOSE   : This application file is used to test the Functionality       **
**              of the WdgM module when Deadline supervision is configured.   **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

/*******************************************************************************
**                     Include Section                                        **
*******************************************************************************/
#include "App_WdgM_DeadlineSupervision_Tcs.h"
#include "WdgM.h"
#include "WdgIf.h"

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                            WDGM_ETC_022()                                  **
*******************************************************************************/
uint8 WDGM_ETC_022 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  App_TestPrepareElapsedValue(WDGM_ALLDEADLINE_COUNT1,
    WDGM_ALLDEADLINE_ADDCOUNT1);

  /* Test Description - 02 */
  WdgM_Init(NULL_PTR);

  /* Test Description - 03 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_CheckpointReached(10, 4);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 09 */
  WdgM_MainFunction();

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_ALIVESUPERVISION_CORRECT)
    != WDGM_ALIVESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  LenReturnVal = WdgM_CheckpointReached(10, 1);

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_DEADLINESUPERVISION_CORRECT)
    == WDGM_DEADLINESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  WdgM_MainFunction();

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_022() */

/*******************************************************************************
**                            WDGM_ETC_023()                                  **
*******************************************************************************/
uint8 WDGM_ETC_023 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (!(WDGM_ETC_022() == APP_TC_PASSED))
  {
    return(APP_PC_FAILED);
  }

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 02 */
  App_TestWdgM_MainFunction(WDGM_DEADLINE_SUPREFCYCLE0);

  /* Test Description - 03 */
  LenReturnVal = WdgM_CheckpointReached(10, 1);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_CheckpointReached(10, 2);

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_DEADLINESUPERVISION_CORRECT)
    != WDGM_DEADLINESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  WdgM_MainFunction();

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_023() */

/*******************************************************************************
**                            WDGM_ETC_024()                                  **
*******************************************************************************/
uint8 WDGM_ETC_024 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;
  WdgM_GlobalStatusType LddGlobalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  App_TestPrepareElapsedValue(WDGM_ALLDEADLINE_COUNT1,
    WDGM_ALLDEADLINE_ADDCOUNT1);

  /* Test Description - 02 */
  WdgM_DeInit();

  /* Test Description - 03 */
  WdgM_Init(NULL_PTR);

  /* Test Description - 04 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddGlobalStatus == WDGM_GLOBAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_CheckpointReached(10, 4);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  LenReturnVal = WdgM_CheckpointReached(10, 1);

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_DEADLINESUPERVISION_CORRECT)
    == WDGM_DEADLINESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 08 */
  App_TestWdgM_MainFunction(WDGM_DEADLINE_SUPREFCYCLE3);

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 1, 65535)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 11 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 2, 65535)))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 09 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 12 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 13 */
  App_GddTestStepId++;
  if (!(LddGlobalStatus == WDGM_GLOBAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_024() */

/*******************************************************************************
**                            WDGM_ETC_025()                                  **
*******************************************************************************/
uint8 WDGM_ETC_025 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;
  WdgM_GlobalStatusType LddGlobalStatus;
  WdgM_ModeType LddMode;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_FAILED))
  {
    return(APP_PC_FAILED);
  }

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/
  App_TestPrepareElapsedValue(WDGM_DEADLINE_COUNT2, WDGM_DEADLINE_ADDCOUNT2);

  /* Test Description - 01 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddGlobalStatus == WDGM_GLOBAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 02 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_CheckpointReached(10, 4);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_CheckpointReached(10, 4);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_CheckpointReached(20, 0);

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  LenReturnVal = WdgM_CheckpointReached(20, 1);

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[1] & WDGM_DEADLINESUPERVISION_CORRECT)
    == WDGM_DEADLINESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  App_TestPrepareElapsedValue(WDGM_ALLDEADLINE_COUNT1,
    WDGM_ALLDEADLINE_ADDCOUNT1);

  /* Test Description - 06 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  LenReturnVal = WdgM_CheckpointReached(10, 1);

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 08 */
  WdgM_MainFunction();

  /* Test Description - 09 */
  LenReturnVal = WdgM_CheckpointReached(10, 4);

  /* Expected Result - 11 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 09 */
  LenReturnVal = WdgM_CheckpointReached(10, 4);

  /* Expected Result - 11 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 08 */
  WdgM_MainFunction();

  /* Test Description - 11 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 12 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 13 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 12 */
  LenReturnVal = WdgM_SetMode(1, BSWM_MODULE_ID);

  /* Expected Result - 14 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 15 */
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK)
    == WDGM_LOCAL_STATUS_DEACTIVATED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 16 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetMode(M_VALIDATE, 1, WDGIF_FAST_MODE)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 17 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetMode(M_VALIDATE, 3, WDGIF_SLOW_MODE)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 18 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetMode(M_VALIDATE, 2, WDGIF_SLOW_MODE)))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 13 */
  LenReturnVal = WdgM_GetMode(&LddMode);

  /* Expected Result - 19 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 20 */
  App_GddTestStepId++;
  if (!(LddMode == (WdgM_ModeType)WDGM_ONE))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 14 */
  WdgM_MainFunction();

  /* Expected Result - 21 */
  App_GddTestStepId++;
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 22 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 1, 65535)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 23 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 2, 65535)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_025() */

/*******************************************************************************
**                            WDGM_ETC_026()                                  **
*******************************************************************************/
uint8 WDGM_ETC_026 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;
  WdgM_GlobalStatusType LddGlobalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (!(WDGM_ETC_024() == APP_TC_PASSED))
  {
    return(APP_PC_FAILED);
  }

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  App_WdgMTestCaseSetUp();

  /* Test Description - 02 */
  App_TestPrepareElapsedValue(WDGM_DEADLINE_COUNT2, WDGM_DEADLINE_ADDCOUNT2);

  /* Test Description - 03 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddGlobalStatus == WDGM_GLOBAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  LenReturnVal = WdgM_CheckpointReached(10, 2);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  LenReturnVal = WdgM_CheckpointReached(10, 3);

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_DEADLINESUPERVISION_CORRECT)
    == WDGM_DEADLINESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  WdgM_MainFunction();

  /* Test Description - 08 */
  App_TestPrepareElapsedValue(WDGM_ALLDEADLINE_COUNT1,
    WDGM_ALLDEADLINE_ADDCOUNT1);

  /* Test Description - 09 */
  LenReturnVal = WdgM_CheckpointReached(10, 2);

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 10 */
  LenReturnVal = WdgM_CheckpointReached(10, 3);

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_DEADLINESUPERVISION_CORRECT)
    != WDGM_DEADLINESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 11 */
  WdgM_MainFunction();

  /* Expected Result - 11 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 12 */
  App_GddTestStepId++;
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 13 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 1, 65535)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 14 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 2, 65535)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_026() */

/******************************************************************************
**                          END OF FILE                                      **
******************************************************************************/
