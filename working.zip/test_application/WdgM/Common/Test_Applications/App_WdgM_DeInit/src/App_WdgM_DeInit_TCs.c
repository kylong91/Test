/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: App_WdgM_DeInit_TCs.c                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Watchdog Manager Module                               **
**                                                                            **
**  PURPOSE   : This application file is used to test the Functionality of    **
**              DET in WdgM_DeInit API.                                       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

/*******************************************************************************
**                     Include Section                                        **
*******************************************************************************/
#include "App_WdgM_DeInit_TCs.h"
#include "WdgM.h"
#include "BswM.h"

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/


/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                            WDGM_ETC_048()                                  **
*******************************************************************************/
uint8 WDGM_ETC_048 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_GlobalStatusType LddGlobalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (WdgM_GblModuleInitStatus == WDGM_UNINITIALIZED)
  {
    if (!(App_WDGM_ETC_002() == APP_TC_PASSED))
    {
      return(APP_PC_FAILED);
    }
    WdgM_GblModuleInitStatus = WDGM_INITIALIZED;
  }

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddGlobalStatus == WDGM_GLOBAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 02 */
  WdgM_DeInit();

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (!(WdgM_GblModuleInitStatus == WDGM_UNINITIALIZED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 1, WDGM_DEINIT_TIMEOUT)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 3, WDGM_DEINIT_TIMEOUT)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 2, WDGM_DEINIT_TIMEOUT)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 07 */
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_DEACTIVATED))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_048() */

/*******************************************************************************
**                          END OF FILE                                      **
*******************************************************************************/
