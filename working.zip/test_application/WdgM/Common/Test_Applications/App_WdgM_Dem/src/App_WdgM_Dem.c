/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: App_WdgM_Dem.c                                                **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Watchdog Manager Module                               **
**                                                                            **
**  PURPOSE   : This application file is used to test the Functionality of    **
**              DEM APIs of the WdgM module.                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

/*******************************************************************************
**                     Include Section                                        **
*******************************************************************************/
#include "App_WdgM_Dem.h"

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
uint16 WdgM_GaaTCIdList[] = {45, 46, 47};
App_TCResultType App_GstTCReport[NUMBER_OF_TEST_CASES];
TCFunctionPtr WdgM_GaaTCs[] =
{
  WDGM_ETC_045, /* TC list Index 0 */
  WDGM_ETC_046, /* TC list Index 1 */
  WDGM_ETC_047  /* TC list Index 2 */
  };

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
  **                     Main()                                               **
*******************************************************************************/
int main(void)
{
  uint8 LucTestResult;

  App_GucTestIndex = 0;

  /* Loading the test report with default values */
  App_TestSetUp(App_GstTCReport, WdgM_GaaTCIdList, NUMBER_OF_TEST_CASES);

  /* Loop for all the testcases in this test case file */
  while(App_GucTestIndex < NUMBER_OF_TEST_CASES)
  {
    /* Pre Ample function to load the stubs with default value */
    App_WdgMTestCaseSetUp();

    /* Set the Det stub behavior to Disable the Error Logging */
    TestSetDet_ReportErrorLogEnable(FALSE);

    LucTestResult = (WdgM_GaaTCs[App_GucTestIndex])();
    App_LogTestResult(LucTestResult);
    App_GucTestIndex++;
  }

  #ifdef APP_LOG_TEST_RESULT_TO_FILE
  App_LogTestResultToFile();
  #endif

  return(0);
} /* End main() */

/******************************************************************************
**                          END OF FILE                                      **
******************************************************************************/
