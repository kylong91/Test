/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: App_WdgM_Dem_TCs.c                                            **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Watchdog Manager Module                               **
**                                                                            **
**  PURPOSE   : This application file is used to test the Functionality of    **
**              DEM APIs of the WdgM module.                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

/*******************************************************************************
**                     Include Section                                        **
*******************************************************************************/
#include "App_WdgM_Dem_Tcs.h"
#include "WdgM.h"
#if (WDGM_DEM_ERROR_REPORT == STD_ON)
#include "WdgM_Dem_Cfg.h"              /* Dem Header file */
#endif
#include "WdgM_Ram.h"

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                            WDGM_ETC_045()                                  **
*******************************************************************************/
uint8 WDGM_ETC_045 (void)
{
  Std_ReturnType LenReturnVal;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_Init(NULL_PTR);

  /* Test Description - 02 */
  TestWdgIf_SetModeSetRetVal(E_NOT_OK);

  /* Test Description - 03 */
  LenReturnVal = WdgM_SetMode(0,  BSWM_MODULE_ID);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(TestDem_ReportErrorStatus(M_VALIDATE, WDGM_E_SET_MODE,
    DEM_EVENT_STATUS_FAILED)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
}  /* End WDGM_ETC_045() */

/*******************************************************************************
**                            WDGM_ETC_046()                                  **
*******************************************************************************/
uint8 WDGM_ETC_046 (void)
{
  Std_ReturnType LenReturnVal;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (WdgM_GblModuleInitStatus == WDGM_UNINITIALIZED)
  {
    if (!(App_WDGM_ETC_002() == APP_TC_PASSED))
    {
      return(APP_PC_FAILED);
    }
    WdgM_GblModuleInitStatus = WDGM_INITIALIZED;
  }

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  LenReturnVal = WdgM_SetMode(0, WDGM_IMPROPER_CALLER);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(TestDem_ReportErrorStatus(S_VALIDATE, WDGM_E_IMPROPER_CALLER,
    DEM_EVENT_STATUS_FAILED)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
}  /* End WDGM_ETC_046() */

/*******************************************************************************
**                            WDGM_ETC_047()                                  **
*******************************************************************************/
uint8 WDGM_ETC_047 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;
  WdgM_GlobalStatusType LddGlobalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (WdgM_GblModuleInitStatus == WDGM_UNINITIALIZED)
  {
    return(APP_PC_FAILED);
  }
  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_DeInit();

  /* Test Description - 02 */
  WdgM_Init(NULL_PTR);

  /* Test Description - 03 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddGlobalStatus == WDGM_GLOBAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  LenReturnVal = WdgM_CheckpointReached(10, 1);

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_DEADLINESUPERVISION_CORRECT)
    != WDGM_DEADLINESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  WdgM_MainFunction();

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_STOPPED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (!(TestDem_ReportErrorStatus(M_VALIDATE, WDGM_E_MONITORING,
    DEM_EVENT_STATUS_FAILED)))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 08 */
  LenReturnVal = WdgM_SetMode(1, BSWM_MODULE_ID);

  /* Expected Result - 11 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 12 */
  App_GddTestStepId++;
  if (WdgM_GddCurrentMode  == 0x01)
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
}  /* End WDGM_ETC_047() */
/******************************************************************************
**                          END OF FILE                                      **
******************************************************************************/
