/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: App_WdgM_Det_On_TCs.h                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Watchdog Manager Module                               **
**                                                                            **
**  PURPOSE   : C header for App_WdgM_Det_On_TCs.c                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef APP_WDGM_DET_ON_TCS_H
#define APP_WDGM_DET_ON_TCS_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "App_WdgM_Sub_Functions.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern uint8 WDGM_ETC_034(void);
extern uint8 WDGM_ETC_035(void);
extern uint8 WDGM_ETC_036(void);
extern uint8 WDGM_ETC_037(void);
extern uint8 WDGM_ETC_038(void);
extern uint8 WDGM_ETC_039(void);
extern uint8 WDGM_ETC_040(void);
extern uint8 WDGM_ETC_041(void);

#endif /* End of APP_WDGM_DET_TCS_H */
/*******************************************************************************
**                       End of File                                          **
*******************************************************************************/
