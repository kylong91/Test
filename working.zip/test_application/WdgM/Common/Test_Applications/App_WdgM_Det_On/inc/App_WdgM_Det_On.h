/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: App_WdgM_Det_On.h                                             **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Watchdog Manager Module                               **
**                                                                            **
**  PURPOSE   : C header for App_WdgM_Det_On.c                                **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef APP_WDGM_DET_ON_H
#define APP_WDGM_DET_ON_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "App_WdgM_Det_On_TCs.h"

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/
#define NUMBER_OF_TEST_CASES 0x08
#define WDGM_INVALID_MODE                        (WdgM_ModeType)3
#define WDGM_INVALID_SEID                        (WdgM_SupervisedEntityIdType)22
#define WDGM_INVALID_CHCKPTID                    (WdgM_CheckpointIdType)3

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
extern App_TCResultType App_GstTCReport[NUMBER_OF_TEST_CASES];

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#endif /* End of APP_WDGM_DET_H */
/*******************************************************************************
**                       End of File                                          **
*******************************************************************************/
