/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: App_WdgM_Det_On_TCs.c                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Watchdog Manager Module                               **
**                                                                            **
**  PURPOSE   : This application file is used to test the Functionality of    **
**              DET of the WdgM module.                                       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

/*******************************************************************************
**                     Include Section                                        **
*******************************************************************************/
#include "WdgM.h"
#include "WdgM_PCTypes.h"
#include "WdgIf.h"
#include "Det.h"
#include "SchM_WdgM.h"
#include "App_WdgM_Det_On_Tcs.h"

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                            WDGM_ETC_034()                                  **
*******************************************************************************/
uint8 WDGM_ETC_034(void)
{
  Std_ReturnType LenReturnVal;
  WdgM_ModeType LddMode;
  WdgM_LocalStatusType LddLocalStatus;
  WdgM_GlobalStatusType LddGlobalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (WdgM_GblModuleInitStatus != WDGM_UNINITIALIZED)
  {
    return(APP_PC_FAILED);
  }

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_DeInit();

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_DEINIT_SID,WDGM_E_NO_INIT)))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 02 */
  LenReturnVal = WdgM_SetMode(0, BSWM_MODULE_ID);

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_SETMODE_SID, WDGM_E_NO_INIT)))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_GetMode(&LddMode);

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_GETMODE_SID, WDGM_E_NO_INIT)))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_CHECKPOINTREACHED_SID, WDGM_E_NO_INIT)))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_GETLOCALSTATUS_SID, WDGM_E_NO_INIT)))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 11 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_GETGLOBALSTATUS_SID, WDGM_E_NO_INIT)))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  WdgM_PerformReset();

  /* Expected Result - 12 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_PERFORMRESET_SID, WDGM_E_NO_INIT)))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 08 */
  WdgM_MainFunction();

  /* Expected Result - 13 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_MAINFUNCTION_SID, WDGM_E_NO_INIT)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_034() */

/*******************************************************************************
**                            WDGM_ETC_035()                                  **
*******************************************************************************/
uint8 WDGM_ETC_035(void)
{
  Std_ReturnType LenReturnVal;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (WdgM_GblModuleInitStatus == WDGM_UNINITIALIZED)
  {
    if (!(App_WDGM_ETC_002() == APP_TC_PASSED))
    {
      return(APP_PC_FAILED);
    }
    WdgM_GblModuleInitStatus = WDGM_INITIALIZED;
  }

  /* Set the Det stub behavior to Disable the Error Logging */
  TestDet_DefaultBehavior();
  TestSetDet_ReportErrorLogEnable(FALSE);

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  LenReturnVal = WdgM_SetMode(WDGM_INVALID_MODE, BSWM_MODULE_ID);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_SETMODE_SID, WDGM_E_PARAM_MODE)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_035() */

/*******************************************************************************
**                            WDGM_ETC_036()                                  **
*******************************************************************************/
uint8 WDGM_ETC_036(void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (WdgM_GblModuleInitStatus == WDGM_UNINITIALIZED)
  {
    if (!(App_WDGM_ETC_002() == APP_TC_PASSED))
    {
      return(APP_PC_FAILED);
    }
    WdgM_GblModuleInitStatus = WDGM_INITIALIZED;
  }

  /* Set the Det stub behavior to Disable the Error Logging */
  TestDet_DefaultBehavior();
  TestSetDet_ReportErrorLogEnable(FALSE);

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test description - 01 */
  LenReturnVal = WdgM_CheckpointReached(WDGM_INVALID_SEID, 0);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_CHECKPOINTREACHED_SID, WDGM_E_PARAM_SEID)))
  {
    return(APP_TC_FAILED);
  }

  /* Test description - 02 */
  LenReturnVal = WdgM_UpdateAliveCounter(WDGM_INVALID_SEID);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_UPDATEALIVECOUNTER_SID, WDGM_E_PARAM_SEID)))
  {
    return(APP_TC_FAILED);
  }

  /* Test description - 03 */
  LenReturnVal = WdgM_GetLocalStatus(WDGM_INVALID_SEID, & LddLocalStatus);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_GETLOCALSTATUS_SID, WDGM_E_PARAM_SEID)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_036() */

/*******************************************************************************
**                            WDGM_ETC_037()                                  **
*******************************************************************************/
uint8 WDGM_ETC_037(void)
{
  Std_ReturnType LenReturnVal;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (WdgM_GblModuleInitStatus == WDGM_UNINITIALIZED)
  {
    if (!(App_WDGM_ETC_002() == APP_TC_PASSED))
    {
      return(APP_PC_FAILED);
    }
    WdgM_GblModuleInitStatus = WDGM_INITIALIZED;
  }

  /* Set the Det stub behavior to Disable the Error Logging */
  TestDet_DefaultBehavior();
  TestSetDet_ReportErrorLogEnable(FALSE);

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test description - 01 */
  WdgM_GetVersionInfo(NULL_PTR);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_GETVERSIONINFO_SID, WDGM_E_INV_POINTER)))
  {
    return(APP_TC_FAILED);
  }

  /* Test description - 02 */
  LenReturnVal = WdgM_GetMode(NULL_PTR);

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_GETMODE_SID, WDGM_E_INV_POINTER)))
  {
    return(APP_TC_FAILED);
  }

  /* Test description - 03 */
  LenReturnVal = WdgM_GetLocalStatus(10, NULL_PTR);

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_GETLOCALSTATUS_SID, WDGM_E_INV_POINTER)))
  {
    return(APP_TC_FAILED);
  }

  /* Test description - 04 */
  LenReturnVal = WdgM_GetGlobalStatus(NULL_PTR);

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_GETGLOBALSTATUS_SID, WDGM_E_INV_POINTER)))
  {
    return(APP_TC_FAILED);
  }

  /* Test description - 05 */
  LenReturnVal = WdgM_GetFirstExpiredSEID(NULL_PTR);

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID, WDGM_INSTANCE_ID,
    WDGM_GETFIRSTEXPIRED_SEID_SID, WDGM_E_INV_POINTER)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_037() */

/*******************************************************************************
**                            WDGM_ETC_038()                                  **
*******************************************************************************/
uint8 WDGM_ETC_038(void)
{
  Std_ReturnType LenReturnVal;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (WdgM_GblModuleInitStatus == WDGM_UNINITIALIZED)
  {
    if (!(App_WDGM_ETC_002() == APP_TC_PASSED))
    {
      return(APP_PC_FAILED);
    }
    WdgM_GblModuleInitStatus = WDGM_INITIALIZED;
  }

  /* Set the Det stub behavior to Disable the Error Logging */
  TestDet_DefaultBehavior();
  TestSetDet_ReportErrorLogEnable(FALSE);

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/
  /* Test Description - 01 */
  LenReturnVal = WdgM_SetMode(1, BSWM_MODULE_ID);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_SETMODE_SID, WDGM_E_DISABLE_NOT_ALLOWED)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* WDGM_ETC_038() */

/*******************************************************************************
**                            WDGM_ETC_039()                                  **
*******************************************************************************/
uint8 WDGM_ETC_039(void)
{
  Std_ReturnType LenReturnVal;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (WdgM_GblModuleInitStatus == WDGM_UNINITIALIZED)
  {
    if (!(App_WDGM_ETC_002() == APP_TC_PASSED))
    {
      return(APP_PC_FAILED);
    }
    WdgM_GblModuleInitStatus = WDGM_INITIALIZED;
  }

  /* Set the Det stub behavior to Disable the Error Logging */
  TestDet_DefaultBehavior();
  TestSetDet_ReportErrorLogEnable(FALSE);

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  LenReturnVal = WdgM_CheckpointReached(10, WDGM_INVALID_CHCKPTID);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_CHECKPOINTREACHED_SID, WDGM_E_CPID)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_039() */

/*******************************************************************************
**                            WDGM_ETC_040()                                  **
*******************************************************************************/
uint8 WDGM_ETC_040(void)
{
  Std_ReturnType LenReturnVal;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (WdgM_GblModuleInitStatus == WDGM_UNINITIALIZED)
  {
    if (!(App_WDGM_ETC_002() == APP_TC_PASSED))
    {
      return(APP_PC_FAILED);
    }
    WdgM_GblModuleInitStatus = WDGM_INITIALIZED;
  }

  /* Set the Det stub behavior to Disable the Error Logging */
  TestDet_DefaultBehavior();
  TestSetDet_ReportErrorLogEnable(FALSE);

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  LenReturnVal = WdgM_UpdateAliveCounter(10);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal != E_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_UPDATEALIVECOUNTER_SID, WDGM_E_DEPRECATED)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_040() */

/*******************************************************************************
**                            WDGM_ETC_041()                                  **
*******************************************************************************/
uint8 WDGM_ETC_041(void)
{
  Std_ReturnType LenReturnVal;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (WdgM_GblModuleInitStatus == WDGM_UNINITIALIZED)
  {
    if (!(App_WDGM_ETC_002() == APP_TC_PASSED))
    {
      return(APP_PC_FAILED);
    }
    WdgM_GblModuleInitStatus = WDGM_INITIALIZED;
  }

  /* Set the Det stub behavior to Disable the Error Logging */
  TestDet_DefaultBehavior();
  TestSetDet_ReportErrorLogEnable(FALSE);

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  LenReturnVal = WdgM_CheckpointReached(20, 0);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(TestDet_ReportError(S_VALIDATE, WDGM_MODULE_ID,
    WDGM_INSTANCE_ID, WDGM_CHECKPOINTREACHED_SID, WDGM_E_SEDEACTIVATED)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_041() */
/*******************************************************************************
**                          END OF FILE                                      **
*******************************************************************************/
