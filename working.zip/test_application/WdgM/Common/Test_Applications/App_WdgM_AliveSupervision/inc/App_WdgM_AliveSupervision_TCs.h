/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: App_WdgM_AliveSupervision_TCs.h                               **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Watchdog Manager Module                               **
**                                                                            **
**  PURPOSE   : C header for App_WdgM_AliveSupervision_TCs.c                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef APP_WDGM_ALIVESUPERVISION_TCS_H
#define APP_WDGM_ALIVESUPERVISION_TCS_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "App_WdgM_Sub_Functions.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern uint8 WDGM_ETC_003(void);
extern uint8 WDGM_ETC_004(void);
extern uint8 WDGM_ETC_005(void);
extern uint8 WDGM_ETC_006(void);
extern uint8 WDGM_ETC_007(void);
extern uint8 WDGM_ETC_008(void);
extern uint8 WDGM_ETC_009(void);
extern uint8 WDGM_ETC_010(void);
extern uint8 WDGM_ETC_011(void);

#endif /* End of App_WdgM_AliveSupervision.h */
/*******************************************************************************
**                       End of File                                          **
*******************************************************************************/
