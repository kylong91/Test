/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: App_WdgM_AliveSupervision_TCs.c                               **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Watchdog Manager Module                               **
**                                                                            **
**  PURPOSE   : This application file is used to test the Functionality       **
**              of the WdgM module when Alive supervision is configured.      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

/*******************************************************************************
**                     Include Section                                        **
*******************************************************************************/
#include "App_WdgM_AliveSupervision_Tcs.h"
#include "WdgIf.h"
#include "WdgM.h"
#include "BswM.h"
#include "Mcu.h"
#if (WDGM_DEM_ERROR_REPORT == STD_ON)
#include "Wdgm_Dem_Cfg.h"              /* Dem Header file */
#endif
#include "Det.h"

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                            WDGM_ETC_003()                                  **
*******************************************************************************/
uint8 WDGM_ETC_003 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;
  WdgM_GlobalStatusType LddGlobalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (WdgM_GblModuleInitStatus == WDGM_UNINITIALIZED)
  {
    if (!(App_WDGM_ETC_002() == APP_TC_PASSED))
    {
      return(APP_PC_FAILED);
    }
  }

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddGlobalStatus == WDGM_GLOBAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 02 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_GetLocalStatus(20, &LddLocalStatus);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_DEACTIVATED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  WdgM_MainFunction();

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 1, 65535)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 3, 65535)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 2, 65535)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_003() */

/*******************************************************************************
**                            WDGM_ETC_004()                                  **
*******************************************************************************/
uint8 WDGM_ETC_004 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_GlobalStatusType LddGlobalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (WdgM_GblModuleInitStatus == WDGM_UNINITIALIZED)
  {
    if (!(App_WDGM_ETC_002() == APP_TC_PASSED))
    {
      return(APP_PC_FAILED);
    }
  }

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  LenReturnVal = WdgM_SetMode(0, BSWM_MODULE_ID);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (WdgM_GddCurrentMode  != WDGM_INIT_MODE)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 02 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(LddGlobalStatus == WDGM_GLOBAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  TestWdgIf_SetModeSetRetVal(E_NOT_OK);

  /* Test Description - 04 */
  LenReturnVal = WdgM_SetMode(1, BSWM_MODULE_ID);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal != E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetMode(M_VALIDATE, 1, WDGIF_FAST_MODE)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_STOPPED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 1, 0)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 3, 0)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 2, 0)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_004() */

/*******************************************************************************
**                            WDGM_ETC_005()                                  **
*******************************************************************************/
uint8 WDGM_ETC_005 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_GlobalStatusType LddGlobalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_STOPPED))
  {
    return(APP_PC_FAILED);
  }

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddGlobalStatus == WDGM_GLOBAL_STATUS_STOPPED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 02 */
  WdgM_MainFunction();

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_STOPPED))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_005() */

/*******************************************************************************
**                            WDGM_ETC_006()                                  **
*******************************************************************************/
uint8 WDGM_ETC_006 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;
  WdgM_GlobalStatusType LddGlobalStatus;
  WdgM_ModeType LddMode;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_DeInit();

  /* Test Description - 02 */
  WdgM_Init(NULL_PTR);

  /* Test Description - 03 */
  App_WdgMTestCaseSetUp();

  /* Test Description - 04 */
  LenReturnVal = WdgM_GetLocalStatus(20, &LddLocalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_DEACTIVATED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(LddGlobalStatus == WDGM_GLOBAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  LenReturnVal = WdgM_SetMode(1, BSWM_MODULE_ID);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetMode(M_VALIDATE, 1, WDGIF_FAST_MODE)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetMode(M_VALIDATE, 3, WDGIF_SLOW_MODE)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetMode(M_VALIDATE, 2, WDGIF_SLOW_MODE)))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  WdgM_MainFunction();

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[1] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 08 */
  LenReturnVal = WdgM_GetMode(&LddMode);

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 11 */
  App_GddTestStepId++;
  if (!(LddMode == (WdgM_ModeType)WDGM_ONE))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_006() */

/*******************************************************************************
**                            WDGM_ETC_007()                                  **
*******************************************************************************/
uint8 WDGM_ETC_007 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_DeInit();

  /* Test Description - 02 */
  WdgM_Init(NULL_PTR);

  /* Test Description - 03 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  App_TestWdgM_MainFunction(WDGM_ALIVE_SUPREFCYCLE0);

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_ALIVESUPERVISION_CORRECT)
    == WDGM_ALIVESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_007() */

/*******************************************************************************
**                            WDGM_ETC_008()                                  **
*******************************************************************************/
uint8 WDGM_ETC_008 (void)
{

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_PerformReset();

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_STOPPED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 1, 0)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 3, 0)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 2, 0)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_008() */

/*******************************************************************************
**                            WDGM_ETC_009()                                  **
*******************************************************************************/
uint8 WDGM_ETC_009 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;
  WdgM_GlobalStatusType LddGlobalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_DeInit();

  /* Test Description - 02 */
  WdgM_Init(NULL_PTR);

  /* Test Description - 03 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddGlobalStatus == WDGM_GLOBAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_GetLocalStatus(224, &LddLocalStatus);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  LenReturnVal = WdgM_CheckpointReached(224, 1);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  LenReturnVal = WdgM_CheckpointReached(224, 1);

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  App_TestWdgM_MainFunction(WDGM_ALIVE_SUPREFCYCLE1);

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[3] & WDGM_ALIVESUPERVISION_CORRECT)
    != WDGM_ALIVESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[3] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_STOPPED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (!(TestWdgM_McuPerformReset(S_VALIDATE)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_009() */

/*******************************************************************************
**                            WDGM_ETC_010()                                  **
*******************************************************************************/
uint8 WDGM_ETC_010 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;
  ApplicationType LddApplication;
  LddApplication = (ApplicationType)0;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_DeInit();

  /* Test Description - 02 */
  WdgM_Init(NULL_PTR);

  /* Test Description - 03 */
  App_WdgMTestCaseSetUp();

  /* Test Description - 04 */
  LenReturnVal = WdgM_GetLocalStatus(42, &LddLocalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  LenReturnVal = WdgM_CheckpointReached(42, 0);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  LenReturnVal = WdgM_CheckpointReached(42, 0);

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  App_TestWdgM_MainFunction(WDGM_ALIVE_SUPREFCYCLE1);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[2] & WDGM_ALIVESUPERVISION_CORRECT)
    != WDGM_ALIVESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[2] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!(TestBswM_WdgM_RequestPartitionReset(S_VALIDATE, LddApplication)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_010() */

/*******************************************************************************
**                            WDGM_ETC_011()                                  **
*******************************************************************************/
uint8 WDGM_ETC_011 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;
  WdgM_GlobalStatusType LddGlobalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  App_WdgMTestCaseSetUp();

  /* Test Description - 02 */
  App_TestPrepareElapsedValue(WDGM_ALLDEADLINE_COUNT1,
    WDGM_ALLDEADLINE_ADDCOUNT1);

  /* Test Description - 03 */
  WdgM_DeInit();

  /* Test Description - 04 */
  WdgM_Init(NULL_PTR);

  /* Test Description - 05 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddGlobalStatus == WDGM_GLOBAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  LenReturnVal = WdgM_SetMode(1, BSWM_MODULE_ID);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 08 */
  LenReturnVal = WdgM_CheckpointReached(42, 1);

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 09 */
  WdgM_MainFunction();

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[2] & WDGM_ALIVESUPERVISION_CORRECT)
    != WDGM_ALIVESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[2] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 1, 65535)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 11 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 3, 65535)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 12 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 2, 65535)))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 10 */
  WdgM_MainFunction();

  /* Expected Result - 13 */
  App_GddTestStepId++;
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 14 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 1, 65535)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 15 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 3, 65535)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 16 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 2, 65535)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_011() */

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
