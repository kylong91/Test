/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: App_WdgM_AllSupervisions_TCs.h                                **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Watchdog Manager Module                               **
**                                                                            **
**  PURPOSE   : C header for App_WdgM_AllSupervisions_TCs.c                   **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef APP_WDGM_ALLSUPERVISIONS_TCS_H
#define APP_WDGM_ALLSUPERVISIONS_TCS_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "App_WdgM_Sub_Functions.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern uint8 WDGM_ETC_027(void);
extern uint8 WDGM_ETC_028(void);
extern uint8 WDGM_ETC_029(void);
extern uint8 WDGM_ETC_030(void);
extern uint8 WDGM_ETC_031(void);
extern uint8 WDGM_ETC_032(void);
extern uint8 WDGM_ETC_033(void);

#endif /* End of App_WdgM_AllSupervisions_TCs.h */
/*******************************************************************************
**                       End of File                                          **
*******************************************************************************/
