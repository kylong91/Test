/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: App_WdgM_AllSupervisions.c                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Watchdog Manager Module                               **
**                                                                            **
**  PURPOSE   : This application file is used to test the Functionality       **
**              of the WdgM module when all three supervisions                **
**			       (Alive, Deadline and Logical supervision) are configured.      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

/*******************************************************************************
**                     Include Section                                        **
*******************************************************************************/
#include "App_WdgM_AllSupervisions.h"

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
uint16 WdgM_GaaTCIdList[] = {27, 28, 29, 30, 31, 32, 33};
App_TCResultType App_GstTCReport[NUMBER_OF_TEST_CASES];
TCFunctionPtr WdgM_GaaTCs[] =
{
  WDGM_ETC_027,  /* TC list Index 0 */
  WDGM_ETC_028,  /* TC list Index 1 */
  WDGM_ETC_029,  /* TC list Index 2 */
  WDGM_ETC_030,  /* TC list Index 3 */
  WDGM_ETC_031,  /* TC list Index 4 */
  WDGM_ETC_032,  /* TC list Index 5 */
  WDGM_ETC_033   /* TC list Index 6 */
};

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
  **                     Main()                                               **
*******************************************************************************/
int main(void)
{
  uint8 LucTestResult;

  App_GucTestIndex = 0;

  /* Loading the test report with defualt values */
  App_TestSetUp(App_GstTCReport, WdgM_GaaTCIdList, NUMBER_OF_TEST_CASES);

  /* Loop for all the testcases in this test case file */
  while(App_GucTestIndex < NUMBER_OF_TEST_CASES)
  {
    /* Pre Ample function to load the stubs with default value */
    App_WdgMTestCaseSetUp();

    /* Set the Det stub behavior to Disable the Error Logging */
    TestSetDet_ReportErrorLogEnable(FALSE);

    LucTestResult = (WdgM_GaaTCs[App_GucTestIndex])();
    App_LogTestResult(LucTestResult);
    App_GucTestIndex++;
  }

  #ifdef APP_LOG_TEST_RESULT_TO_FILE
  App_LogTestResultToFile();
  #endif

  return(0);
} /* End main() */

/******************************************************************************
**                          END OF FILE                                      **
******************************************************************************/
