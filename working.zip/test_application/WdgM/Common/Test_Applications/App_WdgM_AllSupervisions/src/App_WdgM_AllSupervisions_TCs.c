/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: App_WdgM_AllSupervisions_TCs.c                                **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Watchdog Manager Module                               **
**                                                                            **
**  PURPOSE   : This application file is used to test the Functionality       **
**              of the WdgM module when all three supervisions                **
**			       (Alive, Deadline and Logical supervision) are configured.      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

/*******************************************************************************
**                     Include Section                                        **
*******************************************************************************/
#include "App_WdgM_AllSupervisions_Tcs.h"
#include "WdgM.h"
#include "WdgIf.h"
#include "Rte_WdgM.h"

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                            WDGM_ETC_027()                                  **
*******************************************************************************/
uint8 WDGM_ETC_027 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;
  WdgM_GlobalStatusType LddGlobalStatus;
  WdgM_ModeType LddMode;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  App_WdgMTestCaseSetUp();

  /* Test Description - 02 */
  WdgM_Init(NULL_PTR);

  /* Test Description - 03 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddGlobalStatus == WDGM_GLOBAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  App_TestPrepareElapsedValue(WDGM_ALLDEADLINE_COUNT1,
    WDGM_ALLDEADLINE_ADDCOUNT1);

  /* Test Description - 06 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  LenReturnVal = WdgM_CheckpointReached(10, 1);

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_DEADLINESUPERVISION_CORRECT)
    == WDGM_DEADLINESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    == WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 08 */
  WdgM_MainFunction();

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_ALIVESUPERVISION_CORRECT)
    != WDGM_ALIVESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 11 */
  App_GddTestStepId++;
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 12 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 3, 65535)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 13 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetTriggerCondition(M_VALIDATE, 1, 65535)))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 09 */
  LenReturnVal = WdgM_SetMode(2, BSWM_MODULE_ID);

  /* Expected Result - 14 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 15 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetMode(M_VALIDATE, 3, WDGIF_SLOW_MODE)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 16 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetMode(M_VALIDATE, 1, WDGIF_FAST_MODE)))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 10 */
  LenReturnVal = WdgM_GetMode(&LddMode);

  /* Expected Result - 17 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 18 */
  App_GddTestStepId++;
  if (!(LddMode == (WdgM_ModeType)WDGM_TWO))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_027() */

/*******************************************************************************
**                            WDGM_ETC_028()                                  **
*******************************************************************************/
uint8 WDGM_ETC_028 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (WdgM_GblModuleInitStatus == WDGM_UNINITIALIZED)
  {
    return(APP_PC_FAILED);
  }

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_DeInit();

  /* Test Description - 02 */
  WdgM_Init(NULL_PTR);

  /* Test Description - 03 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  LenReturnVal = WdgM_CheckpointReached(10, 1);

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_DEADLINESUPERVISION_CORRECT)
    == WDGM_DEADLINESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    == WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  WdgM_MainFunction();

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_ALIVESUPERVISION_CORRECT)
    != WDGM_ALIVESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (!(TestRte_Switch_WdgM_mode_WdgMSupervisedEntity0_currentMode(M_VALIDATE,
    WDGM_LOCAL_STATUS_FAILED)))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_028() */

/*******************************************************************************
**                            WDGM_ETC_029()                                  **
*******************************************************************************/
uint8 WDGM_ETC_029 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (!(WDGM_ETC_028() == APP_TC_PASSED))
  {
    return(APP_PC_FAILED);
  }

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 02 */
  LenReturnVal = WdgM_CheckpointReached(10, 2);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_CheckpointReached(10, 3);

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_DEADLINESUPERVISION_CORRECT)
    == WDGM_DEADLINESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    == WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  WdgM_MainFunction();

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_ALIVESUPERVISION_CORRECT)
    != WDGM_ALIVESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_029() */

/*******************************************************************************
**                            WDGM_ETC_030()                                  **
*******************************************************************************/
uint8 WDGM_ETC_030 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (!(WDGM_ETC_028() == APP_TC_PASSED))
  {
    return(APP_PC_FAILED);
  }

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 11 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 02 */
  LenReturnVal = WdgM_CheckpointReached(10, 2);

  /* Expected Result - 12 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 03 */
  LenReturnVal = WdgM_CheckpointReached(10, 3);

  /* Expected Result - 13 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 14 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 15 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 16 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    == WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  WdgM_MainFunction();

  /* Expected Result - 17 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_ALIVESUPERVISION_CORRECT)
    == WDGM_ALIVESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 18 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_030() */

/*******************************************************************************
**                            WDGM_ETC_031()                                  **
*******************************************************************************/
uint8 WDGM_ETC_031 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (WdgM_GblModuleInitStatus == WDGM_UNINITIALIZED)
  {
    return(APP_PC_FAILED);
  }

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_DeInit();

  /* Test Description - 02 */
  WdgM_Init(NULL_PTR);

  /* Test Description - 03 */
  LenReturnVal = WdgM_GetLocalStatus(224, &LddLocalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_DEACTIVATED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  WdgM_MainFunction();

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[2] & WDGM_STATUS_MASK)
    == WDGM_LOCAL_STATUS_DEACTIVATED))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_031() */

/*******************************************************************************
**                            WDGM_ETC_032()                                  **
*******************************************************************************/
uint8 WDGM_ETC_032 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;
  WdgM_GlobalStatusType LddGlobalStatus;
  WdgM_ModeType LddMode;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (WdgM_GblModuleInitStatus == WDGM_UNINITIALIZED)
  {
    return(APP_PC_FAILED);
  }
  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  WdgM_DeInit();

  /* Test Description - 02 */
  WdgM_Init(NULL_PTR);

  /* Test Description - 01 */
  App_WdgMTestCaseSetUp();

  /* Test Description - 03 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 04 */
  LenReturnVal = WdgM_GetLocalStatus(20, &LddLocalStatus);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  LenReturnVal = WdgM_CheckpointReached(10, 4);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  LenReturnVal = WdgM_CheckpointReached(20, 3);

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    == WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  LenReturnVal = WdgM_CheckpointReached(10, 5);

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_DEADLINESUPERVISION_CORRECT)
    == WDGM_DEADLINESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 08 */
  WdgM_MainFunction();

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_ALIVESUPERVISION_CORRECT)
    != WDGM_ALIVESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 11 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK)
    == WDGM_LOCAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 09 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 12 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 13 */
  App_GddTestStepId++;
  if (!(LddGlobalStatus == WDGM_GLOBAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 10 */
  LenReturnVal = WdgM_SetMode(1, BSWM_MODULE_ID);

  /* Expected Result - 14 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 15 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetMode(M_VALIDATE, 3, WDGIF_SLOW_MODE)))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 16 */
  App_GddTestStepId++;
  if (!(TestWdgIf_SetMode(M_VALIDATE, 1, WDGIF_FAST_MODE)))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 11 */
  WdgM_MainFunction();

  /* Expected Result - 17 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK)
    == WDGM_LOCAL_STATUS_DEACTIVATED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 18 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[1] & WDGM_STATUS_MASK)
    == WDGM_LOCAL_STATUS_DEACTIVATED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 19 */
  App_GddTestStepId++;
  if (!((WdgM_GddFailedRefCycleCounter[0] == WDGM_ZERO)
    && (WdgM_GddFailedRefCycleCounter[1] == WDGM_ZERO)))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 12 */
  LenReturnVal = WdgM_GetMode(&LddMode);

  /* Expected Result - 20 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 21 */
  App_GddTestStepId++;
  if (!(LddMode == (WdgM_ModeType)WDGM_ONE))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_032() */

/*******************************************************************************
**                            WDGM_ETC_033()                                  **
*******************************************************************************/
uint8 WDGM_ETC_033 (void)
{
  Std_ReturnType LenReturnVal;
  WdgM_LocalStatusType LddLocalStatus;
  WdgM_GlobalStatusType LddGlobalStatus;

  /*****************************************************************************
  **                              Pre Condition                               **
  *****************************************************************************/
  if (WdgM_GblModuleInitStatus == WDGM_UNINITIALIZED)
  {
    return(APP_PC_FAILED);
  }

  /*****************************************************************************
  **                              Test Body                                   **
  *****************************************************************************/

  /* Test Description - 01 */
  App_WdgMTestCaseSetUp();

  /* Test Description - 02 */
  WdgM_DeInit();

  /* Test Description - 03 */
  WdgM_Init(NULL_PTR);

  /* Test Description - 04 */
  LenReturnVal = WdgM_GetGlobalStatus(&LddGlobalStatus);

  /* Expected Result - 01 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 02 */
  App_GddTestStepId++;
  if (!(LddGlobalStatus == WDGM_GLOBAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 05 */
  LenReturnVal = WdgM_GetLocalStatus(10, &LddLocalStatus);

  /* Expected Result - 03 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 04 */
  App_GddTestStepId++;
  if (!(LddLocalStatus == WDGM_LOCAL_STATUS_OK))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 06 */
  LenReturnVal = WdgM_CheckpointReached(10, 0);

  /* Expected Result - 05 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 07 */
  LenReturnVal = WdgM_CheckpointReached(10, 1);

  /* Expected Result - 06 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 07 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    == WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 08 */
  App_TestWdgM_MainFunction(WDGM_ALL_SUPREFCYCLE0);

  /* Expected Result - 08 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_ALIVESUPERVISION_CORRECT)
    != WDGM_ALIVESUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 09 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 10 */
  App_GddTestStepId++;
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_FAILED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 09 */
  LenReturnVal = WdgM_CheckpointReached(10, 1);

  /* Expected Result - 11 */
  App_GddTestStepId++;
  if (LenReturnVal == E_NOT_OK)
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 12 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[0] & WDGM_LGSUPERVISION_CORRECT)
    != WDGM_LGSUPERVISION_CORRECT))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 10 */
  WdgM_MainFunction();

  /* Expected Result - 13 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[1] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  /* Test Description - 11 */
  App_TestWdgM_MainFunction(WDGM_ALL_SUPREFCYCLE2);
  WdgM_MainFunction();

  /* Expected Result - 14 */
  App_GddTestStepId++;
  if (!((WdgM_GaaSEStatus[1] & WDGM_STATUS_MASK) == WDGM_LOCAL_STATUS_EXPIRED))
  {
    return(APP_TC_FAILED);
  }

  /* Expected Result - 15 */
  App_GddTestStepId++;
  if (!(WdgM_GddGlobalSupervisionStatus == WDGM_GLOBAL_STATUS_STOPPED))
  {
    return(APP_TC_FAILED);
  }

  return(APP_TC_PASSED);
} /* End WDGM_ETC_033() */

/******************************************************************************
**                          END OF FILE                                      **
******************************************************************************/
