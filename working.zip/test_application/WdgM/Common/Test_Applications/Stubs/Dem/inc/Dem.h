/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Dem.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Dem Stub                                              **
**                                                                            **
**  PURPOSE   : Declaration of Dem Stub functions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef DEM_H
#define DEM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

#include "TC_Generic.h"
#include "Dem_Types.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define DEM_AR_RELEASE_MAJOR_VERSION     0x04
#define DEM_AR_RELEASE_MINOR_VERSION     0x00
#define DEM_AR_RELEASE_REVISION_VERSION  0x03

/* Software Version Information */
#define DEM_SW_MAJOR_VERSION         1
#define DEM_SW_MINOR_VERSION         0
#define DEM_MODULE_ID (uint16)54

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define DEM_ARRAY_SIZE                   0x1F

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#define DemConfigSet0 &Dem_GaaConfig[0]
#define DemConfigSet1 &Dem_GaaConfig[1]

/* WDGM_E_IMPROPER_CALLER */
#define DemConf_DemEventParameter_DemEventParameter0  (Dem_EventIdType)0
/* WDGM_E_MONITORING */
#define DemConf_DemEventParameter_DemEventParameter1  (Dem_EventIdType)1
/* WDGM_E_SET_MODE */
#define DemConf_DemEventParameter_DemEventParameter2  (Dem_EventIdType)2

typedef struct STag_Dem_ConfigType
{
  uint8 dummy;
}Dem_ConfigType;
extern const Dem_ConfigType Dem_GaaConfig[2];
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern boolean TestDem_ReportErrorStatus(App_DataValidateType LucDataValidate,
  Dem_EventIdType LddExpEventId, Dem_EventStatusType LddExpEventStatus);

extern void TestDem_DefaultBehavior(void);

extern boolean TestDem_GetDTCOfEvent(App_DataValidateType LucDataValidate,
  Dem_EventIdType LddExpEventId, Dem_DTCFormatType LddExpDTCKind,
  uint32* ExpDTCOfEvent);
   
extern boolean TestDem_DltGetAllExtendedDataRecords(App_DataValidateType LucDataValidate,
  Dem_EventIdType LddExpEventId, uint8* ExpDestBuffer, uint8* ExpBufSize);
  
extern boolean TestDem_GetEventExtendedDataRecord(App_DataValidateType LucDataValidate,
  Dem_EventIdType LddExpEventId, uint8 LucRecordNumber, uint8* ExpDestBuffer,
  uint8* ExpBufSize);

extern boolean TestDem_DltGetMostRecentFreezeFrameRecordData(App_DataValidateType LucDataValidate,
  Dem_EventIdType LddExpEventId, uint8* DestBuffer, uint8* BufSize);

extern boolean TestDem_GetEventFreezeFrameData(App_DataValidateType LucDataValidate,
  Dem_EventIdType LddExpEventId, uint8 LucRecordNumber,
  boolean LblReportTotalRecord, uint16 LucDataId, uint8* DestBuffer, uint8* BufSize);
  
extern void TestSetDem_GetDTCOfEvent(Std_ReturnType LddReturnVal);

extern void TestSetDem_DltGetAllExtendedDataRecords(Std_ReturnType LddReturnVal);
  
extern void TestSetDem_DltGetMostRecentFreezeFrameRecordData(Std_ReturnType LddReturnVal);

extern void TestSetDem_GetEventExtendedDataRecord(Std_ReturnType LddReturnVal);
  
extern void TestSetDem_GetEventFreezeFrameData(Std_ReturnType LddReturnVal);

extern void SetDem_DefaultBehaviorEnableDTCSet(Dem_ReturnControlDTCSettingType 
  LddRetControlDTCSettingType);
  
extern boolean TestDem_EnableDTCSetting(App_DataValidateType LddDataValidate,
  Dem_DTCGroupType LddDTCGroup, Dem_DTCKindType LddDTCKind);

extern void SetDem_DefaultBehaviorClearDTC(Dem_ReturnClearDTCType 
  LddRetClearDTC);

extern boolean TestDem_ClearDTC(App_DataValidateType LddDataValidate,
  uint32 LucDTC, Dem_DTCKindType LddDTCKind, Dem_DTCOriginType LddDTCOrigin);
  
extern void SetDem_DcmReadDataOfPID01(uint8 *LpData, uint8 LucLength);

extern boolean TestDem_DcmReadDataOfPID01(App_DataValidateType LddDataValidate,
  uint8 *LpExpPID01value);
  
extern void SimulateDtc_StatusMask(uint8 LucDtcStatusMask);

extern void SimulateDem_GetDTCStatusAvailabilityMask
  (Std_ReturnType LddReturnType);
  
extern boolean TestDem_GetDTCStatusAvailabilityMask(App_DataValidateType
  LddDataValidate, uint8 *LpExpDTCStatusMask);
  
extern void SimulateDem_GetTranslationType
  (Dem_DTCTranslationFormatType LddReturnType);
  
extern boolean TestDem_GetTranslationType(App_DataValidateType LddDataValidate);

extern void SimulateDem_SetDTCFilter(Dem_ReturnSetFilterType LddReturnType);

extern boolean TestDem_SetDTCFilter(App_DataValidateType LddDataValidate,
  uint8 ExpDTCStatusMask, Dem_DTCKindType ExpDTCKind, Dem_DTCOriginType
    ExpDTCOrigin, Dem_FilterWithSeverityType ExpFilterWithSeverity,
      Dem_DTCSeverityType ExpDTCSeverityMask, Dem_FilterForFDCType
        ExpFilterForFaultDetectionCounter);
        
extern void SimulateNumberOfFilteredDTCData(uint16 LusFilteredDtc);

extern void SimulateDem_GetNumberOfFilteredDTCReturn
  (Dem_ReturnGetNumberOfFilteredDTCType LddReturnType, uint16 LusFilteredDtc);
  
extern void SimulateDem_GetNumberOfFilteredDTC
  (Dem_ReturnGetNumberOfFilteredDTCType LddReturnType);
  
extern boolean TestDem_GetNumberOfFilteredDTC(App_DataValidateType
  LddDataValidate, uint16* ExpNumberOfFilteredDTC);
  
extern void SimulateDem_GetNextFilteredDTCData
  (uint32 LulDTC, uint8 LucDTCStatus,  uint8 LucCount);
  
extern void SimulateDem_GetNextFilteredDTC
  (Dem_ReturnGetNextFilteredDTCType LddReturn);
  
extern boolean TestDem_GetNextFilteredDTC(App_DataValidateType LddDataValidate);
  
extern void SimulateDem_GetNextFilteredDTCAndSeverity(uint32 LulDTC,
  uint8 LucDTCStatus, Dem_DTCSeverityType LddDTCSeverity,
    uint8 LucDTCFunctionalUnit, uint8 LucCount);
    
extern boolean TestDem_GetNextFilteredDTCAndSeverity(
  App_DataValidateType LddDataValidate);
      
extern void SimulateDem_GetStatusOfDTCData(uint8 LucStatus);

extern void SimulateDem_GetStatusOfDTC
  (Dem_ReturnGetStatusOfDTCType LddReturnType);
  
extern boolean TestDem_GetStatusOfDTC(App_DataValidateType LddDataValidate, 
  uint32 LulExpDTC, Dem_DTCKindType LddExpDTCKind, Dem_DTCOriginType
    LddExpDTCOrigin, uint8 *LpExpDTCStatus);
    
extern void SimulateDem_GetSeverityOfDTCData
  (Dem_DTCSeverityType LddSeverityType);
  
extern void SimulateDem_GetSeverityOfDTC
  (Dem_ReturnGetSeverityOfDTCType LddReturnType);
  
extern boolean TestDem_GetSeverityOfDTC(App_DataValidateType LddDataValidate,
  uint32 LulExpDTC);
  
extern void SimulateDem_GetFunctionalUnitOfDTC(uint8 LucDTCFunctionalUnit);

extern boolean TestDem_GetFunctionalUnitOfDTC(App_DataValidateType LddDataValidate,
  uint32 LulExpDTC);
  
extern void SimulateDem_GetDTCByOccurrenceTimeData(uint32 LulDTC);

extern void SimulateDem_GetDTCByOccurrenceTime
  (Dem_ReturnGetDTCByOccurrenceTimeType LddReturnType);
  
extern boolean TestDem_GetDTCByOccurrenceTime(App_DataValidateType
  LddDataValidate, Dem_DTCRequestType LddExpDTCRequest, Dem_DTCKindType
    LddExpDTCKind, uint32 *LulExpDTC);
    
extern void SimulateDem_GetSizeOfFreezeFrameByDTC
  (Dem_ReturnGetSizeOfFreezeFrameByDTCType LddReturnType);
  
extern boolean TestDem_GetSizeOfFreezeFrameByDTC(App_DataValidateType LddDataValidate, 
  uint32 LulExpDTC, Dem_DTCKindType LddExpDTCKind, Dem_DTCOriginType 
    LddExpDTCOrigin, uint8 LucExpRecordNumber,uint16 *LpSizeOfFreezeFrame);
    
extern void SimulateDem_GetSizeOfFreezeFrameByDTCTest(uint16 LusSizeOfFreezeFrame);

extern void SimulateDem_DisableDTCRecordUpdate(Std_ReturnType LddReturnType);

extern boolean TestDem_DisableDTCRecordUpdate(App_DataValidateType LddDataValidate, 
  uint32 LulExpDTC, Dem_DTCOriginType LddExpDTCOrigin);
  
extern void SimulateDem_GetFreezeFrameDataByDTC (Dem_ReturnGetFreezeFrameDataByDTCType 
  LddFreezeFrameDataByDTCType);
  
extern boolean TestDem_GetFreezeFrameDataByDTC(App_DataValidateType LddDataValidate,
  uint32 LulExpDTC, Dem_DTCKindType LddDTCKind, Dem_DTCOriginType LddExpDTCOrigin,
    uint8 LucRecordNumber, uint16* LusBufSize);
    
extern boolean TestDem_EnaableDTCRecordUpdate(App_DataValidateType LddDataValidate);

extern void SimulateDem_GetFreezeFrameDataByDTCTest(uint16 LusBuffersize, 
  uint8 *LucDestBuffer, uint8 LucLength);
  
extern void SimulateDem_GetFreezeFrameDataByRecord
  (Dem_ReturnGetFreezeFrameDataByRecordType LddReturnType);
  
extern boolean TestDem_GetFreezeFrameDataByRecord(App_DataValidateType 
  LddDataValidate, uint8 LcRecordNumber, Dem_DTCOriginType LddDTCOrigin,
    Dem_DTCKindType LddDTCKind, uint32* LulDTC, uint8* LucDestBuffer, 
    uint16* LusBufSize);
    
extern void SimulateDem_GetFreezeFrameDataByRecordTest(uint32 LulDTC, 
  uint16 LusBufsize,uint8 *LucDestbuf);
  
extern void SimulateDem_GetSizeOfExtendedDataRecordByDTC(
  Dem_ReturnGetSizeOfExtendedDataRecordByDTCType LucReturnType);
  
extern boolean TestDem_GetSizeOfExtendedDataRecordByDTC(App_DataValidateType 
  LddDataValidate,uint32 Lul_DTC, Dem_DTCKindType Ldd_DTCKind, Dem_DTCOriginType
    Ldd_DTCOrigin,uint8 Luc_ExtendedDataNumber, uint16* Lus_SizeOfExtendedDataRecord);
    
extern void SimulateDem_GetSizeOfExtendedDataRecordByDTCUpdate 
  (uint16 Lus_SizeOfExtendedDataRecord );
    
extern void SimulateDem_GetExtendedDataRecordByDTC(
  Dem_ReturnGetExtendedDataRecordByDTCType LucReturntype);
  
extern boolean TestDem_GetExtendedDataRecordByDTC(App_DataValidateType LddDataValidate, uint32 Lul_DTC, 
  Dem_DTCKindType Ldd_DTCKind, Dem_DTCOriginType Ldd_DTCOrigin, 
    uint8 Luc_ExtendedDataNumber, uint8* Lp_DestBuffer, uint16 *Lus_BufSize);
    
extern boolean TestDem_EnableDTCRecordUpdate(App_DataValidateType LddDataValidate);

extern void SimulateDem_GetExtendedDataRecordByDTCUpdate( uint8 *Laa_Destbuffer, 
  uint16 Lus_BuffSize);
    
extern void SimulateDem_SetFreezeFrameRecordFilter 
  ( Dem_ReturnSetFilterType Lus_ReturnType);
  
extern boolean TestDem_SetFreezeFrameRecordFilter(App_DataValidateType LddDataValidate,
  uint16* Lus_NumberOfFilteredRecords);
  
extern void SimulateDem_SetFreezeFrameRecordFilterUpdate
  ( uint16 Lus_NumberOfFilteredRecords );
  
extern void SimulateDem_GetNextFilteredRecord ( uint32 Lul_DTC, 
  uint8 Luc_RecordNum, uint8 LucCount);

extern boolean TestDem_GetNextFilteredRecord(App_DataValidateType LddDataValidate, 
  uint32* Lul_DTC, uint8* Luc_RecordNumber);
extern boolean TestDem_GetNextFilteredDTCAndFDC(
  App_DataValidateType LddDataValidate, uint32 *LulExpDTC,
    sint8 *DTCFaultDetectionCounter);
  
extern void SimulateDem_GetNextFilteredDTCAndFDC( uint32 Lul_DTC, 
  sint8 Luc_DTCFaultDetectionCounter);
  
extern void SetDem_GetFreezeFrameDataByDTCBehaviour (uint8 Behaviour);
extern void SimulateDem_GetExtendedDataRecordByDTCBehavior(uint8 LucBehavior);
extern void SimulateDem_SetNextFilterRecordReturn
  (Dem_ReturnGetNextFilteredDTCType Lus_ReturnType);
  
extern boolean TestDem_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
  
extern boolean TestDem_Shutdown(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);

extern boolean TestDem_GetEventStatus(App_DataValidateType LddDataValidate,
  Dem_EventIdType LddExpEventId, Dem_EventStatusExtendedType*
  LpExpEventStatusExtended);


extern void TestSetDem_GetEventStatus(Std_ReturnType LddReturnVal, uint8 LucIndex,
  Dem_EventIdType EventId, Dem_EventStatusExtendedType* EventStatusExtended);  
  

extern void Dem_PreInit(const Dem_ConfigType* ConfigPtr);

extern boolean TestDem_PreInit(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, uint8 LucData);

extern void Dem_Init(void);

extern void Dem_Shutdown(void);

extern void Dem_ReportErrorStatus(Dem_EventIdType EventId,
  Dem_EventStatusType EventStatus);
extern void Dem_SetEventStatus(Dem_EventIdType EventId,
  Dem_EventStatusType EventStatus);
  
extern Std_ReturnType Dem_GetEventStatus(Dem_EventIdType EventId, 
  Dem_EventStatusExtendedType* EventStatusExtended);

extern Std_ReturnType Dem_GetEventFailed(Dem_EventIdType EventId, 
  boolean* EventFailed);

extern Std_ReturnType Dem_GetEventTested(Dem_EventIdType EventId, 
  boolean* EventTested);

extern Std_ReturnType Dem_GetDTCOfEvent(Dem_EventIdType EventId, 
  Dem_DTCFormatType DTCFormat, uint32* DTCOfEvent);
  
extern Std_ReturnType Dem_SetEnableCondition(uint8 EnableConditionID,
  boolean ConditionFulfilled);

extern Std_ReturnType Dem_SetStorageCondition(uint8 StorageConditionID, 
  boolean ConditionFulfilled);
  
extern Std_ReturnType Dem_GetIndicatorStatus(uint8 IndicatorId, 
  Dem_IndicatorStatusType* IndicatorStatus);

extern Std_ReturnType Dem_GetEventFreezeFrameData(Dem_EventIdType EventId, 
  uint8 RecordNumber, boolean ReportTotalRecord, 
  uint16 DataId, uint8* DestBuffer);  
  
extern Std_ReturnType Dem_GetEventExtendedDataRecord(Dem_EventIdType EventId, 
  uint8 RecordNumber, uint8* DestBuffer);
  
extern Std_ReturnType Dem_GetEventMemoryOverflow(Dem_DTCOriginType DTCOrigin,
  boolean* OverflowIndication);
  
extern Std_ReturnType Dem_SetDTCSuppression(uint32 DTC, Dem_DTCFormatType 
  DTCFormat,boolean SuppressionStatus);
  
extern Dem_ReturnSetFilterType Dem_SetDTCFilter(uint8 DTCStatusMask, 
  Dem_DTCKindType DTCKind, Dem_DTCFormatType DTCFormat, Dem_DTCOriginType 
  DTCOrigin, 
  Dem_FilterWithSeverityType FilterWithSeverity, 
  Dem_DTCSeverityType DTCSeverityMask,
  Dem_FilterForFDCType FilterForFaultDetectionCounter);
  
extern Dem_ReturnSetFilterType Dem_SetFreezeFrameRecordFilter
  (Dem_DTCFormatType DTCFormat, uint16* NumberOfFilteredRecords);
  
extern Dem_ReturnGetStatusOfDTCType Dem_GetStatusOfDTC(
  uint32 DTC, Dem_DTCOriginType DTCOrigin, uint8* DTCStatus);

extern Std_ReturnType Dem_GetDTCStatusAvailabilityMask(uint8* DTCStatusMask);

extern Dem_ReturnGetNumberOfFilteredDTCType Dem_GetNumberOfFilteredDTC(
  uint16* NumberOfFilteredDTC);

extern Dem_ReturnGetNextFilteredDTCType Dem_GetNextFilteredDTC(
  uint32* DTC, uint8* DTCStatus);

extern Dem_ReturnGetDTCByOccurrenceTimeType Dem_GetDTCByOccurrenceTime(
  Dem_DTCRequestType DTCRequest, uint32* DTC);

extern Dem_ReturnGetNextFilteredDTCType Dem_GetNextFilteredRecord(uint32* DTC, 
  uint8* RecordNumber);

extern Dem_ReturnGetNextFilteredDTCType Dem_GetNextFilteredDTCAndFDC(
  uint32* DTC, sint8* DTCFaultDetectionCounter);

extern Dem_ReturnGetNextFilteredDTCType Dem_GetNextFilteredDTCAndSeverity(
  uint32* DTC, uint8* DTCStatus, Dem_DTCSeverityType* DTCSeverity, 
  uint8* DTCFunctionalUnit);
  
extern Dem_DTCTranslationFormatType Dem_GetTranslationType(void);

extern Dem_ReturnGetSeverityOfDTCType Dem_GetSeverityOfDTC(uint32 DTC,
  Dem_DTCSeverityType* DTCSeverity);

extern Dem_ReturnGetFunctionalUnitOfDTCType Dem_GetFunctionalUnitOfDTC(
  uint32 DTC, uint8* DTCFunctionalUnit);

extern Dem_ReturnDisableDTCRecordUpdateType Dem_DisableDTCRecordUpdate(
  uint32 DTC, Dem_DTCOriginType DTCOrigin);
  
extern Std_ReturnType Dem_EnableDTCRecordUpdate(void);

extern Dem_ReturnGetFreezeFrameDataByRecordType Dem_GetFreezeFrameDataByRecord(
  uint8 RecordNumber,Dem_DTCOriginType DTCOrigin, uint32* DTC, 
  uint8* DestBuffer, uint16* BufSize);
  
extern Dem_ReturnGetFreezeFrameDataByDTCType Dem_GetFreezeFrameDataByDTC(
  uint32 DTC, Dem_DTCOriginType DTCOrigin, uint8 RecordNumber, 
  uint8* DestBuffer, uint16* BufSize);
  
extern Dem_ReturnGetSizeOfFreezeFrameByDTCType Dem_GetSizeOfFreezeFrameByDTC(
  uint32 DTC, Dem_DTCOriginType DTCOrigin, uint8 RecordNumber, 
  uint16* SizeOfFreezeFrame);
  
extern Dem_ReturnGetExtendedDataRecordByDTCType Dem_GetExtendedDataRecordByDTC(
  uint32 DTC, Dem_DTCOriginType DTCOrigin, uint8 ExtendedDataNumber, 
  uint8* DestBuffer, uint16* BufSize);

extern Dem_ReturnGetSizeOfExtendedDataRecordByDTCType
  Dem_GetSizeOfExtendedDataRecordByDTC(uint32 DTC, Dem_DTCOriginType
  DTCOrigin, uint8 ExtendedDataNumber, uint16* SizeOfExtendedDataRecord);
 
extern Dem_ReturnControlDTCSettingType Dem_DisableDTCSetting(Dem_DTCGroupType 
  DTCGroup, Dem_DTCKindType DTCKind);

extern Dem_ReturnControlDTCSettingType Dem_EnableDTCSetting(Dem_DTCGroupType 
 DTCGroup, Dem_DTCKindType DTCKind);
 
extern void Dem_DcmCancelOperation(void);

extern boolean Dlt_Test_DemValidateData(uint8* LpExpDestBuffer, uint8* 
  LpActDestBuffer, uint8 LucBufSize);
  
extern Std_ReturnType Dem_DltGetMostRecentFreezeFrameRecordData(
  Dem_EventIdType EventId, uint8* DestBuffer, uint8* BufSize);
  
extern Std_ReturnType Dem_DltGetAllExtendedDataRecords(Dem_EventIdType EventId, 
  uint8* DestBuffer, uint8* BufSize);
  
extern Std_ReturnType Dem_SetEventDisabled(Dem_EventIdType EventId);

extern Std_ReturnType Dem_RepIUMPRFaultDetect(Dem_RatioIdType RatioID);

extern Std_ReturnType Dem_RepIUMPRDenLock(Dem_RatioIdType RatioID);

extern Std_ReturnType Dem_RepIUMPRDenRelease(Dem_RatioIdType RatioID);
  
extern Std_ReturnType Dem_DcmReadDataOfPID01(uint8* PID01value);

extern Std_ReturnType Dem_DcmReadDataOfPID1C(uint8* PID1Cvalue);

extern Std_ReturnType Dem_DcmReadDataOfPID21(uint8* PID21value);

extern Std_ReturnType Dem_DcmReadDataOfPID30(uint8* PID30value);

extern Std_ReturnType Dem_DcmReadDataOfPID31(uint8* PID31value);

extern Std_ReturnType Dem_DcmReadDataOfPID41(uint8* PID41value);

extern Std_ReturnType Dem_DcmReadDataOfPID4D(uint8* PID4Dvalue);

extern Std_ReturnType Dem_DcmReadDataOfPID4E(uint8* PID4Evalue);

extern Std_ReturnType Dem_ReadDataOfOBDFreezeFrame(uint8 PID, 
  uint8 DataElementIndexOfPID, uint8* DestBuffer, uint8* BufSize);

extern Std_ReturnType Dem_GetDTCOfOBDFreezeFrame(uint8 FrameNumber, 
  uint32* DTC);

extern Std_ReturnType Dem_SetPtoStatus(boolean PtoStatus);
#endif /* DEM_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

