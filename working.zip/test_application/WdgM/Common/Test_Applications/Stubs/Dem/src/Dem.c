/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Dem.c                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Dem Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Dem Stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dem.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Dem_GucReportCount;
uint8 Dem_GucReportCheckCount;
Dem_EventIdType Dem_GaaEventId[DEM_ARRAY_SIZE];
Dem_EventStatusType Dem_GaaEventStatus[DEM_ARRAY_SIZE];
#ifdef DLT_MODULE_ACTIVE
Dem_EventIdType Dlt_GddEventId;
Dem_DTCFormatType Dlt_GddDTCKind;
Std_ReturnType Dlt_GddDTCReturnVal;
Std_ReturnType Dlt_GddEventExtReturnVal;
Std_ReturnType Dlt_GddEventFrReturnVal;
uint32 Dlt_GucDTCOfEvent;
Dem_EventIdType Dlt_GddEventExtendedEventId;
Dem_EventIdType Dlt_GddFreezeFrameEventId;
uint16 Dlt_GucFreezeFrameDataId;
uint8 Dlt_GucEventExtendedRecordNumber;
uint8 Dlt_GucEventExtendedBufSize;
uint8 Dlt_GaaExtendedDataDestBuffer[3] = {0x00, 0x01, 0x02};
uint8 Dlt_GaaFreezeFrameDestBuffer[3] = {0x00, 0x01, 0x02};
uint8 Dlt_GucFreezeFrameRecordNumber;
uint8 Dlt_GucFreezeFrameBufSize;
boolean Dlt_GblFreezeFrameReportTotalRecord;
#endif
#ifdef BSWM_MODULE_ACTIVE
uint8 Dem_GucInitCnt;
uint8 Dem_GucInitSeqCnt;
#endif

#ifdef DCM_MODULE_ACTIVE
uint32 Dcm_GulDTC;
uint32 Dcm_GulDTC2;
uint32 Dcm_GulDTC3;
uint32 Dcm_GaaDTC3[50];
uint32 Dcm_GaaDTC4[255];
uint32 Dcm_GaaDTC5[255];
Dem_ReturnControlDTCSettingType Dcm_GddEnableDTCRetVal;
Dem_ReturnControlDTCSettingType Dcm_GddDisableDTCRetVal;
Dem_DTCGroupType Dcm_GddDTCGroup;
Dem_ReturnClearDTCType Dcm_GddClearDTCRetVal;
Dem_DTCKindType Dcm_GddGeneralDTCKind = DEM_DTC_KIND_ALL_DTCS;
Dem_DTCKindType Dcm_GddGeneralDTCKind2 = DEM_DTC_KIND_ALL_DTCS;
Dem_DTCKindType Dcm_GddGeneralDTCKind3;
Dem_DTCKindType Dcm_GddGeneralDTCKind4[255];
Dem_DTCKindType Dcm_GaaGeneralDTCKind4[255];
Dem_DTCOriginType Dcm_GddDTCOrigin;
Dem_DTCOriginType Dcm_GddDTCOrigin2;
Dem_DTCOriginType Dcm_GddDTCOrigin3;
Dem_DTCOriginType Dcm_GaaDTCOrigin3[255];
Dem_DTCOriginType Dcm_GddDTCOrigin4[255];
Std_ReturnType Dcm_GddDemGeneralReturn;
Dem_ReturnSetFilterType Dcm_GddSetFilterReturn;
Dem_ReturnSetFilterType Dcm_GddSetFilterReturn1;
Dem_ReturnGetNextFilteredDTCType Dcm_GddSetFilterReturn2;
Dem_ReturnGetNumberOfFilteredDTCType Dcm_GddNumOfFilteredReturn;
Dem_ReturnGetNextFilteredDTCType Dcm_GddNextFilteredReturn;
Dem_DTCTranslationFormatType Dcm_GddTranslationReturn;
Dem_FilterWithSeverityType Dcm_GddFilterWithSeverityType;
Dem_DTCSeverityType Dcm_GddDTCSeverityType;
Dem_DTCSeverityType Dcm_GaaTCSeverityType[DEM_ARRAY_SIZE];
Dem_FilterForFDCType Dcm_GddFilterForFDCType;
Dem_ReturnGetStatusOfDTCType Dcm_GddGetStatusOfDtcType;
Dem_ReturnGetSeverityOfDTCType Dcm_GddGetSeverityOfDTCTypeReturn;
Dem_ReturnGetFunctionalUnitOfDTCType Dcm_GddFunctionalUnitReturn;
Dem_ReturnGetDTCByOccurrenceTimeType Dcm_GddGetDtcOccurenceReturn;
Dem_ReturnGetSizeOfFreezeFrameByDTCType Dcm_GddGetSizeOfFreezeFrameByDTCType;
Dem_DTCRequestType Dcm_GddDtcReqType;
Dem_ReturnGetFreezeFrameDataByDTCType Dcm_GddFreezeFrameDataByDTCType;
Dem_ReturnGetFreezeFrameDataByRecordType Dcm_FreezeFrameDataByRecordType;
Dem_ReturnGetSizeOfExtendedDataRecordByDTCType Dcm_SizeOfExtendedDataRecordByDTCType;
Dem_ReturnGetExtendedDataRecordByDTCType Dcm_GucExtendedDataRecordByDTCType;
uint32 Dcm_GaaNextFilteredDTC[DEM_ARRAY_SIZE];
uint8 Dcm_GaaNextFilteredDtcStatus[DEM_ARRAY_SIZE];
uint8 Dcm_GucNormalBehaviour;
uint16 Dcm_GusNumberOfFilteredDTC;
uint16 Dcm_GusSizeOfFreezeFrame;
uint16 Dcm_GusRequestBuff;
uint16 Dcm_GaaRequestBuff1[255];
uint16 Dcm_GusBuffsize;
uint16 Dcm_GusBuffsize1;
uint16 Dcm_GusBuffsize2;
uint16 Dcm_GusBuffsize3[255];
uint16 Dcm_GusnumberOfFilteredRecords ;
uint16 Dcm_GusSizeOfExtendedDataRecord;
uint8 Dcm_GucNumOfFilteredDtcCount;
uint8 Dcm_GucTranslationCount;
uint8 Dcm_GucDemGeneralCount;
uint8 Dcm_GucSetDtcFilterCount;
uint8 Dcm_GucGetNextFilteredCount;
uint8 Dcm_GucGetNextFilteredCheckCount;
uint8 Dcm_GucDemFreezeFrameCount;
uint8 Dcm_GucDemFreezeFrameCheckCount;
uint8 Dcm_GucDtcStatusMask;
uint8 Dcm_GaaDemGeneralData[10] = {0,0,0,0,0,0,0,0,0,0};
uint8 Dcm_GucDtcStatus;
uint8 Dcm_GaaDtcStatus[DEM_ARRAY_SIZE];
uint8 Dcm_GaaDTCFunctionalUnit[DEM_ARRAY_SIZE];
uint8 Dcm_GucDtcStatusCount;
uint8 Dcm_GucRecordNum;
uint8 Dcm_GucRecordNum2;
uint8 Dcm_GaaRecordNum3[255];
uint8 Dcm_GaaRecordNum4[255];
uint8 Dcm_GucRecordNum3;
uint8 Dcm_GucDestBuffer;
uint8 Dcm_GucDestBuffer1;
uint8 Dcm_GucExtendedDataNumber;
uint8 Dcm_GucExtendedDataNumber1[255];
sint8 Dcm_GucDTCFaultDetectionCounter;
uint8 Dcm_GucExtendedDataRecordByDTCBehavior;
uint8 Dcm_GucDemGeneralCountEnableSet;
uint8 Dcm_GucDemGeneralCountDisableSet;
uint8 Dcm_GucDemGeneralClearCount;
uint8 Dcm_GucDemGeneralCountMask;
uint8 Dcm_GucDemGeneralCountFFSize;
uint8 Dcm_GucDemGeneralCountEnable;
uint8 Dcm_GucDemGeneralCountDisable;
uint8 Dcm_GucDemGeneralCountFFRecord;
uint8 Dcm_GucDemGeneralCountExtRecords;
uint8 Dcm_GucDemGeneralCountExtSize;
uint8 Dcm_GucGetExtRecordCheckCount;
uint8 Dcm_GaaGetFreezeFrameData[10] = {0x03, 0x02, 0xF0, 0x41, 0x01, 0x02, 0xF0,
  0x42, 0x03, 0x04};
uint8 Dcm_GaaGetFreezeFrameData1[] = {0x00, 0x01, 0xF1, 0x01, 0x01};
uint8 Dcm_GaaGetFreezeFrameData2[] = {0x01, 0x01, 0xF1, 0x02, 0x02};
uint8 Dcm_GaaGetFreezeFrameData3[] = {0x02, 0x01, 0xF1, 0x03, 0x03};
uint8 Dcm_GucGetNextFilteredRecordCheckCount;
uint8 Dcm_GucDemGeneralFilterCount;
#endif

#ifdef ECUM_MODULE_ACTIVE
uint8 Dem_GucConfigData;
uint8 Dem_GucPreInitSeqCnt;
uint8 Dem_GucPreInitCount;
uint8 Dem_GucInitSeqCnt;
#endif

#ifdef FIM_MODULE_ACTIVE
Std_ReturnType FiM_GddEventStatusReturnVal;
Dem_EventIdType FiM_GddEventId[DEM_ARRAY_SIZE];
Dem_EventStatusExtendedType FiM_GddEventStatusExtended[DEM_ARRAY_SIZE]; 
uint8 FiM_GucReportCount;
uint8 FiM_GucReportCheckCount;
#endif
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
#ifdef ECUM_MODULE_ACTIVE

/*******************************************************************************
**                           Dem_PreInit()                                    **
*******************************************************************************/
void Dem_PreInit(const Dem_ConfigType* ConfigPtr)
{
  #ifndef TYPICAL_CONFIG
  if (ConfigPtr != NULL_PTR)
  {
    Dem_GucConfigData = (ConfigPtr->dummy);
  }
  App_GucApiSeqCnt++;
  Dem_GucPreInitSeqCnt = App_GucApiSeqCnt;
  Dem_GucPreInitCount++;
  #endif
}

/*******************************************************************************
**                        TestDem_PreInit()                                   **
*******************************************************************************/
boolean TestDem_PreInit(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, uint8 LucData)
{
  boolean LblStepResult;  
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Dem_GucConfigData == LucData) && 
        (Dem_GucPreInitCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Dem_GucPreInitCount = 0;
      Dem_GucPreInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
   
    case S_VALIDATE_SEQ:
    {
      if((Dem_GucConfigData == LucData) && 
        (Dem_GucPreInitSeqCnt == LucSeqNo))
      {
        LblStepResult = STEP_PASSED;
      }
      Dem_GucPreInitCount = 0;
      Dem_GucPreInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */    
    
  return(LblStepResult);
} /* End TestDem_PreInit() */

#endif

#ifdef BSWM_MODULE_ACTIVE
/*******************************************************************************
**                          Dem_Init()                                      **
*******************************************************************************/

void Dem_Init(void)
{
	App_GucApiSeqCnt++;
	Dem_GucInitSeqCnt = App_GucApiSeqCnt;
	Dem_GucInitCnt++;
}/* End Dem_Init() */

/*******************************************************************************
**                           TestDem_Init()                                 **
*******************************************************************************/
boolean TestDem_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Dem_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Dem_GucInitCnt = 0;
      Dem_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(Dem_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Dem_GucInitCnt = 0;
      Dem_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestDem_Init() */

/*******************************************************************************
**                          Dem_shutdown()                                    **
*******************************************************************************/

void Dem_Shutdown(void)
{
	App_GucApiSeqCnt++;
	Dem_GucInitSeqCnt = App_GucApiSeqCnt;
	Dem_GucInitCnt++;
}/* End Dem_shutdown() */

/*******************************************************************************
**                           TestDem_shutdown()                               **
*******************************************************************************/
boolean TestDem_Shutdown(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Dem_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Dem_GucInitCnt = 0;
      Dem_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(Dem_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Dem_GucInitCnt = 0;
      Dem_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestDem_shutdown() */

#endif

#ifdef DLT_MODULE_ACTIVE
/*******************************************************************************
**                      Dem_GetDTCOfEvent()                                   **
*******************************************************************************/
Std_ReturnType Dem_GetDTCOfEvent(Dem_EventIdType EventId, Dem_DTCFormatType 
  DTCKind, uint32* DTCOfEvent)
{ 
  #ifndef TYPICAL_CONFIG
  Dlt_GddEventId = EventId;
  Dlt_GddDTCKind = DTCKind;
  *DTCOfEvent = (uint32)0xFFFFFFFF;
  Dlt_GucDTCOfEvent = *DTCOfEvent;
  #endif
  return(Dlt_GddDTCReturnVal);
} /* End Dem_GetDTCOfEvent() */

/*******************************************************************************
**                       TestDem_GetDTCOfEvent()                              **
*******************************************************************************/
boolean TestDem_GetDTCOfEvent(App_DataValidateType LucDataValidate,
  Dem_EventIdType LddExpEventId, Dem_DTCFormatType LddExpDTCKind,
  uint32* ExpDTCOfEvent)
{
  uint32 LucexpDTCOfEvent;
  uint32* LpDTCOfEvent;
  boolean LblStepResult;
  LpDTCOfEvent = (uint32 *)ExpDTCOfEvent;
  LucexpDTCOfEvent = *LpDTCOfEvent;


  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GddEventId == LddExpEventId) &&
        (Dlt_GddDTCKind == LddExpDTCKind) &&
        (Dlt_GucDTCOfEvent == LucexpDTCOfEvent))
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestDem_GetDTCOfEvent() */
/*******************************************************************************
**                      Dem_GetEventExtendedDataRecord()                      **
*******************************************************************************/
Std_ReturnType Dem_DltGetAllExtendedDataRecords( Dem_EventIdType EventId,
  uint8* DestBuffer, uint8* BufSize )
{
  #ifndef TYPICAL_CONFIG
  uint8* LpDestBufferptr;
  uint8 LucDataIndex;
  Dlt_GddEventExtendedEventId = EventId;
  LpDestBufferptr = (uint8 *)DestBuffer;
  *BufSize = 0x03;
  Dlt_GucEventExtendedBufSize = *BufSize;
  /* Copy the actual data into global array from DestBuffer */
  for(LucDataIndex = 0; LucDataIndex < Dlt_GucEventExtendedBufSize; LucDataIndex++)
  {
    *LpDestBufferptr = Dlt_GaaExtendedDataDestBuffer[LucDataIndex];
     LpDestBufferptr++;
  }
  #endif
  return(Dlt_GddEventExtReturnVal);
} /* End Dem_GetEventExtendedDataRecord() */
/*******************************************************************************
**                       TestDem_GetEventExtendedDataRecord()                 **
*******************************************************************************/
boolean TestDem_DltGetAllExtendedDataRecords(App_DataValidateType LucDataValidate,
  Dem_EventIdType LddExpEventId, uint8* ExpDestBuffer, uint8* ExpBufSize)
{
  boolean LblStepResult;
  uint8 LucExpBufSize;
  uint8 *LpExpDestBuffer;
  uint8 *LpExpBufSize;

  LpExpBufSize = (uint8 *)ExpBufSize;
  LucExpBufSize = *LpExpBufSize;
  LpExpDestBuffer = (uint8 *)ExpDestBuffer;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GddEventExtendedEventId == LddExpEventId) &&
        (Dlt_GucEventExtendedBufSize == LucExpBufSize))
      {
        if(Dlt_Test_DemValidateData(LpExpDestBuffer, &Dlt_GaaExtendedDataDestBuffer[0],
          Dlt_GucEventExtendedBufSize))
        {
          LblStepResult = STEP_PASSED;
        }
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestDem_GetEventExtendedDataRecord() */
/*******************************************************************************
**                      Dem_GetEventFreezeFrameData()                         **
*******************************************************************************/
Std_ReturnType Dem_DltGetMostRecentFreezeFrameRecordData
  ( Dem_EventIdType EventId, uint8* DestBuffer, uint8* BufSize )
{
  #ifndef TYPICAL_CONFIG
  uint8* LpFreezeDestBufferptr;
  uint8 LucDataIndex;
  Dlt_GddFreezeFrameEventId = EventId;
  LpFreezeDestBufferptr = (uint8 *)DestBuffer;
  *BufSize = 0x03;
  Dlt_GucFreezeFrameBufSize = *BufSize;
  for(LucDataIndex = 0; LucDataIndex < Dlt_GucFreezeFrameBufSize; LucDataIndex++)
  {
    *LpFreezeDestBufferptr = Dlt_GaaFreezeFrameDestBuffer[LucDataIndex];
     LpFreezeDestBufferptr++;
  }
  #endif
  return(Dlt_GddEventFrReturnVal);
} /* End Dem_GetEventFreezeFrameData() */
/*******************************************************************************
**                       TestDem_GetEventFreezeFrameData()                   **
*******************************************************************************/
boolean TestDem_DltGetMostRecentFreezeFrameRecordData(App_DataValidateType 
  LucDataValidate, Dem_EventIdType LddExpEventId,  uint8* DestBuffer, 
  uint8* BufSize)
{
  boolean LblStepResult;
  uint8* LpExpBufSize;
  uint8* LpExpDestBuffer;
  uint8 LucExpBufSize;
  LpExpBufSize = (uint8 *)BufSize;
  LucExpBufSize = *LpExpBufSize;
  LpExpDestBuffer = (uint8 *)DestBuffer;
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GddFreezeFrameEventId == LddExpEventId) &&
        (Dlt_GucFreezeFrameBufSize == LucExpBufSize))
      {
        if(Dlt_Test_DemValidateData(LpExpDestBuffer, &Dlt_GaaFreezeFrameDestBuffer[0],
          Dlt_GucFreezeFrameBufSize))
        {
          LblStepResult = STEP_PASSED;
        }
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestDem_GetEventFreezeFrameData() */

/*******************************************************************************
**                       Dlt_Test_DemValidateData()                           **
*******************************************************************************/
boolean Dlt_Test_DemValidateData(uint8* LpExpDestBuffer, uint8* LpActDestBuffer,
  uint8 LucBufSize)
{
  uint8 LucCount;
  boolean LblReturnValue;

  LblReturnValue = TRUE;
  LucCount = 0;

  while((LblReturnValue != FALSE) && (LucCount < LucBufSize))
  {
    if(*LpActDestBuffer != *LpExpDestBuffer)
    {
      LblReturnValue = FALSE;
    }
    LpActDestBuffer++;
    LpExpDestBuffer++;
    LucCount++;
  }
  return(LblReturnValue);
}
/* End Dlt_Test_DemValidateData()  */
/*******************************************************************************
**                        TestSetDem_GetDTCOfEvent()                          **
*******************************************************************************/
void TestSetDem_GetDTCOfEvent(Std_ReturnType LddReturnVal)
{
  Dlt_GddDTCReturnVal = LddReturnVal;
}
/*******************************************************************************
**                        TestSetDem_GetEventExtendedDataRecord()             **
*******************************************************************************/
void TestSetDem_DltGetAllExtendedDataRecords(Std_ReturnType LddReturnVal)
{
  Dlt_GddEventExtReturnVal = LddReturnVal;
}
/*******************************************************************************
**                        TestSetDem_GetEventFreezeFrameData()                **
*******************************************************************************/
void TestSetDem_DltGetMostRecentFreezeFrameRecordData(Std_ReturnType LddReturnVal)
{
  Dlt_GddEventFrReturnVal = LddReturnVal;
}
#endif
/*******************************************************************************
**                      Dem_ReportErrorStatus()                               **
*******************************************************************************/
void Dem_ReportErrorStatus(Dem_EventIdType EventId,
  Dem_EventStatusType EventStatus)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual EventId and EventStatus into Global variables */
  Dem_GaaEventId[Dem_GucReportCount] = EventId;
  Dem_GaaEventStatus[Dem_GucReportCount] = EventStatus;

  /* Increment count variable to handle multiple invocations */
  if(Dem_GucReportCount < DEM_ARRAY_SIZE)
  {
    Dem_GucReportCount++;
  }
  #endif /* TYPICAL_CONFIG */
} /* End Dem_ReportErrorStatus() */

/*******************************************************************************
**                      Dem_SetEventStatus()                                  **
*******************************************************************************/
void Dem_SetEventStatus(Dem_EventIdType EventId,
  Dem_EventStatusType EventStatus)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual EventId and EventStatus into Global variables */
  Dem_GaaEventId[Dem_GucReportCount] = EventId;
  Dem_GaaEventStatus[Dem_GucReportCount] = EventStatus;

  /* Increment count variable to handle multiple invocations */
  if(Dem_GucReportCount < DEM_ARRAY_SIZE)
  {
    Dem_GucReportCount++;
  }
  #endif /* TYPICAL_CONFIG */
} /* End Dem_ReportErrorStatus() */

/*******************************************************************************
**                       TestDem_ReportErrorStatus()                          **
*******************************************************************************/
boolean TestDem_ReportErrorStatus(App_DataValidateType LucDataValidate,
  Dem_EventIdType LddExpEventId, Dem_EventStatusType LddExpEventStatus)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dem_GucReportCount == 0x01) &&
        (Dem_GaaEventId[0] == LddExpEventId) &&
        (Dem_GaaEventStatus[0] == LddExpEventStatus))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Dem_GucReportCount = 0;
      Dem_GucReportCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Dem_GucReportCount; LucIndex++)
      {
        /* Validate EventId and EventStatus */
        if((Dem_GaaEventId[LucIndex] == LddExpEventId) &&
          (Dem_GaaEventStatus[LucIndex] == LddExpEventStatus))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Dem_GucReportCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Dem_GucReportCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Dem_GucReportCheckCount == Dem_GucReportCount)
      {
        Dem_GucReportCount = 0;
        Dem_GucReportCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dem_GucReportCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    
    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblStepResult = STEP_PASSED;

      /* Loop through the global array and check for the expected ID */
      for(LucIndex = 0; (LucIndex < Dem_GucReportCount) &&
        (LblStepResult == STEP_PASSED); LucIndex++)
      {
        /* Validate EventId and EventStatus */
        if((Dem_GaaEventId[LucIndex] == LddExpEventId) &&
          (Dem_GaaEventStatus[LucIndex] == LddExpEventStatus))
        {
          LblStepResult = STEP_FAILED;
        }
      }
      break;
    } /* End case M_NOT_INVOKED: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestDem_ReportErrorStatus() */

#ifdef DCM_MODULE_ACTIVE
/*******************************************************************************
**                        Dem_EnableDTCRecordUpdate()                           **
*******************************************************************************/
Std_ReturnType Dem_EnableDTCRecordUpdate(void)
{
  Dcm_GucDemGeneralCountEnable++;
  return(Dcm_GddDemGeneralReturn);
}

/*******************************************************************************
**                        SetDem_DefaultBehaviorEnableDTCSet()                           **
*******************************************************************************/
void SetDem_DefaultBehaviorEnableDTCSet(Dem_ReturnControlDTCSettingType
  LddRetControlDTCSettingType)
  {
    Dcm_GddEnableDTCRetVal = LddRetControlDTCSettingType;
  }

/*******************************************************************************
**                        Dem_EnableDTCSetting()                           **
*******************************************************************************/
Dem_ReturnControlDTCSettingType Dem_EnableDTCSetting(Dem_DTCGroupType
  LddDTCGroup, Dem_DTCKindType LddDTCKind)
{
  Dcm_GddDTCGroup = LddDTCGroup;
  Dcm_GddGeneralDTCKind = LddDTCKind;
  Dcm_GucDemGeneralCountEnableSet++;
  return(Dcm_GddEnableDTCRetVal);
}


/*******************************************************************************
**                        TestDem_EnableDTCSetting()                           **
*******************************************************************************/
boolean TestDem_EnableDTCSetting(App_DataValidateType LddDataValidate,
  Dem_DTCGroupType LddDTCGroup, Dem_DTCKindType LddDTCKind)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucDemGeneralCountEnableSet == 0x01) && (Dcm_GddDTCGroup == LddDTCGroup) &&
        (Dcm_GddGeneralDTCKind == LddDTCKind))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucDemGeneralCountEnableSet = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucDemGeneralCountEnableSet == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

  /*******************************************************************************
**                        SetDem_DefaultBehaviorDisableDTCSet()                           **
*******************************************************************************/
void SetDem_DefaultBehaviorDisableDTCSet(Dem_ReturnControlDTCSettingType
  LddRetControlDTCSettingType)
  {
    Dcm_GddDisableDTCRetVal = LddRetControlDTCSettingType;
  }

/*******************************************************************************
**                        Dem_DisableDTCSetting()                           **
*******************************************************************************/
Dem_ReturnControlDTCSettingType Dem_DisableDTCSetting(Dem_DTCGroupType
  LddDTCGroup, Dem_DTCKindType LddDTCKind)
{
  Dcm_GddDTCGroup = LddDTCGroup;
  Dcm_GddGeneralDTCKind = LddDTCKind;
  Dcm_GucDemGeneralCountDisableSet++;
  return(Dcm_GddDisableDTCRetVal);
}


/*******************************************************************************
**                        TestDem_DisableDTCSetting()                           **
*******************************************************************************/
boolean TestDem_DisableDTCSetting(App_DataValidateType LddDataValidate,
  Dem_DTCGroupType LddDTCGroup, Dem_DTCKindType LddDTCKind)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucDemGeneralCountDisableSet == 0x01) && (Dcm_GddDTCGroup == LddDTCGroup) &&
        (Dcm_GddGeneralDTCKind == LddDTCKind))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucDemGeneralCountDisableSet = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucDemGeneralCountDisableSet == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }
/*******************************************************************************
**                        SetDem_DefaultBehaviorClearDTC()                           **
*******************************************************************************/
void SetDem_DefaultBehaviorClearDTC(Dem_ReturnClearDTCType
  LddRetControlDTCSettingType)
  {
    Dcm_GddClearDTCRetVal = LddRetControlDTCSettingType;
  }

/*******************************************************************************
**                        Dem_ClearDTC()                           **
*******************************************************************************/
Dem_ReturnClearDTCType Dem_ClearDTC(uint32 LucDTC, Dem_DTCKindType
  LddDTCKind, Dem_DTCOriginType LddDTCOrigin)
{
  Dcm_GulDTC = LucDTC;
  Dcm_GddGeneralDTCKind = LddDTCKind;
  Dcm_GddDTCOrigin = LddDTCOrigin;
  Dcm_GucDemGeneralClearCount++;
  return(Dcm_GddClearDTCRetVal);
}

/*******************************************************************************
**                        TestDem_EnableDTCSetting()                           **
*******************************************************************************/
boolean TestDem_ClearDTC(App_DataValidateType LddDataValidate, uint32 LucDTC,
  Dem_DTCKindType LddDTCKind, Dem_DTCOriginType LddDTCOrigin)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucDemGeneralClearCount == 0x01) && (Dcm_GulDTC == LucDTC) &&
        (Dcm_GddGeneralDTCKind == LddDTCKind) && (Dcm_GddDTCOrigin ==
          LddDTCOrigin))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucDemGeneralClearCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucDemGeneralClearCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**                        SetDem_DcmReadDataOfPID01()                           **
*******************************************************************************/
void SetDem_DcmReadDataOfPID01(uint8 *LpData, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
    Dcm_GaaDemGeneralData[LucIndex] = (*LpData)++;
    LucIndex++;
  }
  while(LucIndex < LucLength);
}

/*******************************************************************************
**                        Dem_DcmReadDataOfPID01()                           **
*******************************************************************************/
Std_ReturnType Dem_DcmReadDataOfPID01(uint8 *LpPID01value)
{
  LpPID01value = &Dcm_GaaDemGeneralData[0];
  Dcm_GucDemGeneralCount++;
  LpPID01value++;
  LpPID01value--; 
  return(Dcm_GddDemGeneralReturn);
}

/*******************************************************************************
**                        TestDem_DcmReadDataOfPID01()                           **
*******************************************************************************/
boolean TestDem_DcmReadDataOfPID01(App_DataValidateType LddDataValidate, uint8
  *LpExpPID01value)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpPID01value++;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if(Dcm_GucDemGeneralCount == 0x01)
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucDemGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucDemGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**                        SimulateDtc_StatusMask()                           **
*******************************************************************************/
void SimulateDtc_StatusMask(uint8 LucDtcStatusMask)
{
  Dcm_GucDtcStatusMask = LucDtcStatusMask;
}

/*******************************************************************************
**               SimulateDem_GetDTCStatusAvailabilityMask()                   **
*******************************************************************************/
void SimulateDem_GetDTCStatusAvailabilityMask(Std_ReturnType LddReturnType)
{
  Dcm_GddDemGeneralReturn = LddReturnType;
}

/*******************************************************************************
**               Dem_GetDTCStatusAvailabilityMask()                           **
*******************************************************************************/
Std_ReturnType Dem_GetDTCStatusAvailabilityMask(uint8 *LpDTCStatusMask)
{
  *LpDTCStatusMask = Dcm_GucDtcStatusMask;
  Dcm_GucDemGeneralCountMask++;
  return(Dcm_GddDemGeneralReturn);
}

/*******************************************************************************
**           TestDem_GetNumberOfFilteredDTC()                           **
*******************************************************************************/
boolean TestDem_GetDTCStatusAvailabilityMask(App_DataValidateType
  LddDataValidate, uint8 *LpExpDTCStatusMask)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpDTCStatusMask++;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucDemGeneralCountMask == 0x01))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucDemGeneralCountMask = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucDemGeneralCountMask == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**                        SimulateDem_GetTranslationType()                           **
*******************************************************************************/
void SimulateDem_GetTranslationType(Dem_DTCTranslationFormatType LddReturnType)
{
  Dcm_GddTranslationReturn = LddReturnType;
}

/*******************************************************************************
**                        Dem_GetTranslationType()                           **
*******************************************************************************/
Dem_DTCTranslationFormatType Dem_GetTranslationType(void)
{
  Dcm_GucTranslationCount++;
  return(Dcm_GddTranslationReturn);
}

/*******************************************************************************
**                        TestDem_GetTranslationType()                           **
*******************************************************************************/
boolean TestDem_GetTranslationType(App_DataValidateType LddDataValidate)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucTranslationCount == 0x01))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucTranslationCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucTranslationCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**                        SimulateDem_SetDTCFilter()                           **
*******************************************************************************/
void SimulateDem_SetDTCFilter(Dem_ReturnSetFilterType LddReturnType)
{
  Dcm_GddSetFilterReturn = LddReturnType;
}

/*******************************************************************************
**                        Dem_SetDTCFilter()                           **
*******************************************************************************/
Dem_ReturnSetFilterType Dem_SetDTCFilter(uint8 DTCStatusMask,
  Dem_DTCKindType DTCKind, Dem_DTCOriginType DTCOrigin,
    Dem_FilterWithSeverityType FilterWithSeverity, Dem_DTCSeverityType
      DTCSeverityMask, Dem_FilterForFDCType FilterForFaultDetectionCounter)
{
  Dcm_GucDtcStatusMask = DTCStatusMask;
  Dcm_GddGeneralDTCKind = DTCKind;
  Dcm_GddDTCOrigin = DTCOrigin;
  Dcm_GddFilterWithSeverityType = FilterWithSeverity;
  Dcm_GddDTCSeverityType = DTCSeverityMask;
  Dcm_GddFilterForFDCType = FilterForFaultDetectionCounter;
  Dcm_GucSetDtcFilterCount++;
  return(Dcm_GddSetFilterReturn);
}

/*******************************************************************************
**                        TestDem_SetDTCFilter()                           **
*******************************************************************************/
boolean TestDem_SetDTCFilter(App_DataValidateType LddDataValidate,
  uint8 ExpDTCStatusMask, Dem_DTCKindType ExpDTCKind, Dem_DTCOriginType
    ExpDTCOrigin, Dem_FilterWithSeverityType ExpFilterWithSeverity,
      Dem_DTCSeverityType ExpDTCSeverityMask, Dem_FilterForFDCType
        ExpFilterForFaultDetectionCounter)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucSetDtcFilterCount == 0x01) && (Dcm_GucDtcStatusMask ==
        ExpDTCStatusMask) && (Dcm_GddGeneralDTCKind  == ExpDTCKind) &&
          (Dcm_GddDTCOrigin == ExpDTCOrigin) &&
            (Dcm_GddFilterWithSeverityType == ExpFilterWithSeverity) &&
              (Dcm_GddDTCSeverityType == ExpDTCSeverityMask) &&
                (Dcm_GddFilterForFDCType == ExpFilterForFaultDetectionCounter))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucSetDtcFilterCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucSetDtcFilterCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**                        SimulateNumberOfFilteredDTCData()                           **
*******************************************************************************/
void SimulateNumberOfFilteredDTCData(uint16 LusFilteredDtc)
{
  Dcm_GusNumberOfFilteredDTC = LusFilteredDtc;
}

/*******************************************************************************
**                        SimulateDem_GetNumberOfFilteredDTCReturn()          **
*******************************************************************************/
void SimulateDem_GetNumberOfFilteredDTCReturn
  (Dem_ReturnGetNumberOfFilteredDTCType LddReturnType, uint16 LusFilteredDtc)
{
  Dcm_GddNumOfFilteredReturn = LddReturnType;
  Dcm_GusNumberOfFilteredDTC = LusFilteredDtc;
}

/*******************************************************************************
**                        SimulateDem_GetNumberOfFilteredDTC()                **
*******************************************************************************/
void SimulateDem_GetNumberOfFilteredDTC(Dem_ReturnGetNumberOfFilteredDTCType
  LddReturnType)
{
  Dcm_GddNumOfFilteredReturn = LddReturnType;
}

/*******************************************************************************
**                        Dem_GetNumberOfFilteredDTC()                        **
*******************************************************************************/
Dem_ReturnGetNumberOfFilteredDTCType Dem_GetNumberOfFilteredDTC
  (uint16* NumberOfFilteredDTC)
{
  *NumberOfFilteredDTC = Dcm_GusNumberOfFilteredDTC;
  Dcm_GucNumOfFilteredDtcCount++;
  return(Dcm_GddNumOfFilteredReturn);
}

/*******************************************************************************
**                        TestDem_GetNumberOfFilteredDTC()                    **
*******************************************************************************/
boolean TestDem_GetNumberOfFilteredDTC(App_DataValidateType LddDataValidate,
  uint16* ExpNumberOfFilteredDTC)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  ExpNumberOfFilteredDTC++;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucNumOfFilteredDtcCount == 0x01))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucNumOfFilteredDtcCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucNumOfFilteredDtcCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**                        SimulateDem_GetNextFilteredDTCData()                **
*******************************************************************************/
void SimulateDem_GetNextFilteredDTCData(uint32 LulDTC, uint8 LucDTCStatus,
  uint8 LucCount)
{
  Dcm_GaaNextFilteredDTC[LucCount] = LulDTC;
  Dcm_GaaNextFilteredDtcStatus[LucCount] = LucDTCStatus;
}


/*******************************************************************************
**                        SimulateDem_GetNextFilteredDTC()                    **
*******************************************************************************/
void SimulateDem_GetNextFilteredDTC(Dem_ReturnGetNextFilteredDTCType LddReturn)
{
  Dcm_GddNextFilteredReturn = LddReturn;
}

/*******************************************************************************
**                        Dem_GetNextFilteredDTC()                            **
*******************************************************************************/
Dem_ReturnGetNextFilteredDTCType Dem_GetNextFilteredDTC(uint32 *DTC,
  uint8 *DTCStatus)
{
  *DTC = Dcm_GaaNextFilteredDTC[Dcm_GucGetNextFilteredCount];
  *DTCStatus = Dcm_GaaNextFilteredDtcStatus[Dcm_GucGetNextFilteredCount];
  Dcm_GucGetNextFilteredCount++;
  return(Dcm_GddNextFilteredReturn);
}

/*******************************************************************************
**                        TestDem_GetNextFilteredDTC()                        **
*******************************************************************************/
boolean TestDem_GetNextFilteredDTC(App_DataValidateType LddDataValidate)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucGetNextFilteredCount == 0x01))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucGetNextFilteredCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucGetNextFilteredCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if(Dcm_GucGetNextFilteredCheckCount <= Dcm_GucGetNextFilteredCount)
      {
        LblRetValue = STEP_PASSED;
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Dcm_GucGetNextFilteredCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Dcm_GucGetNextFilteredCheckCount == Dcm_GucGetNextFilteredCount)
      {
        Dcm_GucGetNextFilteredCount = 0;
        Dcm_GucGetNextFilteredCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */

  }
    return(LblRetValue);
  }

/*******************************************************************************
**           SimulateDem_GetNextFilteredDTCAndFDC()                           **
*******************************************************************************/
void SimulateDem_GetNextFilteredDTCAndFDC( uint32 Lul_DTC,
  sint8 Luc_DTCFaultDetectionCounter)
  {
    Dcm_GulDTC3 = Lul_DTC;
  Dcm_GucDTCFaultDetectionCounter = Luc_DTCFaultDetectionCounter;
  }
/*******************************************************************************
**                   Dem_GetNextFilteredDTCAndFDC()                           **
*******************************************************************************/
Dem_ReturnGetNextFilteredDTCType Dem_GetNextFilteredDTCAndFDC
  (uint32* DTC, sint8* DTCFaultDetectionCounter)
{
  *DTC = Dcm_GulDTC3;
  *DTCFaultDetectionCounter = Dcm_GucDTCFaultDetectionCounter;
  Dcm_GucGetNextFilteredCount++;
  return(Dcm_GddNextFilteredReturn);
}

/*******************************************************************************
**                        TestDem_GetNextFilteredDTCAndFDC()                  **
*******************************************************************************/
boolean TestDem_GetNextFilteredDTCAndFDC(
  App_DataValidateType LddDataValidate, uint32 *LulExpDTC,
    sint8 *DTCFaultDetectionCounter)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LulExpDTC++;
  DTCFaultDetectionCounter++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucGetNextFilteredCount == 0x01))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucGetNextFilteredCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucGetNextFilteredCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}
/*******************************************************************************
**                        SimulateDem_GetNextFilteredDTCAndSeverity()         **
*******************************************************************************/
void SimulateDem_GetNextFilteredDTCAndSeverity(uint32 LulDTC,
  uint8 LucDTCStatus, Dem_DTCSeverityType LddDTCSeverity,
    uint8 LucDTCFunctionalUnit, uint8 LucCount)
{
  Dcm_GaaNextFilteredDTC[LucCount] = LulDTC;
  Dcm_GaaDtcStatus[LucCount] = LucDTCStatus;
  Dcm_GaaTCSeverityType[LucCount] = LddDTCSeverity;
  Dcm_GaaDTCFunctionalUnit[LucCount] = LucDTCFunctionalUnit;
}

/*******************************************************************************
**                        Dem_GetNextFilteredDTCAndSeverity()                 **
*******************************************************************************/
Dem_ReturnGetNextFilteredDTCType Dem_GetNextFilteredDTCAndSeverity(uint32 *DTC,
  uint8 *DTCStatus, Dem_DTCSeverityType *DTCSeverity, uint8 *DTCFunctionalUnit)
{
  *DTC = Dcm_GaaNextFilteredDTC[Dcm_GucGetNextFilteredCount];
  *DTCStatus = Dcm_GaaDtcStatus[Dcm_GucGetNextFilteredCount];
  *DTCSeverity = Dcm_GaaTCSeverityType[Dcm_GucGetNextFilteredCount];
  *DTCFunctionalUnit = Dcm_GaaDTCFunctionalUnit[Dcm_GucGetNextFilteredCount];
  Dcm_GucGetNextFilteredCount++;
  return(Dcm_GddNextFilteredReturn);
}

/*******************************************************************************
**                        TestDem_GetNextFilteredDTCAndSeverity()             **
*******************************************************************************/
boolean TestDem_GetNextFilteredDTCAndSeverity(
  App_DataValidateType LddDataValidate)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucGetNextFilteredCount == 0x01))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucGetNextFilteredCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucGetNextFilteredCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
    {

      /* Validating the Sequnce count and ID */
      if(Dcm_GucGetNextFilteredCheckCount <= Dcm_GucGetNextFilteredCount)
      {
        LblRetValue = STEP_PASSED;
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Dcm_GucGetNextFilteredCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Dcm_GucGetNextFilteredCheckCount == Dcm_GucGetNextFilteredCount)
      {
        Dcm_GucGetNextFilteredCount = 0;
        Dcm_GucGetNextFilteredCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
  }
    return(LblRetValue);
}

/*******************************************************************************
**                        SimulateDem_GetStatusOfDTCData()                    **
*******************************************************************************/
void SimulateDem_GetStatusOfDTCData(uint8 LucStatus)
{
  Dcm_GucDtcStatus = LucStatus;
}

/*******************************************************************************
**                        SimulateDem_GetStatusOfDTC()                        **
*******************************************************************************/
void SimulateDem_GetStatusOfDTC(Dem_ReturnGetStatusOfDTCType LddReturnType)
{
  Dcm_GddGetStatusOfDtcType = LddReturnType;
}

/*******************************************************************************
**                        Dem_GetStatusOfDTC()                                **
*******************************************************************************/
Dem_ReturnGetStatusOfDTCType Dem_GetStatusOfDTC(uint32 DTC, Dem_DTCKindType
 DTCKind, Dem_DTCOriginType DTCOrigin, uint8 *DTCStatus)
{
  Dcm_GulDTC2 = DTC;
  Dcm_GddGeneralDTCKind2 = DTCKind;
  Dcm_GddDTCOrigin2 = DTCOrigin;
  *DTCStatus = Dcm_GucDtcStatus;
  Dcm_GucDtcStatusCount++;
  return(Dcm_GddGetStatusOfDtcType);
}

/*******************************************************************************
**                        TestDem_GetStatusOfDTC()                            **
*******************************************************************************/
boolean TestDem_GetStatusOfDTC(App_DataValidateType LddDataValidate,
  uint32 LulExpDTC, Dem_DTCKindType LddExpDTCKind, Dem_DTCOriginType
    LddExpDTCOrigin, uint8 *LpExpDTCStatus)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpDTCStatus++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucDtcStatusCount == 0x01) && (Dcm_GulDTC2 == LulExpDTC) &&
        (Dcm_GddGeneralDTCKind2 == LddExpDTCKind) && (Dcm_GddDTCOrigin2 ==
          LddExpDTCOrigin))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucDtcStatusCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucDtcStatusCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}

/*******************************************************************************
**                        SimulateDem_GetSeverityOfDTCData()                  **
*******************************************************************************/
void SimulateDem_GetSeverityOfDTCData(Dem_DTCSeverityType LddSeverityType)
{
  Dcm_GddDTCSeverityType = LddSeverityType;
}

/*******************************************************************************
**                        SimulateDem_GetSeverityOfDTC()                      **
*******************************************************************************/
void SimulateDem_GetSeverityOfDTC(Dem_ReturnGetSeverityOfDTCType LddReturnType)
{
  Dcm_GddGetSeverityOfDTCTypeReturn = LddReturnType;
}

/*******************************************************************************
**                        Dem_GetSeverityOfDTC()                              **
*******************************************************************************/
Dem_ReturnGetSeverityOfDTCType Dem_GetSeverityOfDTC(uint32 DTC,
  Dem_DTCSeverityType *DTCSeverity)
{
  Dcm_GulDTC = DTC;
  *DTCSeverity = Dcm_GddDTCSeverityType;
  Dcm_GucGetNextFilteredCount++;
  return(Dcm_GddGetSeverityOfDTCTypeReturn);
}

/*******************************************************************************
**                        TestDem_GetSeverityOfDTC()                          **
*******************************************************************************/
boolean TestDem_GetSeverityOfDTC(App_DataValidateType LddDataValidate,
  uint32 LulExpDTC)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucGetNextFilteredCount == 0x01) && (Dcm_GulDTC == LulExpDTC))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucGetNextFilteredCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucGetNextFilteredCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}

/*******************************************************************************
**                        Dem_GetFunctionalUnitOfDTC()                        **
*******************************************************************************/
void SimulateDem_GetFunctionalUnitOfDTC(uint8 LucDTCFunctionalUnit)
{
  Dcm_GaaDTCFunctionalUnit[0] = LucDTCFunctionalUnit;
}

/*******************************************************************************
**                        Dem_GetFunctionalUnitOfDTC()                        **
*******************************************************************************/
Dem_ReturnGetFunctionalUnitOfDTCType Dem_GetFunctionalUnitOfDTC(uint32 DTC,
  uint8 *DTCFunctionalUnit)
{
  Dcm_GulDTC = DTC;
  *DTCFunctionalUnit = Dcm_GaaDTCFunctionalUnit[0];
  Dcm_GucSetDtcFilterCount++;
  return(Dcm_GddFunctionalUnitReturn);
}

/*******************************************************************************
**                        TestDem_GetFunctionalUnitOfDTC()                    **
*******************************************************************************/
boolean TestDem_GetFunctionalUnitOfDTC(App_DataValidateType LddDataValidate,
  uint32 LulExpDTC)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucSetDtcFilterCount == 0x01) && (Dcm_GulDTC == LulExpDTC))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucSetDtcFilterCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucSetDtcFilterCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}

/*******************************************************************************
**                        SimulateDem_GetDTCByOccurrenceTime()                **
*******************************************************************************/
void SimulateDem_GetDTCByOccurrenceTimeData(uint32 LulDTC)
{
  Dcm_GulDTC = LulDTC;
}

/*******************************************************************************
**                        SimulateDem_GetDTCByOccurrenceTime()                **
*******************************************************************************/
void SimulateDem_GetDTCByOccurrenceTime(Dem_ReturnGetDTCByOccurrenceTimeType
  LddReturnType)
{
  Dcm_GddGetDtcOccurenceReturn = LddReturnType;
}

/*******************************************************************************
**                        Dem_GetDTCByOccurrenceTime()                        **
*******************************************************************************/
Dem_ReturnGetDTCByOccurrenceTimeType Dem_GetDTCByOccurrenceTime
(Dem_DTCRequestType DTCRequest, Dem_DTCKindType DTCKind, uint32 *DTC)
{
  Dcm_GddDtcReqType = DTCRequest;
  Dcm_GddGeneralDTCKind = DTCKind;
  *DTC = Dcm_GulDTC;
  Dcm_GucSetDtcFilterCount++;
  return(Dcm_GddGetDtcOccurenceReturn);
}

/*******************************************************************************
**                        TestDem_GetDTCByOccurrenceTime()                    **
*******************************************************************************/
boolean TestDem_GetDTCByOccurrenceTime(App_DataValidateType LddDataValidate,
  Dem_DTCRequestType LddExpDTCRequest, Dem_DTCKindType LddExpDTCKind,
    uint32 *LulExpDTC)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LddExpDTCRequest++;
  LddExpDTCKind++;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucSetDtcFilterCount == 0x01) && (Dcm_GulDTC == *LulExpDTC))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucSetDtcFilterCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucSetDtcFilterCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}

/*******************************************************************************
**          SimulateDem_GetSizeOfFreezeFrameByDTCTest()                       **
*******************************************************************************/
void SimulateDem_GetSizeOfFreezeFrameByDTCTest(uint16 LusSizeOfFreezeFrame)
{
  Dcm_GusSizeOfFreezeFrame = LusSizeOfFreezeFrame;
}

/*******************************************************************************
**                        SimulateDem_GetSizeOfFreezeFrameByDTC()             **
*******************************************************************************/
void SimulateDem_GetSizeOfFreezeFrameByDTC
  (Dem_ReturnGetSizeOfFreezeFrameByDTCType LddReturnType)
{
  Dcm_GddGetSizeOfFreezeFrameByDTCType = LddReturnType;
}

/*******************************************************************************
**                        Dem_GetSizeOfFreezeFrameByDTC()                     **
*******************************************************************************/
Dem_ReturnGetSizeOfFreezeFrameByDTCType Dem_GetSizeOfFreezeFrameByDTC(uint32 DTC,
  Dem_DTCKindType DTCKind, Dem_DTCOriginType DTCOrigin,uint8 RecordNumber,
    uint16 *SizeOfFreezeFrame)
{
  Dcm_GulDTC = DTC;
  Dcm_GddGeneralDTCKind = DTCKind;
  Dcm_GddDTCOrigin = DTCOrigin;
  Dcm_GucRecordNum = RecordNumber;
  *SizeOfFreezeFrame = Dcm_GusSizeOfFreezeFrame;
  Dcm_GucDemGeneralCountFFSize++;
  return(Dcm_GddGetSizeOfFreezeFrameByDTCType);
}

/*******************************************************************************
**                        TestDem_GetSizeOfFreezeFrameByDTC()                 **
*******************************************************************************/
boolean TestDem_GetSizeOfFreezeFrameByDTC(App_DataValidateType LddDataValidate,
  uint32 LulExpDTC, Dem_DTCKindType LddExpDTCKind, Dem_DTCOriginType
    LddExpDTCOrigin, uint8 LucExpRecordNumber,uint16 *LpSizeOfFreezeFrame)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpSizeOfFreezeFrame++;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucDemGeneralCountFFSize == 0x01) && (LulExpDTC == Dcm_GulDTC) &&
        (LddExpDTCKind == Dcm_GddGeneralDTCKind) && (LddExpDTCOrigin == 
        Dcm_GddDTCOrigin) && (LucExpRecordNumber == Dcm_GucRecordNum))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucDemGeneralCountFFSize = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucDemGeneralCountFFSize == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}

/*******************************************************************************
**                        SmulateDem_DisableDTCRecordUpdate()                 **
*******************************************************************************/
void SimulateDem_DisableDTCRecordUpdate(Std_ReturnType LddReturnType)
{
  Dcm_GddDemGeneralReturn = LddReturnType;
}

/*******************************************************************************
**                        Dem_DisableDTCRecordUpdate()                        **
*******************************************************************************/
Std_ReturnType Dem_DisableDTCRecordUpdate(uint32 DTC, Dem_DTCOriginType DTCOrigin)
{
  Dcm_GulDTC = DTC;
  Dcm_GddDTCOrigin = DTCOrigin;
  Dcm_GucDemGeneralCountDisable++;
  return(Dcm_GddDemGeneralReturn);
}

/*******************************************************************************
**                        TestDem_DisableDTCRecordUpdate()                    **
*******************************************************************************/
boolean TestDem_DisableDTCRecordUpdate(App_DataValidateType LddDataValidate,
  uint32 LulExpDTC, Dem_DTCOriginType LddExpDTCOrigin)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucDemGeneralCountDisable == 0x01) && (LulExpDTC == Dcm_GulDTC) &&
        (LddExpDTCOrigin == Dcm_GddDTCOrigin))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucDemGeneralCountDisable = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucDemGeneralCountDisable == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}

/*******************************************************************************
**                        SimulateDem_GetFreezeFrameDataByDTC()               **
*******************************************************************************/
void SimulateDem_GetFreezeFrameDataByDTC (Dem_ReturnGetFreezeFrameDataByDTCType
  LddFreezeFrameDataByDTCType)
{
  Dcm_GddFreezeFrameDataByDTCType = LddFreezeFrameDataByDTCType;
  Dcm_GucDemGeneralCount++;

}
/*******************************************************************************
**                        SetDem_GetFreezeFrameDataByDTCBehaviour()           **
*******************************************************************************/
void SetDem_GetFreezeFrameDataByDTCBehaviour (uint8 Behaviour)
{
  Dcm_GucNormalBehaviour = Behaviour;
}

/*******************************************************************************
**                        Dem_GetFreezeFrameDataByDTC()                       **
*******************************************************************************/
Dem_ReturnGetFreezeFrameDataByDTCType Dem_GetFreezeFrameDataByDTC
  (uint32 DTC, Dem_DTCKindType DTCKind, Dem_DTCOriginType DTCOrigin,
    uint8 RecordNumber, uint8* DestBuffer, uint16* BufSize)
{

  uint8 LucIndex;
  LucIndex = 0x00;
switch(Dcm_GucNormalBehaviour)
{
  case DCM_NORMAL_BEHAVIOUR:
  {
    Dcm_GaaRequestBuff1[Dcm_GucDemFreezeFrameCount] = *BufSize;
    Dcm_GaaDTC5[Dcm_GucDemFreezeFrameCount] = DTC;
    Dcm_GaaGeneralDTCKind4[Dcm_GucDemFreezeFrameCount] = DTCKind;
    Dcm_GaaDTCOrigin3[Dcm_GucDemFreezeFrameCount] = DTCOrigin;
    Dcm_GaaRecordNum3[Dcm_GucDemFreezeFrameCount] = RecordNumber;
    *BufSize = 0x0A;
    while(LucIndex < 10)
    {
      *DestBuffer = Dcm_GaaGetFreezeFrameData[LucIndex];
      DestBuffer++;
      LucIndex++;
    }
    break;
  }
  case DCM_BEHAVIOUR_1:
  {
    Dcm_GaaRequestBuff1[Dcm_GucDemFreezeFrameCount] = *BufSize;
    Dcm_GaaDTC5[Dcm_GucDemFreezeFrameCount] = DTC;
    Dcm_GaaGeneralDTCKind4[Dcm_GucDemFreezeFrameCount] = DTCKind;
    Dcm_GaaDTCOrigin3[Dcm_GucDemFreezeFrameCount] = DTCOrigin;
    Dcm_GaaRecordNum3[Dcm_GucDemFreezeFrameCount] = RecordNumber;
   if((RecordNumber == 0x00) || (RecordNumber == 0x01) || (RecordNumber == 0x02))
   {
     Dcm_GddFreezeFrameDataByDTCType = DEM_GET_FFDATABYDTC_WRONG_RECORDNUMBER;
   }
   else if(RecordNumber == 0x03)
   {
     Dcm_GddFreezeFrameDataByDTCType = DEM_GET_FFDATABYDTC_OK;
     *BufSize = 0x000A;
    while(LucIndex < 10)
    {
     *DestBuffer = Dcm_GaaGetFreezeFrameData[LucIndex];
     LucIndex++;
     DestBuffer++;
    }
   }
   else
   {
     Dcm_GddFreezeFrameDataByDTCType = DEM_GET_FFDATABYDTC_WRONG_RECORDNUMBER;
   }
   break;
  }
  case DCM_BEHAVIOUR_2:
  {
    Dcm_GaaRequestBuff1[Dcm_GucDemFreezeFrameCount] = *BufSize;
    Dcm_GaaDTC5[Dcm_GucDemFreezeFrameCount] = DTC;
    Dcm_GaaGeneralDTCKind4[Dcm_GucDemFreezeFrameCount] = DTCKind;
    Dcm_GaaDTCOrigin3[Dcm_GucDemFreezeFrameCount] = DTCOrigin;
    Dcm_GaaRecordNum3[Dcm_GucDemFreezeFrameCount] = RecordNumber;
   if(RecordNumber == 0x00)
   {
     *BufSize = 0x0005;
     while(LucIndex < 5)
     {
      *DestBuffer = Dcm_GaaGetFreezeFrameData1[LucIndex];
      LucIndex++;
      DestBuffer++;
     }
   }
   else if(RecordNumber == 0x01)
   {
     *BufSize = 0x0005;
     while(LucIndex < 5)
     {
      *DestBuffer = Dcm_GaaGetFreezeFrameData2[LucIndex];
      LucIndex++;
      DestBuffer++;
     }
   }
   else
   {
     Dcm_GddFreezeFrameDataByDTCType = DEM_GET_FFDATABYDTC_WRONG_RECORDNUMBER;
   }
   break;
  }

  case DCM_BEHAVIOUR_3:
  {
    Dcm_GaaRequestBuff1[Dcm_GucDemFreezeFrameCount] = *BufSize;
    Dcm_GaaDTC5[Dcm_GucDemFreezeFrameCount] = DTC;
    Dcm_GaaGeneralDTCKind4[Dcm_GucDemFreezeFrameCount] = DTCKind;
    Dcm_GaaDTCOrigin3[Dcm_GucDemFreezeFrameCount] = DTCOrigin;
    Dcm_GaaRecordNum3[Dcm_GucDemFreezeFrameCount] = RecordNumber;
   if(RecordNumber == 0x02)
   {
     Dcm_GddFreezeFrameDataByDTCType = DEM_GET_FFDATABYDTC_OK;
     *BufSize = 0x0005;
     while(LucIndex < 5)
     {
      *DestBuffer = Dcm_GaaGetFreezeFrameData3[LucIndex];
      LucIndex++;
      DestBuffer++;
     }
   }
   else
   {
     Dcm_GddFreezeFrameDataByDTCType = DEM_GET_FFDATABYDTC_WRONG_RECORDNUMBER;
   }
   break;
  }
}
  Dcm_GucDemFreezeFrameCount++;
  return(Dcm_GddFreezeFrameDataByDTCType);

}

/*******************************************************************************
**                        TestDem_GetFreezeFrameDataByDTC()                   **
*******************************************************************************/
boolean TestDem_GetFreezeFrameDataByDTC(App_DataValidateType LddDataValidate,
  uint32 LulExpDTC, Dem_DTCKindType LddDTCKind, Dem_DTCOriginType LddExpDTCOrigin,
    uint8 LucRecordNumber, uint16* LusBufSize)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucDemFreezeFrameCount == 0x01) && (LulExpDTC == Dcm_GaaDTC5[0]) &&
       (LddDTCKind == Dcm_GaaGeneralDTCKind4[0]) &&
       (LddExpDTCOrigin == Dcm_GaaDTCOrigin3[0]) &&
       (LucRecordNumber == Dcm_GaaRecordNum3[0]) &&
       (*LusBufSize == Dcm_GaaRequestBuff1[0]))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucDemFreezeFrameCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucDemFreezeFrameCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
    {
      /* Validating the Sequnce count and ID */
      if((Dcm_GucDemFreezeFrameCheckCount <= Dcm_GucDemFreezeFrameCount) &&
        (LulExpDTC == Dcm_GaaDTC5[Dcm_GucDemFreezeFrameCheckCount]) &&
        (LddDTCKind == Dcm_GaaGeneralDTCKind4[Dcm_GucDemFreezeFrameCheckCount]) &&
        (LddExpDTCOrigin == Dcm_GaaDTCOrigin3[Dcm_GucDemFreezeFrameCheckCount]) &&
        (LucRecordNumber == Dcm_GaaRecordNum3[Dcm_GucDemFreezeFrameCheckCount]) &&
        (*LusBufSize == Dcm_GaaRequestBuff1[Dcm_GucDemFreezeFrameCheckCount]))
      {
        LblRetValue = STEP_PASSED;
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Dcm_GucDemFreezeFrameCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Dcm_GucDemFreezeFrameCheckCount == Dcm_GucDemFreezeFrameCount)
      {
        Dcm_GucDemFreezeFrameCount = 0;
        Dcm_GucDemFreezeFrameCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
  }
  return(LblRetValue);
}

/*******************************************************************************
**                        TestDem_EnableDTCRecordUpdate()                     **
*******************************************************************************/
boolean TestDem_EnableDTCRecordUpdate(App_DataValidateType LddDataValidate)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucDemGeneralCountEnable == 0x01))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucDemGeneralCountEnable = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucDemGeneralCountEnable == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}
/*******************************************************************************
**                        TestDem_EnableDTCRecordUpdate()                     **
*******************************************************************************/
void SimulateDem_GetFreezeFrameDataByRecord(Dem_ReturnGetFreezeFrameDataByRecordType
  LddReturnType)
{
  Dcm_FreezeFrameDataByRecordType = LddReturnType;
}
/*******************************************************************************
**                        Dem_GetFreezeFrameDataByRecord()                    **
*******************************************************************************/
Dem_ReturnGetFreezeFrameDataByRecordType Dem_GetFreezeFrameDataByRecord( uint8
  RecordNumber, Dem_DTCOriginType DTCOrigin, Dem_DTCKindType DTCKind,
    uint32* DTC, uint8* DestBuffer, uint16* BufSize )
{
  uint8 LucIndex;
  Dcm_GusBuffsize2 = *BufSize;
  LucIndex = 0;
  Dcm_GucRecordNum2 = RecordNumber;
  Dcm_GddDTCOrigin = DTCOrigin;
  Dcm_GddGeneralDTCKind = DTCKind;
  *DTC = Dcm_GulDTC2;
  *BufSize = Dcm_GusBuffsize;
  Dcm_GucDemGeneralCountFFRecord++;
  do
  {
   *DestBuffer = Dcm_GaaDemGeneralData[LucIndex];
   LucIndex++;
   DestBuffer++;
  }
  while(LucIndex < Dcm_GusBuffsize);
  return(Dcm_FreezeFrameDataByRecordType);
}
/*******************************************************************************
**                        TestDem_GetFreezeFrameDataByRecord()                **
*******************************************************************************/
boolean TestDem_GetFreezeFrameDataByRecord(App_DataValidateType LddDataValidate, uint8
  LcRecordNumber, Dem_DTCOriginType LddDTCOrigin, Dem_DTCKindType LddDTCKind,
    uint32* LulDTC, uint8* LucDestBuffer, uint16* LusBufSize)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LucDestBuffer++;
  LulDTC++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucDemGeneralCountFFRecord == 0x01) && (LcRecordNumber == Dcm_GucRecordNum2)
      && (LddDTCOrigin == Dcm_GddDTCOrigin) && (LddDTCKind == Dcm_GddGeneralDTCKind)
      &&(*LusBufSize == Dcm_GusBuffsize2))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucDemGeneralCountFFRecord = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucDemGeneralCountFFRecord == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}
/*******************************************************************************
**            SimulateDem_GetFreezeFrameDataByRecordTest()                    **
*******************************************************************************/
void SimulateDem_GetFreezeFrameDataByRecordTest(uint32 LulDTC, uint16 LusBufsize,
  uint8 *LucDestbuf)
{
  uint8 LucIndex = 0;
  Dcm_GulDTC2 = LulDTC;
  Dcm_GusBuffsize = LusBufsize;
  do
  {
    Dcm_GaaDemGeneralData[LucIndex] = *LucDestbuf;
  LucIndex++;
  LucDestbuf++;
  }
  while(LucIndex < LusBufsize);
  Dcm_GucDemGeneralCount++;
}
/*******************************************************************************
**            SimulateDem_GetSizeOfExtendedDataRecordByDTC()                  **
*******************************************************************************/
void SimulateDem_GetSizeOfExtendedDataRecordByDTC(
  Dem_ReturnGetSizeOfExtendedDataRecordByDTCType LucReturnType)
  {
    Dcm_SizeOfExtendedDataRecordByDTCType = LucReturnType;
  }
/*******************************************************************************
**                 Dem_GetSizeOfExtendedDataRecordByDTC()                     **
*******************************************************************************/
Dem_ReturnGetSizeOfExtendedDataRecordByDTCType Dem_GetSizeOfExtendedDataRecordByDTC
  ( uint32 DTC, Dem_DTCKindType DTCKind, Dem_DTCOriginType DTCOrigin,
    uint8 ExtendedDataNumber, uint16* SizeOfExtendedDataRecord )
{
  Dcm_GulDTC3 = DTC;
  Dcm_GddGeneralDTCKind3 = DTCKind;
  Dcm_GddDTCOrigin3 = DTCOrigin;
  Dcm_GucExtendedDataNumber = ExtendedDataNumber;
  *SizeOfExtendedDataRecord = Dcm_GusSizeOfExtendedDataRecord;
  Dcm_GucDemGeneralCountExtSize++;
  return(Dcm_SizeOfExtendedDataRecordByDTCType);
}

/*******************************************************************************
**           TestDem_GetSizeOfExtendedDataRecordByDTC()                       **
*******************************************************************************/
boolean TestDem_GetSizeOfExtendedDataRecordByDTC(App_DataValidateType LddDataValidate,
  uint32 Lul_DTC, Dem_DTCKindType Ldd_DTCKind, Dem_DTCOriginType Ldd_DTCOrigin,
    uint8 Luc_ExtendedDataNumber, uint16* Lus_SizeOfExtendedDataRecord)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  Lus_SizeOfExtendedDataRecord++;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucDemGeneralCountExtSize == 0x01) && (Lul_DTC == Dcm_GulDTC3) && 
        (Ldd_DTCKind == Dcm_GddGeneralDTCKind3) && (Ldd_DTCOrigin == 
        Dcm_GddDTCOrigin3) && (Luc_ExtendedDataNumber == 
        Dcm_GucExtendedDataNumber))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucDemGeneralCountExtSize = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucDemGeneralCountExtSize == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}
/*******************************************************************************
**          SimulateDem_GetSizeOfExtendedDataRecordByDTCUpdate()              **
*******************************************************************************/
void SimulateDem_GetSizeOfExtendedDataRecordByDTCUpdate
  (uint16 Lus_SizeOfExtendedDataRecord )
{
  Dcm_GusSizeOfExtendedDataRecord = Lus_SizeOfExtendedDataRecord;
}

/*******************************************************************************
**          SimulateDem_GetExtendedDataRecordByDTC()                          **
*******************************************************************************/
void SimulateDem_GetExtendedDataRecordByDTC(
  Dem_ReturnGetExtendedDataRecordByDTCType LucReturntype)
{
  Dcm_GucExtendedDataRecordByDTCType = LucReturntype;
}

/*******************************************************************************
**          SimulateDem_GetExtendedDataRecordByDTCBehavior()                  **
*******************************************************************************/
void SimulateDem_GetExtendedDataRecordByDTCBehavior(uint8 LucBehavior)
{
  Dcm_GucExtendedDataRecordByDTCBehavior = LucBehavior;
}

/*******************************************************************************
**          SimulateDem_GetExtendedDataRecordByDTCUpdate()                    **
*******************************************************************************/
void SimulateDem_GetExtendedDataRecordByDTCUpdate(uint8 *Laa_Destbuffer, uint16
  Lus_BuffSize)
{
  uint8 LucIndex;
  LucIndex = 0x00;
  Dcm_GusBuffsize1 = Lus_BuffSize;
  do
  {
    Dcm_GaaDemGeneralData[LucIndex] = *Laa_Destbuffer;
    LucIndex++;
    Laa_Destbuffer++;
  }
  while( LucIndex < Dcm_GusBuffsize1);

}

/*******************************************************************************
**                  Dem_GetExtendedDataRecordByDTC()                          **
*******************************************************************************/
Dem_ReturnGetExtendedDataRecordByDTCType Dem_GetExtendedDataRecordByDTC( uint32 DTC,
  Dem_DTCKindType DTCKind, Dem_DTCOriginType DTCOrigin, uint8 ExtendedDataNumber,
    uint8* DestBuffer, uint16 *BufSize )
{
  uint8 LucIndex;
  LucIndex = 0x00;
  switch(Dcm_GucExtendedDataRecordByDTCBehavior)
  {
    case DCM_EXTENDEDDATARECORDNORMALBEHAVIOR:
    {
      Dcm_GusBuffsize3[Dcm_GucDemGeneralCountExtRecords] = *BufSize;
      Dcm_GaaDTC4[Dcm_GucDemGeneralCountExtRecords] = DTC;
      Dcm_GddGeneralDTCKind4[Dcm_GucDemGeneralCountExtRecords] = DTCKind;
      Dcm_GddDTCOrigin4[Dcm_GucDemGeneralCountExtRecords] = DTCOrigin;
      Dcm_GucExtendedDataNumber1[Dcm_GucDemGeneralCountExtRecords] = 
        ExtendedDataNumber;
      while(LucIndex != Dcm_GusBuffsize1)
      {
        *DestBuffer = Dcm_GaaDemGeneralData[LucIndex];
        LucIndex++;
        DestBuffer++;
      }
      *BufSize = Dcm_GusBuffsize1;
      break;
    }
    case DCM_EXTENDEDDATARECORDBEHAVIOR1:
    {
      Dcm_GusBuffsize3[Dcm_GucDemGeneralCountExtRecords] = *BufSize;
      Dcm_GaaDTC4[Dcm_GucDemGeneralCountExtRecords] = DTC;
      Dcm_GddGeneralDTCKind4[Dcm_GucDemGeneralCountExtRecords] = DTCKind;
      Dcm_GddDTCOrigin4[Dcm_GucDemGeneralCountExtRecords] = DTCOrigin;
      Dcm_GucExtendedDataNumber1[Dcm_GucDemGeneralCountExtRecords] = 
        ExtendedDataNumber;
      if(ExtendedDataNumber ==  0x01)
      {
       *DestBuffer = 0x01;
        DestBuffer++;
       *DestBuffer = 0x02;
        *BufSize = 0x0002;
      }
      else if(ExtendedDataNumber ==  0x02)
      {
       *DestBuffer = 0x03;
        DestBuffer++;
       *DestBuffer = 0x04;
        *BufSize = 0x0002;
      }
      else if(ExtendedDataNumber >= 0x03)
      {
        Dcm_GucExtendedDataRecordByDTCType = DEM_RECORD_WRONG_NUMBER;
      }
      break;
    }
    case DCM_EXTENDEDDATARECORDBEHAVIOR2:
    {
      Dcm_GusBuffsize3[Dcm_GucDemGeneralCountExtRecords] = *BufSize;
      Dcm_GaaDTC4[Dcm_GucDemGeneralCountExtRecords] = DTC;
      Dcm_GddGeneralDTCKind4[Dcm_GucDemGeneralCountExtRecords] = DTCKind;
      Dcm_GddDTCOrigin4[Dcm_GucDemGeneralCountExtRecords] = DTCOrigin;
      Dcm_GucExtendedDataNumber1[Dcm_GucDemGeneralCountExtRecords] = 
        ExtendedDataNumber;
      if(ExtendedDataNumber ==  0x90)
      {
       *DestBuffer = 0x01;
        DestBuffer++;
       *DestBuffer = 0x02;
        *BufSize = 0x0002;
      }
      else if(ExtendedDataNumber ==  0x91)
      {
       *DestBuffer = 0x03;
        DestBuffer++;
       *DestBuffer = 0x04;
        *BufSize = 0x0002;
      }
      else if(ExtendedDataNumber >= 0x92)
      {
        Dcm_GucExtendedDataRecordByDTCType = DEM_RECORD_WRONG_NUMBER;
      }
      break;
    }
    case DCM_EXTENDEDDATARECORDBEHAVIOR3:
    {
      Dcm_GusBuffsize3[Dcm_GucDemGeneralCountExtRecords] = *BufSize;
      Dcm_GaaDTC4[Dcm_GucDemGeneralCountExtRecords] = DTC;
      Dcm_GddGeneralDTCKind4[Dcm_GucDemGeneralCountExtRecords] = DTCKind;
      Dcm_GddDTCOrigin4[Dcm_GucDemGeneralCountExtRecords] = DTCOrigin;
      Dcm_GucExtendedDataNumber1[Dcm_GucDemGeneralCountExtRecords] = 
        ExtendedDataNumber;
      *DestBuffer = 0x01;
       DestBuffer++;
      *DestBuffer = 0x02;
       DestBuffer++;
      *DestBuffer = 0x03;
       *BufSize = 0x0003;
      break;
    }
    case DCM_EXTENDEDDATARECORDBEHAVIOR4:
    {
      Dcm_GusBuffsize3[Dcm_GucDemGeneralCountExtRecords] = *BufSize;
      Dcm_GaaDTC4[Dcm_GucDemGeneralCountExtRecords] = DTC;
      Dcm_GddGeneralDTCKind4[Dcm_GucDemGeneralCountExtRecords] = DTCKind;
      Dcm_GddDTCOrigin4[Dcm_GucDemGeneralCountExtRecords] = DTCOrigin;
      Dcm_GucExtendedDataNumber1[Dcm_GucDemGeneralCountExtRecords] = 
        ExtendedDataNumber;
      if(ExtendedDataNumber == 0x01)
      {
        *DestBuffer = 0x01;
         DestBuffer++;
        *DestBuffer = 0x02;
         DestBuffer++;
         *BufSize = 0x0002;
      }
      else if(ExtendedDataNumber == 0x02)
      {
        *DestBuffer = 0x03;
         DestBuffer++;
        *DestBuffer = 0x04;
         DestBuffer++;
         *BufSize = 0x0002;
      }
      break;
    }
    case DCM_EXTENDEDDATARECORDBEHAVIOR5:
    {
      Dcm_GusBuffsize3[Dcm_GucDemGeneralCountExtRecords] = *BufSize;
      Dcm_GaaDTC4[Dcm_GucDemGeneralCountExtRecords] = DTC;
      Dcm_GddGeneralDTCKind4[Dcm_GucDemGeneralCountExtRecords] = DTCKind;
      Dcm_GddDTCOrigin4[Dcm_GucDemGeneralCountExtRecords] = DTCOrigin;
      Dcm_GucExtendedDataNumber1[Dcm_GucDemGeneralCountExtRecords] = 
        ExtendedDataNumber;
      if(ExtendedDataNumber == 0x03)
      {
        *DestBuffer = 0x05;
         DestBuffer++;
        *DestBuffer = 0x06;
         DestBuffer++;
      }
      else if(ExtendedDataNumber >= 0x04)
      {
        Dcm_GucExtendedDataRecordByDTCType = DEM_RECORD_WRONG_NUMBER;
      }
      break;
    }
    case DCM_EXTENDEDDATARECORDBEHAVIOR6:
    {
      Dcm_GusBuffsize3[Dcm_GucDemGeneralCountExtRecords] = *BufSize;
      Dcm_GaaDTC4[Dcm_GucDemGeneralCountExtRecords] = DTC;
      Dcm_GddGeneralDTCKind4[Dcm_GucDemGeneralCountExtRecords] = DTCKind;
      Dcm_GddDTCOrigin4[Dcm_GucDemGeneralCountExtRecords] = DTCOrigin;
      Dcm_GucExtendedDataNumber1[Dcm_GucDemGeneralCountExtRecords] = 
        ExtendedDataNumber;
      if(ExtendedDataNumber == 0x92)
      {
        *DestBuffer = 0x05;
         DestBuffer++;
        *DestBuffer = 0x06;
         DestBuffer++;
      }
      else if(ExtendedDataNumber >= 0x93)
      {
        Dcm_GucExtendedDataRecordByDTCType = DEM_RECORD_WRONG_NUMBER;
      }
      break;
    }
  case DCM_EXTENDEDDATARECORDBEHAVIOR7:
    {
      Dcm_GusBuffsize3[Dcm_GucDemGeneralCountExtRecords] = *BufSize;
      Dcm_GaaDTC4[Dcm_GucDemGeneralCountExtRecords] = DTC;
      Dcm_GddGeneralDTCKind4[Dcm_GucDemGeneralCountExtRecords] = DTCKind;
      Dcm_GddDTCOrigin4[Dcm_GucDemGeneralCountExtRecords] = DTCOrigin;
      Dcm_GucExtendedDataNumber1[Dcm_GucDemGeneralCountExtRecords] = 
        ExtendedDataNumber;
       DestBuffer++;
       *BufSize = 0x0000;
      break;
    }
  }  
  Dcm_GucDemGeneralCountExtRecords++;
  return(Dcm_GucExtendedDataRecordByDTCType);
}

/*******************************************************************************
**                 TestDem_GetExtendedDataRecordByDTC()                       **
*******************************************************************************/
boolean TestDem_GetExtendedDataRecordByDTC(App_DataValidateType LddDataValidate,
  uint32 Lul_DTC, Dem_DTCKindType Ldd_DTCKind, Dem_DTCOriginType Ldd_DTCOrigin,
    uint8 Luc_ExtendedDataNumber, uint8* Lp_DestBuffer, uint16 *Lus_BufSize)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  Lp_DestBuffer++;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucDemGeneralCountExtRecords == 0x01) && (Lul_DTC == Dcm_GaaDTC4[0]) && (Ldd_DTCKind ==
      Dcm_GddGeneralDTCKind4[0]) && (Ldd_DTCOrigin == Dcm_GddDTCOrigin4[0]) &&
      (Luc_ExtendedDataNumber == Dcm_GucExtendedDataNumber1[0]) &&
        (*Lus_BufSize ==  Dcm_GusBuffsize3[0]))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucDemGeneralCountExtRecords = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucDemGeneralCountExtRecords == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
    {
      /* Validating the Sequnce count and ID */
      if((Dcm_GucGetExtRecordCheckCount <= Dcm_GucDemGeneralCountExtRecords) && 
        (Lul_DTC == Dcm_GaaDTC4[Dcm_GucGetExtRecordCheckCount]) && (Ldd_DTCKind ==
        Dcm_GddGeneralDTCKind4[Dcm_GucGetExtRecordCheckCount]) && (Ldd_DTCOrigin == Dcm_GddDTCOrigin4[Dcm_GucGetExtRecordCheckCount]) &&
        (Luc_ExtendedDataNumber == Dcm_GucExtendedDataNumber1[Dcm_GucGetExtRecordCheckCount]) &&
        (*Lus_BufSize == Dcm_GusBuffsize3[Dcm_GucGetExtRecordCheckCount]))
      {
        LblRetValue = STEP_PASSED;
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Dcm_GucGetExtRecordCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Dcm_GucGetExtRecordCheckCount == Dcm_GucDemGeneralCountExtRecords)
      {
        Dcm_GucDemGeneralCountExtRecords = 0;
        Dcm_GucGetExtRecordCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */

  }
    return(LblRetValue);
}

/*******************************************************************************
**          SimulateDem_SetFreezeFrameRecordFilter()                          **
*******************************************************************************/
void SimulateDem_SetFreezeFrameRecordFilter ( Dem_ReturnSetFilterType Lus_ReturnType)
{
  Dcm_GddSetFilterReturn1 = Lus_ReturnType ;
}
/*******************************************************************************
**          SimulateDem_SetFreezeFrameRecordFilterUpdate()                    **
*******************************************************************************/
void SimulateDem_SetFreezeFrameRecordFilterUpdate
  ( uint16 Lus_NumberOfFilteredRecords )
{
  Dcm_GusnumberOfFilteredRecords = Lus_NumberOfFilteredRecords ;
}
/*******************************************************************************
**          SimulateDem_SetFreezeFrameRecordFilter()                          **
*******************************************************************************/
Dem_ReturnSetFilterType Dem_SetFreezeFrameRecordFilter(
  uint16* Lus_NumberOfFilteredRecords )
{
  *Lus_NumberOfFilteredRecords = Dcm_GusnumberOfFilteredRecords ;
  Dcm_GucDemGeneralFilterCount++;
  return ( Dcm_GddSetFilterReturn1 );
}


/*******************************************************************************
**                TestDem_SetFreezeFrameRecordFilter()                        **
*******************************************************************************/
boolean TestDem_SetFreezeFrameRecordFilter(App_DataValidateType LddDataValidate,
  uint16* Lus_NumberOfFilteredRecords)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  Lus_NumberOfFilteredRecords++;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucDemGeneralFilterCount == 0x01))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucDemGeneralFilterCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucDemGeneralFilterCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}

/*******************************************************************************
**          SimulateDem_SetNextFilterRecordReturn()                           **
*******************************************************************************/
void SimulateDem_SetNextFilterRecordReturn (Dem_ReturnGetNextFilteredDTCType Lus_ReturnType)
{
  Dcm_GddSetFilterReturn2 = Lus_ReturnType ;
}

/*******************************************************************************
**                        SimulateDem_GetNextFilteredRecord()                 **
*******************************************************************************/
void SimulateDem_GetNextFilteredRecord ( uint32 Lul_DTC, uint8 Luc_RecordNum, uint8 LucCount)
{
  Dcm_GaaDTC3[LucCount] = Lul_DTC;
  Dcm_GaaRecordNum4[LucCount] = Luc_RecordNum;
}

/*******************************************************************************
**                       Dem_GetNextFilteredRecord()                           **
*******************************************************************************/
Dem_ReturnGetNextFilteredDTCType Dem_GetNextFilteredRecord
  ( uint32* DTC, uint8* RecordNumber )
{
  *DTC = Dcm_GaaDTC3[Dcm_GucDemGeneralCount];
   *RecordNumber = Dcm_GaaRecordNum4[Dcm_GucDemGeneralCount];
   Dcm_GucDemGeneralCount++ ;
   return(Dcm_GddSetFilterReturn2);
}

/*******************************************************************************
**                    TestDem_GetNextFilteredRecord()                         **
*******************************************************************************/
boolean TestDem_GetNextFilteredRecord(App_DataValidateType LddDataValidate,
  uint32* Lul_DTC, uint8* Luc_RecordNumber)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  Lul_DTC++;
  Luc_RecordNumber++;


  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and DTC group */
      if((Dcm_GucDemGeneralCount == 0x01) )
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucDemGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucDemGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      {

      /* Validating the Sequnce count and ID */
      if(Dcm_GucGetNextFilteredRecordCheckCount <= Dcm_GucDemGeneralCount)
      {
        LblRetValue = STEP_PASSED;
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Dcm_GucGetNextFilteredRecordCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Dcm_GucGetNextFilteredRecordCheckCount == Dcm_GucDemGeneralCount)
      {
        Dcm_GucDemGeneralCount = 0;
        Dcm_GucGetNextFilteredRecordCheckCount = 0;
      }
      break;
    } 
    

  }
    return(LblRetValue);
}
#endif /* End DCM_MODULE_ACTIVE */
#ifdef FIM_MODULE_ACTIVE
/*******************************************************************************
**                        TestSetDem_GetEventStatus()                         **
*******************************************************************************/
void TestSetDem_GetEventStatus(Std_ReturnType LddReturnVal, uint8 LucIndex, 
  Dem_EventIdType EventId, Dem_EventStatusExtendedType* EventStatusExtended)
{
  FiM_GddEventStatusReturnVal = LddReturnVal;
  FiM_GddEventId[LucIndex] = EventId;
  FiM_GddEventStatusExtended[LucIndex] = *EventStatusExtended;
}

/*******************************************************************************
**                      Dem_GetEventStatus()                                  **
*******************************************************************************/
Std_ReturnType Dem_GetEventStatus(Dem_EventIdType EventId, 
  Dem_EventStatusExtendedType* EventStatusExtended)
{
  #ifndef TYPICAL_CONFIG
  FiM_GddEventId[FiM_GucReportCount] = EventId;
  *EventStatusExtended = FiM_GddEventStatusExtended[FiM_GucReportCount];
  FiM_GucReportCount++;
  #endif
  return(FiM_GddEventStatusReturnVal);
}

/*******************************************************************************
**                          TestDem_GetEventStatus()                          **
*******************************************************************************/
boolean TestDem_GetEventStatus(App_DataValidateType LddDataValidate,
  Dem_EventIdType LddExpEventId, Dem_EventStatusExtendedType* 
  LpExpEventStatusExtended)
{
  uint8 LucIndex;
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;
  
  UNUSED(LpExpEventStatusExtended);

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((FiM_GucReportCount == 0x01) &&
        (FiM_GddEventId[FiM_GucReportCount] == LddExpEventId))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      FiM_GucReportCount = 0;
      FiM_GucReportCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < FiM_GucReportCount; LucIndex++)
      {
        /* Validate EventId */
        if(FiM_GddEventId[LucIndex] == LddExpEventId)
        {
          LblStepResult = STEP_PASSED;
          LucIndex = FiM_GucReportCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FiM_GucReportCheckCount++;

      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FiM_GucReportCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestDem_GetEventStatus() */
#endif 
/*******************************************************************************
**                        TestDem_DefaultBehavior()                           **
*******************************************************************************/
void TestDem_DefaultBehavior(void)
{
  Dem_GucReportCount = 0;
  Dem_GucReportCheckCount = 0;
  #ifdef DCM_MODULE_ACTIVE
  Dcm_GucDemGeneralCount = 0;
  Dcm_GucDemGeneralCountEnableSet = 0;
  Dcm_GucDemGeneralCountDisableSet = 0;
  Dcm_GucDemGeneralClearCount = 0;
  Dcm_GucDemGeneralCountMask = 0;
  Dcm_GucDemGeneralCountFFSize = 0;
  Dcm_GucDemGeneralCountEnable = 0;
  Dcm_GucDemGeneralCountDisable = 0;
  Dcm_GucDemGeneralCountFFRecord = 0;
  Dcm_GucDemGeneralCountExtSize = 0;
  Dcm_GucDemGeneralCountExtRecords = 0;
  Dcm_GucGetExtRecordCheckCount = 0;
  Dcm_GddGetSizeOfFreezeFrameByDTCType = E_OK;
  Dcm_GddGetStatusOfDtcType = E_OK;
  Dcm_FreezeFrameDataByRecordType = E_OK;
  Dcm_GddDemGeneralReturn = E_OK;
  Dcm_GddTranslationReturn = DEM_DTC_TRANSLATION_ISO14229_1;
  Dcm_GddSetFilterReturn = DEM_FILTER_ACCEPTED;
  Dcm_GddNumOfFilteredReturn = DEM_NUMBER_OK;
  Dcm_GddNextFilteredReturn = DEM_FILTERED_OK;
  Dcm_GucGetNextFilteredCount = 0;
  Dcm_GddEnableDTCRetVal = DEM_CONTROL_DTC_SETTING_OK;
  Dcm_GddDisableDTCRetVal = DEM_CONTROL_DTC_SETTING_OK;
  Dcm_GucNormalBehaviour = DCM_NORMAL_BEHAVIOUR;
  Dcm_GddFreezeFrameDataByDTCType = DEM_GET_FFDATABYDTC_OK;
  Dcm_GucExtendedDataRecordByDTCBehavior = DCM_EXTENDEDDATARECORDNORMALBEHAVIOR;
  Dcm_GucExtendedDataRecordByDTCType = DEM_RECORD_OK;
  Dcm_GddSetFilterReturn1 = DEM_FILTER_ACCEPTED;
  Dcm_GddSetFilterReturn2 = DEM_FILTERED_OK;
  Dcm_GucDemGeneralFilterCount = 0x00;
  Dcm_GucGetNextFilteredRecordCheckCount = 0x00;
  Dcm_GucGetNextFilteredCheckCount = 0x00;
  Dcm_SizeOfExtendedDataRecordByDTCType = DEM_GET_SIZEOFEDRBYDTC_OK;
  Dcm_GucDtcStatusCount = 0x00;
  #endif 
  #ifdef ECUM_MODULE_ACTIVE
  Dem_GucPreInitSeqCnt = 0;
  Dem_GucPreInitCount = 0;
  #endif
  #ifdef FIM_MODULE_ACTIVE
  FiM_GucReportCount = 0;
  FiM_GucReportCheckCount = 0;
  FiM_GddEventStatusReturnVal = E_OK;
  #endif  
  #ifdef DLT_MODULE_ACTIVE
  Dlt_GddDTCReturnVal = 0;
  Dlt_GddEventExtReturnVal = 0;
  Dlt_GddEventFrReturnVal = 0;
  #endif
}

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
