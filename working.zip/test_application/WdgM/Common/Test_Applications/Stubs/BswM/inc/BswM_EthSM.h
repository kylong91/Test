/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: BswM_EthSM.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BswM Stub                                             **
**                                                                            **
**  PURPOSE   : Declaration of BswM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef BSWM_ETHSM_H
#define BSWM_ETHSM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
#include "EthSM.h"
#include "ComStack_Types.h"
#include "BswM.h"

/* AUTOSAR Specification Version Information */
#define BSWM_ETHSM_AR_RELEASE_MAJOR_VERSION    4
#define BSWM_ETHSM_AR_RELEASE_MINOR_VERSION    0
#define BSWM_ETHSM_AR_RELEASE_REVISION_VERSION 3

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern void BswM_EthSM_CurrentState( NetworkHandleType Network, 
                                   EthSM_BswMNetworkModeStateType CurrentState);

extern boolean TestBswM_EthSM_CurrentState(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpNetwork,EthSM_BswMNetworkModeStateType 
  LddExpCurrentState);
#endif /* BSWM_ETHSM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
