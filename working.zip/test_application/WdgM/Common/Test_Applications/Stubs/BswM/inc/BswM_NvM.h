/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: BswM_NvM.h                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BswM Stub                                             **
**                                                                            **
**  PURPOSE   : Declaration of BswM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef BSWM_WDGM_H
#define BSWM_WDGM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
#include "NvM.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void BswM_NvM_CurrentBlockMode
  (NvM_BlockIdType Block, NvM_RequestResultType CurrentBlockMode);

extern void BswM_NvM_CurrentJobMode
  (uint8 ServiceId, NvM_RequestResultType CurrentJobMode);
  
extern boolean Test_BswM_NvM_CurrentJobMode(App_DataValidateType LucDataValidate, 
  uint8 LucServiceId, NvM_RequestResultType LddCurrentJobMode);
  
extern boolean Test_BswM_NvM_CurrentBlockMode(App_DataValidateType LucDataValidate,
  NvM_BlockIdType LddBlock, NvM_RequestResultType LddCurrentBlockMode);
#endif /* BSWM_WDGM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
