/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: BswM_ComM.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BswM Stub                                             **
**                                                                            **
**  PURPOSE   : Declaration of BswM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef BSWM_COMM_H
#define BSWM_COMM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComM.h"
#include "ComStack_Types.h"
#include "TC_Generic.h"

extern NetworkHandleType BswM_GddNetwork;
extern ComM_ModeType BswM_GddRequestedMode;

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern void BswM_ComM_CurrentMode(NetworkHandleType Network,
  ComM_ModeType RequestedMode);

extern boolean TestBswM_ComM_CurrentMode(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpNetwork,
  ComM_ModeType LddExpRequestedMode);

extern void BswM_ComM_CurrentPNCMode(PNCHandleType PNC,
  ComM_PncModeType RequestedPNCMode);

extern boolean TestBswM_ComM_CurrentPNCMode(App_DataValidateType LucDataValidate,
  PNCHandleType LddExpPNC,
  ComM_PncModeType LddExpRequestedPNCMode);
  
#endif /* BSWM_COMM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
