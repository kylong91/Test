/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: BswM_EcuM.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BswM Stub                                             **
**                                                                            **
**  PURPOSE   : Declaration of BswM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef BSWM_ECUM_H
#define BSWM_ECUM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"
#include "EcuM.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void BswM_EcuM_CurrentState(EcuM_StateType CurrentState);
extern void BswM_EcuM_CurrentWakeup(EcuM_WakeupSourceType source, 
  EcuM_WakeupStatusType state);

extern boolean TestBswM_EcuM_CurrentState(App_DataValidateType LucDataValidate, 
  EcuM_StateType LddCurrentState);
extern boolean TestBswM_EcuM_CurrentWakeup(App_DataValidateType LucDataValidate, 
  EcuM_WakeupSourceType Lddsource, EcuM_WakeupStatusType Lddstate);

#endif /* BSWM_ECUM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
