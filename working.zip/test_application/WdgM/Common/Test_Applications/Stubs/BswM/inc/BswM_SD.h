/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: BswM_SD.h                                                     **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BswM Stub                                             **
**                                                                            **
**  PURPOSE   : Declaration of BswM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef BSWM_SD_H
#define BSWM_SD_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Sd.h"
#include "TC_Generic.h"
#include "ComStack_Types.h"
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
/* [SWS_SD_00006] */
/* Function called by SD module to indicate its current state. */
extern void BswM_SD_CurrentState( uint16, SD_StateType );

extern boolean TestBswM_SD_CurrentState(App_DataValidateType LucDataValidate,
  uint16 LusServiceInstanceID,
  SD_StateType LddExpCurrentState);


#endif /* BSWM_SD_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
