/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: BswM_WdgM.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BswM Stub                                             **
**                                                                            **
**  PURPOSE   : Declaration of BswM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef BSWM_WDGM_H
#define BSWM_WDGM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"
#include "Os.h"
#include "BswM.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/


extern void BswM_WdgM_RequestPartitionReset(ApplicationType Application);
extern boolean TestBswM_WdgM_RequestPartitionReset(
	App_DataValidateType LucDataValidate, ApplicationType LddApplication);

#endif /* BSWM_WDGM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
