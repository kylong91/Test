/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: BswM_Dcm.h                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BswM Stub                                             **
**                                                                            **
**  PURPOSE   : Declaration of BswM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef BSWM_DCM_H
#define BSWM_DCM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
#include "Dcm.h"
#include "ComStack_Types.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void BswM_Dcm_CommunicationMode_CurrentState(NetworkHandleType Network, 
Dcm_CommunicationModeType RequestedMode);

extern boolean TestBswM_Dcm_CommunicationMode_CurrentState(
  App_DataValidateType LucDataValidate, NetworkHandleType LddExpNetworkId,
  Dcm_CommunicationModeType LddExpCommunicationType);

#endif /* End BSWM_DCM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
