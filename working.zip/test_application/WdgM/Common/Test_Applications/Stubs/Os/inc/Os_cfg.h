/*******************************************************************************
**                  KPIT Technologies Limited                                 **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This           **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Os_Cfg.h                                                      **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Os Stub                                               **
**                                                                            **
**  PURPOSE   : Declaration of Os Stub functions                              **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By          Description                            **
********************************************************************************
** 1.0.0     21-Feb-2014   Srujana K   Initial version                        **
*******************************************************************************/
#ifndef  OS_CFG_H
#define  OS_CFG_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Os_Types.h"

/*******************************************************************************
**                      Version Information                                  **
*******************************************************************************/


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/* Task Handles */
#define OsConf_OsTask_OsTask0 (TaskType)1
#define OsConf_OsTask_OsTask1 (TaskType)2
#define OsConf_OsTask_OsTask2 (TaskType)3
#define OsConf_OsTask_OsTask3 (TaskType)4

#define OsTask0 (TaskType)1
#define OsTask1 (TaskType)2
#define OsTask2 (TaskType)3
#define OsTask3 (TaskType)4

#define OsTask_LowPower_10ms 6
#define OsTask_LowPower_20ms 7
#define OsTask_LowPower_30ms 8
#define OsTask_LowPower_40ms 9
#define OsTask_LowPower_50ms 10
#define OsTask_LowPower_60ms 11
#define OsTask_LowPower_70ms 12
#define OsTask_LowPower_80ms 13
#define OsTask_LowPower_90ms 14
#define OsTask_LowPower_100ms 15

#define OsTask_LowPower_NonPeriodic1 16
#define OsTask_LowPower_NonPeriodic2 17
#define OsTask_LowPower_NonPeriodic3 18
#define OsTask_LowPower_NonPeriodic4 19
#define OsTask_LowPower_NonPeriodic5 20

/* Event Handles */
#define OsConf_OsEvent_OsEvent0             (EventMaskType)1
#define OsConf_OsEvent_OsEvent1             (EventMaskType)2
#define OsConf_OsEvent_OsEvent2             (EventMaskType)4
#define OsConf_OsEvent_OsEvent3             (EventMaskType)8

#define OsEvent0             (EventMaskType)1
#define OsEvent1             (EventMaskType)2
#define OsEvent2             (EventMaskType)4
#define OsEvent3             (EventMaskType)8

/* AppMode Handles */
#define OsConf_OsAppMode_OsAppMode0 (AppModeType)1

#define OsAppMode0 (AppModeType)1

/* Resource Handles */
/*
#define OsConf_OsResource_OsResource0 (ResourceType)1
*/
#define OsConf_OsResource_OsResource1 (ResourceType)2

#define OsResource0 (ResourceType)1
#define OsResource1 (ResourceType)2

/* Application Handles */
#define OsConf_OsApplication_OsApplication0 (ApplicationType)0
#define OsConf_OsApplication_OsApplication1 (ApplicationType)1

#define OsApplication0 (ApplicationType)0
#define OsApplication1 (ApplicationType)1

/* Counter Handles */
#define OsConf_OsCounter_OsCounter0 (CounterType)1
#define OsConf_OsCounter_OsCounter1 (CounterType)2

#define OsCounter0 (CounterType)1
#define OsCounter1 (CounterType)2

/* ScheduleTable Handles */
#define OsConf_OsScheduleTable_OsScheduleTable0 1

#define OsScheduleTable0 1

/* Spinlock Handles */
#define OsConf_OsSpinlock_OsSpinlock0 1

#define OsSpinlock0 1

/* Partition Handles */
#define EcucPartition0 1


#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
