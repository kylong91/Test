/*******************************************************************************
**                  KPIT Technologies Limited                                 **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This           **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Os_Types.h                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR OS                                                    **
**                                                                            **
**  PURPOSE   : ApplicationType  and CoreIdType                               **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By          Description                            **
********************************************************************************
** 1.1.0     21-Feb-2014   Srujana K   As per SCR79,111type definition added  **
                                       for EventMaskRefType.                  **

** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/
#ifndef OS_TYPES_H
#define OS_TYPES_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
typedef uint32 OSDWORD;
typedef uint8 ApplicationType;
typedef uint16 CoreIdType;
typedef uint8 TaskType;
typedef TaskType * TaskRefType;
typedef uint8 AlarmType;
typedef uint32 TickType;
typedef TickType * TickRefType;
typedef uint8 ScheduleTableType;
typedef uint8 ScheduleTableStatusType;
typedef ScheduleTableStatusType * ScheduleTableStatusRefType;
typedef uint8 CounterType;
typedef uint8  AppModeType;
typedef uint8  ResourceType;
typedef uint8 EventMaskType;
typedef EventMaskType * EventMaskRefType;
typedef uint32 SpinlockIdType;

#define OS_THREE 0x03
/*
 * @def E_OS_ID
 *
 * This error code means : invalid identifier
 *
 * @warning OSEK error code meanings are not globally defined. Refer to each
 * standard service definition to know the exact meaning.
 */
#define E_OS_ID                               (uint8) 3
/*******************************************************************************
** Schedule Table states and actions                                          **
*******************************************************************************/
/**
 * @def SCHEDULETABLE_STOPPED
 *
 * This is a state of a ScheduleTable.
 */
#define SCHEDULETABLE_STOPPED                 ((ScheduleTableStatusType) 0)

/**
 * @def SCHEDULETABLE_NEXT
 *
 * This is a state of a ScheduleTable.
 */
#define SCHEDULETABLE_NEXT                    ((ScheduleTableStatusType) 1)

/**
 * @def SCHEDULETABLE_RUNNING
 *
 * This is a state of a ScheduleTable.
 */
#define SCHEDULETABLE_RUNNING                 ((ScheduleTableStatusType) 2)

/**
 * @def SCHEDULETABLE_STOPPED
 *
 * This is a state of a ScheduleTable.
 */
#define SCHEDULETABLE_WAITING                 ((ScheduleTableStatusType) 3)

/**
 * @def OS_SCHEDULETABLE_EXP_DEV
 *
 * This is a state of a ScheduleTable.
 */
#define OS_SCHEDULETABLE_EXP_DEV              ((ScheduleTableStatusType) 4)

/**
 * @def SCHEDULETABLE_RUNNING_AND_SYNCHRONOUS
 *
 * This is a state of a ScheduleTable.
 */
#define SCHEDULETABLE_RUNNING_AND_SYNCHRONOUS ((ScheduleTableStatusType) 5)

/**
 * @def OS_SCHEDULETABLE_EXP_REQ
 *
 * This is a state of a ScheduleTable.
 */
#define OS_SCHEDULETABLE_EXP_REQ              ((ScheduleTableStatusType) 6)

/**
 * @def OS_SCHEDULETABLE_EXP_PRE
 *
 * This is a state of a ScheduleTable.
 */
#define OS_SCHEDULETABLE_EXP_PRE              ((ScheduleTableStatusType) 7)
#endif 

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
