/*******************************************************************************
**                  KPIT Technologies Limited                                 **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This           **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Os.h                                                          **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Os Stub                                               **
**                                                                            **
**  PURPOSE   : Declaration of Os Stub functions                              **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By          Description                            **
********************************************************************************
** 1.1.0     21-Feb-2014   Srujana K   As per SCR79,111 change has been taken **
**                                     for multicore functionality.           **
**                                     extern declaration for API GetEvent and**
**                                     TestGetEvent added.                    **
**                                                                            **
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/
#ifndef OS_H
#define OS_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
#include "Std_Types.h"
#include "Os_Types.h"
#include "Os_Cfg.h"

/*******************************************************************************
**                      Version Information                                  **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define OS_AR_RELEASE_MAJOR_VERSION    0x04
#define OS_AR_RELEASE_MINOR_VERSION    0x04
#define OS_AR_RELEASE_REVISION_VERSION 0x00

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#define OsAlarm0 (AlarmType)0
#define OS_UNUSED(x) (void)(x)
extern AppModeType Os_GddMode;
extern StatusType Os_GddStatus;
extern ResourceType Os_GddResourceId;

#define OS_CORE_ID_MASTER (CoreIdType)0
#define OS_CORE_ID_0 (CoreIdType)1
#define OS_CORE_ID_1 (CoreIdType)2
#define OS_CORE_ID_2 (CoreIdType)3

#define OS_ARRAY_SIZE 25

#define INVALID_ISR 21

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern uint16 GetISRID (void);
extern void StartOS(AppModeType mode);
extern void ShutdownOS(StatusType Error);

extern void TestOs_DefaultBehavior(void);

extern StatusType SetAbsAlarm(AlarmType AlarmID, TickType start, 
  TickType cycle);
extern StatusType CancelAlarm(AlarmType AlarmID);

extern StatusType GetCounterValue(CounterType CounterID, TickRefType Value);
extern StatusType GetElapsedValue(CounterType CounterID, TickRefType Value, 
  TickRefType ElapsedValue);
extern boolean TestGetElapsedValue(App_DataValidateType LucDataValidate,
 CounterType CounterID, TickType Value, TickType ElapsedValue);
extern void App_TestPrepareElapsedValue(TickType LddCounterValue,
  TickType LddAdditionalCount);
extern boolean TestSetAbsAlarm(App_DataValidateType LucDataValidate, 
  AlarmType ExpAlarmID, TickType Expstart, TickType Expcycle);
extern boolean TestCancelAlarm(App_DataValidateType LucDataValidate, 
  AlarmType ExpAlarmID);

extern void TestResetOsInvocationCounts(void);

extern void TestGetElapsedValueSetVal
(StatusType RetStatus, TickType Value, TickType ElapsedValue);

extern StatusType GetScheduleTableStatus
(ScheduleTableType ScheduleTableID, ScheduleTableStatusRefType ScheduleStatus);

extern boolean TestGetScheduleTableStatus
(App_DataValidateType LucDataValidate, ScheduleTableType ScheduleTableID,
 ScheduleTableStatusType ScheduleStatus);

extern void TestGetScheduleTableStatusSetVal
(StatusType RetStatus, ScheduleTableStatusType ScheduleStatus);

extern StatusType SyncScheduleTable
(ScheduleTableType ScheduleTableID, TickType Value);

extern boolean TestSyncScheduleTable
(App_DataValidateType LucDataValidate,
 ScheduleTableType ScheduleTableID, TickType Value);

extern void TestSyncScheduleTableSetVal(StatusType RetStatus);

extern CoreIdType GetCoreID( void );
extern StatusType GetResource(ResourceType ResID);
extern StatusType ReleaseResource(ResourceType ResID);
extern StatusType GetSpinlock(SpinlockIdType SpinlockId);
extern StatusType ReleaseSpinlock(SpinlockIdType SpinlockId);
extern StatusType SetEvent(TaskType TaskID, EventMaskType Mask);
extern StatusType GetEvent(TaskType TaskID, EventMaskType* Event);
extern StatusType WaitEvent(EventMaskType Mask);
extern void EnableAllInterrupts(void);
extern void DisableAllInterrupts(void);
extern void StartCore(CoreIdType CoreID, StatusType* Status);
extern void ShutdownAllCores(StatusType Error);
extern boolean TestStartOS(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, AppModeType LddMode);
extern boolean TestShutdownOS(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, StatusType LddError);
extern boolean TestGetResource(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, ResourceType LddResID);
extern boolean TestReleaseResource(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, ResourceType LddResID);
extern boolean TestGetSpinlock(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, SpinlockIdType LddSpinID);
extern boolean TestReleaseSpinlock(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, SpinlockIdType LddSpinID);
extern boolean TestEnableAllInterrupts(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo);
extern boolean TestDisableAllInterrupts(App_DataValidateType LucDataValidate,
	uint8 LucSeqNo);
extern boolean TestGetCoreID(App_DataValidateType LucDataValidate,
	uint8 LucSeqNo);
extern boolean TestStartCore(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, CoreIdType LddCoreId, StatusType *LddStatus);
extern boolean TestShutdownAllCores(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, StatusType Error);
extern boolean TestSetEvent(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, TaskType TaskID, EventMaskType Mask);
extern boolean TestWaitEvent(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, EventMaskType Mask);
boolean TestGetEvent(App_DataValidateType LucDataValidate,uint8 LucSeqNo, TaskType TaskID );
extern void AppOs_SimulateGetCoreID(CoreIdType Type);

extern StatusType ActivateTask(TaskType TaskID);

extern boolean TestActivateTask(App_DataValidateType LucDataValidate, TaskType TaskID);

#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
