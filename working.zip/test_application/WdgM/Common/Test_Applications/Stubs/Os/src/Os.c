/*******************************************************************************
**                  KPIT Technologies Limited                                 **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This           **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Os.c                                                          **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Os Stub                                               **
**                                                                            **
**  PURPOSE   : This application file contains the Os Stub functions          **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By          Description                            **
********************************************************************************
** 1.1.1     25-Feb-2014   Srujana K   As per SCR ASRKPITBSW403_SCR_125       **
**                                     following variables extern decalared   **
**                                     EcuM_TcId_Flag, EcuM_SimulateCAN1,     **
**                                     EcuM_SimulatePower.                    **
**                                                                            **
** 1.1.0     21-Feb-2014   Srujana K   As per SCR79,111 following function are**
**                                     GetEvent, TestGetEvent and updated     **
**                                     WaitEvent.                             **
**                                                                            **
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Os.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#ifdef DBG_MODULE_ACTIVE
AlarmType Os_GddAlarmID;
TickType Os_GddStart;
TickType Os_GddCycle;
uint8 Os_GucSetAbsAlarmCount;
uint8 Os_GucCancelAlarm;
#endif 
#ifdef ECUM_MODULE_ACTIVE
AppModeType Os_GddMode = 0;
StatusType Os_GddStatus = E_OK;
ResourceType Os_GddResourceId = 0;
SpinlockIdType Os_GddSpinlockId = 0;
CoreIdType OsApp_GddCoreId;
TaskType Os_GddTaskIDValue;
uint8 Os_GucStartCount;
uint8 Os_GucStartSeqCnt;
uint8 Os_GucShutdownSeqCnt;
uint8 Os_GucShutdownCount;
uint8 Os_GucGetResourceCount;
uint8 Os_GucGetResourceSeqCnt[OS_ARRAY_SIZE];
uint8 Os_GucReleaseResourceCount;
uint8 Os_GucReleaseResourceSeqCnt[OS_ARRAY_SIZE];
uint8 Os_GucGetSpinlockCount;
uint8 Os_GucGetSpinlockSeqCnt[OS_ARRAY_SIZE];
uint8 Os_GucReleaseSpinlockCount;
uint8 Os_GucReleaseSpinlockSeqCnt[OS_ARRAY_SIZE];
uint8 Os_GucStartCoreCount;
uint8 Os_GucGetTaskID;
uint8 Os_GaaStartCoreSeqCnt[OS_ARRAY_SIZE];
uint8 Os_GaaGetResource[OS_ARRAY_SIZE];
uint8 Os_GaaReleaseResource[OS_ARRAY_SIZE];
uint8 Os_GaaGetSpinlock[OS_ARRAY_SIZE];
uint8 Os_GaaReleaseSpinlock[OS_ARRAY_SIZE];
uint8 Os_GucGetCoreIDSeqCnt[OS_ARRAY_SIZE];
uint8 Os_GucGetTaskIDSeqCnt[OS_ARRAY_SIZE];
uint8 Os_GucGetCoreIDCount;
uint8 Os_GucGetTaskIDCount;
uint8 Os_GucShutdownAllCoresSeqCnt[OS_ARRAY_SIZE];
uint8 Os_GucShutdownAllCoresCount;
uint8 Os_GucShutdownAllCoresStateCount = 0;
uint8 Os_GucEnableAllSeqCnt[OS_ARRAY_SIZE];
uint8 Os_GucEnableAllCount = 0;
uint8 Os_GucDisableAllSeqCnt[OS_ARRAY_SIZE];
uint8 Os_GucDisableAllCount = 0;
uint8 Os_GucEnableCheckStateCount = 0;
uint8 Os_GucDisableCheckStateCount = 0;
uint8 Os_GucStartCoreStateCount = 0;
uint8 Os_GucGetResCheckCount = 0;
uint8 Os_GucRelResCheckCount = 0;
uint8 Os_GucGetSpinlockCheckCount = 0;
uint8 Os_GucRelSpinlockCheckCount = 0;
uint8 Os_GucSetSlaveEventCount = 0;
uint8 Os_GucSetEventSeqCnt[OS_ARRAY_SIZE];
uint8 Os_GucSetEventCheckCount = 0;
uint8 Os_GaaSetEventTaskId[OS_ARRAY_SIZE];
uint8 Os_GaaSetSlaveEventMask[OS_ARRAY_SIZE];
uint8 Os_GaaSetEventMask;
uint8 Os_GucWaitEventCount = 0;
uint8 Os_GucWaitEventSeqCnt[OS_ARRAY_SIZE];
uint8 Os_GucWaitEventCheckCount = 0;
uint8 Os_GucGetCoreStateCount = 0;
uint8 Os_GucGetTaskStateCount = 0;
uint8 Os_GaaWaitEventMask[OS_ARRAY_SIZE];
uint8 Os_GucSimulateCoreId=OS_CORE_ID_0;
uint8 Os_GaaGetEventTaskId[OS_ARRAY_SIZE];
uint8 Os_GucGetEventCount=0;
uint8 Os_GucGetEventSeqCnt[OS_ARRAY_SIZE];
uint8 Os_GaaGetEventMask[OS_ARRAY_SIZE];
uint8 Os_GucGetEventCheckCount = 0;
uint8 Os_GaaClearEventTaskId[OS_ARRAY_SIZE];
uint8 Os_GucClearEventCount=0;
uint8 Os_GucClearEventSeqCnt[OS_ARRAY_SIZE];
uint8 Os_GaaClearEventMask[OS_ARRAY_SIZE];
uint8 Os_GucClearEventCheckCount = 0;
#endif
#ifdef BSWM_MODULE_ACTIVE
uint8 Os_GucActivateTaskcnt;
TaskType Os_GddTaskId;
#endif
#ifdef STBM_MODULE_ACTIVE
TickType Os_GddCurrentValue;
TickType Os_GddElapsedValue;
TickType Os_GddScheduleTickValue;
CounterType Os_GddCounterID;
StatusType Os_GddGetElapsedValueRetStatus;
StatusType Os_GddGetScheduleTableStatusRetStatus;
StatusType Os_GddSyncScheduleTableRetStatus;
ScheduleTableStatusType Os_GddScheduleStatus;
ScheduleTableType Os_GddScheduleID;
uint8 Os_GddGetElapsedValueCount;
uint8 Os_GddGetScheduleTableStatusCount;
uint8 Os_GddSyncScheduleTableCount;
#endif /* #ifdef STBM_MODULE_ACTIVE */

#define ECUM_MULTI_CORE_SUPPORT STD_OFF
#if(ECUM_MULTI_CORE_SUPPORT == STD_ON)
 extern uint8 NumerOfSlaveCore;
 extern boolean EcuM_TcId_Flag;
 extern boolean EcuM_SimulateCAN1;
 extern boolean EcuM_SimulatePower;
#endif
#ifdef WDGM_MODULE_ACTIVE
TickType Os_GddCounterValue;
TickType Os_GddAdditionalCount;
#endif

#ifdef STBM_MODULE_ACTIVE
/******************************************************************************/
void TestResetOsInvocationCounts(void)
{
  Os_GddGetElapsedValueCount = 0;
  Os_GddGetScheduleTableStatusCount = 0;
  Os_GddSyncScheduleTableCount = 0;
}
/******************************************************************************/

StatusType GetElapsedValue
(CounterType CounterID, TickRefType Value, TickRefType ElapsedValue)
{
  *Value = Os_GddCurrentValue;
  *ElapsedValue = Os_GddElapsedValue;
  Os_GddCounterID = CounterID;
  Os_GddGetElapsedValueCount++;
  return Os_GddGetElapsedValueRetStatus;
}

void TestGetElapsedValueSetVal
(StatusType RetStatus, TickType Value, TickType ElapsedValue)
{
  Os_GddGetElapsedValueRetStatus = RetStatus;
  Os_GddCurrentValue = Value;
  Os_GddElapsedValue = ElapsedValue;
}

boolean TestGetElapsedValue(App_DataValidateType LucDataValidate,
 CounterType CounterID, TickType Value, TickType ElapsedValue)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Value == Os_GddCurrentValue) && 
        (ElapsedValue == Os_GddElapsedValue) &&
        (CounterID == Os_GddCounterID) && (1 == Os_GddGetElapsedValueCount))
      {
        LblStepResult = STEP_PASSED;
        Os_GddGetElapsedValueCount = 0x00;
      }
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Os_GddGetElapsedValueCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
}
/******************************************************************************/
StatusType GetScheduleTableStatus
(ScheduleTableType ScheduleTableID, ScheduleTableStatusRefType ScheduleStatus)
{
  Os_GddScheduleID = ScheduleTableID;
  *ScheduleStatus = Os_GddScheduleStatus;
  Os_GddGetScheduleTableStatusCount++;
  return Os_GddGetScheduleTableStatusRetStatus;
}

void TestGetScheduleTableStatusSetVal
(StatusType RetStatus, ScheduleTableStatusType ScheduleStatus)
{
  Os_GddGetScheduleTableStatusRetStatus = RetStatus;
  Os_GddScheduleStatus = ScheduleStatus;
}

boolean TestGetScheduleTableStatus
(App_DataValidateType LucDataValidate, ScheduleTableType ScheduleTableID,
 ScheduleTableStatusType ScheduleStatus)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((ScheduleStatus == Os_GddScheduleStatus) && 
        (ScheduleTableID == Os_GddScheduleID) &&
        (1 == Os_GddGetScheduleTableStatusCount))
      {
        LblStepResult = STEP_PASSED;
        Os_GddGetScheduleTableStatusCount = 0;
      }
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Os_GddGetScheduleTableStatusCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
}
/******************************************************************************/
StatusType SyncScheduleTable
(ScheduleTableType ScheduleTableID, TickType Value)
{
  Os_GddScheduleID = ScheduleTableID;
  Os_GddScheduleTickValue = Value;
  Os_GddSyncScheduleTableCount++;
  return Os_GddSyncScheduleTableRetStatus;
}

void TestSyncScheduleTableSetVal(StatusType RetStatus)
{
  Os_GddSyncScheduleTableRetStatus = RetStatus;
}

boolean TestSyncScheduleTable
(App_DataValidateType LucDataValidate,
 ScheduleTableType ScheduleTableID, TickType Value)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Value == Os_GddScheduleTickValue) && 
        (ScheduleTableID == Os_GddScheduleID) &&
        (1 == Os_GddSyncScheduleTableCount))
      {
        LblStepResult = STEP_PASSED;
        Os_GddSyncScheduleTableCount = 0;
      }
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Os_GddSyncScheduleTableCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
}
/******************************************************************************/
void TestOs_DefaultBehavior(void)
{
  
} /* End TestOs_DefaultBehavior() */
#endif /* #ifdef STBM_MODULE_ACTIVE */
#ifdef DBG_MODULE_ACTIVE
/*******************************************************************************
**                       SetAbsAlarm()                                        **
*******************************************************************************/
StatusType SetAbsAlarm(AlarmType AlarmID, TickType start, TickType cycle)
{
  #ifndef TYPICAL_CONFIG
  Os_GddAlarmID = AlarmID;
  Os_GddStart = start;
  Os_GddCycle = cycle;
  Os_GucSetAbsAlarmCount++;
  #endif
  return(E_OK);
} /* End SetAbsAlarm() */

/*******************************************************************************
**                       TestSetAbsAlarm()                                    **
*******************************************************************************/
boolean TestSetAbsAlarm(App_DataValidateType LucDataValidate, 
  AlarmType ExpAlarmID, TickType Expstart, TickType Expcycle)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Os_GucSetAbsAlarmCount == 0x01) && 
        (ExpAlarmID == Os_GddAlarmID) && 
        (Expstart == Os_GddStart) && 
        (Expcycle == Os_GddCycle))
      {
        LblStepResult = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Os_GucSetAbsAlarmCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End TestSetAbsAlarm() */

/*******************************************************************************
**                       CancelAlarm()                                        **
*******************************************************************************/
StatusType CancelAlarm(AlarmType AlarmID)
{
  #ifndef TYPICAL_CONFIG
  Os_GddAlarmID = AlarmID;
  Os_GucCancelAlarm++;
  #endif
  return(E_OK);
} /* End CancelAlarm() */

/*******************************************************************************
**                       TestCancelAlarm()                                    **
*******************************************************************************/
boolean TestCancelAlarm(App_DataValidateType LucDataValidate, 
  AlarmType ExpAlarmID)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Os_GucCancelAlarm == 0x01) && 
        (ExpAlarmID == Os_GddAlarmID))
      {
        LblStepResult = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Os_GucCancelAlarm = 0;      
      break;
    } /* End case S_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End TestCancelAlarm() */
#endif

#ifdef WDGM_MODULE_ACTIVE
/*******************************************************************************
**                            GetCounterValue()                               **
*******************************************************************************/
StatusType GetCounterValue(CounterType CounterID, TickRefType Value)
{
  UNUSED(CounterID);
  (*Value) = Os_GddCounterValue;
  return(E_OK);
} /* End GetCounterValue() */

/*******************************************************************************
**                            GetElapsedValue()                               **
*******************************************************************************/
StatusType GetElapsedValue(CounterType CounterID, TickRefType Value, 
  TickRefType ElapsedValue)
{
  UNUSED(CounterID);
  (*ElapsedValue) = (*Value) + Os_GddAdditionalCount;
  return(E_OK);
} /* End GetElapsedValue() */

/*******************************************************************************
**                            App_TestPrepareElapsedValue()                   **
*******************************************************************************/
void App_TestPrepareElapsedValue(TickType LddCounterValue, TickType 
  LddAdditionalCount)
{
  Os_GddCounterValue = LddCounterValue;
  Os_GddAdditionalCount = LddAdditionalCount;
} /* End App_TestPrepareElapsedValue() */
#endif

#ifdef BSWM_MODULE_ACTIVE

/*******************************************************************************
**                       GetCoreID()                                          **
*******************************************************************************/

CoreIdType GetCoreID(void)
{
  return(1);
}


/*******************************************************************************
**                       TestCancelAlarm()                                    **
*******************************************************************************/

StatusType ActivateTask(TaskType TaskID)
{
  Os_GucActivateTaskcnt++;
  Os_GddTaskId = TaskID;
  return(E_OK);
}

/*******************************************************************************
**                       TestActivateTask()                                   **
*******************************************************************************/
boolean TestActivateTask(App_DataValidateType LucDataValidate, TaskType TaskID)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Os_GucActivateTaskcnt != 0x00) && 
        (Os_GddTaskId == TaskID))
      {
        LblStepResult = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Os_GucActivateTaskcnt = 0;      
      break;
    } /* End case S_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End TestActivateTask() */

#endif
#ifdef ECUM_MODULE_ACTIVE

/*******************************************************************************
**                       GetTaskID()                                          **
*******************************************************************************/
StatusType GetTaskID(TaskRefType TaskID)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GucGetTaskIDSeqCnt[Os_GucGetTaskIDCount] = App_GucApiSeqCnt;
  *TaskID = Os_GddTaskIDValue;
  if(Os_GucGetTaskIDCount < OS_ARRAY_SIZE)
  {
    Os_GucGetTaskIDCount++;
  }
  else
  {
    Os_GucGetTaskIDCount = 0;
  }
  #endif

  return(E_OK);
}

void TestGetTaskIDSetVal(TaskType TaskID)
{
  Os_GddTaskIDValue = TaskID;
}

/*******************************************************************************
**                         TestStartCore()                                    **
*******************************************************************************/
boolean TestGetTaskID(App_DataValidateType LucDataValidate, uint8 LucSeqNo)
{
  uint8 LucIndex;
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Os_GucGetTaskIDCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucGetTaskIDCount = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if(Os_GucGetTaskIDSeqCnt[0] == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucGetTaskIDCount = 0;
      Os_GucGetTaskIDSeqCnt[0] = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */


    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Os_GucGetTaskIDCount; LucIndex++)
      {
        /* Validate Current state */
        if(Os_GucGetTaskIDSeqCnt[LucIndex] == LucSeqNo)
        {
          LblStepResult = STEP_PASSED;
          Os_GucGetTaskIDSeqCnt[LucIndex] = 0;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucGetTaskIDCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucGetTaskStateCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucGetTaskStateCount == Os_GucGetTaskIDCount)
      {
        Os_GucGetTaskIDCount = 0;
        Os_GucGetTaskStateCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestReleaseResource() */

/*******************************************************************************
**                             StartOS()                                      **
*******************************************************************************/
void StartOS(AppModeType mode)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GucStartSeqCnt = App_GucApiSeqCnt;
  Os_GucStartCount++;
  Os_GddMode = mode;
  #endif
}

/*******************************************************************************
**                             TestStartOS()                                  **
*******************************************************************************/
boolean TestStartOS(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, AppModeType LddMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Os_GddMode == LddMode) && (Os_GucStartCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucStartCount = 0;
      Os_GucStartSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if((Os_GddMode == LddMode) && (Os_GucStartSeqCnt == LucSeqNo))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucStartSeqCnt = 0;
      Os_GucStartCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestStartOS() */

/*******************************************************************************
**                             ShutdownOS()                                   **
*******************************************************************************/
void ShutdownOS(StatusType Error)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GucShutdownSeqCnt = App_GucApiSeqCnt;
  Os_GucShutdownCount++;
  Os_GddStatus = Error;
  #endif
}

/*******************************************************************************
**                             TestShutdownOS()                               **
*******************************************************************************/
boolean TestShutdownOS(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, StatusType LddError)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Os_GddStatus == LddError) && (Os_GucShutdownCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucShutdownCount = 0;
      Os_GucShutdownSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if((Os_GddStatus == LddError) && (Os_GucShutdownSeqCnt == LucSeqNo))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucShutdownSeqCnt = 0;
      Os_GucShutdownCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Os_GucShutdownCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestShutdownOS() */

/*******************************************************************************
**                             GetResource()                                  **
*******************************************************************************/
StatusType GetResource(ResourceType ResID)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GucGetResourceSeqCnt[Os_GucGetResourceCount] = App_GucApiSeqCnt;
  Os_GaaGetResource[Os_GucGetResourceCount] = ResID;
  if(Os_GucGetResourceCount < OS_ARRAY_SIZE)
  {
    Os_GucGetResourceCount++;
  }
  #endif
  return(Os_GddStatus);
}

/*******************************************************************************
**                             TestGetResource()                              **
*******************************************************************************/
boolean TestGetResource(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, ResourceType LddResID)
{
  uint8 LucIndex;
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Os_GaaGetResource[0] == LddResID) && (Os_GucGetResourceCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucGetResourceCount = 0;
      Os_GucGetResourceSeqCnt[0] = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if((Os_GaaGetResource[0] == LddResID) &&
        (Os_GucGetResourceSeqCnt[0] == LucSeqNo))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucGetResourceSeqCnt[0] = 0;
      Os_GucGetResourceCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Os_GucGetResourceCount; LucIndex++)
      {
        /* Validate Current state */
        if((Os_GaaGetResource[LucIndex] == LddResID) &&
           (Os_GucGetResourceSeqCnt[LucIndex] == LucSeqNo))
        {
          LblStepResult = STEP_PASSED;
          Os_GucGetResourceSeqCnt[LucIndex] = 0;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucGetResourceCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucGetResCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucGetResCheckCount == Os_GucGetResourceCount)
      {
        Os_GucGetResourceCount = 0;
        Os_GucGetResCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestGetResource() */

/*******************************************************************************
**                           ReleaseResource()                                **
*******************************************************************************/
StatusType ReleaseResource(ResourceType ResID)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GucReleaseResourceSeqCnt[Os_GucReleaseResourceCount] = App_GucApiSeqCnt;
  Os_GaaReleaseResource[Os_GucReleaseResourceCount] = ResID;
  if(Os_GucReleaseResourceCount < OS_ARRAY_SIZE)
  {
    Os_GucReleaseResourceCount++;
  }
  #endif
  return(Os_GddStatus);
}

/*******************************************************************************
**                         TestReleaseResource()                              **
*******************************************************************************/
boolean TestReleaseResource(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, ResourceType LddResID)
{
  uint8 LucIndex;
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Os_GaaReleaseResource[0] == LddResID) && (Os_GucReleaseResourceCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucReleaseResourceCount = 0;
      Os_GucReleaseResourceSeqCnt[0] = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if((Os_GaaReleaseResource[0] == LddResID) &&
        (Os_GucReleaseResourceSeqCnt[0] == LucSeqNo))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucReleaseResourceSeqCnt[0] = 0;
      Os_GucReleaseResourceCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Os_GucReleaseResourceCount; LucIndex++)
      {
        /* Validate Current state */
        if((Os_GaaReleaseResource[LucIndex] == LddResID) &&
           (Os_GucReleaseResourceSeqCnt[LucIndex] == LucSeqNo))
        {
          LblStepResult = STEP_PASSED;
          Os_GucReleaseResourceSeqCnt[LucIndex] = 0;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucReleaseResourceCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucRelResCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucRelResCheckCount == Os_GucReleaseResourceCount)
      {
        Os_GucReleaseResourceCount = 0;
        Os_GucRelResCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestReleaseResource() */
#if (ECUM_MULTI_CORE_SUPPORT == STD_ON)
/*******************************************************************************
**                             GetSpinlock()                                  **
*******************************************************************************/
StatusType GetSpinlock(SpinlockIdType SpinlockId)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GucGetSpinlockSeqCnt[Os_GucGetSpinlockCount] = App_GucApiSeqCnt;
  Os_GaaGetSpinlock[Os_GucGetSpinlockCount] = SpinlockId;
  if(Os_GucGetSpinlockCount < OS_ARRAY_SIZE)
  {
    Os_GucGetSpinlockCount++;
  }

  #endif
  return(Os_GddStatus);
}

/*******************************************************************************
**                             TestGetSpinlock()                              **
*******************************************************************************/
boolean TestGetSpinlock(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, SpinlockIdType LddSpinID)
{
  uint8 LucIndex;
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Os_GaaGetSpinlock[0] == LddSpinID) && (Os_GucGetSpinlockCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucGetSpinlockCount = 0;
      Os_GucGetSpinlockSeqCnt[0] = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if((Os_GaaGetSpinlock[0] == LddSpinID) &&
        (Os_GucGetSpinlockSeqCnt[0] == LucSeqNo))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucGetSpinlockSeqCnt[0] = 0;
      Os_GucGetSpinlockCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Os_GucGetSpinlockCount; LucIndex++)
      {
        /* Validate Current state */
        if((Os_GaaGetSpinlock[LucIndex] == LddSpinID) &&
           (Os_GucGetSpinlockSeqCnt[LucIndex] == LucSeqNo))
        {
          LblStepResult = STEP_PASSED;
		  Os_GucGetSpinlockSeqCnt[LucIndex] = 0;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucGetSpinlockCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucGetSpinlockCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucGetSpinlockCheckCount == Os_GucGetSpinlockCount)
      {
        Os_GucGetSpinlockCount = 0;
        Os_GucGetSpinlockCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestGetSpinlock() */

/*******************************************************************************
**                           ReleaseSpinlock()                                **
*******************************************************************************/
StatusType ReleaseSpinlock(SpinlockIdType SpinlockId)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GucReleaseSpinlockSeqCnt[Os_GucReleaseSpinlockCount] = App_GucApiSeqCnt;
  Os_GaaReleaseSpinlock[Os_GucReleaseSpinlockCount] = SpinlockId;
  if(Os_GucReleaseSpinlockCount < OS_ARRAY_SIZE)
  {
    Os_GucReleaseSpinlockCount++;
  }
  #endif
  return(Os_GddStatus);
}

/*******************************************************************************
**                         TestReleaseSpinlock()                              **
*******************************************************************************/
boolean TestReleaseSpinlock(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, SpinlockIdType LddSpinID)
{
  uint8 LucIndex;
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Os_GaaReleaseSpinlock[0] == LddSpinID) && (Os_GucReleaseSpinlockCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucReleaseSpinlockCount = 0;
      Os_GucReleaseSpinlockSeqCnt[0] = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if((Os_GaaReleaseSpinlock[0] == LddSpinID) &&
        (Os_GucReleaseSpinlockSeqCnt[0] == LucSeqNo))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucReleaseSpinlockSeqCnt[0] = 0;
      Os_GucReleaseSpinlockCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Os_GucReleaseSpinlockCount; LucIndex++)
      {
        /* Validate Current state */
        if((Os_GaaReleaseSpinlock[LucIndex] == LddSpinID) &&
           (Os_GucReleaseSpinlockSeqCnt[LucIndex]))
        {
          LblStepResult = STEP_PASSED;
		  Os_GucReleaseSpinlockSeqCnt[LucIndex] = 0;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucReleaseSpinlockCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucRelSpinlockCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucRelSpinlockCheckCount == Os_GucReleaseSpinlockCount)
      {
        Os_GucReleaseSpinlockCount = 0;
        Os_GucRelSpinlockCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestReleaseSpinlock() */

/*******************************************************************************
**                         SetEvent()                                         **
*******************************************************************************/
StatusType SetEvent(TaskType TaskID, EventMaskType Mask)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GucSetEventSeqCnt[Os_GucSetSlaveEventCount] = App_GucApiSeqCnt;
  Os_GaaSetEventTaskId[Os_GucSetSlaveEventCount] = TaskID;
  Os_GaaSetEventMask |= Mask;
  Os_GaaSetSlaveEventMask[Os_GucSetSlaveEventCount] = 
                                      Os_GaaSetEventMask;
  if(Os_GucSetSlaveEventCount < OS_ARRAY_SIZE)
  {
    Os_GucSetSlaveEventCount++;
  }

  #endif
  return(0);
}

/*******************************************************************************
**                         GetEvent()                                         **
*******************************************************************************/
StatusType GetEvent(TaskType TaskID, EventMaskType* Event)
{
 boolean LblReturn;
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GucGetEventSeqCnt[Os_GucGetEventCount] = App_GucApiSeqCnt;
  Os_GaaGetEventTaskId[Os_GucGetEventCount] = TaskID;
  * Event = Os_GaaSetSlaveEventMask[Os_GucSetSlaveEventCount-1];
  if(Os_GucGetEventCount < OS_ARRAY_SIZE)
  {
    Os_GucGetEventCount++;
  }
  #endif
  LblReturn = E_OK; 
  return(LblReturn);
}

/*******************************************************************************
**                         ClearEvent()                                       **
*******************************************************************************/
StatusType ClearEvent(EventMaskType Event)
{
  boolean LblReturn;
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++; 
  Os_GaaSetEventMask &= (~Event);
  Os_GaaClearEventMask[Os_GucClearEventCount] = Event;
  Os_GucClearEventSeqCnt[Os_GucClearEventCount] = App_GucApiSeqCnt;
  if(Os_GucClearEventCount < OS_ARRAY_SIZE)
  {
    Os_GucClearEventCount++;
  } 
  #endif
  LblReturn = E_OK; 
  return(LblReturn);
}
/*******************************************************************************
**                         TestGetEvent()                                     **
*******************************************************************************/
boolean TestGetEvent(App_DataValidateType LucDataValidate,uint8 LucSeqNo,
                                                               TaskType TaskID )
{
 uint8 LucIndex=0;
 boolean LblStepResult;
  switch(LucDataValidate)
  {
   /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
   case S_VALIDATE:
    {
      if((Os_GaaGetEventTaskId[0] == TaskID) &&
        (Os_GucGetEventCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucGetEventCount = 0;
      Os_GucGetEventSeqCnt[0] = 0;
      break;
    } /* End case S_VALIDATE: */
    
   case S_VALIDATE_SEQ:
    {
      if((Os_GaaGetEventTaskId[0] == TaskID) &&
        (Os_GucGetEventSeqCnt[0] == LucSeqNo))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucGetEventSeqCnt[0] = 0;
      Os_GucGetEventCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
     for(LucIndex = 0; LucIndex < Os_GucGetEventCount; LucIndex++)
      {
        /* Validate Current state */
        if((Os_GaaGetEventTaskId[LucIndex] == TaskID) && 
           (Os_GucGetEventSeqCnt[LucIndex] == LucSeqNo))
        {
          LblStepResult = STEP_PASSED;
          Os_GucGetEventSeqCnt[LucIndex] = 0;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucGetEventCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucGetEventCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucGetEventCheckCount == Os_GucGetEventCount)
      {
        Os_GucGetEventCount = 0;
        Os_GucGetEventCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
     default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
    
  }
  return(LblStepResult);
}
/*******************************************************************************
**                         TestSetEvent()                                     **
*******************************************************************************/
boolean TestSetEvent(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, TaskType TaskID, EventMaskType Mask)
{
  uint8 LucIndex;
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Os_GaaSetEventTaskId[0] == TaskID) && (Os_GaaSetEventMask == Mask) &&
        (Os_GucSetSlaveEventCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucSetSlaveEventCount = 0;
      Os_GucSetEventSeqCnt[0] = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if((Os_GaaSetEventTaskId[0] == TaskID) && (Os_GaaSetEventMask == Mask) &&
        (Os_GucSetEventSeqCnt[0] == LucSeqNo))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucSetEventSeqCnt[0] = 0;
      Os_GucSetSlaveEventCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Os_GucSetSlaveEventCount; LucIndex++)
      {
        /* Validate Current state */
        if((Os_GaaSetEventTaskId[LucIndex] == TaskID) &&
           (Os_GaaSetSlaveEventMask[LucIndex] == Mask) &&
           (Os_GucSetEventSeqCnt[LucIndex] == LucSeqNo))
        {
          LblStepResult = STEP_PASSED;
          Os_GucSetEventSeqCnt[LucIndex] = 0;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucSetSlaveEventCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucSetEventCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucSetEventCheckCount == Os_GucSetSlaveEventCount)
      {
        Os_GucSetEventCheckCount = 0;
        Os_GucSetSlaveEventCount = 0;
        Os_GaaSetEventMask = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestReleaseResource() */

/*******************************************************************************
**                         TestClearEvent()                                   **
*******************************************************************************/
boolean TestClearEvent(App_DataValidateType LucDataValidate,uint8 LucSeqNo,
                                                            EventMaskType Mask )
{
 uint8 LucIndex=0;
 boolean LblStepResult;
  switch(LucDataValidate)
  {
   /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
   case S_VALIDATE:
    {
      if((Os_GaaClearEventMask[0] == Mask) &&
        (Os_GucClearEventCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucClearEventCount = 0;
      Os_GucClearEventSeqCnt[0] = 0;
      break;
    } /* End case S_VALIDATE: */
    
   case S_VALIDATE_SEQ:
    {
      if((Os_GaaClearEventMask[0] == Mask) &&
        (Os_GucClearEventSeqCnt[0] == LucSeqNo))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucClearEventSeqCnt[0] = 0;
      Os_GucClearEventCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
     for(LucIndex = 0; LucIndex < Os_GucClearEventCount; LucIndex++)
      {
        /* Validate Current state */
        if((Os_GaaClearEventMask[LucIndex] == Mask) &&
           (Os_GucClearEventSeqCnt[LucIndex] == LucSeqNo))
        {
          LblStepResult = STEP_PASSED;

          Os_GucClearEventSeqCnt[LucIndex] = 0;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucClearEventCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucClearEventCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucClearEventCheckCount == Os_GucClearEventCount)
      {
        Os_GucClearEventCount = 0;
        Os_GucClearEventCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
     default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
    
  }
  return(LblStepResult);
}
/*******************************************************************************
**                         WaitEvent()                                        **
*******************************************************************************/
StatusType WaitEvent(EventMaskType Mask)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GaaWaitEventMask[Os_GucWaitEventCount] = Mask;
  Os_GucWaitEventSeqCnt[Os_GucWaitEventCount] = App_GucApiSeqCnt;
  if(Os_GucWaitEventCount < OS_ARRAY_SIZE)
  {
    Os_GucWaitEventCount++;
  }  
  #endif
  if(NumerOfSlaveCore != (uint8)OS_THREE)
  {
    if(EcuM_TcId_Flag == ECUM_TRUE)
    {
      if(Os_GucSimulateCoreId == OS_CORE_ID_0)
      {
       /* simulate slave core 0 id */
       AppOs_SimulateGetCoreID(OS_CORE_ID_0);
       if(EcuM_SimulatePower == ECUM_FALSE)
       {
        /* Simulate wakeup event as CAN */
        App_SimulateStub(SET_CAN);
       }
       else
       {
       /* Simulate wakeup event as POWER */
        App_SimulateStub(SET_POWER);
       }
       /* Call main function for slave */
       EcuM_MainFunction();
       Os_GucSimulateCoreId++;
       if(EcuM_SimulatePower == ECUM_FALSE)
       {
        /* Clear CAN wakeup event */
        EcuM_ClearWakeupEvent(ECUM_WKSOURCE_CAN);
       }
       else
       {
        /* Clear POWER wakeup event */
        EcuM_ClearWakeupEvent(ECUM_WKSOURCE_POWER);
       }
      }
      else if(Os_GucSimulateCoreId == OS_CORE_ID_1)
      {
       /* Set core id to slave core 1 */
       AppOs_SimulateGetCoreID(OS_CORE_ID_1);
       if(EcuM_SimulatePower == ECUM_FALSE)
       {
        /* Simulate wakeup event as CAN */
        App_SimulateStub(SET_CAN);
       }
       else
       {
        /* Simulate wakeup event as POWER */
        App_SimulateStub(SET_POWER);
       }
       /* Call main function for slave */ 
       EcuM_MainFunction();
       Os_GucSimulateCoreId = OS_CORE_ID_0;
       if(EcuM_SimulatePower == ECUM_FALSE)
       {
        /* Clear CAN wakeup event */
        EcuM_ClearWakeupEvent(ECUM_WKSOURCE_CAN);
       }
       else
       {
       /* Clear POWER wakeup event */
        EcuM_ClearWakeupEvent(ECUM_WKSOURCE_POWER);
       }
       /* Simulate master core id */
       AppOs_SimulateGetCoreID(OS_CORE_ID_MASTER);
       if(EcuM_SimulatePower == ECUM_FALSE)
       {
         if(EcuM_SimulateCAN1 == ECUM_FALSE)
         {
          /* Simulate wakeup event as CAN */
          App_SimulateStub(SET_CAN);
         }
         else
         {
          /* Simulate wakeup event as CAN1 */
          App_SimulateStub(SET_CAN1);
         }
       }
       else
       {
        /* Simulate wakeup event as POWER */
        App_SimulateStub(SET_POWER);
       }
       /* Clear all flags used for check conditions */
       EcuM_TcId_Flag = ECUM_FALSE;
       EcuM_SimulateCAN1 = ECUM_FALSE;
       EcuM_SimulatePower = ECUM_FALSE;
      }
      
    }
    else
    {
      if(Os_GucSimulateCoreId == OS_CORE_ID_0)
      {
       /* Simulate slave core id 0 */
       AppOs_SimulateGetCoreID(OS_CORE_ID_0);
       /* Call main function for slave */  
       EcuM_MainFunction();
       Os_GucSimulateCoreId++;
      }
     else if(Os_GucSimulateCoreId == OS_CORE_ID_1)
     {
       /* Simulate slave core id 1 */
       AppOs_SimulateGetCoreID(OS_CORE_ID_1);
       /* Call main function for slave */ 
       EcuM_MainFunction();
       Os_GucSimulateCoreId = OS_CORE_ID_0;
     }
    }
  }
  else
  {
   if(Os_GucSimulateCoreId == OS_CORE_ID_0)
    {
       /* Simulate slave core id 0 */
       AppOs_SimulateGetCoreID(OS_CORE_ID_0);
       /* Call main function for slave */  
       EcuM_MainFunction();
       AppOs_SimulateGetCoreID(OS_CORE_ID_1);
       EcuM_MainFunction();
       Os_GucSimulateCoreId++;
    }
    else if(Os_GucSimulateCoreId == OS_CORE_ID_1)
    {
     AppOs_SimulateGetCoreID(OS_CORE_ID_2);
     EcuM_MainFunction();
     Os_GucSimulateCoreId = OS_CORE_ID_0;
    }
  
  }
  return(0);
  
}

/*******************************************************************************
**                         TestWaitEvent()                                    **
*******************************************************************************/
boolean TestWaitEvent(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, EventMaskType Mask)
{
  uint8 LucIndex;
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Os_GaaWaitEventMask[0] == Mask) &&
        (Os_GucWaitEventCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucWaitEventCount = 0;
      Os_GucWaitEventSeqCnt[0] = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if((Os_GaaWaitEventMask[0] == Mask) &&
        (Os_GucWaitEventSeqCnt[0] == LucSeqNo))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucWaitEventSeqCnt[0] = 0;
      Os_GucWaitEventCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex <= Os_GucWaitEventCount; LucIndex++)
      {
        /* Validate Current state */
        if((Os_GaaWaitEventMask[LucIndex] == Mask) &&
           (Os_GucWaitEventSeqCnt[LucIndex] == LucSeqNo))
        {
          LblStepResult = STEP_PASSED;
          Os_GucWaitEventSeqCnt[LucIndex] = 0;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucWaitEventCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucWaitEventCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucWaitEventCheckCount == Os_GucWaitEventCount)
      {
        Os_GucWaitEventCount = 0;
        Os_GucWaitEventCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestWaitEvent() */
#endif // End of #ifdef ECUM_MULTI_CORE_SUPPORT

/*******************************************************************************
**                         EnableAllInterrupts()                              **
*******************************************************************************/
void EnableAllInterrupts(void)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GucEnableAllSeqCnt[Os_GucEnableAllCount] = App_GucApiSeqCnt;
  if(Os_GucEnableAllCount < OS_ARRAY_SIZE)
  {
    Os_GucEnableAllCount++;
  }
  else
  {
    Os_GucEnableAllCount = 0;
  }
  #endif
}
/*******************************************************************************
**                         DisableAllInterrupts()                             **
*******************************************************************************/
void DisableAllInterrupts(void)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GucDisableAllSeqCnt[Os_GucDisableAllCount] = App_GucApiSeqCnt;
  if(Os_GucDisableAllCount < OS_ARRAY_SIZE)
  {
    Os_GucDisableAllCount++;
  }
  else
  {
    Os_GucDisableAllCount = 0;
  }
  #endif
}
/*******************************************************************************
**                         TestEnableAllInterrupts()                          **
*******************************************************************************/
boolean TestEnableAllInterrupts(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Os_GucEnableAllCount == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucEnableAllCount = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if(Os_GucEnableAllSeqCnt[0] == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucEnableAllCount = 0;

      break;
    } /* End case S_VALIDATE_SEQ: */

    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Os_GucEnableAllCount; LucIndex++)
      {
        /* Validate Current state */
        if(Os_GucEnableAllSeqCnt[LucIndex] == LucSeqNo)
        {
          LblStepResult = STEP_PASSED;
          Os_GucEnableAllSeqCnt[LucIndex] = 0;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucEnableAllCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucEnableCheckStateCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucEnableCheckStateCount == Os_GucEnableAllCount)
      {
        Os_GucEnableAllCount = 0;
        Os_GucEnableCheckStateCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
}
/*******************************************************************************
**                         TestDisableAllInterrupts()                         **
*******************************************************************************/
boolean TestDisableAllInterrupts(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Os_GucDisableAllCount == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucDisableAllCount = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if(Os_GucDisableAllSeqCnt[0] == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucDisableAllCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Os_GucDisableAllCount; LucIndex++)
      {
        /* Validate Current state */
        if(Os_GucDisableAllSeqCnt[LucIndex] == LucSeqNo)
        {
          LblStepResult = STEP_PASSED;
          Os_GucDisableAllSeqCnt[LucIndex] = 0;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucDisableAllCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucDisableCheckStateCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucDisableCheckStateCount == Os_GucDisableAllCount)
      {
        Os_GucDisableAllCount = 0;
        Os_GucDisableCheckStateCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
}
/*******************************************************************************
**                         StartCore()                                        **
*******************************************************************************/
void StartCore(CoreIdType CoreID, StatusType* Status)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GaaStartCoreSeqCnt[Os_GucStartCoreCount] = App_GucApiSeqCnt;
  if(Os_GucStartCoreCount < OS_ARRAY_SIZE)
  {
    Os_GucStartCoreCount++;
  }
  else
  {
    Os_GucStartCoreCount = 0;
  }
  OS_UNUSED(CoreID);
  OS_UNUSED(Status);
  #endif
}
/*******************************************************************************
**                         ShutdownAllCores()                                 **
*******************************************************************************/
void ShutdownAllCores(StatusType Error)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GucShutdownAllCoresSeqCnt[Os_GucShutdownAllCoresCount] = App_GucApiSeqCnt;
  Os_GucShutdownAllCoresCount++;
	OS_UNUSED(Error);
  #endif
}
/*******************************************************************************
**                         AppOs_SimulateGetCoreID()                          **
*******************************************************************************/
void AppOs_SimulateGetCoreID(CoreIdType Type)
{
  OsApp_GddCoreId = Type;
}
/*******************************************************************************
**                         GetCoreID()                                        **
*******************************************************************************/
CoreIdType GetCoreID(void)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GucGetCoreIDSeqCnt[Os_GucGetCoreIDCount] = App_GucApiSeqCnt;
  if(Os_GucGetCoreIDCount < OS_ARRAY_SIZE)
  {
    Os_GucGetCoreIDCount++;
  }
  else
  {
    Os_GucGetCoreIDCount = 0;
  }
  #endif
  return(OsApp_GddCoreId);
}

/*******************************************************************************
**                         TestStartCore()                                    **
*******************************************************************************/
boolean TestStartCore(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, CoreIdType LddCoreId, StatusType *LddStatus)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Os_GucStartCoreCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucStartCoreCount = 0;
      Os_GaaStartCoreSeqCnt[Os_GucStartCoreCount] = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if(Os_GaaStartCoreSeqCnt[Os_GucStartCoreCount] == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucStartCoreCount = 0;
      Os_GaaStartCoreSeqCnt[Os_GucStartCoreCount] = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Os_GucStartCoreCount; LucIndex++)
      {
        /* Validate Current state */
        if(Os_GaaStartCoreSeqCnt[LucIndex] == LucSeqNo)
        {
          LblStepResult = STEP_PASSED;
          Os_GaaStartCoreSeqCnt[LucIndex] = 0;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucStartCoreCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucStartCoreStateCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucStartCoreStateCount == Os_GucStartCoreCount)
      {
        Os_GucStartCoreCount = 0;
        Os_GucStartCoreStateCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  OS_UNUSED(LddCoreId);
	OS_UNUSED(LddStatus);
  return(LblStepResult);
} /* End TestStartCore() */

/*******************************************************************************
**                         TestGetCoreID()                                    **
*******************************************************************************/
boolean TestGetCoreID(App_DataValidateType LucDataValidate, uint8 LucSeqNo)
{
  uint8 LucIndex;
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Os_GucGetCoreIDCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucGetCoreIDCount = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if(Os_GucGetCoreIDSeqCnt[0] == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucGetCoreIDCount = 0;
      Os_GucGetCoreIDSeqCnt[0] = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */


    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Os_GucGetCoreIDCount; LucIndex++)
      {
        /* Validate Current state */
        if(Os_GucGetCoreIDSeqCnt[LucIndex] == LucSeqNo)
        {
          LblStepResult = STEP_PASSED;
          Os_GucGetCoreIDSeqCnt[LucIndex] = 0;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucGetCoreIDCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucGetCoreStateCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucGetCoreStateCount == Os_GucGetCoreIDCount)
      {
        Os_GucGetCoreIDCount = 0;
        Os_GucGetCoreStateCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestGetCoreID() */

/*******************************************************************************
**                         TestShutdownAllCores()                             **
*******************************************************************************/
boolean TestShutdownAllCores(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, StatusType Error)
{
  uint8 LucIndex;
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;


  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
   case S_VALIDATE:
    {
      if((Os_GucShutdownAllCoresCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucShutdownAllCoresCount = 0;
      Os_GucShutdownAllCoresSeqCnt[0] = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if(Os_GucShutdownAllCoresSeqCnt[0] == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucShutdownAllCoresCount = 0;
      Os_GucShutdownAllCoresSeqCnt[0] = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Os_GucShutdownAllCoresCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }

    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Os_GucShutdownAllCoresCount; LucIndex++)
      {
        /* Validate Current state */
        if(Os_GucShutdownAllCoresSeqCnt[LucIndex] == LucSeqNo)
        {
          LblStepResult = STEP_PASSED;
          Os_GucShutdownAllCoresSeqCnt[LucIndex] = 0;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucShutdownAllCoresCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucShutdownAllCoresStateCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucShutdownAllCoresStateCount == Os_GucShutdownAllCoresCount)
      {
        Os_GucShutdownAllCoresCount = 0;
        Os_GucShutdownAllCoresStateCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  OS_UNUSED(Error);
  return(LblStepResult);
} /* End TestShutdownAllCores() */
#endif // End of #ifdef ECUM_MODULE_ACTIVE

#ifdef PM_MODULE_ACTIVE
uint16 GetISRID (void)
{
  return 0;
}
#endif

#ifndef STBM_MODULE_ACTIVE
/*******************************************************************************
**                       TestOs_DefaultBehavior()                             **
*******************************************************************************/
void TestOs_DefaultBehavior(void)
{
  #ifdef DBG_MODULE_ACTIVE
  Os_GddAlarmID = 0;
  Os_GddStart = 0;
  Os_GddCycle = 0;
  Os_GucSetAbsAlarmCount = 0;
  Os_GucCancelAlarm = 0;
  #endif
  #ifdef ECUM_MODULE_ACTIVE
  Os_GddMode = 0;
  Os_GddStatus = E_OK;
  Os_GddResourceId = 0;
  Os_GddSpinlockId = 0;
  Os_GucStartCount = 0;
  Os_GucStartSeqCnt = 0;
  Os_GucShutdownSeqCnt = 0;
  Os_GucShutdownCount = 0;
  Os_GucGetResourceCount = 0;
  Os_GucReleaseResourceCount = 0;
  Os_GucGetSpinlockCount = 0;
  Os_GucReleaseSpinlockCount = 0;
  Os_GucEnableAllCount = 0;
  Os_GucDisableAllCount = 0;
  Os_GucEnableCheckStateCount = 0;
  Os_GucDisableCheckStateCount = 0;
  Os_GucStartCoreStateCount = 0;
  Os_GucGetCoreIDCount = 0;
  Os_GucGetTaskIDCount = 0;

  for(LucIndex = 0; LucIndex < OS_ARRAY_SIZE; LucIndex++)
  {
    Os_GucGetResourceSeqCnt[LucIndex] = 0;
    Os_GucReleaseResourceSeqCnt[LucIndex] = 0;
    Os_GucGetSpinlockSeqCnt[LucIndex] = 0;
    Os_GucReleaseSpinlockSeqCnt[LucIndex] = 0;
    Os_GaaStartCoreSeqCnt[LucIndex] = 0;
    Os_GaaGetResource[LucIndex] = 0;
    Os_GaaReleaseResource[LucIndex] = 0;
    Os_GaaGetSpinlock[LucIndex] = 0;
    Os_GaaReleaseSpinlock[LucIndex] = 0;
    Os_GucGetCoreIDSeqCnt[LucIndex] = 0;
    Os_GucGetTaskIDSeqCnt[LucIndex] = 0;
    Os_GucShutdownAllCoresSeqCnt[LucIndex] = 0;
    Os_GucEnableAllSeqCnt[LucIndex] = 0;
    Os_GucDisableAllSeqCnt[LucIndex] = 0;
    Os_GucSetEventSeqCnt[LucIndex] = 0;
    Os_GaaSetEventTaskId[LucIndex] = 0;
    Os_GaaSetSlaveEventMask[LucIndex] = 0;
    Os_GucWaitEventSeqCnt[LucIndex] = 0;
    Os_GaaWaitEventMask[LucIndex] = 0;
    Os_GaaGetEventTaskId[LucIndex] = 0;
    Os_GucGetEventSeqCnt[LucIndex] = 0;
    Os_GaaGetEventMask[LucIndex] = 0;
    Os_GaaClearEventTaskId[LucIndex] = 0;
    Os_GucClearEventSeqCnt[LucIndex] = 0;
    Os_GaaClearEventMask[LucIndex] = 0;
  }
  #endif
  #ifdef WDGM_MODULE_ACTIVE
  Os_GddCounterValue = 0;
  Os_GddAdditionalCount= 0;
  #endif
} /* End TestOs_DefaultBehavior() */
#endif /* ifndef STBM_MODULE_ACTIVE */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
