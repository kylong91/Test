/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Mcu.h                                                       	**
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Mcu Stub                                            	**
**                                                                            **
**  PURPOSE   : Declaration of Mcu Stub functions                           	**
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef MCU_H
#define MCU_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Std_Types.h"                  /* Standard type header */
#include "ComStack_Types.h"             /* Com Stack header */
#include "TC_Generic.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define MCU_AR_RELEASE_MAJOR_VERSION    0x04
#define MCU_AR_RELEASE_MINOR_VERSION    0x04
#define MCU_AR_RELEASE_REVISION_VERSION 0x00

#define McuModuleConfiguration0 &Mcu_GaaConfig[0]
#define McuModuleConfiguration1 &Mcu_GaaConfig[1]
#define MCU_ARRAY_SIZE 25
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/* Dummy Structure for Mcu_ConfigType */
typedef struct STag_Mcu_ConfigType
{
  uint8 dummy;
} Mcu_ConfigType;

typedef enum
{
  MCU_POWER_ON_RESET = 0,
  MCU_WATCHDOG_RESET,
  MCU_SW_RESET,
  MCU_RESET_UNDEFINED
} Mcu_ResetType;
typedef uint8 Mcu_ModeType;
extern const Mcu_ConfigType Mcu_GaaConfig[2];
extern uint8 Mcu_GucConfigData;
extern Mcu_ResetType Mcu_GddResetReason;
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void Mcu_Init(const Mcu_ConfigType *ConfigPtr);
extern Mcu_ResetType Mcu_GetResetReason(void);
extern void Mcu_PerformReset(void);
extern void Mcu_SetMode(const Mcu_ModeType McuMode);
extern boolean TestMcu_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, uint8 LucData);
extern boolean TestMcu_GetResetReason(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
extern boolean TestMcu_PerformReset(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
extern boolean TestMcu_SetMode(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, const Mcu_ModeType LddMcuMode);
extern void TestMcu_DefaultBehavior(void);
extern void TestWdgM_McuDefaultBehavior(void);
extern void TestSetMcu_GetResetReason(Mcu_ResetType reason);
extern boolean TestWdgM_McuPerformReset(App_DataValidateType LucDataValidate);
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
