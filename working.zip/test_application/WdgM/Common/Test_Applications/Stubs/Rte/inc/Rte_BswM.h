/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Rte_BswM.h                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Bsw Mode Manager
**                                                                            **
**  PURPOSE   : Declaration of Rte functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef RTE_BSWM_H
#define RTE_BSWM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Rte_BswM_Type.h" 
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Std_ReturnType Rte_Switch_modeSwitchPort0_currentMode(SwitchMode_Type NewMode);

/* Extern declaration for Rte_Switch() API */
extern boolean TestRte_Switch_modeSwitchPort0_currentMode(App_DataValidateType LucDataValidate, 
 SwitchMode_Type LddExpNewMode);
 
 extern Std_ReturnType Rte_Switch_modeSwitchPort1_currentMode(SwitchMode_Type NewMode);

/* Extern declaration for Rte_Switch() API */
extern boolean TestRte_Switch_modeSwitchPort1_currentMode(App_DataValidateType LucDataValidate, 
 SwitchMode_Type LddExpNewMode);
 
extern Std_ReturnType Rte_Switch_modeSwitchPort2_currentMode(SwitchMode_Type NewMode);

/* Extern declaration for Rte_Switch() API */
extern boolean TestRte_Switch_modeSwitchPort2_currentMode(App_DataValidateType LucDataValidate, 
 SwitchMode_Type LddExpNewMode);

extern Std_ReturnType Rte_Switch_modeSwitchPort3_currentMode(SwitchMode_Type NewMode);

/* Extern declaration for Rte_Switch() API */
extern boolean TestRte_Switch_modeSwitchPort3_currentMode(App_DataValidateType LucDataValidate, 
 SwitchMode_Type LddExpNewMode);
 
extern Std_ReturnType Rte_Switch_modeSwitchPort4_currentMode(SwitchMode_Type NewMode);

/* Extern declaration for Rte_Switch() API */
extern boolean TestRte_Switch_modeSwitchPort4_currentMode(App_DataValidateType LucDataValidate, 
 SwitchMode_Type LddExpNewMode);
 
extern Std_ReturnType Rte_Switch_modeSwitchPort5_currentMode(SwitchMode_Type NewMode);

/* Extern declaration for Rte_Switch() API */
extern boolean TestRte_Switch_modeSwitchPort5_currentMode(App_DataValidateType LucDataValidate, 
 SwitchMode_Type LddExpNewMode);
 
extern Std_ReturnType Rte_Switch_modeSwitchPort6_currentMode(SwitchMode_Type NewMode);

/* Extern declaration for Rte_Switch() API */
extern boolean TestRte_Switch_modeSwitchPort6_currentMode(App_DataValidateType LucDataValidate, 
 SwitchMode_Type LddExpNewMode);
 
extern Std_ReturnType Rte_Switch_modeSwitchPort7_currentMode(SwitchMode_Type NewMode);

/* Extern declaration for Rte_Switch() API */
extern boolean TestRte_Switch_modeSwitchPort7_currentMode(App_DataValidateType LucDataValidate, 
 SwitchMode_Type LddExpNewMode);
 
extern Std_ReturnType Rte_Switch_modeSwitchPort8_currentMode(SwitchMode_Type NewMode);

/* Extern declaration for Rte_Switch() API */
extern boolean TestRte_Switch_modeSwitchPort8_currentMode(App_DataValidateType LucDataValidate, 
 SwitchMode_Type LddExpNewMode);
 
extern Std_ReturnType Rte_Switch_modeSwitchPort10_currentMode(SwitchMode_Type NewMode);

/* Extern declaration for Rte_Switch() API */
extern boolean TestRte_Switch_modeSwitchPort10_currentMode(App_DataValidateType LucDataValidate, 
 SwitchMode_Type LddExpNewMode);
 
extern AppModeRequestType Rte_Mode_modeNotificationPort0_currentMode(void);

/* Extern declaration for Rte_Switch() API */
extern boolean TestSetRte_Mode_modeNotificationPort0_currentMode(App_DataValidateType LucDataValidate,
AppModeRequestType LddExpNewMode);
 
extern void AppRte_SetBehavior_Switch(Std_ReturnType LddSetRetVal);

extern void TestRte_SetBehavior(Std_ReturnType Rte_GddPortRetVal);


extern void TestSetRte_Mode_Port1_AppModeRequestType(AppModeRequestType LddRetVal);

extern void TestSetRte_Read_modeRequestPort0_requestedMode(AppModeRequestType LddRetVal);

extern Std_ReturnType Rte_Read_modeRequestPort0_requestedMode(AppModeRequestType *NewMode);

extern boolean TestRte_Read_modeRequestPort0_requestedMode(App_DataValidateType LucDataValidate,
AppModeRequestType LddExpNewMode);

extern Std_ReturnType Rte_RestartPartition_1(void);

extern boolean TestRte_RestartPartition_1(App_DataValidateType LucDataValidate);

#endif /* RTE_BSWM_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
