/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: SchM_CanNm.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR SchM CanNm Stub                                       **
**                                                                            **
**  PURPOSE   : Declaration of SchM CanNm Stub functions                      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef SCHM_CANNM_H
#define SCHM_CANNM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"             /* ComStack type header */

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                      Exclusive Area                                        **
*******************************************************************************/

/*
 * This type define the exclusive areas along with scheduler services are used
 * to provide data integrity for shared resources
 */
extern void SchM_Enter_CanNm_TX_USER_DATA_CHANNEL0(void);
extern void SchM_Enter_CanNm_TX_USER_DATA_CHANNEL1(void);
extern void SchM_Enter_CanNm_RX_USER_DATA_CHANNEL1(void);
extern void SchM_Enter_CanNm_RX_USER_DATA_CHANNEL0(void);
extern void SchM_Enter_CanNm_INTERNAL_STATUS_CHANNEL0(void);
extern void SchM_Enter_CanNm_INTERNAL_STATUS_CHANNEL1(void);
extern void SchM_Exit_CanNm_TX_USER_DATA_CHANNEL0(void);
extern void SchM_Exit_CanNm_TX_USER_DATA_CHANNEL1(void);
extern void SchM_Exit_CanNm_RX_USER_DATA_CHANNEL0(void);
extern void SchM_Exit_CanNm_RX_USER_DATA_CHANNEL1(void);
extern void SchM_Exit_CanNm_INTERNAL_STATUS_CHANNEL0(void);
extern void SchM_Exit_CanNm_INTERNAL_STATUS_CHANNEL1(void);
extern void SchM_Enter_CanNm_TX_USER_DATA(void);
extern void SchM_Enter_CanNm_RX_USER_DATA(void);
extern void SchM_Enter_CanNm_INTERNAL_STATUS(void);
extern void SchM_Exit_CanNm_TX_USER_DATA(void);
extern void SchM_Exit_CanNm_RX_USER_DATA(void);
extern void SchM_Exit_CanNm_INTERNAL_STATUS(void);

#endif /*SCHM_CANNM_H*/

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
