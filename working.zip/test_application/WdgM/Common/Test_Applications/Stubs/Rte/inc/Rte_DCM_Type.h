/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Dcm_Types.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR DCM                                                   **
**                                                                            **
**  PURPOSE   : Provision of Dcm type definitions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef RTE_DCM_TYPES_H
#define RTE_DCM_TYPES_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/* AUTOSAR SPECIFICATION VERSION */
#define DCM_TYPES_AR_RELEASE_MAJOR_VERSION      DCM_AR_RELEASE_MAJOR_VERSION
#define DCM_TYPES_AR_RELEASE_MINOR_VERSION      DCM_AR_RELEASE_MINOR_VERSION
#define DCM_TYPES_AR_RELEASE_REVISION_VERSION   DCM_AR_RELEASE_REVISION_VERSION

/* SOFTWARE VERSION INFORMATION */
#define DCM_TYPES_SW_MAJOR_VERSION       DCM_SW_MAJOR_VERSION
#define DCM_TYPES_SW_MINOR_VERSION       DCM_SW_MINOR_VERSION

/******************************************************************************
**                     Security Level type definition                        **
******************************************************************************/

typedef uint8 Dcm_SecLevelType;



/******************************************************************************
**                     Session type definition                               **
******************************************************************************/

typedef uint8 Dcm_SesCtrlType;



/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/* Protocol type definition */
typedef uint8 Dcm_ProtocolType;



/******************************************************************************
**                         NRC type and NRCs supported                       **
******************************************************************************/
/*
 * The Negative Response Codes represents the allowed Response Codes an AUTOSAR
 * SW Component will return after a function call
 */
typedef uint8 Dcm_NegativeResponseCodeType;



/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#endif /* DCM_TYPES_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
