/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: SchM_FrIf.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FrNm Module                                           **
**                                                                            **
**  PURPOSE   : Declaration of SchM macros                                    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef SCHM_FRIF_H
#define SCHM_FRIF_H

/*******************************************************************************
*                       Include Section                                        *
*******************************************************************************/
#include "ComStack_Types.h"   

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
extern volatile uint8 GucDummy;
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
//extern void SchM_Enter_FrIf(uint8 event);
//extern void SchM_Exit_FrIf(uint8 event);
extern void SchM_Enter_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER0(void);
extern void SchM_Exit_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER0(void);
extern void SchM_Enter_FrIf_TRANSCEIVER_MODE_PROTECTION_CLUSTER0(void);
extern void SchM_Exit_FrIf_TRANSCEIVER_MODE_PROTECTION_CLUSTER0(void);
extern void SchM_Enter_FrIf_TRANSCEIVER_WAKEUP_PROTECTION_CLUSTER0(void);
extern void SchM_Exit_FrIf_TRANSCEIVER_WAKEUP_PROTECTION_CLUSTER0(void);
extern void SchM_Enter_FrIf_TRANSCEIVER_BRANCH_PROTECTION_CLUSTER0(void);
extern void SchM_Exit_FrIf_TRANSCEIVER_BRANCH_PROTECTION_CLUSTER0(void);
extern void SchM_Enter_FrIf_JOBCOUNTER_PROTECTION_CLUSTER0(void);
extern void SchM_Exit_FrIf_JOBCOUNTER_PROTECTION_CLUSTER0(void);
extern void SchM_Enter_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER1(void);
extern void SchM_Exit_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER1(void);
extern void SchM_Enter_FrIf_JOBCOUNTER_PROTECTION_CLUSTER1(void);
extern void SchM_Exit_FrIf_JOBCOUNTER_PROTECTION_CLUSTER1(void);
extern void SchM_Enter_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER2(void);
extern void SchM_Exit_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER2(void);
extern void SchM_Enter_FrIf_JOBCOUNTER_PROTECTION_CLUSTER2(void);
extern void SchM_Exit_FrIf_JOBCOUNTER_PROTECTION_CLUSTER2(void);
extern void SchM_Enter_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER3(void);
extern void SchM_Exit_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER3(void);
extern void SchM_Enter_FrIf_JOBCOUNTER_PROTECTION_CLUSTER3(void);
extern void SchM_Exit_FrIf_JOBCOUNTER_PROTECTION_CLUSTER3(void);
extern void SchM_Enter_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER4(void);
extern void SchM_Exit_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER4(void);
extern void SchM_Enter_FrIf_JOBCOUNTER_PROTECTION_CLUSTER4(void);
extern void SchM_Exit_FrIf_JOBCOUNTER_PROTECTION_CLUSTER4(void);
extern void SchM_Enter_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER5(void);
extern void SchM_Exit_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER5(void);
extern void SchM_Enter_FrIf_JOBCOUNTER_PROTECTION_CLUSTER5(void);
extern void SchM_Exit_FrIf_JOBCOUNTER_PROTECTION_CLUSTER5(void);
 /*For this exclusive area disabling all interrupts by scheduler is recommended
 */
#endif /*SCHM_FRIF_H*/
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
