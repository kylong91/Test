/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: NvM.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PDU Router                                            **
**                                                                            **
**  PURPOSE   : Declaration of Rte functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef RTE_NVM_TYPE_H
#define RTE_NVM_TYPE_H

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/


/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
typedef uint8 NvM_RequestResultType;

#define  NVM_REQ_OK                                   (NvM_RequestResultType)0
#define  NVM_REQ_NOT_OK                               (NvM_RequestResultType)1
#define  NVM_REQ_PENDING                              (NvM_RequestResultType)2
#define  NVM_REQ_INTEGRITY_FAILED                     (NvM_RequestResultType)3
#define  NVM_REQ_BLOCK_SKIPPED                        (NvM_RequestResultType)4
#define  NVM_REQ_NV_INVALIDATED                       (NvM_RequestResultType)5
#define  NVM_REQ_CANCELED                             (NvM_RequestResultType)6  
#define  NVM_REQ_REDUNDANCY_FAILED                    (NvM_RequestResultType)7  
#define  NVM_REQ_RESTORED_FROM_ROM                    (NvM_RequestResultType)8  

/* Type of NVRAM block ID */
typedef uint16 NvM_BlockIdType;

#endif /*RTE_NVM_TYPE_H*/

/*******************************************************************************
**                       End of File                                          **
*******************************************************************************/

