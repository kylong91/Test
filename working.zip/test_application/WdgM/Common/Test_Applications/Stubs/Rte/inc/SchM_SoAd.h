/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: SchM_SoAd.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PDU Router                                            **
**                                                                            **
**  PURPOSE   : Declaration of SchM functions                                 **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef SCHM_SOAD_H
#define SCHM_SOAD_H

extern void SchM_Enter_SOAD_SOCKET_STATE(void);

extern void SchM_Exit_SOAD_SOCKET_STATE(void);

extern void SchM_Enter_SOAD_ROUTING_GROUP_STATE(void);

extern void SchM_Exit_SOAD_ROUTING_GROUP_STATE(void);

extern void SchM_Exit_SOAD_SOCKET_GRP_IP_STATE(void);

extern void SchM_Enter_SOAD_SOCKET_GRP_IP_STATE(void);

#endif
