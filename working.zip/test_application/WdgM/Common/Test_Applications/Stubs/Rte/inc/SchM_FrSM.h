/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: SchM_FrSM.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR SchM FrSM  Stub                                       **
**                                                                            **
**  PURPOSE   : Declaration of SchM FrSM Stub functions                       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef SCHM_FRSM_H
#define SCHM_FRSM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"             /* ComStack type header */
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                      Exclusive Area                                        **
*******************************************************************************/

/*
 * This type define the exclusive areas along with scheduler services are used
 * to provide data integrity for shared resources
 */
extern void SchM_Enter_FrSM_CLUSTER_STATUS_PROTECTION_0(void);
extern void SchM_Enter_FrSM_CLUSTER_STATUS_PROTECTION_1(void);
extern void SchM_Enter_FrSM_CLUSTER_STATUS_PROTECTION_2(void);
extern void SchM_Enter_FrSM_CLUSTER_STATUS_PROTECTION_3(void);
extern void SchM_Exit_FrSM_CLUSTER_STATUS_PROTECTION_0(void);
extern void SchM_Exit_FrSM_CLUSTER_STATUS_PROTECTION_1(void);
extern void SchM_Exit_FrSM_CLUSTER_STATUS_PROTECTION_2(void);
extern void SchM_Exit_FrSM_CLUSTER_STATUS_PROTECTION_3(void);
#endif /*SCHM_FRSM_H*/

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
