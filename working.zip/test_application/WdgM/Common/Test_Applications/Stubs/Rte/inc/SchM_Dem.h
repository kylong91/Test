/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: SchM_BswM.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BSW Mode Manager                                      **
**                                                                            **
**  PURPOSE   : SchM_BswM.h                                                   **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef SCHM_DEM_H
#define SCHM_DEM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void SchM_Enter_Dem_REQUEST_BUFFER_PROTECTION(void);
extern void SchM_Exit_Dem_REQUEST_BUFFER_PROTECTION(void);
extern void SchM_Enter_Dem_REQUEST_STATUS_PROTECTION(void);
extern void SchM_Exit_Dem_REQUEST_STATUS_PROTECTION(void);
extern void SchM_Enter_Dem_REQUEST_RECORD_PROTECTION(void);
extern void SchM_Exit_Dem_REQUEST_RECORD_PROTECTION(void);
extern void SchM_Enter_Dem_REQUEST_NVDATA_PROTECTION(void);
extern void SchM_Exit_Dem_REQUEST_NVDATA_PROTECTION(void);
extern void SchM_Enter_Dem_CAPTURE_OBD_DATA(void);
extern void SchM_Exit_Dem_CAPTURE_OBD_DATA(void);
extern void SchM_Enter_Dem_REQUEST_OCC_PROTECTION(void);
extern void SchM_Exit_Dem_REQUEST_OCC_PROTECTION(void);
extern void SchM_Enter_Dem_REQUEST_OCCTIME_PROTECTION(void);
extern void SchM_Exit_Dem_REQUEST_OCCTIME_PROTECTION(void);
extern void SchM_Enter_Dem_REQUEST_DATA_PROTECTION(void);
extern void SchM_Exit_Dem_REQUEST_DATA_PROTECTION(void);

#endif /* SCHM_BSWM_H */
/*******************************************************************************
                          End of the file
*******************************************************************************/
