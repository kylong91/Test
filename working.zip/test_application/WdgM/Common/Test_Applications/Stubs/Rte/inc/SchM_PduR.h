/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: SchM_PduR.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PDU Router                                            **
**                                                                            **
**  PURPOSE   : Declaration of SchM  functions                                **
**                                                                            **
**  PLATFORM DEPENDANT [Yes/No]: No                                           **
**                                                                            **
**  TO BE CHANGED BY USER [Yes/No]: No                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef SCHM_PDUR__H
#define SCHM_PDUR__H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Std_Types.h"                  /* Standard type header */
#include "ComStack_Types.h"   


/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define SCHM_PDUR_AR_MAJOR_VERSION         4
#define SCHM_PDUR_AR_MINOR_VERSION         0
#define SCHM_PDUR_AR_PATCH_VERSION         2

/* Software Version Information */
#define SCHM_PDUR_SW_MAJOR_VERSION         4
#define SCHM_PDUR_SW_MINOR_VERSION         0


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void SchM_Enter_PduR_TP_TX_PROTECTION_AREA(void);

extern void SchM_Enter_PduR_GROUP_STATUS_PROTECTION_AREA(void);

extern void SchM_Enter_PduR_FIFO_STATUS_PROTECTION_AREA(void);

extern void SchM_Enter_PduR_DATA_BUFFER_PROTECTION_AREA(void);

extern void SchM_Enter_PduR_TP_GATEWAY_PROTECTION_AREA(void);

extern void SchM_Exit_PduR_TP_TX_PROTECTION_AREA(void);

extern void SchM_Exit_PduR_GROUP_STATUS_PROTECTION_AREA(void);

extern void SchM_Exit_PduR_FIFO_STATUS_PROTECTION_AREA(void);

extern void SchM_Exit_PduR_DATA_BUFFER_PROTECTION_AREA(void);

extern void SchM_Exit_PduR_TP_GATEWAY_PROTECTION_AREA(void);

#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
