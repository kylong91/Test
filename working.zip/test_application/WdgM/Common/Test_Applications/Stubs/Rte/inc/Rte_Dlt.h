/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Rte_Dlt.h                                                     **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR RTE                                                   **
**                                                                            **
**  PURPOSE   : Declaration of Rte functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef RTE_DLT_H
#define RTE_DLT_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Compiler.h"                  /* mapping compiler specific keywords */
#include "Platform_Types.h"            /* platform specific type definitions */
#include "Rte_Dlt_Type.h"
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#define DLT_DATA_ARRAY   0x0F
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Std_ReturnType Rte_Call_PSCN000_Dlt_SetLogLevel(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, Dlt_MessageLogLevelType loglevel);

extern Std_ReturnType Rte_Call_PSCN000_Dlt_SetTraceStatus(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, boolean new_trace_status);

extern Std_ReturnType Rte_Call_VCN000_Dlt_SetVerboseMode(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, boolean is_verbose_mode);

extern Std_ReturnType Rte_Call_ICN000_Dlt_InjectCall(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, uint32 service_id, uint32 data_length,
  uint8* data);
extern Std_ReturnType Rte_Call_PSCN001_Dlt_SetLogLevel(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, Dlt_MessageLogLevelType loglevel);

extern Std_ReturnType Rte_Call_PSCN001_Dlt_SetTraceStatus(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, boolean new_trace_status);

extern Std_ReturnType Rte_Call_VCN001_Dlt_SetVerboseMode(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, boolean is_verbose_mode);

extern Std_ReturnType Rte_Call_ICN001_Dlt_InjectCall(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, uint32 service_id, uint32 data_length,
  uint8* data);

extern Std_ReturnType Rte_Call_PSCN002_Dlt_SetLogLevel(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, Dlt_MessageLogLevelType loglevel);

extern Std_ReturnType Rte_Call_PSCN002_Dlt_SetTraceStatus(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, boolean new_trace_status);

extern Std_ReturnType Rte_Call_VCN002_Dlt_SetVerboseMode(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, boolean is_verbose_mode);

extern Std_ReturnType Rte_Call_ICN002_Dlt_InjectCall(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, uint32 service_id, uint32 data_length,
  uint8* data);

extern Std_ReturnType Rte_Call_PSCN003_Dlt_SetLogLevel(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, Dlt_MessageLogLevelType loglevel);

extern Std_ReturnType Rte_Call_PSCN003_Dlt_SetTraceStatus(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, boolean new_trace_status);

extern Std_ReturnType Rte_Call_VCN003_Dlt_SetVerboseMode(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, boolean is_verbose_mode);

extern Std_ReturnType Rte_Call_ICN003_Dlt_InjectCall(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, uint32 service_id, uint32 data_length,
  uint8* data);

extern Std_ReturnType Rte_Call_PSCN004_Dlt_SetLogLevel(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, Dlt_MessageLogLevelType loglevel);

extern Std_ReturnType Rte_Call_PSCN004_Dlt_SetTraceStatus(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, boolean new_trace_status);

extern Std_ReturnType Rte_Call_VCN004_Dlt_SetVerboseMode(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, boolean is_verbose_mode);

extern Std_ReturnType Rte_Call_ICN004_Dlt_InjectCall(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, uint32 service_id, uint32 data_length,
  uint8* data);

extern boolean TestRte_Call_PSCN000_Dlt_SetLogLevel(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  Dlt_MessageLogLevelType Lddloglevel);

extern boolean TestRte_Call_PSCN000_Dlt_SetTraceStatus(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblnew_trace_status);

extern boolean TestRte_Call_VCN000_Dlt_SetVerboseMode(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblis_verbose_mode);

extern boolean TestRte_Call_ICN000_Dlt_InjectCall(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  uint32 Lucservice_id, uint32 Lucdata_length,uint8* data);

extern boolean TestRte_Call_PSCN001_Dlt_SetLogLevel(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  Dlt_MessageLogLevelType Lddloglevel);

extern boolean TestRte_Call_PSCN001_Dlt_SetTraceStatus(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblnew_trace_status);

extern boolean TestRte_Call_VCN001_Dlt_SetVerboseMode(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblis_verbose_mode);

extern boolean TestRte_Call_ICN001_Dlt_InjectCall(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  uint32 Lucservice_id, uint32 Lucdata_length,uint8* Lucdata);

extern boolean TestRte_Call_PSCN002_Dlt_SetLogLevel(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  Dlt_MessageLogLevelType Lddloglevel);

extern boolean TestRte_Call_PSCN002_Dlt_SetTraceStatus(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblnew_trace_status);

extern boolean TestRte_Call_VCN002_Dlt_SetVerboseMode(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblis_verbose_mode);

extern boolean TestRte_Call_ICN002_Dlt_InjectCall(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  uint32 Lucservice_id, uint32 Lucdata_length,uint8* data);

extern boolean TestRte_Call_PSCN003_Dlt_SetLogLevel(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  Dlt_MessageLogLevelType Lddloglevel);

extern boolean TestRte_Call_PSCN003_Dlt_SetTraceStatus(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblnew_trace_status);

extern boolean TestRte_Call_VCN003_Dlt_SetVerboseMode(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblis_verbose_mode);

  extern boolean TestRte_Call_PSCN004_Dlt_SetLogLevel(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  Dlt_MessageLogLevelType Lddloglevel);

extern boolean TestRte_Call_PSCN004_Dlt_SetTraceStatus(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblnew_trace_status);

extern boolean TestRte_Call_VCN004_Dlt_SetVerboseMode(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblis_verbose_mode);

extern boolean TestRte_Call_ICN004_Dlt_InjectCall(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  uint32 Lucservice_id, uint32 Lucdata_length,uint8* data);

extern boolean Dlt_Test_ValidateData(uint8* LpExpData, uint8* LpActData,
  uint32 Lucdatalength);
#endif /* RTE_DLT_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
