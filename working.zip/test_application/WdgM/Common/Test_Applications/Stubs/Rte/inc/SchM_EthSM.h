/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: SchM_CanSM.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR SchM CanSM Stub                                       **
**                                                                            **
**  PURPOSE   : Declaration of SchM CanSM Stub functions                      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef SCHM_ETHSM_H
#define SCHM_ETHSM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Std_Types.h"                  /* Standard type header */
#include "ComStack_Types.h"             /* ComStack type header */

/* AUTOSAR specification version information */
#define SCHM_AR_RELEASE_MAJOR_VERSION     4
#define SCHM_AR_RELEASE_MINOR_VERSION     0
#define SCHM_AR_RELEASE_REVISION_VERSION  3
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                      Exclusive Area                                        **
*******************************************************************************/

/*
 * This type define the exclusive areas along with scheduler services are used
 * to provide data integrity for shared resources
 */
extern void SchM_Enter_ETHSM_MODE_STATUS_PROTECTION(void);
extern void SchM_Exit_ETHSM_MODE_STATUS_PROTECTION(void);

#endif /*SCHM_ETHSM_H*/

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
