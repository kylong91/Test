/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: <>                                                            **
**                                                                            **
**  TARGET    : <All/Microcontroller Name/Device Name>                        **
**                                                                            **
**  PRODUCT   : AUTOSAR <MSN>                                                 **
**                                                                            **
**  PURPOSE   : <Description of the file>                                     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]:                                              **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]:                                           **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef RTE_WDGM_H
#define RTE_WDGM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Compiler.h"                  /* mapping compiler specific keywords */
#include "Platform_Types.h"            /* platform specific type definitions */
#include "Rte_WdgM_Type.h"
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Std_ReturnType Rte_Switch_WdgM_mode_WdgMSupervisedEntity0_currentMode(
  Rte_ModeType_WdgM_Mode NewMode);
extern Std_ReturnType TestRte_Switch_WdgM_mode_WdgMSupervisedEntity0_currentMode(
  App_DataValidateType LucDataValidate, Rte_ModeType_WdgM_Mode ExpNewMode);

extern Std_ReturnType Rte_Switch_WdgM_mode_WdgMSupervisedEntity1_currentMode(
  Rte_ModeType_WdgM_Mode NewMode);
extern Std_ReturnType TestRte_Switch_WdgM_mode_WdgMSupervisedEntity1_currentMode(
  App_DataValidateType LucDataValidate, Rte_ModeType_WdgM_Mode ExpNewMode);

extern Std_ReturnType Rte_Switch_WdgM_mode_WdgMSupervisedEntity2_currentMode(
  Rte_ModeType_WdgM_Mode NewMode);
extern Std_ReturnType TestRte_Switch_WdgM_mode_WdgMSupervisedEntity2_currentMode(
  App_DataValidateType LucDataValidate, Rte_ModeType_WdgM_Mode ExpNewMode);

extern Std_ReturnType Rte_Switch_WdgM_mode_WdgMSupervisedEntity3_currentMode(
  Rte_ModeType_WdgM_Mode NewMode);
extern Std_ReturnType TestRte_Switch_WdgM_mode_WdgMSupervisedEntity3_currentMode(
  App_DataValidateType LucDataValidate, Rte_ModeType_WdgM_Mode ExpNewMode);

extern Std_ReturnType Rte_Switch_WdgM_mode_WdgMSupervisedEntity4_currentMode(
  Rte_ModeType_WdgM_Mode NewMode);
extern Std_ReturnType TestRte_Switch_WdgM_mode_WdgMSupervisedEntity4_currentMode(
  App_DataValidateType LucDataValidate, Rte_ModeType_WdgM_Mode ExpNewMode);

extern Std_ReturnType Rte_Switch_WdgM_mode_WdgMSupervisedEntity5_currentMode(
  Rte_ModeType_WdgM_Mode NewMode);
extern Std_ReturnType TestRte_Switch_WdgM_mode_WdgMSupervisedEntity5_currentMode(
  App_DataValidateType LucDataValidate, Rte_ModeType_WdgM_Mode ExpNewMode);

extern Std_ReturnType Rte_Switch_WdgM_mode_WdgMSupervisedEntity6_currentMode(
  Rte_ModeType_WdgM_Mode NewMode);
extern Std_ReturnType TestRte_Switch_WdgM_mode_WdgMSupervisedEntity6_currentMode(
  App_DataValidateType LucDataValidate, Rte_ModeType_WdgM_Mode ExpNewMode);

extern Std_ReturnType Rte_Switch_WdgM_mode_WdgMSupervisedEntity7_currentMode(
  Rte_ModeType_WdgM_Mode NewMode);
extern Std_ReturnType TestRte_Switch_WdgM_mode_WdgMSupervisedEntity7_currentMode(
  App_DataValidateType LucDataValidate, Rte_ModeType_WdgM_Mode ExpNewMode);  

extern Std_ReturnType Rte_Switch_WdgM_globalMode_currentMode
  (Rte_ModeType_WdgM_Mode NewMode);
extern Std_ReturnType TestRte_Switch_globalMode_currentMode(App_DataValidateType
  LucDataValidate, Rte_ModeType_WdgM_Mode ExpNewMode);

/*******************************************************************************
** API Mapping                                                                **
*******************************************************************************/
#ifndef Rte_Switch_globalMode_currentMode
#define Rte_Switch_globalMode_currentMode Rte_Switch_WdgM_globalMode_currentMode
#endif

#ifndef Rte_Switch_mode_WdgMSupervisedEntity0_currentMode
#define Rte_Switch_mode_WdgMSupervisedEntity0_currentMode Rte_Switch_WdgM_mode_WdgMSupervisedEntity0_currentMode
#endif

#ifndef Rte_Switch_mode_WdgMSupervisedEntity1_currentMode
#define Rte_Switch_mode_WdgMSupervisedEntity1_currentMode Rte_Switch_WdgM_mode_WdgMSupervisedEntity1_currentMode
#endif

#ifndef Rte_Switch_mode_WdgMSupervisedEntity2_currentMode
#define Rte_Switch_mode_WdgMSupervisedEntity2_currentMode Rte_Switch_WdgM_mode_WdgMSupervisedEntity2_currentMode
#endif

#ifndef Rte_Switch_mode_WdgMSupervisedEntity3_currentMode
#define Rte_Switch_mode_WdgMSupervisedEntity3_currentMode Rte_Switch_WdgM_mode_WdgMSupervisedEntity3_currentMode
#endif

#ifndef Rte_Switch_mode_WdgMSupervisedEntity4_currentMode
#define Rte_Switch_mode_WdgMSupervisedEntity4_currentMode Rte_Switch_WdgM_mode_WdgMSupervisedEntity4_currentMode
#endif

#ifndef Rte_Switch_mode_WdgMSupervisedEntity5_currentMode
#define Rte_Switch_mode_WdgMSupervisedEntity5_currentMode Rte_Switch_WdgM_mode_WdgMSupervisedEntity5_currentMode
#endif

#ifndef Rte_Switch_mode_WdgMSupervisedEntity6_currentMode
#define Rte_Switch_mode_WdgMSupervisedEntity6_currentMode Rte_Switch_WdgM_mode_WdgMSupervisedEntity6_currentMode
#endif

#ifndef Rte_Switch_mode_WdgMSupervisedEntity7_currentMode
#define Rte_Switch_mode_WdgMSupervisedEntity7_currentMode Rte_Switch_WdgM_mode_WdgMSupervisedEntity7_currentMode
#endif


#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
