/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Rte_StbM_Type.h                                               **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Synchronized Time Base Manager                        **
**                                                                            **
**  PURPOSE   : Provision of StbM Types used in RTE port interfaces           **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef RTE_STBM_TYPE_H
#define RTE_STBM_TYPE_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
/* Header for RTE types */
#include "Rte_Type.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
/* Time base sync state */
typedef enum ETag_StbM_SyncStatusType
{
  STBM_STATE_SYNC = 0,
  STBM_STATE_NOT_SYNC
} StbM_SyncStatusType;

/* Unique time base identifier */
typedef uint16 StbM_SynchronizedTimeBaseType;

/* Number of time base ticks */
typedef uint16 StbM_TickType;

/* Absolute time since ECU startup */
typedef struct STag_StbM_SystemTimeType
{
  /* Number of time base ticks */
  StbM_TickType ticks;
  /* Duration of one tick in microseconds  */
  uint16 tickDuration;
  /* Number of overflows of time base counter */
  uint32 systemTicks;
} StbM_SystemTimeType;
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#endif /* RTE_STBM_TYPE_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
