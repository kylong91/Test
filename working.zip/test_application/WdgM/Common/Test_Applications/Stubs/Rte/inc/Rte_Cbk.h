/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Com.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Rte                                                   **
**                                                                            **
**  PURPOSE   : Declaration of Rte functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef RTE_CBK_H
#define RTE_CBK_H

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Platform_Types.h"
#include "TC_Generic.h"
#include "ComStack_Types.h"
extern uint8 GucSWCCbkCount;
extern uint8 Com_CallOutCount;
extern uint8 Com_CallOutCount6;
extern uint8 Com_Rx_CallOutCount;
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
typedef boolean (*TestCallBackType[10])(App_DataValidateType LenDataValidate);
extern void TestRte_DefaultBehavior(void);
extern void Rte_COMCbkTxTOut_s4(void);
extern boolean TestRte_COMCbkTxTOut_s4(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTxTOut_s5(void);
extern boolean TestRte_COMCbkTxTOut_s5(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTxTOut_s6(void);
extern boolean TestRte_COMCbkTxTOut_s6(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTxTOut_s7(void);
extern boolean TestRte_COMCbkTxTOut_s7(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTxTOut_s8(void);
extern boolean TestRte_COMCbkTxTOut_s8(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s7(void);
extern boolean TestRte_COMCbkRxTOut_s7(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s8(void);
extern boolean TestRte_COMCbkRxTOut_s8(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s9(void);
extern boolean TestRte_COMCbkRxTOut_s9(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s10(void);
extern boolean TestRte_COMCbkRxTOut_s10(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s11(void);
extern boolean TestRte_COMCbkRxTOut_s11(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s12(void);
extern boolean TestRte_COMCbkRxTOut_s12(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s28(void);
extern boolean TestRte_COMCbkRxTOut_s12(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s13(void);
extern void Rte_COMCbkRxTOut_s29(void);
extern boolean TestRte_COMCbkRxTOut_s12(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s30(void);
extern boolean TestRte_COMCbkRxTOut_s30(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s37(void);
extern void Rte_COMCbkRxTOut_s38(void);
extern void Rte_COMCbkTAck_s3(void);
extern boolean TestRte_COMCbkTAck_s3(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTAck_s4(void);
extern boolean TestRte_COMCbkTAck_s4(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTAck_s5(void);
extern boolean TestRte_COMCbkTAck_s5(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTAck_s6(void);
extern boolean TestRte_COMCbkTAck_s6(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTAck_s9(void);
extern void Rte_COMCbkTAck_s10(void);
extern void Rte_COMCbkTAck_s20(void);
extern void Rte_COMCbkTAck_s21(void);
extern void Rte_COMCbkTAck_s24(void);
extern void Rte_COMCbkTAck_s26(void);
extern void Rte_COMCbkTAck_s28(void);
extern void Rte_COMCbk_s3(void);
extern boolean TestRte_COMCbk_s3(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s5(void);
extern boolean TestRte_COMCbk_s5(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s6(void);
extern void Rte_COMCbk_s7(void);
extern void Rte_COMCbk_s8(void);
extern void Rte_COMCbkInv_s7(void);
extern void Rte_COMCbkInv_s10(void);
extern void Rte_COMCbkInv_s13(void);
extern void Rte_COMCbkInv_s5(void);
extern void Rte_COMCbkInv_s4(void);
extern boolean TestRte_COMCbkInv_s4(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s9(void);
extern boolean TestRte_COMCbk_s9(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_s9(void);
extern boolean TestRte_COMCbkInv_s9(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s10(void);
extern boolean TestRte_COMCbk_s10(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_s14(void);
extern boolean TestRte_COMCbkInv_s14(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s14(void);
extern boolean TestRte_COMCbk_s14(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s15(void);
extern boolean TestRte_COMCbk_s15(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_s15(void);
extern void Rte_COMCbkInv_s16(void);
extern boolean TestRte_COMCbkInv_s16(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s16(void);
extern boolean TestRte_COMCbk_s16(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_s11(void);
extern void Rte_COMCbk_s17(void);
extern void Rte_COMCbkInv_s17(void);
extern void Rte_COMCbk_s18(void);
extern void Rte_COMCbk_s19(void);
extern void Rte_COMCbkInv_s19(void);
extern void Rte_COMCbk_s20(void);
extern void Rte_COMCbkInv_s21(void);
extern void Rte_COMCbkInv_s34(void);
extern void Rte_COMCbkInv_s37(void);
extern void Rte_COMCbk_s23(void);
extern boolean TestRte_COMCbk_s23(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s24(void);
extern boolean TestRte_COMCbk_s24(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s25(void);
extern boolean TestRte_COMCbk_s25(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s26(void);
extern boolean TestRte_COMCbk_s26(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s27(void);
extern boolean TestRte_COMCbk_s27(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s28(void);
extern boolean TestRte_COMCbk_s28(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s29(void);
extern boolean TestRte_COMCbk_s29(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s30(void);
extern boolean TestRte_COMCbk_s30(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s31(void);
extern boolean TestRte_COMCbk_s31(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s32(void);
extern boolean TestRte_COMCbk_s32(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s33(void);
extern boolean TestRte_COMCbk_s33(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s34(void);
extern boolean TestRte_COMCbk_s34(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s35(void);
extern boolean TestRte_COMCbk_s35(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s36(void);
extern boolean TestRte_COMCbk_s36(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s37(void);
extern boolean TestRte_COMCbk_s37(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s38(void);
extern boolean TestRte_COMCbk_s38(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s39(void);
extern boolean TestRte_COMCbk_s39(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s40(void);
extern boolean TestRte_COMCbk_s40(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s41(void);
extern boolean TestRte_COMCbk_s41(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s42(void);
extern boolean TestRte_COMCbk_s42(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s43(void);
extern boolean TestRte_COMCbk_s43(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s44(void);
extern boolean TestRte_COMCbk_s44(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s45(void);
extern boolean TestRte_COMCbk_s45(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s46(void);
extern boolean TestRte_COMCbk_s46(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s47(void);
extern boolean TestRte_COMCbk_s47(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s48(void);
extern boolean TestRte_COMCbk_s48(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s49(void);
extern boolean TestRte_COMCbk_s49(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s50(void);
extern boolean TestRte_COMCbk_s50(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s51(void);
extern boolean TestRte_COMCbk_s51(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s52(void);
extern boolean TestRte_COMCbk_s52(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s53(void);
extern boolean TestRte_COMCbk_s53(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s54(void);
extern boolean TestRte_COMCbk_s54(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s55(void);
extern boolean TestRte_COMCbk_s55(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s56(void);
extern boolean TestRte_COMCbk_s56(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s57(void);
extern boolean TestRte_COMCbk_s57(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s58(void);
extern boolean TestRte_COMCbk_s58(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s59(void);
extern boolean TestRte_COMCbk_s59(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s60(void);
extern boolean TestRte_COMCbk_s60(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s61(void);
extern boolean TestRte_COMCbk_s61(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s62(void);
extern boolean TestRte_COMCbk_s62(App_DataValidateType LenDataValidate);
extern boolean TestRte_COMCbk_s6(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s63(void);
extern void Rte_COMCbkInv_s63(void);
extern void Rte_COMCbk_sg1(void);
extern boolean TestRte_COMCbk_sg1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_sg2(void);
extern boolean TestRte_COMCbk_sg2(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_sg9(void);
extern void Rte_COMCbk_sg10(void);
extern void Rte_COMCbkInv_sg3(void);
extern boolean TestRte_COMCbkInv_sg3(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_sg4(void);
extern boolean TestRte_COMCbkInv_sg4(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_sg5(void);
extern boolean TestRte_COMCbkInv_sg5(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_sg6(void);
extern boolean TestRte_COMCbkInv_sg6(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_sg9(void);
extern void Rte_COMCbkInv_sg10(void);
extern void Rte_COMCbkRxTOut_s1(void);
extern boolean TestRte_COMCbkRxTOut_s1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s2(void);
extern boolean TestRte_COMCbkRxTOut_s2(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s3(void);
extern boolean TestRte_COMCbkRxTOut_s3(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s4(void);
extern boolean TestRte_COMCbkRxTOut_s4(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s5(void);
extern boolean TestRte_COMCbkRxTOut_s5(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s6(void);
extern boolean TestRte_COMCbkRxTOut_s6(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_sg6(void);
extern boolean TestRte_COMCbkRxTOut_sg6(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_sg2(void);
extern boolean TestRte_COMCbkRxTOut_sg2(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_sg3(void);
extern boolean TestRte_COMCbkRxTOut_sg3(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_sg5(void);
extern boolean TestRte_COMCbkRxTOut_sg5(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s34(void);
extern boolean TestRte_COMCbkRxTOut_s34(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s35(void);
extern boolean TestRte_COMCbkRxTOut_s35(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s36(void);
extern boolean TestRte_COMCbkRxTOut_s36(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s28(void);
extern boolean TestRte_COMCbkRxTOut_s28(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s29(void);
extern boolean TestRte_COMCbkRxTOut_s29(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_sg1(void);
extern boolean TestRte_COMCbkRxTOut_sg1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s31(void);
extern boolean TestRte_COMCbkRxTOut_s31(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s32(void);
extern boolean TestRte_COMCbkRxTOut_s32(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s33(void);
extern boolean TestRte_COMCbkRxTOut_s33(App_DataValidateType LenDataValidate);
extern void Rte_ComCbkTErr_s4(void);
extern boolean TestRte_ComCbkTErr_s4(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_s1(void);
extern boolean TestRte_COMCbkInv_s1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_sg1(void);
extern boolean TestRte_COMCbkInv_sg1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTAck_s2(void);
extern boolean TestRte_COMCbkTAck_s2(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTAck_sg1(void);
extern boolean TestRte_COMCbkTAck_sg1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTAck_sg6(void);
extern void Rte_COMCbkTAck_s1(void);
extern boolean TestRte_COMCbkTAck_s1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTAck_sg2(void);
extern boolean TestRte_COMCbkTAck_sg2(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTAck_sg3(void);
extern boolean TestRte_COMCbkTAck_sg3(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTAck_sg4(void);
extern boolean TestRte_COMCbkTAck_sg4(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTAck_sg5(void);
extern boolean TestRte_COMCbkTAck_sg5(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s2(void);
extern boolean TestRte_COMCbk_s2(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s1(void);
extern boolean TestRte_COMCbk_s1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s4(void);
extern boolean TestRte_COMCbk_s4(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTxTOut_s3(void);
extern boolean TestRte_COMCbkTxTOut_s3(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTxTOut_sg2(void);
extern boolean TestRte_COMCbkTxTOut_sg2(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTxTOut_s1(void);
extern boolean TestRte_COMCbkTxTOut_s1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTxTOut_s2(void);
extern boolean TestRte_COMCbkTxTOut_s2(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTxTOut_s9(void);
extern void Rte_COMCbkTxTOut_s20(void);
extern void Rte_COMCbkTxTOut_s21(void);
extern void Rte_COMCbkTxTOut_s25(void);
extern void Rte_COMCbkTxTOut_s26(void);
extern void Rte_COMCbkTxTOut_s27(void);
extern void Rte_COMCbkTxTOut_s28(void);
extern void Rte_COMCbkTxTOut_sg1(void);
extern void Rte_COMCbkTxTOut_sg3(void);
extern void Rte_COMCbkTxTOut_sg6(void);
extern boolean TestRte_COMCbkTxTOut_sg1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s21(void);
extern boolean TestRte_COMCbkRxTOut_s21(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_sg8(void);
extern boolean TestRte_COMCbkRxTOut_sg8(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_sg9(void);
extern void Rte_COMCbkRxTOut_sg10(void);
extern void Rte_COMCbkInv_s2(void);
extern boolean TestRte_COMCbkInv_s2(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_sg2(void);
extern boolean TestRte_COMCbk_s6(App_DataValidateType LenDataValidate);
extern boolean TestRte_COMCbk_s7(App_DataValidateType LenDataValidate);
extern boolean TestRte_COMCbk_s17(App_DataValidateType LenDataValidate);
extern boolean TestRte_COMCbk_s18(App_DataValidateType LenDataValidate);
extern boolean TestRte_COMCbk_s8(App_DataValidateType LenDataValidate);
extern boolean TestRte_COMCbk_s11(App_DataValidateType LenDataValidate);
extern boolean TestRte_COMCbkInv_s7(App_DataValidateType LenDataValidate);
extern boolean TestRte_COMCbkInv_s17(App_DataValidateType LenDataValidate);
extern boolean TestRte_COMCbkInv_s18(App_DataValidateType LenDataValidate);
extern boolean TestRte_COMCbkInv_s21(App_DataValidateType LenDataValidate);
extern boolean TestRte_COMCbkInv_s11(App_DataValidateType LenDataValidate);
extern void CounterErrorNotification_Rx_1(PduIdType ComPduId,
  uint8 ExpectedCounter, uint8 ReceivedCounter);

extern boolean TestCounterErrorNotification_Rx_1(App_DataValidateType LddLabel,
  PduIdType LddComPduId, uint8 LucExpCount, uint8 LucExpRecCount);
extern void App_Com_CbkCounterErr_RxIpdu_4(PduIdType ComPduId,
  uint8 ExpectedCounter, uint8 ReceivedCounter);
extern boolean TestApp_Com_CbkCounterErr_RxIpdu_4(App_DataValidateType LddLabel,
  PduIdType LddComPduId, uint8 LucExpCount, uint8 LucExpRecCount);
  
extern void CounterErrorNotification_Rx_8(PduIdType ComPduId,
  uint8 ExpectedCounter, uint8 ReceivedCounter);
extern boolean TestCounterErrorNotification_Rx_8(App_DataValidateType LddLabel,
  PduIdType LddComPduId, uint8 LucExpCount, uint8 LucExpRecCount);
extern void ComIpduCallout_Tx_SetVal(boolean RetVal);
extern boolean ComIPduCallout_Tx_1(PduIdType Id, uint8* IpduData);

extern boolean TestComIPduCallout_Tx_1(App_DataValidateType LddLabel,
  PduIdType LddComPduId, uint8* ExpPduInfo);
  
extern void ComIpduCallout_Rx_SetVal(boolean RetVal);
extern boolean ComIpduCallout_Rx_1(PduIdType Id, const uint8* IpduData);

extern boolean TestComIpduCallout_Rx_1(App_DataValidateType LddLabel,
  PduIdType LddComPduId, const uint8* ExpPduInfo);
  
extern boolean ComIPduCallout_Rx_2(PduIdType Id, const uint8* IpduData);
extern boolean ComIPduCallout_Rx_3(PduIdType Id, const uint8* IpduData);
extern boolean ComIPduCallout_Rx_4(PduIdType Id, const uint8* IpduData);
extern boolean ComIPduCallout_Rx_5(PduIdType Id, const uint8* IpduData);
extern boolean ComIPduCallout_Rx_6(PduIdType Id, const uint8* IpduData);
extern boolean ComIPduCallout_Rx_7(PduIdType Id, const uint8* IpduData);
extern boolean ComIPduCallout_Rx_8(PduIdType Id, const uint8* IpduData);
  extern boolean ComIPduCallout_Tx_2(PduIdType Id, uint8* IpduData);

extern boolean TestComIPduCallout_Tx_2(App_DataValidateType LddLabel,
  PduIdType LddComPduId, uint8* ExpPduInfo);

extern boolean ComIpduCallout_Tx_3(PduIdType Id, uint8* IpduData);

extern boolean TestComIpduCallout_Tx_3(App_DataValidateType LddLabel,
  PduIdType LddComPduId, uint8* ExpPduInfo);
  
extern boolean Com_Callout_ComIPdu_Tx_6(PduIdType Id, uint8* IpduData);

extern boolean TestCom_Callout_ComIPdu_Tx_6(App_DataValidateType LddLabel,
  PduIdType LddComPduId, uint8* ExpPduInfo);
extern boolean Com_Callout_ComIPdu_Tx_1(PduIdType Id, uint8* IpduData);
extern boolean Com_Callout_ComIPdu_Tx_2(PduIdType Id, uint8* IpduData);
extern boolean Com_Callout_ComIPdu_Tx_3(PduIdType Id, uint8* IpduData);
extern boolean Com_Callout_ComIPdu_Tx_4(PduIdType Id, uint8* IpduData);
extern boolean Com_Callout_ComIPdu_Tx_5(PduIdType Id, uint8* IpduData);
extern boolean Com_Callout_ComIPdu_Tx_7(PduIdType Id, uint8* IpduData);
extern boolean Com_Callout_ComIPdu_Tx_8(PduIdType Id, uint8* IpduData);
extern boolean Com_Callout_ComIPdu_Tx_9(PduIdType Id, uint8* IpduData);
#endif /*RTE_CBK_H*/

/*******************************************************************************
**                       End of File                                          **
*******************************************************************************/
