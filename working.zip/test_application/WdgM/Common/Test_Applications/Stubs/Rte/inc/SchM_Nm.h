/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: SchM.h                                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Nm Module                                             **
**                                                                            **
**  PURPOSE   : Provision of SchM functions                                   **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef SCHM_NM_H
#define SCHM_NM_H

/*******************************************************************************
* I N C L U D E S                                                              *
*******************************************************************************/
#include "ComStack_Types.h"
/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/
/*******************************************************************************
**                      Function Prototype                                    **
*******************************************************************************/

extern void SchM_Exit_Nm_UPDATE_NETWORK_STATUS_NW0(void); 
  
extern void SchM_Exit_Nm_UPDATE_NETWORK_STATUS_NW1(void); 

extern void SchM_Exit_Nm_UPDATE_NETWORK_STATUS_NW2(void); 

extern void SchM_Exit_Nm_UPDATE_NETWORK_STATUS_NW3(void); 
extern void SchM_Exit_Nm_UPDATE_NETWORK_STATUS_NW4(void); 
extern void SchM_Exit_Nm_UPDATE_NETWORK_STATUS_NW5(void); 
extern void SchM_Exit_Nm_UPDATE_NETWORK_STATUS_NW8(void); 

extern void SchM_Exit_Nm_UPDATE_NETWORK_STATUS_NW11(void); 

extern void SchM_Enter_Nm_UPDATE_NETWORK_STATUS_NW0(void); 
  
extern void SchM_Enter_Nm_UPDATE_NETWORK_STATUS_NW1(void); 

extern void SchM_Enter_Nm_UPDATE_NETWORK_STATUS_NW2(void); 

extern void SchM_Enter_Nm_UPDATE_NETWORK_STATUS_NW3(void); 
extern void SchM_Enter_Nm_UPDATE_NETWORK_STATUS_NW4(void); 
extern void SchM_Enter_Nm_UPDATE_NETWORK_STATUS_NW5(void); 
extern void SchM_Enter_Nm_UPDATE_NETWORK_STATUS_NW8(void); 
extern void SchM_Enter_Nm_UPDATE_NETWORK_STATUS_NW11(void); 

#endif
/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
