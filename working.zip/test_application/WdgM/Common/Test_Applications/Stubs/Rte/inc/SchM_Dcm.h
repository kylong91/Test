/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: SchM_Dcm.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Dcm Router                                            **
**                                                                            **
**  PURPOSE   : Declaration of SchM  functions                                **
**                                                                            **
**  PLATFORM DEPENDANT [Yes/No]: No                                           **
**                                                                            **
**  TO BE CHANGED BY USER [Yes/No]: No                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef SCHM_DCM_H
#define SCHM_DCM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Std_Types.h"                  /* Standard type header */
#include "TC_Generic.h"
#include "Dcm_Types.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define SCHM_AR_RELEASE_MAJOR_VERSION         4
#define SCHM_AR_RELEASE_MINOR_VERSION         0
#define SCHM_AR_RELEASE_PATCH_VERSION         2

/* Software Version Information */
#define SCHM_SW_MAJOR_VERSION         4
#define SCHM_SW_MINOR_VERSION         0


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/


/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void SchM_Enter_Dcm_RxPduIdProtection(void);

extern void SchM_Exit_Dcm_RxPduIdProtection(void);

extern void SchM_Enter_Dcm_ProtclProtection(void);

extern void SchM_Exit_Dcm_ProtclProtection(void);

extern void SchM_Enter_Dcm_RxLengthProtection(void);

extern void SchM_Exit_Dcm_RxLengthProtection(void);
extern void SchM_Switch_Dcm_DcmDiagnosticSessionControl(Dcm_SesCtrlType sessiontype);
extern void SchM_Switch_Dcm_DcmEcuReset(uint8 EcuRestMode);

extern boolean TestSchM_Switch_Dcm_DcmEcuReset(
  App_DataValidateType LddDataValidate, uint8 LucExpRestMode);

extern boolean TestSchM_Switch_Dcm_DcmDiagnosticSessionControl(
  App_DataValidateType LddDataValidate, uint8 LucExpRestMode);

extern boolean TestSchM_Switch_Dcm_DcmDiagnosticSessionControl(
  App_DataValidateType LddDataValidate, Dcm_SesCtrlType Ldd_Expsessiontype);

extern void SchM_Switch_Dcm_DcmCommunicationcontrol
  (Dcm_CommunicationModeType CommunicationType, uint8 ControlType);

extern void SchM_Switch_Dcm_DcmControlDTCSetting(uint8 DTCSetting);

extern boolean TestSchM_Switch_Dcm_DcmControlDTCSetting(App_DataValidateType LddDataValidate,
  uint8 LucExpDTCSetting);
extern boolean TestSchM_Switch_Dcm_DcmCommunicationControl(App_DataValidateType LucDataValidate,
Dcm_CommunicationModeType LddExpCommunicationType, uint8 LddExpControlType);

extern void TestSchM_DefaultBehavior(void);
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
