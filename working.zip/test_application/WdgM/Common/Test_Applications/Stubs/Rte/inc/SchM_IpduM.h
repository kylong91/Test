/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: SchM_PduR.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PDU Router                                            **
**                                                                            **
**  PURPOSE   : Declaration of SchM  functions                                **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef SCHM_IPDUM_H
#define SCHM_IPDUM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Std_Types.h"                  /* Standard type header */
#include "ComStack_Types.h"   

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define IPDUM_RTE_AR_RELEASE_MAJOR_VERSION         4
#define IPDUM_RTE_AR_RELEASE_MINOR_VERSION         0
#define IPDUM_RTE_AR_RELEASE_REVISION_VERSION      2

/* Software Version Information */
#define SCHM_IPDUM_SW_MAJOR_VERSION         4
#define SCHM_IPDUM_SW_MINOR_VERSION         0


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Protection Memory Area                                **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void SchM_Enter_IpduM_DEST_DATA_PROTECTION_AREA(void);
extern void SchM_Enter_IpduM_TX_STATUS_PROTECTION_AREA(void);
extern void SchM_Exit_IpduM_DEST_DATA_PROTECTION_AREA(void);
extern void SchM_Exit_IpduM_TX_STATUS_PROTECTION_AREA(void);
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
