/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Rte_ComM.h                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Communication Manager                                 **
**                                                                            **
**  PURPOSE   : Declaration of Rte functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef RTE_ComM_H
#define RTE_ComM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Compiler.h"                  /* mapping compiler specific keywords */
#include "Platform_Types.h"            /* platform specific type definitions */ 
#include "ComM.h"
#include "Rte_ComM_Type.h"
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define RTE_AR_RELEASE_MAJOR_VERSION  4
#define RTE_AR_RELEASE_MINOR_VERSION  0
#define RTE_AR_RELEASE_REVISION_VERSION  3

/* Software Version Information */
#define RTE_SW_MAJOR_VERSION  0
#define RTE_SW_MINOR_VERSION  0

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
extern const struct Rte_CDS_ComMUser Rte_Inst_ComMUser;
extern const struct Rte_CDS_ComMChnl Rte_Inst_ComMChannel;
extern uint8 Rte_GucComModeIndicationCount;
extern ComM_ModeType Rte_GddMode;
extern uint8 Rte_GucWriteCount;
extern uint8 Rte_Gddnoofreq[10];
extern ComM_UserHandleType Rte_Gdduserid[10];
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#define Rte_Ports_ComM_CurrentMode_P() &(Rte_Inst_ComMUser.UM000)
#define Rte_Ports_ComM_CurrentChannelRequest_P() &(Rte_Inst_ComMChannel.CR000)

typedef struct Rte_PDS_ComM_ComM_CurrentMode_P *Rte_PortHandle_ComM_CurrentMode_P;
typedef struct Rte_PDS_ComM_ComM_CurrentChannelRequest_P *Rte_PortHandle_ComM_CurrentChannelRequest_P;

Std_ReturnType Rte_Switch_ComM_UM000_currentMode(IN Rte_ModeType_ComMMode NewMode);
Std_ReturnType Rte_Switch_ComM_UM001_currentMode(IN Rte_ModeType_ComMMode NewMode);
Std_ReturnType Rte_Switch_ComM_UM002_currentMode(IN Rte_ModeType_ComMMode NewMode);
Std_ReturnType Rte_Switch_ComM_UM003_currentMode(IN Rte_ModeType_ComMMode NewMode);
Std_ReturnType Rte_Switch_ComM_UM004_currentMode(IN Rte_ModeType_ComMMode NewMode);
Std_ReturnType Rte_Switch_ComM_UM005_currentMode(IN Rte_ModeType_ComMMode NewMode);
Std_ReturnType Rte_Switch_ComM_UM006_currentMode(IN Rte_ModeType_ComMMode NewMode);
Std_ReturnType Rte_Switch_ComM_UM007_currentMode(IN Rte_ModeType_ComMMode NewMode);
Std_ReturnType Rte_Switch_ComM_UM008_currentMode(IN Rte_ModeType_ComMMode NewMode);
Std_ReturnType Rte_Switch_ComM_UM009_currentMode(IN Rte_ModeType_ComMMode NewMode);

Std_ReturnType Rte_Write_ComM_CR000_fullComRequestors(IN ComM_UserHandleArrayType *data);
Std_ReturnType Rte_Write_ComM_CR001_fullComRequestors(IN ComM_UserHandleArrayType *data);
Std_ReturnType Rte_Write_ComM_CR002_fullComRequestors(IN ComM_UserHandleArrayType *data);
Std_ReturnType Rte_Write_ComM_CR003_fullComRequestors(IN ComM_UserHandleArrayType *data);
Std_ReturnType Rte_Write_ComM_CR004_fullComRequestors(IN ComM_UserHandleArrayType *data);
Std_ReturnType Rte_Write_ComM_CR005_fullComRequestors(IN ComM_UserHandleArrayType *data);
Std_ReturnType Rte_Write_ComM_CR006_fullComRequestors(IN ComM_UserHandleArrayType *data);
Std_ReturnType Rte_Write_ComM_CR007_fullComRequestors(IN ComM_UserHandleArrayType *data);
Std_ReturnType Rte_Write_ComM_CR008_fullComRequestors(IN ComM_UserHandleArrayType *data);
Std_ReturnType Rte_Write_ComM_CR009_fullComRequestors(IN ComM_UserHandleArrayType *data);

Std_ReturnType TestRte_Switch_ComM_UM000_currentMode(App_DataValidateType LucDataValidate,
IN Rte_ModeType_ComMMode ExpNewMode);
Std_ReturnType TestRte_Switch_ComM_UM001_currentMode(App_DataValidateType LucDataValidate,
IN Rte_ModeType_ComMMode ExpNewMode);
Std_ReturnType TestRte_Switch_ComM_UM002_currentMode(App_DataValidateType LucDataValidate,
IN Rte_ModeType_ComMMode ExpNewMode);
Std_ReturnType TestRte_Switch_ComM_UM003_currentMode(App_DataValidateType LucDataValidate,
IN Rte_ModeType_ComMMode ExpNewMode);
Std_ReturnType TestRte_Switch_ComM_UM004_currentMode(App_DataValidateType LucDataValidate,
IN Rte_ModeType_ComMMode ExpNewMode);
Std_ReturnType TestRte_Switch_ComM_UM005_currentMode(App_DataValidateType LucDataValidate,
IN Rte_ModeType_ComMMode ExpNewMode);
Std_ReturnType TestRte_Switch_ComM_UM006_currentMode(App_DataValidateType LucDataValidate,
IN Rte_ModeType_ComMMode ExpNewMode);
Std_ReturnType TestRte_Switch_ComM_UM007_currentMode(App_DataValidateType LucDataValidate,
IN Rte_ModeType_ComMMode ExpNewMode);
Std_ReturnType TestRte_Switch_ComM_UM008_currentMode(App_DataValidateType LucDataValidate,
IN Rte_ModeType_ComMMode ExpNewMode);
Std_ReturnType TestRte_Switch_ComM_UM009_currentMode(App_DataValidateType LucDataValidate,
IN Rte_ModeType_ComMMode ExpNewMode);

Std_ReturnType TestRte_Write_ComM_CR000_fullComRequestors(App_DataValidateType LucDataValidate,
IN ComM_UserHandleArrayType *Expdata);
Std_ReturnType TestRte_Write_ComM_CR001_fullComRequestors(App_DataValidateType LucDataValidate,
IN ComM_UserHandleArrayType *Expdata);
Std_ReturnType TestRte_Write_ComM_CR002_fullComRequestors(App_DataValidateType LucDataValidate,
IN ComM_UserHandleArrayType *Expdata);
Std_ReturnType TestRte_Write_ComM_CR003_fullComRequestors(App_DataValidateType LucDataValidate,
IN ComM_UserHandleArrayType *Expdata);
Std_ReturnType TestRte_Write_ComM_CR004_fullComRequestors(App_DataValidateType LucDataValidate,
IN ComM_UserHandleArrayType *Expdata);
Std_ReturnType TestRte_Write_ComM_CR005_fullComRequestors(App_DataValidateType LucDataValidate,
IN ComM_UserHandleArrayType *Expdata);
Std_ReturnType TestRte_Write_ComM_CR006_fullComRequestors(App_DataValidateType LucDataValidate,
IN ComM_UserHandleArrayType *Expdata);
Std_ReturnType TestRte_Write_ComM_CR007_fullComRequestors(App_DataValidateType LucDataValidate,
IN ComM_UserHandleArrayType *Expdata);
Std_ReturnType TestRte_Write_ComM_CR008_fullComRequestors(App_DataValidateType LucDataValidate,
IN ComM_UserHandleArrayType *Expdata);
Std_ReturnType TestRte_Write_ComM_CR009_fullComRequestors(App_DataValidateType LucDataValidate,
IN ComM_UserHandleArrayType *Expdata);
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
