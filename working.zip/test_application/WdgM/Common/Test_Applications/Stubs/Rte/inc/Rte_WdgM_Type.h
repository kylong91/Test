/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: <>                                                            **
**                                                                            **
**  TARGET    : <All/Microcontroller Name/Device Name>                        **
**                                                                            **
**  PRODUCT   : AUTOSAR <MSN>                                                 **
**                                                                            **
**  PURPOSE   : <Description of the file>                                     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]:                                              **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]:                                           **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef RTE_WDGM_TYPES_H
#define RTE_WDGM_TYPES_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Rte_Type.h"                    /* Standard AUTOSAR types */
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

typedef uint8 Rte_ModeType_WdgM_Mode;

#ifndef RTE_MODE_WdgMMode_SUPERVISION_DEACTIVATED
#define RTE_MODE_WdgMMode_SUPERVISION_DEACTIVATED ((Rte_ModeType_WdgM_Mode)4)
#endif

#ifndef RTE_MODE_WdgMMode_SUPERVISION_EXPIRED
#define RTE_MODE_WdgMMode_SUPERVISION_EXPIRED ((Rte_ModeType_WdgM_Mode)2)
#endif

#ifndef RTE_MODE_WdgMMode_SUPERVISION_FAILED
#define RTE_MODE_WdgMMode_SUPERVISION_FAILED ((Rte_ModeType_WdgM_Mode)1)
#endif

#ifndef RTE_MODE_WdgMMode_SUPERVISION_OK
#define RTE_MODE_WdgMMode_SUPERVISION_OK ((Rte_ModeType_WdgM_Mode)0)
#endif

#ifndef RTE_MODE_WdgMMode_SUPERVISION_STOPPED
#define RTE_MODE_WdgMMode_SUPERVISION_STOPPED ((Rte_ModeType_WdgM_Mode)3)
#endif

/*******************************************************************************
** Type Definitions for Enumeration constants                                 **
*******************************************************************************/

#ifndef WDGM_LOCAL_STATUS_DEACTIVATED
#define WDGM_LOCAL_STATUS_DEACTIVATED 4U
#endif /*WDGM_LOCAL_STATUS_DEACTIVATED*/

#ifndef WDGM_LOCAL_STATUS_OK
#define WDGM_LOCAL_STATUS_OK 0U
#endif /*WDGM_LOCAL_STATUS_OK*/

#ifndef WDGM_LOCAL_STATUS_EXPIRED
#define WDGM_LOCAL_STATUS_EXPIRED 2U
#endif /*WDGM_LOCAL_STATUS_EXPIRED*/

#ifndef WDGM_LOCAL_STATUS_FAILED
#define WDGM_LOCAL_STATUS_FAILED 1U
#endif /*WDGM_LOCAL_STATUS_FAILED*/

#ifndef WDGM_GLOBAL_STATUS_STOPPED
#define WDGM_GLOBAL_STATUS_STOPPED 3U
#endif /*WDGM_GLOBAL_STATUS_STOPPED*/

#ifndef WDGM_GLOBAL_STATUS_OK
#define WDGM_GLOBAL_STATUS_OK 0U
#endif /*WDGM_GLOBAL_STATUS_OK*/

#ifndef WDGM_GLOBAL_STATUS_EXPIRED
#define WDGM_GLOBAL_STATUS_EXPIRED 2U
#endif /*WDGM_GLOBAL_STATUS_EXPIRED*/

#ifndef WDGM_GLOBAL_STATUS_FAILED
#define WDGM_GLOBAL_STATUS_FAILED 1U
#endif /*WDGM_GLOBAL_STATUS_FAILED*/

#ifndef WDGM_GLOBAL_STATUS_DEACTIVATED
#define WDGM_GLOBAL_STATUS_DEACTIVATED 4U
#endif /*WDGM_GLOBAL_STATUS_DEACTIVATED*/


/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
