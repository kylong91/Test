/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Rte_BswM.h                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Bsw Mode Manager
**                                                                            **
**  PURPOSE   : Declaration of Rte functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef RTE_DEM_H
#define RTE_DEM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Rte_Dem_Type.h" 
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/******************************************************************************
*                       Macros
******************************************************************************/


/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/


/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
/* Dem_SetEventStatus */
extern Std_ReturnType Dem_SetEventStatus (Dem_EventIdType EventId,
	Dem_EventStatusType EventStatus);

extern Std_ReturnType Dem_ResetEventStatus(Dem_EventIdType EventId);

extern Std_ReturnType Dem_PrestoreFreezeFrame(Dem_EventIdType EventId);

extern Std_ReturnType Dem_ClearPrestoredFreezeFrame(Dem_EventIdType EventId);

extern Std_ReturnType Dem_SetOperationCycleState(uint8 OperationCycleId, 
	Dem_OperationCycleStateType CycleState);

extern Std_ReturnType Dem_SetOperationCycleCntValue(uint8 OperationCycleId, 
	uint8 CounterValue);
	
extern Std_ReturnType Dem_SetAgingCycleState(uint8 AgingCycleId);

extern Std_ReturnType Dem_SetAgingCycleCounterValue(uint8 CounterValue);

extern Std_ReturnType Dem_GetFaultDetectionCounter(Dem_EventIdType EventId, 
	sint8* FaultDetectionCounter);

  extern Std_ReturnType RTE_DemTriggerOnDTCStatus(uint32 DTC, uint8 DTCStatusOld, 
                                               uint8 DTCStatusNew);
extern Std_ReturnType Test_RTE_DemTriggerOnDTCStatus(App_DataValidateType
  LucDataValidate,
  uint32 DTC,uint8  ExpDTCStatusOld, 
  uint8 ExpDTCStatusNew);

extern Std_ReturnType No_Data_Available(uint8* LpData);

extern Std_ReturnType ReadAmbienttempWrong(uint8* LpData);
extern Std_ReturnType ReadAmbienttemp(uint8* LpData);
extern boolean TestReadAmbienttemp(App_DataValidateType LddDataValidate,
uint8 *LpExpData);
extern Std_ReturnType Rte_CallbackDemGetFaultDetectionCounter
  (sint8* LpEventIdFaultdetectionCounter);
extern Std_ReturnType DemInitMonitorForSWC(uint8 LucInitMonitorReason);

extern Std_ReturnType a_csensor(uint8* LpData);

extern Std_ReturnType Noxsensor(uint8* LpData);
extern Std_ReturnType EvaporativeSensor(uint8* LpData);
extern Std_ReturnType oxygensensor(uint8* LpData);
extern Std_ReturnType Test_DemInitMonitorForSWC(
uint8 *LpInitMonitorReason);

extern void SWC_DemTriggerOnEventData( Dem_EventIdType EventId );

extern Std_ReturnType Test_SWC_DemTriggerOnEventData(App_DataValidateType
  LucDataValidate,Dem_EventIdType ExpEventId);

extern Std_ReturnType Test_SWC_DemTriggerOnEventStatus_Event(
  App_DataValidateType LucDataValidate,
 Dem_EventIdType ExpEventId,Dem_EventStatusExtendedType ExpEventStatusOld, 
  Dem_EventStatusExtendedType ExpEventStatusNew);

extern void SWC_DemTriggerOnEventStatus_Event(Dem_EventIdType EventId, 
  Dem_EventStatusExtendedType EventStatusOld, 
  Dem_EventStatusExtendedType EventStatusNew);
  
extern Std_ReturnType ReadGlobalEngineRPMFnc(uint8* LpData);

extern boolean TestReadGlobalEngineRPMFnc(App_DataValidateType LddDataValidate,
  uint8 *LpExpData);

extern Std_ReturnType ReadEngineCoolantTemperatureFnc(uint8* LpData);

extern boolean TestReadEngineCoolantTemperatureFnc(App_DataValidateType 
  LddDataValidate, uint8 *LpExpData);

extern Std_ReturnType ReadVehicleSpeedFnc(uint8* LpData);

extern boolean TestReadVehicleSpeedFnc(App_DataValidateType LddDataValidate,
  uint8 *LpExpData);

extern Std_ReturnType ReadFuelPressureFnc(uint8* LpData);

extern boolean TestReadFuelPressureFnc(App_DataValidateType LddDataValidate, 
  uint8 *LpExpData);

extern Std_ReturnType ReadIntakeAirTemperatureFnc(uint8* LpData);

extern boolean TestReadIntakeAirTemperatureFnc(App_DataValidateType 
  LddDataValidate, uint8 *LpExpData);
  
// -----------------------------------------------------
extern Std_ReturnType ReadDD00Fnc(uint8* LpData);

extern boolean TestReadDD00Fnc(App_DataValidateType LddDataValidate);

extern Std_ReturnType ReadDD01Fnc(uint8* LpData);

extern boolean TestReadDD01Fnc(App_DataValidateType LddDataValidate);

extern Std_ReturnType ReadDD02Fnc(uint8* LpData);

extern boolean TestReadDD02Fnc(App_DataValidateType LddDataValidate);

extern Std_ReturnType ReadDD0AFnc(uint8* LpData);

extern boolean TestReadDD0AFnc(App_DataValidateType LddDataValidate);

extern Std_ReturnType ReadTS20Fnc(uint8* LpData);

extern boolean TestReadTS20Fnc(App_DataValidateType LddDataValidate,
  uint8 *LpExpData);

extern Std_ReturnType ReadTS21Fnc(uint8* LpData);

extern boolean TestReadTS21Fnc(App_DataValidateType LddDataValidate,
  uint8 *LpExpData);

extern void UpdateReadUsageModeFnc(uint16 LucIndex);

extern void UpdateReadDD00Fnc(uint32 LucIndex);

extern void UpdateReadDD01Fnc(uint8 LucIndex1, uint8 LucIndex2, 
  uint8 LucIndex3);

extern void UpdateReadDD02Fnc(uint8 LucIndex);

extern void UpdateReadDD0AFnc(uint8 LucIndex);

extern Std_ReturnType Rte_CallbackDemGetFaultDetectionCounter03(sint8* 
  LpEventIdFaultdetectionCounter);
extern Std_ReturnType Test_Rte_CallbackDemGetFaultDetectionCounter03(sint8* 
  LpEventIdFaultdetectionCounter);
  
extern Std_ReturnType Test_Rte_CallbackDemGetFaultDetectionCounter   
  (sint8* LpEventIdFaultdetectionCounter);

extern Std_ReturnType Dem_CallbackInitMForE_3(Dem_InitMonitorReasonType
  LpInitMonitorReason);

extern Std_ReturnType Dem_CallbackInitMForE_4(uint8 LpInitMonitorReason);

extern Std_ReturnType Test_Dem_CallbackInitMForE_3(Dem_InitMonitorReasonType *LpInitMonitorReason);
extern Std_ReturnType Dem_CallbackInitMForE_14(Dem_InitMonitorReasonType
  LucInitMonitorReason);
  
extern Std_ReturnType Test_Dem_CallbackInitMForE_4(uint8 *LpInitMonitorReason);

extern Std_ReturnType DemCallbackClearEventAllowed_1(boolean* Allowed);

extern Std_ReturnType Test_DemCallbackClearEventAllowed_1(boolean* Allowed);

extern Std_ReturnType Test_DemCallbackClearEventAllowed_2(boolean* Allowed);

extern Std_ReturnType DemCallbackClearEventAllowed_2(boolean* Allowed);

extern Std_ReturnType Test_DemCallbackClearEventAllowed_3(boolean* Allowed);

extern Std_ReturnType DemCallbackClearEventAllowed_3(boolean* Allowed);

extern Std_ReturnType SWC_DemTriggerOnEventStatus_Event1
  (uint8 EventId, uint8 EventStatusOld, uint8 EventStatusNew);

extern Std_ReturnType Test_Callback_DemTriggerOnDTCStatus1
  (uint32 DTC, uint8 DTCStatusOld, uint8 DTCStatusNew);

extern Std_ReturnType Callback_DemTriggerOnDTCStatus1
  (uint32 DTC, uint8 DTCStatusOld, uint8 DTCStatusNew);

extern Std_ReturnType Test_Callback_DemTriggerOnDTCStatus2
  (uint32 DTC, uint8 DTCStatusOld, uint8 DTCStatusNew);
                                         
extern Std_ReturnType Callback_DemTriggerOnDTCStatus2
  (uint32 DTC, uint8 DTCStatusOld, uint8 DTCStatusNew);

extern void Callback_DemEventDataChandeg_1(uint8  EventId);

extern Std_ReturnType Test_Callback_DemEventDataChandeg_1(uint8  EventId);

#endif /* RTE_DEM_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
