/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: NvM.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR NvM                                                   **
**                                                                            **
**  PURPOSE   : Declaration of Rte functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef RTE_NVM_H
#define RTE_NVM_H

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#define RTE_ARRAY_SIZE 50
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Rte_NvM_Type.h"
#include "TC_Generic.h"


extern Std_ReturnType SINGLE_BLOCK_CBK_2(uint8 ServiceId, NvM_RequestResultType 
  JobResult);
extern Std_ReturnType SINGLE_BLOCK_CBK_3(uint8 ServiceId, NvM_RequestResultType 
  JobResult);
extern Std_ReturnType SINGLE_BLOCK_CBK_4(uint8 ServiceId, NvM_RequestResultType 
  JobResult);
extern Std_ReturnType SINGLE_BLOCK_CBK_5(uint8 ServiceId, NvM_RequestResultType 
  JobResult);
extern Std_ReturnType SINGLE_BLOCK_CBK_6(uint8 ServiceId, NvM_RequestResultType 
  JobResult);
extern Std_ReturnType SINGLE_BLOCK_CBK_7(uint8 ServiceId, NvM_RequestResultType 
  JobResult);

extern Std_ReturnType INIT_BLOCK_CBK_3(void);

extern Std_ReturnType WRITE_RAM_BLOCK_TO_NVM_CBK_3(void* NvMBuffer);

extern Std_ReturnType READ_RAM_BLOCK_FROM_NVM_CBK_3(void* NvMBuffer);

extern boolean Test_READ_RAM_BLOCK_FROM_NVM_CBK_3
  (App_DataValidateType LucDataValidate);
extern boolean Test_WRITE_RAM_BLOCK_TO_NVM_CBK_3
  (App_DataValidateType LucDataValidate);
extern boolean Test_SINGLE_BLOCK_CBK(App_DataValidateType LucDataValidate,
  uint8 LucExpServiceId, NvM_RequestResultType LddExpJobResult);
  
extern boolean Test_INIT_BLOCK_CBK(App_DataValidateType LucDataValidate);
  
extern void TestSetNvM_WriteRamBlockToNvmRetVal(Std_ReturnType 
  LddWriteRamBlockRetVal);

extern void TestSetNvM_ReadRamBlockFromNvmRetVal(Std_ReturnType 
  LddReadRamBlockRetVal);

extern void TestNvM_CallBackDefaultBehavior(void);

#endif /*RTE_NVM_H*/

/*******************************************************************************
**                       End of File                                          **
*******************************************************************************/
