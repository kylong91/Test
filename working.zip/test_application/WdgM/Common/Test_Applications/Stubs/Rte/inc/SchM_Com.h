/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Com.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PDU Router                                            **
**                                                                            **
**  PURPOSE   : Declaration of SchM functions                                 **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef SCHM_COM_H
#define SCHM_COM_H
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
/* SchM_Enter APIS */
extern void SchM_Enter_Com_RX_DM_STS_PROTECTION_AREA(void);
extern void SchM_Enter_Com_RX_IPDU_STS_PROTECTION_AREA(void);
extern void SchM_Enter_Com_TX_IPDU_STATUS_PROTECTION_AREA(void);
extern void SchM_Enter_Com_TX_IPDU_BUFFER_PROTECTION_AREA(void);
extern void SchM_Enter_Com_TX_SIG_STS_PROTECTION_AREA(void);
extern void SchM_Enter_Com_RX_IPDU_STATUS_PROTECTION(void);
extern void SchM_Enter_Com_TX_SIG_DATA_PROTECTION_AREA(void);
extern void SchM_Enter_Com_RX_SIG_DATA_PROTECTION_AREA(void);
extern void SchM_Enter_Com_RX_IPDU_DATA_PROTECTION_AREA(void);
extern void SchM_Enter_Com_IPDU_GROUP_STATUS_PROTECTION(void);
extern void SchM_Enter_Com_IPDU_STS_PROTECTION(void);
extern void SchM_Enter_Com_TX_TMS_STATUS_PROTECTION_AREA(void);
extern void SchM_Enter_Com_RX_FIFO_PROTECTION_AREA(void);
extern void SchM_Enter_Com_TX_EXT_SIG_DATA_PROTECTION_AREA(void);
extern void SchM_Exit_Com_TX_EXT_SIG_DATA_PROTECTION_AREA(void);
extern void SchM_Enter_Com_RX_EXT_SIG_DATA_PROTECTION_AREA(void);
extern void SchM_Enter_Com_SIG_DATA_PROTECTION_AREA(void);
extern void SchM_Enter_Com_TX_IPDU_DATA_PROTECTION(void);
extern void SchM_Enter_Com_IPDU_COUNTER_PROTECTION(void);
extern void SchM_Enter_Com_RX_GW_STS_PROTECTION_AREA(void);
extern void SchM_Enter_Com_TX_MDT_PROTECTION_AREA(void);
extern void SchM_Enter_Com_RX_IPDU_STATUS_PROTECTION_AREA(void);
extern void SchM_Enter_Com_TX_DM_STS_PROTECTION_AREA(void);
extern void SchM_Enter_Com_TX_MDT_STS_PROTECTION_AREA(void);

/* SchM_Exit APIS */
extern void SchM_Exit_Com_RX_DM_STS_PROTECTION_AREA(void);
extern void SchM_Exit_Com_RX_IPDU_STS_PROTECTION_AREA(void);
extern void SchM_Exit_Com_TX_IPDU_STATUS_PROTECTION(void);
extern void SchM_Exit_Com_TX_IPDU_BUFFER_PROTECTION_AREA(void);
extern void SchM_Exit_Com_TX_SIG_STS_PROTECTION_AREA(void);
extern void SchM_Exit_Com_RX_IPDU_STATUS_PROTECTION(void);
extern void SchM_Exit_Com_TX_SIG_DATA_PROTECTION_AREA(void);
extern void SchM_Exit_Com_SIG_DATA_PROTECTION_AREA(void);
extern void SchM_Exit_Com_RX_SIG_DATA_PROTECTION_AREA(void);
extern void SchM_Exit_Com_RX_IPDU_DATA_PROTECTION_AREA(void);
extern void SchM_Exit_Com_IPDU_GROUP_STATUS_PROTECTION(void);
extern void SchM_Exit_Com_IPDU_STS_PROTECTION(void);
extern void SchM_Exit_Com_TX_TMS_STATUS_PROTECTION_AREA(void);
extern void SchM_Exit_Com_RX_FIFO_PROTECTION_AREA(void);
extern void SchM_Exit_Com_TX_IPDU_DATA_PROTECTION(void);
extern void SchM_Exit_Com_TX_IPDU_STATUS_PROTECTION_AREA(void);
extern void SchM_Exit_Com_TX_EXT_SIG_DATA_PROTECTION_AREA(void);
extern void SchM_Exit_Com_RX_EXT_SIG_DATA_PROTECTION_AREA(void);
extern void SchM_Exit_Com_RX_EXT_SIG_DATA_PROTECTION_AREA(void);
extern void SchM_Exit_Com_IPDU_COUNTER_PROTECTION(void);
extern void SchM_Exit_Com_RX_GW_STS_PROTECTION_AREA(void);
extern void SchM_Exit_Com_TX_MDT_PROTECTION_AREA(void);
extern void SchM_Exit_Com_RX_IPDU_STATUS_PROTECTION_AREA(void);
extern void SchM_Exit_Com_TX_DM_STS_PROTECTION_AREA(void);
extern void SchM_Exit_Com_TX_MDT_STS_PROTECTION_AREA(void);

#endif /* SCHM_COM_H */
/*******************************************************************************
**                       End of File                                          **
*******************************************************************************/
