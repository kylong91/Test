/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Rte_StbM.h                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Synchronized Time Base Manager                        **
**                                                                            **
**  PURPOSE   : Provision of RTE and StbM interface services                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef RTE_STBM_H
#define RTE_STBM_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
/* Header for StbM types provided by the RTE */
#include "Rte_StbM_Type.h"
/* Generic test case header */
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
/* Sync state provider callout */
extern void SyncStateProvider001_Callout
(StbM_SynchronizedTimeBaseType timeBaseID, StbM_SyncStatusType* syncState);
/* Global time provider callout */
extern void GlobalTimeProvider001_Callout
(StbM_SynchronizedTimeBaseType timeBaseID, StbM_TickType* ticks);
/* Tick duration provider callout */
extern void TickDurationProvider001_Callout
(StbM_SynchronizedTimeBaseType timeBaseID, uint16* tickDuration);
/* Sync state customer callout */
extern void SyncStateCustomer001_CallbackFunction
(StbM_SynchronizedTimeBaseType timeBaseID, StbM_SyncStatusType syncState);
extern void SyncStateCustomer002_CallbackFunction
(StbM_SynchronizedTimeBaseType timeBaseID, StbM_SyncStatusType syncState);
/* Global time customer callback */
extern void GlobalTimeCustomer001_CallbackFunction
(StbM_SynchronizedTimeBaseType timeBaseID, StbM_TickType ticks);
extern void GlobalTimeCustomer002_CallbackFunction
(StbM_SynchronizedTimeBaseType timeBaseID, StbM_TickType ticks);

/* Validation functions used in test applications */
extern void TestResetRteInvocationCounts(void);
extern void TestSyncStateProvider001_CalloutSetVal
(StbM_SyncStatusType syncState);

extern boolean TestSyncStateProvider001_Callout
(App_DataValidateType LucDataValidate,
 StbM_SynchronizedTimeBaseType timeBaseID, StbM_SyncStatusType syncState);

extern void TestGlobalTimeProvider001_CalloutSetVal(StbM_TickType ticks);
extern boolean TestTickProvider001_Callout
(App_DataValidateType LucDataValidate, StbM_SynchronizedTimeBaseType timeBaseID,
 StbM_TickType ticks);

extern void TestTickDurationProvider001_CalloutSetVal(uint16 tickDuration);
extern boolean TestTickDurationProvider001_Callout
(App_DataValidateType LucDataValidate, StbM_SynchronizedTimeBaseType timeBaseID,
 uint16 tickDuration);

extern boolean TestSyncStateCustomer001_CallbackFunction
(App_DataValidateType LucDataValidate, StbM_SynchronizedTimeBaseType timeBaseID,
 StbM_SyncStatusType syncState);

extern boolean TestSyncStateCustomer002_CallbackFunction
(App_DataValidateType LucDataValidate, StbM_SynchronizedTimeBaseType timeBaseID,
 StbM_SyncStatusType syncState);

extern boolean TestGlobalTimeCustomer001_CallbackFunction
(App_DataValidateType LucDataValidate, StbM_SynchronizedTimeBaseType timeBaseID,
 StbM_TickType ticks);

extern boolean TestGlobalTimeCustomer002_CallbackFunction
(App_DataValidateType LucDataValidate, StbM_SynchronizedTimeBaseType timeBaseID,
 StbM_TickType ticks);
#endif /* RTE_STBM_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
