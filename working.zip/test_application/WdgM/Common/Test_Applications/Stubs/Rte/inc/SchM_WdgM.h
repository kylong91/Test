/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: SchM_CanTp.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR SchM Stub                                             **
**                                                                            **
**  PURPOSE   : Declaration of SchM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef SCHM_WDGM_H
#define SCHM_WDGM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Std_Types.h"                  /* Standard type header */
#include "ComStack_Types.h"             /* ComStack type header */


/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define SCHM_AR_RELEASE_MAJOR_VERSION      4
#define SCHM_AR_RELEASE_MINOR_VERSION      4
#define SCHM_AR_RELEASE_REVISION_VERSION   0

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                      Exclusive Area                                        **
*******************************************************************************/

/*
 * This type define the exclusive areas along with scheduler services are used
 * to provide data integrity for shared resources
 */

extern void SchM_Enter_WdgM_CURRENTMODE_PROTECTION(void);
extern void SchM_Exit_WdgM_CURRENTMODE_PROTECTION(void);

extern void SchM_Enter_WdgM_GLOBALSUPVSNSTATUS_PROTECTION(void);
extern void SchM_Exit_WdgM_GLOBALSUPVSNSTATUS_PROTECTION(void);

#define WDGM_START_SEC_CODE
#include "MemMap.h"
FUNC(void, WDGM_CODE) WdgM_MainFunction(void);

#define WDGM_STOP_SEC_CODE
#include "MemMap.h"

#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

