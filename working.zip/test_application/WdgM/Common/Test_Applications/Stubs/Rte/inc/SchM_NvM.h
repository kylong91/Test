/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: NvM.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PDU Router                                            **
**                                                                            **
**  PURPOSE   : Declaration of SchM functions                                 **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef SCHM_NVM_H
#define SCHM_NVM_H

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/* SchM_Enter APIS */
extern void SchM_Enter_NvM_RAM_STATUS_PROTECTION(void);
extern void SchM_Enter_NvM_RAM_INDEX(void);

/* SchM_Exit APIS */
extern void SchM_Exit_NvM_RAM_STATUS_PROTECTION(void);
extern void SchM_Exit_NvM_RAM_INDEX(void);

#endif /* SCHM_NVM_H */
/*******************************************************************************
**                       End of File                                          **
*******************************************************************************/
