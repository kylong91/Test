/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Rte_BswM_Type.h                                               **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Bsw Mode Manager                                      **
**                                                                            **
**  PURPOSE   : Declaration of Rte BswM types                                 **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef RTE_BSWM_TYPE_H
#define RTE_BSWM_TYPE_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Rte_Type.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#define RTE_E_LIMIT       0x00
#define RTE_E_OK          0x01
#define APP1_ACTIVE       0x01
#define APP1_INACTIVE     0x00
#define APP1_ECU_SLEEP     0x02
#define APP1_ECU_RESET     0x01
#define APP1_ECU_OFF       0x00
#define APP1_ECU_PASSIVE     0x03
/*******************************************************************************
** Typedefs of Modes
*******************************************************************************/

/* RTE ModeType for CanSM, Based on foreign reference param */
typedef uint8 SwitchMode_Type;

/* RTE ModeType for Dcm, Based on foreign reference param */
typedef uint8 AppModeRequestType;


/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/
#define APP_ACTIVE 1
#define APP_INACTIVE 0
#define RTE_MODE_BswM_Can_States_CANSM_BSWM_BUS_OFF                      0x04
#define RTE_MODE_BswM_Can_States_CANSM_BSWM_FULL_COMMUNICATION           0x00
#define RTE_MODE_BswM_Can_States_CANSM_BSWM_NO_COMMUNICATION             0x01
#define RTE_MODE_BswM_Can_States_CANSM_BSWM_SILENT_COMMUNICATION         0x02
#define RTE_MODE_ComMStates_COMM_FULL_COMMUNICATION                      0x00
#define RTE_MODE_ComMStates_COMM_NO_COMMUNICATION                        0x01
#define RTE_MODE_ComMStates_COMM_SILENT_COMMUNICATION                    0x02
#define RTE_MODE_DcmStates_DCM_ENABLE_RX_TX_NORM                         0x00
#define RTE_MODE_DcmStates_DCM_DISABLE_RX_TX_NORM                        0x03
#define RTE_MODE_DcmStates_DCM_DISABLE_RX_TX_NORMAL                      0x03
#define RTE_MODE_DcmStates_DCM_ENABLE_RX_DISABLE_TX_NORM                 0x01
#define RTE_MODE_DcmStates_DCM_DISABLE_RX_ENABLE_TX_NORM                 0x02
#define RTE_MODE_DcmStates_DCM_ENABLE_RX_TX_NM                           0x04
#define RTE_MODE_DcmStates_DCM_DISABLE_RX_TX_NM                          0x07
#define RTE_MODE_DcmStates_DCM_ENABLE_RX_DISABLE_TX_NM                   0x05
#define RTE_MODE_DcmStates_DCM_ENABLE_RX_TX_NORM_NM                      0x08
#define RTE_MODE_DcmStates_DCM_DISABLE_RX_TX_NORM_NM                     0x0b
#define RTE_MODE_DcmStates_DCM_ENABLE_RX_DISABLE_TX_NORM_NM              0x09
#define RTE_MODE_DcmStates_DCM_DISABLE_RX_ENABLE_TX_NORM_NM              0x0a
#define RTE_MODE_DcmStates_DCM_DISABLE_RX_ENABLE_TX_NM                   0x06
#define RTE_MODE_BswM_EcuM_States_ECUM_STATE_STARTUP_TWO                 0x12
#define RTE_MODE_BswM_EcuM_States_ECUM_STATE_WAKEUP_ONE                  0x21
#define RTE_MODE_BswM_EcuM_States_ECUM_STATE_WAKEUP_VALIDATION           0x22
#define RTE_MODE_BswM_EcuM_States_ECUM_STATE_WAKEUP_REACTION             0x23
#define RTE_MODE_BswM_EcuM_States_ECUM_STATE_WAKEUP_TWO                  0x24
#define RTE_MODE_BswM_EcuM_States_ECUM_STATE_WAKEUP_WAKESLEEP            0x25
#define RTE_MODE_BswM_EcuM_States_ECUM_STATE_WAKEUP_TTII                 0x26
#define RTE_MODE_BswM_EcuM_States_ECUM_STATE_APP_RUN                     0x32
#define RTE_MODE_BswM_EcuM_States_ECUM_STATE_APP_POST_RUN                0x33
#define RTE_MODE_BswM_EcuM_States_ECUM_STATE_PREP_SHUTDOWN               0x44
#define RTE_MODE_BswM_EcuM_States_ECUM_STATE_GO_SLEEP                    0x49
#define RTE_MODE_BswM_EcuM_States_ECUM_STATE_GO_OFF_ONE                  0x4d
#define RTE_MODE_BswM_EcuM_States_ECUM_STATE_GO_OFF_TWO                  0x4e
#define RTE_MODE_BswM_EcuM_States_ECUM_WKSTATUS_NONE                     0x00
#define RTE_MODE_BswM_EcuM_States_ECUM_WKSTATUS_PENDING                  0x01
#define RTE_MODE_BswM_EcuM_States_ECUM_WKSTATUS_VALIDATED                0x02
#define RTE_MODE_BswM_EcuM_States_ECUM_WKSTATUS_EXPIRED                  0x03
#define RTE_MODE_BswM_EcuM_States_ECUM_WKSTATUS_DISABLED                 0x04
#define RTE_MODE_BswM_EcuM_States_ECUM_STATE_SLEEP                       0x50
#define RTE_MODE_BswM_EcuM_States_ECUM_STATE_RUN                         0x30
#define RTE_MODE_EthSMStates_ETHSM_NO_COMMUNICATION                      0x01
#define RTE_MODE_EthSMStates_ETHSM_FULL_COMMUNICATION                    0x02
#define RTE_MODE_FrSMStates_FRSM_BSWM_ONLINE                             0x0a
#define RTE_MODE_FrSMStates_FRSM_BSWM_ONLINE_ECU_PASSIVE                 0x0b
#define RTE_MODE_FrSMStates_FRSM_BSWM_STARTUP_ECU_PASSIVE                0x03
#define RTE_MODE_LinStates_LINSM_NO_COM                                  0x02
#define RTE_MODE_LinStates_LINSM_FULL_COM                                0x01
#define RTE_MODE_LinTpStates_LINTP_APPLICATIVE_SCHEDULE                  0x00
#define RTE_MODE_LinTpStates_LINTP_DIAG_RESPONSE                         0x02
#define RTE_MODE_LinTpStates_LINTP_DIAG_REQUEST                          0x01
#define RTE_MODE_AppModeType_APP1_ACTIVE                                 0x01
#define RTE_MODE_AppModeType_APP1_INACTIVE                               0x00


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#endif /* RTE_BSWM_TYPE_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
