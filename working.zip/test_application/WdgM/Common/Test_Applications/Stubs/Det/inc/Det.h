/*******************************************************************************
**  (C) 2014 Hyundai AUTRON                                                   **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Det.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Det Stub                                              **
**                                                                            **
**  PURPOSE   : Declaration of Det Stub functions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     07-Oct-2014   Sinil        Initial Version                       **
*******************************************************************************/

#ifndef DET_H
#define DET_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
/*
 * This header file includes all the standard data types, platform dependent
 * header file and common return types
 */
#include "Std_Types.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define DET_AR_RELEASE_MAJOR_VERSION      0x04
#define DET_AR_RELEASE_MINOR_VERSION      0x04
#define DET_AR_RELEASE_REVISION_VERSION   0x00

#define DET_MODULE_ID (uint16)15

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define DET_ARRAY_SIZE                    10

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/*
 * Defining the structure to store the parameters of Det Report Error function
 */
typedef struct
{  /* It will store the ModuleId of the reporting module */
   uint16 ModuleId;

   /* It will store the index based InstanceId of the reporting module */
   uint8 InstanceId;

   /* It will store the ApiId of the reporting function */
   uint8 ApiId;

   /* It will store the ErrorId of the reporting error */
   uint8 ErrorId;
}tDet_Error;

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void Det_Init (void);
extern void Det_Start (void);
extern Std_ReturnType Det_ReportError(uint16 ModuleId, uint8 InstanceId,
  uint8 ApiId, uint8 ErrorId);
extern boolean TestDet_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
extern boolean TestDet_Start(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
extern boolean TestDet_ReportError(App_DataValidateType LucDataValidate,
  uint16 ExpModuleId, uint8 ExpInstanceId, uint8 ExpApiId, uint8 ExpErrorId);

extern void TestDet_DefaultBehavior(void);

extern void TestSetDet_ReportErrorLogEnable(boolean LblErrorLog);

extern void TestSetDet_ReportErrorRetVal(Std_ReturnType LddRetVal);

#endif /* End DET_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

