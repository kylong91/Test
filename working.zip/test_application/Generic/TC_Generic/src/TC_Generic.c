/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: TC_Generic.c                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : TC Generic                                                    **
**                                                                            **
**  PURPOSE   : Common file for Testing                                       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/


/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     02-Nov-2012   Kavya M    Initial Version                         **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Platform_Types.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 App_GucApiSeqCnt;
uint8 App_GucTestIndex;
uint8 App_GucTestCaseCount;
App_TCStepIdType App_GddTestStepId;
App_TCResultType *App_GpTCReport;

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                            App_LogTestResult()                             **
*******************************************************************************/
void App_LogTestResult(uint8 LucTestResult)
{
  App_TCResultType *LpTCReport;
  
  LpTCReport = (App_GpTCReport + App_GucTestIndex);
  
  if(LucTestResult == APP_TC_FAILED_DET)
  {
    LpTCReport->ucFailedStepId = App_GddTestStepId;
    LpTCReport->ucTCResult = LucTestResult;
  }
  else if(LpTCReport->ucTCResult == APP_TC_FAILED_DET)
  {
    /* Do Nothing */
  }
  else
  {
    LpTCReport->ucTCResult = LucTestResult;
    if(LucTestResult == APP_TC_FAILED)
    {
      LpTCReport->ucFailedStepId = App_GddTestStepId;
    }
  }
} /* End App_LogTestResult() */

/*******************************************************************************
**                            App_TestSetUp()                                 **
*******************************************************************************/
void App_TestSetUp(App_TCResultType *LpTCReport, uint16* TCIdList, 
  uint8 LucTestCaseCount)
{
  uint8 LucTestIndex;
  App_GpTCReport = LpTCReport;
  App_GucTestCaseCount = LucTestCaseCount; 
  /* Loading the test report with defualt values */
  for(LucTestIndex = 0; LucTestIndex < App_GucTestCaseCount; LucTestIndex++)
  {
    LpTCReport = (App_GpTCReport + LucTestIndex);
    LpTCReport->usTCId = *(TCIdList + LucTestIndex);
    LpTCReport->ucTCResult = APP_TC_FAILED;
    LpTCReport->ucFailedStepId = APP_STEP_NA;
  }
} /* End App_TestSetUp() */

#ifdef APP_LOG_TEST_RESULT_TO_FILE
/*******************************************************************************
**                            App_LogTestResult()                             **
*******************************************************************************/
void App_LogTestResultToFile(void)
{
  uint8 LucTestIndex;
  App_TCResultType *LpTCReport;
  FILE *fp;
  fp = fopen("TestResult.txt", "w");

  fprintf(fp,"%-7s", "TC ID");
  fprintf(fp,"\t%-20s", "TC RESULT");
  fprintf(fp,"\t%-20s", "TC STEP ID");

  /* Loading the test report with defualt values */
  for(LucTestIndex = 0; LucTestIndex < App_GucTestCaseCount; LucTestIndex++)
  {
    LpTCReport = (App_GpTCReport + LucTestIndex);
    fprintf(fp,"\n%-7d", LpTCReport->usTCId);

    if(LpTCReport->ucTCResult == APP_TC_FAILED)
    {
      fprintf(fp,"\t%-20s", "APP_TC_FAILED");
      fprintf(fp,"\t%-20d", LpTCReport->ucFailedStepId);
    }
    else if(LpTCReport->ucTCResult == APP_PC_FAILED)
    {
      fprintf(fp,"\t%-20s", "APP_PC_FAILED");
      fprintf(fp,"\t%-20s", "APP_STEP_NA");
    }
    else if(LpTCReport->ucTCResult == APP_TC_PASSED)
    {
      fprintf(fp,"\t%-20s", "APP_TC_PASSED");
      fprintf(fp,"\t%-20s", "APP_STEP_NA");
    }
    else if(LpTCReport->ucTCResult == APP_TC_FAILED_DET)
    {
      fprintf(fp,"\t%-20s", "APP_TC_FAILED_DET");
      fprintf(fp,"\t%-20d", LpTCReport->ucFailedStepId);
    }
  } /* End for(LucTestIndex = 0; */
  fclose(fp);
} /* End App_LogTestResultToFile() */
#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
