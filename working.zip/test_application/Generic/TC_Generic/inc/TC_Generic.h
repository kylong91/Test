/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: TC_Generic.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : TC Generic                                                    **
**                                                                            **
**  PURPOSE   : C header for TC_Generic.c                                     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By         Description                             **
********************************************************************************
** 1.0.0     02-Nov-2012   Kavya M    Initial Version                         **
*******************************************************************************/
#ifndef TC_GENERIC_H
#define TC_GENERIC_H

#define APP_INVALID_ID 0x00

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
/* This header file includes all the standard data types, platform dependent
   header file and common return types */

#include "Platform_Types.h"
#include "Compiler.h"

#ifdef APP_LOG_TEST_RESULT_TO_FILE
#include "Stdio.h"
#endif

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#define APP_STEP_NA 0x00
#define APP_TC_FAILED 0x00
#define APP_TC_FAILED_DET 0x02
#define APP_TC_PASSED 0x01
#define APP_PC_FAILED 0xff
#define STEP_FAILED 0x00
#define STEP_PASSED 0x01

typedef uint8 App_TCStepIdType;

typedef P2FUNC(uint8, TCGENERIC_APPL_CODE, TCFunctionPtr)(void);

typedef struct STag_App_TCResultType
{
  /* It will store the test case Id */
   uint16 usTCId;

   /* It will store the failed expected step number */
   uint8 ucFailedStepId;

   /* It will store the test result */
   uint8 ucTCResult;
}App_TCResultType ;

typedef enum
{
  /*
   * This type is to handle API invocation with single occurance and to validate
   * parameters of the API with what it has been invoked
   */
  S_VALIDATE = 0x00,

  /*
   * This type is to handle API invocation with multiple occurance (with out any
   * sequnce) and to validate parameters of the API with what it has been
   * invoked
   */
  M_VALIDATE,

  /*
   * This type is to handle API invocation with multiple occurance (with
   * sequnce) and to validate parameters of the API with what it has been
   * invoked
   */
  M_VALIDATE_SEQ,

  /* This type is to handle API not invoked for single occurance */
  S_NOT_INVOKED,

  /*
   * This type is to handle API not invoked with given ID for multiple
   * occurances
   */
  M_NOT_INVOKED,

  /*
   * This type is to handle API invocation with single occurance (with sequnce)
   * and to validate parameters of the API with what it has been invoked
   */
  S_VALIDATE_SEQ,
  
  S_VALIDATE_SECOND,

  S_VALIDATE_THIRD,  

    /* This type is to handle Dhcpv6 Message type */
  VALIDATE_MSG_TYPE,
  /* This type is to handle Dhcpv6 TxId type */
  VALIDATE_TXID,
  /* This type is to handle Dhcpv6 Client Id type */
  VALIDATE_CLIENTID
}App_DataValidateType;

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
extern uint8 App_GucApiSeqCnt;
extern uint8 App_GucTestIndex;
extern App_TCStepIdType App_GddTestStepId;

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void App_LogTestResult (uint8 LucTestResult);

extern void App_TestSetUp(App_TCResultType *LpTCReport, uint16* TCIdList,
  uint8 LucTestCaseCount);

#ifdef APP_LOG_TEST_RESULT_TO_FILE
extern void App_LogTestResultToFile(void);
#endif /* End APP_LOG_TEST_RESULT_TO_FILE */

#endif /* End of #ifndef TC_GENERIC_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

