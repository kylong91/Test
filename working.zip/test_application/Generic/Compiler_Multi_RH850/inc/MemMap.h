/*******************************************************************************
**  (C) 2014 HYUNDAI AUTRON Co., Ltd.                                         **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: MemMap.h                                                      **
**                                                                            **
**  TARGET    : TC2xx                                                         **
**                                                                            **
**  PRODUCT   : AUTOSAR BSW R4.0.3 Modules                                    **
**                                                                            **
**  PURPOSE   : Provision for sections for memory mapping.                    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: yes                                       **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By        Description                              **
********************************************************************************
** 1.0.1     10-Jun-2015   JH.Jung   EcuM related macros are added            **
** 1.0.0     29-Apr-2014   MJ.Woo    Initial Version                          **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR specification version information */
#define MEMMAP_AR_MAJOR_VERSION   4
#define MEMMAP_AR_MINOR_VERSION   0
#define MEMMAP_AR_PATCH_VERSION   3

/* File version information */
#define MEMMAP_SW_MAJOR_VERSION   1
#define MEMMAP_SW_MINOR_VERSION   0

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Module section mapping                                **
*******************************************************************************/
/*
 * The symbol 'START_WITH_IF' is undefined.
 *
 * Thus, the preprocessor continues searching for defined symbols.
 * This first #ifdef makes integration of delivered parts of MemMap.h
 * easier because every supplier starts with #elif
 */
#if defined (START_WITH_IF)

/*----------------------------------------------------------------------------*/
/*                           J1939TP                                          */
/*----------------------------------------------------------------------------*/
#elif defined (J1939TP_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      J1939TP_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (J1939TP_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      J1939TP_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (J1939TP_START_SEC_VAR_CLEARED_8)
   #undef      J1939TP_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (J1939TP_STOP_SEC_VAR_CLEARED_8)
   #undef      J1939TP_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (J1939TP_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      J1939TP_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (J1939TP_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      J1939TP_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (J1939TP_START_SEC_VAR_NO_INIT_8)
   #undef      J1939TP_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (J1939TP_STOP_SEC_VAR_NO_INIT_8)
   #undef      J1939TP_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (J1939TP_START_SEC_VAR_NO_INIT_16)
   #undef      J1939TP_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (J1939TP_STOP_SEC_VAR_NO_INIT_16)
   #undef      J1939TP_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (J1939TP_START_SEC_VAR_NO_INIT_32)
   #undef      J1939TP_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (J1939TP_STOP_SEC_VAR_NO_INIT_32)
   #undef      J1939TP_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (J1939TP_START_SEC_VAR_SAVED_ZONE_16)
   #undef      J1939TP_START_SEC_VAR_SAVED_ZONE_16
   #define DEFAULT_START_SEC_VAR_SAVED_ZONE_16
#elif defined (J1939TP_STOP_SEC_VAR_SAVED_ZONE_16)
   #undef      J1939TP_STOP_SEC_VAR_SAVED_ZONE_16
   #define DEFAULT_STOP_SEC_VAR_SAVED_ZONE_16

#elif defined (J1939TP_START_SEC_VAR_SAVED_ZONE_8)
   #undef      J1939TP_START_SEC_VAR_SAVED_ZONE_8
   #define DEFAULT_START_SEC_VAR_SAVED_ZONE_8
#elif defined (J1939TP_STOP_SEC_VAR_SAVED_ZONE_8)
   #undef      J1939TP_STOP_SEC_VAR_SAVED_ZONE_8
   #define DEFAULT_STOP_SEC_VAR_SAVED_ZONE_8

#elif defined (J1939TP_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      J1939TP_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (J1939TP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      J1939TP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (J1939TP_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      J1939TP_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
#elif defined (J1939TP_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      J1939TP_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED

#elif defined (J1939TP_START_SEC_CONST_8)
   #undef      J1939TP_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (J1939TP_STOP_SEC_CONST_8)
   #undef      J1939TP_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (J1939TP_START_SEC_CONST_UNSPECIFIED)
   #undef      J1939TP_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (J1939TP_STOP_SEC_CONST_UNSPECIFIED)
   #undef      J1939TP_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (J1939TP_START_SEC_CODE)
   #undef      J1939TP_START_SEC_CODE
   #define     DEFAULT_START_SEC_CODE
#elif defined (J1939TP_STOP_SEC_CODE)
   #undef      J1939TP_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*                 CAN Transceiver                                            */
/* -------------------------------------------------------------------------- */

#elif defined (CANTRCV_START_SEC_CODE)
   #undef      CANTRCV_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE

#elif defined (CANTRCV_STOP_SEC_CODE)
   #undef      CANTRCV_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (CANTRCV_START_SEC_CONST_UNSPECIFIED)
   #undef      CANTRCV_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED

#elif defined (CANTRCV_STOP_SEC_CONST_UNSPECIFIED)
   #undef      CANTRCV_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (CANTRCV_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANTRCV_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (CANTRCV_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANTRCV_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (CANTRCV_START_SEC_VAR_CLEARED_8)
   #undef      CANTRCV_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (CANTRCV_STOP_SEC_VAR_CLEARED_8)
   #undef      CANTRCV_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8
   
#elif defined (CANTRCV_START_SEC_VAR_CLEARED_16)
   #undef      CANTRCV_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (CANTRCV_STOP_SEC_VAR_CLEARED_16)
   #undef      CANTRCV_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16
   
#elif defined (CANTRCV_START_SEC_VAR_CLEARED_32)
   #undef      CANTRCV_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (CANTRCV_STOP_SEC_VAR_CLEARED_32)
   #undef      CANTRCV_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

/* -------------------------------------------------------------------------- */
/*                                CANTP                                       */
/* -------------------------------------------------------------------------- */
#elif defined (CANTP_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       CANTP_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.CANTP_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (CANTP_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       CANTP_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (CANTP_START_SEC_VAR_CLEARED_8)
  #undef       CANTP_START_SEC_VAR_CLEARED_8
  #pragma ghs section bss=".bss.CANTP_RAM_VAR_CLEARED_8"
#elif defined (CANTP_STOP_SEC_VAR_CLEARED_8)
  #undef       CANTP_STOP_SEC_VAR_CLEARED_8
  #pragma ghs section

#elif defined (CANTP_START_SEC_CONST_8)
  #undef       CANTP_START_SEC_CONST_8
  #pragma ghs section rodata=".rodata.CANTP_ROM_CONST_8"
#elif defined (CANTP_STOP_SEC_CONST_8)
  #undef       CANTP_STOP_SEC_CONST_8
  #pragma ghs section

#elif defined (CANTP_START_SEC_VAR_CLEARED_16)
  #undef       CANTP_START_SEC_VAR_CLEARED_16
  #pragma ghs section bss=".bss.CANTP_RAM_VAR_CLEARED_16"
#elif defined (CANTP_STOP_SEC_VAR_CLEARED_16)
  #undef       CANTP_STOP_SEC_VAR_CLEARED_16
  #pragma ghs section

#elif defined (CANTP_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       CANTP_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.CANTP_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (CANTP_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       CANTP_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (CANTP_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       CANTP_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.CANTP_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (CANTP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       CANTP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (CANTP_START_SEC_VAR_INIT_UNSPECIFIED)
  #undef       CANTP_START_SEC_VAR_INIT_UNSPECIFIED
  #pragma ghs section data=".data.CANTP_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (CANTP_STOP_SEC_VAR_INIT_UNSPECIFIED)
  #undef       CANTP_STOP_SEC_VAR_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (CANTP_START_SEC_CONST_UNSPECIFIED)
  #undef       CANTP_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.CANTP_ROM_CONST_UNSPECIFIED"
#elif defined (CANTP_STOP_SEC_CONST_UNSPECIFIED)
  #undef       CANTP_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (CANTP_START_SEC_CODE)
  #undef       CANTP_START_SEC_CODE
  #pragma ghs section text=".text.CANTP_CODE"
  #pragma ghs section rodata=".rodata.CANTP_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.CANTP_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.CANTP_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (CANTP_STOP_SEC_CODE)
  #undef       CANTP_STOP_SEC_CODE
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*                 DCM                                                      */
/* -------------------------------------------------------------------------- */
#elif defined (DCM_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
  #undef       DCM_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.DCM_RAM_VAR_POWER_ON_CLEARED_BOOLEAN"
#elif defined (DCM_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
  #undef       DCM_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (DCM_START_SEC_VAR_NO_INIT_BOOLEAN)
  #undef       DCM_START_SEC_VAR_NO_INIT_BOOLEAN
  #pragma ghs section bss=".bss.DCM_RAM_VAR_NO_INIT_BOOLEAN"
#elif defined (DCM_STOP_SEC_VAR_NO_INIT_BOOLEAN)
  #undef       DCM_STOP_SEC_VAR_NO_INIT_BOOLEAN
  #pragma ghs section

#elif defined (DCM_START_SEC_VAR_NO_INIT_8)
  #undef       DCM_START_SEC_VAR_NO_INIT_8
  #pragma ghs section bss=".bss.DCM_RAM_VAR_NO_INIT_8"
#elif defined (DCM_STOP_SEC_VAR_NO_INIT_8)
  #undef       DCM_STOP_SEC_VAR_NO_INIT_8
  #pragma ghs section

#elif defined (DCM_START_SEC_VAR_NO_INIT_16)
  #undef       DCM_START_SEC_VAR_NO_INIT_16
  #pragma ghs section bss=".bss.DCM_RAM_VAR_NO_INIT_16"
#elif defined (DCM_STOP_SEC_VAR_NO_INIT_16)
  #undef       DCM_STOP_SEC_VAR_NO_INIT_16
  #pragma ghs section

#elif defined (DCM_START_SEC_VAR_NO_INIT_32)
  #undef       DCM_START_SEC_VAR_NO_INIT_32
  #pragma ghs section bss=".bss.DCM_RAM_VAR_NO_INIT_32"
#elif defined (DCM_STOP_SEC_VAR_NO_INIT_32)
  #undef       DCM_STOP_SEC_VAR_NO_INIT_32
  #pragma ghs section

#elif defined (DCM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       DCM_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.DCM_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (DCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       DCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (DCM_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       DCM_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.DCM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (DCM_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       DCM_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (DCM_START_SEC_VAR_CLEARED_8)
  #undef       DCM_START_SEC_VAR_CLEARED_8
  #pragma ghs section bss=".bss.DCM_RAM_VAR_CLEARED_8"
#elif defined (DCM_STOP_SEC_VAR_CLEARED_8)
  #undef       DCM_STOP_SEC_VAR_CLEARED_8
  #pragma ghs section

#elif defined (DCM_START_SEC_VAR_CLEARED_16)
  #undef       DCM_START_SEC_VAR_CLEARED_16
  #pragma ghs section bss=".bss.DCM_RAM_VAR_CLEARED_16"
#elif defined (DCM_STOP_SEC_VAR_CLEARED_16)
  #undef       DCM_STOP_SEC_VAR_CLEARED_16
  #pragma ghs section

#elif defined (DCM_START_SEC_VAR_CLEARED_32)
  #undef       DCM_START_SEC_VAR_CLEARED_32
  #pragma ghs section bss=".bss.DCM_RAM_VAR_CLEARED_32"
#elif defined (DCM_STOP_SEC_VAR_CLEARED_32)
  #undef       DCM_STOP_SEC_VAR_CLEARED_32
  #pragma ghs section

#elif defined (DCM_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       DCM_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.DCM_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (DCM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       DCM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (DCM_START_SEC_VAR_INIT_BOOLEAN)
  #undef       DCM_START_SEC_VAR_INIT_BOOLEAN
  #pragma ghs section data=".data.DCM_RAM_VAR_INIT_BOOLEAN"
#elif defined (DCM_STOP_SEC_VAR_INIT_BOOLEAN)
  #undef       DCM_STOP_SEC_VAR_INIT_BOOLEAN
  #pragma ghs section

#elif defined (DCM_START_SEC_VAR_INIT_8)
  #undef       DCM_START_SEC_VAR_INIT_8
  #pragma ghs section data=".data.DCM_RAM_VAR_INIT_8"
#elif defined (DCM_STOP_SEC_VAR_INIT_8)
  #undef       DCM_STOP_SEC_VAR_INIT_8
  #pragma ghs section

#elif defined (DCM_START_SEC_VAR_INIT_16)
  #undef       DCM_START_SEC_VAR_INIT_16
  #pragma ghs section data=".data.DCM_RAM_VAR_INIT_16"
#elif defined (DCM_STOP_SEC_VAR_INIT_16)
  #undef       DCM_STOP_SEC_VAR_INIT_16
  #pragma ghs section

#elif defined (DCM_START_SEC_VAR_INIT_32)
  #undef       DCM_START_SEC_VAR_INIT_32
  #pragma ghs section data=".data.DCM_RAM_VAR_INIT_32"
#elif defined (DCM_STOP_SEC_VAR_INIT_32)
  #undef       DCM_STOP_SEC_VAR_INIT_32
  #pragma ghs section

#elif defined (DCM_START_SEC_VAR_INIT_UNSPECIFIED)
  #undef       DCM_START_SEC_VAR_INIT_UNSPECIFIED
  #pragma ghs section data=".data.DCM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (DCM_STOP_SEC_VAR_INIT_UNSPECIFIED)
  #undef       DCM_STOP_SEC_VAR_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (DCM_START_SEC_CONST_BOOLEAN)
  #undef       DCM_START_SEC_CONST_BOOLEAN
  #pragma ghs section rodata=".rodata.DCM_ROM_CONST_BOOLEAN"
#elif defined (DCM_STOP_SEC_CONST_BOOLEAN)
  #undef       DCM_STOP_SEC_CONST_BOOLEAN
  #pragma ghs section

#elif defined (DCM_START_SEC_CONST_8)
  #undef       DCM_START_SEC_CONST_8
  #pragma ghs section rodata=".rodata.DCM_ROM_CONST_8"
#elif defined (DCM_STOP_SEC_CONST_8)
  #undef       DCM_STOP_SEC_CONST_8
  #pragma ghs section

#elif defined (DCM_START_SEC_CONST_16)
  #undef       DCM_START_SEC_CONST_16
  #pragma ghs section rodata=".rodata.DCM_ROM_CONST_16"
#elif defined (DCM_STOP_SEC_CONST_16)
  #undef       DCM_STOP_SEC_CONST_16
  #pragma ghs section

#elif defined (DCM_START_SEC_CONST_UNSPECIFIED)
  #undef       DCM_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.DCM_ROM_CONST_UNSPECIFIED"
#elif defined (DCM_STOP_SEC_CONST_UNSPECIFIED)
  #undef       DCM_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (DCM_START_SEC_CODE)
  #undef       DCM_START_SEC_CODE
  #pragma ghs section text=".text.DCM_CODE"
  #pragma ghs section rodata=".rodata.DCM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.DCM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.DCM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (DCM_STOP_SEC_CODE)
  #undef       DCM_STOP_SEC_CODE
  #pragma ghs section

#elif defined (DCM_START_SEC_CALLOUT_CODE)
  #undef       DCM_START_SEC_CALLOUT_CODE
  #pragma ghs section text=".text.DCM_CODE"
  #pragma ghs section rodata=".rodata.DCM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.DCM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.DCM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (DCM_STOP_SEC_CALLOUT_CODE)
  #undef       DCM_STOP_SEC_CALLOUT_CODE
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*             Dem                                                           */
/* -------------------------------------------------------------------------- */
#elif defined (DEM_START_SEC_CONST_BOOLEAN)
  #undef       DEM_START_SEC_CONST_BOOLEAN
  #pragma ghs section rodata=".rodata.DEM_ROM_CONST_BOOLEAN"
#elif defined (DEM_STOP_SEC_CONST_BOOLEAN)
  #undef       DEM_STOP_SEC_CONST_BOOLEAN
  #pragma ghs section

#elif defined (DEM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
  #undef       DEM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.DEM_RAM_VAR_POWER_ON_CLEARED_UNSPECIFIED"
#elif defined (DEM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
  #undef       DEM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (DEM_START_SEC_VAR_CLEARED_8)
  #undef       DEM_START_SEC_VAR_CLEARED_8
  #pragma ghs section bss=".bss.DEM_RAM_VAR_CLEARED_8"
#elif defined (DEM_STOP_SEC_VAR_CLEARED_8)
  #undef       DEM_STOP_SEC_VAR_CLEARED_8
  #pragma ghs section

#elif defined (DEM_START_SEC_VAR_CLEARED_16)
  #undef       DEM_START_SEC_VAR_CLEARED_16
  #pragma ghs section bss=".bss.DEM_RAM_VAR_CLEARED_16"
#elif defined (DEM_STOP_SEC_VAR_CLEARED_16)
  #undef       DEM_STOP_SEC_VAR_CLEARED_16
  #pragma ghs section

#elif defined (DEM_START_SEC_VAR_CLEARED_32)
  #undef       DEM_START_SEC_VAR_CLEARED_32
  #pragma ghs section bss=".bss.DEM_RAM_VAR_CLEARED_32"
#elif defined (DEM_STOP_SEC_VAR_CLEARED_32)
  #undef       DEM_STOP_SEC_VAR_CLEARED_32
  #pragma ghs section

#elif defined (DEM_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       DEM_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.DEM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (DEM_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       DEM_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (DEM_START_SEC_VAR_NO_INIT_8)
  #undef       DEM_START_SEC_VAR_NO_INIT_8
  #pragma ghs section bss=".bss.DEM_RAM_VAR_NO_INIT_8"
#elif defined (DEM_STOP_SEC_VAR_NO_INIT_8)
  #undef       DEM_STOP_SEC_VAR_NO_INIT_8
  #pragma ghs section

#elif defined (DEM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       DEM_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.DEM_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (DEM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       DEM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (DEM_START_SEC_CONST_UNSPECIFIED)
  #undef       DEM_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.DEM_ROM_CONST_UNSPECIFIED"
#elif defined (DEM_STOP_SEC_CONST_UNSPECIFIED)
  #undef       DEM_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (DEM_START_SEC_CODE)
  #undef       DEM_START_SEC_CODE
  #pragma ghs section text=".text.DEM_CODE"
  #pragma ghs section rodata=".rodata.DEM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.DEM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.DEM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (DEM_STOP_SEC_CODE)
  #undef       DEM_STOP_SEC_CODE
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*                              Det                                           */
/* -------------------------------------------------------------------------- */
#elif defined (DET_START_SEC_VAR_NO_INIT_16)
  #undef       DET_START_SEC_VAR_NO_INIT_16
  #pragma ghs section bss=".bss.DET_RAM_VAR_NO_INIT_16"
#elif defined (DET_STOP_SEC_VAR_NO_INIT_16)
  #undef       DET_STOP_SEC_VAR_NO_INIT_16
  #pragma ghs section

#elif defined (DET_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       DET_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.DET_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (DET_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       DET_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (DET_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       DET_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.DET_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (DET_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       DET_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (DET_START_SEC_CONST_UNSPECIFIED)
  #undef       DET_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.DET_ROM_CONST_UNSPECIFIED"
#elif defined (DET_STOP_SEC_CONST_UNSPECIFIED)
  #undef       DET_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (DET_START_SEC_CODE)
  #undef       DET_START_SEC_CODE
  #pragma ghs section text=".text.DET_CODE"
  #pragma ghs section rodata=".rodata.DET_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.DET_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.DET_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (DET_STOP_SEC_CODE)
  #undef       DET_STOP_SEC_CODE
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*                                 OS                                         */
/* -------------------------------------------------------------------------- */

#elif defined (OS_START_SEC_VAR_NO_INIT_8)
  #undef       OS_START_SEC_VAR_NO_INIT_8
  #pragma ghs section bss=".bss.OS_RAM_VAR_NO_INIT_8"
#elif defined (OS_STOP_SEC_VAR_NO_INIT_8)
  #undef       OS_STOP_SEC_VAR_NO_INIT_8
  #pragma ghs section

#elif defined (OS_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       OS_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.OS_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (OS_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       OS_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (OS_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       OS_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.OS_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (OS_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       OS_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (OS_START_SEC_VAR_CLEARED_8)
  #undef       OS_START_SEC_VAR_CLEARED_8
  #pragma ghs section bss=".bss.OS_RAM_VAR_CLEARED_8"
#elif defined (OS_STOP_SEC_VAR_CLEARED_8)
  #undef       OS_STOP_SEC_VAR_CLEARED_8
  #pragma ghs section

#elif defined (OS_START_SEC_VAR_CLEARED_16)
  #undef       OS_START_SEC_VAR_CLEARED_16
  #pragma ghs section bss=".bss.OS_RAM_VAR_CLEARED_16"
#elif defined (OS_STOP_SEC_VAR_CLEARED_16)
  #undef       OS_STOP_SEC_VAR_CLEARED_16
  #pragma ghs section

#elif defined (OS_START_SEC_VAR_CLEARED_32)
  #undef       OS_START_SEC_VAR_CLEARED_32
  #pragma ghs section bss=".bss.OS_RAM_VAR_CLEARED_32"
#elif defined (OS_STOP_SEC_VAR_CLEARED_32)
  #undef       OS_STOP_SEC_VAR_CLEARED_32
  #pragma ghs section

#elif defined (OS_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       OS_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.OS_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (OS_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       OS_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (OS_START_SEC_VAR_INIT_32)
  #undef       OS_START_SEC_VAR_INIT_32
  #pragma ghs section data=".data.OS_RAM_VAR_INIT_32"
#elif defined (OS_STOP_SEC_VAR_INIT_32)
  #undef       OS_STOP_SEC_VAR_INIT_32
  #pragma ghs section

#elif defined (OS_START_SEC_VAR_INIT_UNSPECIFIED)
  #undef       OS_START_SEC_VAR_INIT_UNSPECIFIED
  #pragma ghs section data=".data.OS_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (OS_STOP_SEC_VAR_INIT_UNSPECIFIED)
  #undef       OS_STOP_SEC_VAR_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (OS_START_SEC_CONST_32)
  #undef       OS_START_SEC_CONST_32
  #pragma ghs section rodata=".rodata.OS_ROM_CONST_32"
#elif defined (OS_STOP_SEC_CONST_32)
  #undef       OS_STOP_SEC_CONST_32
  #pragma ghs section

#elif defined (OS_START_SEC_CONST_UNSPECIFIED)
  #undef       OS_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.OS_ROM_CONST_UNSPECIFIED"
#elif defined (OS_STOP_SEC_CONST_UNSPECIFIED)
  #undef       OS_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (OS_START_SEC_CODE)
  #undef       OS_START_SEC_CODE
  #pragma ghs section text=".text.OS_CODE"
  #pragma ghs section rodata=".rodata.OS_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.OS_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.OS_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (OS_STOP_SEC_CODE)
  #undef       OS_STOP_SEC_CODE
  #pragma ghs section

#elif defined (OS_START_SEC_API_CODE)
  #undef       OS_START_SEC_API_CODE
  #pragma ghs section text=".text.OS_CODE"
#elif defined (OS_STOP_SEC_API_CODE)
  #undef       OS_STOP_SEC_API_CODE
  #pragma ghs section

#elif defined (OS_START_SEC_EXCEPTION_VECTOR)
  #undef       OS_START_SEC_EXCEPTION_VECTOR
  #pragma ghs section text=".vector.EXCEPTION"
#elif defined (OS_STOP_SEC_EXCEPTION_VECTOR)
  #undef       OS_STOP_SEC_EXCEPTION_VECTOR
  #pragma ghs section

#elif defined (OS_START_SEC_INTERRUPT_VECTOR)
  #undef       OS_START_SEC_INTERRUPT_VECTOR
  #pragma ghs section text=".vector.INTERRUPT"
#elif defined (OS_STOP_SEC_INTERRUPT_VECTOR)
  #undef       OS_STOP_SEC_INTERRUPT_VECTOR
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*                 LinSM                                                      */
/* -------------------------------------------------------------------------- */
#elif defined (LINSM_START_SEC_CONST_UNSPECIFIED)
  #undef       LINSM_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.LINSM_ROM_CONST_UNSPECIFIED"
#elif defined (LINSM_STOP_SEC_CONST_UNSPECIFIED)
  #undef       LINSM_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (LINSM_START_SEC_CONST_8)
  #undef       LINSM_START_SEC_CONST_8
  #pragma ghs section rodata=".rodata.LINSM_ROM_CONST_8"
#elif defined (LINSM_STOP_SEC_CONST_8)
  #undef       LINSM_STOP_SEC_CONST_8
  #pragma ghs section

#elif defined (LINSM_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       LINSM_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.LINSM_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (LINSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       LINSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (LINSM_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       LINSM_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.LINSM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (LINSM_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       LINSM_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (LINSM_START_SEC_VAR_CLEARED_8)
  #undef       LINSM_START_SEC_VAR_CLEARED_8
  #pragma ghs section bss=".bss.LINSM_RAM_VAR_CLEARED_8"
#elif defined (LINSM_STOP_SEC_VAR_CLEARED_8)
  #undef       LINSM_STOP_SEC_VAR_CLEARED_8
  #pragma ghs section

#elif defined (LINSM_START_SEC_CODE)
  #undef       LINSM_START_SEC_CODE
  #pragma ghs section text=".text.LINSM_CODE"
  #pragma ghs section rodata=".rodata.LINSM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.LINSM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.LINSM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (LINSM_STOP_SEC_CODE)
  #undef       LINSM_STOP_SEC_CODE
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*                             LinNm                                          */
/* -------------------------------------------------------------------------- */
#elif defined (LINNM_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       LINNM_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.LINNM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (LINNM_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       LINNM_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (LINNM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       LINNM_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.LINNM_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (LINNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       LINNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (LINNM_START_SEC_CONST_UNSPECIFIED)
  #undef       LINNM_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.LINNM_ROM_CONST_UNSPECIFIED"
#elif defined (LINNM_STOP_SEC_CONST_UNSPECIFIED)
  #undef       LINNM_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (LINNM_START_SEC_CODE)
  #undef       LINNM_START_SEC_CODE
  #pragma ghs section text=".text.LINNM_CODE"
  #pragma ghs section rodata=".rodata.LINNM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.LINNM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.LINNM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (LINNM_STOP_SEC_CODE)
  #undef       LINNM_STOP_SEC_CODE
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*             FiM                                                            */
/* -------------------------------------------------------------------------- */

#elif defined (FIM_START_SEC_CODE)
  #undef       FIM_START_SEC_CODE
  #pragma ghs section text=".text.FIM_CODE"
  #pragma ghs section rodata=".rodata.FIM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.FIM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.FIM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (FIM_STOP_SEC_CODE)
  #undef       FIM_STOP_SEC_CODE
  #pragma ghs section

#elif defined (FIM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       FIM_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.FIM_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (FIM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       FIM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (FIM_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       FIM_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.FIM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (FIM_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       FIM_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (FIM_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       FIM_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.FIM_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (FIM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       FIM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (FIM_START_SEC_CONST_UNSPECIFIED)
  #undef       FIM_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.FIM_ROM_CONST_UNSPECIFIED"
#elif defined (FIM_STOP_SEC_CONST_UNSPECIFIED)
  #undef       FIM_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section


/* -------------------------------------------------------------------------- */
/*                 FRSM                                                       */
/* -------------------------------------------------------------------------- */
#elif defined (FRSM_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       FRSM_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.FRSM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (FRSM_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       FRSM_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

  #elif defined (FRSM_START_SEC_VAR_CLEARED_8)
  #undef       FRSM_START_SEC_VAR_CLEARED_8
  #pragma ghs section bss=".bss.FRSM_RAM_VAR_CLEARED_8"
#elif defined (FRSM_STOP_SEC_VAR_CLEARED_8)
  #undef       FRSM_STOP_SEC_VAR_CLEARED_8
  #pragma ghs section

#elif defined (FRSM_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       FRSM_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.FRSM_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (FRSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       FRSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (FRSM_START_SEC_VAR_NO_INIT_8)
  #undef       FRSM_START_SEC_VAR_NO_INIT_8
  #pragma ghs section bss=".bss.FRSM_RAM_VAR_NO_INIT_8"
#elif defined (FRSM_STOP_SEC_VAR_NO_INIT_8)
  #undef       FRSM_STOP_SEC_VAR_NO_INIT_8
  #pragma ghs section

#elif defined (FRSM_START_SEC_CONST_UNSPECIFIED)
  #undef       FRSM_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.FRSM_ROM_CONST_UNSPECIFIED"
#elif defined (FRSM_STOP_SEC_CONST_UNSPECIFIED)
  #undef       FRSM_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (FRSM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       FRSM_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.FRSM_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (FRSM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       FRSM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (FRSM_START_SEC_CODE)
  #undef       FRSM_START_SEC_CODE
  #pragma ghs section text=".text.FRSM_CODE"
  #pragma ghs section rodata=".rodata.FRSM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.FRSM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.FRSM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (FRSM_STOP_SEC_CODE)
  #undef       FRSM_STOP_SEC_CODE
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*             FrIf                                                           */
/* -------------------------------------------------------------------------- */
#elif defined (FRIF_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       FRIF_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.FRIF_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (FRIF_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       FRIF_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (FRIF_START_SEC_CONST_UNSPECIFIED)
  #undef       FRIF_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.FRIF_ROM_CONST_UNSPECIFIED"
#elif defined (FRIF_STOP_SEC_CONST_UNSPECIFIED)
  #undef       FRIF_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (FRIF_START_SEC_VAR_NO_INIT_8)
  #undef       FRIF_START_SEC_VAR_NO_INIT_8
  #pragma ghs section bss=".bss.FRIF_RAM_VAR_NO_INIT_8"
#elif defined (FRIF_STOP_SEC_VAR_NO_INIT_8)
  #undef       FRIF_STOP_SEC_VAR_NO_INIT_8
  #pragma ghs section

#elif defined (FRIF_START_SEC_VAR_NO_INIT_8)
  #undef       FRIF_START_SEC_VAR_NO_INIT_8
  #pragma ghs section bss=".bss.FRIF_RAM_VAR_NO_INIT_8"
#elif defined (FRIF_STOP_SEC_VAR_NO_INIT_8)
  #undef       FRIF_STOP_SEC_VAR_NO_INIT_8
  #pragma ghs section

#elif defined (FRIF_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       FRIF_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.FRIF_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (FRIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       FRIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (FRIF_START_SEC_VAR_CLEARED_16)
  #undef       FRIF_START_SEC_VAR_CLEARED_16
  #pragma ghs section bss=".bss.FRIF_RAM_VAR_CLEARED_16"
#elif defined (FRIF_STOP_SEC_VAR_CLEARED_16)
  #undef       FRIF_STOP_SEC_VAR_CLEARED_16
  #pragma ghs section

#elif defined (FRIF_START_SEC_CONST_8)
  #undef       FRIF_START_SEC_CONST_8
  #pragma ghs section rodata=".rodata.FRIF_ROM_CONST_8"
#elif defined (FRIF_STOP_SEC_CONST_8)
  #undef       FRIF_STOP_SEC_CONST_8
  #pragma ghs section

#elif defined (FRIF_START_SEC_CONST_UNSPECIFIED)
  #undef       FRIF_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.FRIF_ROM_CONST_UNSPECIFIED"
#elif defined (FRIF_STOP_SEC_CONST_UNSPECIFIED)
  #undef       FRIF_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (FRIF_START_SEC_CODE)
  #undef       FRIF_START_SEC_CODE
  #pragma ghs section text=".text.FRIF_CODE"
  #pragma ghs section rodata=".rodata.FRIF_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.FRIF_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.FRIF_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (FRIF_STOP_SEC_CODE)
  #undef       FRIF_STOP_SEC_CODE
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*                 CANIF                                                      */
/* -------------------------------------------------------------------------- */
#elif defined (CANIF_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       CANIF_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.CANIF_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (CANIF_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       CANIF_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (CANIF_START_SEC_VAR_CLEARED_8)
  #undef       CANIF_START_SEC_VAR_CLEARED_8
  #pragma ghs section bss=".bss.CANIF_RAM_VAR_CLEARED_8"
#elif defined (CANIF_STOP_SEC_VAR_CLEARED_8)
  #undef       CANIF_STOP_SEC_VAR_CLEARED_8
  #pragma ghs section

#elif defined (CANIF_START_SEC_VAR_NO_INIT_8)
  #undef       CANIF_START_SEC_VAR_NO_INIT_8
  #pragma ghs section bss=".bss.CANIF_RAM_VAR_NO_INIT_8"
#elif defined (CANIF_STOP_SEC_VAR_NO_INIT_8)
  #undef       CANIF_STOP_SEC_VAR_NO_INIT_8
  #pragma ghs section

#elif defined (CANIF_START_SEC_CONST_8)
  #undef       CANIF_START_SEC_CONST_8
  #pragma ghs section rodata=".rodata.CANIF_ROM_CONST_8"
#elif defined (CANIF_STOP_SEC_CONST_8)
  #undef       CANIF_STOP_SEC_CONST_8
  #pragma ghs section

 #elif defined (CANIF_START_SEC_VAR_INIT_UNSPECIFIED)
  #undef       CANIF_START_SEC_VAR_INIT_UNSPECIFIED
  #pragma ghs section data=".data.CANIF_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (CANIF_STOP_SEC_VAR_INIT_UNSPECIFIED)
  #undef       CANIF_STOP_SEC_VAR_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (CANIF_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       CANIF_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.CANIF_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (CANIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       CANIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (CANIF_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       CANIF_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.CANIF_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (CANIF_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       CANIF_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (CANIF_START_SEC_CONST_UNSPECIFIED)
  #undef       CANIF_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.CANIF_ROM_CONST_UNSPECIFIED"
#elif defined (CANIF_STOP_SEC_CONST_UNSPECIFIED)
  #undef       CANIF_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

 #elif defined (CANIF_START_SEC_CODE)
  #undef        CANIF_START_SEC_CODE
  #pragma ghs section text=".text.CANIF_CODE"
  #pragma ghs section rodata=".rodata.CANIF_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.CANIF_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.CANIF_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (CANIF_STOP_SEC_CODE)
  #undef       CANIF_STOP_SEC_CODE
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*                 BswM                                                       */
/* -------------------------------------------------------------------------- */
#elif defined (BSWM_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       BSWM_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.BSWM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (BSWM_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       BSWM_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (BSWM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       BSWM_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.BSWM_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (BSWM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       BSWM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (BSWM_START_SEC_CONST_UNSPECIFIED)
  #undef       BSWM_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.BSWM_ROM_CONST_UNSPECIFIED"
#elif defined (BSWM_STOP_SEC_CONST_UNSPECIFIED)
  #undef       BSWM_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (BSWM_START_SEC_CODE)
  #undef       BSWM_START_SEC_CODE
  #pragma ghs section text=".text.BSWM_CODE"
  #pragma ghs section rodata=".rodata.BSWM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.BSWM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.BSWM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (BSWM_STOP_SEC_CODE)
  #undef       BSWM_STOP_SEC_CODE
  #pragma ghs section

#elif defined (BSWM_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       BSWM_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.BSWM_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (BSWM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       BSWM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*             ComM                                                           */
/* -------------------------------------------------------------------------- */
#elif defined (COMM_START_SEC_VAR_POWER_ON_CLEARED_8)
  #undef       COMM_START_SEC_VAR_POWER_ON_CLEARED_8
  #pragma ghs section bss=".bss.COMM_RAM_VAR_POWER_ON_CLEARED_8"
#elif defined (COMM_STOP_SEC_VAR_POWER_ON_CLEARED_8)
  #undef       COMM_STOP_SEC_VAR_POWER_ON_CLEARED_8
  #pragma ghs section

#elif defined (COMM_START_SEC_VAR_POWER_ON_CLEARED_16)
  #undef       COMM_START_SEC_VAR_POWER_ON_CLEARED_16
  #pragma ghs section bss=".bss.COMM_RAM_VAR_POWER_ON_CLEARED_16"
#elif defined (COMM_STOP_SEC_VAR_POWER_ON_CLEARED_16)
  #undef       COMM_STOP_SEC_VAR_POWER_ON_CLEARED_16
  #pragma ghs section

#elif defined (COMM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
  #undef       COMM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.COMM_RAM_VAR_POWER_ON_CLEARED_UNSPECIFIED"
#elif defined (COMM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
  #undef       COMM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (COMM_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
  #undef       COMM_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.COMM_RAM_VAR_POWER_ON_CLEARED_BOOLEAN"
#elif defined (COMM_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
  #undef       COMM_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (COMM_START_SEC_VAR_CLEARED_8)
  #undef       COMM_START_SEC_VAR_CLEARED_8
  #pragma ghs section bss=".bss.COMM_RAM_VAR_CLEARED_8"
#elif defined (COMM_STOP_SEC_VAR_CLEARED_8)
  #undef       COMM_STOP_SEC_VAR_CLEARED_8
  #pragma ghs section

#elif defined (COMM_START_SEC_VAR_CLEARED_16)
  #undef       COMM_START_SEC_VAR_CLEARED_16
  #pragma ghs section bss=".bss.COMM_RAM_VAR_CLEARED_16"
#elif defined (COMM_STOP_SEC_VAR_CLEARED_16)
  #undef       COMM_STOP_SEC_VAR_CLEARED_16
  #pragma ghs section

#elif defined (COMM_START_SEC_VAR_CLEARED_32)
  #undef       COMM_START_SEC_VAR_CLEARED_32
  #pragma ghs section bss=".bss.COMM_RAM_VAR_CLEARED_32"
#elif defined (COMM_STOP_SEC_VAR_CLEARED_32)
  #undef       COMM_STOP_SEC_VAR_CLEARED_32
  #pragma ghs section

#elif defined (COMM_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       COMM_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.COMM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (COMM_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       COMM_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (COMM_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       COMM_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.COMM_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (COMM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       COMM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (COMM_START_SEC_VAR_NO_INIT_8)
  #undef       COMM_START_SEC_VAR_NO_INIT_8
  #pragma ghs section bss=".bss.COMM_RAM_VAR_NO_INIT_8"
#elif defined (COMM_STOP_SEC_VAR_NO_INIT_8)
  #undef       COMM_STOP_SEC_VAR_NO_INIT_8
  #pragma ghs section

#elif defined (COMM_START_SEC_VAR_NO_INIT_16)
  #undef       COMM_START_SEC_VAR_NO_INIT_16
  #pragma ghs section bss=".bss.COMM_RAM_VAR_NO_INIT_16"
#elif defined (COMM_STOP_SEC_VAR_NO_INIT_16)
  #undef       COMM_STOP_SEC_VAR_NO_INIT_16
  #pragma ghs section

#elif defined (COMM_START_SEC_VAR_NO_INIT_32)
  #undef       COMM_START_SEC_VAR_NO_INIT_32
  #pragma ghs section bss=".bss.COMM_RAM_VAR_NO_INIT_32"
#elif defined (COMM_STOP_SEC_VAR_NO_INIT_32)
  #undef       COMM_STOP_SEC_VAR_NO_INIT_32
  #pragma ghs section

#elif defined (COMM_START_SEC_VAR_SAVED_ZONE_16)
  #undef       COMM_START_SEC_VAR_SAVED_ZONE_16
  #pragma ghs section bss=".bss.COMM_RAM_VAR_SAVED_ZONE_16"
#elif defined (COMM_STOP_SEC_VAR_SAVED_ZONE_16)
  #undef       COMM_STOP_SEC_VAR_SAVED_ZONE_16
  #pragma ghs section

#elif defined (COMM_START_SEC_VAR_SAVED_ZONE_8)
  #undef       COMM_START_SEC_VAR_SAVED_ZONE_8
  #pragma ghs section bss=".bss.COMM_RAM_VAR_SAVED_ZONE_8"
#elif defined (COMM_STOP_SEC_VAR_SAVED_ZONE_8)
  #undef       COMM_STOP_SEC_VAR_SAVED_ZONE_8
  #pragma ghs section

#elif defined (COMM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       COMM_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.COMM_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (COMM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       COMM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (COMM_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
  #undef       COMM_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
  #pragma ghs section bss=".bss.COMM_RAM_VAR_SAVED_ZONE_UNSPECIFIED"
#elif defined (COMM_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
  #undef       COMM_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED
  #pragma ghs section

#elif defined (COMM_START_SEC_CONST_8)
  #undef       COMM_START_SEC_CONST_8
  #pragma ghs section rodata=".rodata.COMM_ROM_CONST_8"
#elif defined (COMM_STOP_SEC_CONST_8)
  #undef       COMM_STOP_SEC_CONST_8
  #pragma ghs section

#elif defined (COMM_START_SEC_CONST_UNSPECIFIED)
  #undef       COMM_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.COMM_ROM_CONST_UNSPECIFIED"
#elif defined (COMM_STOP_SEC_CONST_UNSPECIFIED)
  #undef       COMM_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (COMM_START_SEC_CODE)
  #undef       COMM_START_SEC_CODE
  #pragma ghs section text=".text.COMM_CODE"
  #pragma ghs section rodata=".rodata.COMM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.COMM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.COMM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (COMM_STOP_SEC_CODE)
  #undef       COMM_STOP_SEC_CODE
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*             LINIF                                                          */
/* -------------------------------------------------------------------------- */
#elif defined (LINIF_START_SEC_CODE)
  #undef       LINIF_START_SEC_CODE
  #pragma ghs section text=".text.LINIF_CODE"
  #pragma ghs section rodata=".rodata.LINIF_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.LINIF_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.LINIF_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (LINIF_STOP_SEC_CODE)
  #undef       LINIF_STOP_SEC_CODE
  #pragma ghs section

#elif defined (LINIF_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       LINIF_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.LINIF_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (LINIF_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       LINIF_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (LINIF_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       LINIF_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.LINIF_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (LINIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       LINIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (LINIF_START_SEC_CONST_UNSPECIFIED)
  #undef       LINIF_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.LINIF_ROM_CONST_UNSPECIFIED"
#elif defined (LINIF_STOP_SEC_CONST_UNSPECIFIED)
  #undef       LINIF_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (LINIF_START_SEC_DBTOC_CONST_UNSPECIFIED)
  #undef       LINIF_START_SEC_DBTOC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.LINIF_ROM_CONFIG_UNSPECIFIED"
#elif defined (LINIF_STOP_SEC_DBTOC_CONST_UNSPECIFIED)
  #undef       LINIF_STOP_SEC_DBTOC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (LINIF_START_SEC_CONST_8)
  #undef       LINIF_START_SEC_CONST_8
  #pragma ghs section rodata=".rodata.LINIF_ROM_CONST_8"
#elif defined (LINIF_STOP_SEC_CONST_8)
  #undef       LINIF_STOP_SEC_CONST_8
  #pragma ghs section

#elif defined (LINIF_START_SEC_CONST_UNSPECIFIED)
  #undef       LINIF_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.LINIF_ROM_CONFIG_UNSPECIFIED"
#elif defined (LINIF_STOP_SEC_CONST_UNSPECIFIED)
  #undef       LINIF_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (LINIF_START_SEC_VAR_NO_INIT_8)
  #undef       LINIF_START_SEC_VAR_NO_INIT_8
  #pragma ghs section bss=".bss.LINIF_RAM_VAR_NO_INIT_8"
#elif defined (LINIF_STOP_SEC_VAR_NO_INIT_8)
  #undef       LINIF_STOP_SEC_VAR_NO_INIT_8
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*             LINTP                                                          */
/* -------------------------------------------------------------------------- */

#elif defined (LINTP_START_SEC_CODE)
  #undef       LINTP_START_SEC_CODE
  #pragma ghs section text=".text.LINTP_CODE"
  #pragma ghs section rodata=".rodata.LINTP_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.LINTP_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.LINTP_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (LINTP_STOP_SEC_CODE)
  #undef       LINTP_STOP_SEC_CODE
  #pragma ghs section

#elif defined (LINTP_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       LINTP_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.LINTP_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (LINTP_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       LINTP_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (LINTP_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       LINTP_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.LINTP_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (LINTP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       LINTP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (LINTP_START_SEC_VAR_CLEARED_16)
  #undef       LINTP_START_SEC_VAR_CLEARED_16
  #pragma ghs section bss=".bss.LINTP_RAM_VAR_CLEARED_16"
#elif defined (LINTP_STOP_SEC_VAR_CLEARED_16)
  #undef       LINTP_STOP_SEC_VAR_CLEARED_16
  #pragma ghs section

#elif defined (LINTP_START_SEC_VAR_NO_INIT_8)
  #undef       LINTP_START_SEC_VAR_NO_INIT_8
  #pragma ghs section bss=".bss.LINTP_RAM_VAR_NO_INIT_8"
#elif defined (LINTP_STOP_SEC_VAR_NO_INIT_8)
  #undef       LINTP_STOP_SEC_VAR_NO_INIT_8
  #pragma ghs section

#elif defined (LINTP_START_SEC_DBTOC_CONST_UNSPECIFIED)
  #undef       LINTP_START_SEC_DBTOC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.LINTP_ROM_CONFIG_UNSPECIFIED"
#elif defined (LINTP_STOP_SEC_DBTOC_CONST_UNSPECIFIED)
  #undef       LINTP_STOP_SEC_DBTOC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (LINTP_START_SEC_CONST_UNSPECIFIED)
  #undef       LINTP_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.LINTP_ROM_CONFIG_UNSPECIFIED"
#elif defined (LINTP_STOP_SEC_CONST_UNSPECIFIED)
  #undef       LINTP_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*             Com                                                            */
/* -------------------------------------------------------------------------- */

#elif defined (COM_START_SEC_VAR_POWER_ON_CLEARED_8)
  #undef       COM_START_SEC_VAR_POWER_ON_CLEARED_8
  #pragma ghs section bss=".bss.COM_RAM_VAR_POWER_ON_CLEARED_8"
#elif defined (COM_STOP_SEC_VAR_POWER_ON_CLEARED_8)
  #undef       COM_STOP_SEC_VAR_POWER_ON_CLEARED_8
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_POWER_ON_CLEARED_16)
  #undef       COM_START_SEC_VAR_POWER_ON_CLEARED_16
  #pragma ghs section bss=".bss.COM_RAM_VAR_POWER_ON_CLEARED_16"
#elif defined (COM_STOP_SEC_VAR_POWER_ON_CLEARED_16)
  #undef       COM_STOP_SEC_VAR_POWER_ON_CLEARED_16
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
  #undef       COM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.COM_RAM_VAR_POWER_ON_CLEARED_UNSPECIFIED"
#elif defined (COM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
  #undef       COM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
  #undef       COM_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.COM_RAM_VAR_POWER_ON_CLEARED_BOOLEAN"
#elif defined (COM_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
  #undef       COM_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_CLEARED_8)
  #undef       COM_START_SEC_VAR_CLEARED_8
  #pragma ghs section bss=".bss.COM_RAM_VAR_CLEARED_8"
#elif defined (COM_STOP_SEC_VAR_CLEARED_8)
  #undef       COM_STOP_SEC_VAR_CLEARED_8
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_CLEARED_16)
  #undef       COM_START_SEC_VAR_CLEARED_16
  #pragma ghs section bss=".bss.COM_RAM_VAR_CLEARED_16"
#elif defined (COM_STOP_SEC_VAR_CLEARED_16)
  #undef       COM_STOP_SEC_VAR_CLEARED_16
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       COM_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.COM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (COM_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       COM_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       COM_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.COM_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (COM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       COM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_NOINIT_8)
  #undef       COM_START_SEC_VAR_NOINIT_8
  #pragma ghs section bss=".bss.COM_RAM_VAR_NO_INIT_8"
#elif defined (COM_STOP_SEC_VAR_NOINIT_8)
  #undef       COM_STOP_SEC_VAR_NOINIT_8
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_NOINIT_16)
  #undef       COM_START_SEC_VAR_NOINIT_16
  #pragma ghs section bss=".bss.COM_RAM_VAR_NO_INIT_16"
#elif defined (COM_STOP_SEC_VAR_NOINIT_16)
  #undef       COM_STOP_SEC_VAR_NOINIT_16
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_NOINIT_32)
  #undef       COM_START_SEC_VAR_NOINIT_32
  #pragma ghs section bss=".bss.COM_RAM_VAR_NO_INIT_32"
#elif defined (COM_STOP_SEC_VAR_NOINIT_32)
  #undef       COM_STOP_SEC_VAR_NOINIT_32
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_SAVED_ZONE_16)
  #undef       COM_START_SEC_VAR_SAVED_ZONE_16
  #pragma ghs section bss=".bss.COM_SAVED_RAM_16"
#elif defined (COM_STOP_SEC_VAR_SAVED_ZONE_16)
  #undef       COM_STOP_SEC_VAR_SAVED_ZONE_16
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_SAVED_ZONE_8)
  #undef       COM_START_SEC_VAR_SAVED_ZONE_8
  #pragma ghs section bss=".bss.COM_SAVED_RAM_8"
#elif defined (COM_STOP_SEC_VAR_SAVED_ZONE_8)
  #undef       COM_STOP_SEC_VAR_SAVED_ZONE_8
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
  #undef       COM_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
  #pragma ghs section bss=".bss.COM_SAVED_RAM_UNSPECIFIED"
#elif defined (COM_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
  #undef       COM_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED
  #pragma ghs section

#elif defined (COM_START_SEC_CONST_8)
  #undef       COM_START_SEC_CONST_8
  #pragma ghs section rodata=".rodata.COM_ROM_CONST_8"
#elif defined (COM_STOP_SEC_CONST_8)
  #undef       COM_STOP_SEC_CONST_8
  #pragma ghs section

#elif defined (COM_START_SEC_CONST_16)
  #undef       COM_START_SEC_CONST_16
  #pragma ghs section rodata=".rodata.COM_ROM_CONST_16"
#elif defined (COM_STOP_SEC_CONST_16)
  #undef       COM_STOP_SEC_CONST_16
  #pragma ghs section

#elif defined (COM_START_SEC_CONST_32)
  #undef       COM_START_SEC_CONST_32
  #pragma ghs section rodata=".rodata.COM_ROM_CONST_32"
#elif defined (COM_STOP_SEC_CONST_32)
  #undef       COM_STOP_SEC_CONST_32
  #pragma ghs section

#elif defined (COM_START_SEC_CONST_UNSPECIFIED)
  #undef       COM_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.COM_ROM_CONST_UNSPECIFIED"
#elif defined (COM_STOP_SEC_CONST_UNSPECIFIED)
  #undef       COM_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (COM_START_SEC_CODE)
  #undef       COM_START_SEC_CODE
  #pragma ghs section text=".text.COM_CODE"
  #pragma ghs section rodata=".rodata.COM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.COM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.COM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (COM_STOP_SEC_CODE)
  #undef       COM_STOP_SEC_CODE
  #pragma ghs section

#elif defined (COM_START_SEC_APPL_CODE)
  #undef       COM_START_SEC_APPL_CODE
  #pragma ghs section text=".text.COM_APPL_CODE"
  #pragma ghs section rodata=".rodata.COM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.COM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.COM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (COM_STOP_SEC_APPL_CODE)
  #undef       COM_STOP_SEC_APPL_CODE
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       COM_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.COM_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (COM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       COM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_NOINIT_UNSPECIFIED)
  #undef       COM_START_SEC_VAR_NOINIT_UNSPECIFIED
  #pragma ghs section bss=".bss.COM_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (COM_STOP_SEC_VAR_NOINIT_UNSPECIFIED)
  #undef       COM_STOP_SEC_VAR_NOINIT_UNSPECIFIED
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_NO_INIT_8)
  #undef       COM_START_SEC_VAR_NO_INIT_8
  #pragma ghs section bss=".bss.COM_RAM_VAR_NO_INIT_8"
#elif defined (COM_STOP_SEC_VAR_NO_INIT_8)
  #undef       COM_STOP_SEC_VAR_NO_INIT_8
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_INIT_16)
  #undef       COM_START_SEC_VAR_INIT_16
  #pragma ghs section data=".data.COM_RAM_VAR_INIT_16"
#elif defined (COM_STOP_SEC_VAR_INIT_16)
  #undef       COM_STOP_SEC_VAR_INIT_16
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_NO_INIT_16)
  #undef       COM_START_SEC_VAR_NO_INIT_16
  #pragma ghs section bss=".bss.COM_RAM_VAR_NO_INIT_16"
#elif defined (COM_STOP_SEC_VAR_NO_INIT_16)
  #undef       COM_STOP_SEC_VAR_NO_INIT_16
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_INIT_UNSPECIFIED)
  #undef       COM_START_SEC_VAR_INIT_UNSPECIFIED
  #pragma ghs section data=".data.COM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (COM_STOP_SEC_VAR_INIT_UNSPECIFIED)
  #undef       COM_STOP_SEC_VAR_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_INIT_32)
  #undef       COM_START_SEC_VAR_INIT_32
  #pragma ghs section data=".data.COM_RAM_VAR_INIT_32"
#elif defined (COM_STOP_SEC_VAR_INIT_32)
  #undef       COM_STOP_SEC_VAR_INIT_32
  #pragma ghs section

#elif defined (COM_START_SEC_VAR_INIT_8)
  #undef       COM_START_SEC_VAR_INIT_8
  #pragma ghs section data=".data.COM_RAM_VAR_INIT_8"
#elif defined (COM_STOP_SEC_VAR_INIT_8)
  #undef       COM_STOP_SEC_VAR_INIT_8
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*             			PduR                                                      */
/* -------------------------------------------------------------------------- */
#elif defined (PDUR_START_SEC_CODE)
  #undef       PDUR_START_SEC_CODE
  #pragma ghs section text=".text.PDUR_CODE"
  #pragma ghs section rodata=".rodata.PDUR_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.PDUR_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.PDUR_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (PDUR_STOP_SEC_CODE)
  #undef       PDUR_STOP_SEC_CODE
  #pragma ghs section

#elif defined (PDUR_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       PDUR_START_SEC_VAR_CLEARED_BOOLEAN
	#pragma ghs section bss=".bss.PDUR_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (PDUR_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       PDUR_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (PDUR_START_SEC_VAR_INIT_32)
  #undef       PDUR_START_SEC_VAR_INIT_32
  #pragma ghs section data=".data.PDUR_RAM_VAR_INIT_32"
#elif defined (PDUR_STOP_SEC_VAR_INIT_32)
  #undef       PDUR_STOP_SEC_VAR_INIT_32
  #pragma ghs section

#elif defined (PDUR_START_SEC_CONST_UNSPECIFIED)
  #undef       PDUR_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.PDUR_ROM_CONST_UNSPECIFIED"
#elif defined (PDUR_STOP_SEC_CONST_UNSPECIFIED)
  #undef       PDUR_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (PDUR_START_SEC_VAR_INIT_UNSPECIFIED)
  #undef       PDUR_START_SEC_VAR_INIT_UNSPECIFIED
  #pragma ghs section data=".data.PDUR_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (PDUR_STOP_SEC_VAR_INIT_UNSPECIFIED)
  #undef       PDUR_STOP_SEC_VAR_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (PDUR_START_SEC_VAR_CLEARED_8)
  #undef       PDUR_START_SEC_VAR_CLEARED_8
  #pragma ghs section bss=".bss.PDUR_RAM_VAR_CLEARED_8"
#elif defined (PDUR_STOP_SEC_VAR_CLEARED_8)
  #undef       PDUR_STOP_SEC_VAR_CLEARED_8
  #pragma ghs section

#elif defined (PDUR_START_SEC_VAR_NO_INIT_8)
  #undef       PDUR_START_SEC_VAR_NO_INIT_8
  #pragma ghs section bss=".bss.PDUR_RAM_VAR_NO_INIT_8"
#elif defined (PDUR_STOP_SEC_VAR_NO_INIT_8)
  #undef       PDUR_STOP_SEC_VAR_NO_INIT_8
  #pragma ghs section

#elif defined (PDUR_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       PDUR_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.PDUR_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (PDUR_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       PDUR_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (PDUR_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       PDUR_START_SEC_VAR_CLEARED_UNSPECIFIED
	#pragma ghs section bss=".bss.PDUR_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (PDUR_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       PDUR_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (PDUR_START_SEC_VAR_NO_INIT_16)
  #undef       PDUR_START_SEC_VAR_NO_INIT_16
  #pragma ghs section bss=".bss.PDUR_RAM_VAR_NO_INIT_16"
#elif defined (PDUR_STOP_SEC_VAR_NO_INIT_16)
  #undef       PDUR_STOP_SEC_VAR_NO_INIT_16
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*             IpduM                                                          */
/* -------------------------------------------------------------------------- */
#elif defined (IPDUM_START_SEC_VAR_NO_INIT_BOOLEAN)
  #undef       IPDUM_START_SEC_VAR_NO_INIT_BOOLEAN
  #pragma ghs section bss=".bss.IPDUM_RAM_VAR_NO_INIT_BOOLEAN"
#elif defined (IPDUM_STOP_SEC_VAR_NO_INIT_BOOLEAN)
  #undef       IPDUM_STOP_SEC_VAR_NO_INIT_BOOLEAN
  #pragma ghs section

#elif defined (IPDUM_START_SEC_VAR_NO_INIT_8)
  #undef       IPDUM_START_SEC_VAR_NO_INIT_8
  #pragma ghs section bss=".bss.IPDUM_RAM_VAR_NO_INIT_8"
#elif defined (IPDUM_STOP_SEC_VAR_NO_INIT_8)
  #undef       IPDUM_STOP_SEC_VAR_NO_INIT_8
  #pragma ghs section

#elif defined (IPDUM_START_SEC_VAR_NO_INIT_16)
  #undef       IPDUM_START_SEC_VAR_NO_INIT_16
  #pragma ghs section bss=".bss.IPDUM_RAM_VAR_NO_INIT_16"
#elif defined (IPDUM_STOP_SEC_VAR_NO_INIT_16)
  #undef       IPDUM_STOP_SEC_VAR_NO_INIT_16
  #pragma ghs section

#elif defined (IPDUM_START_SEC_VAR_NO_INIT_32)
  #undef       IPDUM_START_SEC_VAR_NO_INIT_32
  #pragma ghs section bss=".bss.IPDUM_RAM_VAR_NO_INIT_32"
#elif defined (IPDUM_STOP_SEC_VAR_NO_INIT_32)
  #undef       IPDUM_STOP_SEC_VAR_NO_INIT_32
  #pragma ghs section

#elif defined (IPDUM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       IPDUM_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.IPDUM_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (IPDUM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       IPDUM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (IPDUM_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       IPDUM_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.IPDUM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (IPDUM_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       IPDUM_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (IPDUM_START_SEC_VAR_CLEARED_8)
  #undef       IPDUM_START_SEC_VAR_CLEARED_8
  #pragma ghs section bss=".bss.IPDUM_RAM_VAR_CLEARED_8"
#elif defined (IPDUM_STOP_SEC_VAR_CLEARED_8)
  #undef       IPDUM_STOP_SEC_VAR_CLEARED_8
  #pragma ghs section

#elif defined (IPDUM_START_SEC_VAR_CLEARED_16)
  #undef       IPDUM_START_SEC_VAR_CLEARED_16
  #pragma ghs section bss=".bss.IPDUM_RAM_VAR_CLEARED_16"
#elif defined (IPDUM_STOP_SEC_VAR_CLEARED_16)
  #undef       IPDUM_STOP_SEC_VAR_CLEARED_16
  #pragma ghs section

#elif defined (IPDUM_START_SEC_VAR_CLEARED_32)
  #undef       IPDUM_START_SEC_VAR_CLEARED_32
  #pragma ghs section bss=".bss.IPDUM_RAM_VAR_CLEARED_32"
#elif defined (IPDUM_STOP_SEC_VAR_CLEARED_32)
  #undef       IPDUM_STOP_SEC_VAR_CLEARED_32
  #pragma ghs section

#elif defined (IPDUM_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       IPDUM_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.IPDUM_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (IPDUM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       IPDUM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (IPDUM_START_SEC_VAR_INIT_BOOLEAN)
  #undef       IPDUM_START_SEC_VAR_INIT_BOOLEAN
  #pragma ghs section data=".data.IPDUM_RAM_VAR_INIT_BOOLEAN"
#elif defined (IPDUM_STOP_SEC_VAR_INIT_BOOLEAN)
  #undef       IPDUM_STOP_SEC_VAR_INIT_BOOLEAN
  #pragma ghs section

#elif defined (IPDUM_START_SEC_VAR_INIT_8)
  #undef       IPDUM_START_SEC_VAR_INIT_8
  #pragma ghs section data=".data.IPDUM_RAM_VAR_INIT_8"
#elif defined (IPDUM_STOP_SEC_VAR_INIT_8)
  #undef       IPDUM_STOP_SEC_VAR_INIT_8
  #pragma ghs section

#elif defined (IPDUM_START_SEC_VAR_INIT_16)
  #undef       IPDUM_START_SEC_VAR_INIT_16
  #pragma ghs section data=".data.IPDUM_RAM_VAR_INIT_16"
#elif defined (IPDUM_STOP_SEC_VAR_INIT_16)
  #undef       IPDUM_STOP_SEC_VAR_INIT_16
  #pragma ghs section

#elif defined (IPDUM_START_SEC_VAR_INIT_32)
  #undef       IPDUM_START_SEC_VAR_INIT_32
  #pragma ghs section data=".data.IPDUM_RAM_VAR_INIT_32"
#elif defined (IPDUM_STOP_SEC_VAR_INIT_32)
  #undef       IPDUM_STOP_SEC_VAR_INIT_32
  #pragma ghs section

#elif defined (IPDUM_START_SEC_VAR_INIT_UNSPECIFIED)
  #undef       IPDUM_START_SEC_VAR_INIT_UNSPECIFIED
  #pragma ghs section data=".data.IPDUM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (IPDUM_STOP_SEC_VAR_INIT_UNSPECIFIED)
  #undef       IPDUM_STOP_SEC_VAR_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (IPDUM_START_SEC_CONST_BOOLEAN)
  #undef       IPDUM_START_SEC_CONST_BOOLEAN
  #pragma ghs section rodata=".rodata.IPDUM_ROM_CONST_BOOLEAN"
#elif defined (IPDUM_STOP_SEC_CONST_BOOLEAN)
  #undef       IPDUM_STOP_SEC_CONST_BOOLEAN
  #pragma ghs section

#elif defined (IPDUM_START_SEC_CONST_8)
  #undef       IPDUM_START_SEC_CONST_8
  #pragma ghs section rodata=".rodata.IPDUM_ROM_CONST_8"
#elif defined (IPDUM_STOP_SEC_CONST_8)
  #undef       IPDUM_STOP_SEC_CONST_8
  #pragma ghs section

#elif defined (IPDUM_START_SEC_CONST_16)
  #undef       IPDUM_START_SEC_CONST_16
  #pragma ghs section rodata=".rodata.IPDUM_ROM_CONST_16"
#elif defined (IPDUM_STOP_SEC_CONST_16)
  #undef       IPDUM_STOP_SEC_CONST_16
  #pragma ghs section

#elif defined (IPDUM_START_SEC_CONST_UNSPECIFIED)
  #undef       IPDUM_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.IPDUM_ROM_CONST_UNSPECIFIED"
#elif defined (IPDUM_STOP_SEC_CONST_UNSPECIFIED)
  #undef       IPDUM_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (IPDUM_START_SEC_CODE)
  #undef       IPDUM_START_SEC_CODE
  #pragma ghs section text=".text.IPDUM_CODE"
  #pragma ghs section rodata=".rodata.IPDUM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.IPDUM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.IPDUM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (IPDUM_STOP_SEC_CODE)
  #undef       IPDUM_STOP_SEC_CODE
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*             			CanSM                                                     */
/* -------------------------------------------------------------------------- */
#elif defined (CANSM_START_SEC_CODE)
  #undef       CANSM_START_SEC_CODE
  #pragma ghs section text=".text.CANSM_CODE"
  #pragma ghs section rodata=".rodata.CANSM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.CANSM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.CANSM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (CANSM_STOP_SEC_CODE)
  #undef       CANSM_STOP_SEC_CODE
  #pragma ghs section

#elif defined (CANSM_START_SEC_CONST_UNSPECIFIED)
  #undef       CANSM_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.CANSM_ROM_CONST_UNSPECIFIED"
#elif defined (CANSM_STOP_SEC_CONST_UNSPECIFIED)
  #undef       CANSM_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (CANSM_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       CANSM_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.CANSM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (CANSM_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       CANSM_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (CANSM_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       CANSM_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.CANSM_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (CANSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       CANSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*             			CanNM                                                     */
/* -------------------------------------------------------------------------- */
#elif defined (CANNM_START_SEC_CONST_UNSPECIFIED)
  #undef       CANNM_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.CANNM_ROM_CONST_UNSPECIFIED"
#elif defined (CANNM_STOP_SEC_CONST_UNSPECIFIED)
  #undef       CANNM_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (CANNM_START_SEC_CODE)
  #undef       CANNM_START_SEC_CODE
  #pragma ghs section text=".text.CANNM_CODE"
  #pragma ghs section rodata=".rodata.CANNM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.CANNM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.CANNM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (CANNM_STOP_SEC_CODE)
  #undef       CANNM_STOP_SEC_CODE
  #pragma ghs section

#elif defined (CANNM_START_SEC_CONST_8)
  #undef       CANNM_START_SEC_CONST_8
  #pragma ghs section rodata=".rodata.CANNM_ROM_CONST_8"
#elif defined (CANNM_STOP_SEC_CONST_8)
  #undef       CANNM_STOP_SEC_CONST_8
  #pragma ghs section

#elif defined (CANNM_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       CANNM_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.CANNM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (CANNM_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       CANNM_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (CANNM_START_SEC_VAR_UNSPECIFIED)
  #undef       CANNM_START_SEC_VAR_UNSPECIFIED
  #pragma ghs section bss=".bss.CANNM_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (CANNM_STOP_SEC_VAR_UNSPECIFIED)
  #undef       CANNM_STOP_SEC_VAR_UNSPECIFIED
  #pragma ghs section

#elif defined (CANNM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       CANNM_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.CANNM_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (CANNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       CANNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (CANNM_START_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED)
  #undef       CANNM_START_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.CANNM_ROM_CONFIG_UNSPECIFIED"
#elif defined (CANNM_STOP_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED)
  #undef       CANNM_STOP_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*             			CanCM                                                     */
/* -------------------------------------------------------------------------- */
#elif defined (CANCM_START_SEC_CONST_UNSPECIFIED)
  #undef      CANCM_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.CANCM_ROM_CONST_UNSPECIFIED"
#elif defined (CANCM_STOP_SEC_CONST_UNSPECIFIED)
  #undef      CANCM_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section
#elif defined (CANCM_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef      CANCM_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.CANCM_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (CANCM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef      CANCM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section
#elif defined (CANCM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef      CANCM_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.CANCM_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (CANCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef      CANCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section
#elif defined (CANCM_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef      CANCM_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.CANCM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (CANCM_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef      CANCM_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section
#elif defined (CANCM_START_SEC_CODE)
  #undef      CANCM_START_SEC_CODE
  #pragma ghs section text=".text.CANCM_CODE"
  #pragma ghs section rodata=".rodata.CANCM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.CANCM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.CANCM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (CANCM_STOP_SEC_CODE)
  #undef      CANCM_STOP_SEC_CODE
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*             			OSEKNm                                                    */
/* -------------------------------------------------------------------------- */
#elif defined (OSEKNM_START_SEC_CONST_UNSPECIFIED)
  #undef       OSEKNM_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.OSEKNM_ROM_CONST_UNSPECIFIED"
#elif defined (OSEKNM_STOP_SEC_CONST_UNSPECIFIED)
  #undef       OSEKNM_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (OSEKNM_START_SEC_CODE)
  #undef       OSEKNM_START_SEC_CODE
  #pragma ghs section text=".text.OSEKNM_CODE"
  #pragma ghs section rodata=".rodata.OSEKNM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.OSEKNM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.OSEKNM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (OSEKNM_STOP_SEC_CODE)
  #undef       OSEKNM_STOP_SEC_CODE
  #pragma ghs section

#elif defined (OSEKNM_START_SEC_CONST_8)
  #undef       OSEKNM_START_SEC_CONST_8
  #pragma ghs section rodata=".rodata.OSEKNM_ROM_CONST_8"
#elif defined (OSEKNM_STOP_SEC_CONST_8)
  #undef       OSEKNM_STOP_SEC_CONST_8
  #pragma ghs section

#elif defined (OSEKNM_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       OSEKNM_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.OSEKNM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (OSEKNM_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       OSEKNM_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (OSEKNM_START_SEC_VAR_UNSPECIFIED)
  #undef       OSEKNM_START_SEC_VAR_UNSPECIFIED
  #pragma ghs section bss=".bss.OSEKNM_RAM_VAR_CLEARED_UNSPECIFIED"
 #elif defined (OSEKNM_STOP_SEC_VAR_UNSPECIFIED)
  #undef       OSEKNM_STOP_SEC_VAR_UNSPECIFIED
  #pragma ghs section

#elif defined (OSEKNM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       OSEKNM_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.OSEKNM_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (OSEKNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       OSEKNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (OSEKNM_START_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED)
  #undef       OSEKNM_START_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.OSEKNM_ROM_CONFIG_UNSPECIFIED"
#elif defined (OSEKNM_STOP_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED)
  #undef       OSEKNM_STOP_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*             			ECUM                                                      */
/* -------------------------------------------------------------------------- */
#elif defined (ECUM_START_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED)
  #undef       ECUM_START_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.ECUM_ROM_CONFIG_UNSPECIFIED"
#elif defined (ECUM_STOP_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED)
  #undef       ECUM_STOP_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (ECUM_START_SEC_CODE)
  #undef       ECUM_START_SEC_CODE
  #pragma ghs section text=".text.ECUM_CODE"
  #pragma ghs section rodata=".rodata.ECUM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.ECUM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.ECUM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (ECUM_STOP_SEC_CODE)
  #undef       ECUM_STOP_SEC_CODE
  #pragma ghs section

#elif defined (ECUM_START_SEC_CONFIG_CONST_32)
  #undef       ECUM_START_SEC_CONFIG_CONST_32
  #pragma ghs section rodata=".rodata.ECUM_ROM_CONFIG_CONST_32"
#elif defined (ECUM_STOP_SEC_CONFIG_CONST_32)
  #undef       ECUM_STOP_SEC_CONFIG_CONST_32
  #pragma ghs section

#elif defined (ECUM_START_SEC_CONST_32)
  #undef       ECUM_START_SEC_CONST_32
  #pragma ghs section rodata=".rodata.ECUM_ROM_CONST_32"
#elif defined (ECUM_STOP_SEC_CONST_32)
  #undef       ECUM_STOP_SEC_CONST_32
  #pragma ghs section

#elif defined (ECUM_START_SEC_CONST_16)
  #undef       ECUM_START_SEC_CONST_16
  #pragma ghs section rodata=".rodata.ECUM_ROM_CONST_16"
#elif defined (ECUM_STOP_SEC_CONST_16)
  #undef       ECUM_STOP_SEC_CONST_16
  #pragma ghs section
  
#elif defined (ECUM_START_SEC_CONST_8)
  #undef       ECUM_START_SEC_CONST_8
  #pragma ghs section rodata=".rodata.ECUM_ROM_CONST_8"
#elif defined (ECUM_STOP_SEC_CONST_8)
  #undef       ECUM_STOP_SEC_CONST_8
  #pragma ghs section

#elif defined (ECUM_START_SEC_CONST_UNSPECIFIED)
  #undef       ECUM_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.ECUM_ROM_CONST_UNSPECIFIED"
#elif defined (ECUM_STOP_SEC_CONST_UNSPECIFIED)
  #undef       ECUM_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (ECUM_START_SEC_CALLOUT_CODE)
  #undef       ECUM_START_SEC_CALLOUT_CODE
  #pragma ghs section text=".text.ECUM_CALLOUT_CODE"
  #pragma ghs section rodata=".rodata.ECUM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.ECUM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.ECUM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (ECUM_STOP_SEC_CALLOUT_CODE)
  #undef       ECUM_STOP_SEC_CALLOUT_CODE
  #pragma ghs section

#elif defined (ECUM_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       ECUM_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.ECUM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (ECUM_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       ECUM_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (ECUM_START_SEC_VAR_CLEARED_32)
  #undef       ECUM_START_SEC_VAR_CLEARED_32
  #pragma ghs section bss=".bss.ECUM_RAM_VAR_CLEARED_32"
#elif defined (ECUM_STOP_SEC_VAR_CLEARED_32)
  #undef       ECUM_STOP_SEC_VAR_CLEARED_32
  #pragma ghs section

#elif defined (ECUM_START_SEC_VAR_CLEARED_16)
  #undef       ECUM_START_SEC_VAR_CLEARED_16
  #pragma ghs section bss=".bss.ECUM_RAM_VAR_CLEARED_16"
#elif defined (ECUM_STOP_SEC_VAR_CLEARED_16)
  #undef       ECUM_STOP_SEC_VAR_CLEARED_16
  #pragma ghs section
  
#elif defined (ECUM_START_SEC_VAR_CLEARED_8)
  #undef       ECUM_START_SEC_VAR_CLEARED_8
  #pragma ghs section bss=".bss.ECUM_RAM_VAR_CLEARED_8"
#elif defined (ECUM_STOP_SEC_VAR_CLEARED_8)
  #undef       ECUM_STOP_SEC_VAR_CLEARED_8
  #pragma ghs section  

#elif defined (ECUM_START_SEC_VAR_NO_INIT_8)
  #undef       ECUM_START_SEC_VAR_NO_INIT_8
  #pragma ghs section bss=".bss.ECUM_RAM_VAR_NO_INIT_8"
#elif defined (ECUM_STOP_SEC_VAR_NO_INIT_8)
  #undef       ECUM_STOP_SEC_VAR_NO_INIT_8
  #pragma ghs section

#elif defined (ECUM_START_SEC_VAR_POWER_ON_CLEARED_32)
   #undef      ECUM_START_SEC_VAR_POWER_ON_CLEARED_32
   #pragma ghs section bss=".bss.ECUM_RAM_VAR_POWER_ON_CLEARED_32"
#elif defined (ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_32)
   #undef      ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_32
  #pragma ghs section
#elif defined (ECUM_START_SEC_VAR_POWER_ON_CLEARED_16)
  #undef       ECUM_START_SEC_VAR_POWER_ON_CLEARED_16
  #pragma ghs section bss=".bss.ECUM_RAM_VAR_POWER_ON_CLEARED_16"
#elif defined (ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_16)
  #undef       ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_16
  #pragma ghs section
#elif defined (ECUM_START_SEC_VAR_POWER_ON_CLEARED_8)
  #undef       ECUM_START_SEC_VAR_POWER_ON_CLEARED_8
  #pragma ghs section bss=".bss.ECUM_RAM_VAR_POWER_ON_CLEARED_8"
#elif defined (ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_8)
  #undef       ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_8
  #pragma ghs section  
#elif defined (ECUM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
   #undef      ECUM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
   #pragma ghs section bss=".bss.ECUM_RAM_VAR_POWER_ON_CLEARED_UNSPECIFIED"
#elif defined (ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
   #undef      ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (ECUM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       ECUM_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.ECUM_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (ECUM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       ECUM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (ECUM_START_SEC_CONST_UNSPECIFIED)
   #undef      ECUM_START_SEC_CONST_UNSPECIFIED
   #pragma ghs section bss=".bss.ECUM_RAM_CONST_UNSPECIFIED"
#elif defined (ECUM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      ECUM_STOP_SEC_CONST_UNSPECIFIED
   #pragma ghs section
#elif defined (ECUM_START_SEC_CODE)
   #undef      ECUM_START_SEC_CODE
   #pragma ghs section bss=".bss.ECUM_RAM_CODE"
#elif defined (ECUM_STOP_SEC_CODE)
   #undef      ECUM_STOP_SEC_CODE
   #pragma ghs section
#elif defined (ECUM_START_SEC_CALLOUT_CODE)
   #undef      ECUM_START_SEC_CALLOUT_CODE
   #pragma ghs section bss=".bss.ECUM_RAM_CALLOUT_CODE"
#elif defined (ECUM_STOP_SEC_CALLOUT_CODE)
   #undef      ECUM_STOP_SEC_CALLOUT_CODE
   #pragma ghs section

#elif defined (ECUM_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
  #undef      ECUM_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
  #pragma ghs section bss=".bss.ECUM_RAM_VAR_SAVED_ZONE_UNSPECIFIED"
#elif defined (ECUM_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
  #undef      ECUM_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED
  #pragma ghs section

#elif defined (ECUM_START_SEC_CONFIG_DATA_UNSPECIFIED)
  #undef      ECUM_START_SEC_CONFIG_DATA_UNSPECIFIED
  #pragma ghs section bss=".bss.ECUM_RAM_CONFIG_DATA_UNSPECIFIED"
#elif defined (ECUM_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
  #undef      ECUM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*                 NM                                                         */
/* -------------------------------------------------------------------------- */

#elif defined (NM_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       NM_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.NM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (NM_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       NM_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (NM_START_SEC_VAR_POWER_ON_INIT_8)
  #undef       NM_START_SEC_VAR_POWER_ON_INIT_8
  #pragma ghs section data=".data.NM_RAM_VAR_INIT_8"
#elif defined (NM_STOP_SEC_VAR_POWER_ON_INIT_8)
  #undef       NM_STOP_SEC_VAR_POWER_ON_INIT_8
  #pragma ghs section

#elif defined (NM_START_SEC_VAR_POWER_ON_INIT_16)
  #undef       NM_START_SEC_VAR_POWER_ON_INIT_16
  #pragma ghs section data=".data.NM_RAM_VAR_INIT_16"
#elif defined (NM_STOP_SEC_VAR_POWER_ON_INIT_16)
  #undef       NM_STOP_SEC_VAR_POWER_ON_INIT_16
  #pragma ghs section

#elif defined (NM_START_SEC_CONST_UNSPECIFIED)
  #undef       NM_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.NM_ROM_CONST_UNSPECIFIED"
#elif defined (NM_STOP_SEC_CONST_UNSPECIFIED)
  #undef       NM_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (NM_START_SEC_CODE)
  #undef       NM_START_SEC_CODE
  #pragma ghs section text=".text.NM_CODE"
  #pragma ghs section rodata=".rodata.NM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.NM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.NM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (NM_STOP_SEC_CODE)
  #undef       NM_STOP_SEC_CODE
  #pragma ghs section

#elif defined (NM_START_SEC_VAR_NO_INIT_8)
  #undef       NM_START_SEC_VAR_NO_INIT_8
  #pragma ghs section bss=".bss.NM_RAM_VAR_NO_INIT_8"
#elif defined (NM_STOP_SEC_VAR_NO_INIT_8)
  #undef       NM_STOP_SEC_VAR_NO_INIT_8
  #pragma ghs section

/*----------------------------------------------------------------------------*/
/*                           E2E                                              */
/*----------------------------------------------------------------------------*/

#elif defined (E2E_START_SEC_CODE)
  #undef      E2E_START_SEC_CODE
  #pragma ghs section text=".text.E2E_CODE"
  #pragma ghs section rodata=".rodata.E2E_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.E2E_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.E2E_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (E2E_STOP_SEC_CODE)
  #undef      E2E_STOP_SEC_CODE
  #pragma ghs section
/* -------------------------------------------------------------------------- */
/*                                 MemIf                                      */
/* -------------------------------------------------------------------------- */

#elif defined (MEMIF_START_SEC_CODE)
  #undef       MEMIF_START_SEC_CODE
  #pragma ghs section text=".text.MEMIF_CODE"
  #pragma ghs section rodata=".rodata.MEMIF_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.MEMIF_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.MEMIF_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (MEMIF_STOP_SEC_CODE)
  #undef       MEMIF_STOP_SEC_CODE
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*                                 Crc                                        */
/* -------------------------------------------------------------------------- */

#elif defined (CRC_START_SEC_CODE)
  #undef       CRC_START_SEC_CODE
  #pragma ghs section text=".text.CRC_CODE"
  #pragma ghs section rodata=".rodata.CRC_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.CRC_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.CRC_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (CRC_STOP_SEC_CODE)
  #undef       CRC_STOP_SEC_CODE
  #pragma ghs section

#elif defined (CRC_START_SEC_CONST_8)
  #undef       CRC_START_SEC_CONST_8
  #pragma ghs section rodata=".rodata.CRC_ROM_CONST_8"
#elif defined (CRC_STOP_SEC_CONST_8)
  #undef       CRC_STOP_SEC_CONST_8
  #pragma ghs section

#elif defined (CRC_START_SEC_CONST_16)
  #undef       CRC_START_SEC_CONST_16
  #pragma ghs section rodata=".rodata.CRC_ROM_CONST_16"
#elif defined (CRC_STOP_SEC_CONST_16)
  #undef       CRC_STOP_SEC_CONST_16
  #pragma ghs section

#elif defined (CRC_START_SEC_CONST_32)
  #undef       CRC_START_SEC_CONST_32
  #pragma ghs section rodata=".rodata.CRC_ROM_CONST_32"
#elif defined (CRC_STOP_SEC_CONST_32)
  #undef       CRC_STOP_SEC_CONST_32
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*                                 NvM                                        */
/* -------------------------------------------------------------------------- */
#elif defined (NVM_START_SEC_CODE)
  #undef       NVM_START_SEC_CODE
  #pragma ghs section text=".text.NVM_CODE"
  #pragma ghs section rodata=".rodata.NVM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.NVM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.NVM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (NVM_STOP_SEC_CODE)
  #undef       NVM_STOP_SEC_CODE
  #pragma ghs section

#elif defined (NVM_START_SEC_CONST_UNSPECIFIED)
  #undef       NVM_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.NVM_ROM_CONST_UNSPECIFIED"
#elif defined (NVM_STOP_SEC_CONST_UNSPECIFIED)
  #undef       NVM_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (NVM_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       NVM_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.NVM_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (NVM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       NVM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (NVM_START_SEC_VAR_CLEARED_16)
  #undef       NVM_START_SEC_VAR_CLEARED_16
  #pragma ghs section bss=".bss.NVM_RAM_VAR_CLEARED_16"
#elif defined (NVM_STOP_SEC_VAR_CLEARED_16)
  #undef       NVM_STOP_SEC_VAR_CLEARED_16
  #pragma ghs section

#elif defined (NVM_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       NVM_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.NVM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (NVM_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       NVM_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (NVM_START_SEC_VAR_NO_INIT_32)
  #undef       NVM_START_SEC_VAR_NO_INIT_32
  #pragma ghs section bss=".bss.NVM_RAM_VAR_NO_INIT_32"
#elif defined (NVM_STOP_SEC_VAR_NO_INIT_32)
  #undef       NVM_STOP_SEC_VAR_NO_INIT_32
  #pragma ghs section

#elif defined (NVM_START_SEC_VAR_NO_INIT_16)
  #undef       NVM_START_SEC_VAR_NO_INIT_16
  #pragma ghs section bss=".bss.NVM_RAM_VAR_NO_INIT_16"
#elif defined (NVM_STOP_SEC_VAR_NO_INIT_16)
  #undef       NVM_STOP_SEC_VAR_NO_INIT_16
  #pragma ghs section

#elif defined (NVM_START_SEC_VAR_NO_INIT_8)
  #undef       NVM_START_SEC_VAR_NO_INIT_8
  #pragma ghs section bss=".bss.NVM_RAM_VAR_NO_INIT_8"
#elif defined (NVM_STOP_SEC_VAR_NO_INIT_8)
  #undef       NVM_STOP_SEC_VAR_NO_INIT_8
  #pragma ghs section

#elif defined (NVM_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
  #undef       NVM_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.NVM_RAM_VAR_POWER_ON_CLEARED_BOOLEAN"
#elif defined (NVM_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
  #undef       NVM_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (NVM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
  #undef       NVM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.NVM_RAM_VAR_POWER_ON_CLEARED_UNSPECIFIED"
#elif defined (NVM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
  #undef       NVM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (NVM_START_SEC_VAR_POWER_ON_CLEARED_16)
  #undef       NVM_START_SEC_VAR_POWER_ON_CLEARED_16
  #pragma ghs section bss=".bss.NVM_RAM_VAR_POWER_ON_CLEARED_16"
#elif defined (NVM_STOP_SEC_VAR_POWER_ON_CLEARED_16)
  #undef       NVM_STOP_SEC_VAR_POWER_ON_CLEARED_16
  #pragma ghs section

#elif defined (NVM_START_SEC_VAR_POWER_ON_CLEARED_8)
  #undef       NVM_START_SEC_VAR_POWER_ON_CLEARED_8
  #pragma ghs section bss=".bss.NVM_RAM_VAR_POWER_ON_CLEARED_8"
#elif defined (NVM_STOP_SEC_VAR_POWER_ON_CLEARED_8)
  #undef       NVM_STOP_SEC_VAR_POWER_ON_CLEARED_8
  #pragma ghs section

#elif defined (NVM_START_SEC_VAR_NO_INIT_BOOLEAN)
  #undef       NVM_START_SEC_VAR_NO_INIT_BOOLEAN
  #pragma ghs section bss=".bss.NVM_RAM_VAR_NO_INIT_BOOLEAN"
#elif defined (NVM_STOP_SEC_VAR_NO_INIT_BOOLEAN)
  #undef       NVM_STOP_SEC_VAR_NO_INIT_BOOLEAN
  #pragma ghs section

#elif defined (NVM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      NVM_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.NVM_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (NVM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      NVM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (NVM_START_SEC_CONST_8)
  #undef       NVM_START_SEC_CONST_8
  #pragma ghs section rodata=".rodata.NVM_ROM_CONST_8"
#elif defined (NVM_STOP_SEC_CONST_8)
  #undef       NVM_STOP_SEC_CONST_8
  #pragma ghs section
  
#elif defined (NVM_START_SEC_CONST_16)
  #undef      NVM_START_SEC_CONST_16
  #pragma ghs section rodata=".rodata.NVM_ROM_CONST_16"
#elif defined (NVM_STOP_SEC_CONST_16)
  #undef      NVM_STOP_SEC_CONST_16
  #pragma ghs section
   
#elif defined (NVM_START_SEC_VAR_INIT_8)
  #undef      NVM_START_SEC_VAR_INIT_8
  #pragma ghs section bss=".bss.NVM_RAM_VAR_INIT_8"
#elif defined (NVM_STOP_SEC_VAR_INIT_8)
  #undef      NVM_STOP_SEC_VAR_INIT_8
  #pragma ghs section
  
/* -------------------------------------------------------------------------- */
/*                           RamTst                                           */
/* -------------------------------------------------------------------------- */
#elif defined (RAMTST_START_SEC_CODE)
  #undef      RAMTST_START_SEC_CODE
  #pragma ghs section text=".text.RAMTST_CODE"
  #pragma ghs section rodata=".rodata.RAMTST_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.RAMTST_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.RAMTST_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (RAMTST_STOP_SEC_CODE)
   #undef      RAMTST_STOP_SEC_CODE
  #pragma ghs section
  
#elif defined (RAMTST_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef      RAMTST_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.RAMTST_RAM_VAR_POWER_ON_CLEARED_BOOLEAN"
#elif defined (RAMTST_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef      RAMTST_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section
   
#elif defined (RAMTST_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef      RAMTST_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.RAMTST_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (RAMTST_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef      RAMTST_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section
  
#elif defined (RAMTST_START_SEC_CONST_UNSPECIFIED)
  #undef      RAMTST_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.RAMTST_ROM_CONST_UNSPECIFIED"
#elif defined (RAMTST_STOP_SEC_CONST_UNSPECIFIED)
  #undef      RAMTST_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (RAMTST_START_SEC_VAR_CLEARED_8)
  #undef      RAMTST_START_SEC_VAR_CLEARED_8
  #pragma ghs section bss=".bss.RAMTST_RAM_VAR_CLEARED_8"
#elif defined (RAMTST_STOP_SEC_VAR_CLEARED_8)
   #undef      RAMTST_STOP_SEC_VAR_CLEARED_8
  #pragma ghs section
/* -------------------------------------------------------------------------- */
/*                                 Eep                                        */
/* -------------------------------------------------------------------------- */
#elif defined (EEP_START_SEC_CODE)
  #undef       EEP_START_SEC_CODE
  #pragma ghs section text=".text.EEP_CODE"
  #pragma ghs section rodata=".rodata.EEP_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.EEP_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.EEP_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (EEP_STOP_SEC_CODE)
  #undef       EEP_STOP_SEC_CODE
  #pragma ghs section

#elif defined (EEP_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       EEP_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.EEP_RAM_VAR_POWER_ON_CLEARED_BOOLEAN"
#elif defined (EEP_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       EEP_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (EEP_START_SEC_VAR_CLEARED_8)
  #undef       EEP_START_SEC_VAR_CLEARED_8
  #pragma ghs section bss=".bss.EEP_RAM_VAR_POWER_ON_CLEARED_8"
#elif defined (EEP_STOP_SEC_VAR_CLEARED_8)
  #undef       EEP_STOP_SEC_VAR_CLEARED_8
  #pragma ghs section

#elif defined (EEP_START_SEC_VAR_CLEARED_16)
  #undef       EEP_START_SEC_VAR_CLEARED_16
  #pragma ghs section bss=".bss.EEP_RAM_VAR_POWER_ON_CLEARED_16"
#elif defined (EEP_STOP_SEC_VAR_CLEARED_16)
  #undef       EEP_STOP_SEC_VAR_CLEARED_16
  #pragma ghs section

#elif defined (EEP_START_SEC_VAR_CLEARED_32)
  #undef       EEP_START_SEC_VAR_CLEARED_32
  #pragma ghs section bss=".bss.EEP_RAM_VAR_POWER_ON_CLEARED_32"
#elif defined (EEP_STOP_SEC_VAR_CLEARED_32)
  #undef       EEP_STOP_SEC_VAR_CLEARED_32
  #pragma ghs section

#elif defined (EEP_START_SEC_CONST_UNSPECIFIED)
  #undef       EEP_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.EEP_ROM_CONST_UNSPECIFIED"
#elif defined (EEP_STOP_SEC_CONST_UNSPECIFIED)
  #undef       EEP_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*                                 Ea                                         */
/* -------------------------------------------------------------------------- */
#elif defined (EA_START_SEC_CODE)
  #undef       EA_START_SEC_CODE
  #pragma ghs section text=".text.EA_CODE"
  #pragma ghs section rodata=".rodata.EA_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.EA_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.EA_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (EA_STOP_SEC_CODE)
  #undef       EA_STOP_SEC_CODE
  #pragma ghs section

#elif defined (EA_START_SEC_NO_INIT_VAR_BOOLEAN)
  #undef       EA_START_SEC_NO_INIT_VAR_BOOLEAN
  #pragma ghs section bss=".bss.EA_RAM_VAR_NO_INIT_BOOLEAN"
#elif defined (EA_STOP_SEC_NO_INIT_VAR_BOOLEAN)
  #undef       EA_STOP_SEC_NO_INIT_VAR_BOOLEAN
  #pragma ghs section

#elif defined (EA_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       EA_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.EA_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (EA_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       EA_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (EA_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
  #undef       EA_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
  #pragma ghs section bss=".bss.EEP_RAM_VAR_SAVED_ZONE_UNSPECIFIED"
#elif defined (EA_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
  #undef       EA_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED
  #pragma ghs section

#elif defined (EA_START_SEC_CONST_16)
  #undef       EA_START_SEC_CONST_16
  #pragma ghs section rodata=".rodata.EA_ROM_CONST_16"
#elif defined (EA_STOP_SEC_CONST_16)
  #undef       EA_STOP_SEC_CONST_16
  #pragma ghs section

#elif defined (EA_START_SEC_CONST_UNSPECIFIED)
  #undef       EA_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.EA_ROM_CONST_UNSPECIFIED"
#elif defined (EA_STOP_SEC_CONST_UNSPECIFIED)
  #undef       EA_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (EA_START_SEC_NO_INIT_VAR_16)
  #undef       EA_START_SEC_NO_INIT_VAR_16
  #pragma ghs section bss=".bss.EA_RAM_VAR_NO_INIT_16"
#elif defined (EA_STOP_SEC_NO_INIT_VAR_16)
  #undef       EA_STOP_SEC_NO_INIT_VAR_16
  #pragma ghs section

#elif defined (EA_START_SEC_NO_INIT_VAR_8)
  #undef       EA_START_SEC_NO_INIT_VAR_8
  #pragma ghs section bss=".bss.EA_RAM_VAR_NO_INIT_8"
#elif defined (EA_STOP_SEC_NO_INIT_VAR_8)
  #undef       EA_STOP_SEC_NO_INIT_VAR_8
  #pragma ghs section

#elif defined (EA_START_SEC_NO_INIT_VAR_UNSPECIFIED)
  #undef       EA_START_SEC_NO_INIT_VAR_UNSPECIFIED
  #pragma ghs section bss=".bss.EA_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (EA_STOP_SEC_NO_INIT_VAR_UNSPECIFIED)
  #undef       EA_STOP_SEC_NO_INIT_VAR_UNSPECIFIED
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*                 RTE                                                        */
/* -------------------------------------------------------------------------- */
#elif defined (RTE_START_SEC_CODE)
  #undef       RTE_START_SEC_CODE
  #pragma ghs section text=".text.RTE_CODE"
  #pragma ghs section rodata=".rodata.RTE_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.RTE_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.RTE_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (RTE_STOP_SEC_CODE)
  #undef       RTE_STOP_SEC_CODE
  #pragma ghs section

#elif defined (RTE_START_SEC_CONST_UNSPECIFIED)
  #undef       RTE_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.RTE_ROM_CONST_UNSPECIFIED"
#elif defined (RTE_STOP_SEC_CONST_UNSPECIFIED)
  #undef       RTE_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (RTE_START_SEC_VAR_UNSPECIFIED)
  #undef       RTE_START_SEC_VAR_UNSPECIFIED
  #pragma ghs section bss=".bss.RTE_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (RTE_STOP_SEC_VAR_UNSPECIFIED)
  #undef       RTE_STOP_SEC_VAR_UNSPECIFIED
  #pragma ghs section

#elif defined (RTE_START_CONFIG_DATA_UNSPECIFIED)
  #undef       RTE_START_CONFIG_DATA_UNSPECIFIED
  #pragma ghs section rodata=".rodata.RTE_ROM_CONFIG_CONST_UNSPECIFIED"
#elif defined (RTE_STOP_CONFIG_DATA_UNSPECIFIED)
  #undef       RTE_STOP_CONFIG_DATA_UNSPECIFIED
  #pragma ghs section

#elif defined (RTE_START_SEC_VAR_8)
  #undef       RTE_START_SEC_VAR_8
  #pragma ghs section bss=".bss.RTE_RAM_VAR_CLEARED_8"
#elif defined (RTE_STOP_SEC_VAR_8)
  #undef       RTE_STOP_SEC_VAR_8
  #pragma ghs section

#elif defined (RTE_START_SEC_VAR_NOINIT_8)
  #undef       RTE_START_SEC_VAR_NOINIT_8
  #pragma ghs section bss=".bss.RTE_RAM_VAR_NO_INIT_8"
#elif defined (RTE_STOP_SEC_VAR_NOINIT_8)
  #undef       RTE_STOP_SEC_VAR_NOINIT_8
  #pragma ghs section

#elif defined (RTE_START_SEC_CONST_8)
  #undef       RTE_START_SEC_CONST_8
  #pragma ghs section rodata=".rodata.RTE_ROM_CONST_8"
#elif defined (RTE_STOP_SEC_CONST_8)
  #undef       RTE_STOP_SEC_CONST_8
  #pragma ghs section

#elif defined (RTE_START_SEC_VAR_16)
  #undef       RTE_START_SEC_VAR_16
  #pragma ghs section bss=".bss.RTE_RAM_VAR_NO_INIT_16"
#elif defined (RTE_STOP_SEC_VAR_16)
  #undef       RTE_STOP_SEC_VAR_16
  #pragma ghs section

#elif defined (RTE_START_SEC_VAR_NOINIT_16)
  #undef       RTE_START_SEC_VAR_NOINIT_16
  #pragma ghs section bss=".bss.RTE_RAM_VAR_NO_INIT_16"
#elif defined (RTE_STOP_SEC_VAR_NOINIT_16)
  #undef       RTE_STOP_SEC_VAR_NOINIT_16
  #pragma ghs section

#elif defined (RTE_START_SEC_CONST_16)
  #undef       RTE_START_SEC_CONST_16
  #pragma ghs section rodata=".rodata.RTE_ROM_CONST_16"
#elif defined (RTE_STOP_SEC_CONST_16)
  #undef       RTE_STOP_SEC_CONST_16
  #pragma ghs section

#elif defined (RTE_START_SEC_VAR_NOINIT_UNSPECIFIED)
  #undef       RTE_START_SEC_VAR_NOINIT_UNSPECIFIED
  #pragma ghs section bss=".bss.RTE_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (RTE_STOP_SEC_VAR_NOINIT_UNSPECIFIED)
  #undef       RTE_STOP_SEC_VAR_NOINIT_UNSPECIFIED
  #pragma ghs section

#elif defined (RTE_START_SEC_VAR_CONST_UNSPECIFIED)
  #undef       RTE_START_SEC_VAR_CONST_UNSPECIFIED
  #pragma ghs section data=".data.RTE_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (RTE_STOP_SEC_VAR_CONST_UNSPECIFIED)
  #undef       RTE_STOP_SEC_VAR_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (RTE_START_SEC_CALIB_UNSPECIFIED)
  #undef       RTE_START_SEC_CALIB_UNSPECIFIED
  #pragma ghs section rodata=".rodata.RTE_CONFIG_CALIB_ROM_UNSPECIFIED"
#elif defined (RTE_STOP_SEC_CALIB_UNSPECIFIED)
  #undef       RTE_STOP_SEC_CALIB_UNSPECIFIED
  #pragma ghs section

#elif defined (RTE_START_SEC_CALIB_8)
  #undef       RTE_START_SEC_VAR_8
  #pragma ghs section rodata=".rodata.RTE_CONFIG_CALIB_ROM_8"
#elif defined (RTE_STOP_SEC_CALIB_8)
  #undef       RTE_STOP_SEC_VAR_8
  #pragma ghs section

#elif defined (RTE_START_SEC_INTERNAL_VAR_UNSPECIFIED)
  #undef       RTE_START_SEC_INTERNAL_VAR_UNSPECIFIED
  #pragma ghs section bss=".bss.RTE_CONFIG_CALIB_RAM_UNSPECIFIED"
#elif defined (RTE_STOP_SEC_INTERNAL_VAR_UNSPECIFIED)
  #undef       RTE_STOP_SEC_INTERNAL_VAR_UNSPECIFIED
  #pragma ghs section

#elif defined (RTE_START_SEC_INTERNAL_VAR_8)
  #undef       RTE_START_SEC_INTERNAL_VAR_8
  #pragma ghs section bss=".bss.RTE_CONFIG_CALIB_RAM_8"
#elif defined (RTE_STOP_SEC_INTERNAL_VAR_8)
  #undef       RTE_STOP_SEC_INTERNAL_VAR_8
  #pragma ghs section

#elif defined (BSWMODULEDESCRIPTION_CALIB_START_SEC_CODE)
  #undef       BSWMODULEDESCRIPTION_CALIB_START_SEC_CODE
  #pragma ghs section text=".text.RTE_CODE"
  #pragma ghs section rodata=".rodata.RTE_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.RTE_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.RTE_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (BSWMODULEDESCRIPTION_CALIB_STOP_SEC_CODE)
  #undef       BSWMODULEDESCRIPTION_CALIB_STOP_SEC_CODE
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*                 WDG_39_ACW                                                        */
/* -------------------------------------------------------------------------- */
#elif defined (WDG_39_ACW_START_SEC_CODE)
  #undef       WDG_39_ACW_START_SEC_CODE
  #pragma ghs section text=".text.WDG_39_ACW_CODE"
  #pragma ghs section rodata=".rodata.WDG_39_ACW_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.WDG_39_ACW_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.WDG_39_ACW_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (WDG_39_ACW_STOP_SEC_CODE)
  #undef       WDG_39_ACW_STOP_SEC_CODE
  #pragma ghs section

#elif defined (WDG_39_ACW_START_SEC_VAR_UNSPECIFIED)
  #undef       WDG_39_ACW_START_SEC_VAR_UNSPECIFIED
  #pragma ghs section bss=".bss.WDG_39_ACW_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (WDG_39_ACW_STOP_SEC_VAR_UNSPECIFIED)
  #undef       WDG_39_ACW_STOP_SEC_VAR_UNSPECIFIED
  #pragma ghs section

#elif defined (WDG_39_ACW_START_SEC_VAR_CLEARED_32)
  #undef       WDG_39_ACW_START_SEC_VAR_CLEARED_32
  #pragma ghs section bss=".bss.WDG_39_ACW_RAM_VAR_CLEARED_32"
#elif defined (WDG_39_ACW_STOP_SEC_VAR_CLEARED_32)
  #undef       WDG_39_ACW_STOP_SEC_VAR_CLEARED_32
  #pragma ghs section

#elif defined (WDG_39_ACW_START_SEC_CONST_8)
  #undef       WDG_39_ACW_START_SEC_CONST_8
  #pragma ghs section rodata=".rodata.WDG_39_ACW_ROM_CONST_8"
#elif defined (WDG_39_ACW_STOP_SEC_CONST_8)
  #undef       WDG_39_ACW_STOP_SEC_CONST_8
  #pragma ghs section

#elif defined (WDG_39_ACW_START_SEC_CONST_32)
  #undef       WDG_39_ACW_START_SEC_CONST_32
  #pragma ghs section rodata=".rodata.WDG_39_ACW_ROM_CONST_32"
#elif defined (WDG_39_ACW_STOP_SEC_CONST_32)
  #undef       WDG_39_ACW_STOP_SEC_CONST_32
  #pragma ghs section

#elif defined (WDG_39_ACW_START_SEC_CONST_UNSPECIFIED)
  #undef       WDG_39_ACW_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.WDG_39_ACW_ROM_CONST_UNSPECIFIED"
#elif defined (WDG_39_ACW_STOP_SEC_CONST_UNSPECIFIED)
  #undef       WDG_39_ACW_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*                 WDGIF                                                      */
/* -------------------------------------------------------------------------- */
#elif defined (WDGIF_START_SEC_CODE)
  #undef       WDGIF_START_SEC_CODE
  #pragma ghs section text=".text.WDGIF_CODE"
  #pragma ghs section rodata=".rodata.WDGIF_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.WDGIF_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.WDGIF_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (WDGIF_STOP_SEC_CODE)
  #undef       WDGIF_STOP_SEC_CODE
  #pragma ghs section

#elif defined (WDGIF_START_SEC_CONST_UNSPECIFIED)
  #undef       WDGIF_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.WDGIF_ROM_CONST_UNSPECIFIED"
#elif defined (WDGIF_STOP_SEC_CONST_UNSPECIFIED)
  #undef       WDGIF_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*                 WDGM                                                       */
/* -------------------------------------------------------------------------- */

#elif defined (WDGM_START_SEC_CONST_8)
  #undef       WDGM_START_SEC_CONST_8
  #pragma ghs section rodata=".rodata.WDGM_ROM_CONST_8"
#elif defined (WDGM_STOP_SEC_CONST_8)
  #undef       WDGM_STOP_SEC_CONST_8
  #pragma ghs section

#elif defined (WDGM_START_SEC_CONST_16)
  #undef       WDGM_START_SEC_CONST_16
  #pragma ghs section rodata=".rodata.WDGM_ROM_CONST_16"
#elif defined (WDGM_STOP_SEC_CONST_16)
  #undef       WDGM_STOP_SEC_CONST_16
  #pragma ghs section

#elif defined (WDGM_START_SEC_CONST_UNSPECIFIED)
  #undef       WDGM_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.WDGM_ROM_CONST_UNSPECIFIED"
#elif defined (WDGM_STOP_SEC_CONST_UNSPECIFIED)
  #undef       WDGM_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (WDGM_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       WDGM_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.WDGM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (WDGM_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       WDGM_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (WDGM_START_SEC_VAR_CLEARED_8)
  #undef       WDGM_START_SEC_VAR_CLEARED_8
  #pragma ghs section bss=".bss.WDGM_RAM_VAR_CLEARED_8"
#elif defined (WDGM_STOP_SEC_VAR_CLEARED_8)
  #undef       WDGM_STOP_SEC_VAR_CLEARED_8
  #pragma ghs section

#elif defined (WDGM_START_SEC_VAR_CLEARED_16)
  #undef       WDGM_START_SEC_VAR_CLEARED_16
  #pragma ghs section bss=".bss.WDGM_RAM_VAR_CLEARED_16"
#elif defined (WDGM_STOP_SEC_VAR_CLEARED_16)
  #undef       WDGM_STOP_SEC_VAR_CLEARED_16
  #pragma ghs section
  
#elif defined (WDGM_START_SEC_VAR_CLEARED_32)
  #undef       WDGM_START_SEC_VAR_CLEARED_32
  #pragma ghs section bss=".bss.WDGM_RAM_VAR_CLEARED_32"
#elif defined (WDGM_STOP_SEC_VAR_CLEARED_32)
  #undef       WDGM_STOP_SEC_VAR_CLEARED_32
  #pragma ghs section

#elif defined (WDGM_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       WDGM_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.WDGM_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (WDGM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       WDGM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (WDGM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       WDGM_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.WDGM_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (WDGM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       WDGM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (WDGM_START_SEC_CODE)
  #undef       WDGM_START_SEC_CODE
  #pragma ghs section text=".text.WDGM_CODE"
  #pragma ghs section rodata=".rodata.WDGM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.WDGM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.WDGM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (WDGM_STOP_SEC_CODE)
  #undef       WDGM_STOP_SEC_CODE
  #pragma ghs section

#elif defined (WDGM_START_SEC_PUBLIC_CODE)
  #undef       WDGM_START_SEC_PUBLIC_CODE
  #pragma ghs section text=".text.WDGM_PUBLIC_CODE"
  #pragma ghs section rodata=".rodata.WDGM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.WDGM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.WDGM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (WDGM_STOP_SEC_PUBLIC_CODE)
  #undef       WDGM_STOP_SEC_PUBLIC_CODE
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*			  Xcp												                                          */
/* -------------------------------------------------------------------------- */
#elif defined (XCP_START_SEC_VAR_CLEARED_8)
  #undef       XCP_START_SEC_VAR_CLEARED_8
  #pragma ghs section bss=".bss.XCP_RAM_VAR_CLEARED_8"
  #pragma alignvar (4)
#elif defined (XCP_STOP_SEC_VAR_CLEARED_8)
  #undef       XCP_STOP_SEC_VAR_CLEARED_8
  #pragma ghs section

#elif defined (XCP_START_SEC_VAR_CLEARED_16)
  #undef       XCP_START_SEC_VAR_CLEARED_16
  #pragma ghs section bss=".bss.XCP_RAM_VAR_CLEARED_16"
  #pragma alignvar (4)
#elif defined (XCP_STOP_SEC_VAR_CLEARED_16)
  #undef       XCP_STOP_SEC_VAR_CLEARED_16
  #pragma ghs section

#elif defined (XCP_START_SEC_CONST_8)
  #undef       XCP_START_SEC_CONST_8
  #pragma ghs section rodata=".rodata.XCP_ROM_CONST_8"
  #pragma alignvar (4)
#elif defined (XCP_STOP_SEC_CONST_8)
  #undef       XCP_STOP_SEC_CONST_8
  #pragma ghs section

#elif defined (XCP_START_SEC_VAR_CLEARED_32)
  #undef       XCP_START_SEC_VAR_CLEARED_32
  #pragma ghs section bss=".bss.XCP_RAM_VAR_CLEARED_32"
  #pragma alignvar (4)
#elif defined (XCP_STOP_SEC_VAR_CLEARED_32)
  #undef       XCP_STOP_SEC_VAR_CLEARED_32
  #pragma ghs section

#elif defined (XCP_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       XCP_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.XCP_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma alignvar (4)
#elif defined (XCP_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       XCP_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (XCP_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
  #undef       XCP_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.XCP_RAM_VAR_CLEARED_BOOLEAN"
  #pragma alignvar (4)
#elif defined (XCP_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
  #undef       XCP_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (XCP_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
  #undef       XCP_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.XCP_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma alignvar (4)
#elif defined (XCP_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
  #undef       XCP_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (XCP_START_SEC_VAR_NO_INIT_BOOLEAN)
  #undef       XCP_START_SEC_VAR_NO_INIT_BOOLEAN
  #pragma ghs section bss=".bss.XCP_RAM_VAR_NO_INIT_BOOLEAN"
  #pragma alignvar (4)
#elif defined (XCP_STOP_SEC_VAR_NO_INIT_BOOLEAN)
  #undef       XCP_STOP_SEC_VAR_NO_INIT_BOOLEAN
  #pragma ghs section

#elif defined (XCP_START_SEC_VAR_NO_INIT_8)
  #undef       XCP_START_SEC_VAR_NO_INIT_8
  #pragma ghs section bss=".bss.XCP_RAM_VAR_NO_INIT_8"
  #pragma alignvar (4)
#elif defined (XCP_STOP_SEC_VAR_NO_INIT_8)
  #undef       XCP_STOP_SEC_VAR_NO_INIT_8
  #pragma ghs section

#elif defined (XCP_START_SEC_VAR_NO_INIT_32)
  #undef       XCP_START_SEC_VAR_NO_INIT_32
  #pragma ghs section bss=".bss.XCP_RAM_VAR_NO_INIT_32"
  #pragma alignvar (4)
#elif defined (XCP_STOP_SEC_VAR_NO_INIT_32)
  #undef       XCP_STOP_SEC_VAR_NO_INIT_32
  #pragma ghs section

#elif defined (XCP_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       XCP_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section bss=".bss.XCP_RAM_VAR_NO_INIT_UNSPECIFIED"
  #pragma alignvar (4)
#elif defined (XCP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef       XCP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #pragma ghs section

#elif defined (XCP_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef       XCP_START_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section bss=".bss.XCP_RAM_VAR_CLEARED_BOOLEAN"
  #pragma alignvar (4)
#elif defined (XCP_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef       XCP_STOP_SEC_VAR_CLEARED_BOOLEAN
  #pragma ghs section

#elif defined (XCP_START_SEC_CONST_UNSPECIFIED)
  #undef       XCP_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.XCP_ROM_CONST_UNSPECIFIED"
  #pragma alignvar (4)
#elif defined (XCP_STOP_SEC_CONST_UNSPECIFIED)
  #undef       XCP_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (XCP_START_SEC_CODE)
  #undef       XCP_START_SEC_CODE
  #pragma ghs section text=".text.XCP_CODE"
  #pragma ghs section rodata=".rodata.XCP_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.XCP_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.XCP_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (XCP_STOP_SEC_CODE)
  #undef       XCP_STOP_SEC_CODE
  #pragma ghs section

#elif defined (XCP_START_SEC_VAR_POWER_ON_CLEARED_8)
  #undef       XCP_START_SEC_VAR_POWER_ON_CLEARED_8
  #pragma ghs section bss=".bss.XCP_RAM_VAR_CLEARED_8"
  #pragma alignvar (4)
#elif defined (XCP_STOP_SEC_VAR_POWER_ON_CLEARED_8)
  #undef       XCP_STOP_SEC_VAR_POWER_ON_CLEARED_8
  #pragma ghs section

#elif defined (XCP_START_SEC_VAR_CALIBRATION_ROM)
  #undef       XCP_START_SEC_VAR_CALIBRATION_ROM
  #pragma alignvar (4)
  #pragma ghs section rodata=".rodata.XCP_ROM_CALIBRATION_ROM"
#elif defined (XCP_STOP_SEC_VAR_CALIBRATION_ROM)
  #undef       XCP_STOP_SEC_VAR_CALIBRATION_ROM
  #pragma ghs section

#elif defined (XCP_START_SEC_VAR_CALIBRATION_RAM)
  #undef       XCP_START_SEC_VAR_CALIBRATION_RAM
  #pragma alignvar (4)
  #pragma ghs section rodata=".rodata.XCP_ROM_CALIBRATION_RAM"
#elif defined (XCP_STOP_SEC_VAR_CALIBRATION_RAM)
  #undef       XCP_STOP_SEC_VAR_CALIBRATION_RAM
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*                 CoSvAb                                                     */
/* -------------------------------------------------------------------------- */
#elif defined (COSVAB_START_SEC_CODE)
  #undef       COSVAB_START_SEC_CODE
  #pragma ghs section text=".text.COSVAB_CODE"
  #pragma ghs section rodata=".rodata.COSVAB_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.COSVAB_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.COSVAB_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (COSVAB_STOP_SEC_CODE)
  #undef       COSVAB_STOP_SEC_CODE
  #pragma ghs section

#elif defined (COSVAB_START_SEC_VAR_INIT_8)
  #undef       COSVAB_START_SEC_VAR_INIT_8
  #pragma ghs section data=".data.COSVAB_RAM_VAR_INIT_8"
#elif defined (COSVAB_STOP_SEC_VAR_INIT_8)
  #undef       COSVAB_STOP_SEC_VAR_INIT_8
  #pragma ghs section

#elif defined (COSVAB_START_SEC_VAR_CLEARED_32)
  #undef       COSVAB_START_SEC_VAR_CLEARED_32
  #pragma ghs section bss=".bss.COSVAB_RAM_VAR_CLEARED_32"
#elif defined (COSVAB_STOP_SEC_VAR_CLEARED_32)
  #undef       COSVAB_STOP_SEC_VAR_CLEARED_32
  #pragma ghs section

#elif defined (COSVAB_START_SEC_CONST_32)
  #undef       COSVAB_START_SEC_CONST_32
  #pragma ghs section rodata=".rodata.COSVAB_ROM_CONST_32"
#elif defined (COSVAB_STOP_SEC_CONST_32)
  #undef       COSVAB_STOP_SEC_CONST_32
  #pragma ghs section

#elif defined (COSVAB_START_SEC_CONST_UNSPECIFIED)
  #undef       COSVAB_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.COSVAB_ROM_CONST_UNSPECIFIED"
#elif defined (COSVAB_STOP_SEC_CONST_UNSPECIFIED)
  #undef       COSVAB_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

/* -------------------------------------------------------------------------- */
/*                 IoHwAb                                                     */
/* -------------------------------------------------------------------------- */
#elif defined (IOHWAB_START_SEC_CODE)
  #undef       IOHWAB_START_SEC_CODE
  #pragma ghs section text=".text.IOHWAB_CODE"
  #pragma ghs section rodata=".rodata.IOHWAB_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.IOHWAB_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.IOHWAB_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (IOHWAB_STOP_SEC_CODE)
  #undef       IOHWAB_STOP_SEC_CODE
  #pragma ghs section

#elif defined (IOHWAB_START_SEC_VAR_CLEARED_8)
  #undef       IOHWAB_START_SEC_VAR_CLEARED_8
  #pragma ghs section bss=".bss.IOHWAB_RAM_VAR_CLEARED_8"
#elif defined (IOHWAB_STOP_SEC_VAR_CLEARED_8)
  #undef       IOHWAB_STOP_SEC_VAR_CLEARED_8
  #pragma ghs section

#elif defined (IOHWAB_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       IOHWAB_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.IOHWAB_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (IOHWAB_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       IOHWAB_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (IOHWAB_START_SEC_CONST_8)
  #undef       IOHWAB_START_SEC_CONST_8
  #pragma ghs section rodata=".rodata.IOHWAB_ROM_CONST_8"
#elif defined (IOHWAB_STOP_SEC_CONST_8)
  #undef       IOHWAB_STOP_SEC_CONST_8
  #pragma ghs section

#elif defined (IOHWAB_START_SEC_CONST_16)
  #undef       IOHWAB_START_SEC_CONST_16
  #pragma ghs section rodata=".rodata.IOHWAB_ROM_CONST_16"
#elif defined (IOHWAB_STOP_SEC_CONST_16)
  #undef       IOHWAB_STOP_SEC_CONST_16
  #pragma ghs section

#elif defined (IOHWAB_START_SEC_CONST_UNSPECIFIED)
  #undef       IOHWAB_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.IOHWAB_ROM_CONST_UNSPECIFIED"
#elif defined (IOHWAB_STOP_SEC_CONST_UNSPECIFIED)
  #undef       IOHWAB_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

#elif defined (PM_START_SEC_CODE)
  #undef       PM_START_SEC_CODE
  #pragma ghs section text=".text.PM_CODE"
  #pragma ghs section rodata=".rodata.PM_ROM_CONST_UNSPECIFIED"
  #pragma ghs section bss=".bss.PM_RAM_VAR_CLEARED_UNSPECIFIED"
  #pragma ghs section data=".data.PM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (PM_STOP_SEC_CODE)
  #undef       PM_STOP_SEC_CODE
  #pragma ghs section

#elif defined (PM_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       PM_START_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section bss=".bss.PM_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (PM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef       PM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #pragma ghs section

#elif defined (PM_START_SEC_CONST_UNSPECIFIED)
  #undef       PM_START_SEC_CONST_UNSPECIFIED
  #pragma ghs section rodata=".rodata.PM_ROM_CONST_UNSPECIFIED"
#elif defined (PM_STOP_SEC_CONST_UNSPECIFIED)
  #undef       PM_STOP_SEC_CONST_UNSPECIFIED
  #pragma ghs section

/*************************** Stack section ************************************/

/******************************END*********************************************/

#else
  //linked with below line. #include "Rte_MemMap.h"
  #define SECTION_NOT_FOUND //linked with above line

  #if defined (SECTION_NOT_FOUND)
    #undef SECTION_NOT_FOUND
	#include "Mcal_MemMap.h"
  #endif
  #if defined (SECTION_NOT_FOUND)
    #undef SECTION_NOT_FOUND
	#include "Os_MemMap.h"
  #endif

  #if defined (SECTION_NOT_FOUND)
    //FIXME Temporarily commented #error "MemMap.h: No valid section define found"

  #endif
#endif  /* START_WITH_IF */
