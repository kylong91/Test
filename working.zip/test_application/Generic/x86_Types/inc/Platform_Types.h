/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Platform_Types.h                                              **
**                                                                            **
**  TARGET    : x86                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BSW R4.0 Modules                                      **
**                                                                            **
**  PURPOSE   : This file contains platform dependent types and symbols.      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     12-Sep-2012   MKT    Initial version                             **
*******************************************************************************/

#ifndef PLATFORM_TYPES_H
#define PLATFORM_TYPES_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*
 * AUTOSAR specification version information
 */
#define PLATFORM_TYPES_AR_RELEASE_MAJOR_VERSION     4
#define PLATFORM_TYPES_AR_RELEASE_MINOR_VERSION     0
#define PLATFORM_TYPES_AR_RELEASE_REVISION_VERSION  3

/*
 * File version information
 */
#define PLATFORM_TYPES_SW_MAJOR_VERSION  1
#define PLATFORM_TYPES_SW_MINOR_VERSION  0
#define PLATFORM_TYPES_SW_PATCH_VERSION  0

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/*
  CPU register type width
*/
#define CPU_TYPE_8        8
#define CPU_TYPE_16       16
#define CPU_TYPE_32       32

/*
  Bit order definition
*/
#define MSB_FIRST         0                 /* Big endian bit ordering       */
#define LSB_FIRST         1                 /* Little endian bit ordering    */

/*
  Byte order definition
*/
#define HIGH_BYTE_FIRST   0                 /* Big endian byte ordering      */
#define LOW_BYTE_FIRST    1                 /* Little endian byte ordering   */

/*
  Word order definition
*/
#define HIGH_WORD_FIRST   0                 /* Big endian word ordering      */
#define LOW_WORD_FIRST    1                 /* Little endian word ordering   */


/*
  Platform type and endianess definitions for Intel
*/
#define CPU_TYPE            CPU_TYPE_32
#define CPU_BIT_ORDER       LSB_FIRST
#define CPU_BYTE_ORDER      LOW_BYTE_FIRST
#define CPU_WORD_ORDER      LOW_WORD_FIRST

#define EXTERN              extern

/*
  AUTOSAR integer data types
*/
typedef signed char         sint8;          /*        -128 .. +127           */
typedef unsigned char       uint8;          /*           0 .. 255            */
typedef signed short        sint16;         /*      -32768 .. +32767         */
typedef unsigned short      uint16;         /*           0 .. 65535          */
typedef signed long         sint32;         /* -2147483648 .. +2147483647    */
typedef unsigned long       uint32;         /*           0 .. 4294967295     */
typedef float               float32;        /*           32 bit              */
typedef double              float64;        /*           64 bit              */

typedef unsigned long       uint8_least;    /* At least 8 bit                */
typedef unsigned long       uint16_least;   /* At least 16 bit               */
typedef unsigned long       uint32_least;   /* At least 32 bit               */
typedef signed long         sint8_least;    /* At least 7 bit + 1 bit sign   */
typedef signed long         sint16_least;   /* At least 15 bit + 1 bit sign  */
typedef signed long         sint32_least;   /* At least 31 bit + 1 bit sign  */

typedef unsigned char       boolean;        /* for use with TRUE/FALSE       */


#ifndef TRUE                                /* conditional check */
  #define TRUE      ((boolean) 1)
#endif

#ifndef FALSE                               /* conditional check */
  #define FALSE     ((boolean) 0)
#endif

#ifndef UNUSED                              /* Check for unused parameter 
                                                                      warnings*/
  #define UNUSED(variable) (void) variable
#endif
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#endif /* PLATFORM_TYPES_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
