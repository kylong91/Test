/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: SchM_Det.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Development Error Tracer                              **
**                                                                            **
**  PURPOSE   : Declaration of SchM  functions                                **
**                                                                            **
**  PLATFORM DEPENDANT [Yes/No]: No                                           **
**                                                                            **
**  TO BE CHANGED BY USER [Yes/No]: No                                        **
**                                                                            **
*******************************************************************************/


/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By         Description                             **
********************************************************************************
** 4.0.0     12-Dec-2011    MKK        Creation of SchM_PduR.h module         **
*******************************************************************************/
#ifndef SCHM_DET_H
#define SCHM_DET_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern void SchM_Enter_Det_RAM_DATA_PROTECTION(void);

extern void SchM_Exit_Det_RAM_DATA_PROTECTION(void);


#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
