/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: SchM_FrIf.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FrNm Module                                           **
**                                                                            **
**  PURPOSE   : Declaration of SchM macros                                    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     02/28/2012   APT    Initial Version                              **
*******************************************************************************/

#ifndef SCHM_FRIF_H
#define SCHM_FRIF_H

/*******************************************************************************
*                       Include Section                                        *
*******************************************************************************/
#include "ComStack_Types.h"   

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
extern volatile uint8 GucDummy;
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
//extern void SchM_Enter_FrIf(uint8 event);
//extern void SchM_Exit_FrIf(uint8 event);
extern void SchM_Enter_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER0(void);
extern void SchM_Exit_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER0(void);
extern void SchM_Enter_FrIf_TRANSCEIVER_MODE_PROTECTION_CLUSTER0(void);
extern void SchM_Exit_FrIf_TRANSCEIVER_MODE_PROTECTION_CLUSTER0(void);
extern void SchM_Enter_FrIf_TRANSCEIVER_WAKEUP_PROTECTION_CLUSTER0(void);
extern void SchM_Exit_FrIf_TRANSCEIVER_WAKEUP_PROTECTION_CLUSTER0(void);
extern void SchM_Enter_FrIf_TRANSCEIVER_BRANCH_PROTECTION_CLUSTER0(void);
extern void SchM_Exit_FrIf_TRANSCEIVER_BRANCH_PROTECTION_CLUSTER0(void);
extern void SchM_Enter_FrIf_JOBCOUNTER_PROTECTION_CLUSTER0(void);
extern void SchM_Exit_FrIf_JOBCOUNTER_PROTECTION_CLUSTER0(void);
extern void SchM_Enter_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER1(void);
extern void SchM_Exit_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER1(void);
extern void SchM_Enter_FrIf_JOBCOUNTER_PROTECTION_CLUSTER1(void);
extern void SchM_Exit_FrIf_JOBCOUNTER_PROTECTION_CLUSTER1(void);
extern void SchM_Enter_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER2(void);
extern void SchM_Exit_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER2(void);
extern void SchM_Enter_FrIf_JOBCOUNTER_PROTECTION_CLUSTER2(void);
extern void SchM_Exit_FrIf_JOBCOUNTER_PROTECTION_CLUSTER2(void);
extern void SchM_Enter_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER3(void);
extern void SchM_Exit_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER3(void);
extern void SchM_Enter_FrIf_JOBCOUNTER_PROTECTION_CLUSTER3(void);
extern void SchM_Exit_FrIf_JOBCOUNTER_PROTECTION_CLUSTER3(void);
extern void SchM_Enter_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER4(void);
extern void SchM_Exit_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER4(void);
extern void SchM_Enter_FrIf_JOBCOUNTER_PROTECTION_CLUSTER4(void);
extern void SchM_Exit_FrIf_JOBCOUNTER_PROTECTION_CLUSTER4(void);
extern void SchM_Enter_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER5(void);
extern void SchM_Exit_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER5(void);
extern void SchM_Enter_FrIf_JOBCOUNTER_PROTECTION_CLUSTER5(void);
extern void SchM_Exit_FrIf_JOBCOUNTER_PROTECTION_CLUSTER5(void);
 /*For this exclusive area disabling all interrupts by scheduler is recommended
 */
#endif /*SCHM_FRIF_H*/
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
