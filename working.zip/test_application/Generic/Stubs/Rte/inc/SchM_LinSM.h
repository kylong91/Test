/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: SchM_LinSM.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR SchM LinSM Stub                                       **
**                                                                            **
**  PURPOSE   : Declaration of SchM LinSM Stub functions                      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     04-Nov-2011   KVM    Initial version                             **
*******************************************************************************/

#ifndef SCHM_LINSM_H
#define SCHM_LINSM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"             /* ComStack type header */
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                      Exclusive Area                                        **
*******************************************************************************/

/*
 * This type define the exclusive areas along with scheduler services are used
 * to provide data integrity for shared resources
 */
extern void SchM_Enter_LinSM_CHANNEL_STATUS_PROTECTION_0(void);
extern void SchM_Enter_LinSM_CHANNEL_STATUS_PROTECTION_1(void);
extern void SchM_Enter_LinSM_CHANNEL_STATUS_PROTECTION_2(void);
extern void SchM_Exit_LinSM_CHANNEL_STATUS_PROTECTION_0(void);
extern void SchM_Exit_LinSM_CHANNEL_STATUS_PROTECTION_1(void);
extern void SchM_Exit_LinSM_CHANNEL_STATUS_PROTECTION_2(void);

#endif /*SCHM_LINSM_H*/

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
