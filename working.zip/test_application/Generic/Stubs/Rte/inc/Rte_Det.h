/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Rte_Dlt.h                                                     **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR RTE                                                   **
**                                                                            **
**  PURPOSE   : Declaration of Rte functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     12-Mar-2012   SHV    Initial version                             **
*******************************************************************************/
#ifndef RTE_DET_H
#define RTE_DET_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Compiler.h"                  /* mapping compiler specific keywords */
#include "Platform_Types.h"            /* platform specific type definitions */
#include "Rte_Det_Type.h"
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define RTE_AR_RELEASE_MAJOR_VERSION  4
#define RTE_AR_RELEASE_MINOR_VERSION  0
#define RTE_AR_RELEASE_REVISION_VERSION  3

/* Software Version Information */
#define RTE_SW_MAJOR_VERSION  1
#define RTE_SW_MINOR_VERSION  0

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Std_ReturnType Rte_Call_Det_ReportError(uint8 InstanceId, uint8 ApiId,
  uint8 ErrorId);
  
extern boolean TestRte_Call_Det_ReportError(App_DataValidateType LucDataValidate,
  uint8 ExpInstanceId, uint8 ExpApiId, uint8 ExpErrorId);
#endif /* RTE_DET_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
