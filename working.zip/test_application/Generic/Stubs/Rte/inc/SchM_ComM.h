/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
** Infosystems Limited.                                                       **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: SchM.h                                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Communication Manager                                 **
**                                                                            **
**  PURPOSE   : Declaration of SchM functions                                 **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0    30-Aug-2012   Ravi Tiwari    Initial version                      **
*******************************************************************************/
#ifndef SCHM_COMM_H
#define SCHM_COMM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void SchM_Enter_ComM_VERSION_INFO_PROTECTION(void);
extern void SchM_Exit_ComM_VERSION_INFO_PROTECTION(void);

extern void SchM_Enter_ComM_REQ_COMM_MODE_PROTECTION(void);
extern void SchM_Exit_ComM_REQ_COMM_MODE_PROTECTION(void);


extern void SchM_Enter_ComM_INHIBIT_CNT_PROTECTION(void);
extern void SchM_Exit_ComM_INHIBIT_CNT_PROTECTION(void);

extern void SchM_Enter_ComM_REQ_MODECNT_PROTECTION(void);
extern void SchM_Exit_ComM_REQ_MODECNT_PROTECTION(void);

extern void SchM_Enter_ComM_CURRENT_MODE_PROTECTION(void);
extern void SchM_Exit_ComM_CURRENT_MODE_PROTECTION(void);

extern void SchM_Enter_ComM_DCM_DIAGNOSTIC_PROTECTION(void);
extern void SchM_Exit_ComM_DCM_DIAGNOSTIC_PROTECTION(void);

extern void SchM_Enter_ComM_ECUM_WAKEUP_IND(void);
extern void SchM_Exit_ComM_ECUM_WAKEUP_IND(void);

extern void SchM_Enter_ComM_NM_INDICATION_PROTECTION(void);
extern void SchM_Exit_ComM_NM_INDICATION_PROTECTION(void);

extern void SchM_Enter_ComM_PNC_PREPARE_TIMER(void);
extern void SchM_Exit_ComM_PNC_PREPARE_TIMER(void);

extern void SchM_Enter_ComM_PNC_WAKEUP_IND(void);
extern void SchM_Exit_ComM_PNC_WAKEUP_IND(void);

extern void SchM_Enter_ComM_PNC_EIRA_RX(void);
extern void SchM_Exit_ComM_PNC_EIRA_RX(void);

extern void SchM_Enter_ComM_PNC_ERA_RX(void);
extern void SchM_Exit_ComM_PNC_ERA_RX(void);



#endif /* SCHM_COMM_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

