/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: SchM_EthIf.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR SchM EthIf Stub                                       **
**                                                                            **
**  PURPOSE   : Declaration of SchM EthIf Stub functions                      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By        Description                              **
********************************************************************************
** 4.0.0     08-Aug-2012   BCC       Initial version                          **
*******************************************************************************/

#ifndef SCHM_ETHIF_H
#define SCHM_ETHIF_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Std_Types.h"                  /* Standard type header */
#include "ComStack_Types.h"             /* ComStack type header */

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                      Exclusive Area                                        **
*******************************************************************************/

/*
 * This type define the exclusive areas along with scheduler services are used
 * to provide data integrity for shared resources
 */
extern void SchM_Enter_EthIf_MAIN_PERIOD_PROTECT(void);
extern void SchM_Exit_EthIf_MAIN_PERIOD_PROTECT(void);

extern void SchM_Enter_EthIf_ExclusiveArea_0(void);
extern void SchM_Exit_EthIf_ExclusiveArea_0(void);

#endif /*SCHM_ETHIF_H*/

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
