/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: SchM_LinNm.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR SchM LinNm Stub                                       **
**                                                                            **
**  PURPOSE   : Declaration of SchM LinNm Stub functions                      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     24-Oct-2011   BHP    Creation of SchM.h module                   **
*******************************************************************************/
#ifndef SCHM_LINNM_H
#define SCHM_LINNM_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"             /* ComStack type header */

/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define SCHM_LINNM_AR_RELEASE_MAJOR_VERSION         4
#define SCHM_LINNM_AR_RELEASE_MINOR_VERSION         0
#define SCHM_LINNM_AR_RELEASE_REVISION_VERSION      2

/* Software Version Information */
#define SCHM_LINNM_SW_MAJOR_VERSION         4
#define SCHM_LINNM_SW_MINOR_VERSION         0
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                      Exclusive Area                                        **
*******************************************************************************/
/*
 * This type define the exclusive areas along with scheduler services are used
 * to provide data integrity for shared resources
 */
extern void SchM_Enter_LinNm_UPDATE_NETWORK_STATUS_NW0(void);
extern void SchM_Enter_LinNm_UPDATE_NETWORK_STATUS_NW1(void);
extern void SchM_Enter_LinNm_UPDATE_NETWORK_STATUS_NW2(void);
extern void SchM_Exit_LinNm_UPDATE_NETWORK_STATUS_NW0(void);
extern void SchM_Exit_LinNm_UPDATE_NETWORK_STATUS_NW1(void);
extern void SchM_Exit_LinNm_UPDATE_NETWORK_STATUS_NW2(void);
#endif /*SCHM_LINNM_H*/
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
