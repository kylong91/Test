/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: SchM_PduR.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PDU Router                                            **
**                                                                            **
**  PURPOSE   : Declaration of SchM  functions                                **
**                                                                            **
**  PLATFORM DEPENDANT [Yes/No]: No                                           **
**                                                                            **
**  TO BE CHANGED BY USER [Yes/No]: No                                        **
**                                                                            **
*******************************************************************************/


/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By         Description                             **
********************************************************************************
** 4.0.0     25-Sep-2011    NKD        Creation of SchM_PduR.h module          **
*******************************************************************************/


#ifndef SCHM_PDUR_H
#define SCHM_PDUR_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Std_Types.h"                  /* Standard type header */
#include "ComStack_Types.h"   
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define SCHM_PDUR_AR_MAJOR_VERSION         4
#define SCHM_PDUR_AR_MINOR_VERSION         0
#define SCHM_PDUR_AR_PATCH_VERSION         2

/* Software Version Information */
#define SCHM_PDUR_SW_MAJOR_VERSION         4
#define SCHM_PDUR_SW_MINOR_VERSION         0


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void SchM_Enter_PduR_PDUR_TP_TX_PROTECTION_AREA(void);

extern void SchM_Enter_PduR_PDUR_GROUP_STATUS_PROTECTION_AREA(void);

extern void SchM_Enter_PduR_PDUR_FIFO_STATUS_PROTECTION_AREA(void);

extern void SchM_Enter_PduR_PDUR_DATA_BUFFER_PROTECTION_AREA(void);

extern void SchM_Enter_PduR_PDUR_TP_GATEWAY_PROTECTION_AREA(void);

extern void SchM_Exit_PduR_PDUR_TP_TX_PROTECTION_AREA(void);

extern void SchM_Exit_PduR_PDUR_GROUP_STATUS_PROTECTION_AREA(void);

extern void SchM_Exit_PduR_PDUR_FIFO_STATUS_PROTECTION_AREA(void);

extern void SchM_Exit_PduR_PDUR_DATA_BUFFER_PROTECTION_AREA(void);

extern void SchM_Exit_PduR_PDUR_TP_GATEWAY_PROTECTION_AREA(void);

#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
