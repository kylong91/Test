/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Com.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PDU Router                                            **
**                                                                            **
**  PURPOSE   : Declaration of SchM functions                                 **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     26-Sep-2011   VKU    Creation of SchM_Com.h                      **
*******************************************************************************/
#ifndef SCHM_COM_H
#define SCHM_COM_H
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
/* SchM_Enter APIS */
extern void SchM_Enter_Com_RX_DM_STS_PROTECTION_AREA(void);
extern void SchM_Enter_Com_RX_IPDU_STS_PROTECTION_AREA(void);
extern void SchM_Enter_Com_TX_IPDU_STATUS_PROTECTION(void);
extern void SchM_Enter_Com_TX_IPDU_DATA_PROTECTION(void);
extern void SchM_Enter_Com_TX_SIG_STS_PROTECTION_AREA(void);
extern void SchM_Enter_Com_RX_IPDU_STATUS_PROTECTION(void);
extern void SchM_Enter_Com_TX_SIG_DATA_PROTECTION_AREA(void);
extern void SchM_Enter_Com_SIG_DATA_PROTECTION_AREA(void);
extern void SchM_Enter_Com_RX_SIG_DATA_PROTECTION_AREA(void);
extern void SchM_Enter_Com_RX_IPDU_DATA_PROTECTION_AREA(void);
extern void SchM_Enter_Com_IPDU_GRP_STS_PROTECTION(void);
extern void SchM_Enter_Com_IPDU_STS_PROTECTION(void);

/* SchM_Exit APIS */
extern void SchM_Exit_Com_RX_DM_STS_PROTECTION_AREA(void);
extern void SchM_Exit_Com_RX_IPDU_STS_PROTECTION_AREA(void);
extern void SchM_Exit_Com_TX_IPDU_STATUS_PROTECTION(void);
extern void SchM_Exit_Com_TX_IPDU_DATA_PROTECTION(void);
extern void SchM_Exit_Com_TX_SIG_STS_PROTECTION_AREA(void);
extern void SchM_Exit_Com_RX_IPDU_STATUS_PROTECTION(void);
extern void SchM_Exit_Com_TX_SIG_DATA_PROTECTION_AREA(void);
extern void SchM_Exit_Com_SIG_DATA_PROTECTION_AREA(void);
extern void SchM_Exit_Com_RX_SIG_DATA_PROTECTION_AREA(void);
extern void SchM_Exit_Com_RX_IPDU_DATA_PROTECTION_AREA(void);
extern void SchM_Exit_Com_IPDU_GRP_STS_PROTECTION(void);
extern void SchM_Exit_Com_IPDU_STS_PROTECTION(void);

#endif /* SCHM_COM_H */
/*******************************************************************************
**                       End of File                                          **
*******************************************************************************/
