/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Rte_EcuM_Type.h                                               **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR ECUM                                                  **
**                                                                            **
**  PURPOSE   : Header file for Rte and EcuM Type definitions                 **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                    Description                  **
********************************************************************************
** 1.0.0     28-Dec-2012   Shanthi Vishwanath    Initial version              **
*******************************************************************************/

#ifndef RTE_ECUM_TYPE_H
#define RTE_ECUM_TYPE_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Rte_Type.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
typedef uint8 EcuM_StateType;
/* ECU State Manager states */
#define ECUM_STATE_STARTUP                0x10
#define ECUM_STATE_STARTUP_ONE            0x11
#define ECUM_STATE_STARTUP_TWO            0x12
#define ECUM_STATE_WAKEUP                 0x20
#define ECUM_STATE_WAKEUP_ONE             0x21
#define ECUM_STATE_WAKEUP_VALIDATION      0x22
#define ECUM_STATE_WAKEUP_REACTION        0x23
#define ECUM_STATE_WAKEUP_TWO             0x24
#define ECUM_STATE_WAKEUP_WAKESLEEP       0x25
#define ECUM_STATE_WAKEUP_TTII            0x26
#define ECUM_STATE_RUN                    0x30
#define ECUM_STATE_APP_RUN                0x32
#define ECUM_STATE_APP_POST_RUN           0x33
#define ECUM_STATE_SHUTDOWN               0x40
#define ECUM_STATE_PREP_SHUTDOWN          0x44
#define ECUM_STATE_GO_SLEEP               0x49
#define ECUM_STATE_GO_OFF_ONE             0x4d
#define ECUM_STATE_GO_OFF_TWO             0x4e
#define ECUM_STATE_SLEEP                  0x50
#define ECUM_STATE_OFF                    0x80
#define ECUM_STATE_RESET                  0x90
#define ECUM_SUBSTATE_MASK                0x0f

typedef uint8 EcuM_UserType;

typedef uint8 EcuM_BootTargetType;
/* The boot targets supported by the ECU State Manager */
#define ECUM_BOOT_TARGET_APP 0x00
#define ECUM_BOOT_TARGET_OEM_BOOTLOADER 0x01
#define ECUM_BOOT_TARGET_SYS_BOOTLOADER 0x02

typedef uint8 EcuM_ShutdownCauseType;
/* The boot targets supported by the ECU State Manager */
#define ECUM_CAUSE_UNKNOWN               0x00
#define ECUM_CAUSE_ECU_STATE             0x01
#define ECUM_CAUSE_WDGM                  0x02
#define ECUM_CAUSE_DCM                   0x03

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#endif /* RTE_ECUM_TYPE_H */
/*******************************************************************************
                          End of the file
*******************************************************************************/
