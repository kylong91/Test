/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: SchM_FiM.h                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Function Inhibition Manager                           **
**                                                                            **
**  PURPOSE   : SchM_FiM.h                                                    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.3     12-Jul-2012   UKB    Initial version                             **
*******************************************************************************/

#ifndef SCHM_FIM_H
#define SCHM_FIM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void SchM_Enter_FiM_REQUEST_EVENTID_PROTECTION(void);
extern void SchM_Exit_FiM_REQUEST_EVENTID_PROTECTION(void);
extern void SchM_Enter_FiM_REQUEST_FID_PROTECTION(void);
extern void SchM_Exit_FiM_REQUEST_FID_PROTECTION(void);

#endif /* SCHM_FIM_H */
/*******************************************************************************
                          End of the file
*******************************************************************************/
