/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Rte_BswM.h                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Bsw Mode Manager                                      **
**                                                                            **
**  PURPOSE   : Declaration of Rte functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     28-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef RTE_MAIN_H
#define RTE_MAIN_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/


/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern boolean TestRte_Start(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);

extern Std_ReturnType Rte_Start(void);

extern Std_ReturnType Rte_Stop(void);

extern boolean TestRte_Stop(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
  

#endif /* RTE_MAIN_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
