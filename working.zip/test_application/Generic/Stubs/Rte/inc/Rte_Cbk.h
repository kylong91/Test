/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Com.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Rte                                                   **
**                                                                            **
**  PURPOSE   : Declaration of Rte functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     21-Dec-2011   GKM    Creation of Rte_Cbk.h                       **
** 4.0.1     07-Feb-2012   RPS    TestRte_DefaultBehavior is removed          **
*******************************************************************************/
#ifndef RTE_CBK_H
#define RTE_CBK_H

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Platform_Types.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
typedef boolean (*TestCallBackType[10])(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTxTOut_s4(void);
extern boolean TestRte_COMCbkTxTOut_s4(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s7(void);
extern boolean TestRte_COMCbkRxTOut_s7(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s8(void);
extern boolean TestRte_COMCbkRxTOut_s8(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s9(void);
extern boolean TestRte_COMCbkRxTOut_s9(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s10(void);
extern boolean TestRte_COMCbkRxTOut_s10(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s11(void);
extern boolean TestRte_COMCbkRxTOut_s11(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s12(void);
extern boolean TestRte_COMCbkRxTOut_s12(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTAck_s4(void);
extern boolean TestRte_COMCbkTAck_s4(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s3(void);
extern boolean TestRte_COMCbk_s3(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_s4(void);
extern boolean TestRte_COMCbkInv_s4(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s9(void);
extern boolean TestRte_COMCbk_s9(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_s9(void);
extern boolean TestRte_COMCbkInv_s9(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s10(void);
extern boolean TestRte_COMCbk_s10(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_s14(void);
extern boolean TestRte_COMCbkInv_s14(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s14(void);
extern boolean TestRte_COMCbk_s14(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s15(void);
extern boolean TestRte_COMCbk_s15(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_s16(void);
extern boolean TestRte_COMCbkInv_s16(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s16(void);
extern boolean TestRte_COMCbk_s16(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_sg1(void);
extern boolean TestRte_COMCbk_sg1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_sg2(void);
extern boolean TestRte_COMCbk_sg2(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_sg3(void);
extern boolean TestRte_COMCbkInv_sg3(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_sg4(void);
extern boolean TestRte_COMCbkInv_sg4(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_sg5(void);
extern boolean TestRte_COMCbkInv_sg5(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_sg6(void);
extern boolean TestRte_COMCbkInv_sg6(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s1(void);
extern boolean TestRte_COMCbkRxTOut_s1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s2(void);
extern boolean TestRte_COMCbkRxTOut_s2(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s3(void);
extern boolean TestRte_COMCbkRxTOut_s3(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s4(void);
extern boolean TestRte_COMCbkRxTOut_s4(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s5(void);
extern boolean TestRte_COMCbkRxTOut_s5(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s6(void);
extern boolean TestRte_COMCbkRxTOut_s6(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_sg6(void);
extern boolean TestRte_COMCbkRxTOut_sg6(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_sg3(void);
extern boolean TestRte_COMCbkRxTOut_sg3(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s34(void);
extern boolean TestRte_COMCbkRxTOut_s34(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s35(void);
extern boolean TestRte_COMCbkRxTOut_s35(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s36(void);
extern boolean TestRte_COMCbkRxTOut_s36(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_sg1(void);
extern boolean TestRte_COMCbkRxTOut_sg1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s31(void);
extern boolean TestRte_COMCbkRxTOut_s31(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s32(void);
extern boolean TestRte_COMCbkRxTOut_s32(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s33(void);
extern boolean TestRte_COMCbkRxTOut_s33(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_s1(void);
extern boolean TestRte_COMCbkInv_s1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_sg1(void);
extern boolean TestRte_COMCbkInv_sg1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTAck_s2(void);
extern boolean TestRte_COMCbkTAck_s2(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTAck_sg1(void);
extern boolean TestRte_COMCbkTAck_sg1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTAck_s1(void);
extern boolean TestRte_COMCbkTAck_s1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTAck_sg2(void);
extern boolean TestRte_COMCbkTAck_sg2(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s2(void);
extern boolean TestRte_COMCbk_s2(App_DataValidateType LenDataValidate);
extern void Rte_COMCbk_s1(void);
extern boolean TestRte_COMCbk_s1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTxTOut_s3(void);
extern boolean TestRte_COMCbkTxTOut_s3(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTxTOut_sg2(void);
extern boolean TestRte_COMCbkTxTOut_sg2(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTxTOut_s1(void);
extern boolean TestRte_COMCbkTxTOut_s1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTxTOut_s2(void);
extern boolean TestRte_COMCbkTxTOut_s2(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkTxTOut_sg1(void);
extern boolean TestRte_COMCbkTxTOut_sg1(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_s21(void);
extern boolean TestRte_COMCbkRxTOut_s21(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkRxTOut_sg8(void);
extern boolean TestRte_COMCbkRxTOut_sg8(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_s2(void);
extern boolean TestRte_COMCbkInv_s2(App_DataValidateType LenDataValidate);
extern void Rte_COMCbkInv_s2(void);

#endif /*RTE_CBK_H*/

/*******************************************************************************
**                       End of File                                          **
*******************************************************************************/
