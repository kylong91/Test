/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Rte_Det_Type.h                                                **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Rte                                                   **
**                                                                            **
**  PURPOSE   : Declaration of Rte Types                                      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     12-Mar-2012   SHV    Initial version                             **
*******************************************************************************/
#ifndef RTE_DET_TYPE_H
#define RTE_DET_TYPE_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Rte_Type.h"
/* COMPATIBLE WITH C and C++ languages */
#ifdef __cplusplus
 extern "C"

#endif

/*******************************************************************************
** Type Definitions for AUTOSAR data types                                    **
*******************************************************************************/

#define IN
/*******************************************************************************
** Typedefs of Modes
*******************************************************************************/

#endif /* RTE_DET_TYPE_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/


