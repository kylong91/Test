/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Rte_Dlt_Type.h                                                **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Rte                                                   **
**                                                                            **
**  PURPOSE   : Declaration of Rte Types                                      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     12-Mar-2012   SHV    Initial version                             **
*******************************************************************************/
#ifndef RTE_DLT_TYPE_H
#define RTE_DLT_TYPE_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Std_Types.h"
/* COMPATIBLE WITH C and C++ languages */
#ifdef __cplusplus
 extern "C" 
 {
#endif 

/*******************************************************************************
** Type Definitions for AUTOSAR data types                                    **
*******************************************************************************/

typedef uint8 UInt8;
#define IN
/*******************************************************************************
** Typedefs of Modes
*******************************************************************************/
typedef uint16 Dlt_MessageArgumentCount;

typedef uint32 Dlt_SessionIDType;

typedef uint32 Dlt_ApplicationIDType;

typedef uint32 Dlt_ContextIDType;

typedef uint8 Dlt_MessageIDType;

typedef uint8 Dlt_MessageOptionsType;

typedef enum
{
  DLT_E_OK,
  DLT_E_INT_BUFFER_FULL,
  DLT_E_MSG_TOO_LARGE,
  DLT_E_CONTEXT_ALREADY_REG,
  DLT_E_UNKNOWN_SESSION_ID,
  DLT_E_IF_NOT_AVAILABLE,
  DLT_E_IF_BUSY,
  DLT_E_ERROR_UNKNOWN
} Dlt_ReturnType;

typedef enum
{
  DLT_TYPE_LOG = 1,
  DLT_TYPE_APP_TRACE,
  DLT_TYPE_NW_TRACE,
  DLT_TYPE_CONTROL
} Dlt_MessageTypeType;

typedef enum
{
  DLT_TRACE_VARIABLE = 1,
  DLT_TRACE_FUNCTION_IN,
  DLT_TRACE_FUNCTION_OUT,
  DLT_TRACE_STATE,
  DLT_TRACE_VFB
} Dlt_MessageTraceType;

typedef enum
{
  DLT_LOG_OFF,
  DLT_LOG_FATAL,
  DLT_LOG_ERROR,
  DLT_LOG_WARN,
  DLT_LOG_INFO,
  DLT_LOG_DEBUG,
  DLT_LOG_VERBOSE
} Dlt_MessageLogLevelType;

typedef struct STag_Dlt_MessageLogInfoType
{
  Dlt_MessageArgumentCount arg_count;
  Dlt_MessageLogLevelType log_level;
  Dlt_MessageOptionsType options;
  Dlt_ContextIDType context_id;
  Dlt_ApplicationIDType app_id;
}Dlt_MessageLogInfoType;

typedef struct STag_Dlt_MessageTraceInfoType
{
  Dlt_MessageTraceType trace_info;
  Dlt_MessageOptionsType options;
  Dlt_ContextIDType context;
  Dlt_ApplicationIDType app_id;
}Dlt_MessageTraceInfoType;




#endif /* RTE_DLT_TYPE_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/


