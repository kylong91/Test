/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: SchM_Dbg.h                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR DBG                                                   **
**                                                                            **
**  PURPOSE   : Declaration of SchM  functions                                **
**                                                                            **
**  PLATFORM DEPENDANT [Yes/No]: No                                           **
**                                                                            **
**  TO BE CHANGED BY USER [Yes/No]: No                                        **
**                                                                            **
*******************************************************************************/


/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By         Description                             **
********************************************************************************
** 4.0.0     22-Mar-2012   RPS        Creation of SchM_Dbg.h module           **
*******************************************************************************/
#ifndef SCHM_DBG_H
#define SCHM_DBG_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"   
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define SCHM_DBG_AR_MAJOR_VERSION         4
#define SCHM_DBG_AR_MINOR_VERSION         0
#define SCHM_DBG_AR_PATCH_VERSION         2

/* Software Version Information */
#define SCHM_DBG_SW_MAJOR_VERSION         4
#define SCHM_DBG_SW_MINOR_VERSION         0


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void SchM_Enter_Dbg_TX_BUFFER_PROTECTION(void);

extern void SchM_Exit_Dbg_TX_BUFFER_PROTECTION(void);

extern void SchM_Enter_Dbg_RING_BUFFER_PROTECTION(void);

extern void SchM_Exit_Dbg_RING_BUFFER_PROTECTION(void);

extern void SchM_Enter_Dbg_COLLECTION_STATUS_PROTECTION(void);

extern void SchM_Exit_Dbg_COLLECTION_STATUS_PROTECTION(void);

extern void SchM_Enter_Dbg_DATA_RECORD_PROTECTION(void);

extern void SchM_Exit_Dbg_DATA_RECORD_PROTECTION(void);

#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
