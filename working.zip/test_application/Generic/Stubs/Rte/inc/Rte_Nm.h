/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Rte_Nm.h                                                      **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Rte Stub                                              **
**                                                                            **
**  PURPOSE   : Declaration of Rte Stub functions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     05-Apr-2012   CRC    Creation of Rte_Dcm.h module                **
*******************************************************************************/
#ifndef RTE_NM_H
#define RTE_NM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
#include "ComStack_Types.h" /* For NetworkHandleType */

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void Rte_Nm_CarWakeUpIndication(const NetworkHandleType nmNetworkHandle);

extern boolean TestRte_Nm_CarWakeUpIndication(App_DataValidateType LddDataValidate,
  NetworkHandleType nmNetworkHandle);
  
#endif /* End RTE_NM_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
