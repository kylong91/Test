/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE:  SchM_LinIf.h                                                 **
**                                                                            **
**  TARGET    :  ALL                                                          **
**                                                                            **
**  PRODUCT   : AUTOSAR SchM Module                                           **
**                                                                            **
**  PURPOSE   : This file is a stub for LinIf Module.                         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     09/03/2010    KBH    Initial version                             **
** 4.0.1     04-Apr-2012   RPS    Updated for LinIf                           **
*******************************************************************************/

#ifndef SCHM_LINIF_H
#define SCHM_LINIF_H

/*******************************************************************************
* I N C L U D E S                                                              *
*******************************************************************************/
#include "ComStack_Types.h"

/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/
/*******************************************************************************
**                      Function Prototype                                    **
*******************************************************************************/

extern void SchM_Enter_LinIf_CHANNEL_STATUS_PROTECTION(void);
extern void SchM_Exit_LinIf_CHANNEL_STATUS_PROTECTION(void);
extern void SchM_Enter_LinIf_SLEEP_REQUEST_STATUS_PROTECTION(void);
extern void SchM_Exit_LinIf_SLEEP_REQUEST_STATUS_PROTECTION(void);
extern void SchM_Enter_LinIf_SPORADIC_STATUS_PROTECTION(void);
extern void SchM_Exit_LinIf_SPORADIC_STATUS_PROTECTION(void);
extern void SchM_Enter_LinIf_WAKEUP_CONFCOUNT_PROTECTION(void);
extern void SchM_Exit_LinIf_WAKEUP_CONFCOUNT_PROTECTION(void);
extern void SchM_Enter_LinIf_STATUS_PROTECTION(void);
extern void SchM_Exit_LinIf_STATUS_PROTECTION(void);

#endif

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/


