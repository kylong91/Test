/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Rte_Dcm.h                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Rte Stub
**                                                                            **
**  PURPOSE   : Declaration of Rte Stub functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     05-Apr-2012   CRC    Creation of Rte_Dcm.h module                **
** 4.0.1     12-Apr-2012   RPS    Updated for Dcm                             **
*******************************************************************************/
#ifndef RTE_DCM_H
#define RTE_DCM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
#include "Dcm_Types.h"
#include "Rte_DCM_Type.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#define RTE_MAXVALUE                        (uint8)0xFF

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Std_ReturnType RTE_DcmStopProtocol(Dcm_ProtocolType ProtocolID);

extern Std_ReturnType RTE_DcmStartProtocol(Dcm_ProtocolType ProtocolID);

extern void TestRte_DefaultBehavior(void);

extern Std_ReturnType Rte_Call_DCM_CallbackDCMRequestServices_SWC1_StartProtocol
  (Dcm_ProtocolType ProtocolID);
extern Std_ReturnType Rte_Call_DCM_CallbackDCMRequestServices_SWC1_StopProtocol
  (Dcm_ProtocolType ProtocolID); 
extern void SetRte_DefaultBehaviorGetSeed(uint8 *LpSeed, uint8 LucDataLength);

extern void SetRte_DefaultBehaviorGetSeedReturn(Std_ReturnType LddRetType,
  Dcm_NegativeResponseCodeType LddNegResCode);
  
extern void SetRte_DefaultBehaviorGetSeedReturnOne(Std_ReturnType LddRetType);

extern void SetRte_DefaultBehaviorCompareKey(Std_ReturnType LddKeyRetType);

extern Std_ReturnType Rte_GetSeed(uint8 *LpSecurityAccessDataRecord,
  Dcm_OpStatusType LddOpStatus, uint8 *LpSeed, Dcm_NegativeResponseCodeType
    *LddErrorCode);
    
extern boolean TestRte_GetSeed(App_DataValidateType LddDataValidate, uint8
  *LucSecurityAccessDataRecord, Dcm_OpStatusType LddOpStatus, uint8 *LpExpSeed,
    Dcm_NegativeResponseCodeType *LddExpErrorCode, uint16 LucDataLength);
    
extern Std_ReturnType Rte_CompareKey(uint8 *LucKey, Dcm_OpStatusType
  LddOpStatus);
  
extern boolean TestRte_CompareKey(App_DataValidateType LddDataValidate,
  uint8 *LucKey, Dcm_OpStatusType LddOpStatus, uint16 LusDataLength);
  
extern void SetRte_Call_DCM_DidServices_F112_ConditionCheckRead(Std_ReturnType 
  LddRetType, Dcm_NegativeResponseCodeType LddNegResCode);
  
extern Std_ReturnType Rte_Call_DCM_DidServices_F112_ConditionCheckRead(
  Dcm_OpStatusType LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode);
  
extern boolean TestRte_Call_DCM_DidServices_F112_ConditionCheckRead(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
  Dcm_NegativeResponseCodeType *LddExpErrorCode);

extern void SetRte_Call_DCM_DidServices_F113_ConditionCheckRead(Std_ReturnType 
  LddRetType, Dcm_NegativeResponseCodeType LucNegResCode);
  
extern Std_ReturnType Rte_Call_DCM_DidServices_F113_ConditionCheckRead(
  Dcm_OpStatusType LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode);
  
extern boolean TestRte_Call_DCM_DidServices_F113_ConditionCheckRead(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
  Dcm_NegativeResponseCodeType *LddExpErrorCode);

extern void SetRte_Call_DCM_DidServices_F114_ReadDataReturn(Std_ReturnType
  LddRetType);
  
extern void SetRte_Call_DCM_DidServices_F114_ReadData(uint8 *LpData,
  uint8 LucLength);
  
extern void SetRte_Call_DCM_DidServices_F114_ConditionCheckRead(Std_ReturnType
  LddReturnType);
  
extern Std_ReturnType Rte_Call_DCM_DidServices_F114_ConditionCheckRead(
  Dcm_OpStatusType LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode);
  
extern Std_ReturnType Rte_Call_DCM_DidServices_F114_ReadData(Dcm_OpStatusType 
  LddOpStatus, uint8 *LpData);
  
extern boolean TestRte_Call_DCM_DidServices_F114_ConditionCheckRead(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
  Dcm_NegativeResponseCodeType *LddExpErrorCode);
    
extern boolean TestRte_Call_DCM_DidServices_F114_ReadData(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    uint8 *LpExpData);
    
extern void SetRte_Call_DCM_DidServices_F115_ReadDataReturn(Std_ReturnType
  LddRetType);
  
extern void SetRte_Call_DCM_DidServices_F115_ReadData(uint8 *LpData,
  uint8 LucLength);
  
extern Std_ReturnType Rte_Call_DCM_DidServices_F115_ConditionCheckRead(
  Dcm_OpStatusType LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode);
  
extern Std_ReturnType Rte_Call_DCM_DidServices_F115_ReadData(Dcm_OpStatusType 
  LddOpStatus, uint8 *LpData);
  
extern boolean TestRte_Call_DCM_DidServices_F115_ConditionCheckRead(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    Dcm_NegativeResponseCodeType *LpExpErrorCode);
    
extern boolean TestRte_Call_DCM_DidServices_F115_ReadData(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    uint8 *LpExpData);
    
extern void SetRte_Call_DCM_DidServices_F116_ReadDataReturn(Std_ReturnType
  LddRetType);
  
extern void SetRte_Call_DCM_DidServices_F116_ReadData(uint8 *LpData,
  uint8 LucLength);
  
extern void SetRte_Call_DCM_DidServices_F116_ReadDataLength(uint16
  LusDataLength);
  
extern Std_ReturnType Rte_Call_DCM_DidServices_F116_ConditionCheckRead(
  Dcm_OpStatusType LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode);
  
extern Std_ReturnType Rte_Call_DCM_DidServices_F116_ReadData(Dcm_OpStatusType 
  LddOpStatus, uint8 *LpData);
  
extern Std_ReturnType Rte_Call_DCM_DidServices_F116_ReadDataLength(uint16
  *LusData);
  
extern boolean TestRte_Call_DCM_DidServices_F116_ConditionCheckRead(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    Dcm_NegativeResponseCodeType *LddExpErrorCode);
    
extern boolean TestRte_Call_DCM_DidServices_F116_ReadData(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    uint8 *LpExpData);
    
extern boolean TestRte_Call_DCM_DidServices_F116_ReadDataLength(
  App_DataValidateType LddDataValidate, uint16 *LusExpDataLength);
  
extern void SetRte_Call_DCM_DidServices_F117_ReadDataReturn(Std_ReturnType
  LddRetType);
  
extern void SetRte_Call_DCM_DidServices_F117_ReadData(uint8 *LpData,
  uint8 LucLength);
  
extern void SetRte_Call_DCM_DidServices_F117_ReadDataLength(uint16
  LusDataLength);
  
extern Std_ReturnType Rte_Call_DCM_DidServices_F117_ConditionCheckRead(
  Dcm_OpStatusType LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode);
  
extern Std_ReturnType Rte_Call_DCM_DidServices_F117_ReadData(Dcm_OpStatusType 
  LddOpStatus, uint8 *LpData);
  
extern Std_ReturnType Rte_Call_DCM_DidServices_F117_ReadDataLength(uint16
  *LucData);
  
extern boolean TestRte_Call_DCM_DidServices_F117_ConditionCheckRead(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    Dcm_NegativeResponseCodeType *LddExpErrorCode);
    
extern boolean TestRte_Call_DCM_DidServices_F117_ReadData(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    uint8 *LpExpData);
    
extern boolean TestRte_Call_DCM_DidServices_F117_ReadDataLength(
  App_DataValidateType LddDataValidate, uint16 *LpExpDataLength);
  
extern void SetRte_Call_DCM_DidServices_F118_ReadData(uint8 *LpData, uint8
  LucLength);
  
extern void SetRte_Call_DCM_DidServices_F118_ReadDataLength(uint16
  LusDataLength);
  
extern Std_ReturnType Rte_Call_DCM_DidServices_F118_ConditionCheckRead(
  Dcm_OpStatusType LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode);
  
extern Std_ReturnType Rte_Call_DCM_DidServices_F118_ReadData(Dcm_OpStatusType 
  LddOpStatus, uint8 *LpData);
  
extern Std_ReturnType Rte_Call_DCM_DidServices_F118_ReadDataLength(uint16
  *LucData);
  
extern boolean TestRte_Call_DCM_DidServices_F118_ConditionCheckRead(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    Dcm_NegativeResponseCodeType *LddExpErrorCode);
    
extern boolean TestRte_Call_DCM_DidServices_F118_ReadData(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8
    *LpExpData);
    
extern boolean TestRte_Call_DCM_DidServices_F118_ReadDataLength(
  App_DataValidateType LddDataValidate, uint16 *LucExpDataLength);
  
extern void SetRte_Call_DCM_DidServices_F119_ReadData(uint8 *LpData,
  uint8 LucLength);
  
extern Std_ReturnType Rte_Call_DCM_DidServices_F119_ConditionCheckRead(
  Dcm_OpStatusType LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode);
  
extern Std_ReturnType Rte_Call_DCM_DidServices_F119_ReadData(Dcm_OpStatusType 
  LddOpStatus, uint8 *LpData);
  
extern boolean TestRte_Call_DCM_DidServices_F119_ConditionCheckRead(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    Dcm_NegativeResponseCodeType *LddExpErrorCode);
    
extern boolean TestRte_Call_DCM_DidServices_F119_ReadData(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    uint8 *LpExpData);
    
extern void SetRte_Call_DCM_PidServices_03_GetPIDValue(uint8 *LpData, uint8
  LucLength);
  
extern Std_ReturnType Rte_Call_DCM_PidServices_03_GetPIDValue(Dcm_OpStatusType 
  LddOpStatus, uint8 *LpData);
  
extern boolean TestRte_Call_DCM_PidServices_03_GetPIDValue(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData);
  
extern void SetRte_Call_DCM_DTRServices_21_GetDTRValue(uint16 LusTestVal, uint16
  LusMinLimit, uint16 LusMaxLimit, uint8 LcuStatus);
  
extern Std_ReturnType Rte_Call_DCM_DTRServices_21_GetDTRValue(Dcm_OpStatusType
  LddOpStatus, uint16 *LpTestval, uint16 *LpMinlimit, uint16 *LpMaxlimit, 
    uint8 *LpStatus);
    
/*extern boolean TestRte_Call_DCM_DTRServices_21_GetDTRValue(App_DataValidateType
  LddDataValidate, DDcm_OpStatusType LddExpOpStatus, uint16 *LpExpTestval,
    uint16 *LpExpMinlimit, uint16 *LpExpMaxlimit, uint8 *LpExpStatus);*/
    
extern void SetRte_Call_DCM_InfotypeServices_09_GetInfoTypeValueData(uint8
  *LpData, uint8 LucLength);
  
extern Std_ReturnType Rte_Call_DCM_InfotypeServices_09_GetInfoTypeValueData(
  Dcm_OpStatusType LddOpStatus, uint8 *LpDataValueBuffer);
  
extern boolean TestRte_Call_DCM_InfotypeServices_09_GetInfoTypeValueData(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8
    *LpExpData);
    
extern void SimulateRte_Call_DCM_F016_ReturnControlToEcuReturn(Std_ReturnType
  LddReturnType);
  
extern void SimulateRte_Call_DCM_F016_ReturnControlToEcu(Std_ReturnType LddReturnType,
  Dcm_NegativeResponseCodeType LddErrorCode);
  
extern void SimulateRte_Call_DCM_F016_ReadData(uint8 *LpData, uint8 LucLength);

extern Std_ReturnType Rte_Call_DCM_F016_ReturnControlToEcu(Dcm_OpStatusType
  LddOpStatus, Dcm_NegativeResponseCodeType *LpErrorCode);
  
extern Std_ReturnType Rte_Call_DCM_F016_ReadData(Dcm_OpStatusType LddOpStatus,
  uint8 *LpData);
  
extern boolean TestRte_Call_DCM_F016_ReturnControlToEcu(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, Dcm_NegativeResponseCodeType
    *LpExpErrorCode);
    
extern boolean TestRte_Call_DCM_F016_ReadData(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData);
  
extern void SimulateRte_Call_DCM_F017_ResetToDefault(Std_ReturnType
  LddReturnType, Dcm_NegativeResponseCodeType LddErrorCode);
  
extern void SimulateRte_Call_DCM_F017_ReadData(uint8 *LpData, uint8 LucLength);

extern Std_ReturnType Rte_Call_DCM_F017_ResetToDefault(Dcm_OpStatusType
  LddOpStatus, Dcm_NegativeResponseCodeType *LpErrorCode);
  
extern Std_ReturnType Rte_Call_DCM_F017_ReadData(Dcm_OpStatusType LddOpStatus,
  uint8 *LpData);
  
extern boolean TestRte_Call_DCM_F017_ResetToDefault(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, Dcm_NegativeResponseCodeType
    *LpExpErrorCode);
    
extern boolean TestRte_Call_DCM_F017_ReadData(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData);
  
extern void SimulateRte_Call_DCM_F018_FreezeCurrentStateReturn(Std_ReturnType
  LddReturnType);
  
extern void SimulateRte_Call_DCM_F018_FreezeCurrentState(Std_ReturnType
  LddReturnType, Dcm_NegativeResponseCodeType LddErrorCode);
  
extern void SimulateRte_Call_DCM_F018_ReadData(uint8 *LpData, uint8 LucLength);

extern Std_ReturnType Rte_Call_DCM_F018_FreezeCurrentState(Dcm_OpStatusType
  LddOpStatus, Dcm_NegativeResponseCodeType *LpErrorCode);
  
extern Std_ReturnType Rte_Call_DCM_F018_ReadData(Dcm_OpStatusType LddOpStatus,
  uint8 *LpData);
  
extern boolean TestRte_Call_DCM_F018_FreezeCurrentState(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, Dcm_NegativeResponseCodeType
    *LpExpErrorCode);
    
extern boolean TestRte_Call_DCM_F018_ReadData(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData);
  
extern void SimulateRte_Call_DCM_F019_ShortTermAdjustmentReturn(Std_ReturnType
  LddReturnType);
  
extern void SimulateRte_Call_DCM_F019_ShortTermAdjustment(Std_ReturnType
  LddReturnType, Dcm_NegativeResponseCodeType LddErrorCode);
  
extern void SimulateRte_Call_DCM_F019_ReadData(uint8 *LpData, uint8 LucLength);

extern Std_ReturnType Rte_Call_DCM_F019_ShortTermAdjustment(uint8
  *LpControlOptionRecord, Dcm_OpStatusType LddOpStatus,
    Dcm_NegativeResponseCodeType *LpErrorCode);
    
extern Std_ReturnType Rte_Call_DCM_F019_ReadData(Dcm_OpStatusType LddOpStatus,
  uint8 *LpData);
  
extern boolean TestRte_Call_DCM_F019_ShortTermAdjustment(App_DataValidateType
  LddDataValidate, uint8 *LucControlOptionRecord, Dcm_OpStatusType
    LddExpOpStatus, Dcm_NegativeResponseCodeType *LpExpErrorCode);
    
extern boolean TestRte_Call_DCM_F019_ReadData(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData);
  
extern void SimulateRte_Call_DCM_DidServices_F190_GetScalingInfoReturn(
  Std_ReturnType LddReturn);
  
extern void SimulateRte_Call_DCM_DidServices_F190_GetScalingInfoReturnData(
  Std_ReturnType LddReturn, uint8 *LpScalingInfo, uint8 LucLength);
  
extern void SimulateRte_Call_DCM_DidServices_F190_GetScalingInformationReturn(
  Std_ReturnType LddReturn, Dcm_NegativeResponseCodeType LddErrorCode);
  
extern void SimulateRte_Call_DCM_DidServices_F190_GetScalingInformation(uint8
  *LpScalingInfo, uint8 LucLength);
  
/*extern Std_ReturnType Rte_Call_DCM_DidServices_F190_GetScalingInformation(
  Dcm_OpStatusType LddOpStatus, UInt8 *LpScalingInfo,
    Dcm_NegativeResponseCodeType *LpErrorCode);*/
    
extern boolean TestRte_Call_DCM_DidServices_F190_GetScalingInformation(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    uint8 *LpExpScalingInfo, Dcm_NegativeResponseCodeType *LpExpErrorCode);
    
extern void SimulateRte_Call_DCM_DidServices_F191_GetScalingInfoReturn(
  Std_ReturnType LddReturn);
  
extern void SimulateRte_Call_DCM_DidServices_F191_GetScalingInfoReturnData(
  Std_ReturnType LddReturn, uint8 *LpScalingInfo, uint8 LucLength);
  
extern void SimulateRte_Call_DCM_DidServices_F191_GetScalingInformationReturn(
  Std_ReturnType LddReturn, Dcm_NegativeResponseCodeType LddErrorCode);
  
extern void SimulateRte_Call_DCM_DidServices_F191_GetScalingInformation(uint8
  *LpScalingInfo, uint8 LucLength);
  
/*extern Std_ReturnType Rte_Call_DCM_DidServices_F191_GetScalingInformation(
  Dcm_OpStatusType LddOpStatus, UInt8 *LpScalingInfo,
    Dcm_NegativeResponseCodeType *LpErrorCode);*/
    
extern boolean TestRte_Call_DCM_DidServices_F191_GetScalingInformation(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    uint8 *LpExpScalingInfo, Dcm_NegativeResponseCodeType *LpExpErrorCode);
    
extern void SimulateRte_Call_DCM_DidServices_F188_WriteDataReturn(Std_ReturnType
  LddReturn);
  
extern void SimulateRte_Call_DCM_DidServices_F188_WriteData(Std_ReturnType
  LddReturn, Dcm_NegativeResponseCodeType LddErrorCode);
  
extern Std_ReturnType Rte_Call_DCM_DidServices_F188_WriteData(uint8 *LpData,
  uint16 LusDataLength, Dcm_OpStatusType LddOpStatus,
    Dcm_NegativeResponseCodeType *LpErrorCode);
    
extern boolean TestRte_Call_DCM_DidServices_F188_WriteData(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData, uint16
    LusExpDataLength, Dcm_NegativeResponseCodeType *LpExpErrorCode);
    
extern void SimulateRte_Call_DCM_DidServices_F189_WriteDataReturn(Std_ReturnType
  LddReturn);
  
extern void SimulateRte_Call_DCM_DidServices_F189_WriteData(Std_ReturnType
  LddReturn, Dcm_NegativeResponseCodeType LddErrorCode);
  
extern Std_ReturnType Rte_Call_DCM_DidServices_F189_WriteData(uint8 *LpData,
  uint16 LusDataLength, Dcm_OpStatusType LddOpStatus,
    Dcm_NegativeResponseCodeType *LpErrorCode);
    
extern boolean TestRte_Call_DCM_DidServices_F189_WriteData(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData, uint16
    LusExpDataLength, Dcm_NegativeResponseCodeType *LpExpErrorCode);
    
extern Std_ReturnType Rte_Call_DCM_DidServices_F192_WriteData(uint8 *LpData,
  uint16 LusDataLength, Dcm_OpStatusType LddOpStatus,
    Dcm_NegativeResponseCodeType *LpErrorCode);
    
extern boolean TestRte_Call_DCM_DidServices_F192_WriteData(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData, uint16
    LusExpDataLength, Dcm_NegativeResponseCodeType *LpExpErrorCode);
    
extern Std_ReturnType Rte_Call_DCM_DidServices_F193_WriteData(uint8 *LpData,
  uint16 LusDataLength, Dcm_OpStatusType LddOpStatus,
    Dcm_NegativeResponseCodeType *LpErrorCode);
    
extern boolean TestRte_Call_DCM_DidServices_F193_WriteData(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData, uint16
    LusExpDataLength, Dcm_NegativeResponseCodeType *LpExpErrorCode);
    
extern Std_ReturnType Rte_Call_DCM_DidServices_F194_WriteData(uint8 *LpData,
  uint16 LusDataLength, Dcm_OpStatusType LddOpStatus,
    Dcm_NegativeResponseCodeType *LpErrorCode);
    
extern boolean TestRte_Call_DCM_DidServices_F194_WriteData(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData, uint16
    LusExpDataLength, Dcm_NegativeResponseCodeType *LpExpErrorCode);
    
extern void SimulateRte_Call_DCM_RoutineServices_0202_StartReturnData(
  Std_ReturnType LddReturn, uint8 *LpOutData, uint8 LucDataLength);
  
extern void SimulateRte_Call_DCM_RoutineServices_0202_StartReturn(Std_ReturnType
  LddReturn, Dcm_NegativeResponseCodeType LddErrorCode);
  
extern void SimulateRte_Call_DCM_RoutineServices_0202_Start(uint8 *LpOutData,
  Dcm_NegativeResponseCodeType LddErrorCode, uint8 LucDataLength);
  
extern Std_ReturnType Rte_Call_DCM_RoutineServices_0202_Start(uint8 *LpDataIn,
  Dcm_OpStatusType LddOpStatus, uint8 *LpDataOut, Dcm_NegativeResponseCodeType
    *LddErrorCode);
    
extern boolean TestRte_Call_DCM_RoutineServices_0202_Start(App_DataValidateType
  LddDataValidate, uint8 *LpExpDataIn, Dcm_OpStatusType LddExpOpStatus, uint8
    *LpExpDataOut, Dcm_NegativeResponseCodeType *LpExpErrorCode, uint16
      LusExpDataLength);
      
extern void SimulateRte_Call_DCM_RoutineServices_0203_StopReturn(Std_ReturnType
  LddReturn, Dcm_NegativeResponseCodeType LddErrorCode);
  
extern void SimulateRte_Call_DCM_RoutineServices_0203_Stop(uint8 *LpOutData,
  Dcm_NegativeResponseCodeType LddErrorCode, uint8 LucDataLength);
  
extern Std_ReturnType Rte_Call_DCM_RoutineServices_0203_Stop(uint8 *LpDataIn,
  Dcm_OpStatusType LddOpStatus, uint8 *LpDataOut, Dcm_NegativeResponseCodeType
    *LddErrorCode);
    
extern boolean TestRte_Call_DCM_RoutineServices_0203_Stop(App_DataValidateType
  LddDataValidate, uint8 *LpExpDataIn, Dcm_OpStatusType LddExpOpStatus, uint8
    *LpExpDataOut, Dcm_NegativeResponseCodeType *LpExpErrorCode, uint16
      LusExpDataLength);
      
extern void SimulateRte_Call_DCM_RoutineServices_0204_RequestResultsReturn(
  Std_ReturnType Dcm_GddGeneralReturn, Dcm_NegativeResponseCodeType
    LddErrorCode);
    
extern void SimulateRte_Call_DCM_RoutineServices_0204_RequestResults(uint8
  *LpOutData, Dcm_NegativeResponseCodeType LddErrorCode, uint8 LucDataLength);
  
extern Std_ReturnType Rte_Call_DCM_RoutineServices_0204_RequestResults(
  Dcm_OpStatusType LddOpStatus, uint8 *LpDataOut, Dcm_NegativeResponseCodeType
    *LddErrorCode);
    
extern boolean TestRte_Call_DCM_RoutineServices_0204_RequestResults(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8
    *LpExpDataOut, Dcm_NegativeResponseCodeType *LpExpErrorCode);
    
extern void SimulateRte_DcmStartProtocol(Std_ReturnType LddReturnType);

extern boolean TestRte_DcmStartProtocol(App_DataValidateType LddDataValidate,
   Dcm_ProtocolType LddExpProtocolType);
   
extern Std_ReturnType Rte_ConditionCheckRead(Dcm_OpStatusType LddOpStatus,
  Dcm_NegativeResponseCodeType *LddErrorCode);
  
extern void SetRte_ConditionCheckRead(Std_ReturnType LddReturnType, 
  Dcm_NegativeResponseCodeType LddErrorCode);
  
extern boolean TestRte_ConditionCheckRead(App_DataValidateType LddDataValidate,
  Dcm_OpStatusType LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode);
  


extern Std_ReturnType Rte_ReadData(Dcm_OpStatusType LddOpStatus, uint8 *LpData);


extern void SetRte_ReadData(uint8 *LpData, uint8 LucLength);

extern boolean TestRte_ReadData(App_DataValidateType LddDataValidate,
  Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData);
  
extern void SetRte_ReadDataReturn(Std_ReturnType LddReturnType);

extern Std_ReturnType Rte_ReadDataLength(uint16 *LusData);

extern void SetRte_ReadDataLength(uint16 LulDataLength);

extern boolean TestRte_ReadDataLength(
  App_DataValidateType LddDataValidate, uint16 *LusExpDataLength);
extern Std_ReturnType Rte_Call_DCM_DidServices_F124_ConditionCheckRead(
  Dcm_OpStatusType LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode);
extern Std_ReturnType Rte_Call_DCM_DidServices_F124_ReadData(Dcm_OpStatusType 
  LddOpStatus, uint8 *LpData);
  
extern void SetRte_Call_DCM_DidServices_F123_ReadDataReturn(Std_ReturnType
  LddRetType);
extern void SetRte_Call_DCM_DidServices_F123_ReadData(uint8 *LpData,
  uint8 LucLength);
extern void SetRte_Call_DCM_DidServices_F123_ReadDataLength(uint16
  LusDataLength);
extern Std_ReturnType Rte_Call_DCM_DidServices_F123_ConditionCheckRead(
  Dcm_OpStatusType LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode);
extern Std_ReturnType Rte_Call_DCM_DidServices_F123_ReadData(uint8 *LpData);
extern Std_ReturnType Rte_Call_DCM_DidServices_F123_ReadDataLength(uint16
  *LusData);
extern boolean TestRte_Call_DCM_DidServices_F123_ConditionCheckRead(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    Dcm_NegativeResponseCodeType *LddExpErrorCode);
extern boolean TestRte_Call_DCM_DidServices_F123_ReadData(
  App_DataValidateType LddDataValidate,
    uint8 *LpExpData);
extern boolean TestRte_Call_DCM_DidServices_F123_ReadDataLength(
  App_DataValidateType LddDataValidate, uint16 *LusExpDataLength);
extern Std_ReturnType Rte_SyncReadData( uint8 *LpData);
extern void SetRte_SyncReadData(uint8 *LpData, uint8 LucLength);
extern boolean TestRte_SyncReadData(App_DataValidateType LddDataValidate,
uint8 *LpExpData); 
 extern void SetRte_SyncReadDataReturn(Std_ReturnType LddReturnType);

#endif /* End RTE_DCM_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
