/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: SchM_CanTp.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR SchM Stub                                             **
**                                                                            **
**  PURPOSE   : Declaration of SchM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     23-Sep-2011   DCN    Creation of SchM_CanTp.h module             **
*******************************************************************************/

#ifndef SCHM_CANTP_H
#define SCHM_CANTP_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Std_Types.h"                  /* Standard type header */
#include "ComStack_Types.h"             /* ComStack type header */


/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define SCHM_AR_RELEASE_MAJOR_VERSION      4
#define SCHM_AR_RELEASE_MINOR_VERSION      0
#define SCHM_AR_RELEASE_REVISION_VERSION   2

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                      Exclusive Area                                        **
*******************************************************************************/

/*
 * This type define the exclusive areas along with scheduler services are used
 * to provide data integrity for shared resources
 */
#ifdef CANTP_MODULE_ACTIVE
extern void SchM_Enter_CanTp_TIMER_PROTECTION(void);
extern void SchM_Exit_CanTp_TIMER_PROTECTION(void);
#endif

#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

