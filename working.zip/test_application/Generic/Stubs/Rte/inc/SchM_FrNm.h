/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: SchM_FrNm.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR SchM FrNm Stub                                       **
**                                                                            **
**  PURPOSE   : Declaration of SchM FrNm Stub functions                      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     20-Dec-2011   RPS    Initial version                             **
*******************************************************************************/

#ifndef SCHM_FRNM_H
#define SCHM_FRNM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"             /* ComStack type header */

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define RTE_AR_RELEASE_MAJOR_VERSION  4
#define RTE_AR_RELEASE_MINOR_VERSION  0
#define RTE_AR_RELEASE_REVISION_VERSION  2

/* Software Version Information */
#define RTE_SW_MAJOR_VERSION  4
#define RTE_SW_MINOR_VERSION  0

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                      Exclusive Area                                        **
*******************************************************************************/

/*
 * This type define the exclusive areas along with scheduler services are used
 * to provide data integrity for shared resources
 */
extern void SchM_Enter_FrNm_TX_USER_DATA_CHANNEL0(void);
extern void SchM_Enter_FrNm_TX_USER_DATA_CHANNEL1(void);
extern void SchM_Enter_FrNm_TX_USER_DATA(void);
extern void SchM_Enter_FrNm_RX_USER_DATA_CHANNEL1(void);
extern void SchM_Enter_FrNm_RX_USER_DATA_CHANNEL0(void);
extern void SchM_Enter_FrNm_INTERNAL_STATUS_CHANNEL0(void);
extern void SchM_Enter_FrNm_INTERNAL_STATUS_CHANNEL1(void);
extern void SchM_Exit_FrNm_TX_USER_DATA_CHANNEL0(void);
extern void SchM_Exit_FrNm_TX_USER_DATA_CHANNEL1(void);
extern void SchM_Exit_FrNm_TX_USER_DATA(void);
extern void SchM_Exit_FrNm_RX_USER_DATA_CHANNEL0(void);
extern void SchM_Exit_FrNm_RX_USER_DATA_CHANNEL1(void);
extern void SchM_Exit_FrNm_RX_USER_DATA(void);
extern void SchM_Exit_FrNm_INTERNAL_STATUS_CHANNEL0(void);
extern void SchM_Exit_FrNm_INTERNAL_STATUS(void);
extern void SchM_Exit_FrNm_INTERNAL_STATUS_CHANNEL1(void);
extern void SchM_Enter_FrNm_RX_USER_DATA(void);
extern void SchM_Enter_FrNm_INTERNAL_STATUS(void);
#endif /*SCHM_FRNM_H*/

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
