/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: SchM_CanIf.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR SchM CanIf Stub                                       **
**                                                                            **
**  PURPOSE   : Declaration of SchM CanIf Stub functions                      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By        Description                              **
********************************************************************************
** 4.0.0     20-Dec-2011   RPS       Initial version                          **
*******************************************************************************/

#ifndef SCHM_CANIF_H
#define SCHM_CANIF_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Std_Types.h"                  /* Standard type header */
#include "ComStack_Types.h"             /* ComStack type header */
#include "TC_Generic.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                      Exclusive Area                                        **
*******************************************************************************/

/*
 * This type define the exclusive areas along with scheduler services are used
 * to provide data integrity for shared resources
 */
extern void SchM_Enter_CanIf_MODE_STATUS_PROTECTION(void);
extern void SchM_Enter_CanIf_TX_QUEUE_PROTECTION(void);
extern void SchM_Exit_CanIf_MODE_STATUS_PROTECTION(void);

extern void SchM_Enter_CanIf_TX_NOTIFSTATUS_PROTECTION(void);
extern void SchM_Exit_CanIf_TX_NOTIFSTATUS_PROTECTION(void);

extern void SchM_Enter_CanIf_TX_DYNCANID_PROTECTION(void);
extern void SchM_Exit_CanIf_TX_DYNCANID_PROTECTION(void);


extern void SchM_Exit_CanIf_TX_QUEUE_PROTECTION(void);

extern void SchM_Enter_CanIf_TX_STATUS_PROTECTION(void);
extern void SchM_Exit_CanIf_TX_STATUS_PROTECTION(void);

extern void SchM_Enter_CanIf_RX_DATA_PROTECTION(void);
extern void SchM_Exit_CanIf_RX_DATA_PROTECTION(void);

extern void SchM_Enter_CanIf_RX_NOTIFSTATUS_PROTECTION(void);
extern void SchM_Exit_CanIf_RX_NOTIFSTATUS_PROTECTION(void);

extern void SchM_Enter_CanIf_ExclusiveArea_0(void);
extern void SchM_Exit_CanIf_ExclusiveArea_0(void);

extern boolean TestSchM_Enter_CanIf_TX_QUEUE_PROTECTION(App_DataValidateType LddDataValidate);
extern boolean TestSchM_Exit_CanIf_TX_QUEUE_PROTECTION(App_DataValidateType LddDataValidate);

extern boolean TestSchM_Enter_CanIf_RX_DATA_PROTECTION(App_DataValidateType LddDataValidate);
extern boolean TestSchM_Exit_CanIf_RX_DATA_PROTECTION(App_DataValidateType LddDataValidate);

#endif /*SCHM_CANIF_H*/

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
