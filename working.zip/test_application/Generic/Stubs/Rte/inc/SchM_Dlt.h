/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: SchM_Dlt.h                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR SchM                                                  **
**                                                                            **
**  PURPOSE   : Declaration of SchM functions                                 **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     12-Mar-2012    SHV    Initial version                             **
**                                                                            **
*******************************************************************************/
#ifndef SCHM_DLT_H
#define SCHM_DLT_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void SchM_Enter_Dlt_LOGTRACE_PROTECTION(void);
extern void SchM_Exit_Dlt_LOGTRACE_PROTECTION(void);

extern void SchM_Enter_Dlt_REGISTER_CNTXT_PROTECTION(void);
extern void SchM_Exit_Dlt_REGISTER_CNTXT_PROTECTION(void);

#endif /* SCHM_DLT_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

