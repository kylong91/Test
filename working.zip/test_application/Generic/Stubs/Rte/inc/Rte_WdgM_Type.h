/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: <>                                                            **
**                                                                            **
**  TARGET    : <All/Microcontroller Name/Device Name>                        **
**                                                                            **
**  PRODUCT   : AUTOSAR <MSN>                                                 **
**                                                                            **
**  PURPOSE   : <Description of the file>                                     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]:                                              **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]:                                           **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** X.Y.Z     dd-Mmm-yyyy   ABC    Initial version                             **
**                                                                            **
** X.Y.Z     dd-Mmm-yyyy   ABC    Changes made as per SCR_025                 **
**                                <Provide the list of changes>               **
*******************************************************************************/
#ifndef RTE_WDGM_TYPES_H
#define RTE_WDGM_TYPES_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Std_Types.h"                    /* Standard AUTOSAR types           */
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/* Watchdog Manager Mode Type */
typedef uint8 WdgM_ModeType;

/* The current status of supervision for individual Supervised Entities */
typedef uint8 WdgM_LocalStatusType;

#define WDGM_LOCAL_STATUS_OK (WdgM_LocalStatusType)0
#define WDGM_LOCAL_STATUS_FAILED (WdgM_LocalStatusType)1
#define WDGM_LOCAL_STATUS_EXPIRED (WdgM_LocalStatusType)2
#define WDGM_LOCAL_STATUS_DEACTIVATED (WdgM_LocalStatusType)4

/* The global supervision status of the Watchdog Manager module */
typedef uint8 WdgM_GlobalStatusType;

#define WDGM_GLOBAL_STATUS_OK (WdgM_GlobalStatusType)0
#define WDGM_GLOBAL_STATUS_FAILED (WdgM_GlobalStatusType)1
#define WDGM_GLOBAL_STATUS_EXPIRED (WdgM_GlobalStatusType)2
#define WDGM_GLOBAL_STATUS_STOPPED (WdgM_GlobalStatusType)3
#define WDGM_GLOBAL_STATUS_DEACTIVATED (WdgM_GlobalStatusType)4





/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
