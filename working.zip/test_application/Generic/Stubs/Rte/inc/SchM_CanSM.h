/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: SchM_CanSM.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR SchM CanSM Stub                                       **
**                                                                            **
**  PURPOSE   : Declaration of SchM CanSM Stub functions                      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     20-Dec-2011   RPS    Initial version                             **
*******************************************************************************/
#ifndef SCHM_CANSM_H
#define SCHM_CANSM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Std_Types.h"                  /* Standard type header */
#include "ComStack_Types.h"             /* ComStack type header */

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                      Exclusive Area                                        **
*******************************************************************************/

/*
 * This type define the exclusive areas along with scheduler services are used
 * to provide data integrity for shared resources
 */
extern void SchM_Enter_CanSM_MODE_STATUS_PROTECTION(void);
extern void SchM_Enter_CanSM_BUSOFF_STATUS_PROTECTION(void);

extern void SchM_Exit_CanSM_MODE_STATUS_PROTECTION(void);
extern void SchM_Exit_CanSM_BUSOFF_STATUS_PROTECTION(void);

#endif /*SCHM_CANSM_H*/

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
