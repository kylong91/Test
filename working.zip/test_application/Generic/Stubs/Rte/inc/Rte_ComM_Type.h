/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Rte.c                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Communication Manager                                 **
**                                                                            **
**  PURPOSE   : Declaration of Rte functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0    30-Aug-2012   Ravi Tiwari    Initial version                      **
*******************************************************************************/
/* MULTIPLE INCLUSION PROTECTION */
#ifndef RTE_COMM_TYPE_H
#define RTE_COMM_TYPE_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Std_Types.h"
/* COMPATIBLE WITH C and C++ languages */
#ifdef __cplusplus
 extern "C" 
 {
#endif 

/*******************************************************************************
** Type Definitions for AUTOSAR data types                                    **
*******************************************************************************/

typedef uint8 UInt8;
typedef UInt8 Rte_ModeType_ComMMode;
#define MAX_CHANNEL_REQUESTERS (uint8)3
#define IN
/*******************************************************************************
** Typedefs of Modes
*******************************************************************************/
typedef uint8 ComM_ModeType;

typedef uint8 ComM_UserHandleType;

typedef uint8 ComM_InhibitionStatusType;

typedef struct STag_ComM_UserHandleArrayType
{
  uint8 numberOfRequesters;
  ComM_UserHandleType handleArray[MAX_CHANNEL_REQUESTERS];
}ComM_UserHandleArrayType;


#define RTE_MODE_ComMMode_COMM_NO_COMMUNICATION ((ComM_ModeType)0)
#define RTE_MODE_ComMMode_COMM_SILENT_COMMUNICATION ((ComM_ModeType)1)
#define RTE_MODE_ComMMode_COMM_FULL_COMMUNICATION ((ComM_ModeType)2)



/*******************************************************************************
** Port Data Structures                                                       **
*******************************************************************************/
struct Rte_PDS_ComM_ComM_CurrentMode_P
{
  P2FUNC(Rte_ModeType_ComMMode, COMM_CODE, Mode_currentMode)(void);
  P2FUNC(Std_ReturnType, COMM_CODE, Switch_currentMode)
    (Rte_ModeType_ComMMode);
};
struct Rte_PDS_ComM_ComM_CurrentChannelRequest_P
{
  P2FUNC(Std_ReturnType, COMM_CODE, Write_fullComRequestors)
    (ComM_UserHandleArrayType *);
};



/*******************************************************************************
** Component Data Structures                                                  **
** If sections of the Component Data Structure are specified                  **
*******************************************************************************/
struct Rte_CDS_ComMUser
{

  /* Data Handles Section */


  /* PerInstance Memory Handle section */


 /* Inter-runnable Variable Handles section */

 /* Exclusive-area Handles section */
 
  /* Port API section For all PDS */
  struct Rte_PDS_ComM_ComM_CurrentMode_P UM000;
  struct Rte_PDS_ComM_ComM_CurrentMode_P UM001;
  struct Rte_PDS_ComM_ComM_CurrentMode_P UM002;
  struct Rte_PDS_ComM_ComM_CurrentMode_P UM003;
  struct Rte_PDS_ComM_ComM_CurrentMode_P UM004;
  struct Rte_PDS_ComM_ComM_CurrentMode_P UM005;
  struct Rte_PDS_ComM_ComM_CurrentMode_P UM006;
  struct Rte_PDS_ComM_ComM_CurrentMode_P UM007;
  struct Rte_PDS_ComM_ComM_CurrentMode_P UM008;
  struct Rte_PDS_ComM_ComM_CurrentMode_P UM009;

 /* Inter Runnable Variable API section */
};

struct Rte_CDS_ComMChnl
{

  /* Data Handles Section */


  /* PerInstance Memory Handle section */


 /* Inter-runnable Variable Handles section */

 /* Exclusive-area Handles section */
  
  /* Port API section For all PDS */
  struct Rte_PDS_ComM_ComM_CurrentChannelRequest_P CR000;
  struct Rte_PDS_ComM_ComM_CurrentChannelRequest_P CR001;
  struct Rte_PDS_ComM_ComM_CurrentChannelRequest_P CR002;
  struct Rte_PDS_ComM_ComM_CurrentChannelRequest_P CR003;
  struct Rte_PDS_ComM_ComM_CurrentChannelRequest_P CR004;
  struct Rte_PDS_ComM_ComM_CurrentChannelRequest_P CR005;
  struct Rte_PDS_ComM_ComM_CurrentChannelRequest_P CR006;
  struct Rte_PDS_ComM_ComM_CurrentChannelRequest_P CR007;
  struct Rte_PDS_ComM_ComM_CurrentChannelRequest_P CR008;
  struct Rte_PDS_ComM_ComM_CurrentChannelRequest_P CR009;

 /* Inter Runnable Variable API section */
};


#endif /* RTE_COMM_TYPE_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/


