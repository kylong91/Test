/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Rte_DEM_Type.h                                               **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR ECUM                                                  **
**                                                                            **
**  PURPOSE   : Header file for Rte.c                                         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     10-Nov-2012   Ravi Tiwari Initial version                        **
*******************************************************************************/

#ifndef RTE_DEM_TYPE_H
#define RTE_DEM_TYPE_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Platform_Types.h"            /* Platform specific type definitions */
#include "Rte_Type.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
typedef uint16 Dem_EventIdType;

typedef uint8 Dem_EventStatusType;
#define DEM_EVENT_STATUS_PASSED           0x00
#define DEM_EVENT_STATUS_FAILED           0x01
#define DEM_EVENT_STATUS_PREPASSED        0x02
#define DEM_EVENT_STATUS_PREFAILED        0x03
typedef uint8 Dem_EventStatusExtendedType;
#define DEM_UDS_STATUS_TF           0x01
#define DEM_UDS_STATUS_TFTOC        0x02
#define DEM_UDS_STATUS_PDTC         0x04
#define DEM_UDS_STATUS_CDTC         0x08
#define DEM_UDS_STATUS_TNCSLC       0x10
#define DEM_UDS_STATUS_TFSLC        0x20
#define DEM_UDS_STATUS_TNCTOC       0x40
#define DEM_UDS_STATUS_WIR          0x80
typedef uint8 Dem_DTCFormatType;
#define DEM_DTC_FORMAT_OBD            0x00
#define DEM_DTC_FORMAT_UDS            0x01
typedef uint8 Dem_InitMonitorReasonType;
#define DEM_INIT_MONITOR_CLEAR        0x01
#define DEM_INIT_MONITOR_RESTART      0x02
typedef uint8 Dem_OperationCycleStateType;
#define DEM_CYCLE_STATE_START       0x00
#define DEM_CYCLE_STATE_END         0x01
typedef uint8 Dem_DTCStatusMaskType;
typedef uint8 Dem_IndicatorStatusType;
#define DEM_INDICATOR_OFF             0x00
#define DEM_INDICATOR_CONTINUOUS      0x01
#define DEM_INDICATOR_BLINKING        0x02
#define DEM_INDICATOR_BLINK_CONT      0x03
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/


#endif /* RTE_DEM_TYPE_H */
/*******************************************************************************
                          End of the file
*******************************************************************************/
