/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: SchM_BswM.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BSW Mode Manager                                      **
**                                                                            **
**  PURPOSE   : SchM_BswM.h                                                   **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     20-Dec-2011   RPS    Initial version                             **
** 4.0.1     06-Feb-2012   RPS    TestSchM_DefaultBehavior is removed         **
*******************************************************************************/

#ifndef SCHM_BSWM_H
#define SCHM_BSWM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
#include "EcuM_Types.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/
/* Macro for Dcm_CommunicationModeType */
#define Rte_ModeType_DCM_ENABLE_RX_TX_NORM                     0x00
#define Rte_ModeType_DCM_ENABLE_RX_DISABLE_TX_NORM             0x01
#define Rte_ModeType_DCM_DISABLE_RX_ENABLE_TX_NORM             0x02
#define Rte_ModeType_DCM_DISABLE_RX_TX_NORM                    0x03 
#define Rte_ModeType_DCM_ENABLE_RX_TX_NM                       0x04  
#define Rte_ModeType_DCM_ENABLE_RX_DISABLE_TX_NM               0x05
#define Rte_ModeType_DCM_DISABLE_RX_ENABLE_TX_NM               0x06
#define Rte_ModeType_DCM_DISABLE_RX_TX_NM                      0x07
#define Rte_ModeType_DCM_ENABLE_RX_TX_NORM_NM                  0x08  
#define Rte_ModeType_DCM_ENABLE_RX_DISABLE_TX_NORM_NM          0x09
#define Rte_ModeType_DCM_DISABLE_RX_ENABLE_TX_NORM_NM          0x0A
#define Rte_ModeType_DCM_DISABLE_RX_TX_NORM_NM                 0x0B
#define Rte_ModeType_DCM_ENABLE_TX_RX_NORM                     0x00
#define Rte_ModeType_DCM_INVALID_NETWORKID                     0x02
#define Rte_ModeType_DCM_INVALID_SESSIONMODETYPE               0x00 
#define Rte_ModeType_DCM_INVALID_RESETMODETYPE                 0x00 

/* Macro for Dcm_SesCtrlType */
#define Rte_ModeType_DCM_DEFAULT_SESSION                       0x01
#define Rte_ModeType_DCM_PROGRAMMING_SESSION                   0x02
#define Rte_ModeType_DCM_EXTENDED_DIAGNOSTIC_SESSION           0x03
#define Rte_ModeType_DCM_SAFETY_SYSTEM_DIAGNOSTIC_SESSION      0x04
#define Rte_ModeType_DCM_ALL_SESSION_LEVEL                     0xFF

/* Macro for Dcm_ResetModeType */
#define Rte_ModeType_DCM_NO_RESET                              0x01 
#define Rte_ModeType_DCM_HARD_RESET                            0x01
#define Rte_ModeType_DCM_KEY_ON_OFF_RESET                      0x02
#define Rte_ModeType_DCM_SOFT_RESET                            0x03
#define Rte_ModeType_DCM_ENABLE_RAPID_POWER_SHUTDOWN_RESET     0x04
#define Rte_ModeType_DCM_DISABLE_RAPID_POWER_SHUTDOWN_RESET    0x05
#define Rte_ModeType_DCM_BOOTLOADER_RESET                      0x06
#define Rte_ModeType_DCM_SS_BOOTLOADER_RESET                   0x07  
#define Rte_ModeType_DCM_RESET_EXECUTION                       0x08 
#define Rte_ModeType_DCM_INVALID_COMMUNICATIONMODETYPE         0x00

#define SCHM_E_OK 0x01 

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void SchM_Enter_BswM_CANSMCURRENTSTATE_PROTECTION(void);
extern void SchM_Exit_BswM_CANSMCURRENTSTATE_PROTECTION(void);
extern void SchM_Enter_BswM_GENERICCURRENTSTATE_PROTECTION(void);
extern void SchM_Exit_BswM_GENERICCURRENTSTATE_PROTECTION(void);
extern void SchM_Enter_BswM_RULESTATUS_PROTECTION(void);
extern void SchM_Exit_BswM_RULESTATUS_PROTECTION(void);
extern void SchM_Enter_BswM_RULEPREVRESULT_PROTECTION(void);
extern void SchM_Exit_BswM_RULEPREVRESULT_PROTECTION(void);
extern void SchM_Enter_BswM_COMMCURRENTMODE_PROTECTION(void);
extern void SchM_Exit_BswM_COMMCURRENTMODE_PROTECTION(void);
extern void SchM_Enter_BswM_DCMCOMMCURRENTSTATE_PROTECTION(void);
extern void SchM_Exit_BswM_DCMCOMMCURRENTSTATE_PROTECTION(void);
extern void SchM_Enter_BswM_ECUMCURRENTSTATE_PROTECTION(void);
extern void SchM_Exit_BswM_ECUMCURRENTSTATE_PROTECTION(void);
extern void SchM_Enter_BswM_ECUMWAKEUPSOURCE_PROTECTION(void);
extern void SchM_Exit_BswM_ECUMWAKEUPSOURCE_PROTECTION(void);
extern void SchM_Enter_BswM_ETHSMCURRENTSTATE_PROTECTION(void);
extern void SchM_Exit_BswM_ETHSMCURRENTSTATE_PROTECTION(void);
extern void SchM_Enter_BswM_FRSMCURRENTSTATE_PROTECTION(void);
extern void SchM_Exit_BswM_FRSMCURRENTSTATE_PROTECTION(void);
extern void SchM_Enter_BswM_LINSMCURRENTSTATE_PROTECTION(void);
extern void SchM_Exit_BswM_LINSMCURRENTSTATE_PROTECTION(void);
extern void SchM_Enter_BswM_LINSMCURRENTSCHEDULE_PROTECTION(void);
extern void SchM_Exit_BswM_LINSMCURRENTSCHEDULE_PROTECTION(void);
extern void SchM_Enter_BswM_LINTPSCHDREQUESTMODE_PROTECTION(void);
extern void SchM_Exit_BswM_LINTPSCHDREQUESTMODE_PROTECTION(void);
extern void SchM_Enter_BswM_HISTORYBUFFER_PROTECTION(void);
extern void SchM_Exit_BswM_HISTORYBUFFER_PROTECTION(void);
extern void SchM_Enter_BswM_EVALUATIONTRUE_PROTECTION(void);
extern void SchM_Exit_BswM_EVALUATIONTRUE_PROTECTION(void);
extern void SchM_Enter_BswM_EVALUATIONFALSE_PROTECTION(void);
extern void SchM_Exit_BswM_EVALUATIONFALSE_PROTECTION(void);
extern void SchM_Enter_BswM_COMMPNCCURRENTMODE_PROTECTION(void);
extern void SchM_Exit_BswM_COMMPNCCURRENTMODE_PROTECTION(void);
extern void SchM_Enter_BswM_NVMCURRENTBLOCKMODE_PROTECTION(void);
extern void SchM_Exit_BswM_NVMCURRENTBLOCKMODE_PROTECTION(void);
extern void SchM_Enter_BswM_NVMCURRENTJOBMODE_PROTECTION(void);
extern void SchM_Exit_BswM_NVMCURRENTJOBMODE_PROTECTION(void);
extern void SchM_Enter_BswM_WDGMPARTITIONRESETREQUEST_PROTECTION(void);
extern void SchM_Exit_BswM_WDGMPARTITIONRESETREQUEST_PROTECTION(void);


/* Extern Declaration for SchM_Switch() API */
extern Std_ReturnType SchM_Switch_BswM_39_Prov_SchM_Mdgp(EcuM_StateType state);

/* Extern Declaration for SchM_Switch() Test API */
extern boolean TestSchM_Switch_BswM_39_Prov_SchM_Mdgp(App_DataValidateType 
  LucDataValidate, EcuM_StateType LddExpNewMode);

/* Extern Declaration for SchM_Mode() Test API */
extern boolean TestSchM_Mode_BswM_39_Req_SchM_Mdgp(App_DataValidateType 
  LucDataValidate, EcuM_StateType LddExpNewMode);
  
extern void TestSetSchM_Mode_BswM_39_Req_SchM_Mdgp(EcuM_StateType LddRetVal);

extern EcuM_StateType SchM_Mode_BswM_39_Req_SchM_Mdgp(void);

#endif /* SCHM_BSWM_H */
/*******************************************************************************
                          End of the file
*******************************************************************************/
