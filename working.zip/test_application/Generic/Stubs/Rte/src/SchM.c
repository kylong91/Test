/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: SchM.c                                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR SchM                                                  **
**                                                                            **
**  PURPOSE   : Declaration of SchM functions                                 **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#ifdef COMM_MODULE_ACTIVE
#include "SchM_ComM.h"
#endif

#ifdef DEM_MODULE_ACTIVE
#include "SchM_Dem.h"
#endif

#ifdef FIM_MODULE_ACTIVE
#include "SchM_FiM.h"
#endif

#ifdef NM_MODULE_ACTIVE
#include "SchM_Nm.h"
#endif

#ifdef CAN_MODULE_ACTIVE
#include "SchM_Can.h"
#endif

#ifdef CANSM_MODULE_ACTIVE
#include "SchM_CanSM.h"
#endif

#ifdef CANIF_MODULE_ACTIVE
#include "SchM_CanIf.h"
#endif

#ifdef CANNM_MODULE_ACTIVE
#include "SchM_CanNm.h"
#endif

#ifdef IPDUM_MODULE_ACTIVE
#include "SchM_IpduM.h"
#endif

#ifdef LINIF_MODULE_ACTIVE
#include "SchM_LinIf.h"
#endif

#ifdef CANTP_MODULE_ACTIVE
#include "Schm_CanTp.h"
#endif

#ifdef PDUR_MODULE_ACTIVE
#include "Schm_PduR.h"
#endif

#ifdef COM_MODULE_ACTIVE
#include "Schm_Com.h"
#endif

#ifdef BSWM_MODULE_ACTIVE
#include "SchM_BswM.h"
#endif

#ifdef LINNM_MODULE_ACTIVE
#include "SchM_LinNm.h"
#endif

#ifdef DET_MODULE_ACTIVE
#include "SchM_Det.h"
#endif

#ifdef LINSM_MODULE_ACTIVE
#include "SchM_LinSM.h"
#endif

#ifdef DBG_MODULE_ACTIVE
#include "SchM_Dbg.h"
#endif

#ifdef NVM_MODULE_ACTIVE
#include "SchM_NvM.h"
#endif

#ifdef DCM_MODULE_ACTIVE
#include "SchM_Dcm.h"
#endif

#ifdef WDGM_MODULE_ACTIVE
#include "SchM_WdgM.h"
#endif

#ifdef FRM_MODULE_ACTIVE
#include "SchM_FrSM.h"
#endif

#ifdef ETHIF_MODULE_ACTIVE
#include "SchM_EthIf.h"
#endif

#ifdef ETHSM_MODULE_ACTIVE
#include "SchM_EthSM.h"
#endif

#ifdef FRIF_MODULE_ACTIVE
#include "SchM_FrIf.h"
#endif

#ifdef FRTP_MODULE_ACTIVE
#include "SchM_FrTp.h"
#endif

#ifdef DLT_MODULE_ACTIVE
#include "SchM_Dlt.h"
#endif

#ifdef CSM_MODULE_ACTIVE
#include "SchM_Csm.h"
#endif
/******************************************************************************
* D E F I N E S
******************************************************************************/

/******************************************************************************
* M A C R O 'S
******************************************************************************/

/******************************************************************************
* T Y P E   D E F I N I T I O N S
******************************************************************************/

/******************************************************************************
* C O N S T A N T S
******************************************************************************/

/******************************************************************************
* F I L E    S C O P E    V A R I A B L E S
******************************************************************************/

/******************************************************************************
* G L O B A L    V A R I A B L E S
******************************************************************************/
#ifdef CANIF_MODULE_ACTIVE
uint8 Guc_SchMCnt;
uint8 Guc_SchMCnt1;
uint8 Guc_SchMenterCnt1;
uint8 Guc_SchMexitCnt1;
#endif

#ifdef BSWM_MODULE_ACTIVE
uint8 SchM_GucModecnt;
uint8 SchM_Switch_BswMCount;
EcuM_StateType SchM_GddNewMode;
EcuM_StateType SchM_GddCurrentActiveMode;
Std_ReturnType SchM_GddPortRetValue;
#endif

#ifdef DCM_MODULE_ACTIVE
uint8 Dcm_GucGeneralCount;
uint8 Dcm_GaaResetMode[5];
Dcm_SesCtrlType Dcm_GddSecCntrlType;
Dcm_CommunicationModeType Dcm_GddCommunication[15] = {0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
uint8 Dcm_GddControl[15] = {0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
uint8 Dcm_SecCntrlCount;
uint8 SchM_GucDcmCommuControlCheckCount;
uint8 SchM_GucDcmEcuResetCount;
uint8 Dcm_GddDTCStting;
#endif

/******************************************************************************
* M A I N  F U N C T I O N    D E F I N I T I O N S
******************************************************************************/
void SchM_Enter_OsekNm_OSEKNM_BLOCK_ALL_INTERRUPT(void){}
void SchM_Exit_OsekNm_OSEKNM_BLOCK_ALL_INTERRUPT(void){}
#ifdef FRIF_MODULE_ACTIVE
void SchM_Enter_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER0(void)
{
}
void SchM_Enter_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER1(void)
{
}
void SchM_Enter_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER2(void)
{
}
void SchM_Enter_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER3(void)
{
}
void SchM_Enter_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER4(void)
{
}
void SchM_Enter_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER5(void)
{
}


void SchM_Exit_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER0(void)
{
}
void SchM_Exit_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER1(void)
{
}
void SchM_Exit_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER2(void)
{
}
void SchM_Exit_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER3(void)
{
}
void SchM_Exit_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER4(void)
{
}
void SchM_Exit_FrIf_CLUSTER_STATE_PROTECTION_CLUSTER5(void)
{
}

void SchM_Enter_FrIf_JOBCOUNTER_PROTECTION_CLUSTER0(void)
{
}
void SchM_Enter_FrIf_JOBCOUNTER_PROTECTION_CLUSTER1(void)
{
}
void SchM_Enter_FrIf_JOBCOUNTER_PROTECTION_CLUSTER2(void)
{
}
void SchM_Enter_FrIf_JOBCOUNTER_PROTECTION_CLUSTER3(void)
{
}
void SchM_Enter_FrIf_JOBCOUNTER_PROTECTION_CLUSTER4(void)
{
}
void SchM_Enter_FrIf_JOBCOUNTER_PROTECTION_CLUSTER5(void)
{
}

void SchM_Exit_FrIf_JOBCOUNTER_PROTECTION_CLUSTER0(void)
{
}
void SchM_Exit_FrIf_JOBCOUNTER_PROTECTION_CLUSTER1(void)
{
}
void SchM_Exit_FrIf_JOBCOUNTER_PROTECTION_CLUSTER2(void)
{
}
void SchM_Exit_FrIf_JOBCOUNTER_PROTECTION_CLUSTER3(void)
{
}
void SchM_Exit_FrIf_JOBCOUNTER_PROTECTION_CLUSTER4(void)
{
}
void SchM_Exit_FrIf_JOBCOUNTER_PROTECTION_CLUSTER5(void)
{
}
#endif

/*******************************************************************************
**                              FrTp                                          **
*******************************************************************************/

#ifdef FRTP_MODULE_ACTIVE
/*******************************************************************************
**                              SchM_Enter_FrTp                               **
*******************************************************************************/
void SchM_Enter_FrTp(void)
{
}
/*******************************************************************************
**                              SchM_Exit_FrTp                                **
*******************************************************************************/
void SchM_Exit_FrTp(void)
{
}
#endif

#ifdef ETHSM_MODULE_ACTIVE
void SchM_Enter_ETHSM_MODE_STATUS_PROTECTION(void)
{
}
void SchM_Exit_ETHSM_MODE_STATUS_PROTECTION(void)
{
}
#endif 
#ifdef COMM_MODULE_ACTIVE
/*******************************************************************************
**                              ComM                                          **
*******************************************************************************/
void SchM_Enter_ComM_VERSION_INFO_PROTECTION(void)
{
}
void SchM_Exit_ComM_VERSION_INFO_PROTECTION(void)
{
}

void SchM_Enter_ComM_REQ_COMM_MODE_PROTECTION(void)
{
}
void SchM_Exit_ComM_REQ_COMM_MODE_PROTECTION(void)
{
}

void SchM_Enter_ComM_INHIBIT_CNT_PROTECTION(void)
{
}
void SchM_Exit_ComM_INHIBIT_CNT_PROTECTION(void)
{
}

void SchM_Enter_ComM_REQ_MODECNT_PROTECTION(void)
{
}
void SchM_Exit_ComM_REQ_MODECNT_PROTECTION(void)
{
}

void SchM_Enter_ComM_CURRENT_MODE_PROTECTION(void)
{
}
void SchM_Exit_ComM_CURRENT_MODE_PROTECTION(void)
{
}

void SchM_Enter_ComM_DCM_DIAGNOSTIC_PROTECTION(void)
{
}
void SchM_Exit_ComM_DCM_DIAGNOSTIC_PROTECTION(void)
{
}

void SchM_Enter_ComM_ECUM_WAKEUP_IND(void)
{
}
void SchM_Exit_ComM_ECUM_WAKEUP_IND(void)
{
}

void SchM_Enter_ComM_NM_INDICATION_PROTECTION(void)
{
}
void SchM_Exit_ComM_NM_INDICATION_PROTECTION(void)
{
}

void SchM_Enter_ComM_PNC_PREPARE_TIMER(void)
{
}
void SchM_Exit_ComM_PNC_PREPARE_TIMER(void)
{
}

void SchM_Enter_ComM_PNC_WAKEUP_IND(void)
{
}

void SchM_Exit_ComM_PNC_WAKEUP_IND(void)
{
}
void SchM_Enter_ComM_PNC_EIRA_RX(void)
{
}
void SchM_Exit_ComM_PNC_EIRA_RX(void)
{
}
void SchM_Enter_ComM_PNC_ERA_RX(void)
{
}
void SchM_Exit_ComM_PNC_ERA_RX(void)
{
}
#endif
/*******************************************************************************
**                              EthIf                                         **
*******************************************************************************/
#ifdef ETHIF_MODULE_ACTIVE
void SchM_Enter_EthIf_MAIN_PERIOD_PROTECT(void)
{
}
void SchM_Exit_EthIf_MAIN_PERIOD_PROTECT(void)
{
}
#endif
#ifdef DET_MODULE_ACTIVE
/*******************************************************************************
**                              Det                                           **
*******************************************************************************/
void SchM_Enter_Det_RAM_DATA_PROTECTION(void)
{
 
}
void SchM_Exit_Det_RAM_DATA_PROTECTION(void)
{
 
}
#endif

#ifdef NM_MODULE_ACTIVE
/*******************************************************************************
**                              Nm                                            **
*******************************************************************************/

void SchM_Enter_Nm_UPDATE_NETWORK_STATUS_NW0(void)
{
}
void SchM_Enter_Nm_UPDATE_NETWORK_STATUS_NW1(void)
{
}
void SchM_Enter_Nm_UPDATE_NETWORK_STATUS_NW2(void)
{
}
void SchM_Enter_Nm_UPDATE_NETWORK_STATUS_NW3(void)
{
}
void SchM_Enter_Nm_UPDATE_NETWORK_STATUS_NW4(void)
{
}
void SchM_Enter_Nm_UPDATE_NETWORK_STATUS_NW5(void)
{
}
void SchM_Enter_Nm_UPDATE_NETWORK_STATUS_NW8(void)
{
}
void SchM_Enter_Nm_UPDATE_NETWORK_STATUS_NW11(void)
{
}
void SchM_Exit_Nm_UPDATE_NETWORK_STATUS_NW0(void)
{
}
void SchM_Exit_Nm_UPDATE_NETWORK_STATUS_NW1(void)
{
}
void SchM_Exit_Nm_UPDATE_NETWORK_STATUS_NW2(void)
{
}
void SchM_Exit_Nm_UPDATE_NETWORK_STATUS_NW3(void)
{
}
void SchM_Exit_Nm_UPDATE_NETWORK_STATUS_NW4(void)
{
}
void SchM_Exit_Nm_UPDATE_NETWORK_STATUS_NW5(void)
{
}
void SchM_Exit_Nm_UPDATE_NETWORK_STATUS_NW8(void)
{
}
void SchM_Exit_Nm_UPDATE_NETWORK_STATUS_NW11(void)
{
}
#endif

#ifdef NVM_MODULE_ACTIVE
/*******************************************************************************
**                                NvM                                         **
*******************************************************************************/
void SchM_Enter_NvM_RAM_STATUS_PROTECTION(void)
{
}

void SchM_Enter_NvM_RAM_INDEX(void)
{
}

void SchM_Exit_NvM_RAM_STATUS_PROTECTION(void)
{
}

void SchM_Exit_NvM_RAM_INDEX(void)
{
}
#endif

#ifdef CANSM_MODULE_ACTIVE
/*******************************************************************************
**                              CanSM                                         **
*******************************************************************************/
void SchM_Enter_CanSM_MODE_STATUS_PROTECTION(void)
{
}
void SchM_Enter_CanSM_BUSOFF_STATUS_PROTECTION(void)
{
}
void SchM_Exit_CanSM_MODE_STATUS_PROTECTION(void)
{
}
void SchM_Exit_CanSM_BUSOFF_STATUS_PROTECTION(void)
{
}
#endif

#ifdef CAN_MODULE_ACTIVE
/*******************************************************************************
**                                Can                                         **
*******************************************************************************/
void SchM_Enter_Can_INTERRUPT_CONTROL_PROTECTION_AREA(void)
{
}
void SchM_Exit_Can_INTERRUPT_CONTROL_PROTECTION_AREA(void)
{
}
#endif

#ifdef IPDUM_MODULE_ACTIVE
/*******************************************************************************
**                               IpduM                                        **
*******************************************************************************/
void SchM_Enter_IpduM_DEST_DATA_PROTECTION_AREA (void)
{
}
void SchM_Enter_IpduM_TX_STATUS_PROTECTION_AREA(void)
{
}
void SchM_Exit_IpduM_DEST_DATA_PROTECTION_AREA(void)
{
}
void SchM_Exit_IpduM_TX_STATUS_PROTECTION_AREA(void)
{
}
#endif

#ifdef LINIF_MODULE_ACTIVE
/*******************************************************************************
**                               LinIf                                        **
*******************************************************************************/
void SchM_Enter_LinIf_CHANNEL_STATUS_PROTECTION(void)
{
}
void SchM_Exit_LinIf_CHANNEL_STATUS_PROTECTION(void)
{
}
void SchM_Enter_LinIf_SLEEP_REQUEST_STATUS_PROTECTION(void)
{
}
void SchM_Exit_LinIf_SLEEP_REQUEST_STATUS_PROTECTION(void)
{
}
void SchM_Enter_LinIf_SPORADIC_STATUS_PROTECTION(void)
{
}
void SchM_Exit_LinIf_SPORADIC_STATUS_PROTECTION(void)
{
}
void SchM_Enter_LinIf_WAKEUP_CONFCOUNT_PROTECTION(void)
{
}
void SchM_Exit_LinIf_WAKEUP_CONFCOUNT_PROTECTION(void)
{
}
void SchM_Enter_LinIf_STATUS_PROTECTION(void)
{
}
void SchM_Exit_LinIf_STATUS_PROTECTION(void)
{
}
#endif


#ifdef FRNM_MODULE_ACTIVE

/*******************************************************************************
**                                     FrNm                                  **
*******************************************************************************/

void SchM_Enter_FrNm_INTERNAL_STATUS(void)
{

}

void SchM_Exit_FrNm_INTERNAL_STATUS(void)
{

}
void SchM_Enter_FrNm_TX_USER_DATA_CHANNEL0(void)
{
}
void SchM_Enter_FrNm_TX_USER_DATA_CHANNEL1(void)
{
}
void SchM_Enter_FrNm_RX_USER_DATA_CHANNEL0(void)
{
}
void SchM_Enter_FrNm_RX_USER_DATA_CHANNEL1(void)
{
}
void SchM_Enter_FrNm_INTERNAL_STATUS_CHANNEL0(void)
{
}
void SchM_Enter_FrNm_INTERNAL_STATUS_CHANNEL1(void)
{
}
void SchM_Exit_FrNm_TX_USER_DATA_CHANNEL0(void)
{  
}
void SchM_Exit_FrNm_TX_USER_DATA_CHANNEL1(void)
{
}
void SchM_Exit_FrNm_RX_USER_DATA_CHANNEL0(void)
{
}
void SchM_Exit_FrNm_RX_USER_DATA_CHANNEL1(void)
{
}
void SchM_Exit_FrNm_INTERNAL_STATUS_CHANNEL0(void)
{
}
void SchM_Exit_FrNm_INTERNAL_STATUS_CHANNEL1(void)
{
}


void SchM_Enter_FrNm_RX_USER_DATA(void)
{
}
void SchM_Exit_FrNm_RX_USER_DATA(void)
{
}
void SchM_Enter_FrNm_TX_USER_DATA(void)
{
}
void SchM_Exit_FrNm_TX_USER_DATA(void)
{
}

#endif
#ifdef CANNM_MODULE_ACTIVE

/*******************************************************************************
**                                     CanNm                                  **
*******************************************************************************/
void SchM_Enter_CanNm_TX_USER_DATA(void)
{
}
void SchM_Exit_CanNm_TX_USER_DATA(void)
{  
}
void SchM_Enter_CanNm_RX_USER_DATA(void)
{
}
void SchM_Exit_CanNm_RX_USER_DATA(void)
{
}
void SchM_Enter_CanNm_INTERNAL_STATUS(void)
{
}
void SchM_Exit_CanNm_INTERNAL_STATUS(void)
{
}
void SchM_Enter_CanNm_TX_USER_DATA_CHANNEL0(void)
{
}
void SchM_Enter_CanNm_TX_USER_DATA_CHANNEL1(void)
{
}
void SchM_Enter_CanNm_RX_USER_DATA_CHANNEL0(void)
{
}
void SchM_Enter_CanNm_RX_USER_DATA_CHANNEL1(void)
{
}
void SchM_Enter_CanNm_INTERNAL_STATUS_CHANNEL0(void)
{
}
void SchM_Enter_CanNm_INTERNAL_STATUS_CHANNEL1(void)
{
}
void SchM_Exit_CanNm_TX_USER_DATA_CHANNEL0(void)
{  
}
void SchM_Exit_CanNm_TX_USER_DATA_CHANNEL1(void)
{
}
void SchM_Exit_CanNm_RX_USER_DATA_CHANNEL0(void)
{
}
void SchM_Exit_CanNm_RX_USER_DATA_CHANNEL1(void)
{
}
void SchM_Exit_CanNm_INTERNAL_STATUS_CHANNEL0(void)
{
}
void SchM_Exit_CanNm_INTERNAL_STATUS_CHANNEL1(void)
{
}
#endif

#ifdef CANIF_MODULE_ACTIVE
/*******************************************************************************
**                                     CanIf                                  **
*******************************************************************************/
void SchM_Enter_CanIf_MODE_STATUS_PROTECTION(void)
{
}
void SchM_Exit_CanIf_MODE_STATUS_PROTECTION(void)
{
}

void SchM_Enter_CanIf_TX_NOTIFSTATUS_PROTECTION(void)
{
}
void SchM_Exit_CanIf_TX_NOTIFSTATUS_PROTECTION(void)
{
}

void SchM_Enter_CanIf_TX_DYNCANID_PROTECTION(void)
{
}
void SchM_Exit_CanIf_TX_DYNCANID_PROTECTION(void)
{
}

void SchM_Enter_CanIf_TX_QUEUE_PROTECTION(void)
{
  Guc_SchMCnt++;
}
void SchM_Exit_CanIf_TX_QUEUE_PROTECTION(void)
{
  Guc_SchMCnt1++;
}

void SchM_Enter_CanIf_TX_STATUS_PROTECTION(void)
{
}
void SchM_Exit_CanIf_TX_STATUS_PROTECTION(void)
{
}

void SchM_Enter_CanIf_RX_DATA_PROTECTION(void)
{
Guc_SchMenterCnt1++;

}
void SchM_Exit_CanIf_RX_DATA_PROTECTION(void)
{
Guc_SchMexitCnt1++;
}

void SchM_Enter_CanIf_RX_NOTIFSTATUS_PROTECTION(void)
{
}
void SchM_Exit_CanIf_RX_NOTIFSTATUS_PROTECTION(void)
{
}

void SchM_Enter_CanIf_ExclusiveArea_0(void)
{
}
void SchM_Exit_CanIf_ExclusiveArea_0(void)
{
}
void SchM_Enter_CanIf_TX_BUFFER_PROTECTION(void)
{
  Guc_SchMCnt++;
}

void SchM_Exit_CanIf_TX_BUFFER_PROTECTION(void)
{
  Guc_SchMCnt++;
}

/*******************************************************************************
**       TestSchM_Enter_CanIf_TX_BUFFER_PROTECTION()                          **
*******************************************************************************/
boolean TestSchM_Enter_CanIf_TX_QUEUE_PROTECTION(App_DataValidateType LddDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Guc_SchMCnt == 0x01)
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Guc_SchMCnt = 0x00;
    
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {    
      if(Guc_SchMCnt == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestSchM_Enter_CanIf_TX_BUFFER_PROTECTION() */




/*******************************************************************************
**       TestSchM_Exit_CanIf_TX_BUFFER_PROTECTION()                          **
*******************************************************************************/
boolean TestSchM_Exit_CanIf_TX_QUEUE_PROTECTION(App_DataValidateType LddDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Guc_SchMCnt1 == 0x01)
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Guc_SchMCnt1 = 0x00;
    
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {    
      if(Guc_SchMCnt1 == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestSchM_Exit_CanIf_TX_BUFFER_PROTECTION() */


/*******************************************************************************
**       TestSchM_Exit_CanIf_TX_BUFFER_PROTECTION()                          **
*******************************************************************************/
boolean TestSchM_Enter_CanIf_RX_DATA_PROTECTION(App_DataValidateType LddDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Guc_SchMenterCnt1 == 0x01)
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Guc_SchMenterCnt1 = 0x00;
    
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {    
      if(Guc_SchMenterCnt1 == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestSchM_Enter_CanIf_RX_DATA_PROTECTION() */

/*******************************************************************************
**       TestSchM_Exit_CanIf_TX_BUFFER_PROTECTION()                          **
*******************************************************************************/
boolean TestSchM_Exit_CanIf_RX_DATA_PROTECTION(App_DataValidateType LddDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Guc_SchMexitCnt1 == 0x01)
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Guc_SchMexitCnt1 = 0x00;
    
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {    
      if(Guc_SchMexitCnt1 == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestSchM_Exit_CanIf_RX_DATA_PROTECTION() */



#endif

#ifdef CANTP_MODULE_ACTIVE
/*******************************************************************************
**                      CANTP                                                 **
*******************************************************************************/
void SchM_Enter_CanTp_TIMER_PROTECTION(void)
{
}
void SchM_Exit_CanTp_TIMER_PROTECTION(void)
{
}
#endif

#ifdef COM_MODULE_ACTIVE
/*******************************************************************************
**                      COM                                                   **
*******************************************************************************/
/* Enter */
void SchM_Enter_Com_RX_DM_STS_PROTECTION_AREA(void)
{
}

void SchM_Enter_Com_TX_DM_STS_PROTECTION_AREA(void)
{
}

void SchM_Enter_Com_RX_IPDU_STATUS_PROTECTION_AREA(void)
{
}

void SchM_Enter_Com_RX_GW_STS_PROTECTION_AREA(void)
{
}

void SchM_Enter_Com_RX_IPDU_STS_PROTECTION_AREA(void)
{
}

void SchM_Enter_Com_TX_MDT_STS_PROTECTION_AREA(void)
{
}

void SchM_Enter_Com_TX_IPDU_BUFFER_PROTECTION_AREA(void)
{
}
void SchM_Enter_Com_TX_IPDU_DATA_PROTECTION(void)
{
}

void SchM_Enter_Com_TX_SIG_STS_PROTECTION_AREA(void)
{
}


void SchM_Enter_Com_TX_IPDU_STATUS_PROTECTION_AREA(void)
{
}

void SchM_Enter_Com_TX_SIG_DATA_PROTECTION_AREA(void)
{
}

void SchM_Enter_Com_SIG_DATA_PROTECTION_AREA(void)
{
}

void SchM_Enter_Com_RX_SIG_DATA_PROTECTION_AREA(void)
{
}

void SchM_Enter_Com_RX_IPDU_DATA_PROTECTION_AREA(void)
{
}
void SchM_Enter_Com_IPDU_GRP_STS_PROTECTION(void)
{
}
void SchM_Enter_Com_IPDU_STS_PROTECTION(void)
{
}

void SchM_Enter_Com_TX_TMS_STATUS_PROTECTION_AREA(void)
{
}

void SchM_Enter_Com_RX_FIFO_PROTECTION_AREA(void)
{
}

void SchM_Enter_Com_IPDU_GROUP_STATUS_PROTECTION(void)
{
}

void SchM_Enter_Com_IPDU_COUNTER_PROTECTION(void)
{
}

void SchM_Enter_Com_TX_EXT_SIG_DATA_PROTECTION_AREA(void)
{
}

void SchM_Enter_Com_TX_MDT_PROTECTION_AREA(void)
{
}

void SchM_Enter_Com_RX_EXT_SIG_DATA_PROTECTION_AREA(void)
{
}

/* Exit */
void SchM_Exit_Com_RX_DM_STS_PROTECTION_AREA(void)
{
}
void SchM_Exit_Com_TX_EXT_SIG_DATA_PROTECTION_AREA(void)
{
}

void SchM_Exit_Com_RX_IPDU_STS_PROTECTION_AREA(void)
{
}

void SchM_Exit_Com_TX_IPDU_STATUS_PROTECTION_AREA(void)
{
}

void SchM_Exit_Com_TX_IPDU_BUFFER_PROTECTION_AREA(void)
{
}

void SchM_Exit_Com_TX_TMS_STATUS_PROTECTION_AREA(void)
{
}

void SchM_Exit_Com_RX_FIFO_PROTECTION_AREA(void)
{
}

void SchM_Exit_Com_TX_SIG_STS_PROTECTION_AREA(void)
{
}

void SchM_Exit_Com_RX_IPDU_STATUS_PROTECTION(void)
{
}

void SchM_Exit_Com_TX_SIG_DATA_PROTECTION_AREA(void)
{
}

void SchM_Exit_Com_SIG_DATA_PROTECTION_AREA(void)
{
}

void SchM_Exit_Com_RX_SIG_DATA_PROTECTION_AREA(void)
{
}
void SchM_Exit_Com_RX_IPDU_DATA_PROTECTION_AREA(void)
{
}
void SchM_Exit_Com_IPDU_GRP_STS_PROTECTION(void)
{
}
void SchM_Exit_Com_IPDU_STS_PROTECTION(void)
{
}

void SchM_Exit_Com_IPDU_GROUP_STATUS_PROTECTION(void)
{
}

void SchM_Exit_Com_IPDU_COUNTER_PROTECTION(void)
{
}
void SchM_Exit_Com_TX_IPDU_DATA_PROTECTION(void)
{
}

void SchM_Exit_Com_RX_EXT_SIG_DATA_PROTECTION_AREA(void)
{
}

void SchM_Exit_Com_TX_MDT_PROTECTION_AREA(void)
{
}

void SchM_Exit_Com_TX_DM_STS_PROTECTION_AREA(void)
{
}

void SchM_Exit_Com_RX_IPDU_STATUS_PROTECTION_AREA(void)
{
}

void SchM_Exit_Com_RX_GW_STS_PROTECTION_AREA(void)
{
}

void SchM_Exit_Com_TX_MDT_STS_PROTECTION_AREA(void)
{
}

#endif

#ifdef LINNM_MODULE_ACTIVE

/*******************************************************************************
**                                     LinNm                                  **
*******************************************************************************/
void SchM_Enter_LinNm_UPDATE_NETWORK_STATUS_NW0(void)
{
}
void SchM_Enter_LinNm_UPDATE_NETWORK_STATUS_NW1(void)
{
}
void SchM_Enter_LinNm_UPDATE_NETWORK_STATUS_NW2(void)
{
}
void SchM_Exit_LinNm_UPDATE_NETWORK_STATUS_NW0(void)
{
}
void SchM_Exit_LinNm_UPDATE_NETWORK_STATUS_NW1(void)
{
}
void SchM_Exit_LinNm_UPDATE_NETWORK_STATUS_NW2(void)
{
}

#endif

#ifdef LINSM_MODULE_ACTIVE

/*******************************************************************************
**                                     LinSM                                  **
*******************************************************************************/
void SchM_Enter_LinSM_CHANNEL_STATUS_PROTECTION_0(void)
{
}
void SchM_Enter_LinSM_CHANNEL_STATUS_PROTECTION_1(void)
{
}
void SchM_Enter_LinSM_CHANNEL_STATUS_PROTECTION_2(void)
{
}
void SchM_Exit_LinSM_CHANNEL_STATUS_PROTECTION_0(void)
{
}
void SchM_Exit_LinSM_CHANNEL_STATUS_PROTECTION_1(void)
{
}
void SchM_Exit_LinSM_CHANNEL_STATUS_PROTECTION_2(void)
{
}
#endif

#ifdef DEM_MODULE_ACTIVE
/*******************************************************************************
**                                DEM                                         **
*******************************************************************************/
void SchM_Enter_Dem_REQUEST_BUFFER_PROTECTION(void)
{
}

void SchM_Exit_Dem_REQUEST_BUFFER_PROTECTION(void)
{
}

void SchM_Enter_Dem_REQUEST_STATUS_PROTECTION(void)
{
}

void SchM_Exit_Dem_REQUEST_STATUS_PROTECTION(void)
{
}
void SchM_Enter_Dem_REQUEST_RECORD_PROTECTION(void)
{
}

void SchM_Exit_Dem_REQUEST_RECORD_PROTECTION(void)
{
}

void SchM_Enter_Dem_REQUEST_NVDATA_PROTECTION(void)
{
}

void SchM_Exit_Dem_REQUEST_NVDATA_PROTECTION(void)
{
}
void SchM_Enter_Dem_CAPTURE_OBD_DATA(void)
{
}
void SchM_Exit_Dem_CAPTURE_OBD_DATA(void)
{
}

void SchM_Enter_Dem_REQUEST_OCC_PROTECTION(void)
{
}

void SchM_Exit_Dem_REQUEST_OCC_PROTECTION(void)
{
}

void SchM_Enter_Dem_REQUEST_OCCTIME_PROTECTION(void)
{
}
void SchM_Exit_Dem_REQUEST_OCCTIME_PROTECTION(void)
{
}
void SchM_Enter_Dem_REQUEST_DATA_PROTECTION(void)
{
}
void SchM_Exit_Dem_REQUEST_DATA_PROTECTION(void)
{
}
#endif
#ifdef PDUR_MODULE_ACTIVE
/*******************************************************************************
**                                PDUR                                        **
*******************************************************************************/
void SchM_Enter_PduR_PDUR_TP_TX_PROTECTION_AREA(void)
{
}

void SchM_Enter_PduR_PDUR_GROUP_STATUS_PROTECTION_AREA(void)
{
}

void SchM_Enter_PduR_PDUR_FIFO_STATUS_PROTECTION_AREA(void)
{
}

void SchM_Enter_PduR_PDUR_DATA_BUFFER_PROTECTION_AREA(void)
{
}

void SchM_Enter_PduR_PDUR_TP_GATEWAY_PROTECTION_AREA(void)
{
}

void SchM_Exit_PduR_PDUR_TP_TX_PROTECTION_AREA(void)
{
}

void SchM_Exit_PduR_PDUR_GROUP_STATUS_PROTECTION_AREA(void)
{
}

void SchM_Exit_PduR_PDUR_FIFO_STATUS_PROTECTION_AREA(void)
{
}

void SchM_Exit_PduR_PDUR_DATA_BUFFER_PROTECTION_AREA(void)
{
}

void SchM_Exit_PduR_PDUR_TP_GATEWAY_PROTECTION_AREA(void)
{
}
#endif

#ifdef DBG_MODULE_ACTIVE
/*******************************************************************************
**                                Dbg                                         **
*******************************************************************************/
void SchM_Enter_Dbg_TX_BUFFER_PROTECTION(void)
{
}
void SchM_Exit_Dbg_TX_BUFFER_PROTECTION(void)
{
}

void SchM_Enter_Dbg_RING_BUFFER_PROTECTION(void)
{
}
void SchM_Exit_Dbg_RING_BUFFER_PROTECTION(void)
{
}

void SchM_Enter_Dbg_COLLECTION_STATUS_PROTECTION(void)
{
}
void SchM_Exit_Dbg_COLLECTION_STATUS_PROTECTION(void)
{
}

void SchM_Enter_Dbg_DATA_RECORD_PROTECTION(void)
{
}
void SchM_Exit_Dbg_DATA_RECORD_PROTECTION(void)
{
}
#endif

#ifdef BSWM_MODULE_ACTIVE
/*******************************************************************************
**                              BswM                                          **
*******************************************************************************/
void SchM_Enter_BswM_CANSMCURRENTSTATE_PROTECTION(void)
{
}
void SchM_Exit_BswM_CANSMCURRENTSTATE_PROTECTION(void)
{
}

void SchM_Enter_BswM_GENERICCURRENTSTATE_PROTECTION(void)
{
}
void SchM_Exit_BswM_GENERICCURRENTSTATE_PROTECTION(void)
{
}

void SchM_Enter_BswM_RULESTATUS_PROTECTION(void)
{
}
void SchM_Exit_BswM_RULESTATUS_PROTECTION(void)
{
}

void SchM_Enter_BswM_RULEPREVRESULT_PROTECTION(void)
{
}
void SchM_Exit_BswM_RULEPREVRESULT_PROTECTION(void)
{
}

void SchM_Enter_BswM_COMMCURRENTMODE_PROTECTION(void)
{
}
void SchM_Exit_BswM_COMMCURRENTMODE_PROTECTION(void)
{
}

void SchM_Enter_BswM_COMMPNCCURRENTMODE_PROTECTION(void)
{
}
void SchM_Exit_BswM_COMMPNCCURRENTMODE_PROTECTION(void)
{
}

void SchM_Enter_BswM_DCMCOMMCURRENTSTATE_PROTECTION(void)
{
}
void SchM_Exit_BswM_DCMCOMMCURRENTSTATE_PROTECTION(void)
{
}

void SchM_Enter_BswM_ECUMCURRENTSTATE_PROTECTION(void)
{
}
void SchM_Exit_BswM_ECUMCURRENTSTATE_PROTECTION(void)
{
}

void SchM_Enter_BswM_ECUMWAKEUPSOURCE_PROTECTION(void)
{
}
void SchM_Exit_BswM_ECUMWAKEUPSOURCE_PROTECTION(void)
{
}

void SchM_Enter_BswM_ETHSMCURRENTSTATE_PROTECTION(void)
{
}
void SchM_Exit_BswM_ETHSMCURRENTSTATE_PROTECTION(void)
{
}

void SchM_Enter_BswM_FRSMCURRENTSTATE_PROTECTION(void)
{
}
void SchM_Exit_BswM_FRSMCURRENTSTATE_PROTECTION(void)
{
}

void SchM_Enter_BswM_LINSMCURRENTSTATE_PROTECTION(void)
{
}
void SchM_Exit_BswM_LINSMCURRENTSTATE_PROTECTION(void)
{
}

void SchM_Enter_BswM_LINSMCURRENTSCHEDULE_PROTECTION(void)
{
}
void SchM_Exit_BswM_LINSMCURRENTSCHEDULE_PROTECTION(void)
{
}

void SchM_Enter_BswM_LINTPSCHDREQUESTMODE_PROTECTION(void)
{
}
void SchM_Exit_BswM_LINTPSCHDREQUESTMODE_PROTECTION(void)
{
}

void SchM_Enter_BswM_NVMCURRENTBLOCKMODE_PROTECTION(void)
{
}
void SchM_Exit_BswM_NVMCURRENTBLOCKMODE_PROTECTION(void)
{
}

void SchM_Enter_BswM_NVMCURRENTJOBMODE_PROTECTION(void)
{
}
void SchM_Exit_BswM_NVMCURRENTJOBMODE_PROTECTION(void)
{
}

void SchM_Enter_BswM_WDGMPARTITIONRESETREQUEST_PROTECTION(void)
{
}
void SchM_Exit_BswM_WDGMPARTITIONRESETREQUEST_PROTECTION(void)
{
}


/*******************************************************************************
**          TestSetSchM_Mode_BswM_39_Req_SchM_Mdgp()                          **
*******************************************************************************/
void TestSetSchM_Mode_BswM_39_Req_SchM_Mdgp(EcuM_StateType LddRetVal)
{
  SchM_GddCurrentActiveMode = LddRetVal;
}/* End TestSetSchM_Mode_BswM_39_Req_SchM_Mdgp() */

/*******************************************************************************
**          SchM_Mode_BswM_39_Req_SchM_Mdgp                                   **
*******************************************************************************/
EcuM_StateType SchM_Mode_BswM_39_Req_SchM_Mdgp(void)
{
  SchM_GucModecnt++;
  return(SchM_GddCurrentActiveMode);
}/* End SchM_Mode_BswM_39_Req_SchM_Mdgp() */

/*******************************************************************************
**          SchM_Switch_BswM_39_Prov_SchM_Mdgp                            **
*******************************************************************************/
Std_ReturnType SchM_Switch_BswM_39_Prov_SchM_Mdgp(EcuM_StateType NewMode)
{
  SchM_Switch_BswMCount++;
  SchM_GddNewMode = NewMode; 
  return(SchM_GddPortRetValue);
}/* End SchM_Switch_BswM_39_Prov_SchM_Mdgp() */

/*******************************************************************************
**                      AppSchm_SetBehavior_Switch()                          **
*******************************************************************************/
void AppSchm_SetBehavior_Switch(Std_ReturnType LddSetRetVal)
{
  SchM_GddPortRetValue = LddSetRetVal; 
}/* End AppSchm_SetBehavior_Switch() */

/*******************************************************************************
**       TestSchM_Switch_BswM_39_Prov_SchM_Mdgp()                             **
*******************************************************************************/
boolean TestSchM_Switch_BswM_39_Prov_SchM_Mdgp(App_DataValidateType LucDataValidate, 
EcuM_StateType LddExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((SchM_Switch_BswMCount != 0x00) && 
        (SchM_GddNewMode == LddExpNewMode)) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      SchM_Switch_BswMCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
    if(SchM_Switch_BswMCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestSchM_Switch_BswM_39_Prov_SchM_Mdgp() */

/*******************************************************************************
**       TestSchM_Mode_BswM_39_Req_SchM_Mdgp()                                **
*******************************************************************************/
boolean TestSchM_Mode_BswM_39_Req_SchM_Mdgp(App_DataValidateType LucDataValidate, 
EcuM_StateType LddExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((SchM_GucModecnt != 0x00) && 
        (SchM_GddCurrentActiveMode == LddExpNewMode)) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      SchM_GucModecnt = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
    if(SchM_GucModecnt == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestSchM_Mode_BswM_39_Req_SchM_Mdgp() */

#endif /* BSWM_MODULE_ACTIVE */

#ifdef DCM_MODULE_ACTIVE
/*******************************************************************************
**                              Dcm                                         **
*******************************************************************************/
void SchM_Enter_Dcm_RxPduIdProtection(void)
{

}

void SchM_Exit_Dcm_RxPduIdProtection(void)
{

}

void SchM_Enter_Dcm_ProtclProtection(void)
{

}

void SchM_Exit_Dcm_ProtclProtection(void)
{

}

void SchM_Enter_Dcm_RxLengthProtection(void)
{

}

void SchM_Exit_Dcm_RxLengthProtection(void)
{

}

/*******************************************************************************
**          SchM_Switch_Dcm_DcmEcuReset             **
*******************************************************************************/
void SchM_Switch_Dcm_DcmEcuReset(uint8 EcuRestMode)
{
  #ifndef TYPICAL_CONFIG
  Dcm_GaaResetMode[Dcm_GucGeneralCount] = EcuRestMode;
  Dcm_GucGeneralCount++;
  #endif
}

/*******************************************************************************
**          TestSchM_Switch_Dcm_DcmEcuReset             **
*******************************************************************************/
boolean TestSchM_Switch_Dcm_DcmEcuReset(
  App_DataValidateType LddDataValidate, uint8 LucExpRestMode)
{
  uint8 LucIndex;
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucGeneralCount == 0x01) && (LucExpRestMode == Dcm_GaaResetMode[0]))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    
    case M_VALIDATE :
    {
      for(LucIndex = 0; LucIndex < Dcm_GucGeneralCount; LucIndex++)
      {
        if(Dcm_GaaResetMode[LucIndex] == LucExpRestMode) 
          {
            LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
          LucIndex = Dcm_GucGeneralCount;
          }
      }
      
       /*
             * Increment global variable to check number of times the API invocation
             * is verified
             */
      SchM_GucDcmEcuResetCount++;
      if(Dcm_GucGeneralCount == SchM_GucDcmEcuResetCount)
      {
        SchM_GucDcmEcuResetCount = 0;
        Dcm_GucGeneralCount = 0;
      }
      break;
    }
    
    case M_NOT_INVOKED :
      break;
    
    case S_VALIDATE_SEQ :
      break;
      
    case M_VALIDATE_SEQ :
      break;
    
  }  
    return(LblRetValue);
}

/*******************************************************************************
**                              SchM_Switch_Dcm_DcmDiagnosticSessionControl                                          **
*******************************************************************************/
void SchM_Switch_Dcm_DcmDiagnosticSessionControl(Dcm_SesCtrlType sessiontype)
{
  Dcm_GddSecCntrlType = sessiontype;
  Dcm_SecCntrlCount++;
}

/*******************************************************************************
**                              TestSchM_Switch_Dcm_DcmDiagnosticSessionControl                                          **
*******************************************************************************/
boolean TestSchM_Switch_Dcm_DcmDiagnosticSessionControl(
  App_DataValidateType LddDataValidate, Dcm_SesCtrlType Ldd_Expsessiontype)
{

  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_SecCntrlCount == 0x01) && (Ldd_Expsessiontype == 
        Dcm_GddSecCntrlType))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_SecCntrlCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_SecCntrlCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    
    case M_VALIDATE :
      break;
    
    case M_NOT_INVOKED :
      break;
    
    case S_VALIDATE_SEQ :
      break;
      
    case M_VALIDATE_SEQ :
      break;
    
  }  
    return(LblRetValue);
}

/*******************************************************************************
**          SchM_Switch_Dcm_DcmCommunicationControl             **
*******************************************************************************/
void SchM_Switch_Dcm_DcmCommunicationcontrol
  (Dcm_CommunicationModeType CommunicationType, uint8 ControlType)
{
    #ifndef TYPICAL_CONFIG
  Dcm_GddCommunication[Dcm_GucGeneralCount] = CommunicationType;
  Dcm_GddControl[Dcm_GucGeneralCount] = ControlType;
  Dcm_GucGeneralCount++;
  #endif
}
/*******************************************************************************
**       TestSchM_Switch_Dcm_DcmCommunicationControl()                                 **
*******************************************************************************/
boolean TestSchM_Switch_Dcm_DcmCommunicationControl(App_DataValidateType LucDataValidate, 
Dcm_CommunicationModeType LddExpCommunicationType, uint8 LddExpControlType)
{
  uint8 LucIndex;
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Dcm_GucGeneralCount == 0x01) && 
        (Dcm_GddCommunication[0] == LddExpCommunicationType)
    && (Dcm_GddControl[0] == LddExpControlType)) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucGeneralCount = 0x00;
    SchM_GucDcmCommuControlCheckCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
    for(LucIndex = 0; LucIndex < Dcm_GucGeneralCount; LucIndex++)
      {
      if((Dcm_GddCommunication[LucIndex] == LddExpCommunicationType) &&
        (Dcm_GddControl[LucIndex] == LddExpControlType))
        {
          LblStepResult = APP_TC_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = Dcm_GucGeneralCount;
        }
    }
    
    /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      SchM_GucDcmCommuControlCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Dcm_GucGeneralCount == SchM_GucDcmCommuControlCheckCount)
      {
        SchM_GucDcmCommuControlCheckCount = 0;
        Dcm_GucGeneralCount = 0;
      }
     
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {    
      if(Dcm_GucGeneralCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestSchM_Switch_Dcm_DcmCommunicationControl() */

/*******************************************************************************
**          SchM_Switch_Dcm_DcmControlDTCSetting             **
*******************************************************************************/
void SchM_Switch_Dcm_DcmControlDTCSetting(uint8 DTCSetting)
{
  Dcm_GddDTCStting = DTCSetting;
  Dcm_GucGeneralCount++;
}
/*******************************************************************************
**       TestSchM_Switch_Dcm_DcmControlDTCSetting()                                 **
*******************************************************************************/
boolean TestSchM_Switch_Dcm_DcmControlDTCSetting(App_DataValidateType LddDataValidate, 
uint8 LucExpDTCSetting)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Dcm_GucGeneralCount == 0x01) && 
        (Dcm_GddDTCStting == LucExpDTCSetting)) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucGeneralCount = 0x00;
    
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {    
      if(Dcm_GucGeneralCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestSchM_Switch_Dcm_DcmControlDTCSetting() */

#endif

#ifdef WDGM_MODULE_ACTIVE
/*******************************************************************************
**                      WDGM                                                 **
*******************************************************************************/
void SchM_Enter_WdgM_CURRENTMODE_PROTECTION(void)
{
}
void SchM_Exit_WdgM_CURRENTMODE_PROTECTION(void)
{
}
void SchM_Enter_WdgM_GLOBALSUPVSNSTATUS_PROTECTION(void)
{
}
void SchM_Exit_WdgM_GLOBALSUPVSNSTATUS_PROTECTION(void)
{
}
#endif

#ifdef FRSM_MODULE_ACTIVE
/*******************************************************************************
**                      WDGM                                                 **
*******************************************************************************/
void SchM_Enter_FrSM_CLUSTER_STATUS_PROTECTION_0(void)
{
}
void SchM_Enter_FrSM_CLUSTER_STATUS_PROTECTION_1(void)
{
}
void SchM_Enter_FrSM_CLUSTER_STATUS_PROTECTION_2(void)
{
}
void SchM_Enter_FrSM_CLUSTER_STATUS_PROTECTION_3(void)
{
}
void SchM_Exit_FrSM_CLUSTER_STATUS_PROTECTION_0(void)
{
}
void SchM_Exit_FrSM_CLUSTER_STATUS_PROTECTION_1(void)
{
}
void SchM_Exit_FrSM_CLUSTER_STATUS_PROTECTION_2(void)
{
}
void SchM_Exit_FrSM_CLUSTER_STATUS_PROTECTION_3(void)
{
}
#endif
#ifdef FIM_MODULE_ACTIVE
/*******************************************************************************
**                      FIM                                                 **
*******************************************************************************/
void SchM_Enter_FiM_REQUEST_EVENTID_PROTECTION(void)
{
}
void SchM_Exit_FiM_REQUEST_EVENTID_PROTECTION(void)
{
}
void SchM_Enter_FiM_REQUEST_FID_PROTECTION(void)
{
}
void SchM_Exit_FiM_REQUEST_FID_PROTECTION(void)
{
}
#endif
/*******************************************************************************
**                      DLT                                                 **
*******************************************************************************/

#ifdef DLT_MODULE_ACTIVE
void SchM_Enter_Dlt_LOGTRACE_PROTECTION(void)
{
}
void SchM_Exit_Dlt_LOGTRACE_PROTECTION(void)
{
}
void SchM_Enter_Dlt_REGISTER_CNTXT_PROTECTION(void)
{
}
void SchM_Exit_Dlt_REGISTER_CNTXT_PROTECTION(void)
{
}
#endif

#ifdef CSM_MODULE_ACTIVE
/*******************************************************************************
**                      CSM                                                   **
*******************************************************************************/
void SchM_Enter_Csm_FUNCTION_PTR_PROTECTION(void)
{
}
void SchM_Exit_Csm_FUNCTION_PTR_PROTECTION(void)
{
}
#endif

/*******************************************************************************
**                         TestSchM_DefaultBehavior()                         **
*******************************************************************************/
void TestSchM_DefaultBehavior(void)
{
  #ifdef BSWM_MODULE_ACTIVE
  SchM_Switch_BswMCount = 0;
  #endif
  #ifdef DCM_MODULE_ACTIVE
  Dcm_SecCntrlCount = 0;
  #endif
  #ifdef CANIF_MODULE_ACTIVE
  Guc_SchMenterCnt1 = 0;
  Guc_SchMexitCnt1 = 0;
  #endif
}
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
