/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Rte.c                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Run Time Environment                                  **
**                                                                            **
**  PURPOSE   : Declaration of Rte functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Rte.h"
#include "Rte_Type.h"
#ifdef COMM_MODULE_ACTIVE
#include "Rte_ComM.h"
#include "Rte_ComM_Type.h"
#endif

#ifdef CSM_MODULE_ACTIVE
#include "Rte_Csm.h"
#endif

#ifdef DLT_MODULE_ACTIVE
#include "Rte_Dlt_Type.h"
#include "Rte_Dlt.h"
#endif

#ifdef COM_MODULE_ACTIVE
#include "Rte_Cbk.h"
#include "App_Com_Sub_Functions.h"
#endif

#ifdef BSWM_MODULE_ACTIVE
#include "Rte_BswM.h"
#endif

#ifdef NVM_MODULE_ACTIVE
#include "Rte_NvM.h"
#include "App_NvM_Sub_Functions.h"
#endif

#ifdef DCM_MODULE_ACTIVE
#include "Rte_Dcm.h"
#endif

#ifdef DEM_MODULE_ACTIVE
#include "Rte_Dem.h"
#endif

#ifdef STBM_MODULE_ACTIVE
#include "Rte_StbM_Type.h"
#include "Rte_StbM.h"
#endif

#ifdef NM_MODULE_ACTIVE
#include "Rte_Nm.h"
#endif

#ifdef DET_MODULE_ACTIVE
#include "Rte_Det.h"
#endif
/*******************************************************************************
* D E F I N E S
*******************************************************************************/

/*******************************************************************************
* M A C R O 'S
*******************************************************************************/

/*******************************************************************************
* T Y P E   D E F I N I T I O N S
*******************************************************************************/

/*******************************************************************************
* C O N S T A N T S
*******************************************************************************/

/*******************************************************************************
* F I L E    S C O P E    V A R I A B L E S
*******************************************************************************/

/*******************************************************************************
* G L O B A L    V A R I A B L E S
*******************************************************************************/
#ifdef CSM_MODULE_ACTIVE
Csm_ReturnType GddReturnVal;
#endif

#ifdef COMM_MODULE_ACTIVE
uint8 Rte_GucComModeIndicationCount;
ComM_ModeType Rte_GddMode;
uint8 Rte_GucWriteCount;
uint8 Rte_Gddnoofreq[10];
ComM_UserHandleType Rte_Gdduserid[10];
#endif

#ifdef COM_MODULE_ACTIVE
uint8 GucSeqCount;
boolean Com_GblTxTOutS4;
boolean Com_GblTxTOutS5;
boolean Com_GblTxTOutS6;
boolean Com_GblTxTOutS7;
boolean Com_GblTxTOutS8;
boolean Com_GblRxTOutS7;
boolean Com_GblRxTOutS8;
boolean Com_GblRxTOutS9;
boolean Com_GblRxTOutS10;
boolean Com_GblRxTOutS11;
boolean Com_GblRxTOutS12;
boolean Com_GblRxTOutS28;
boolean Com_GblRxTOutS29;
boolean Com_GblRxTOutS30;
boolean Com_GblRxTOutS1;
boolean Com_GblRxTOutS2;
boolean Com_GblRxTOutS3;
boolean Com_GblRxTOutS4;
boolean Com_GblRxTOutS5;
boolean Com_GblRxTOutS6;
boolean Com_GblRxTOutSg2;
boolean Com_GblRxTOutS34;
boolean Com_GblRxTOutS35;
boolean Com_GblRxTOutS36;
boolean Com_GblRxTOutS31;
boolean Com_GblRxTOutS32;
boolean Com_GblRxTOutS33;
boolean Com_GblRxTOutSg3;
boolean Com_GblRxTOutSg5;
boolean Com_GblRxTOutSg6;
boolean Com_GblRxTOutSg1;
boolean Com_GblTACks3;
boolean Com_GblTACks4;
boolean Com_GblTACks6;
boolean Com_GblTACks2;
boolean Com_GblTACkSg1;
boolean Com_GblTACkSg3;
boolean Com_GblTACkSg4;
boolean Com_GblTACkSg5;
boolean Com_GblTACkSg6;
boolean Com_GblComCbk3;
boolean Com_GblCbkInv4;
boolean Com_GblComCbk9;
boolean Com_GblComCbk4;
boolean Com_GblComCbk5;
boolean Com_GblComCbk6;
boolean Com_GblComCbk7;
boolean Com_GblComCbk8;
boolean Com_GblComCbk9;
boolean Com_GblComCbk10;
boolean Com_GblComCbk14;
boolean Com_GblComCbk15;
boolean Com_GblComCbk16;
boolean Com_GblComCbk17;
boolean Com_GblComCbk18;
boolean Com_GblComCbk19;
boolean Com_GblComCbk20;
boolean Com_GblComCbk23;
boolean Com_GblComCbk24;
boolean Com_GblComCbk25;
boolean Com_GblComCbk26;
boolean Com_GblComCbk27;
boolean Com_GblComCbk28;
boolean Com_GblComCbk29;
boolean Com_GblComCbk30;
boolean Com_GblComCbk31;
boolean Com_GblComCbk32;
boolean Com_GblComCbk33;
boolean Com_GblComCbk34;
boolean Com_GblComCbk35;
boolean Com_GblComCbk36;
boolean Com_GblComCbk37;
boolean Com_GblComCbk38;
boolean Com_GblComCbk39;
boolean Com_GblComCbk40;
boolean Com_GblComCbk41;
boolean Com_GblComCbk42;
boolean Com_GblComCbk43;
boolean Com_GblComCbk44;
boolean Com_GblComCbk45;
boolean Com_GblComCbk46;
boolean Com_GblComCbk47;
boolean Com_GblComCbk48;
boolean Com_GblComCbk49;
boolean Com_GblComCbk50;
boolean Com_GblComCbk51;
boolean Com_GblComCbk52;
boolean Com_GblComCbk53;
boolean Com_GblComCbk54;
boolean Com_GblComCbk55;
boolean Com_GblComCbk56;
boolean Com_GblComCbk57;
boolean Com_GblComCbk58;
boolean Com_GblComCbk59;
boolean Com_GblComCbk60;
boolean Com_GblComCbk61;
boolean Com_GblComCbk62;
boolean Com_GblComCbk63;
boolean Com_GblCbkInv9;
boolean Com_GblCbkInv14;
boolean Com_GblCbkInv16;
boolean Com_GblComCbkSg1;
boolean Com_GblComCbkSg2;
boolean Com_GblComCbkSg10;
boolean Com_GblCbkInvSg3;
boolean Com_GblCbkInvSg4;
boolean Com_GblCbkInvSg5;
boolean Com_GblCbkInvSg6;
boolean Com_GblCbkInvS1;
boolean Com_GblCbkInvS17;
boolean Com_GblCbkInvS11;
boolean Com_GblCbkInvS21;
boolean Com_GblCbkInvS15;
boolean Com_GblCbkInvS19;
boolean Com_GblCbkInvS63;
boolean Com_GblCbkInvSg1;
boolean Com_GblCbkInvSg2;
boolean Com_GblComCbk1;
boolean Com_GblTACks1;
boolean Com_GblTACks5;
boolean Com_GblTACks6;
boolean Com_GblTACkSg2;
boolean Com_GblComCbk2;
boolean Com_GblTxTOutSg2;
boolean Com_GblTxTOutS3;
boolean Com_GblTxTOutS1;
boolean Com_GblTxTOutS2;
boolean Com_GblTxTOutSg1;
boolean Com_GblRxTOutS21;
boolean Com_GblRxTOutSg8;
boolean Com_GblTErrS4;
boolean Com_GblCbkInvS2;
boolean Com_GblCbkInvS7;
uint8 GucSWCCbkCount;
uint8 GucActExpCount;
uint8 GucActRecCount;
PduIdType GddActComPduId;
PduIdType GddCalloutId;
PduIdType GddRxCalloutId;
uint8* GddCalloutIpduData;
const uint8* GddRxCalloutIpduData;
uint8 Com_CallOutCount;
uint8 Com_CallOutCount6;
boolean Com_CallOutRetVal;
uint8 Com_Rx_CallOutCount;
boolean Com_CallOutRxRetVal;
#endif

#ifdef BSWM_MODULE_ACTIVE
uint8 Rte_GucRead_Port1_VariableDataProtoType1Count;
uint8 Rte_GucNotification_Port1_ModeDeclarationGroupProtoType1Count;
uint8 Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count;
uint8 Rte_GucPartitionResetCount;
uint8 Rte_GucMode_Port1_ModeDeclarationGroupProtoType1Count;
SwitchMode_Type Rte_GddNewMode;
Std_ReturnType Rte_GddPortRetValue;
AppModeRequestType Rte_GddCurrentActiveMode;
AppModeRequestType Rte_GddRequestedMode;
uint8 Rte_GucInitCnt;
uint8 Rte_GucInitSeqCnt;
#endif

#ifdef DEM_MODULE_ACTIVE
uint8 Rte_GucReportCheckCount;
uint16 Det_GucEventId[10];
uint8 Det_GucDTCId[10];
uint8 Rte_GucReportCount;
uint8  Det_GucEventStatusNew[10];
uint8  Det_GucDTCStatusNew[10];
uint8 Det_GusEventStatusOld[10];
uint8 Det_GusDTCStatusOld[10];
Dem_InitMonitorReasonType Rte_DemInitMonitorReason;
Dem_InitMonitorReasonType Rte_DemInitMonitorReason3;
Dem_InitMonitorReasonType Rte_DemInitMonitorReason4;
uint8 Rte_GucDemGlobalCount;
uint8 Rte_GucDemGlobalCount3=0;
uint8 Rte_GucDemGlobalCount4=0;
uint8 Rte_DemCallbackClearEventAllowedCnt_1;
uint8 Rte_DemCallbackClearEventAllowedCnt_2;
uint8 Rte_DemCallbackClearEventAllowedCnt_3;
uint8 Rte_CallbackDemGetFaultDetectionCallCnt_3=0;
uint8 Test_SWC_DemTriggerOnEventStatus_Event1_Cnt=0;
uint8 Test_SWC_DemTriggerOnEventStatus_Event2_Cnt=0;
uint8 Test_DemTriggerOnDTCStatus1_Cnt=0;
uint8 Test_DemTriggerOnDTCStatus2_Cnt=0;
uint8 GucDemEventDataChanged_EventId=0;
uint8 GucDemEventDataChanged_Cnt=0;
uint32 DemTriggerOnDTCStatus_DTC=0;
uint8 DemTriggerOnDTCStatus_DTCStatusOld;
uint8 DemTriggerOnDTCStatus_DTCStatusNew;
Std_ReturnType Rte_GddRetValue;
uint8 Rte_GaaDataBuffer1[1] = {0x01};
uint8 Rte_GaaDataBuffer2[2] = {0x01, 0x02};
uint8 Rte_GaaDataBuffer3[1] = {0x01};
uint8 Rte_GaaDataBuffer4[3] = {0x01, 0x02,0x03};
uint8 Rte_GaaDataBuffer5[1] = {0x01};
uint8 Rte_GaaObdDataBuffer1[2] = {1,2};
uint8 Rte_GaaObdDataBuffer2[1] = {120};
uint8 Rte_GaaObdDataBuffer3[3] = {4,5,6};
uint8 Rte_GaaObdDataBuffer4[1] = {7};
uint16 Dem_GusReadUsageModeData;
uint8 GucIndex;
uint32 Dem_GusReadDD00Data;
uint8 Dem_GusReadDD01Data[3];
uint8 Dem_GusReadDD02Data;
uint8 Dem_GusReadDD0AData;
Dem_InitMonitorReasonType Rte_DemInitMonitorReason14;
uint8 Rte_GucDemGlobalCount14=0;
#endif

#ifdef DLT_MODULE_ACTIVE
Dlt_ApplicationIDType Dlt_GaaSetVal0app_id[4];
Dlt_ApplicationIDType Dlt_GaaSetVal1app_id[4];
Dlt_ApplicationIDType Dlt_GaaSetVal2app_id[4];
Dlt_ApplicationIDType Dlt_GaaSetVal3app_id[4];
Dlt_ContextIDType Dlt_GaaSetVal0context_id[4];
Dlt_ContextIDType Dlt_GaaSetVal1context_id[4];
Dlt_ContextIDType Dlt_GaaSetVal2context_id[4];
Dlt_ContextIDType Dlt_GaaSetVal3context_id[4];
Dlt_MessageLogLevelType Dlt_Gddloglevel;
boolean Dlt_Gblnew_trace_status;
boolean Dlt_Gblis_verbose_mode;
uint32 Dlt_Gucservice_id;
uint32 Dlt_Gucdata_length;
uint8 Dlt_GaaInjectData[DLT_DATA_ARRAY];
#endif

#ifdef NVM_MODULE_ACTIVE
uint8 NvM_SingleBlockServiceId[RTE_ARRAY_SIZE];
uint8 NvM_GucSingleBlkCbkCount;
uint8 NvM_GucInitBlkCbkCount;
uint8 NvM_GucSingleBlkCbkCheckCount;
uint8 NvM_GucMirrorBlkCbkCount;
NvM_RequestResultType NvM_SingleBlockJobResult[RTE_ARRAY_SIZE];
Std_ReturnType NvM_GddReadRamBlockRetVal;
Std_ReturnType NvM_GddWriteRamBlockRetVal;
#endif

#ifdef DCM_MODULE_ACTIVE
uint16 Dcm_GusGeneralDataLength;
uint16 Dcm_GusTestVal;
uint16 Dcm_GusMinLinit;
uint16 Dcm_GusMaxLimit;
uint8 Dcm_GucRteGeneralCountseed;
uint8 Dcm_GucRteGeneralCount;
uint8 Dcm_GucRteGeneralCountkey;
uint8 Dcm_GucRteGeneralCountCheck;
uint8 Dcm_GucStatus;
uint8 GaaSecurityAccessDataRecord[2];
uint8 Dcm_GaaGeneralData[5];
uint8 Dcm_GaaGetSeed[5];
uint8 Dcm_GaaKeyValue[5];
uint8 Dcm_GaaRoutineOutData[2];
uint8 Dcm_GaaRoutineInData[2];
uint8 Dcm_GaaRteGeneralData[5];
uint8 Dcm_GucControlOptionRecord;
uint8 Dcm_GucRteDataLength;
uint8 Dcm_GucRteReadCount;
uint8 Dcm_GucRteGeneralCountCheck;
uint8 Dcm_GucRteReadLengthCount;
Dcm_OpStatusType Dcm_GddGeneralOpStatus;
Dcm_NegativeResponseCodeType Dcm_GddGeneralNegativeError;
Std_ReturnType Dcm_GddRteGeneralReturn;
Std_ReturnType Dcm_GddRteStartGeneralReturn;
Std_ReturnType Dcm_GddRteReadDataReturn;
Std_ReturnType Dcm_GddRteReadLengthReturn;
Std_ReturnType Dcm_GddWriteDataOneReturn;
Dcm_ProtocolType Dcm_GddProtocolType;
#endif

#ifdef STBM_MODULE_ACTIVE
StbM_SynchronizedTimeBaseType StbM_GddTimeBaseId001;
StbM_SyncStatusType StbM_GddSyncState001;
StbM_TickType StbM_GddTicks001;
uint16 StbM_GddTickDuration001;
uint8 StbM_GddProvider001Count;
uint8 StbM_GddTickProvider001Count;
uint8 StbM_GddTickDurationProvider001Count;
StbM_SynchronizedTimeBaseType StbM_GddCustomerTimeBase001;
StbM_SynchronizedTimeBaseType StbM_GddCustomerTimeBase002;
StbM_SyncStatusType StbM_GddCustomerSyncState001;
uint8 StbM_GddCustomerSyncState001Count;
StbM_SyncStatusType StbM_GddCustomerSyncState002;
uint8 StbM_GddCustomerSyncState002Count;
StbM_TickType StbM_GddCustomerGlobalTime001;
uint8 StbM_GddCustomerGlobalTime001Count;
StbM_TickType StbM_GddCustomerGlobalTime002;
uint8 StbM_GddCustomerGlobalTime002Count;
#endif /* #ifdef STBM_MODULE_ACTIVE */

#ifdef NM_MODULE_ACTIVE
NetworkHandleType Nm_GddChnlHandle;
uint8 Nm_GucChnlHandlCount;
#endif
/*******************************************************************************
* M A I N  F U N C T I O N    D E F I N I T I O N S
*******************************************************************************/

#ifdef CSM_MODULE_ACTIVE
Std_ReturnType Rte_CsmCallback(Csm_ReturnType Result)
{
  GddReturnVal = Result;
  return E_OK;
}

Std_ReturnType TestRte_CsmCallback(Csm_ReturnType *ResultPtr)
{
  *ResultPtr = GddReturnVal;
  return E_OK;
}
#endif

/******************************************************************************/
#ifdef COMM_MODULE_ACTIVE
/* Channel specific main function extern declarations */
void User1_FullComFunc(ComM_ModeType ComMode)
{
  UNUSED(ComMode);
}

void User1_SilentComFunc(ComM_ModeType ComMode)
{
  UNUSED(ComMode);
}

void User1_NoComFunc(ComM_ModeType ComMode)
{
 UNUSED(ComMode);
}

/* Channel specific main function extern declarations */
void User2_FullComFunc(ComM_ModeType ComMode)
{
  UNUSED(ComMode);
}

void User2_SilentComFunc(ComM_ModeType ComMode)
{
  UNUSED(ComMode);
}

void User2_NoComFunc(ComM_ModeType ComMode)
{
  UNUSED(ComMode);
}

/* Channel specific main function extern declarations */
void User3_FullComFunc(ComM_ModeType ComMode)
{
  UNUSED(ComMode);
}

void User3_SilentComFunc(ComM_ModeType ComMode)
{
  UNUSED(ComMode);
}

void User3_NoComFunc(ComM_ModeType ComMode)
{
  UNUSED(ComMode);
}
const struct Rte_CDS_ComMUser Rte_Inst_ComMUser = 
{
  /* Port API section */ 
  {
    0,
    Rte_Switch_ComM_UM000_currentMode
  },
  
  {
    0,
    Rte_Switch_ComM_UM001_currentMode
  },
  
  {
    0,
    Rte_Switch_ComM_UM002_currentMode
  },
  
  {
    0,
    Rte_Switch_ComM_UM003_currentMode
  },
  
  {
    0,
    Rte_Switch_ComM_UM004_currentMode
  },
  
  {
    0,
    Rte_Switch_ComM_UM005_currentMode
  },
  
  {
    0,
    Rte_Switch_ComM_UM006_currentMode
  },
  
  {
    0,
    Rte_Switch_ComM_UM007_currentMode
  },
  
  {
    0,
    Rte_Switch_ComM_UM008_currentMode
  },
  
  {
    0,
    Rte_Switch_ComM_UM009_currentMode
  }  
};

const struct Rte_CDS_ComMChnl Rte_Inst_ComMChannel = 
{
  /* Port API section */ 
  {
    Rte_Write_ComM_CR000_fullComRequestors
  },
  
  {
    Rte_Write_ComM_CR001_fullComRequestors
  },
  
  {
    Rte_Write_ComM_CR002_fullComRequestors
  },
  
  {
    Rte_Write_ComM_CR003_fullComRequestors
  },
  
  {
    Rte_Write_ComM_CR004_fullComRequestors
  },
  
  {
    Rte_Write_ComM_CR005_fullComRequestors
  },
  
  {
    Rte_Write_ComM_CR006_fullComRequestors
  },
  
  {
    Rte_Write_ComM_CR007_fullComRequestors
  },
  
  {
    Rte_Write_ComM_CR008_fullComRequestors
  },
  
  {
    Rte_Write_ComM_CR009_fullComRequestors
  }  
};



Std_ReturnType Rte_Switch_ComM_UM000_currentMode(IN Rte_ModeType_ComMMode NewMode)
{
  #ifndef TYPICAL_CONFIG
  Rte_GucComModeIndicationCount++;
  Rte_GddMode = NewMode;
  #endif
  return E_OK;  
}

Std_ReturnType TestRte_Switch_ComM_UM000_currentMode(App_DataValidateType LucDataValidate,
  IN Rte_ModeType_ComMMode ExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucComModeIndicationCount == 0x01) && 
        (Rte_GddMode == ExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucComModeIndicationCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucComModeIndicationCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}


Std_ReturnType Rte_Switch_ComM_UM001_currentMode(IN Rte_ModeType_ComMMode NewMode)
{
  #ifndef TYPICAL_CONFIG
  Rte_GucComModeIndicationCount++;
  Rte_GddMode = NewMode;
  #endif
  return E_OK;
}

Std_ReturnType TestRte_Switch_ComM_UM001_currentMode(App_DataValidateType LucDataValidate,
IN Rte_ModeType_ComMMode ExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucComModeIndicationCount == 0x01) && 
        (Rte_GddMode == ExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucComModeIndicationCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucComModeIndicationCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}

Std_ReturnType Rte_Switch_ComM_UM002_currentMode(IN Rte_ModeType_ComMMode NewMode)
{
  #ifndef TYPICAL_CONFIG
  Rte_GucComModeIndicationCount++;
  Rte_GddMode = NewMode;
  #endif
  return E_OK;
}

Std_ReturnType TestRte_Switch_ComM_UM002_currentMode(App_DataValidateType LucDataValidate,
IN Rte_ModeType_ComMMode ExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucComModeIndicationCount == 0x01) && 
        (Rte_GddMode == ExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucComModeIndicationCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucComModeIndicationCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}

Std_ReturnType Rte_Switch_ComM_UM003_currentMode(IN Rte_ModeType_ComMMode NewMode)
{
  #ifndef TYPICAL_CONFIG
  Rte_GucComModeIndicationCount++;
  Rte_GddMode = NewMode;
  #endif
  return E_OK;
}

Std_ReturnType TestRte_Switch_ComM_UM003_currentMode(App_DataValidateType LucDataValidate,
IN Rte_ModeType_ComMMode ExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucComModeIndicationCount == 0x01) && 
        (Rte_GddMode == ExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucComModeIndicationCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucComModeIndicationCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}


Std_ReturnType Rte_Switch_ComM_UM004_currentMode(IN Rte_ModeType_ComMMode NewMode)
{
  #ifndef TYPICAL_CONFIG
  Rte_GucComModeIndicationCount++;
  Rte_GddMode = NewMode;
  #endif
  return E_OK;
}

Std_ReturnType TestRte_Switch_ComM_UM004_currentMode(App_DataValidateType LucDataValidate,
IN Rte_ModeType_ComMMode ExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucComModeIndicationCount == 0x01) && 
        (Rte_GddMode == ExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucComModeIndicationCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucComModeIndicationCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}


Std_ReturnType Rte_Switch_ComM_UM005_currentMode(IN Rte_ModeType_ComMMode NewMode)
{
  #ifndef TYPICAL_CONFIG
  Rte_GucComModeIndicationCount++;
  Rte_GddMode = NewMode;
  #endif
  return E_OK;
}

Std_ReturnType TestRte_Switch_ComM_UM005_currentMode(App_DataValidateType LucDataValidate,
IN Rte_ModeType_ComMMode ExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucComModeIndicationCount == 0x01) && 
        (Rte_GddMode == ExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucComModeIndicationCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucComModeIndicationCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}
Std_ReturnType Rte_Switch_ComM_UM006_currentMode(IN Rte_ModeType_ComMMode NewMode)
{
  #ifndef TYPICAL_CONFIG
  Rte_GucComModeIndicationCount++;
  Rte_GddMode = NewMode;
  #endif
  return E_OK;
}

Std_ReturnType TestRte_Switch_ComM_UM006_currentMode(App_DataValidateType LucDataValidate,
IN Rte_ModeType_ComMMode ExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucComModeIndicationCount == 0x01) && 
        (Rte_GddMode == ExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucComModeIndicationCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucComModeIndicationCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}
Std_ReturnType Rte_Switch_ComM_UM007_currentMode(IN Rte_ModeType_ComMMode NewMode)
{
  #ifndef TYPICAL_CONFIG
  Rte_GucComModeIndicationCount++;
  Rte_GddMode = NewMode;
  #endif
  return E_OK;
}

Std_ReturnType TestRte_Switch_ComM_UM007_currentMode(App_DataValidateType LucDataValidate,
IN Rte_ModeType_ComMMode ExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucComModeIndicationCount == 0x01) && 
        (Rte_GddMode == ExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucComModeIndicationCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucComModeIndicationCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}

Std_ReturnType Rte_Switch_ComM_UM008_currentMode(IN Rte_ModeType_ComMMode NewMode)
{
  #ifndef TYPICAL_CONFIG
  Rte_GucComModeIndicationCount++;
  Rte_GddMode = NewMode;
  #endif
  return E_OK;
}

Std_ReturnType TestRte_Switch_ComM_UM008_currentMode(App_DataValidateType LucDataValidate,
IN Rte_ModeType_ComMMode ExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucComModeIndicationCount == 0x01) && 
        (Rte_GddMode == ExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucComModeIndicationCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucComModeIndicationCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}

Std_ReturnType Rte_Switch_ComM_UM009_currentMode(IN Rte_ModeType_ComMMode NewMode)
{
  #ifndef TYPICAL_CONFIG
  Rte_GucComModeIndicationCount++;
  Rte_GddMode = NewMode;
  #endif
  return E_OK;
}

Std_ReturnType TestRte_Switch_ComM_UM009_currentMode(App_DataValidateType LucDataValidate,
IN Rte_ModeType_ComMMode ExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucComModeIndicationCount == 0x01) && 
        (Rte_GddMode == ExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucComModeIndicationCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucComModeIndicationCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}


Std_ReturnType Rte_Write_ComM_CR000_fullComRequestors(IN ComM_UserHandleArrayType *data)
{
  #ifndef TYPICAL_CONFIG
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *data;
  Rte_GucWriteCount++;
  Rte_Gddnoofreq[0] = Ldddata.numberOfRequesters;
  Rte_Gdduserid[0] = Ldddata.handleArray[0];
  #endif
  return E_OK;  
}

Std_ReturnType TestRte_Write_ComM_CR000_fullComRequestors(App_DataValidateType LucDataValidate,
  IN ComM_UserHandleArrayType *Expdata)
{
  boolean LblStepResult;
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *Expdata;
  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucWriteCount == 0x01) && 
        (Rte_Gddnoofreq[0] == Ldddata.numberOfRequesters) &&
        (Rte_Gdduserid[0] == Ldddata.handleArray[0]))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucWriteCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucWriteCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}


Std_ReturnType Rte_Write_ComM_CR001_fullComRequestors(IN ComM_UserHandleArrayType *data)
{
  #ifndef TYPICAL_CONFIG
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *data;
  Rte_GucWriteCount++;
  Rte_Gddnoofreq[1] = Ldddata.numberOfRequesters;
  Rte_Gdduserid[1] = Ldddata.handleArray[0];
  #endif
  return E_OK;
}

Std_ReturnType TestRte_Write_ComM_CR001_fullComRequestors(App_DataValidateType LucDataValidate,
IN ComM_UserHandleArrayType *Expdata)
{
  boolean LblStepResult;
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *Expdata;
  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucWriteCount == 0x01) && 
        (Rte_Gddnoofreq[1] == Ldddata.numberOfRequesters)&&
        (Rte_Gdduserid[1] == Ldddata.handleArray[0]))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucWriteCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucWriteCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}

Std_ReturnType Rte_Write_ComM_CR002_fullComRequestors(IN ComM_UserHandleArrayType *data)
{
  #ifndef TYPICAL_CONFIG
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *data;
  Rte_GucWriteCount++;
  Rte_Gddnoofreq[2] = Ldddata.numberOfRequesters;
  Rte_Gdduserid[2] = Ldddata.handleArray[0];
  #endif
  return E_OK;
}

Std_ReturnType TestRte_Write_ComM_CR002_fullComRequestors(App_DataValidateType LucDataValidate,
IN ComM_UserHandleArrayType *Expdata)
{
  boolean LblStepResult;
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *Expdata;
  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucWriteCount == 0x01) && 
        (Rte_Gddnoofreq[2] == Ldddata.numberOfRequesters) &&
        (Rte_Gdduserid[2] == Ldddata.handleArray[0]))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucWriteCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucWriteCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}

Std_ReturnType Rte_Write_ComM_CR003_fullComRequestors(IN ComM_UserHandleArrayType *data)
{
  #ifndef TYPICAL_CONFIG
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *data;
  Rte_GucWriteCount++;
  Rte_Gddnoofreq[3] = Ldddata.numberOfRequesters;
  Rte_Gdduserid[3] = Ldddata.handleArray[0];
  #endif
  return E_OK;
}

Std_ReturnType TestRte_Write_ComM_CR003_fullComRequestors(App_DataValidateType LucDataValidate,
IN ComM_UserHandleArrayType *Expdata)
{
  boolean LblStepResult;
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *Expdata;
  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucWriteCount == 0x01) && 
        (Rte_Gddnoofreq[3] == Ldddata.numberOfRequesters) &&
        (Rte_Gdduserid[3] == Ldddata.handleArray[0]))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucWriteCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucWriteCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}

Std_ReturnType Rte_Write_ComM_CR004_fullComRequestors(IN ComM_UserHandleArrayType *data)
{
  #ifndef TYPICAL_CONFIG
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *data;
  Rte_GucWriteCount++;
  Rte_Gddnoofreq[4] = Ldddata.numberOfRequesters;
  Rte_Gdduserid[4] = Ldddata.handleArray[0];
  #endif
  return E_OK;
}

Std_ReturnType TestRte_Write_ComM_CR004_fullComRequestors(App_DataValidateType LucDataValidate,
IN ComM_UserHandleArrayType *Expdata)
{
  boolean LblStepResult;
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *Expdata;
  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucWriteCount == 0x01) && 
        (Rte_Gddnoofreq[4] == Ldddata.numberOfRequesters) &&
        (Rte_Gdduserid[4] == Ldddata.handleArray[0]))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucWriteCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucWriteCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}

Std_ReturnType Rte_Write_ComM_CR005_fullComRequestors(IN ComM_UserHandleArrayType *data)
{
  #ifndef TYPICAL_CONFIG
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *data;
  Rte_GucWriteCount++;
  Rte_Gddnoofreq[5] = Ldddata.numberOfRequesters;
  Rte_Gdduserid[5] = Ldddata.handleArray[0];
  #endif
  return E_OK;
}

Std_ReturnType TestRte_Write_ComM_CR005_fullComRequestors(App_DataValidateType LucDataValidate,
IN ComM_UserHandleArrayType *Expdata)
{
  boolean LblStepResult;
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *Expdata;
  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucWriteCount == 0x01) && 
        (Rte_Gddnoofreq[5] == Ldddata.numberOfRequesters) &&
        (Rte_Gdduserid[5] == Ldddata.handleArray[0]))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucWriteCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucWriteCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}

Std_ReturnType Rte_Write_ComM_CR006_fullComRequestors(IN ComM_UserHandleArrayType *data)
{
  #ifndef TYPICAL_CONFIG
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *data;
  Rte_GucWriteCount++;
  Rte_Gddnoofreq[6] = Ldddata.numberOfRequesters;
  Rte_Gdduserid[6] = Ldddata.handleArray[0];
  #endif
  return E_OK;
}

Std_ReturnType TestRte_Write_ComM_CR006_fullComRequestors(App_DataValidateType LucDataValidate,
IN ComM_UserHandleArrayType *Expdata)
{
  boolean LblStepResult;
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *Expdata;
  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucWriteCount == 0x01) && 
        (Rte_Gddnoofreq[6] == Ldddata.numberOfRequesters) &&
        (Rte_Gdduserid[6] == Ldddata.handleArray[0]))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucWriteCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucWriteCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}

Std_ReturnType Rte_Write_ComM_CR007_fullComRequestors(IN ComM_UserHandleArrayType *data)
{
  #ifndef TYPICAL_CONFIG
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *data;
  Rte_GucWriteCount++;
  Rte_Gddnoofreq[7] = Ldddata.numberOfRequesters;
  Rte_Gdduserid[7] = Ldddata.handleArray[0];
  #endif
  return E_OK;
}

Std_ReturnType TestRte_Write_ComM_CR007_fullComRequestors(App_DataValidateType LucDataValidate,
IN ComM_UserHandleArrayType *Expdata)
{
  boolean LblStepResult;
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *Expdata;
  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucWriteCount == 0x01) && 
        (Rte_Gddnoofreq[7] == Ldddata.numberOfRequesters) &&
        (Rte_Gdduserid[7] == Ldddata.handleArray[0]))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucWriteCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucWriteCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}

Std_ReturnType Rte_Write_ComM_CR008_fullComRequestors(IN ComM_UserHandleArrayType *data)
{
  #ifndef TYPICAL_CONFIG
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *data;
  Rte_GucWriteCount++;
  Rte_Gddnoofreq[8] = Ldddata.numberOfRequesters;
  Rte_Gdduserid[8] = Ldddata.handleArray[0];
  #endif
  return E_OK;
}

Std_ReturnType TestRte_Write_ComM_CR008_fullComRequestors(App_DataValidateType LucDataValidate,
IN ComM_UserHandleArrayType *Expdata)
{
  boolean LblStepResult;
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *Expdata;
  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucWriteCount == 0x01) && 
        (Rte_Gddnoofreq[8] == Ldddata.numberOfRequesters) &&
        (Rte_Gdduserid[8] == Ldddata.handleArray[0]))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucWriteCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucWriteCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}

Std_ReturnType Rte_Write_ComM_CR009_fullComRequestors(IN ComM_UserHandleArrayType *data)
{
  #ifndef TYPICAL_CONFIG
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *data;
  Rte_GucWriteCount++;
  Rte_Gddnoofreq[9] = Ldddata.numberOfRequesters;
  Rte_Gdduserid[9] = Ldddata.handleArray[0];
  #endif
  return E_OK;
}

Std_ReturnType TestRte_Write_ComM_CR009_fullComRequestors(App_DataValidateType LucDataValidate,
IN ComM_UserHandleArrayType *Expdata)
{
  boolean LblStepResult;
  ComM_UserHandleArrayType Ldddata;
  Ldddata = *Expdata;
  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Rte_GucWriteCount == 0x01) && 
        (Rte_Gddnoofreq[9] == Ldddata.numberOfRequesters) &&
        (Rte_Gdduserid[9] == Ldddata.handleArray[0]))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Rte_GucWriteCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Rte_GucWriteCount == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);  
}
#endif /* #ifdef COMM_MODULE_ACTIVE */

#ifdef COM_MODULE_ACTIVE
/*******************************************************************************
**                     Rte_COMCbkInv_s2()                                     **
*******************************************************************************/
void Rte_COMCbkInv_s2(void)
{
  Com_GblCbkInvS2 = TRUE;
}/* End Rte_COMCbkInv_s2 */

/*******************************************************************************
**                     Rte_COMCbkInv_sg2()                                    **
*******************************************************************************/
void Rte_COMCbkInv_sg2(void)
{
  Com_GblCbkInvSg2 = TRUE;
}/* End Rte_COMCbkInv_sg2 */

/*******************************************************************************
**                     Rte_COMCbkInv_s7()                                     **
*******************************************************************************/
void Rte_COMCbkInv_s7(void)
{
  Com_GblCbkInvS7 = TRUE;
}/* End Rte_COMCbkInv_s7 */

/*******************************************************************************
**                     Rte_COMCbkTxTOut_s4()                                  **
*******************************************************************************/
void Rte_COMCbkTxTOut_s4(void)
{
  Com_GblTxTOutS4 = TRUE;
}/* End Rte_COMCbkTxTOut_s4 */

/*******************************************************************************
**                     TestRte_COMCbkTxTOut_s4()                              **
*******************************************************************************/
boolean TestRte_COMCbkTxTOut_s4(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTxTOutS4 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTxTOutS4 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTxTOutS4 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTxTOut_s4 */

/*******************************************************************************
**                     Rte_COMCbkTxTOut_s5()                                  **
*******************************************************************************/
void Rte_COMCbkTxTOut_s5(void)
{
  Com_GblTxTOutS5 = TRUE;
}/* End Rte_COMCbkTxTOut_s5 */

/*******************************************************************************
**                     TestRte_COMCbkTxTOut_s5()                              **
*******************************************************************************/
boolean TestRte_COMCbkTxTOut_s5(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTxTOutS5 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTxTOutS5 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTxTOutS5 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTxTOut_s5 */

/*******************************************************************************
**                     Rte_COMCbkTxTOut_s6()                                  **
*******************************************************************************/
void Rte_COMCbkTxTOut_s6(void)
{
  Com_GblTxTOutS6 = TRUE;
}/* End Rte_COMCbkTxTOut_s6 */

/*******************************************************************************
**                     TestRte_COMCbkTxTOut_s6()                              **
*******************************************************************************/
boolean TestRte_COMCbkTxTOut_s6(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTxTOutS6 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTxTOutS6 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTxTOutS6 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTxTOut_s6 */

/*******************************************************************************
**                     TestRte_COMCbk_s7()                                    **
*******************************************************************************/
boolean TestRte_COMCbk_s7(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk7 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk7 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk7 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s7 */

/*******************************************************************************
**                     TestRte_COMCbkInv_s7()                                 **
*******************************************************************************/
boolean TestRte_COMCbkInv_s7(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblCbkInvS7 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblCbkInvS7 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblCbkInvS7 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkInv_s7 */

/*******************************************************************************
**                     TestRte_COMCbk_s8()                                    **
*******************************************************************************/
boolean TestRte_COMCbk_s8(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk8 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk8 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk8 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s8 */

/*******************************************************************************
**                     TestRte_COMCbkInv_s11()                                **
*******************************************************************************/
boolean TestRte_COMCbkInv_s11(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblCbkInvS11 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblCbkInvS11 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblCbkInvS11 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkInv_s11 */

/*******************************************************************************
**                     TestRte_COMCbk_s17()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s17(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk17 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk17 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk17 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s17 */

/*******************************************************************************
**                     TestRte_COMCbkInv_s17()                                **
*******************************************************************************/
boolean TestRte_COMCbkInv_s17(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblCbkInvS17 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblCbkInvS17 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }

    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblCbkInvS17 = FALSE;
  return(LblRetVal);
} /* End TestRte_ComCbkInv_s1 */

/*******************************************************************************
**                     TestRte_COMCbk_s18()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s18(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk18 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk18 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk18 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s18 */

/*******************************************************************************
**                     TestRte_COMCbkInv_s21()                                **
*******************************************************************************/
boolean TestRte_COMCbkInv_s21(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblCbkInvS21 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblCbkInvS21 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblCbkInvS21 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkInv_s21 */

/*******************************************************************************
**                     TestRte_COMCbk_s6()                                    **
*******************************************************************************/
boolean TestRte_COMCbk_s6(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk6 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk6 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk6 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s6 */
/*******************************************************************************
**                     Rte_COMCbkTxTOut_s7()                                  **
*******************************************************************************/
void Rte_COMCbkTxTOut_s7(void)
{
  Com_GblTxTOutS7 = TRUE;
}/* End Rte_COMCbkTxTOut_s6 */

/*******************************************************************************
**                     TestRte_COMCbkTxTOut_s7()                              **
*******************************************************************************/
boolean TestRte_COMCbkTxTOut_s7(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTxTOutS7 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTxTOutS7 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTxTOutS7 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTxTOut_s7 */

/*******************************************************************************
**                     Rte_COMCbkTxTOut_s8()                                  **
*******************************************************************************/
void Rte_COMCbkTxTOut_s8(void)
{
  Com_GblTxTOutS8 = TRUE;
}/* End Rte_COMCbkTxTOut_s8 */

/*******************************************************************************
**                     TestRte_COMCbkTxTOut_s8()                              **
*******************************************************************************/
boolean TestRte_COMCbkTxTOut_s8(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTxTOutS8 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTxTOutS8 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTxTOutS8 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTxTOut_s8 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s7()                                  **
*******************************************************************************/
void Rte_COMCbkRxTOut_s7(void)
{
  Com_GblRxTOutS7 = TRUE;
}/* End Rte_COMCbkRxTOut_s7 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s7()                              **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s7(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS7 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS7 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS7 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s7 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s8()                                  **
*******************************************************************************/
void Rte_COMCbkRxTOut_s8(void)
{
  Com_GblRxTOutS8 = TRUE;
}/* End Rte_COMCbkRxTOut_s8 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s8()                              **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s8(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS8 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS8 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS8 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s8 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s9()                                  **
*******************************************************************************/
void Rte_COMCbkRxTOut_s9(void)
{
  Com_GblRxTOutS9 = TRUE;
}/* End Rte_COMCbkRxTOut_s9 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s9()                              **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s9(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS9 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS9 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS9 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s9 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s10()                                 **
*******************************************************************************/
void Rte_COMCbkRxTOut_s10(void)
{
  Com_GblRxTOutS10 = TRUE;
}/* End Rte_COMCbkRxTOut_s10 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s10()                             **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s10(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS10 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS10 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS10 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s10 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s11()                                 **
*******************************************************************************/
void Rte_COMCbkRxTOut_s11(void)
{
  Com_GblRxTOutS11 = TRUE;
}/* End Rte_COMCbkRxTOut_s11 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s11()                             **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s11(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS11 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS11 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS11 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s11 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s12()                                 **
*******************************************************************************/
void Rte_COMCbkRxTOut_s12(void)
{
  Com_GblRxTOutS12 = TRUE;
}/* End Rte_COMCbkRxTOut_s12 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s12()                             **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s12(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS12 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS12 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS12 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s12 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s28()                                 **
*******************************************************************************/
void Rte_COMCbkRxTOut_s28(void)
{
  Com_GblRxTOutS28 = TRUE;
}/* End Rte_COMCbkRxTOut_s28 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s28()                             **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s28(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS28 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS28 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS28 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s28 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s29()                                 **
*******************************************************************************/
void Rte_COMCbkRxTOut_s29(void)
{
  Com_GblRxTOutS29 = TRUE;
}/* End Rte_COMCbkRxTOut_s29 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s29()                             **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s29(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS29 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS29 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS29 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s29 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s30()                                 **
*******************************************************************************/
void Rte_COMCbkRxTOut_s30(void)
{
  Com_GblRxTOutS30 = TRUE;
}/* End Rte_COMCbkRxTOut_s30 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s30()                             **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s30(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS30 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS30 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS30 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s30 */

/*******************************************************************************
**                     Rte_COMCbkTAck_s3()                                    **
*******************************************************************************/
void Rte_COMCbkTAck_s3(void)
{
  Com_GblTACks3 = TRUE;
}/* End Rte_COMCbkTAck_s3 */

/*******************************************************************************
**                     TestRte_COMCbkTAck_s3()                                **
*******************************************************************************/
boolean TestRte_COMCbkTAck_s3(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTACks3 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTACks3 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTACks3 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTAck_s3 */

/*******************************************************************************
**                     Rte_COMCbkTAck_s4()                                    **
*******************************************************************************/
void Rte_COMCbkTAck_s4(void)
{
  Com_GblTACks4 = TRUE;
}/* End Rte_COMCbkTAck_s4 */

/*******************************************************************************
**                     TestRte_COMCbkTAck_s4()                                **
*******************************************************************************/
boolean TestRte_COMCbkTAck_s4(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTACks4 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTACks4 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTACks4 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTAck_s4 */

/*******************************************************************************
**                     Rte_COMCbkTAck_s5()                                    **
*******************************************************************************/
void Rte_COMCbkTAck_s5(void)
{
  Com_GblTACks5 = TRUE;
}/* End Rte_COMCbkTAck_s5 */

/*******************************************************************************
**                     TestRte_COMCbkTAck_s5()                                **
*******************************************************************************/
boolean TestRte_COMCbkTAck_s5(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTACks5 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTACks5 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTACks5 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTAck_s5 */
/*******************************************************************************
**                     Rte_COMCbkTAck_s6()                                    **
*******************************************************************************/
void Rte_COMCbkTAck_s6(void)
{
  Com_GblTACks6 = TRUE;
}/* End Rte_COMCbkTAck_s6 */

/*******************************************************************************
**                     TestRte_COMCbkTAck_s6()                                **
*******************************************************************************/
boolean TestRte_COMCbkTAck_s6(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTACks6 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTACks6 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTACks6 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTAck_s6 */

/*******************************************************************************
**                     Rte_COMCbk_s3()                                        **
*******************************************************************************/
void Rte_COMCbk_s3(void)
{
  Com_GblComCbk3 = TRUE;
}/* End Rte_COMCbk_s3 */

/*******************************************************************************
**                     TestRte_COMCbk_s3()                                    **
*******************************************************************************/
boolean TestRte_COMCbk_s3(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk3 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk3 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk3 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s3 */

/*******************************************************************************
**                    Rte_COMCbkInv_s4()                                      **
*******************************************************************************/
void Rte_COMCbkInv_s4(void)
{
  Com_GblCbkInv4 = TRUE;
}/* End Rte_COMCbkInv_s4 */

/*******************************************************************************
**                     TestRte_COMCbkInv_s4()                                 **
*******************************************************************************/
boolean TestRte_COMCbkInv_s4(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblCbkInv4 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblCbkInv4 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblCbkInv4 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkInv_s4 */

/*******************************************************************************
**                     Rte_COMCbk_s9()                                        **
*******************************************************************************/
void Rte_COMCbk_s9(void)
{
  Com_GblComCbk9 = TRUE;
}/* End Rte_COMCbk_s9 */

/*******************************************************************************
**                     TestRte_COMCbk_s9()                                    **
*******************************************************************************/
boolean TestRte_COMCbk_s9(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk9 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk9 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk9 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s9 */

/*******************************************************************************
**                    Rte_COMCbkInv_s9()                                      **
*******************************************************************************/
void Rte_COMCbkInv_s9(void)
{
  Com_GblCbkInv9 = TRUE;
}/* End Rte_COMCbkInv_s9 */

/*******************************************************************************
**                     TestRte_COMCbkInv_s9()                                 **
*******************************************************************************/
boolean TestRte_COMCbkInv_s9(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblCbkInv9 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblCbkInv9 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblCbkInv9 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkInv_s9 */

/*******************************************************************************
**                     Rte_COMCbk_s10()                                       **
*******************************************************************************/
void Rte_COMCbk_s10(void)
{
  Com_GblComCbk10 = TRUE;
}/* End Rte_COMCbk_s10 */

/*******************************************************************************
**                     TestRte_COMCbk_s10()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s10(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk10 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk10 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk10 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s10 */

/*******************************************************************************
**                    Rte_COMCbkInv_s14()                                     **
*******************************************************************************/
void Rte_COMCbkInv_s14(void)
{
  Com_GblCbkInv14 = TRUE;
}/* End Rte_COMCbkInv_s14 */

/*******************************************************************************
**                     TestRte_COMCbkInv_s14()                                **
*******************************************************************************/
boolean TestRte_COMCbkInv_s14(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblCbkInv14 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblCbkInv14 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblCbkInv14 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkInv_s14 */

/*******************************************************************************
**                     Rte_COMCbk_s14()                                       **
*******************************************************************************/
void Rte_COMCbk_s14(void)
{
  Com_GblComCbk14 = TRUE;
}/* End Rte_COMCbk_s14 */

/*******************************************************************************
**                     TestRte_COMCbk_s14()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s14(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk14 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk14 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
    break;
  }

  /* Reset Global variable */
  Com_GblComCbk14 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s14 */

/*******************************************************************************
**                     Rte_COMCbk_s15()                                       **
*******************************************************************************/
void Rte_COMCbk_s15(void)
{
  Com_GblComCbk15 = TRUE;
}/* End Rte_COMCbk_s15 */

/*******************************************************************************
**                     TestRte_COMCbk_s15()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s15(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk15 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk15 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk15 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s15 */

/*******************************************************************************
**                    Rte_COMCbkInv_s16()                                     **
*******************************************************************************/
void Rte_COMCbkInv_s16(void)
{
  Com_GblCbkInv16 = TRUE;
}/* End Rte_COMCbkInv_s16 */

/*******************************************************************************
**                     TestRte_COMCbkInv_s16()                                **
*******************************************************************************/
boolean TestRte_COMCbkInv_s16(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblCbkInv16 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblCbkInv16 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblCbkInv16 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkInv_s16 */

/*******************************************************************************
**                     Rte_COMCbk_s16()                                       **
*******************************************************************************/
void Rte_COMCbk_s16(void)
{
  Com_GblComCbk16 = TRUE;
}/* End Rte_COMCbk_s16 */

/*******************************************************************************
**                     TestRte_COMCbk_s16()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s16(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk16 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk16 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk16 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s16 */

/*******************************************************************************
**                     Rte_COMCbk_s5()                                        **
*******************************************************************************/
void Rte_COMCbk_s5(void)
{
  Com_GblComCbk5 = TRUE;
}/* End Rte_COMCbk_s5 */

/*******************************************************************************
**                     TestRte_COMCbk_s5()                                    **
*******************************************************************************/
boolean TestRte_COMCbk_s5(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk5 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk5 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk5 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s5 */

/*******************************************************************************
**                     Rte_COMCbk_s6()                                        **
*******************************************************************************/
void Rte_COMCbk_s6(void)
{
  Com_GblComCbk6 = TRUE;
}/* End Rte_COMCbk_s6 */

/*******************************************************************************
**                     Rte_COMCbk_s8()                                        **
*******************************************************************************/
void Rte_COMCbk_s8(void)
{
  Com_GblComCbk8 = TRUE;
}/* End Rte_COMCbk_s8 */

/*******************************************************************************
**                     Rte_COMCbk_s7()                                        **
*******************************************************************************/
void Rte_COMCbk_s7(void)
{
  Com_GblComCbk7 = TRUE;
}/* End Rte_COMCbk_s7 */

/*******************************************************************************
**                     Rte_COMCbk_s17()                                       **
*******************************************************************************/
void Rte_COMCbk_s17(void)
{
  Com_GblComCbk17 = TRUE;
}/* End Rte_COMCbk_s17 */

/*******************************************************************************
**                     Rte_COMCbk_s18()                                       **
*******************************************************************************/
void Rte_COMCbk_s18(void)
{
  Com_GblComCbk18 = TRUE;
}/* End Rte_COMCbk_s18 */

/*******************************************************************************
**                     Rte_COMCbk_s19()                                       **
*******************************************************************************/
void Rte_COMCbk_s19(void)
{
  Com_GblComCbk19 = TRUE;
}/* End Rte_COMCbk_s19 */

/*******************************************************************************
**                     Rte_COMCbk_s20()                                       **
*******************************************************************************/
void Rte_COMCbk_s20(void)
{
  Com_GblComCbk20 = TRUE;
}/* End Rte_COMCbk_s20 */

/*******************************************************************************
**                     Rte_COMCbk_s23()                                       **
*******************************************************************************/
void Rte_COMCbk_s23(void)
{
  Com_GblComCbk23 = TRUE;
}/* End Rte_COMCbk_s23 */

/*******************************************************************************
**                     TestRte_COMCbk_s23()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s23(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk23 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk23 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk23 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s23 */

/*******************************************************************************
**                     Rte_COMCbk_s24()                                       **
*******************************************************************************/
void Rte_COMCbk_s24(void)
{
  Com_GblComCbk24 = TRUE;
}/* End Rte_COMCbk_s24 */

/*******************************************************************************
**                     TestRte_COMCbk_s24()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s24(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk24 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk24 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk24 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s24 */

/*******************************************************************************
**                     Rte_COMCbk_s25()                                       **
*******************************************************************************/
void Rte_COMCbk_s25(void)
{
  Com_GblComCbk25 = TRUE;
}/* End Rte_COMCbk_s25 */

/*******************************************************************************
**                     TestRte_COMCbk_s25()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s25(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk25 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk25 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk25 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s25 */

/*******************************************************************************
**                     Rte_COMCbk_s26()                                       **
*******************************************************************************/
void Rte_COMCbk_s26(void)
{
  Com_GblComCbk26 = TRUE;
}/* End Rte_COMCbk_s26 */

/*******************************************************************************
**                     TestRte_COMCbk_s26()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s26(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk26 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk26 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk26 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s26 */

/*******************************************************************************
**                     Rte_COMCbk_s27()                                       **
*******************************************************************************/
void Rte_COMCbk_s27(void)
{
  Com_GblComCbk27 = TRUE;
}/* End Rte_COMCbk_s27 */

/*******************************************************************************
**                     TestRte_COMCbk_s27()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s27(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk27 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk27 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk27 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s27 */

/*******************************************************************************
**                     Rte_COMCbk_s28()                                       **
*******************************************************************************/
void Rte_COMCbk_s28(void)
{
  Com_GblComCbk28 = TRUE;
}/* End Rte_COMCbk_s28 */

/*******************************************************************************
**                     TestRte_COMCbk_s28()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s28(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk28 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk28 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk28 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s28 */

/*******************************************************************************
**                     Rte_COMCbk_s29()                                       **
*******************************************************************************/
void Rte_COMCbk_s29(void)
{
  Com_GblComCbk29 = TRUE;
}/* End Rte_COMCbk_s29 */

/*******************************************************************************
**                     TestRte_COMCbk_s29()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s29(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk29 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk29 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk29 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s29 */

/*******************************************************************************
**                     Rte_COMCbk_s30()                                       **
*******************************************************************************/
void Rte_COMCbk_s30(void)
{
  Com_GblComCbk30 = TRUE;
}/* End Rte_COMCbk_s30 */

/*******************************************************************************
**                     TestRte_COMCbk_s30()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s30(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk30 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk30 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk30 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s30 */

/*******************************************************************************
**                     Rte_COMCbk_s31()                                       **
*******************************************************************************/
void Rte_COMCbk_s31(void)
{
  Com_GblComCbk31 = TRUE;
}/* End Rte_COMCbk_s31 */

/*******************************************************************************
**                     TestRte_COMCbk_s31()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s31(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk31 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk31 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk31 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s31 */

/*******************************************************************************
**                     Rte_COMCbk_s32()                                       **
*******************************************************************************/
void Rte_COMCbk_s32(void)
{
  Com_GblComCbk32 = TRUE;
}/* End Rte_COMCbk_s32 */

/*******************************************************************************
**                     TestRte_COMCbk_s32()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s32(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk32 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk32 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk32 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s32 */

/*******************************************************************************
**                     Rte_COMCbk_s33()                                       **
*******************************************************************************/
void Rte_COMCbk_s33(void)
{
  Com_GblComCbk33 = TRUE;
}/* End Rte_COMCbk_s33 */

/*******************************************************************************
**                     TestRte_COMCbk_s33()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s33(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk33 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk33 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk33 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s33 */

/*******************************************************************************
**                     Rte_COMCbk_s34()                                       **
*******************************************************************************/
void Rte_COMCbk_s34(void)
{
  Com_GblComCbk34 = TRUE;
}/* End Rte_COMCbk_s34 */

/*******************************************************************************
**                     TestRte_COMCbk_s34()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s34(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk34 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk34 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk34 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s34 */

/*******************************************************************************
**                     Rte_COMCbk_s35()                                       **
*******************************************************************************/
void Rte_COMCbk_s35(void)
{
  Com_GblComCbk35 = TRUE;
}/* End Rte_COMCbk_s35 */

/*******************************************************************************
**                     TestRte_COMCbk_s35()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s35(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk35 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk35 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk35 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s35 */

/*******************************************************************************
**                     Rte_COMCbk_s36()                                       **
*******************************************************************************/
void Rte_COMCbk_s36(void)
{
  Com_GblComCbk36 = TRUE;
}/* End Rte_COMCbk_s36 */

/*******************************************************************************
**                     TestRte_COMCbk_s36()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s36(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk36 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk36 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk36 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s36 */

/*******************************************************************************
**                     Rte_COMCbk_s37()                                       **
*******************************************************************************/
void Rte_COMCbk_s37(void)
{
  Com_GblComCbk37 = TRUE;
}/* End Rte_COMCbk_s37 */

/*******************************************************************************
**                     TestRte_COMCbk_s37()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s37(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk37 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk37 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk37 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s37 */

/*******************************************************************************
**                     Rte_COMCbk_s38()                                       **
*******************************************************************************/
void Rte_COMCbk_s38(void)
{
  Com_GblComCbk38 = TRUE;
}/* End Rte_COMCbk_s38 */

/*******************************************************************************
**                     TestRte_COMCbk_s38()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s38(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk38 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk38 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk38 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s38 */

/*******************************************************************************
**                     Rte_COMCbk_s39()                                       **
*******************************************************************************/
void Rte_COMCbk_s39(void)
{
  Com_GblComCbk39 = TRUE;
}/* End Rte_COMCbk_s39 */

/*******************************************************************************
**                     TestRte_COMCbk_s39()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s39(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk39 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk39 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk39 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s39 */

/*******************************************************************************
**                     Rte_COMCbk_s40()                                       **
*******************************************************************************/
void Rte_COMCbk_s40(void)
{
  Com_GblComCbk40 = TRUE;
}/* End Rte_COMCbk_s40 */

/*******************************************************************************
**                     TestRte_COMCbk_s40()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s40(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk40 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk40 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk40 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s40 */

/*******************************************************************************
**                     Rte_COMCbk_s41()                                       **
*******************************************************************************/
void Rte_COMCbk_s41(void)
{
  Com_GblComCbk41 = TRUE;
}/* End Rte_COMCbk_s41 */

/*******************************************************************************
**                     TestRte_COMCbk_s41()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s41(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk41 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk41 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk41 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s41 */

/*******************************************************************************
**                     Rte_COMCbk_s42()                                       **
*******************************************************************************/
void Rte_COMCbk_s42(void)
{
  Com_GblComCbk42 = TRUE;
}/* End Rte_COMCbk_s42 */

/*******************************************************************************
**                     TestRte_COMCbk_s42()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s42(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk42 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk42 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk42 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s42 */

/*******************************************************************************
**                     Rte_COMCbk_s43()                                       **
*******************************************************************************/
void Rte_COMCbk_s43(void)
{
  Com_GblComCbk43 = TRUE;
}/* End Rte_COMCbk_s43 */

/*******************************************************************************
**                     TestRte_COMCbk_s43()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s43(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk43 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk43 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk43 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s43 */

/*******************************************************************************
**                     Rte_COMCbk_s44()                                       **
*******************************************************************************/
void Rte_COMCbk_s44(void)
{
  Com_GblComCbk44 = TRUE;
}/* End Rte_COMCbk_s44 */

/*******************************************************************************
**                     TestRte_COMCbk_s44()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s44(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk44 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk44 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk44 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s44 */

/*******************************************************************************
**                     Rte_COMCbk_s45()                                       **
*******************************************************************************/
void Rte_COMCbk_s45(void)
{
  Com_GblComCbk45 = TRUE;
}/* End Rte_COMCbk_s45 */

/*******************************************************************************
**                     TestRte_COMCbk_s45()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s45(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk45 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk45 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk45 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s45 */

/*******************************************************************************
**                     Rte_COMCbk_s46()                                       **
*******************************************************************************/
void Rte_COMCbk_s46(void)
{
  Com_GblComCbk46 = TRUE;
}/* End Rte_COMCbk_s46 */

/*******************************************************************************
**                     TestRte_COMCbk_s46()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s46(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk46 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk46 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk46 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s46 */

/*******************************************************************************
**                     Rte_COMCbk_s47()                                       **
*******************************************************************************/
void Rte_COMCbk_s47(void)
{
  Com_GblComCbk47 = TRUE;
}/* End Rte_COMCbk_s47 */

/*******************************************************************************
**                     TestRte_COMCbk_s47()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s47(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk47 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk47 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk47 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s47 */

/*******************************************************************************
**                     Rte_COMCbk_s48()                                       **
*******************************************************************************/
void Rte_COMCbk_s48(void)
{
  Com_GblComCbk48 = TRUE;
}/* End Rte_COMCbk_s48 */

/*******************************************************************************
**                     TestRte_COMCbk_s48()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s48(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk48 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk48 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk48 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s48 */

/*******************************************************************************
**                     Rte_COMCbk_s49()                                       **
*******************************************************************************/
void Rte_COMCbk_s49(void)
{
  Com_GblComCbk49 = TRUE;
}/* End Rte_COMCbk_s49 */

/*******************************************************************************
**                     TestRte_COMCbk_s49()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s49(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk49 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk49 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk49 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s49 */

/*******************************************************************************
**                     Rte_COMCbk_s50()                                       **
*******************************************************************************/
void Rte_COMCbk_s50(void)
{
  Com_GblComCbk50 = TRUE;
}/* End Rte_COMCbk_s50 */

/*******************************************************************************
**                     TestRte_COMCbk_s50()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s50(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk50 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk50 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk50 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s50 */

/*******************************************************************************
**                     Rte_COMCbk_s51()                                       **
*******************************************************************************/
void Rte_COMCbk_s51(void)
{
  Com_GblComCbk51 = TRUE;
}/* End Rte_COMCbk_s51 */

/*******************************************************************************
**                     TestRte_COMCbk_s51()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s51(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk51 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk51 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk51 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s51 */

/*******************************************************************************
**                     Rte_COMCbk_s52()                                       **
*******************************************************************************/
void Rte_COMCbk_s52(void)
{
  Com_GblComCbk52 = TRUE;
}/* End Rte_COMCbk_s52 */

/*******************************************************************************
**                     TestRte_COMCbk_s52()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s52(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk52 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk52 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk52 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s52 */

/*******************************************************************************
**                     Rte_COMCbk_s53()                                       **
*******************************************************************************/
void Rte_COMCbk_s53(void)
{
  Com_GblComCbk53 = TRUE;
}/* End Rte_COMCbk_s53 */

/*******************************************************************************
**                     TestRte_COMCbk_s53()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s53(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk53 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk53 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk53 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s53 */

/*******************************************************************************
**                     Rte_COMCbk_s54()                                       **
*******************************************************************************/
void Rte_COMCbk_s54(void)
{
  Com_GblComCbk54 = TRUE;
}/* End Rte_COMCbk_s54 */

/*******************************************************************************
**                     TestRte_COMCbk_s54()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s54(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk54 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk54 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk54 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s54 */

/*******************************************************************************
**                     Rte_COMCbk_s55()                                       **
*******************************************************************************/
void Rte_COMCbk_s55(void)
{
  Com_GblComCbk55 = TRUE;
}/* End Rte_COMCbk_s55 */

/*******************************************************************************
**                     TestRte_COMCbk_s55()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s55(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk55 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk55 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk55 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s55 */

/*******************************************************************************
**                     Rte_COMCbk_s56()                                       **
*******************************************************************************/
void Rte_COMCbk_s56(void)
{
  Com_GblComCbk56 = TRUE;
}/* End Rte_COMCbk_s56 */

/*******************************************************************************
**                     TestRte_COMCbk_s56()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s56(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk56 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk56 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk56 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s56 */

/*******************************************************************************
**                     Rte_COMCbk_s57()                                       **
*******************************************************************************/
void Rte_COMCbk_s57(void)
{
  Com_GblComCbk57 = TRUE;
}/* End Rte_COMCbk_s57 */

/*******************************************************************************
**                     TestRte_COMCbk_s57()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s57(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk57 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk57 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk57 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s57 */

/*******************************************************************************
**                     Rte_COMCbk_s58()                                       **
*******************************************************************************/
void Rte_COMCbk_s58(void)
{
  Com_GblComCbk58 = TRUE;
}/* End Rte_COMCbk_s58 */

/*******************************************************************************
**                     TestRte_COMCbk_s58()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s58(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk58 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk58 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk58 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s58 */

/*******************************************************************************
**                     Rte_COMCbk_s59()                                       **
*******************************************************************************/
void Rte_COMCbk_s59(void)
{
  Com_GblComCbk59 = TRUE;
}/* End Rte_COMCbk_s59 */

/*******************************************************************************
**                     TestRte_COMCbk_s59()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s59(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk59 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk59 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk59 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s59 */

/*******************************************************************************
**                     Rte_COMCbk_s60()                                       **
*******************************************************************************/
void Rte_COMCbk_s60(void)
{
  Com_GblComCbk60 = TRUE;
}/* End Rte_COMCbk_s60 */

/*******************************************************************************
**                     TestRte_COMCbk_s60()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s60(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk60 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk60 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk60 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s60 */

/*******************************************************************************
**                     Rte_COMCbk_s61()                                       **
*******************************************************************************/
void Rte_COMCbk_s61(void)
{
  Com_GblComCbk61 = TRUE;
}/* End Rte_COMCbk_s61 */

/*******************************************************************************
**                     TestRte_COMCbk_s61()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s61(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk61 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk61 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk61 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s61 */

/*******************************************************************************
**                     Rte_COMCbk_s62()                                       **
*******************************************************************************/
void Rte_COMCbk_s62(void)
{
  Com_GblComCbk62 = TRUE;
}/* End Rte_COMCbk_s62 */

/*******************************************************************************
**                     TestRte_COMCbk_s62()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_s62(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk62 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk62 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk62 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s62 */

/*******************************************************************************
**                     Rte_COMCbk_s63()                                       **
*******************************************************************************/
void Rte_COMCbk_s63(void)
{
  Com_GblComCbk63 = TRUE;
}/* End Rte_COMCbk_s63 */

/*******************************************************************************
**                     Rte_COMCbk_sg1()                                       **
*******************************************************************************/
void Rte_COMCbk_sg1(void)
{
  Com_GblComCbkSg1 = TRUE;
}/* End Rte_COMCbk_sg1 */

/*******************************************************************************
**                     TestRte_COMCbk_sg1()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_sg1(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbkSg1 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbkSg1 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbkSg1 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_sg1 */

/*******************************************************************************
**                     Rte_COMCbk_sg2()                                       **
*******************************************************************************/
void Rte_COMCbk_sg2(void)
{
  Com_GblComCbkSg2 = TRUE;
}/* End Rte_COMCbk_sg2 */
/*******************************************************************************
**                     TestRte_COMCbk_sg2()                                   **
*******************************************************************************/
boolean TestRte_COMCbk_sg2(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbkSg2 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbkSg2 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbkSg2 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_sg2 */

/*******************************************************************************
**                     Rte_COMCbk_sg10()                                      **
*******************************************************************************/
void Rte_COMCbk_sg10(void)
{
  Com_GblComCbkSg10 = TRUE;
}/* End Rte_COMCbk_sg10 */

/*******************************************************************************
**                    Rte_COMCbkInv_sg3()                                     **
*******************************************************************************/
void Rte_COMCbkInv_sg3(void)
{
  Com_GblCbkInvSg3 = TRUE;
}/* End Rte_COMCbkInv_sg3 */

/*******************************************************************************
**                     TestRte_COMCbkInv_sg3()                                **
*******************************************************************************/
boolean TestRte_COMCbkInv_sg3(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblCbkInvSg3 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblCbkInvSg3 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblCbkInvSg3 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkInv_sg3 */

/*******************************************************************************
**                    Rte_COMCbkInv_sg4()                                     **
*******************************************************************************/
void Rte_COMCbkInv_sg4(void)
{
  Com_GblCbkInvSg4 = TRUE;
}/* End Rte_COMCbkInv_sg4 */

/*******************************************************************************
**                     TestRte_COMCbkInv_sg4()                                **
*******************************************************************************/
boolean TestRte_COMCbkInv_sg4(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblCbkInvSg4 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblCbkInvSg4 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblCbkInvSg4 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkInv_sg4 */

/*******************************************************************************
**                    Rte_COMCbkInv_sg5()                                     **
*******************************************************************************/
void Rte_COMCbkInv_sg5(void)
{
  Com_GblCbkInvSg5 = TRUE;
}/* End Rte_COMCbkInv_sg5 */

/*******************************************************************************
**                     TestRte_COMCbkInv_sg5()                                **
*******************************************************************************/
boolean TestRte_COMCbkInv_sg5(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblCbkInvSg5 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblCbkInvSg5 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblCbkInvSg5 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkInv_sg5 */

/*******************************************************************************
**                    Rte_COMCbkInv_sg6()                                     **
*******************************************************************************/
void Rte_COMCbkInv_sg6(void)
{
  Com_GblCbkInvSg6 = TRUE;
}/* End Rte_COMCbkInv_sg6 */

/*******************************************************************************
**                     TestRte_COMCbkInv_sg6()                                **
*******************************************************************************/
boolean TestRte_COMCbkInv_sg6(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblCbkInvSg6 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblCbkInvSg6 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblCbkInvSg6 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkInv_sg6 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s1()                                  **
*******************************************************************************/
void Rte_COMCbkRxTOut_s1(void)
{
  Com_GblRxTOutS1 = TRUE;
  if(Com_GblCbkInvS1 == TRUE)
  {
    GucSeqCount++;
  }
}/* End Rte_COMCbkRxTOut_s1 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s1()                              **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s1(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS1 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS1 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }

    case S_VALIDATE_SEQ:
    {
      if((GucSeqCount == 2) && (Com_GblRxTOutS1 == TRUE))
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS1 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s1 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s2()                                  **
*******************************************************************************/
void Rte_COMCbkRxTOut_s2(void)
{
  Com_GblRxTOutS2 = TRUE;
}/* End Rte_COMCbkRxTOut_s2 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s2()                              **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s2(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS2 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS2 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS2 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s2 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s3()                                  **
*******************************************************************************/
void Rte_COMCbkRxTOut_s3(void)
{
  Com_GblRxTOutS3 = TRUE;
}/* End Rte_COMCbkRxTOut_s3 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s3()                              **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s3(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS3 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS3 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS3 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s3 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s4()                                  **
*******************************************************************************/
void Rte_COMCbkRxTOut_s4(void)
{
  Com_GblRxTOutS4 = TRUE;
}/* End Rte_COMCbkRxTOut_s4 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s4()                              **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s4(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS4 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS4 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS4 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s4 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s5()                                  **
*******************************************************************************/
void Rte_COMCbkRxTOut_s5(void)
{
  Com_GblRxTOutS5 = TRUE;
}/* End Rte_COMCbkRxTOut_s5 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s5()                              **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s5(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS5 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS5 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS5 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s5 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s6()                                  **
*******************************************************************************/
void Rte_COMCbkRxTOut_s6(void)
{
  Com_GblRxTOutS6 = TRUE;
}/* End Rte_COMCbkRxTOut_s6 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s6()                              **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s6(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS6 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS6 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS6 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s6 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_sg2()                                 **
*******************************************************************************/
void Rte_COMCbkRxTOut_sg2(void)
{
  Com_GblRxTOutSg2 = TRUE;
}/* End Rte_COMCbkRxTOut_sg2 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_sg2()                             **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_sg2(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutSg2 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutSg2 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutSg2 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_sg2 */
/*******************************************************************************
**                     Rte_COMCbkRxTOut_sg3()                                 **
*******************************************************************************/
void Rte_COMCbkRxTOut_sg3(void)
{
  Com_GblRxTOutSg3 = TRUE;
}/* End Rte_COMCbkRxTOut_sg3 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_sg3()                             **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_sg3(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutSg3 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutSg3 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutSg3 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_sg3 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_sg5()                                 **
*******************************************************************************/
void Rte_COMCbkRxTOut_sg5(void)
{
  Com_GblRxTOutSg5 = TRUE;
}/* End Rte_COMCbkRxTOut_sg3 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_sg5()                             **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_sg5(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutSg5 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutSg5 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutSg5 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_sg5 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_sg6()                                 **
*******************************************************************************/
void Rte_COMCbkRxTOut_sg6(void)
{
  Com_GblRxTOutSg6 = TRUE;
}/* End Rte_COMCbkRxTOut_sg6 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_sg6()                             **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_sg6(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutSg6 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutSg6 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutSg6 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_sg6 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s34()                                 **
*******************************************************************************/
void Rte_COMCbkRxTOut_s34(void)
{
  Com_GblRxTOutS34 = TRUE;
}/* End Rte_COMCbkRxTOut_s34 */
/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s34()                             **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s34(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS34 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS34 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS34 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s34 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s35()                                 **
*******************************************************************************/
void Rte_COMCbkRxTOut_s35(void)
{
  Com_GblRxTOutS35 = TRUE;
}/* End Rte_COMCbkRxTOut_s35 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s35()                             **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s35(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS35 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS35 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS35 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s35 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s36()                                 **
*******************************************************************************/
void Rte_COMCbkRxTOut_s36(void)
{
  Com_GblRxTOutS36 = TRUE;
}/* End Rte_COMCbkRxTOut_s36 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s36()                             **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s36(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS36 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS36 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS36 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s36 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_sg1()                                 **
*******************************************************************************/
void Rte_COMCbkRxTOut_sg1(void)
{
  Com_GblRxTOutSg1 = TRUE;
  if(Com_GblCbkInvSg1 == TRUE)
  {
    GucSeqCount++;
  }
}/* End Rte_COMCbkRxTOut_sg1 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_sg1()                             **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_sg1(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutSg1 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutSg1 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    case S_VALIDATE_SEQ:
    {
      if((GucSeqCount == 2) && (Com_GblRxTOutSg1 == TRUE))
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutSg1 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_sg1 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s31()                                 **
*******************************************************************************/
void Rte_COMCbkRxTOut_s31(void)
{
  Com_GblRxTOutS31 = TRUE;
}/* End Rte_COMCbkRxTOut_s31 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s31()                             **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s31(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS31 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS31 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS31 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s31 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s32()                                 **
*******************************************************************************/
void Rte_COMCbkRxTOut_s32(void)
{
  Com_GblRxTOutS32 = TRUE;
}/* End Rte_COMCbkRxTOut_s32 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s32()                             **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s32(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS32 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS32 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS32 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s32 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s33()                                 **
*******************************************************************************/
void Rte_COMCbkRxTOut_s33(void)
{
  Com_GblRxTOutS33 = TRUE;
}/* End Rte_COMCbkRxTOut_s33 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s33()                             **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s33(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS33 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS33 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS33 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s33 */

/*******************************************************************************
**                    Rte_COMCbkInv_s1()                                      **
*******************************************************************************/
void Rte_COMCbkInv_s1(void)
{
  Com_GblCbkInvS1 = TRUE;
  if(Com_GblRxTOutS1 == FALSE)
  {
    GucSeqCount++;
  }
}/* End Rte_COMCbkInv_s1 */

/*******************************************************************************
**                     TestRte_COMCbkInv_s1()                                 **
*******************************************************************************/
boolean TestRte_COMCbkInv_s1(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblCbkInvS1 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblCbkInvS1 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }

    case S_VALIDATE_SEQ:
    {
      if((GucSeqCount == 2) && (Com_GblCbkInvS1 == TRUE))
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblCbkInvS1 = FALSE;
  return(LblRetVal);
} /* End TestRte_ComCbkInv_s1 */

/*******************************************************************************
**                     Rte_COMCbkInv_s17()                                    **
*******************************************************************************/
void Rte_COMCbkInv_s17(void)
{
  Com_GblCbkInvS17 = TRUE;
}/* End Rte_COMCbkInv_s17 */

/*******************************************************************************
**                     Rte_COMCbkInv_s11()                                    **
*******************************************************************************/
void Rte_COMCbkInv_s11(void)
{
  Com_GblCbkInvS11 = TRUE;
}/* End Rte_COMCbkInv_s11 */

/*******************************************************************************
**                     Rte_COMCbkInv_s21()                                    **
*******************************************************************************/
void Rte_COMCbkInv_s21(void)
{
  Com_GblCbkInvS21 = TRUE;
}/* End Rte_COMCbkInv_s21 */

/*******************************************************************************
**                     Rte_COMCbkInv_s15()                                    **
*******************************************************************************/
void Rte_COMCbkInv_s15(void)
{
  Com_GblCbkInvS15 = TRUE;
}/* End Rte_COMCbkInv_s15 */

/*******************************************************************************
**                     Rte_COMCbkInv_s19()                                    **
*******************************************************************************/
void Rte_COMCbkInv_s19(void)
{
  Com_GblCbkInvS19 = TRUE;
}/* End Rte_COMCbkInv_s19 */

/*******************************************************************************
**                     Rte_COMCbkInv_s63()                                    **
*******************************************************************************/
void Rte_COMCbkInv_s63(void)
{
  Com_GblCbkInvS63 = TRUE;
}/* End Rte_COMCbkInv_s63 */

/*******************************************************************************
**                    Rte_COMCbkInv_sg1()                                     **
*******************************************************************************/
void Rte_COMCbkInv_sg1(void)
{
  Com_GblCbkInvSg1 = TRUE;
  if(Com_GblRxTOutSg1 == FALSE)
  {
    GucSeqCount++;
  }
}/* End Rte_COMCbkInv_sg1 */

/*******************************************************************************
**                     TestRte_COMCbkInv_sg1()                                **
*******************************************************************************/
boolean TestRte_COMCbkInv_sg1(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblCbkInvSg1 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblCbkInvSg1 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }

    case S_VALIDATE_SEQ:
    {
      if((GucSeqCount == 2) && (Com_GblCbkInvSg1 == TRUE))
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblCbkInvSg1 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkInv_sg1 */

/*******************************************************************************
**                     Rte_COMCbkTAck_s2()                                    **
*******************************************************************************/
void Rte_COMCbkTAck_s2(void)
{
  Com_GblTACks2 = TRUE;
}/* End Rte_COMCbkTAck_s2 */

/*******************************************************************************
**                     TestRte_COMCbkTAck_s2()                                **
*******************************************************************************/
boolean TestRte_COMCbkTAck_s2(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTACks2 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTACks2 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTACks2 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTAck_s2 */

/*******************************************************************************
**                     Rte_COMCbkTAck_sg1()                                   **
*******************************************************************************/
void Rte_COMCbkTAck_sg1(void)
{
  Com_GblTACkSg1 = TRUE;
}/* End Rte_COMCbkTAck_sg1 */

/*******************************************************************************
**                     TestRte_COMCbkTAck_sg1()                               **
*******************************************************************************/
boolean TestRte_COMCbkTAck_sg1(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTACkSg1 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTACkSg1 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTACkSg1 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTAck_sg1 */

/*******************************************************************************
**                     Rte_COMCbk_s1()                                        **
*******************************************************************************/
void Rte_COMCbk_s1(void)
{
  Com_GblComCbk1 = TRUE;
}/* End Rte_COMCbk_s1 */

/*******************************************************************************
**                     TestRte_COMCbk_s1()                                    **
*******************************************************************************/
boolean TestRte_COMCbk_s1(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk1 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk1 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk1 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s1 */

/*******************************************************************************
**                     Rte_COMCbk_s4()                                        **
*******************************************************************************/
void Rte_COMCbk_s4(void)
{
  Com_GblComCbk4 = TRUE;
}/* End Rte_COMCbk_s4 */

/*******************************************************************************
**                     TestRte_COMCbk_s4()                                    **
*******************************************************************************/
boolean TestRte_COMCbk_s4(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk1 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk1 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk4 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s4 */

/*******************************************************************************
**                     Rte_COMCbkTAck_s1()                                    **
*******************************************************************************/
void Rte_COMCbkTAck_s1(void)
{
  Com_GblTACks1 = TRUE;
}/* End Rte_COMCbkTAck_s1 */

/*******************************************************************************
**                     TestRte_COMCbkTAck_s1()                                **
*******************************************************************************/
boolean TestRte_COMCbkTAck_s1(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTACks1 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTACks1 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTACks1 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTAck_s1 */

/*******************************************************************************
**                     Rte_COMCbkTAck_sg2()                                   **
*******************************************************************************/
void Rte_COMCbkTAck_sg2(void)
{
  Com_GblTACkSg2 = TRUE;
}/* End Rte_COMCbkTAck_sg2 */

/*******************************************************************************
**                     TestRte_COMCbkTAck_sg2()                               **
*******************************************************************************/
boolean TestRte_COMCbkTAck_sg2(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTACkSg2 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTACkSg2 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTACkSg2 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTAck_sg2 */

/*******************************************************************************
**                     Rte_COMCbkTAck_sg3()                                   **
*******************************************************************************/
void Rte_COMCbkTAck_sg3(void)
{
  Com_GblTACkSg3 = TRUE;
}/* End Rte_COMCbkTAck_sg3 */

/*******************************************************************************
**                     TestRte_COMCbkTAck_sg3()                               **
*******************************************************************************/
boolean TestRte_COMCbkTAck_sg3(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTACkSg3 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTACkSg3 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTACkSg3 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTAck_sg3 */

/*******************************************************************************
**                     Rte_COMCbkTAck_sg1()                                   **
*******************************************************************************/
void Rte_COMCbkTAck_sg4(void)
{
  Com_GblTACkSg4 = TRUE;
}/* End Rte_COMCbkTAck_sg4 */

/*******************************************************************************
**                     TestRte_COMCbkTAck_sg4()                               **
*******************************************************************************/
boolean TestRte_COMCbkTAck_sg4(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTACkSg4 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTACkSg4 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTACkSg4 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTAck_sg4 */

/*******************************************************************************
**                     Rte_COMCbkTAck_sg5()                                   **
*******************************************************************************/
void Rte_COMCbkTAck_sg5(void)
{
  Com_GblTACkSg5 = TRUE;
}/* End Rte_COMCbkTAck_sg5 */

/*******************************************************************************
**                     TestRte_COMCbkTAck_sg5()                               **
*******************************************************************************/
boolean TestRte_COMCbkTAck_sg5(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTACkSg5 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTACkSg5 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTACkSg5 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTAck_sg5 */

/*******************************************************************************
**                     Rte_COMCbk_s2()                                        **
*******************************************************************************/
void Rte_COMCbk_s2(void)
{
  Com_GblComCbk2 = TRUE;
}/* End Rte_COMCbk_s2 */

/*******************************************************************************
**                     TestRte_COMCbk_s2()                                    **
*******************************************************************************/
boolean TestRte_COMCbk_s2(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblComCbk2 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblComCbk2 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblComCbk2 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbk_s2 */

/*******************************************************************************
**                     Rte_COMCbkTxTOut_s3()                                  **
*******************************************************************************/
void Rte_COMCbkTxTOut_s3(void)
{
  Com_GblTxTOutS3 = TRUE;
}/* End Rte_COMCbkTxTOut_s3 */

/*******************************************************************************
**                     TestRte_COMCbkTxTOut_s3()                              **
*******************************************************************************/
boolean TestRte_COMCbkTxTOut_s3(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTxTOutS3 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTxTOutS3 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTxTOutS3 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTxTOut_s3 */

/*******************************************************************************
**                     Rte_COMCbkTxTOut_sg2()                                 **
*******************************************************************************/
void Rte_COMCbkTxTOut_sg2(void)
{
  Com_GblTxTOutSg2 = TRUE;
}/* End Rte_COMCbkTxTOut_sg2 */

/*******************************************************************************
**                     TestRte_COMCbkTxTOut_sg2()                             **
*******************************************************************************/
boolean TestRte_COMCbkTxTOut_sg2(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTxTOutSg2 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTxTOutSg2 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTxTOutSg2 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTxTOut_sg2 */

/*******************************************************************************
**                     Rte_COMCbkTxTOut_s1()                                  **
*******************************************************************************/
void Rte_COMCbkTxTOut_s1(void)
{
  Com_GblTxTOutS1 = TRUE;
}/* End Rte_COMCbkTxTOut_s1 */

/*******************************************************************************
**                     TestRte_COMCbkTxTOut_s1()                              **
*******************************************************************************/
boolean TestRte_COMCbkTxTOut_s1(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTxTOutS1 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTxTOutS1 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTxTOutS1 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTxTOut_s1 */

/*******************************************************************************
**                     Rte_COMCbkTxTOut_s2()                                  **
*******************************************************************************/
void Rte_COMCbkTxTOut_s2(void)
{
  Com_GblTxTOutS2 = TRUE;
}/* End Rte_COMCbkTxTOut_s2 */

/*******************************************************************************
**                     TestRte_COMCbkTxTOut_s2()                              **
*******************************************************************************/
boolean TestRte_COMCbkTxTOut_s2(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTxTOutS2 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTxTOutS2 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTxTOutS2 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTxTOut_s2 */

/*******************************************************************************
**                     Rte_COMCbkTxTOut_sg1()                                 **
*******************************************************************************/
void Rte_COMCbkTxTOut_sg1(void)
{
  Com_GblTxTOutSg1 = TRUE;
}/* End Rte_COMCbkTxTOut_sg1 */

/*******************************************************************************
**                     TestRte_COMCbkTxTOut_sg1()                             **
*******************************************************************************/
boolean TestRte_COMCbkTxTOut_sg1(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTxTOutSg1 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTxTOutSg1 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTxTOutSg1 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkTxTOut_sg1 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_s21()                                 **
*******************************************************************************/
void Rte_COMCbkRxTOut_s21(void)
{
  Com_GblRxTOutS21 = TRUE;
}/* End Rte_COMCbkRxTOut_s21 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_s21()                             **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_s21(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutS21 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutS21 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutS21 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_s21 */

/*******************************************************************************
**                     Rte_COMCbkRxTOut_sg8()                                 **
*******************************************************************************/
void Rte_COMCbkRxTOut_sg8(void)
{
  Com_GblRxTOutSg8 = TRUE;
}/* End Rte_COMCbkRxTOut_sg8 */

/*******************************************************************************
**                     TestRte_COMCbkRxTOut_sg8()                             **
*******************************************************************************/
boolean TestRte_COMCbkRxTOut_sg8(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblRxTOutSg8 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblRxTOutSg8 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblRxTOutSg8 = FALSE;
  return(LblRetVal);
} /* End TestRte_COMCbkRxTOut_sg8 */

/*******************************************************************************
**                     Rte_ComCbkTErr_s4()                                    **
*******************************************************************************/
void Rte_ComCbkTErr_s4(void)
{
  Com_GblTErrS4 = TRUE;
}/* End Rte_ComCbkTErr_s4 */

/*******************************************************************************
**                     TestRte_ComCbkTErr_s4()                                **
*******************************************************************************/
boolean TestRte_ComCbkTErr_s4(App_DataValidateType LenDataValidate)
{
  boolean LblRetVal;

  LblRetVal = FALSE;

  switch(LenDataValidate)
  {
    /* Case to check CallBack function is invoked */
    case S_VALIDATE:
    {
      if(Com_GblTErrS4 == TRUE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    /* Case to check CallBack function is not invoked */
    case S_NOT_INVOKED:
    {
      if(Com_GblTErrS4 == FALSE)
      {
        LblRetVal = TRUE;
      }
      break;
    }
    default:
    {
      LblRetVal = FALSE;
    }
  }

  /* Reset Global variable */
  Com_GblTErrS4 = FALSE;
  return(LblRetVal);
} /* End TestRte_ComCbkTErr_s4 */
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
void App_Com_CbkCounterErr_RxIpdu_4(PduIdType ComPduId, uint8 ExpectedCounter,
  uint8 ReceivedCounter)
{
  GddActComPduId = ComPduId;
  GucActExpCount = ExpectedCounter;
  GucActRecCount = ReceivedCounter;
  GucSWCCbkCount++;
}

boolean TestApp_Com_CbkCounterErr_RxIpdu_4(App_DataValidateType LddLabel,
  PduIdType LddComPduId, uint8 LucExpCount, uint8 LucExpRecCount)
{
  boolean LblRetVal;

  
  LblRetVal = STEP_FAILED;

  switch(LddLabel)
  {
    case S_VALIDATE:
    {
      if(GucSWCCbkCount == 0x01)
      {
        if((LddComPduId == GddActComPduId) &&
          (LucExpCount == GucActExpCount) &&
          (LucExpRecCount == GucActRecCount))
        {
          GucSWCCbkCount = 0;
          LblRetVal = STEP_PASSED;
        }
      }
      break;
    }
    case S_NOT_INVOKED:
    {
      if(GucSWCCbkCount == 0x00)
      {
        LblRetVal = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetVal = STEP_FAILED;
    }
  }
  return(LblRetVal);
}

void ComIpduCallout_Tx_SetVal(boolean RetVal)
{
  Com_CallOutRetVal = RetVal;
}

boolean ComIPduCallout_Tx_1(PduIdType Id, uint8* IpduData)
{
  GddCalloutId = Id;
  GddCalloutIpduData = IpduData;
  Com_CallOutCount++;
  return(Com_CallOutRetVal);
} /* End ComIPduCallout_Tx_1 */

boolean TestComIPduCallout_Tx_1(App_DataValidateType LddLabel,
  PduIdType LddComPduId, uint8* ExpPduInfo)
{
  boolean LblRetVal;

  LblRetVal = STEP_FAILED;


  switch(LddLabel)
  {
    case S_VALIDATE:
    {
      if((Com_CallOutCount == 0x01)&&(GddCalloutId == LddComPduId))
      {
        if(App_CompareVal(ExpPduInfo, GddCalloutIpduData, 0x08))
        {
          Com_CallOutCount = 0;
          LblRetVal = STEP_PASSED;
        }
        
      }
    }
    break;
    case S_NOT_INVOKED:
    {
      if(Com_CallOutCount == 0x00)
      {
        LblRetVal = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetVal = STEP_FAILED;
    }
  }
  return(LblRetVal);
} /* End TestComIPduCallout_Tx_1 */

void ComIpduCallout_Rx_SetVal(boolean RetVal)
{
  Com_CallOutRxRetVal = RetVal;
}

boolean ComIpduCallout_Rx_1(PduIdType Id, const uint8* IpduData)
{
  GddRxCalloutId = Id;
  GddRxCalloutIpduData = IpduData;
  Com_Rx_CallOutCount++;
  return(Com_CallOutRxRetVal);
} /* End ComIPduCallout_Rx_1 */

boolean TestComIPduCallout_Rx_1(App_DataValidateType LddLabel,
  PduIdType LddComPduId, const uint8* ExpPduInfo)
{
  boolean LblRetVal;

  LblRetVal = STEP_FAILED;


  switch(LddLabel)
  {
    case S_VALIDATE:
    {
      if((Com_Rx_CallOutCount == 0x01)&&(GddRxCalloutId == LddComPduId))
      {
        if(App_CompareVal((uint8*)ExpPduInfo, (uint8 *)GddRxCalloutIpduData, 0x08))
        {
          Com_Rx_CallOutCount = 0;
          LblRetVal = STEP_PASSED;
        }
        
      }
    }
    break;
    case S_NOT_INVOKED:
    {
      if(Com_Rx_CallOutCount == 0x00)
      {
        LblRetVal = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetVal = STEP_FAILED;
    }
  }
  return(LblRetVal);
} /* End TestComIPduCallout_Rx_1 */

boolean ComIPduCallout_Tx_2(PduIdType Id, uint8* IpduData)
{
  GddCalloutId = Id;
  GddCalloutIpduData = IpduData;
  Com_CallOutCount++;
  return(Com_CallOutRetVal);
} /* End ComIPduCallout_Tx_2 */

boolean TestComIPduCallout_Tx_2(App_DataValidateType LddLabel,
  PduIdType LddComPduId, uint8* ExpPduInfo)
{
  boolean LblRetVal;

  LblRetVal = STEP_FAILED;


  switch(LddLabel)
  {
    case S_VALIDATE:
    {
      if((Com_CallOutCount == 0x01)&&(GddCalloutId == LddComPduId))
      {
        if(App_CompareVal(ExpPduInfo, GddCalloutIpduData, 0x08))
        {
          Com_CallOutCount = 0;
          LblRetVal = STEP_PASSED;
        }
        
      }
    }
    break;
    case S_NOT_INVOKED:
    {
      if(Com_CallOutCount == 0x00)
      {
        LblRetVal = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetVal = STEP_FAILED;
    }
  }
  return(LblRetVal);
}/* End TestComIPduCallout_Tx_2 */

boolean ComIpduCallout_Tx_3(PduIdType Id, uint8* IpduData)
{
  GddCalloutId = Id;
  GddCalloutIpduData = IpduData;
  Com_CallOutCount++;
  return(Com_CallOutRetVal);
}

boolean TestComIpduCallout_Tx_3(App_DataValidateType LddLabel,
  PduIdType LddComPduId, uint8* ExpPduInfo)
{
  boolean LblRetVal;

  LblRetVal = STEP_FAILED;


  switch(LddLabel)
  {
    case S_VALIDATE:
    {
      if((Com_CallOutCount == 0x01)&&(GddCalloutId == LddComPduId))
      {
        if(App_CompareVal(ExpPduInfo, GddCalloutIpduData, 0x08))
        {
          Com_CallOutCount = 0;
          LblRetVal = STEP_PASSED;
        }
        
      }
    }
    break;
    case S_NOT_INVOKED:
    {
      if(Com_CallOutCount == 0x00)
      {
        LblRetVal = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetVal = STEP_FAILED;
    }
  }
  return(LblRetVal);
}

boolean Com_Callout_ComIPdu_Tx_6(PduIdType Id, uint8* IpduData)
{
  GddCalloutId = Id;
  GddCalloutIpduData = IpduData;
  Com_CallOutCount++;
  return(Com_CallOutRetVal);
}

boolean TestCom_Callout_ComIPdu_Tx_6(App_DataValidateType LddLabel,
  PduIdType LddComPduId, uint8* ExpPduInfo)
{
  boolean LblRetVal;

  LblRetVal = STEP_FAILED;


  switch(LddLabel)
  {
    case S_VALIDATE:
    {
      if((Com_CallOutCount == 0x01)&&(GddCalloutId == LddComPduId))
      {
        if(App_CompareVal(ExpPduInfo, GddCalloutIpduData, 0x08))
        {
          Com_CallOutCount = 0;
          LblRetVal = STEP_PASSED;
        }
        
      }
    }
    break;
    case S_NOT_INVOKED:
    {
      if(Com_CallOutCount == 0x00)
      {
        LblRetVal = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetVal = STEP_FAILED;
    }
  }
  return(LblRetVal);
}



boolean Com_IpduCallout_ComIPdu_Tx_6(PduIdType Id, uint8* IpduData)
{
  GddCalloutId = Id;
  GddCalloutIpduData = IpduData;
  Com_CallOutCount6++;
  return(Com_CallOutRetVal);
}

boolean TestCom_IpduCallout_ComIPdu_Tx_6(App_DataValidateType LddLabel,
  PduIdType LddComPduId, uint8* ExpPduInfo)
{
  boolean LblRetVal;

  LblRetVal = STEP_FAILED;


  switch(LddLabel)
  {
    case S_VALIDATE:
    {
      if((Com_CallOutCount6 == 0x01)&&(GddCalloutId == LddComPduId))
      {
        if(App_CompareVal(ExpPduInfo, GddCalloutIpduData, 0x08))
        {
          Com_CallOutCount6 = 0;
          LblRetVal = STEP_PASSED;
        }
        
      }
    }
    break;
    case S_NOT_INVOKED:
    {
      if(Com_CallOutCount6 == 0x00)
      {
        LblRetVal = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetVal = STEP_FAILED;
    }
  }
  return(LblRetVal);
}

#endif /* #ifdef COM_MODULE_ACTIVE */

#ifdef BSWM_MODULE_ACTIVE

/*******************************************************************************
**                          Rte_Start()                                       **
*******************************************************************************/

Std_ReturnType Rte_Start(void)
{
	App_GucApiSeqCnt++;
	Rte_GucInitSeqCnt = App_GucApiSeqCnt;
	Rte_GucInitCnt++;
  return(RTE_E_OK);
}/* End Rte_Start() */

/*******************************************************************************
**                           TestRte_Start()                                  **
*******************************************************************************/
boolean TestRte_Start(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Rte_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Rte_GucInitCnt = 0;
      Rte_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(Rte_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Rte_GucInitCnt = 0;
      Rte_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Start() */

/*******************************************************************************
**                          Rte_Stop()                                        **
*******************************************************************************/

Std_ReturnType Rte_Stop(void)
{
	App_GucApiSeqCnt++;
	Rte_GucInitSeqCnt = App_GucApiSeqCnt;
	Rte_GucInitCnt++;
  return(RTE_E_OK);
}/* End Rte_Stop() */

/*******************************************************************************
**                           TestRte_Stop()                                 **
*******************************************************************************/
boolean TestRte_Stop(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Rte_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Rte_GucInitCnt = 0;
      Rte_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(Rte_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Rte_GucInitCnt = 0;
      Rte_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Stop() */


/*******************************************************************************
**          TestSetRte_Mode_Port1_AppModeRequestType()            **
*******************************************************************************/
void TestSetRte_Mode_Port1_AppModeRequestType(AppModeRequestType LddRetVal)
{
  Rte_GddCurrentActiveMode = LddRetVal;
}/* End TestSetRte_Mode_Port1_AppModeRequestType() */

/*******************************************************************************
**          Rte_Mode_modeNotificationPort0_currentMode                        **
*******************************************************************************/
AppModeRequestType Rte_Mode_modeNotificationPort0_currentMode(void)
{
  Rte_GucNotification_Port1_ModeDeclarationGroupProtoType1Count++;
  return(Rte_GddCurrentActiveMode);
}/* End Rte_Mode_modeNotificationPort0_currentMode() */


/*******************************************************************************
**       TestRte_Switch_Port0_ModeDeclarationGroupProtoType1()                **
*******************************************************************************/
boolean TestSetRte_Mode_modeNotificationPort0_currentMode(App_DataValidateType LucDataValidate,
AppModeRequestType LddExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Rte_GucNotification_Port1_ModeDeclarationGroupProtoType1Count != 0x00) &&
        (Rte_GddNewMode == LddExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }
      Rte_GucNotification_Port1_ModeDeclarationGroupProtoType1Count = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
    if(Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestRte_Switch_Port0_ModeDeclarationGroupProtoType1() */

/*******************************************************************************
**          Rte_Switch_Port0_ModeDeclarationGroupProtoType1                   **
*******************************************************************************/
Std_ReturnType Rte_Switch_modeSwitchPort0_currentMode(SwitchMode_Type NewMode)
{
  Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count++;
  Rte_GddNewMode = NewMode;
  return(Rte_GddPortRetValue);
}/* End Rte_Switch_Port1_ModeDeclarationGroupProtoType1() */

/*******************************************************************************
**          Rte_Switch_Port1_ModeDeclarationGroupProtoType1                   **
*******************************************************************************/
Std_ReturnType Rte_Switch_modeSwitchPort1_currentMode(SwitchMode_Type NewMode)
{
  Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count++;
  Rte_GddNewMode = NewMode;
  return(Rte_GddPortRetValue);
}/* End Rte_Switch_Port1_ModeDeclarationGroupProtoType1() */
/*******************************************************************************
**          Rte_Switch_Port2_ModeDeclarationGroupProtoType1                   **
*******************************************************************************/
Std_ReturnType Rte_Switch_modeSwitchPort2_currentMode(SwitchMode_Type NewMode)
{
  Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count++;
  Rte_GddNewMode = NewMode;
  return(Rte_GddPortRetValue);
}/* End Rte_Switch_Port2_ModeDeclarationGroupProtoType1() */
/*******************************************************************************
**          Rte_Switch_Port3_ModeDeclarationGroupProtoType1                   **
*******************************************************************************/
Std_ReturnType Rte_Switch_modeSwitchPort3_currentMode(SwitchMode_Type NewMode)
{
  Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count++;
  Rte_GddNewMode = NewMode;
  return(Rte_GddPortRetValue);
}/* End Rte_Switch_Port3_ModeDeclarationGroupProtoType1() */
/*******************************************************************************
**          Rte_Switch_Port4_ModeDeclarationGroupProtoType1                   **
*******************************************************************************/
Std_ReturnType Rte_Switch_modeSwitchPort4_currentMode(SwitchMode_Type NewMode)
{
  Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count++;
  Rte_GddNewMode = NewMode;
  return(Rte_GddPortRetValue);
}/* End Rte_Switch_Port4_ModeDeclarationGroupProtoType1() */
/*******************************************************************************
**          Rte_Switch_Port5_ModeDeclarationGroupProtoType1                   **
*******************************************************************************/
Std_ReturnType Rte_Switch_modeSwitchPort5_currentMode(SwitchMode_Type NewMode)
{
  Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count++;
  Rte_GddNewMode = NewMode;
  return(Rte_GddPortRetValue);
}/* End Rte_Switch_Port5_ModeDeclarationGroupProtoType1() */
/*******************************************************************************
**          Rte_Switch_Port6_ModeDeclarationGroupProtoType1                   **
*******************************************************************************/
Std_ReturnType Rte_Switch_modeSwitchPort6_currentMode(SwitchMode_Type NewMode)
{
  Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count++;
  Rte_GddNewMode = NewMode;
  return(Rte_GddPortRetValue);
}/* End Rte_Switch_Port6_ModeDeclarationGroupProtoType1() */
/*******************************************************************************
**          Rte_Switch_Port7_ModeDeclarationGroupProtoType1                   **
*******************************************************************************/
Std_ReturnType Rte_Switch_modeSwitchPort7_currentMode(SwitchMode_Type NewMode)
{
  Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count++;
  Rte_GddNewMode = NewMode;
  return(Rte_GddPortRetValue);
}/* End Rte_Switch_Port7_ModeDeclarationGroupProtoType1() */
/*******************************************************************************
**          Rte_Switch_Port8_ModeDeclarationGroupProtoType1                   **
*******************************************************************************/
Std_ReturnType Rte_Switch_modeSwitchPort8_currentMode(SwitchMode_Type NewMode)
{
  Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count++;
  Rte_GddNewMode = NewMode;
  return(Rte_GddPortRetValue);
}/* End Rte_Switch_Port8_ModeDeclarationGroupProtoType1() */
/*******************************************************************************
**          Rte_Switch_Port10_ModeDeclarationGroupProtoType1                   **
*******************************************************************************/
Std_ReturnType Rte_Switch_modeSwitchPort10_currentMode(SwitchMode_Type NewMode)
{
  Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count++;
  Rte_GddNewMode = NewMode;
  return(Rte_GddPortRetValue);
}/* End Rte_Switch_Port10_ModeDeclarationGroupProtoType1() */

/*******************************************************************************
**                      AppRte_SetBehavior_Switch()                           **
*******************************************************************************/
void AppRte_SetBehavior_Switch(Std_ReturnType LddSetRetVal)
{
  Rte_GddPortRetValue = LddSetRetVal;
}/* End AppRte_SetBehavior_Switch() */

/*******************************************************************************
**          Rte_Read_Port1_VariableDataPrototype1                             **
*******************************************************************************/
Std_ReturnType Rte_Read_modeRequestPort0_requestedMode(AppModeRequestType *NewMode)
{
	Rte_GucRead_Port1_VariableDataProtoType1Count++;
  *NewMode = Rte_GddRequestedMode; 
	return(RTE_E_OK);
}/* End Rte_Read_Port1_VariableDataPrototype1() */

/*******************************************************************************
**          TestSetRte_Read_modeRequestPort0_requestedMode()                  **
*******************************************************************************/
void TestSetRte_Read_modeRequestPort0_requestedMode(AppModeRequestType LddRetVal)
{
  Rte_GddRequestedMode = LddRetVal;
}/* End TestSetRte_Read_modeRequestPort0_requestedMode() */


/*******************************************************************************
**       TestRte_Switch_Port0_ModeDeclarationGroupProtoType1()                **
*******************************************************************************/
boolean TestRte_Read_modeRequestPort0_requestedMode(App_DataValidateType LucDataValidate,
AppModeRequestType LddExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Rte_GucRead_Port1_VariableDataProtoType1Count != 0x00) &&
        (Rte_GddNewMode == LddExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }
      Rte_GucRead_Port1_VariableDataProtoType1Count = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
    if(Rte_GucRead_Port1_VariableDataProtoType1Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestRte_Switch_Port0_ModeDeclarationGroupProtoType1() */

/*******************************************************************************
**       TestRte_Switch_Port0_ModeDeclarationGroupProtoType1()                **
*******************************************************************************/
boolean TestRte_Switch_modeSwitchPort0_currentMode(App_DataValidateType LucDataValidate,
SwitchMode_Type LddExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count != 0x00) &&
        (Rte_GddNewMode == LddExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }
      Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
    if(Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestRte_Switch_Port0_ModeDeclarationGroupProtoType1() */

/*******************************************************************************
**       TestRte_Switch_Port1_ModeDeclarationGroupProtoType1()                **
*******************************************************************************/
boolean TestRte_Switch_modeSwitchPort1_currentMode(App_DataValidateType LucDataValidate,
SwitchMode_Type LddExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count != 0x00) &&
        (Rte_GddNewMode == LddExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }
      Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
    if(Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestRte_Switch_Port1_ModeDeclarationGroupProtoType1() */
/*******************************************************************************
**       TestRte_Switch_Port2_ModeDeclarationGroupProtoType1()                **
*******************************************************************************/
boolean TestRte_Switch_modeSwitchPort2_currentMode(App_DataValidateType LucDataValidate,
SwitchMode_Type LddExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count != 0x00) &&
        (Rte_GddNewMode == LddExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }
      Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
    if(Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestRte_Switch_Port2_ModeDeclarationGroupProtoType1() */
/*******************************************************************************
**       TestRte_Switch_Port3_ModeDeclarationGroupProtoType1()                **
*******************************************************************************/
boolean TestRte_Switch_modeSwitchPort3_currentMode(App_DataValidateType LucDataValidate,
SwitchMode_Type LddExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count != 0x00) &&
        (Rte_GddNewMode == LddExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }
      Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
    if(Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestRte_Switch_Port3_ModeDeclarationGroupProtoType1() */
/*******************************************************************************
**       TestRte_Switch_Port4_ModeDeclarationGroupProtoType1()                **
*******************************************************************************/
boolean TestRte_Switch_modeSwitchPort4_currentMode(App_DataValidateType LucDataValidate,
SwitchMode_Type LddExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count != 0x00) &&
        (Rte_GddNewMode == LddExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }
      Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
    if(Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestRte_Switch_Port4_ModeDeclarationGroupProtoType1() */
/*******************************************************************************
**       TestRte_Switch_Port5_ModeDeclarationGroupProtoType1()                **
*******************************************************************************/
boolean TestRte_Switch_modeSwitchPort5_currentMode(App_DataValidateType LucDataValidate,
SwitchMode_Type LddExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count != 0x00) &&
        (Rte_GddNewMode == LddExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }
      Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
    if(Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestRte_Switch_Port5_ModeDeclarationGroupProtoType1() */
/*******************************************************************************
**       TestRte_Switch_Port6_ModeDeclarationGroupProtoType1()                **
*******************************************************************************/
boolean TestRte_Switch_modeSwitchPort6_currentMode(App_DataValidateType LucDataValidate,
SwitchMode_Type LddExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count != 0x00) &&
        (Rte_GddNewMode == LddExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }
      Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
    if(Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestRte_Switch_Port6_ModeDeclarationGroupProtoType1() */
/*******************************************************************************
**       TestRte_Switch_Port7_ModeDeclarationGroupProtoType1()                **
*******************************************************************************/
boolean TestRte_Switch_modeSwitchPort7_currentMode(App_DataValidateType LucDataValidate,
SwitchMode_Type LddExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count != 0x00) &&
        (Rte_GddNewMode == LddExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }
      Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
    if(Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestRte_Switch_Port7_ModeDeclarationGroupProtoType1() */
/*******************************************************************************
**       TestRte_Switch_Port8_ModeDeclarationGroupProtoType1()                **
*******************************************************************************/
boolean TestRte_Switch_modeSwitchPort8_currentMode(App_DataValidateType LucDataValidate,
SwitchMode_Type LddExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count != 0x00) &&
        (Rte_GddNewMode == LddExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }
      Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
    if(Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestRte_Switch_Port8_ModeDeclarationGroupProtoType1() */
/*******************************************************************************
**       TestRte_Switch_Port10_ModeDeclarationGroupProtoType1()                **
*******************************************************************************/
boolean TestRte_Switch_modeSwitchPort10_currentMode(App_DataValidateType LucDataValidate,
SwitchMode_Type LddExpNewMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count != 0x00) &&
        (Rte_GddNewMode == LddExpNewMode))
      {
        LblStepResult = APP_TC_PASSED;
      }
      Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
    if(Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestRte_Switch_Port10_ModeDeclarationGroupProtoType1() */

/*******************************************************************************
**          Rte_RestartPartition_1                                            **
*******************************************************************************/
Std_ReturnType Rte_RestartPartition_1(void)
{
  Rte_GucPartitionResetCount++;
  return(Rte_GddPortRetValue);
}


/*******************************************************************************
**       TestRte_RestartPartition_1()                                         **
*******************************************************************************/
boolean TestRte_RestartPartition_1(App_DataValidateType LucDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Rte_GucPartitionResetCount != 0x00) 
      {
        LblStepResult = APP_TC_PASSED;
      }
      Rte_GucPartitionResetCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
    if(Rte_GucPartitionResetCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestRte_RestartPartition_1() */

#endif /* #ifdef BSWM_MODULE_ACTIVE */


#ifdef DLT_MODULE_ACTIVE
/*******************************************************************************
**                      Rte_Call_PSC000_Dlt_SetLogLevel()                     **
*******************************************************************************/
Std_ReturnType Rte_Call_PSCN000_Dlt_SetLogLevel(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, Dlt_MessageLogLevelType loglevel)
{
  #ifndef TYPICAL_CONFIG
  Dlt_GaaSetVal0app_id[0] = app_id;
  Dlt_GaaSetVal0context_id[0] = context_id;
  Dlt_Gddloglevel = loglevel;
  #endif
  return(E_OK) ;
}/* End Rte_Call_PSC000_Dlt_SetLogLevel() */
/*******************************************************************************
**                       TestRte_Call_PSC000_Dlt_SetLogLevel()                **
*******************************************************************************/
boolean TestRte_Call_PSCN000_Dlt_SetLogLevel(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  Dlt_MessageLogLevelType Lddloglevel)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal0app_id[0] == Lddapp_id) && (Dlt_GaaSetVal0context_id[0] == Lddcontext_id) &&
        (Dlt_Gddloglevel = Lddloglevel))
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC000_Dlt_SetLogLevel() */
/*******************************************************************************
**                      Rte_Call_PSC000_Dlt_SetTraceStatus()                  **
*******************************************************************************/
Std_ReturnType Rte_Call_PSCN000_Dlt_SetTraceStatus(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, boolean new_trace_status)
{
  #ifndef TYPICAL_CONFIG
  Dlt_GaaSetVal0app_id[1] = app_id;
  Dlt_GaaSetVal0context_id[1] = context_id;
  Dlt_Gblnew_trace_status = new_trace_status;
  #endif
  return(E_OK);
}/* End Rte_Call_PSC000_Dlt_SetTraceStatus() */
/*******************************************************************************
**                       TestRte_Call_PSC000_Dlt_SetTraceStatus()             **
*******************************************************************************/
boolean TestRte_Call_PSCN000_Dlt_SetTraceStatus(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblnew_trace_status)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal0app_id[1] == Lddapp_id) && (Dlt_GaaSetVal0context_id[1] == Lddcontext_id) &&
        (Dlt_Gblnew_trace_status == Lblnew_trace_status))
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC000_Dlt_SetTraceStatus() */
/*******************************************************************************
**                      Rte_Call_PSC000_Dlt_SetVerboseMode()                  **
*******************************************************************************/
Std_ReturnType Rte_Call_VCN000_Dlt_SetVerboseMode(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, boolean is_verbose_mode)
{
  #ifndef TYPICAL_CONFIG
  Dlt_GaaSetVal0app_id[2] = app_id;
  Dlt_GaaSetVal0context_id[2] = context_id;
  Dlt_Gblis_verbose_mode = is_verbose_mode;
  #endif
  return(E_OK) ;
}/* End Rte_Call_PSC000_Dlt_SetVerboseMode() */
/*******************************************************************************
**                       TestRte_Call_PSC000_Dlt_SetVerboseMode()             **
*******************************************************************************/
boolean TestRte_Call_VCN000_Dlt_SetVerboseMode(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblis_verbose_mode)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal0app_id[2] == Lddapp_id) && (Dlt_GaaSetVal0context_id[2] == Lddcontext_id) &&
        (Dlt_Gblis_verbose_mode == Lblis_verbose_mode))
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      LblStepResult = STEP_PASSED;
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC000_Dlt_SetVerboseMode() */
/*******************************************************************************
**                      Rte_Call_PSC000_Dlt_InjectCall()                     **
*******************************************************************************/
Std_ReturnType Rte_Call_ICN000_Dlt_InjectCall(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, uint32 service_id, uint32 data_length,
  uint8* data)
{ 
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8* LpDataPtr;
  LpDataPtr = (uint8 *) data;
  Dlt_GaaSetVal0app_id[3] = app_id;
  Dlt_GaaSetVal0context_id[3] = context_id;
  Dlt_Gucservice_id = service_id;
  Dlt_Gucdata_length  = data_length;
  /* Copy the actual data into global array */
  for(LucDataIndex = 0; LucDataIndex < Dlt_Gucdata_length; LucDataIndex++)
  {
    Dlt_GaaInjectData[LucDataIndex] = *LpDataPtr;
    LpDataPtr++;
  }  
  #endif
  return(E_OK) ;
}/* End Rte_Call_PSC000_Dlt_InjectCall() */
/*******************************************************************************
**                       TestRte_Call_PSC000_Dlt_InjectCall()                 **
*******************************************************************************/
boolean TestRte_Call_ICN000_Dlt_InjectCall(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  uint32 Lucservice_id, uint32 Lucdata_length,uint8* data)
{
  boolean LblStepResult;
  uint8* LpExpdataptr;
  LpExpdataptr = (uint8 *)data;  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal0app_id[3] == Lddapp_id) && (Dlt_GaaSetVal0context_id[3] == Lddcontext_id) &&
        (Dlt_Gucservice_id == Lucservice_id) &&
        (Dlt_Gucdata_length = Lucdata_length))
      { 
        if(Dlt_Test_ValidateData(LpExpdataptr, &Dlt_GaaInjectData[0],
          Dlt_Gucdata_length))
        {
          LblStepResult = STEP_PASSED;
        }
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      LblStepResult = STEP_PASSED;
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC000_Dlt_InjectCall() */
/*******************************************************************************
**                      Rte_Call_PSC001_Dlt_SetLogLevel()                     **
*******************************************************************************/
Std_ReturnType Rte_Call_PSCN001_Dlt_SetLogLevel(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, Dlt_MessageLogLevelType loglevel)
{
  #ifndef TYPICAL_CONFIG
  Dlt_GaaSetVal1app_id[0] = app_id;
  Dlt_GaaSetVal1context_id[0] = context_id;
  Dlt_Gddloglevel = loglevel;
  #endif
  return(E_OK) ;
}/* End Rte_Call_PSC001_Dlt_SetLogLevel() */
/*******************************************************************************
**                       TestRte_Call_PSC001_Dlt_SetLogLevel()                **
*******************************************************************************/
boolean TestRte_Call_PSCN001_Dlt_SetLogLevel(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  Dlt_MessageLogLevelType Lddloglevel)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal1app_id[0] == Lddapp_id) && (Dlt_GaaSetVal1context_id[0] == Lddcontext_id) &&
        (Dlt_Gddloglevel = Lddloglevel))
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC001_Dlt_SetLogLevel() */
/*******************************************************************************
**                      Rte_Call_PSC001_Dlt_SetTraceStatus()                  **
*******************************************************************************/
Std_ReturnType Rte_Call_PSCN001_Dlt_SetTraceStatus(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, boolean new_trace_status)
{
  #ifndef TYPICAL_CONFIG
  Dlt_GaaSetVal1app_id[1] = app_id;
  Dlt_GaaSetVal1context_id[1] = context_id;
  Dlt_Gblnew_trace_status = new_trace_status;
  #endif
  return(E_OK);
}/* End Rte_Call_PSC001_Dlt_SetTraceStatus() */
/*******************************************************************************
**                       TestRte_Call_PSC001_Dlt_SetTraceStatus()             **
*******************************************************************************/
boolean TestRte_Call_PSCN001_Dlt_SetTraceStatus(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblnew_trace_status)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal1app_id[1] == Lddapp_id) && (Dlt_GaaSetVal1context_id[1] == Lddcontext_id) &&
        (Dlt_Gblnew_trace_status == Lblnew_trace_status))
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC001_Dlt_SetTraceStatus() */
/*******************************************************************************
**                      Rte_Call_PSC001_Dlt_SetVerboseMode()                  **
*******************************************************************************/
Std_ReturnType Rte_Call_VCN001_Dlt_SetVerboseMode(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, boolean is_verbose_mode)
{
  #ifndef TYPICAL_CONFIG
  Dlt_GaaSetVal1app_id[2] = app_id;
  Dlt_GaaSetVal1context_id[2] = context_id;
  Dlt_Gblis_verbose_mode = is_verbose_mode;
  #endif
  return(E_OK) ;
}/* End Rte_Call_PSC001_Dlt_SetVerboseMode() */
/*******************************************************************************
**                       TestRte_Call_PSC001_Dlt_SetVerboseMode()             **
*******************************************************************************/
boolean TestRte_Call_VCN001_Dlt_SetVerboseMode(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblis_verbose_mode)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal1app_id[2] == Lddapp_id) && (Dlt_GaaSetVal1context_id[2] == Lddcontext_id) &&
        (Dlt_Gblis_verbose_mode == Lblis_verbose_mode))
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC001_Dlt_SetVerboseMode() */
/*******************************************************************************
**                      Rte_Call_PSC001_Dlt_InjectCall()                     **
*******************************************************************************/
Std_ReturnType Rte_Call_ICN001_Dlt_InjectCall(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, uint32 service_id, uint32 data_length,
  uint8* data)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8* LpDataPtr;
  LpDataPtr = (uint8 *) data;
  Dlt_GaaSetVal1app_id[3] = app_id;
  Dlt_GaaSetVal1context_id[3] = context_id;
  Dlt_Gucservice_id = service_id;
  Dlt_Gucdata_length  = data_length;
  /* Copy the actual data into global array */
  for(LucDataIndex = 0; LucDataIndex < Dlt_Gucdata_length; LucDataIndex++)
  {
    Dlt_GaaInjectData[LucDataIndex] = *LpDataPtr;
    LpDataPtr++;
  }
  #endif
  return(E_OK);
}/* End Rte_Call_PSC001_Dlt_InjectCall() */
/*******************************************************************************
**                       TestRte_Call_PSC001_Dlt_InjectCall()                 **
*******************************************************************************/
boolean TestRte_Call_ICN001_Dlt_InjectCall(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  uint32 Lucservice_id, uint32 Lucdata_length,uint8* data)
{
  boolean LblStepResult;
  uint8* LpExpdataptr;
  LpExpdataptr = (uint8 *)data;  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal1app_id[3] == Lddapp_id) && (Dlt_GaaSetVal1context_id[3] == Lddcontext_id) &&
        (Dlt_Gucservice_id == Lucservice_id) &&
        (Dlt_Gucdata_length = Lucdata_length))
      { 
        if(Dlt_Test_ValidateData(LpExpdataptr, &Dlt_GaaInjectData[0],
          Dlt_Gucdata_length))
        {
          LblStepResult = STEP_PASSED;
        }
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC001_Dlt_InjectCall() */
/*******************************************************************************
**                      Rte_Call_PSC002_Dlt_SetLogLevel()                     **
*******************************************************************************/
Std_ReturnType Rte_Call_PSCN002_Dlt_SetLogLevel(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, Dlt_MessageLogLevelType loglevel)
{
  #ifndef TYPICAL_CONFIG
  Dlt_GaaSetVal2app_id[0] = app_id;
  Dlt_GaaSetVal2context_id[0] = context_id;
  Dlt_Gddloglevel = loglevel;
  #endif
  return(E_OK) ;
}/* End Rte_Call_PSC002_Dlt_SetLogLevel() */
/*******************************************************************************
**                       TestRte_Call_PSC002_Dlt_SetLogLevel()                **
*******************************************************************************/
boolean TestRte_Call_PSCN002_Dlt_SetLogLevel(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  Dlt_MessageLogLevelType Lddloglevel)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal2app_id[0] == Lddapp_id) && (Dlt_GaaSetVal2context_id[0] == Lddcontext_id) &&
        (Dlt_Gddloglevel == Lddloglevel))
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC002_Dlt_SetLogLevel() */
/*******************************************************************************
**                      Rte_Call_PSC002_Dlt_SetTraceStatus()                  **
*******************************************************************************/
Std_ReturnType Rte_Call_PSCN002_Dlt_SetTraceStatus(Dlt_ApplicationIDType 
  app_id, Dlt_ContextIDType context_id, boolean new_trace_status)
{
  #ifndef TYPICAL_CONFIG
  Dlt_GaaSetVal2app_id[1] = app_id;
  Dlt_GaaSetVal2context_id[1] = context_id;
  Dlt_Gblnew_trace_status = new_trace_status;
  #endif
  return(E_OK) ;
}/* End Rte_Call_PSC002_Dlt_SetTraceStatus() */
/*******************************************************************************
**                       TestRte_Call_PSC002_Dlt_SetTraceStatus()             **
*******************************************************************************/
boolean TestRte_Call_PSCN002_Dlt_SetTraceStatus(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblnew_trace_status)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal2app_id[1] == Lddapp_id) && (Dlt_GaaSetVal2context_id[1] == Lddcontext_id) &&
        (Dlt_Gblnew_trace_status == Lblnew_trace_status))
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC002_Dlt_SetTraceStatus() */
/*******************************************************************************
**                      Rte_Call_PSC002_Dlt_SetVerboseMode()                  **
*******************************************************************************/
Std_ReturnType Rte_Call_VCN002_Dlt_SetVerboseMode(Dlt_ApplicationIDType 
  app_id, Dlt_ContextIDType context_id, boolean is_verbose_mode)
{
  #ifndef TYPICAL_CONFIG
  Dlt_GaaSetVal2app_id[2] = app_id;
  Dlt_GaaSetVal2context_id[2] = context_id;
  Dlt_Gblis_verbose_mode = is_verbose_mode;
  #endif
  return(E_OK) ;
}/* End Rte_Call_PSC002_Dlt_SetVerboseMode() */
/*******************************************************************************
**                       TestRte_Call_PSC002_Dlt_SetVerboseMode()             **
*******************************************************************************/
boolean TestRte_Call_VCN002_Dlt_SetVerboseMode(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblis_verbose_mode)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal2app_id[2] == Lddapp_id) && 
        (Dlt_GaaSetVal2context_id[2] == Lddcontext_id) &&
        (Dlt_Gblis_verbose_mode == Lblis_verbose_mode))
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC002_Dlt_SetVerboseMode() */
/*******************************************************************************
**                      Rte_Call_PSC002_Dlt_InjectCall()                     **
*******************************************************************************/
Std_ReturnType Rte_Call_ICN002_Dlt_InjectCall(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, uint32 service_id, uint32 data_length,
  uint8* data)
{ 
  #ifndef TYPICAL_CONFIG
  uint8* LpDataPtr;
  uint8 LucDataIndex;
  LpDataPtr = (uint8 *) data;
  Dlt_GaaSetVal2app_id[3] = app_id;
  Dlt_GaaSetVal2context_id[3] = context_id;
  Dlt_Gucservice_id = service_id;
  Dlt_Gucdata_length  = data_length;
  /* Copy the actual data into global array */
  for(LucDataIndex = 0; LucDataIndex < Dlt_Gucdata_length; LucDataIndex++)
  {
    Dlt_GaaInjectData[LucDataIndex] = *LpDataPtr;
    LpDataPtr++;
  }
  #endif
  return(E_OK);
 }/* End Rte_Call_PSC002_Dlt_InjectCall() */
/*******************************************************************************
**                       TestRte_Call_PSC002_Dlt_InjectCall()                 **
*******************************************************************************/
boolean TestRte_Call_ICN002_Dlt_InjectCall(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  uint32 Lucservice_id, uint32 Lucdata_length,uint8* data)
{
  boolean LblStepResult;
  uint8* LpExpdataptr;
  LpExpdataptr = (uint8 *)data;  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal2app_id[3] == Lddapp_id) && (Dlt_GaaSetVal2context_id[3] == Lddcontext_id) &&
        (Dlt_Gucservice_id == Lucservice_id) &&
        (Dlt_Gucdata_length = Lucdata_length))
      { 
        if(Dlt_Test_ValidateData(LpExpdataptr, &Dlt_GaaInjectData[0],
          Dlt_Gucdata_length))
        {
          LblStepResult = STEP_PASSED;
        }
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC002_Dlt_InjectCall() */
/*******************************************************************************
**                      Rte_Call_PSC003_Dlt_SetLogLevel()                     **
*******************************************************************************/
Std_ReturnType Rte_Call_PSCN003_Dlt_SetLogLevel(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, Dlt_MessageLogLevelType loglevel)
{
  #ifndef TYPICAL_CONFIG
  Dlt_GaaSetVal3app_id[0] = app_id;
  Dlt_GaaSetVal3context_id[0] = context_id;
  Dlt_Gddloglevel = loglevel;
  #endif
  return(E_OK) ;
}/* End Rte_Call_PSC003_Dlt_SetLogLevel() */
/*******************************************************************************
**                       TestRte_Call_PSC003_Dlt_SetLogLevel()                **
*******************************************************************************/
boolean TestRte_Call_PSCN003_Dlt_SetLogLevel(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  Dlt_MessageLogLevelType Lddloglevel)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal3app_id[0] == Lddapp_id) && (Dlt_GaaSetVal3context_id[0] == Lddcontext_id) &&
        (Dlt_Gddloglevel == Lddloglevel))
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC003_Dlt_SetLogLevel() */
/*******************************************************************************
**                      Rte_Call_PSC003_Dlt_SetTraceStatus()                  **
*******************************************************************************/
Std_ReturnType Rte_Call_PSCN003_Dlt_SetTraceStatus(Dlt_ApplicationIDType 
  app_id, Dlt_ContextIDType context_id, boolean new_trace_status)
{
  #ifndef TYPICAL_CONFIG
  Dlt_GaaSetVal3app_id[1] = app_id;
  Dlt_GaaSetVal3context_id[1] = context_id;
  Dlt_Gblnew_trace_status = new_trace_status;
  #endif
  return(E_OK) ;
}/* End Rte_Call_PSC003_Dlt_SetTraceStatus() */
/*******************************************************************************
**                       TestRte_Call_PSC003_Dlt_SetTraceStatus()             **
*******************************************************************************/
boolean TestRte_Call_PSCN003_Dlt_SetTraceStatus(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblnew_trace_status)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal3app_id[1] == Lddapp_id) && (Dlt_GaaSetVal3context_id[1] == Lddcontext_id) &&
        (Dlt_Gblnew_trace_status == Lblnew_trace_status))
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC003_Dlt_SetTraceStatus() */
/*******************************************************************************
**                      Rte_Call_PSC003_Dlt_SetVerboseMode()                  **
*******************************************************************************/
Std_ReturnType Rte_Call_VCN003_Dlt_SetVerboseMode(Dlt_ApplicationIDType 
  app_id, Dlt_ContextIDType context_id, boolean is_verbose_mode)
{
  #ifndef TYPICAL_CONFIG
  Dlt_GaaSetVal3app_id[2] = app_id;
  Dlt_GaaSetVal3context_id[2] = context_id;
  Dlt_Gblis_verbose_mode = is_verbose_mode;
  #endif
  return(E_OK) ;
}/* End Rte_Call_PSC003_Dlt_SetVerboseMode() */
/*******************************************************************************
**                       TestRte_Call_PSC003_Dlt_SetVerboseMode()             **
*******************************************************************************/
boolean TestRte_Call_VCN003_Dlt_SetVerboseMode(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblis_verbose_mode)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal3app_id[2] == Lddapp_id) && (Dlt_GaaSetVal3context_id[2] == Lddcontext_id) &&
        (Dlt_Gblis_verbose_mode == Lblis_verbose_mode))
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC003_Dlt_SetVerboseMode() */
/*******************************************************************************
**                      Rte_Call_PSC003_Dlt_InjectCall()                     **
*******************************************************************************/
Std_ReturnType Rte_Call_ICN003_Dlt_InjectCall(Dlt_ApplicationIDType 
  app_id, Dlt_ContextIDType context_id, uint32 service_id, uint32 data_length, 
  uint8* data)
{ 
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8* LpDataPtr;
  LpDataPtr = (uint8 *) data;
  Dlt_GaaSetVal3app_id[3] = app_id;
  Dlt_GaaSetVal3context_id[3] = context_id;
  Dlt_Gucservice_id = service_id;
  Dlt_Gucdata_length  = data_length;
  /* Copy the actual data into global array */
  for(LucDataIndex = 0; LucDataIndex < Dlt_Gucdata_length; LucDataIndex++)
  {
    Dlt_GaaInjectData[LucDataIndex] = *LpDataPtr;
    LpDataPtr++;
  }
  #endif
  return(E_OK);
}/* End Rte_Call_PSC003_Dlt_InjectCall() */
/*******************************************************************************
**                       TestRte_Call_PSC003_Dlt_InjectCall()                 **
*******************************************************************************/
boolean TestRte_Call_ICN003_Dlt_InjectCall(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  uint32 Lucservice_id, uint32 Lucdata_length,uint8* data)
{
 boolean LblStepResult;
  uint8* LpExpdataptr;
  LpExpdataptr = (uint8 *)data;
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal3app_id[3] == Lddapp_id) && (Dlt_GaaSetVal3context_id[3] == Lddcontext_id) &&
        (Dlt_Gucservice_id == Lucservice_id) &&
        (Dlt_Gucdata_length = Lucdata_length))
      { 
        if(Dlt_Test_ValidateData(LpExpdataptr, &Dlt_GaaInjectData[0],
          Dlt_Gucdata_length))
        {
          LblStepResult = STEP_PASSED;
        }
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC003_Dlt_InjectCall() */
/*******************************************************************************
**                      Rte_Call_PSC004_Dlt_SetLogLevel()                     **
*******************************************************************************/
Std_ReturnType Rte_Call_PSCN004_Dlt_SetLogLevel(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, Dlt_MessageLogLevelType loglevel)
{
  #ifndef TYPICAL_CONFIG
  Dlt_GaaSetVal0app_id[0] = app_id;
  Dlt_GaaSetVal0context_id[0] = context_id;
  Dlt_Gddloglevel = loglevel;
  #endif
  return(E_OK) ;
}/* End Rte_Call_PSC004_Dlt_SetLogLevel() */
/*******************************************************************************
**                       TestRte_Call_PSC004_Dlt_SetLogLevel()                **
*******************************************************************************/
boolean TestRte_Call_PSCN004_Dlt_SetLogLevel(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  Dlt_MessageLogLevelType Lddloglevel)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal0app_id[0] == Lddapp_id) && (Dlt_GaaSetVal0context_id[0] == Lddcontext_id) &&
        (Dlt_Gddloglevel = Lddloglevel))
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC004_Dlt_SetLogLevel() */
/*******************************************************************************
**                      Rte_Call_PSC004_Dlt_SetTraceStatus()                  **
*******************************************************************************/
Std_ReturnType Rte_Call_PSCN004_Dlt_SetTraceStatus(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, boolean new_trace_status)
{
  #ifndef TYPICAL_CONFIG
  Dlt_GaaSetVal0app_id[1] = app_id;
  Dlt_GaaSetVal0context_id[1] = context_id;
  Dlt_Gblnew_trace_status = new_trace_status;
  #endif
  return(E_OK);
}/* End Rte_Call_PSC004_Dlt_SetTraceStatus() */
/*******************************************************************************
**                       TestRte_Call_PSC004_Dlt_SetTraceStatus()             **
*******************************************************************************/
boolean TestRte_Call_PSCN004_Dlt_SetTraceStatus(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblnew_trace_status)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal0app_id[1] == Lddapp_id) && (Dlt_GaaSetVal0context_id[1] == Lddcontext_id) &&
        (Dlt_Gblnew_trace_status == Lblnew_trace_status))
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC000_Dlt_SetTraceStatus() */
/*******************************************************************************
**                      Rte_Call_PSC004_Dlt_SetVerboseMode()                  **
*******************************************************************************/
Std_ReturnType Rte_Call_VCN004_Dlt_SetVerboseMode(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, boolean is_verbose_mode)
{
  #ifndef TYPICAL_CONFIG
  Dlt_GaaSetVal0app_id[2] = app_id;
  Dlt_GaaSetVal0context_id[2] = context_id;
  Dlt_Gblis_verbose_mode = is_verbose_mode;
  #endif
  return(E_OK) ;
}/* End Rte_Call_PSC004_Dlt_SetVerboseMode() */
/*******************************************************************************
**                       TestRte_Call_PSC004_Dlt_SetVerboseMode()             **
*******************************************************************************/
boolean TestRte_Call_VCN004_Dlt_SetVerboseMode(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  boolean Lblis_verbose_mode)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal0app_id[2] == Lddapp_id) && (Dlt_GaaSetVal0context_id[2] == Lddcontext_id) &&
        (Dlt_Gblis_verbose_mode == Lblis_verbose_mode))
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      LblStepResult = STEP_PASSED;
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC004_Dlt_SetVerboseMode() */
/*******************************************************************************
**                      Rte_Call_PSC004_Dlt_InjectCall()                     **
*******************************************************************************/
Std_ReturnType Rte_Call_ICN004_Dlt_InjectCall(Dlt_ApplicationIDType
  app_id, Dlt_ContextIDType context_id, uint32 service_id, uint32 data_length,
  uint8* data)
{ 
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8* LpDataPtr;
  LpDataPtr = (uint8 *) data;
  Dlt_GaaSetVal0app_id[3] = app_id;
  Dlt_GaaSetVal0context_id[3] = context_id;
  Dlt_Gucservice_id = service_id;
  Dlt_Gucdata_length  = data_length;
  /* Copy the actual data into global array */
  for(LucDataIndex = 0; LucDataIndex < Dlt_Gucdata_length; LucDataIndex++)
  {
    Dlt_GaaInjectData[LucDataIndex] = *LpDataPtr;
    LpDataPtr++;
  }  
  #endif
  return(E_OK) ;
}/* End Rte_Call_PSC004_Dlt_InjectCall() */
/*******************************************************************************
**                       TestRte_Call_PSC004_Dlt_InjectCall()                 **
*******************************************************************************/
boolean TestRte_Call_ICN004_Dlt_InjectCall(App_DataValidateType LucDataValidate,
  Dlt_ApplicationIDType Lddapp_id, Dlt_ContextIDType Lddcontext_id,
  uint32 Lucservice_id, uint32 Lucdata_length,uint8* data)
{
  boolean LblStepResult;
  uint8* LpExpdataptr;
  LpExpdataptr = (uint8 *)data;  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if((Dlt_GaaSetVal0app_id[3] == Lddapp_id) && (Dlt_GaaSetVal0context_id[3] == Lddcontext_id) &&
        (Dlt_Gucservice_id == Lucservice_id) &&
        (Dlt_Gucdata_length = Lucdata_length))
      { 
        if(Dlt_Test_ValidateData(LpExpdataptr, &Dlt_GaaInjectData[0],
          Dlt_Gucdata_length))
        {
          LblStepResult = STEP_PASSED;
        }
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      LblStepResult = STEP_PASSED;
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Call_PSC004_Dlt_InjectCall() */
/*******************************************************************************
**                       Dlt_Test_ValidateData()                              **
*******************************************************************************/
boolean Dlt_Test_ValidateData(uint8* LpExpData, uint8* LpActData,
  uint32 Lucdatalength)
{
  uint8 LucCount;
  boolean LblReturnValue;

  LblReturnValue = TRUE;
  LucCount = 0;

  while((LblReturnValue != FALSE) && (LucCount < Lucdatalength))
  {
    if(*LpActData != *LpExpData)
    {
      LblReturnValue = FALSE;
    }
    LpActData++;
    LpExpData++;
    LucCount++;
  }
  return(LblReturnValue);
}
/* End Dlt_Test_ValidateData()  */
#endif

#ifdef NVM_MODULE_ACTIVE
/*******************************************************************************
**                            SINGLE_BLOCK_CBK_2()                            **
*******************************************************************************/
Std_ReturnType SINGLE_BLOCK_CBK_2(uint8 ServiceId, NvM_RequestResultType JobResult)
{
  /* Load actual ServiceId and JobResult into Global variables */
  NvM_SingleBlockServiceId[NvM_GucSingleBlkCbkCount] = ServiceId;
  NvM_SingleBlockJobResult[NvM_GucSingleBlkCbkCount] = JobResult;

  /* Increment count variable to handle multiple invocations */
  if(NvM_GucSingleBlkCbkCount < NVM_ARRAY_SIZE)
  {
    NvM_GucSingleBlkCbkCount++;
  }
  return(E_OK);
} /* End SINGLE_BLOCK_CBK_2() */

/*******************************************************************************
**                            SINGLE_BLOCK_CBK_3()                            **
*******************************************************************************/
Std_ReturnType SINGLE_BLOCK_CBK_3(uint8 ServiceId, NvM_RequestResultType JobResult)
{
  /* Load actual ServiceId and JobResult into Global variables */
  NvM_SingleBlockServiceId[NvM_GucSingleBlkCbkCount] = ServiceId;
  NvM_SingleBlockJobResult[NvM_GucSingleBlkCbkCount] = JobResult;

  /* Increment count variable to handle multiple invocations */
  if(NvM_GucSingleBlkCbkCount < NVM_ARRAY_SIZE)
  {
    NvM_GucSingleBlkCbkCount++;
  }
  return(E_OK);
} /* End SINGLE_BLOCK_CBK_3() */

/*******************************************************************************
**                            SINGLE_BLOCK_CBK_4()                            **
*******************************************************************************/
Std_ReturnType SINGLE_BLOCK_CBK_4(uint8 ServiceId, NvM_RequestResultType JobResult)
{
  /* Load actual ServiceId and JobResult into Global variables */
  NvM_SingleBlockServiceId[NvM_GucSingleBlkCbkCount] = ServiceId;
  NvM_SingleBlockJobResult[NvM_GucSingleBlkCbkCount] = JobResult;

  /* Increment count variable to handle multiple invocations */
  if(NvM_GucSingleBlkCbkCount < NVM_ARRAY_SIZE)
  {
    NvM_GucSingleBlkCbkCount++;
  }
  return(E_OK);
} /* End SINGLE_BLOCK_CBK_4() */

/*******************************************************************************
**                            SINGLE_BLOCK_CBK_5()                            **
*******************************************************************************/
Std_ReturnType SINGLE_BLOCK_CBK_5(uint8 ServiceId, NvM_RequestResultType JobResult)
{
  /* Load actual ServiceId and JobResult into Global variables */
  NvM_SingleBlockServiceId[NvM_GucSingleBlkCbkCount] = ServiceId;
  NvM_SingleBlockJobResult[NvM_GucSingleBlkCbkCount] = JobResult;

  /* Increment count variable to handle multiple invocations */
  if(NvM_GucSingleBlkCbkCount < NVM_ARRAY_SIZE)
  {
    NvM_GucSingleBlkCbkCount++;
  }
  return(E_OK);
} /* End SINGLE_BLOCK_CBK_5() */

/*******************************************************************************
**                            SINGLE_BLOCK_CBK_6()                            **
*******************************************************************************/
Std_ReturnType SINGLE_BLOCK_CBK_6(uint8 ServiceId, NvM_RequestResultType JobResult)
{
  /* Load actual ServiceId and JobResult into Global variables */
  NvM_SingleBlockServiceId[NvM_GucSingleBlkCbkCount] = ServiceId;
  NvM_SingleBlockJobResult[NvM_GucSingleBlkCbkCount] = JobResult;

  /* Increment count variable to handle multiple invocations */
  if(NvM_GucSingleBlkCbkCount < NVM_ARRAY_SIZE)
  {
    NvM_GucSingleBlkCbkCount++;
  }
  return(E_OK);
} /* End SINGLE_BLOCK_CBK_6() */

/*******************************************************************************
**                            SINGLE_BLOCK_CBK_7()                            **
*******************************************************************************/
Std_ReturnType SINGLE_BLOCK_CBK_7(uint8 ServiceId, NvM_RequestResultType JobResult)
{
  /* Load actual ServiceId and JobResult into Global variables */
  NvM_SingleBlockServiceId[NvM_GucSingleBlkCbkCount] = ServiceId;
  NvM_SingleBlockJobResult[NvM_GucSingleBlkCbkCount] = JobResult;

  /* Increment count variable to handle multiple invocations */
  if(NvM_GucSingleBlkCbkCount < NVM_ARRAY_SIZE)
  {
    NvM_GucSingleBlkCbkCount++;
  }
  return(E_OK);
} /* End SINGLE_BLOCK_CBK_7() */

/*******************************************************************************
**                          Test_SINGLE_BLOCK_CBK()                           **
*******************************************************************************/
boolean Test_SINGLE_BLOCK_CBK(App_DataValidateType LucDataValidate,
  uint8 LucExpServiceId, NvM_RequestResultType LddExpJobResult)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle callback invocation with single occurance and to validate
     * parameters of the callback with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ControllerId and PduModeRequest */
      if((NvM_GucSingleBlkCbkCount == 0x01) &&
        (NvM_SingleBlockServiceId[0] == LucExpServiceId) &&
        (NvM_SingleBlockJobResult[0] == LddExpJobResult))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      NvM_GucSingleBlkCbkCount = 0;
      NvM_GucSingleBlkCbkCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < NvM_GucSingleBlkCbkCount; LucIndex++)
      {
        /* Validate ControllerId and PduModeRequest */
        if((NvM_SingleBlockServiceId[LucIndex] == LucExpServiceId) &&
          (NvM_SingleBlockJobResult[LucIndex] == LddExpJobResult))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = NvM_GucSingleBlkCbkCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      NvM_GucSingleBlkCbkCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(NvM_GucSingleBlkCbkCheckCount == NvM_GucSingleBlkCbkCount)
      {
        NvM_GucSingleBlkCbkCount = 0;
        NvM_GucSingleBlkCbkCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(NvM_GucSingleBlkCbkCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End Test_SINGLE_BLOCK_CBK() */

/*******************************************************************************
**                    READ_RAM_BLOCK_FROM_NVM_CBK_3()                         **
*******************************************************************************/
Std_ReturnType READ_RAM_BLOCK_FROM_NVM_CBK_3(void* NvMBuffer)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucCount;
  uint8* LpDataPtr;
  
  LpDataPtr = (uint8*)NvMBuffer;
  
  for(LucCount = 0; LucCount < 8; LucCount++)
  {
    NvMApp_GaaRam_Result_Buffer0[LucCount] = *LpDataPtr;
    LpDataPtr++;
  }
  
  NvM_GucMirrorBlkCbkCount++;
  return(NvM_GddReadRamBlockRetVal);
  #endif
} /* End READ_RAM_BLOCK_FROM_NVM_CBK_3() */
/*******************************************************************************
**                    Test_READ_RAM_BLOCK_FROM_NVM_CBK_3()                    **
*******************************************************************************/
boolean Test_READ_RAM_BLOCK_FROM_NVM_CBK_3(App_DataValidateType LucDataValidate)
{
  boolean LblStepResult;
   
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle callback invocation with single occurance and to validate
     * parameters of the callback with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ControllerId and PduModeRequest */
      if(NvM_GucMirrorBlkCbkCount == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      NvM_GucMirrorBlkCbkCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(NvM_GucMirrorBlkCbkCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End Test_READ_RAM_BLOCK_FROM_NVM_CBK_3() */
/*******************************************************************************
**                 TestSetNvM_ReadRamBlockFromNvmRetVal()                     **
*******************************************************************************/
void TestSetNvM_ReadRamBlockFromNvmRetVal(Std_ReturnType LddReadRamBlockRetVal)
{
  NvM_GddReadRamBlockRetVal = LddReadRamBlockRetVal;
} /* End TestSetNvM_ReadRamBlockFromNvmRetVal() */

/*******************************************************************************
**                     WRITE_RAM_BLOCK_TO_NVM_CBK_5()                         **
*******************************************************************************/
Std_ReturnType WRITE_RAM_BLOCK_TO_NVM_CBK_3(void* NvMBuffer)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucCount;
  uint8* LpDataPtr;
  
  LpDataPtr = (uint8*)NvMBuffer;
  
  for(LucCount = 0; LucCount < 8; LucCount++)
  {
    *LpDataPtr = NvMApp_GaaNvMUserData1[LucCount];
    LpDataPtr++;
  }
  
  NvM_GucMirrorBlkCbkCount++;
  return(NvM_GddWriteRamBlockRetVal);
  #endif
} /* End WRITE_RAM_BLOCK_TO_NVM_CBK_3() */
/*******************************************************************************
**                    Test_WRITE_RAM_BLOCK_TO_NVM_CBK_3()                    **
*******************************************************************************/
boolean Test_WRITE_RAM_BLOCK_TO_NVM_CBK_3(App_DataValidateType LucDataValidate)
{
  boolean LblStepResult;
   
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle callback invocation with single occurance and to validate
     * parameters of the callback with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ControllerId and PduModeRequest */
      if(NvM_GucMirrorBlkCbkCount == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      NvM_GucMirrorBlkCbkCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(NvM_GucMirrorBlkCbkCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End Test_WRITE_RAM_BLOCK_TO_NVM_CBK_3() */
/*******************************************************************************
**                  TestSetNvM_WriteRamBlockToNvmRetVal()                     **
*******************************************************************************/
void TestSetNvM_WriteRamBlockToNvmRetVal(Std_ReturnType LddWriteRamBlockRetVal)
{
  NvM_GddWriteRamBlockRetVal = LddWriteRamBlockRetVal;
} /* End TestSetNvM_WriteRamBlockToNvmRetVal() */

/*******************************************************************************
**                             INIT_BLOCK_CBK_3()                             **
*******************************************************************************/
Std_ReturnType INIT_BLOCK_CBK_3(void)
{
  NvM_GucInitBlkCbkCount++;
  return(E_OK);
} /* End INIT_BLOCK_CBK_3() */

/*******************************************************************************
**                            Test_INIT_BLOCK_CBK()                           **
*******************************************************************************/
boolean Test_INIT_BLOCK_CBK(App_DataValidateType LucDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle callback invocation with single occurance and to validate
     * parameters of the callback with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ControllerId and PduModeRequest */
      if(NvM_GucInitBlkCbkCount == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      NvM_GucInitBlkCbkCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(NvM_GucInitBlkCbkCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End Test_INIT_BLOCK_CBK() */

/*******************************************************************************
**                        TestNvM_CallBackDefaultBehavior()                   **
*******************************************************************************/
void TestNvM_CallBackDefaultBehavior(void)
{ 
  NvM_GucSingleBlkCbkCount = 0;
  NvM_GucSingleBlkCbkCheckCount = 0;
} /* End TestNvM_CallBackDefaultBehavior() */
#endif

#ifdef DCM_MODULE_ACTIVE

/*******************************************************************************
**                        App_DcmRteDataValidation()                     **
*******************************************************************************/
boolean App_DcmRteDataValidation(uint8* LpExpData, uint8* LpActData,
  uint16 LusDataLength)
{
  boolean LblReturnValue;
  
  LblReturnValue = TRUE;
  
  while(LusDataLength > 0)
  {
    if(*LpExpData != *LpActData)
    {
      LblReturnValue = FALSE;
    }
    LpActData++;
    LpActData++;
    LusDataLength--;
  }
  return(LblReturnValue);
} /* End App_DcmRteDataValidation */

Std_ReturnType RTE_DcmStopProtocol(Dcm_ProtocolType ProtocolID)
{
  ProtocolID++;
  return E_OK;
}

/*******************************************************************************
**          SimulateRte_DcmStartProtocol                   **
*******************************************************************************/
void SimulateRte_DcmStartProtocol(Std_ReturnType LddReturnType)
{
  Dcm_GddRteStartGeneralReturn = LddReturnType;
}

/*******************************************************************************
**          RTE_DcmStartProtocol                   **
*******************************************************************************/
Std_ReturnType RTE_DcmStartProtocol(Dcm_ProtocolType ProtocolID)
{
  Dcm_GddProtocolType = ProtocolID;
  Dcm_GucRteGeneralCount++;
  return (Dcm_GddRteStartGeneralReturn);
}

/*******************************************************************************
**          TestRte_DcmStartProtocol                   **
*******************************************************************************/
boolean TestRte_DcmStartProtocol(App_DataValidateType LddDataValidate,
   Dcm_ProtocolType LddExpProtocolType)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCount == 0x01) &&
        (Dcm_GddProtocolType == LddExpProtocolType))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          SetRte_DefaultBehaviorGetSeed                   **
*******************************************************************************/
void SetRte_DefaultBehaviorGetSeed(uint8 *LpSeed, uint8 LucDataLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  Dcm_GucRteDataLength = LucDataLength;
  do
  {
    Dcm_GaaGetSeed[LucIndex] = *LpSeed;
    LucIndex++;
    LpSeed++;
  }
  while(LucIndex < LucDataLength);
}

/*******************************************************************************
**          SetRte_DefaultBehaviorGetSeedReturn                   **
*******************************************************************************/
void SetRte_DefaultBehaviorGetSeedReturn(Std_ReturnType LddRetType,
  Dcm_NegativeResponseCodeType LddNegResCode)
{
  Dcm_GddRteGeneralReturn = LddRetType;
  Dcm_GddGeneralNegativeError = LddNegResCode;
}

/*******************************************************************************
**          SetRte_DefaultBehaviorGetSeedReturnOne                   **
*******************************************************************************/
void SetRte_DefaultBehaviorGetSeedReturnOne(Std_ReturnType LddRetType)
{
  Dcm_GddRteGeneralReturn = LddRetType;
}
/*******************************************************************************
**          SetRte_DefaultBehaviorCompareKey                   **
*******************************************************************************/
void SetRte_DefaultBehaviorCompareKey(Std_ReturnType LddKeyRetType)
{
  Dcm_GddRteGeneralReturn = LddKeyRetType;
}

/*******************************************************************************
**          Rte_GetSeed                   **
*******************************************************************************/
Std_ReturnType Rte_GetSeed(uint8 *LpSecurityAccessDataRecord,
  Dcm_OpStatusType LddOpStatus, uint8 *LpSeed,
    Dcm_NegativeResponseCodeType *LddErrorCode)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
    *LpSeed = Dcm_GaaGetSeed[LucIndex];
    LpSeed++;
    LucIndex++;
  }
  while(LucIndex < Dcm_GucRteDataLength);

  LucIndex = 0;
  do
  {
    GaaSecurityAccessDataRecord[LucIndex] = *LpSecurityAccessDataRecord;
    LucIndex++;
    LpSecurityAccessDataRecord++;
  }
  while(LucIndex < RTE_MAXVALUE);
  Dcm_GddGeneralOpStatus = LddOpStatus;
  LddErrorCode = &Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCount++;
  if(*LddErrorCode == RTE_MAXVALUE)
  {
  /* For Qac */
  }
  return(Dcm_GddRteGeneralReturn);
}/* End Rte_GetSeed() */

/*******************************************************************************
**          TestRte_GetSeed                   **
*******************************************************************************/
boolean TestRte_GetSeed(App_DataValidateType LddDataValidate, uint8
  *LucSecurityAccessDataRecord, Dcm_OpStatusType LddOpStatus, uint8 *LpExpSeed,
    Dcm_NegativeResponseCodeType *LddExpErrorCode, uint16 LucDataLength)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LddExpErrorCode++;
  LpExpSeed++;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCountseed == 0x01) && (Dcm_GddGeneralOpStatus == LddOpStatus) && 
        (App_DcmRteDataValidation(LucSecurityAccessDataRecord,
          &GaaSecurityAccessDataRecord[0], LucDataLength)))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCountseed = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCountseed == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }
/*******************************************************************************
**          Rte_SetKey                   **
*******************************************************************************/
Std_ReturnType Rte_CompareKey(uint8 *LucKey, Dcm_OpStatusType LddOpStatus)
{
  uint8 LucIndex;
  LucIndex = 0;
  Dcm_GddGeneralOpStatus = LddOpStatus;
  do
  {
    Dcm_GaaKeyValue[LucIndex] = *LucKey;
    LucIndex++;
    LucKey++;
  }
  while(LucIndex < RTE_MAXVALUE);
    Dcm_GucRteGeneralCountkey++;
  return(Dcm_GddRteGeneralReturn);
} /* End  Rte_SetKey */

/*******************************************************************************
**          TestRte_ComparedKey                   **
*******************************************************************************/
boolean TestRte_CompareKey(App_DataValidateType LddDataValidate, uint8 *LucKey,
  Dcm_OpStatusType LddOpStatus, uint16 LusDataLength)
{
  uint8 *LpActualKey;
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
   LpActualKey = &Dcm_GaaKeyValue[0];
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCountkey == 0x01) && (Dcm_GddGeneralOpStatus ==
        LddOpStatus) && (App_DcmRteDataValidation(LucKey, LpActualKey,
          LusDataLength)))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCountkey = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCountkey == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          SetRte_Call_DCM_DidServices_DID_ConditionCheckRead                   **
*******************************************************************************/
void SetRte_Call_DCM_DidServices_F112_ConditionCheckRead(Std_ReturnType
  LddRetType, Dcm_NegativeResponseCodeType LddNegResCode)
{
  Dcm_GddRteGeneralReturn = LddRetType;
  Dcm_GddGeneralNegativeError = LddNegResCode;
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F112_ConditionCheckRead                   **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F112_ConditionCheckRead(Dcm_OpStatusType
 LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LddErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCountCheck++;
  if(*LddErrorCode == RTE_MAXVALUE)
  {
  /* For Qac */
  }
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F112_ConditionCheckRead                   **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F112_ConditionCheckRead(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    Dcm_NegativeResponseCodeType *LddExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LddExpErrorCode++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCountCheck == 0x01) && (Dcm_GddGeneralOpStatus ==
        LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCountCheck = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCountCheck == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          SetRte_Call_DCM_DidServices_F113_ConditionCheckRead                   **
*******************************************************************************/
void SetRte_Call_DCM_DidServices_F113_ConditionCheckRead(Std_ReturnType
  LddRetType, Dcm_NegativeResponseCodeType LucNegResCode)
{
  Dcm_GddRteGeneralReturn = LddRetType;
  Dcm_GddGeneralNegativeError = LucNegResCode;
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F112_ConditionCheckRead                   **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F113_ConditionCheckRead(Dcm_OpStatusType
 LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LddErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCountCheck++;
  if(*LddErrorCode == RTE_MAXVALUE)
  {
  /* For Qac */
  }
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F113_ConditionCheckRead                   **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F113_ConditionCheckRead(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    Dcm_NegativeResponseCodeType *LddExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LddExpErrorCode++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCountCheck == 0x01) && (Dcm_GddGeneralOpStatus ==
        LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCountCheck = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCountCheck == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          SetRte_Call_DCM_DidServices_F114_ReadDataReturn                   **
*******************************************************************************/
void SetRte_Call_DCM_DidServices_F114_ReadDataReturn(Std_ReturnType LddRetType)
{
  Dcm_GddRteReadDataReturn = LddRetType;
}
/*******************************************************************************
**          SetRte_Call_DCM_DidServices_F114_ReadData                   **
*******************************************************************************/
void SetRte_Call_DCM_DidServices_F114_ReadData(uint8 *LpData, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
    Dcm_GaaRteGeneralData[LucIndex] = *LpData;
    LucIndex++;
    LpData++;
  }
  while(LucIndex < LucLength);
}

/*******************************************************************************
**          SetRte_Call_DCM_DidServices_F114_ConditionCheckRead                   **
*******************************************************************************/
void SetRte_Call_DCM_DidServices_F114_ConditionCheckRead(Std_ReturnType
  LddReturnType)
{
  Dcm_GddRteGeneralReturn = LddReturnType;
}
/*******************************************************************************
**          Rte_Call_DCM_DidServices_F114_ConditionCheckRead                   **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F114_ConditionCheckRead(Dcm_OpStatusType
 LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LddErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCountCheck++;
  if(*LddErrorCode == RTE_MAXVALUE)
  {
  /* For Qac */
  }
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F114_ReadData                   **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F114_ReadData(Dcm_OpStatusType
  LddOpStatus, uint8 *LpData)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
    *LpData =Dcm_GaaRteGeneralData[0];
  *LpData++;
  *LpData =Dcm_GaaRteGeneralData[1];
  *LpData++;
  *LpData =Dcm_GaaRteGeneralData[2];
  Dcm_GucRteReadCount++;
  if(*LpData == RTE_MAXVALUE)
  {
    /* To avoid QAC */
  }
  return(Dcm_GddRteReadDataReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F114_ConditionCheckRead                   **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F114_ConditionCheckRead(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    Dcm_NegativeResponseCodeType *LddExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LddExpErrorCode++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCountCheck == 0x01) && (Dcm_GddGeneralOpStatus == LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCountCheck = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCountCheck == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          SetRte_ConditionCheckRead                   **
*******************************************************************************/
void SetRte_ConditionCheckRead(Std_ReturnType LddReturnType,
  Dcm_NegativeResponseCodeType LddErrorCode)
{
  Dcm_GddRteGeneralReturn = LddReturnType;
  Dcm_GddGeneralNegativeError = LddErrorCode;
}

/*******************************************************************************
**          Rte_ConditionCheckRead                   **
*******************************************************************************/
Std_ReturnType Rte_ConditionCheckRead(Dcm_OpStatusType LddOpStatus,
  Dcm_NegativeResponseCodeType *LddErrorCode)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LddErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCountCheck++;
  if(*LddErrorCode == RTE_MAXVALUE)
  {
    /* To avoid QAC */
  }
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          TestRte_ConditionCheckRead                   **
*******************************************************************************/
boolean TestRte_ConditionCheckRead(App_DataValidateType LddDataValidate,
  Dcm_OpStatusType LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LddErrorCode++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCountCheck == 0x01) && 
        (Dcm_GddGeneralOpStatus == LddOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCountCheck = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCountCheck == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}




/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F114_ReadData                   **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F114_ReadData(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    uint8 *LpExpData)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpData++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteReadCount == 0x01) && (Dcm_GddGeneralOpStatus == LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteReadCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteReadCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }


/*******************************************************************************
**          SetRte_ReadDataReturn                   **
*******************************************************************************/
void SetRte_ReadDataReturn(Std_ReturnType LddReturnType)
{
  Dcm_GddRteReadDataReturn = LddReturnType;
}

/*******************************************************************************
**          SetRte_ReadData                   **
*******************************************************************************/
void SetRte_ReadData(uint8 *LpData, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
    Dcm_GaaRteGeneralData[LucIndex] = *LpData;
    LucIndex++;
    LpData++;
  }
  while(LucIndex < LucLength);
}

/*******************************************************************************
**          SetRte_ReadData                   **
*******************************************************************************/
Std_ReturnType Rte_ReadData(Dcm_OpStatusType LddOpStatus, uint8 *LpData)

{
    Dcm_GddGeneralOpStatus = LddOpStatus;
  *LpData =Dcm_GaaRteGeneralData[0];
  *LpData++;
  *LpData =Dcm_GaaRteGeneralData[1];
  *LpData++;
  *LpData =Dcm_GaaRteGeneralData[2];
  Dcm_GucRteReadCount++;
  if(*LpData ==  RTE_MAXVALUE)
  {
    /*To avoid Qac warning*/
  }
  return(Dcm_GddRteReadDataReturn);
}

/*******************************************************************************
**          TestRte_ReadData                   **
*******************************************************************************/
boolean TestRte_ReadData(App_DataValidateType LddDataValidate,
  Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpData++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteReadCount == 0x01) && (Dcm_GddGeneralOpStatus == LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteReadCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteReadCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}

/*******************************************************************************
**          SetRte_ReadDataLength                   **
*******************************************************************************/
void SetRte_ReadDataLength(uint16 LulDataLength)
{
  Dcm_GusGeneralDataLength = LulDataLength;
}

/*******************************************************************************
**          Rte_ReadDataLength                   **
*******************************************************************************/
Std_ReturnType Rte_ReadDataLength(uint16 *LusData)
{
  *LusData = Dcm_GusGeneralDataLength;
  Dcm_GucRteReadLengthCount++;
  return(Dcm_GddRteReadLengthReturn);
}

/*******************************************************************************
**          TestRte_ReadDataLength                   **
*******************************************************************************/
boolean TestRte_ReadDataLength(
  App_DataValidateType LddDataValidate, uint16 *LusExpDataLength)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LusExpDataLength++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if(Dcm_GucRteReadLengthCount == 0x01)
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteReadLengthCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteReadLengthCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}


/*******************************************************************************
**          SetRte_Call_DCM_DidServices_F115_ReadDataReturn                   **
*******************************************************************************/
void SetRte_Call_DCM_DidServices_F115_ReadDataReturn(Std_ReturnType LddRetType)
{
  Dcm_GddRteReadDataReturn = LddRetType;
}

/*******************************************************************************
**          SetRte_Call_DCM_DidServices_F115_ReadData                   **
*******************************************************************************/
void SetRte_Call_DCM_DidServices_F115_ReadData(uint8 *LpData, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
    Dcm_GaaRteGeneralData[LucIndex] = *LpData;
    LucIndex++;
    LpData++;
  }
  while(LucIndex < LucLength);

}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F115_ConditionCheckRead                   **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F115_ConditionCheckRead(Dcm_OpStatusType
 LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LddErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCountCheck++;
  if(*LddErrorCode == RTE_MAXVALUE)
  {
  /* For Qac */
  }
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F115_ReadData                   **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F115_ReadData(Dcm_OpStatusType
  LddOpStatus, uint8 *LpData)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LpData =Dcm_GaaRteGeneralData[0];
  *LpData++;
  *LpData =Dcm_GaaRteGeneralData[1];
  *LpData++;
  *LpData =Dcm_GaaRteGeneralData[2];
  Dcm_GucRteReadCount++;
  if(*LpData == RTE_MAXVALUE)
  {
  /* For Qac */
  }
  return(Dcm_GddRteReadDataReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F115_ConditionCheckRead                   **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F115_ConditionCheckRead(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    Dcm_NegativeResponseCodeType *LpExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpErrorCode++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCountCheck == 0x01) &&
        (Dcm_GddGeneralOpStatus == LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCountCheck = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCountCheck == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F115_ReadData                   **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F115_ReadData(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    uint8 *LpExpData)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpData++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteReadCount == 0x01) &&
        (Dcm_GddGeneralOpStatus == LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteReadCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteReadCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          SetRte_Call_DCM_DidServices_F116_ReadDataReturn                   **
*******************************************************************************/
void SetRte_Call_DCM_DidServices_F116_ReadDataReturn(Std_ReturnType LddRetType)
{
  Dcm_GddRteReadDataReturn = LddRetType;
}

/*******************************************************************************
**          SetRte_Call_DCM_DidServices_F116_ReadData                   **
*******************************************************************************/
void SetRte_Call_DCM_DidServices_F116_ReadData(uint8 *LpData, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
    Dcm_GaaRteGeneralData[LucIndex] = *LpData;
    LucIndex++;
    LpData++;
  }
  while(LucIndex < LucLength);
}

/*******************************************************************************
**          SetRte_Call_DCM_DidServices_F116_ReadDataLength                   **
*******************************************************************************/
void SetRte_Call_DCM_DidServices_F116_ReadDataLength(uint16 LusDataLength)
{
  Dcm_GusGeneralDataLength = LusDataLength;
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F116_ConditionCheckRead                   **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F116_ConditionCheckRead(Dcm_OpStatusType
 LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LddErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCountCheck++;
   if(*LddErrorCode == RTE_MAXVALUE)
  {
  /* For Qac */
  }
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F116_ReadData                   **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F116_ReadData(Dcm_OpStatusType
  LddOpStatus, uint8 *LpData)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LpData =Dcm_GaaRteGeneralData[0];
  *LpData++;
  *LpData =Dcm_GaaRteGeneralData[1];
  *LpData++;
  *LpData =Dcm_GaaRteGeneralData[2];
  Dcm_GucRteReadCount++;
  if(*LpData == RTE_MAXVALUE)
  {
  /* FOR Qac*/
  }
  return(Dcm_GddRteReadDataReturn);
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F116_ReadDataLength                  **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F116_ReadDataLength(uint16 *LusData)
{
  *LusData = Dcm_GusGeneralDataLength;
  Dcm_GucRteReadLengthCount++;
  return(Dcm_GddRteReadLengthReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F116_ConditionCheckRead                   **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F116_ConditionCheckRead(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    Dcm_NegativeResponseCodeType *LddExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LddExpErrorCode++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCountCheck == 0x01) &&
        (Dcm_GddGeneralOpStatus == LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCountCheck = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCountCheck == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F116_ReadData                   **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F116_ReadData(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    uint8 *LpExpData)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpData++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteReadCount == 0x01) &&
        (Dcm_GddGeneralOpStatus == LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteReadCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteReadCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F116_ReadDataLength                   **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F116_ReadDataLength(App_DataValidateType
  LddDataValidate, uint16 *LusExpDataLength)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LusExpDataLength++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if(Dcm_GucRteReadLengthCount == 0x01)
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteReadLengthCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteReadLengthCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          SetRte_Call_DCM_DidServices_F117_ReadDataReturn                   **
*******************************************************************************/
void SetRte_Call_DCM_DidServices_F117_ReadDataReturn(Std_ReturnType LddRetType)
{
  Dcm_GddRteReadDataReturn = LddRetType;
}

/*******************************************************************************
**          SetRte_Call_DCM_DidServices_F117_ReadData                   **
*******************************************************************************/
void SetRte_Call_DCM_DidServices_F117_ReadData(uint8 *LpData, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
    Dcm_GaaRteGeneralData[LucIndex] = *LpData;
    LucIndex++;
    LpData++;
  }
  while(LucIndex < LucLength);
}

/*******************************************************************************
**          SetRte_Call_DCM_DidServices_F117_ReadDataLength                   **
*******************************************************************************/
void SetRte_Call_DCM_DidServices_F117_ReadDataLength(uint16 LusDataLength)
{
  Dcm_GusGeneralDataLength = LusDataLength;
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F117_ConditionCheckRead                   **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F117_ConditionCheckRead(Dcm_OpStatusType
 LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LddErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCountCheck++;
  if(*LddErrorCode == RTE_MAXVALUE)
  {
  /* For Qac */
  }
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F117_ReadData                   **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F117_ReadData(Dcm_OpStatusType
  LddOpStatus, uint8 *LpData)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  LpData = &Dcm_GaaRteGeneralData[0];
  Dcm_GucRteReadCount++;
  if(*LpData == RTE_MAXVALUE)
  {
  /* FOR Qac*/
  }
  return(Dcm_GddRteReadDataReturn);
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F117_ReadDataLength                  **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F117_ReadDataLength(uint16 *LucData)
{
  *LucData = Dcm_GusGeneralDataLength;
  Dcm_GucRteReadLengthCount++;
  return(Dcm_GddRteReadLengthReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F117_ConditionCheckRead                   **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F117_ConditionCheckRead(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    Dcm_NegativeResponseCodeType *LddExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LddExpErrorCode++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCountCheck == 0x01) &&
        (Dcm_GddGeneralOpStatus == LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCountCheck = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCountCheck == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F117_ReadData                   **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F117_ReadData(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    uint8 *LpExpData)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpData++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteReadCount == 0x01) &&
        (Dcm_GddGeneralOpStatus == LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteReadCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteReadCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F117_ReadDataLength                   **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F117_ReadDataLength(App_DataValidateType
  LddDataValidate, uint16 *LpExpDataLength)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpDataLength++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if(Dcm_GucRteReadLengthCount == 0x01)
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteReadLengthCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteReadLengthCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          SetRte_Call_DCM_DidServices_F118_ReadData                   **
*******************************************************************************/
void SetRte_Call_DCM_DidServices_F118_ReadData(uint8 *LpData, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
  Dcm_GaaRteGeneralData[LucIndex] = *LpData;
  LucIndex++;
  LpData++;
  }
  while(LucIndex < LucLength);
}

/*******************************************************************************
**          SetRte_Call_DCM_DidServices_F118_ReadDataLength                   **
*******************************************************************************/
void SetRte_Call_DCM_DidServices_F118_ReadDataLength(uint16 LusDataLength)
{
  Dcm_GusGeneralDataLength = LusDataLength;
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F118_ConditionCheckRead                   **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F118_ConditionCheckRead(Dcm_OpStatusType
 LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LddErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCountCheck++;

  if(*LddErrorCode == RTE_MAXVALUE)
  {
  /* For Qac */
  }
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F118_ReadData                   **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F118_ReadData(Dcm_OpStatusType
  LddOpStatus, uint8 *LpData)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  LpData = &Dcm_GaaRteGeneralData[0];
  Dcm_GucRteReadCount++;
  if(*LpData == RTE_MAXVALUE)
  {
    /* To avoid QAC */
  }
  return(Dcm_GddRteReadDataReturn);
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F118_ReadDataLength                  **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F118_ReadDataLength(uint16 *LucData)
{
  *LucData = Dcm_GusGeneralDataLength;
  Dcm_GucRteReadLengthCount++;
  return(Dcm_GddRteReadLengthReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F118_ConditionCheckRead                   **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F118_ConditionCheckRead(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    Dcm_NegativeResponseCodeType *LddExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LddExpErrorCode++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCountCheck == 0x01) &&
        (Dcm_GddGeneralOpStatus == LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCountCheck = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCountCheck == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F118_ReadData                   **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F118_ReadData(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8
    *LpExpData)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpData++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteReadCount == 0x01) &&
        (Dcm_GddGeneralOpStatus == LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteReadCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteReadCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F118_ReadDataLength                   **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F118_ReadDataLength(App_DataValidateType
  LddDataValidate, uint16 *LucExpDataLength)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LucExpDataLength++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if(Dcm_GucRteReadLengthCount == 0x01)
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteReadLengthCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteReadLengthCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          SetRte_Call_DCM_DidServices_F119_ReadData                   **
*******************************************************************************/
void SetRte_Call_DCM_DidServices_F119_ReadData(uint8 *LpData, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
  Dcm_GaaRteGeneralData[LucIndex] = (*LpData)++;
  LucIndex++;
  }
  while(LucIndex < LucLength);
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F119_ConditionCheckRead                   **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F119_ConditionCheckRead(Dcm_OpStatusType
 LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LddErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCountCheck++;
  
  if(*LddErrorCode == RTE_MAXVALUE)
  {
  /* For Qac */
  }
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F119_ReadData                   **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F119_ReadData(Dcm_OpStatusType
  LddOpStatus, uint8 *LpData)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  LpData = &Dcm_GaaRteGeneralData[0];
  Dcm_GucRteReadCount++;
  if(*LpData == RTE_MAXVALUE)
  {
    /* To avoid QAC */
  }
  return(Dcm_GddRteReadDataReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F119_ConditionCheckRead                   **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F119_ConditionCheckRead(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    Dcm_NegativeResponseCodeType *LddExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LddExpErrorCode++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCountCheck == 0x01) &&
        (Dcm_GddGeneralOpStatus == LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCountCheck = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCountCheck == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F119_ReadData                   **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F119_ReadData(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    uint8 *LpExpData)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpData++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteReadCount == 0x01) &&
        (Dcm_GddGeneralOpStatus == LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteReadCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteReadCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          SetRte_Call_DCM_PidServices_03_GetPIDValue                   **
*******************************************************************************/
void SetRte_Call_DCM_PidServices_03_GetPIDValue(uint8 *LpData, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
    Dcm_GaaRteGeneralData[LucIndex] = (*LpData)++;
    LucIndex++;
  }
  while(LucIndex < LucLength);
}

/*******************************************************************************
**          Rte_Call_DCM_PidServices_03_GetPIDValue                   **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_PidServices_03_GetPIDValue(Dcm_OpStatusType
  LddOpStatus, uint8 *LpData)
{
  LpData = &Dcm_GaaRteGeneralData[0];
  Dcm_GddGeneralOpStatus = LddOpStatus;
  Dcm_GucRteGeneralCount++;
  if(*LpData == RTE_MAXVALUE)
  {
    /* To avoid QAC */
  }
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_PidServices_03_GetPIDValue             **
*******************************************************************************/
boolean TestRte_Call_DCM_PidServices_03_GetPIDValue(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpData++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCount == 0x01) &&
        (Dcm_GddGeneralOpStatus == LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          SetRte_Call_DCM_DTRServices_21_GetDTRValue             **
*******************************************************************************/
void SetRte_Call_DCM_DTRServices_21_GetDTRValue(uint16 LusTestVal, uint16
  LusMinLimit, uint16 LusMaxLimit, uint8 LcuStatus)
{
 Dcm_GusTestVal = LusTestVal;
 Dcm_GusMinLinit = LusMinLimit;
 Dcm_GusMaxLimit = LusMaxLimit;
 Dcm_GucStatus = LcuStatus;
}

/*******************************************************************************
**          Rte_Call_DCM_DTRServices_21_GetDTRValue             **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DTRServices_21_GetDTRValue(Dcm_OpStatusType
  LddOpStatus, uint16 *LpTestval, uint16 *LpMinlimit, uint16 *LpMaxlimit,
    uint8 *LpStatus)
{
  *LpTestval = Dcm_GusTestVal;
  *LpMinlimit = Dcm_GusMinLinit;
  *LpMaxlimit = Dcm_GusMaxLimit;
  *LpStatus = Dcm_GucStatus;
  Dcm_GddGeneralOpStatus = LddOpStatus;
  Dcm_GucRteGeneralCount++;
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_DTRServices_21_GetDTRValue             **
*******************************************************************************/
boolean TestRte_Call_DCM_DTRServices_21_GetDTRValue(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint16 *LpExpTestval,
    uint16 *LpExpMinlimit, uint16 *LpExpMaxlimit, uint8 *LpExpStatus)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpTestval++;
  LpExpMinlimit++;
  LpExpMaxlimit++;
  LpExpStatus++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCount == 0x01) && (Dcm_GddGeneralOpStatus == LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          SetRte_Call_DCM_InfotypeServices_09_GetInfoTypeValueData                   **
*******************************************************************************/
void SetRte_Call_DCM_InfotypeServices_09_GetInfoTypeValueData(uint8 *LpData,
  uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
    Dcm_GaaRteGeneralData[LucIndex] = (*LpData)++;
    LucIndex++;
  }
  while(LucIndex < LucLength);
}

/*******************************************************************************
**          Rte_Call_DCM_InfotypeServices_09_GetInfoTypeValueData                    **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_InfotypeServices_09_GetInfoTypeValueData(
  Dcm_OpStatusType LddOpStatus, uint8 *LpDataValueBuffer)
{
  LpDataValueBuffer = &Dcm_GaaRteGeneralData[0];
  Dcm_GddGeneralOpStatus = LddOpStatus;
  Dcm_GucRteGeneralCount++;
  if(*LpDataValueBuffer == RTE_MAXVALUE)
  {
    /* To avoid QAC */
  }
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_InfotypeServices_09_GetInfoTypeValueData             **
*******************************************************************************/
boolean TestRte_Call_DCM_InfotypeServices_09_GetInfoTypeValueData(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8
    *LpExpData)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpData++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCount == 0x01) && (Dcm_GddGeneralOpStatus ==
        LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          SimulateRte_Call_DCM_F016_ReturnControlToEcuReturn             **
*******************************************************************************/
void SimulateRte_Call_DCM_F016_ReturnControlToEcuReturn(Std_ReturnType
  LddReturnType)
{
  Dcm_GddRteGeneralReturn = LddReturnType;
}

/*******************************************************************************
**          SimulateRte_Call_DCM_F016_ReturnControlToEcu             **
*******************************************************************************/
void SimulateRte_Call_DCM_F016_ReturnControlToEcu(Std_ReturnType LddReturnType,
  Dcm_NegativeResponseCodeType LddErrorCode)
{
  Dcm_GddGeneralNegativeError = LddErrorCode;
  Dcm_GddRteGeneralReturn = LddReturnType;
}

/*******************************************************************************
**          SimulateRte_Call_DCM_F016_ReadData             **
*******************************************************************************/
void SimulateRte_Call_DCM_F016_ReadData(uint8 *LpData, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
    Dcm_GaaRteGeneralData[LucIndex] = (*LpData)++;
    LucIndex++;
    LpData++;
  }
  while(LucIndex < LucLength);
}

/*******************************************************************************
**          Rte_Call_DCM_F016_ReturnControlToEcu             **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_F016_ReturnControlToEcu(Dcm_OpStatusType
  LddOpStatus, Dcm_NegativeResponseCodeType *LpErrorCode)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LpErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCount++;
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          Rte_Call_DCM_F016_ReadData             **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_F016_ReadData(Dcm_OpStatusType LddOpStatus, uint8
  *LpData)
{
  LpData = &Dcm_GaaRteGeneralData[0];
  Dcm_GddGeneralOpStatus = LddOpStatus;
  Dcm_GucRteReadCount++;
   if(*LpData == RTE_MAXVALUE)
  {
    /* To avoid QAC */
  }
  return(Dcm_GddRteReadDataReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_F016_ReturnControlToEcu             **
*******************************************************************************/
boolean TestRte_Call_DCM_F016_ReturnControlToEcu(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, Dcm_NegativeResponseCodeType
    *LpExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpErrorCode++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCount == 0x01) && (Dcm_GddGeneralOpStatus ==
        LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          TestRte_Call_DCM_F016_ReadData             **
*******************************************************************************/
boolean TestRte_Call_DCM_F016_ReadData(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpData++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteReadCount == 0x01) && (Dcm_GddGeneralOpStatus ==
        LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteReadCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteReadCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          SimulateRte_Call_DCM_F017_ResetToDefault            **
*******************************************************************************/
void SimulateRte_Call_DCM_F017_ResetToDefault(Std_ReturnType
  LddReturnType, Dcm_NegativeResponseCodeType LddErrorCode)
{
  Dcm_GddGeneralNegativeError = LddErrorCode;
  Dcm_GddRteGeneralReturn = LddReturnType;
}

/*******************************************************************************
**          SimulateRte_Call_DCM_F017_ReadData             **
*******************************************************************************/
void SimulateRte_Call_DCM_F017_ReadData(uint8 *LpData, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
    Dcm_GaaRteGeneralData[LucIndex] = (*LpData)++;
    LucIndex++;
  }
  while(LucIndex < LucLength);
}

/*******************************************************************************
**          Rte_Call_DCM_F017_ResetToDefault             **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_F017_ResetToDefault(Dcm_OpStatusType LddOpStatus,
  Dcm_NegativeResponseCodeType *LpErrorCode)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LpErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCount++;
   if(*LpErrorCode == RTE_MAXVALUE)
  {
    /* To avoid QAC */
  }
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          Rte_Call_DCM_F017_ReadData             **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_F017_ReadData(Dcm_OpStatusType LddOpStatus, uint8
  *LpData)
{
  LpData = &Dcm_GaaRteGeneralData[0];
  Dcm_GddGeneralOpStatus = LddOpStatus;
  Dcm_GucRteReadCount++;
     if(*LpData == RTE_MAXVALUE)
  {
    /* To avoid QAC */
  }
  return(Dcm_GddRteReadDataReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_F017_ResetToDefault             **
*******************************************************************************/
boolean TestRte_Call_DCM_F017_ResetToDefault(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, Dcm_NegativeResponseCodeType
    *LpExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpErrorCode++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCount == 0x01) && (Dcm_GddGeneralOpStatus ==
        LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          TestRte_Call_DCM_F017_ReadData             **
*******************************************************************************/
boolean TestRte_Call_DCM_F017_ReadData(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpData++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteReadCount == 0x01) && (Dcm_GddGeneralOpStatus ==
        LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteReadCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteReadCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          SimulateRte_Call_DCM_F018_FreezeCurrentStateReturn             **
*******************************************************************************/
void SimulateRte_Call_DCM_F018_FreezeCurrentStateReturn(Std_ReturnType
  LddReturnType)
{
  Dcm_GddRteGeneralReturn = LddReturnType;
}

/*******************************************************************************
**          SimulateRte_Call_DCM_F018_FreezeCurrentState             **
*******************************************************************************/
void SimulateRte_Call_DCM_F018_FreezeCurrentState(Std_ReturnType LddReturnType,
  Dcm_NegativeResponseCodeType LddErrorCode)
{
  Dcm_GddGeneralNegativeError = LddErrorCode;
  Dcm_GddRteGeneralReturn = LddReturnType;
}

/*******************************************************************************
**          SimulateRte_Call_DCM_F018_ReadData             **
*******************************************************************************/
void SimulateRte_Call_DCM_F018_ReadData(uint8 *LpData, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
    Dcm_GaaRteGeneralData[LucIndex] = (*LpData)++;
    LucIndex++;
  }
  while(LucIndex < LucLength);
}

/*******************************************************************************
**          Rte_Call_DCM_F018_FreezeCurrentState             **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_F018_FreezeCurrentState(Dcm_OpStatusType
  LddOpStatus, Dcm_NegativeResponseCodeType *LpErrorCode)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LpErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCount++;
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          Rte_Call_DCM_F018_ReadData             **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_F018_ReadData(Dcm_OpStatusType LddOpStatus, uint8
  *LpData)
{
  LpData = &Dcm_GaaRteGeneralData[0];
  Dcm_GddGeneralOpStatus = LddOpStatus;
  Dcm_GucRteReadCount++;
       if(*LpData == RTE_MAXVALUE)
  {
    /* To avoid QAC */
  }
  return(Dcm_GddRteReadDataReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_F018_FreezeCurrentState             **
*******************************************************************************/
boolean TestRte_Call_DCM_F018_FreezeCurrentState(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, Dcm_NegativeResponseCodeType
    *LpExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpErrorCode++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCount == 0x01) && (Dcm_GddGeneralOpStatus ==
        LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          TestRte_Call_DCM_F018_ReadData             **
*******************************************************************************/
boolean TestRte_Call_DCM_F018_ReadData(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpData++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteReadCount == 0x01) && (Dcm_GddGeneralOpStatus ==
        LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteReadCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteReadCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          SimulateRte_Call_DCM_F019_ShortTermAdjustmentReturn             **
*******************************************************************************/
void SimulateRte_Call_DCM_F019_ShortTermAdjustmentReturn(Std_ReturnType
  LddReturnType)
{
  Dcm_GddRteGeneralReturn = LddReturnType;
}

/*******************************************************************************
**          SimulateRte_Call_DCM_F019_ShortTermAdjustment             **
*******************************************************************************/
void SimulateRte_Call_DCM_F019_ShortTermAdjustment(Std_ReturnType LddReturnType,
  Dcm_NegativeResponseCodeType LddErrorCode)
{
  Dcm_GddRteGeneralReturn = LddReturnType;
  Dcm_GddGeneralNegativeError = LddErrorCode;
}

/*******************************************************************************
**          SimulateRte_Call_DCM_F019_ReadData             **
*******************************************************************************/
void SimulateRte_Call_DCM_F019_ReadData(uint8 *LpData, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
    Dcm_GaaRteGeneralData[LucIndex] = (*LpData)++;
    LucIndex++;
  }
  while(LucIndex < LucLength);
}

/*******************************************************************************
**          Rte_Call_DCM_F019_ShortTermAdjustment             **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_F019_ShortTermAdjustment(uint8
  *LpControlOptionRecord, Dcm_OpStatusType LddOpStatus,
    Dcm_NegativeResponseCodeType *LpErrorCode)
{
  Dcm_GucControlOptionRecord = *LpControlOptionRecord;
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LpErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCount++;
       if(*LpErrorCode == RTE_MAXVALUE)
  {
    /* To avoid QAC */
  }
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          Rte_Call_DCM_F019_ReadData             **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_F019_ReadData(Dcm_OpStatusType LddOpStatus, uint8
  *LpData)
{
  LpData = &Dcm_GaaRteGeneralData[0];
  Dcm_GddGeneralOpStatus = LddOpStatus;
  Dcm_GucRteReadCount++;
  if(*LpData == RTE_MAXVALUE)
  {
    /* To avoid QAC */
  }
  return(Dcm_GddRteReadDataReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_F019_ShortTermAdjustment             **
*******************************************************************************/
boolean TestRte_Call_DCM_F019_ShortTermAdjustment(App_DataValidateType
  LddDataValidate, uint8 *LucControlOptionRecord, Dcm_OpStatusType
    LddExpOpStatus, Dcm_NegativeResponseCodeType *LpExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpErrorCode++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCount == 0x01) && (Dcm_GddGeneralOpStatus ==
        LddExpOpStatus) && (Dcm_GucControlOptionRecord ==
          *LucControlOptionRecord))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          TestRte_Call_DCM_F019_ReadData             **
*******************************************************************************/
boolean TestRte_Call_DCM_F019_ReadData(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpData++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteReadCount == 0x01) && (Dcm_GddGeneralOpStatus ==
        LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteReadCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteReadCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          SimulateRte_Call_DCM_DidServices_F190_GetScalingInfoReturn             **
*******************************************************************************/
void SimulateRte_Call_DCM_DidServices_F190_GetScalingInfoReturn(Std_ReturnType
  LddReturn)
{
  Dcm_GddRteGeneralReturn = LddReturn;
}

/*******************************************************************************
**          SimulateRte_Call_DCM_DidServices_F190_GetScalingInfoReturnData             **
*******************************************************************************/
void SimulateRte_Call_DCM_DidServices_F190_GetScalingInfoReturnData(
  Std_ReturnType LddReturn, uint8 *LpScalingInfo, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
  Dcm_GaaRteGeneralData[LucIndex] = (*LpScalingInfo)++;
  LucIndex++;
  }
  while(LucIndex < LucLength);
  Dcm_GddRteGeneralReturn = LddReturn;
}

/*******************************************************************************
**          SimulateRte_Call_DCM_DidServices_F190_GetScalingInformationReturn             **
*******************************************************************************/
void SimulateRte_Call_DCM_DidServices_F190_GetScalingInformationReturn(
  Std_ReturnType LddReturn, Dcm_NegativeResponseCodeType LddErrorCode)
{
  Dcm_GddRteGeneralReturn = LddReturn;
  Dcm_GddGeneralNegativeError = LddErrorCode;
}

/*******************************************************************************
**          SimulateRte_Call_DCM_DidServices_F190_GetScalingInformation             **
*******************************************************************************/
void SimulateRte_Call_DCM_DidServices_F190_GetScalingInformation(uint8
  *LpScalingInfo, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
  Dcm_GaaRteGeneralData[LucIndex] = (*LpScalingInfo)++;
  LucIndex++;
  }
  while(LucIndex < LucLength);
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F190_GetScalingInformation             **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F190_GetScalingInformation(
  Dcm_OpStatusType LddOpStatus, uint8 *LpScalingInfo,
    Dcm_NegativeResponseCodeType *LpErrorCode)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  LpScalingInfo = &Dcm_GaaRteGeneralData[0];
  *LpErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCount++;
    if(*LpScalingInfo == RTE_MAXVALUE)
  {
    /* To avoid QAC */
  }
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F190_GetScalingInformation             **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F190_GetScalingInformation(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    uint8 *LpExpScalingInfo, Dcm_NegativeResponseCodeType *LpExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpErrorCode++;
  LpExpScalingInfo++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCount == 0x01) && (Dcm_GddGeneralOpStatus ==
        LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          SimulateRte_Call_DCM_DidServices_F191_GetScalingInfoReturn             **
*******************************************************************************/
void SimulateRte_Call_DCM_DidServices_F191_GetScalingInfoReturn(Std_ReturnType
  LddReturn)
{
  Dcm_GddRteGeneralReturn = LddReturn;
}

/*******************************************************************************
**          SimulateRte_Call_DCM_DidServices_F191_GetScalingInfoReturnData             **
*******************************************************************************/
void SimulateRte_Call_DCM_DidServices_F191_GetScalingInfoReturnData(
  Std_ReturnType LddReturn, uint8 *LpScalingInfo, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
  Dcm_GaaRteGeneralData[LucIndex] = (*LpScalingInfo)++;
  LucIndex++;
  }
  while(LucIndex < LucLength);
  Dcm_GddRteGeneralReturn = LddReturn;
}

/*******************************************************************************
**          SimulateRte_Call_DCM_DidServices_F191_GetScalingInformationReturn             **
*******************************************************************************/
void SimulateRte_Call_DCM_DidServices_F191_GetScalingInformationReturn(
  Std_ReturnType LddReturn, Dcm_NegativeResponseCodeType LddErrorCode)
{
  Dcm_GddRteGeneralReturn = LddReturn;
  Dcm_GddGeneralNegativeError = LddErrorCode;
}

/*******************************************************************************
**          SimulateRte_Call_DCM_DidServices_F191_GetScalingInformation             **
*******************************************************************************/
void SimulateRte_Call_DCM_DidServices_F191_GetScalingInformation(uint8
  *LpScalingInfo, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
  Dcm_GaaRteGeneralData[LucIndex] = (*LpScalingInfo)++;
  LucIndex++;
  }
  while(LucIndex < LucLength);
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F191_GetScalingInformation             **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F191_GetScalingInformation(
  Dcm_OpStatusType LddOpStatus, uint8 *LpScalingInfo,
    Dcm_NegativeResponseCodeType *LpErrorCode)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  LpScalingInfo = &Dcm_GaaRteGeneralData[0];
  *LpErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCount++;
   if(*LpScalingInfo == RTE_MAXVALUE)
  {
    /* To avoid QAC */
  }
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F191_GetScalingInformation             **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F191_GetScalingInformation(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    uint8 *LpExpScalingInfo, Dcm_NegativeResponseCodeType *LpExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpErrorCode++;
  LpExpScalingInfo++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCount == 0x01) && (Dcm_GddGeneralOpStatus
        == LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
  }

/*******************************************************************************
**          SimulateRte_Call_DCM_DidServices_F188_WriteDataReturn             **
*******************************************************************************/
void SimulateRte_Call_DCM_DidServices_F188_WriteDataReturn(Std_ReturnType
  LddReturn)
{
  Dcm_GddRteGeneralReturn = LddReturn;
}

/*******************************************************************************
**          SimulateRte_Call_DCM_DidServices_F188_WriteData             **
*******************************************************************************/
void SimulateRte_Call_DCM_DidServices_F188_WriteData(Std_ReturnType LddReturn,
  Dcm_NegativeResponseCodeType LddErrorCode)
{
  Dcm_GddRteGeneralReturn = LddReturn;
  Dcm_GddGeneralNegativeError = LddErrorCode;
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F188_WriteData             **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F188_WriteData(uint8 *LpData, uint16
  LusDataLength, Dcm_OpStatusType LddOpStatus, Dcm_NegativeResponseCodeType
    *LpErrorCode)
{
  uint16 LusIndex;

  LusIndex = 0;
  do
  {
    Dcm_GaaRteGeneralData[LusIndex] = *LpData;
    LpData++;
    LusIndex++;
  }
  while(LusIndex < LusDataLength);

  Dcm_GusGeneralDataLength = LusDataLength;
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LpErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCount++;
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F188_WriteData             **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F188_WriteData(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData, uint16
    LusExpDataLength, Dcm_NegativeResponseCodeType *LpExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpErrorCode++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCount == 0x01) && (Dcm_GddGeneralOpStatus
        == LddExpOpStatus) && (Dcm_GusGeneralDataLength == LusExpDataLength))
      {
        if(App_DcmRteDataValidation(LpExpData, &Dcm_GaaRteGeneralData[0],
          Dcm_GusGeneralDataLength))
        {
         LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}

/*******************************************************************************
**          SimulateRte_Call_DCM_DidServices_F189_WriteDataReturn             **
*******************************************************************************/
void SimulateRte_Call_DCM_DidServices_F189_WriteDataReturn(Std_ReturnType
  LddReturn)
{
  Dcm_GddWriteDataOneReturn = LddReturn;
}

/*******************************************************************************
**          SimulateRte_Call_DCM_DidServices_F189_WriteData             **
*******************************************************************************/
void SimulateRte_Call_DCM_DidServices_F189_WriteData(Std_ReturnType LddReturn,
  Dcm_NegativeResponseCodeType LddErrorCode)
{
  Dcm_GddWriteDataOneReturn = LddReturn;
  Dcm_GddGeneralNegativeError = LddErrorCode;
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F189_WriteData             **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F189_WriteData(uint8 *LpData, uint16
  LusDataLength, Dcm_OpStatusType LddOpStatus, Dcm_NegativeResponseCodeType
    *LpErrorCode)
{
  uint16 LusIndex;

  LusIndex = 0;
  do
  {
    Dcm_GaaRteGeneralData[LusIndex] = *LpData;
    LpData++;
    LusIndex++;
  }
  while(LusIndex < LusDataLength);

  Dcm_GusGeneralDataLength = LusDataLength;
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LpErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCount++;
  return(Dcm_GddWriteDataOneReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F189_WriteData             **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F189_WriteData(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData, uint16
    LusExpDataLength, Dcm_NegativeResponseCodeType *LpExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpErrorCode++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCount == 0x01) && (Dcm_GddGeneralOpStatus
        == LddExpOpStatus) && (Dcm_GusGeneralDataLength == LusExpDataLength))
      {
        if(App_DcmRteDataValidation(LpExpData, &Dcm_GaaRteGeneralData[0],
          Dcm_GusGeneralDataLength))
        {
         LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F192_WriteData             **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F192_WriteData(uint8 *LpData, uint16
  LusDataLength, Dcm_OpStatusType LddOpStatus, Dcm_NegativeResponseCodeType
    *LpErrorCode)
{
  uint16 LusIndex;

  LusIndex = 0;
  do
  {
    Dcm_GaaRteGeneralData[LusIndex] = *LpData;
    LpData++;
    LusIndex++;
  }
  while(LusIndex < LusDataLength);

  Dcm_GusGeneralDataLength = LusDataLength;
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LpErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCount++;
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F192_WriteData             **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F192_WriteData(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData, uint16
    LusExpDataLength, Dcm_NegativeResponseCodeType *LpExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpErrorCode++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCount == 0x01) && (Dcm_GddGeneralOpStatus
        == LddExpOpStatus) && (Dcm_GusGeneralDataLength == LusExpDataLength))
      {
        if(App_DcmRteDataValidation(LpExpData, &Dcm_GaaRteGeneralData[0],
          Dcm_GusGeneralDataLength))
        {
         LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F193_WriteData             **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F193_WriteData(uint8 *LpData, uint16
  LusDataLength, Dcm_OpStatusType LddOpStatus, Dcm_NegativeResponseCodeType
    *LpErrorCode)
{
  uint16 LusIndex;

  LusIndex = 0;
  do
  {
    Dcm_GaaRteGeneralData[LusIndex] = *LpData;
    LpData++;
    LusIndex++;
  }
  while(LusIndex < LusDataLength);

  Dcm_GusGeneralDataLength = LusDataLength;
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LpErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCount++;
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F193_WriteData             **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F193_WriteData(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData, uint16
    LusExpDataLength, Dcm_NegativeResponseCodeType *LpExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpErrorCode++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCount == 0x01) && (Dcm_GddGeneralOpStatus
        == LddExpOpStatus) && (Dcm_GusGeneralDataLength == LusExpDataLength))
      {
        if(App_DcmRteDataValidation(LpExpData, &Dcm_GaaRteGeneralData[0],
          Dcm_GusGeneralDataLength))
        {
         LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F194_WriteData             **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F194_WriteData(uint8 *LpData, uint16
  LusDataLength, Dcm_OpStatusType LddOpStatus, Dcm_NegativeResponseCodeType
    *LpErrorCode)
{
  uint16 LusIndex;

  LusIndex = 0;
  do
  {
    Dcm_GaaRteGeneralData[LusIndex] = *LpData;
    LpData++;
    LusIndex++;
  }
  while(LusIndex < LusDataLength);

  Dcm_GusGeneralDataLength = LusDataLength;
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LpErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCount++;
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F194_WriteData             **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F194_WriteData(App_DataValidateType
  LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8 *LpExpData, uint16
    LusExpDataLength, Dcm_NegativeResponseCodeType *LpExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpErrorCode++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCount == 0x01) && (Dcm_GddGeneralOpStatus
        == LddExpOpStatus) && (Dcm_GusGeneralDataLength == LusExpDataLength))
      {
        if(App_DcmRteDataValidation(LpExpData, &Dcm_GaaRteGeneralData[0],
          Dcm_GusGeneralDataLength))
        {
         LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}

/*******************************************************************************
**          SimulateRte_Call_DCM_RoutineServices_0202_StartReturnData             **
*******************************************************************************/
void SimulateRte_Call_DCM_RoutineServices_0202_StartReturnData(Std_ReturnType
  LddReturn, uint8 *LpOutData, uint8 LucDataLength)
{
  uint8 LucIndex;

  LucIndex = 0;
  do
  {
    Dcm_GaaRoutineOutData[LucIndex] = *LpOutData;
    LpOutData++;
    LucIndex++;
  }
  while(LucIndex < LucDataLength);
  Dcm_GddRteGeneralReturn = LddReturn;
}

/*******************************************************************************
**          SimulateRte_Call_DCM_RoutineServices_0202_StartReturn             **
*******************************************************************************/
void SimulateRte_Call_DCM_RoutineServices_0202_StartReturn(Std_ReturnType
  LddReturn, Dcm_NegativeResponseCodeType LddErrorCode)
{
  Dcm_GddRteGeneralReturn = LddReturn;
  Dcm_GddGeneralNegativeError = LddErrorCode;
}

/*******************************************************************************
**          SimulateRte_Call_DCM_RoutineServices_0202_Start             **
*******************************************************************************/
void SimulateRte_Call_DCM_RoutineServices_0202_Start(uint8 *LpOutData,
  Dcm_NegativeResponseCodeType LddErrorCode, uint8 LucDataLength)
{
  uint8 LucIndex;

  LucIndex = 0;
  do
  {
    Dcm_GaaRoutineOutData[LucIndex] = *LpOutData;
    LpOutData++;
    LucIndex++;
  }
  while(LucIndex < LucDataLength);
  Dcm_GddGeneralNegativeError = LddErrorCode;
}

/*******************************************************************************
**          Rte_Call_DCM_RoutineServices_0202_Start             **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_RoutineServices_0202_Start(uint8 *LpDataIn,
  Dcm_OpStatusType LddOpStatus, uint8 *LpDataOut, Dcm_NegativeResponseCodeType
    *LddErrorCode)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
    Dcm_GaaRoutineInData[LucIndex] = *LpDataIn;
    LpDataIn++;
    LucIndex++;
  }
  while(LucIndex < RTE_MAXVALUE);
  Dcm_GddGeneralOpStatus = LddOpStatus;
  LpDataOut = &Dcm_GaaRoutineOutData[0];
  *LddErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCount++;
   if(*LpDataOut == RTE_MAXVALUE)
  {
    /* To avoid QAC */
  }
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**            TestRte_Call_DCM_RoutineServices_0202_Start                     **
*******************************************************************************/
boolean TestRte_Call_DCM_RoutineServices_0202_Start(App_DataValidateType
  LddDataValidate, uint8 *LpExpDataIn, Dcm_OpStatusType LddExpOpStatus, uint8
    *LpExpDataOut, Dcm_NegativeResponseCodeType *LpExpErrorCode, uint16
      LusExpDataLength)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpErrorCode++;
  LpExpDataOut++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCount == 0x01) && (Dcm_GddGeneralOpStatus
        == LddExpOpStatus))
      {
        if(App_DcmRteDataValidation(LpExpDataIn, &Dcm_GaaRoutineInData[0],
          LusExpDataLength))
        {
         LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}

/*******************************************************************************
**          SimulateRte_Call_DCM_RoutineServices_0203_StopReturn              **
*******************************************************************************/
void SimulateRte_Call_DCM_RoutineServices_0203_StopReturn(Std_ReturnType
  LddReturn, Dcm_NegativeResponseCodeType LddErrorCode)
{
  Dcm_GddRteGeneralReturn = LddReturn;
  Dcm_GddGeneralNegativeError = LddErrorCode;
}

/*******************************************************************************
**             SimulateRte_Call_DCM_RoutineServices_0203_Stop                 **
*******************************************************************************/
void SimulateRte_Call_DCM_RoutineServices_0203_Stop(uint8 *LpOutData,
  Dcm_NegativeResponseCodeType LddErrorCode, uint8 LucDataLength)
{
  uint8 LucIndex;

  LucIndex = 0;
  do
  {
    Dcm_GaaRoutineOutData[LucIndex] = *LpOutData;
    LpOutData++;
    LucIndex++;
  }
  while(LucIndex < LucDataLength);
  Dcm_GddGeneralNegativeError = LddErrorCode;
}

/*******************************************************************************
**                Rte_Call_DCM_RoutineServices_0203_Stop                      **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_RoutineServices_0203_Stop(uint8 *LpDataIn,
  Dcm_OpStatusType LddOpStatus, uint8 *LpDataOut, Dcm_NegativeResponseCodeType
    *LddErrorCode)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
    Dcm_GaaRoutineInData[LucIndex] = *LpDataIn;
    LpDataIn++;
    LucIndex++;
  }
  while(LucIndex < RTE_MAXVALUE);
  Dcm_GddGeneralOpStatus = LddOpStatus;
  LpDataOut = &Dcm_GaaRoutineOutData[0];
  *LddErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCount++;
   if(*LpDataOut == RTE_MAXVALUE)
  {
    /* To avoid QAC */
  }
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_RoutineServices_0203_Stop                        **
*******************************************************************************/
boolean TestRte_Call_DCM_RoutineServices_0203_Stop(App_DataValidateType
  LddDataValidate, uint8 *LpExpDataIn, Dcm_OpStatusType LddExpOpStatus, uint8
    *LpExpDataOut, Dcm_NegativeResponseCodeType *LpExpErrorCode, uint16
      LusExpDataLength)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpErrorCode++;
  LpExpDataOut++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCount == 0x01) && (Dcm_GddGeneralOpStatus
        == LddExpOpStatus))
      {
        if(App_DcmRteDataValidation(LpExpDataIn, &Dcm_GaaRoutineInData[0],
          LusExpDataLength))
        {
         LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}

/*******************************************************************************
**       SimulateRte_Call_DCM_RoutineServices_0204_RequestResultsReturn       **
*******************************************************************************/
void SimulateRte_Call_DCM_RoutineServices_0204_RequestResultsReturn(
  Std_ReturnType LddRteGeneralReturn, Dcm_NegativeResponseCodeType
    LddErrorCode)
{
  Dcm_GddRteGeneralReturn = LddRteGeneralReturn;
  Dcm_GddGeneralNegativeError = LddErrorCode;
}

/*******************************************************************************
**          SimulateRte_Call_DCM_RoutineServices_0204_RequestResults          **
*******************************************************************************/
void SimulateRte_Call_DCM_RoutineServices_0204_RequestResults(uint8 *LpOutData,
  Dcm_NegativeResponseCodeType LddErrorCode, uint8 LucDataLength)
{
  uint8 LucIndex;

  LucIndex = 0;
  do
  {
    Dcm_GaaRoutineOutData[LucIndex] = *LpOutData;
    LpOutData++;
    LucIndex++;
  }
  while(LucIndex < LucDataLength);
  Dcm_GddGeneralNegativeError = LddErrorCode;
}

/*******************************************************************************
**          Rte_Call_DCM_RoutineServices_0204_RequestResults                  **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_CallbackDCMRequestServices_SWC1_StopProtocol
  (Dcm_ProtocolType ProtocolID)
{
  Std_ReturnType LddReturnValue = E_OK;
  ProtocolID++;
  return LddReturnValue;
}

Std_ReturnType Rte_Call_DCM_CallbackDCMRequestServices_SWC1_StartProtocol
  (Dcm_ProtocolType ProtocolID)
{
  Std_ReturnType LddReturnValue = E_OK;
  ProtocolID++;
  return LddReturnValue;
}

Std_ReturnType Rte_Call_DCM_RoutineServices_0204_RequestResults(Dcm_OpStatusType
  LddOpStatus, uint8 *LpDataOut, Dcm_NegativeResponseCodeType *LddErrorCode)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  LpDataOut = &Dcm_GaaRoutineOutData[0];
  *LddErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCount++;
  if(*LddErrorCode == RTE_MAXVALUE)
  {
    /* To avoid QAC */
  }
  if(*LpDataOut == RTE_MAXVALUE)
  {
    /* To avoid QAC */
  }
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_RoutineServices_0204_RequestResults              **
*******************************************************************************/
boolean TestRte_Call_DCM_RoutineServices_0204_RequestResults(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus, uint8
    *LpExpDataOut, Dcm_NegativeResponseCodeType *LpExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpErrorCode++;
  LpExpDataOut++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCount == 0x01) && (Dcm_GddGeneralOpStatus
        == LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    case M_VALIDATE :
      break;

    case M_NOT_INVOKED :
      break;

    case S_VALIDATE_SEQ :
      break;

    case M_VALIDATE_SEQ :
      break;

  }
    return(LblRetValue);
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F124_ReadData                            **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F124_ReadData(Dcm_OpStatusType
  LddOpStatus, uint8 *LpData)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  LpData = &Dcm_GaaRteGeneralData[0];
  Dcm_GucRteReadCount++;
  if(*LpData == RTE_MAXVALUE)
  {
    /* To avoid QAC */
  }
  return(Dcm_GddRteReadDataReturn);
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F124_ConditionCheckRead                  **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F124_ConditionCheckRead(Dcm_OpStatusType
 LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LddErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCount++;
   if(*LddErrorCode == RTE_MAXVALUE)
  {
  /* For Qac */
  
  }
  
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          SetRte_Call_DCM_DidServices_F123_ReadDataReturn                   **
*******************************************************************************/  
void SetRte_Call_DCM_DidServices_F123_ReadDataReturn(Std_ReturnType LddRetType)
{
  Dcm_GddRteReadDataReturn = LddRetType;
}

/*******************************************************************************
**          SetRte_Call_DCM_DidServices_F123_ReadData                         **
*******************************************************************************/
void SetRte_Call_DCM_DidServices_F123_ReadData(uint8 *LpData, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
    Dcm_GaaGeneralData[LucIndex] = *LpData;
    LucIndex++;
    LpData++;
  }
  while(LucIndex < LucLength);
}

/*******************************************************************************
**          SetRte_Call_DCM_DidServices_F123_ReadDataLength                   **
*******************************************************************************/  
void SetRte_Call_DCM_DidServices_F123_ReadDataLength(uint16 LusDataLength)
{
  Dcm_GusGeneralDataLength = LusDataLength;
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F123_ConditionCheckRead                  **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F123_ConditionCheckRead(Dcm_OpStatusType
 LddOpStatus, Dcm_NegativeResponseCodeType *LddErrorCode)
{
  Dcm_GddGeneralOpStatus = LddOpStatus;
  *LddErrorCode = Dcm_GddGeneralNegativeError;
  Dcm_GucRteGeneralCountCheck++;
  
  if(*LddErrorCode == RTE_MAXVALUE)
  {
  /* For Qac */
  }
  return(Dcm_GddRteGeneralReturn);
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F123_ReadData                            **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F123_ReadData(uint8 *LpData)
{
  
  *LpData =Dcm_GaaGeneralData[0];
  *LpData++;
  *LpData =Dcm_GaaGeneralData[1];
  *LpData++;
  *LpData =Dcm_GaaGeneralData[2];
  Dcm_GucRteReadCount++;
  return(Dcm_GddRteReadDataReturn);
}

/*******************************************************************************
**          Rte_Call_DCM_DidServices_F123_ReadDataLength                      **
*******************************************************************************/
Std_ReturnType Rte_Call_DCM_DidServices_F123_ReadDataLength(uint16 *LusData)
{
  *LusData = Dcm_GusGeneralDataLength;
  Dcm_GucRteReadLengthCount++;
  return(Dcm_GddRteReadLengthReturn);
}

/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F123_ConditionCheckRead              **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F123_ConditionCheckRead(
  App_DataValidateType LddDataValidate, Dcm_OpStatusType LddExpOpStatus,
    Dcm_NegativeResponseCodeType *LddExpErrorCode)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LddExpErrorCode++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteGeneralCountCheck == 0x01) &&
        (Dcm_GddGeneralOpStatus == LddExpOpStatus))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteGeneralCountCheck = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteGeneralCountCheck == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    
    case M_VALIDATE :
      break;
    
    case M_NOT_INVOKED :
      break;
    
    case S_VALIDATE_SEQ :
      break;
      
    case M_VALIDATE_SEQ :
      break;
    
  }  
    return(LblRetValue);
  }
  
/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F123_ReadData                        **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F123_ReadData(
  App_DataValidateType LddDataValidate, uint8 *LpExpData)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpData++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GucRteReadCount == 0x01))
        
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteReadCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteReadCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    
    case M_VALIDATE :
      break;
    
    case M_NOT_INVOKED :
      break;
    
    case S_VALIDATE_SEQ :
      break;
      
    case M_VALIDATE_SEQ :
      break;
    
  }  
    return(LblRetValue);
  }  
  
/*******************************************************************************
**          TestRte_Call_DCM_DidServices_F123_ReadDataLength                  **
*******************************************************************************/
boolean TestRte_Call_DCM_DidServices_F123_ReadDataLength(App_DataValidateType
  LddDataValidate, uint16 *LusExpDataLength)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LusExpDataLength++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if(Dcm_GucRteReadLengthCount == 0x01)
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteReadLengthCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteReadLengthCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    
    case M_VALIDATE :
      break;
    
    case M_NOT_INVOKED :
      break;
    
    case S_VALIDATE_SEQ :
      break;
      
    case M_VALIDATE_SEQ :
      break;
    
  }  
    return(LblRetValue);
  }
  
Std_ReturnType Rte_SyncReadData(uint8 *LpData)
  
{
  
  *LpData =Dcm_GaaGeneralData[0];
  *LpData++;
  *LpData =Dcm_GaaGeneralData[1];
  *LpData++;
  *LpData =Dcm_GaaGeneralData[2];
  Dcm_GucRteReadCount++;
  return(Dcm_GddRteReadDataReturn);
}

void SetRte_SyncReadData(uint8 *LpData, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
    Dcm_GaaGeneralData[LucIndex] = *LpData;
    LucIndex++;
    LpData++;
  }
  while(LucIndex < LucLength);
}

/*******************************************************************************
**                            TestRte_SyncReadData                            **
*******************************************************************************/  
boolean TestRte_SyncReadData(App_DataValidateType LddDataValidate,
  uint8 *LpExpData)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  LpExpData++;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if(Dcm_GucRteReadCount == 0x01)
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRteReadCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRteReadCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    
    case M_VALIDATE :
      break;
    
    case M_NOT_INVOKED :
      break;
    
    case S_VALIDATE_SEQ :
      break;
      
    case M_VALIDATE_SEQ :
      break;
    
  }  
    return(LblRetValue);
}

/*******************************************************************************
**                    SetRte_SyncReadDataReturn                               **
*******************************************************************************/  
void SetRte_SyncReadDataReturn(Std_ReturnType LddReturnType)
{
  Dcm_GddRteReadDataReturn = LddReturnType;
} 
#endif /* End DCM_MODULE_ACTIVE */

#ifdef DEM_MODULE_ACTIVE
/*******************************************************************************
**                          oxygensensor()                      **
*******************************************************************************/
Std_ReturnType oxygensensor(uint8* LpData)
{ 
 for(GucIndex = 0; GucIndex < 2; GucIndex++)
  {
    *LpData++ = Rte_GaaObdDataBuffer1[GucIndex];
  }
 Rte_GddRetValue = E_OK;
 
 return(Rte_GddRetValue);
} /* End oxygensensor() */ 
/*******************************************************************************
**                          a_csensor()                      **
*******************************************************************************/
Std_ReturnType a_csensor(uint8* LpData)
{
 
 for(GucIndex = 0; GucIndex < 1; GucIndex++)
  {
    *LpData++ = Rte_GaaObdDataBuffer2[GucIndex];
  }
 Rte_GddRetValue = E_OK;
 
 return(Rte_GddRetValue);
} /* End a_csensor() */ 
/*******************************************************************************
**                          Noxsensor()                      **
*******************************************************************************/
Std_ReturnType Noxsensor(uint8* LpData)
{  
 
 for(GucIndex = 0; GucIndex < 3; GucIndex++)
  {
    *LpData++ = Rte_GaaObdDataBuffer3[GucIndex];
  }
 Rte_GddRetValue = E_OK;
 
 return(Rte_GddRetValue);
} /* End Noxsensor() */ 
/*******************************************************************************
**                          EvaporativeSensor()                               **
*******************************************************************************/
Std_ReturnType EvaporativeSensor(uint8* LpData)
{
 
 for(GucIndex = 0; GucIndex < 1; GucIndex++)
  {
    *LpData++ = Rte_GaaObdDataBuffer4[GucIndex];
  }
 Rte_GddRetValue = E_OK;
 
 return(Rte_GddRetValue);
} /* End EvaporativeSensor() */ 
/*******************************************************************************
**                          Dem_CallbackInitMForE_3                           **
*******************************************************************************/
Std_ReturnType Dem_CallbackInitMForE_3(Dem_InitMonitorReasonType
  LucInitMonitorReason)
{
  Rte_DemInitMonitorReason3 = LucInitMonitorReason;
  Rte_GddRetValue = E_OK;
  Rte_GucDemGlobalCount3++;
  return(Rte_GddRetValue);
} /* End Dem_CallbackInitMForE_3() */ 
/*******************************************************************************
**                       Test_Dem_CallbackInitMForE_3                         **
*******************************************************************************/
Std_ReturnType Test_Dem_CallbackInitMForE_3(
Dem_InitMonitorReasonType *LpInitMonitorReason)
{
  if (Rte_GucDemGlobalCount3>0 )
  {
    *LpInitMonitorReason = Rte_DemInitMonitorReason3;    
    return (E_OK);
  }
  else
  return (E_NOT_OK);
} /* End Test_Dem_CallbackInitMForE_3() */
/*******************************************************************************
**                          Dem_CallbackInitMForE_3                           **
*******************************************************************************/
Std_ReturnType Dem_CallbackInitMForE_14(Dem_InitMonitorReasonType
  LucInitMonitorReason)
{
  Rte_DemInitMonitorReason14 = LucInitMonitorReason;
  Rte_GddRetValue = E_OK;
  Rte_GucDemGlobalCount14++;
  return(Rte_GddRetValue);
} /* End Dem_CallbackInitMForE_14() */ 

/*******************************************************************************
**                          Dem_CallbackInitMForE_4                           **
*******************************************************************************/
Std_ReturnType Dem_CallbackInitMForE_4(uint8 LpInitMonitorReason)
{
  Rte_DemInitMonitorReason4 = LpInitMonitorReason;
  Rte_GddRetValue = E_OK;
  Rte_GucDemGlobalCount4++;
  return(Rte_GddRetValue);
} /* End Dem_CallbackInitMForE_4() */ 
/*******************************************************************************
**                       Test_Dem_CallbackInitMForE_4                         **
*******************************************************************************/
Std_ReturnType Test_Dem_CallbackInitMForE_4(
uint8 *LpInitMonitorReason)
{
  if (Rte_GucDemGlobalCount4>0 )
  {
    *LpInitMonitorReason = Rte_DemInitMonitorReason4;    
    return (E_OK);
  }
  else
  return (E_NOT_OK);
} /* End Test_Dem_CallbackInitMForE_4() */

/*******************************************************************************
**                             DemInitMonitorForSWC                           **
*******************************************************************************/
Std_ReturnType DemInitMonitorForSWC(Dem_InitMonitorReasonType LucInitMonitorReason)
{
  Rte_DemInitMonitorReason = LucInitMonitorReason;
  Rte_GddRetValue = E_OK;
  Rte_GucDemGlobalCount++;
  return(Rte_GddRetValue);
} /* End DemInitMonitorForSWC() */ 
/*******************************************************************************
**                       Test_DemInitMonitorForSWC                            **
*******************************************************************************/
Std_ReturnType Test_DemInitMonitorForSWC(
  uint8 *LpInitMonitorReason)
{
  if (Rte_GucDemGlobalCount>0 )
  {
    *LpInitMonitorReason = Rte_DemInitMonitorReason;    
    return (E_OK);
  }
  else
  return (E_NOT_OK);
} /* End DemInitMonitorForSWC() */

/*******************************************************************************
**                          DemCallbackClearEventAllowed_1()                  **
*******************************************************************************/
Std_ReturnType DemCallbackClearEventAllowed_1(boolean* Allowed)
{
  *Allowed = TRUE;
  Rte_DemCallbackClearEventAllowedCnt_1++;
  return (E_OK);
} /* End DemCallbackClearEventAllowed_1() */

/*******************************************************************************
**                     Test_DemCallbackClearEventAllowed_1()                  **
*******************************************************************************/
Std_ReturnType Test_DemCallbackClearEventAllowed_1(boolean* Allowed)
{
  if (Rte_DemCallbackClearEventAllowedCnt_1 > 0)
  {
    *Allowed = TRUE;
    return (E_OK);
  }
    return (E_NOT_OK);
} /* End Test_DemCallbackClearEventAllowed_1() */

/*******************************************************************************
**                    SWC_DemTriggerOnEventStatus_Event()                     **
*******************************************************************************/
void SWC_DemTriggerOnEventStatus_Event(Dem_EventIdType EventId, 
  Dem_EventStatusExtendedType EventStatusOld, 
  Dem_EventStatusExtendedType EventStatusNew)
{
  Det_GucEventId[Rte_GucReportCount] = EventId;
  Det_GusEventStatusOld[Rte_GucReportCount] = EventStatusOld;
  Det_GucEventStatusNew[Rte_GucReportCount] = EventStatusNew;
  
  
  /* Increment count variable to handle multiple invocations */
  Rte_GucReportCount++;
} /* End SWC_DemTriggerOnEventStatus_Event() */

/*******************************************************************************
**                     Test_SWC_DemTriggerOnEventStatus_Event()               **
*******************************************************************************/
Std_ReturnType Test_SWC_DemTriggerOnEventStatus_Event(App_DataValidateType
  LucDataValidate,
  Dem_EventIdType ExpEventId,Dem_EventStatusExtendedType ExpEventStatusOld, 
  Dem_EventStatusExtendedType ExpEventStatusNew)
{
  Std_ReturnType LblStepResult;
  uint8 LucIndex;
  LblStepResult = E_NOT_OK;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation  */
      if((Rte_GucReportCount == 0x01) &&
         (Det_GucEventId[0] == ExpEventId) &&
         (Det_GusEventStatusOld[0] == ExpEventStatusOld) &&
         (Det_GucEventStatusNew[0] == ExpEventStatusNew))
        
      {
        LblStepResult = E_OK;
      }

      /* Reset API invocation Count after validating the API invocation */
      Rte_GucReportCount = 0;
      Rte_GucReportCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */
    case M_VALIDATE:
    {
       /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Rte_GucReportCount; LucIndex++)
      {
        if((Det_GucEventId[LucIndex] == ExpEventId) &&
         (Det_GusEventStatusOld[LucIndex] == ExpEventStatusOld) &&
         (Det_GucEventStatusNew[LucIndex] == ExpEventStatusNew))
          {
            LblStepResult = E_OK;
            /*
            * Break the loop by reseting LucIndex with max after validating the
            * API invocation
            */
            LucIndex = Rte_GucReportCount;
          }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Rte_GucReportCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Rte_GucReportCheckCount == Rte_GucReportCount)
      {
        Rte_GucReportCount = 0;
        Rte_GucReportCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
   case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Rte_GucReportCount == 0)
      {
        LblStepResult = E_OK;
      }
      break;
    }
    default:
    {
      LblStepResult = E_OK;
      break;
    }
  } /* End Test_SWC_DemTriggerOnEventStatus_Event() */
      /* Case to handle API not invoked for single occurance */
  return(LblStepResult); 
}

/*******************************************************************************
**                    SWC_DemTriggerOnEventData()                             **
*******************************************************************************/
void SWC_DemTriggerOnEventData( Dem_EventIdType EventId )
{
  Det_GucEventId[Rte_GucReportCount] = EventId;
  
  /* Increment count variable to handle multiple invocations */
  Rte_GucReportCount++;
} /* End SWC_DemTriggerOnEventData() */

/*******************************************************************************
**                    Test_SWC_DemTriggerOnEventData()                        **
*******************************************************************************/
Std_ReturnType Test_SWC_DemTriggerOnEventData(App_DataValidateType
  LucDataValidate,Dem_EventIdType ExpEventId)
{
  Std_ReturnType LblStepResult;
  uint8 LucIndex;
  LblStepResult = E_NOT_OK;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation  */
      if((Rte_GucReportCount == 0x01) &&
         (Det_GucEventId[0] == ExpEventId))
        
      {
        LblStepResult = E_OK;
      }

      /* Reset API invocation Count after validating the API invocation */
      Rte_GucReportCount = 0;
      Rte_GucReportCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */
    case M_VALIDATE:
    {
       /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Rte_GucReportCount; LucIndex++)
      {
        if((Det_GucEventId[LucIndex] == ExpEventId))
          {
            LblStepResult = E_OK;
            /*
            * Break the loop by reseting LucIndex with max after validating the
            * API invocation
            */
            LucIndex = Rte_GucReportCount;
          }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Rte_GucReportCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Rte_GucReportCheckCount == Rte_GucReportCount)
      {
        Rte_GucReportCount = 0;
        Rte_GucReportCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
   case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Rte_GucReportCount == 0)
      {
        LblStepResult = E_OK;
      }
      break;
    }
    default:
    {
      LblStepResult = E_OK;
      break;
    }
  } /* End Test_SWC_DemTriggerOnEventStatus_Event() */
  /* Case to handle API not invoked for single occurance */
  return(LblStepResult); 
}
/*******************************************************************************
**                          DemCallbackClearEventAllowed_2()                  **
*******************************************************************************/
Std_ReturnType DemCallbackClearEventAllowed_2(boolean* Allowed)
{
  *Allowed = FALSE;
  Rte_DemCallbackClearEventAllowedCnt_2++;
  return (E_OK);
}/* End DemCallbackClearEventAllowed_2() */ 

/*******************************************************************************
**                     Test_DemCallbackClearEventAllowed_2()                  **
*******************************************************************************/
Std_ReturnType Test_DemCallbackClearEventAllowed_2(boolean* Allowed)
{
  if (Rte_DemCallbackClearEventAllowedCnt_2 > 0)
  {
    *Allowed = FALSE;
    
  }
 return (E_OK);  
} /* End Test_DemCallbackClearEventAllowed_2() */
/*******************************************************************************
**                          DemCallbackClearEventAllowed_3()                  **
*******************************************************************************/
Std_ReturnType DemCallbackClearEventAllowed_3(boolean* Allowed)
{
  *Allowed = FALSE;
  Rte_DemCallbackClearEventAllowedCnt_3++;
  return (E_NOT_OK);
}/* End DemCallbackClearEventAllowed_3() */ 

/*******************************************************************************
**                     Test_DemCallbackClearEventAllowed_2()                  **
*******************************************************************************/
Std_ReturnType Test_DemCallbackClearEventAllowed_3(boolean* Allowed)
{
  if (Rte_DemCallbackClearEventAllowedCnt_3 > 0)
  {
    *Allowed = FALSE;
    
  } 
 return (E_OK);  
} /* End Test_DemCallbackClearEventAllowed_3() */

/*******************************************************************************
**                          Callback_DemTriggerOnDTCStatus1()                 **
*******************************************************************************/
Std_ReturnType RTE_DemTriggerOnDTCStatus(uint32 DTC, uint8 DTCStatusOld, 
                                               uint8 DTCStatusNew)
{
  DemTriggerOnDTCStatus_DTC = DTC;
  DemTriggerOnDTCStatus_DTCStatusOld = DTCStatusOld;
  DemTriggerOnDTCStatus_DTCStatusNew = DTCStatusNew;
  Test_DemTriggerOnDTCStatus1_Cnt++;
  return (E_OK);
}/* End Callback_DemTriggerOnDTCStatus1() */ 

/*******************************************************************************
**                     Test_Callback_DemTriggerOnDTCStatus1()                 **
*******************************************************************************/
Std_ReturnType Test_RTE_DemTriggerOnDTCStatus(App_DataValidateType
  LucDataValidate,
  uint32 DTC,uint8  ExpDTCStatusOld, 
  uint8 ExpDTCStatusNew)
{
  Std_ReturnType LblStepResult;
  uint8 LucIndex;
  LblStepResult = E_NOT_OK;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation  */
      if((Rte_GucReportCount == 0x01) &&
         (Det_GucDTCId[0] == DTC) &&
         (Det_GusDTCStatusOld[0] == ExpDTCStatusOld) &&
         (Det_GucDTCStatusNew[0] == (ExpDTCStatusNew)))
        
      {
        LblStepResult = E_OK;
      }

      /* Reset API invocation Count after validating the API invocation */
      Rte_GucReportCount = 0;
      Rte_GucReportCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */
    case M_VALIDATE:
    {
       /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Rte_GucReportCount; LucIndex++)
      {
        if((Det_GucDTCId[LucIndex] == DTC) &&
         (Det_GusDTCStatusOld[LucIndex] == ExpDTCStatusOld) &&
         (Det_GucDTCStatusNew[LucIndex] == ExpDTCStatusNew))
          {
            LblStepResult = E_OK;
            /*
            * Break the loop by reseting LucIndex with max after validating the
            * API invocation
            */
            LucIndex = Rte_GucReportCount;
          }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Rte_GucReportCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Rte_GucReportCheckCount == Rte_GucReportCount)
      {
        Rte_GucReportCount = 0;
        Rte_GucReportCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
   case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Rte_GucReportCount == 0)
      {
        LblStepResult = E_OK;
      }
      break;
    }
    default:
    {
      LblStepResult = E_OK;
      break;
    }
  } /* End Test_SWC_DemTriggerOnEventStatus_Event() */
      /* Case to handle API not invoked for single occurance */
  return(LblStepResult); 
}

/*******************************************************************************
**                          Rte_ReadGlobalEngineRPMFnc()                      **
*******************************************************************************/
Std_ReturnType ReadGlobalEngineRPMFnc(uint8* LpData)
{
  //uint8 Rte_GaaDataBuffer[] = {0x01, 0x02, 0x03,0x04};
 
 for(GucIndex = 0; GucIndex < 1; GucIndex++)
  {
    *LpData++ = Rte_GaaDataBuffer1[GucIndex];
  }
 Rte_GddRetValue = E_OK;
 Rte_GucDemGlobalCount++;
  return(Rte_GddRetValue);
} /* End ReadGlobalEngineRPMFnc() */ 
/*******************************************************************************
**                       TestRte_ReadGlobalEngineRPMFnc()                      **
*******************************************************************************/
boolean TestReadGlobalEngineRPMFnc(App_DataValidateType LddDataValidate,
uint8 *LpExpData)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence and to validate
     * parameters of the API with what it has been invoked
     */
  case S_VALIDATE:
  {
    for(GucIndex = 0; GucIndex < 1; GucIndex++)
    {
      if((Rte_GucDemGlobalCount != 0x00) &&
         (Rte_GaaDataBuffer1[GucIndex] == *LpExpData++))
      {
        LblStepResult = APP_TC_PASSED;
      }
      else
      {
        GucIndex = 1;
            LblStepResult = STEP_FAILED;     
      }
    }
      Rte_GucDemGlobalCount = 0x00;
      break;
    } /* End case S_VALIDATE: */
  
    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */
  
    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {   
      if(Rte_GucDemGlobalCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestReadGlobalEngineRPMFnc() */
/*******************************************************************************
**                          Rte_ReadEngineCoolantTemperatureFnc()             **
*******************************************************************************/
Std_ReturnType ReadEngineCoolantTemperatureFnc(uint8* LpData)
{
   for(GucIndex = 0; GucIndex < 2; GucIndex++)
  {
    *LpData++ = Rte_GaaDataBuffer2[GucIndex];
  }
 Rte_GddRetValue = E_OK;
 Rte_GucDemGlobalCount++;
  return(Rte_GddRetValue);
} /* End ReadEngineCoolantTemperatureFnc() */
/*******************************************************************************
**                       TestRte_ReadEngineCoolantTemperatureFnc()            **
*******************************************************************************/
boolean TestReadEngineCoolantTemperatureFnc(App_DataValidateType LddDataValidate,
uint8 *LpExpData)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
 
  switch(LddDataValidate)
    {
      /*
       * Case to handle API invocation with single Occurrence and to validate
       * parameters of the API with what it has been invoked
       */
    case S_VALIDATE:
    {
      for(GucIndex = 0; GucIndex < 2; GucIndex++)
     {
        if((Rte_GucDemGlobalCount != 0x00) &&
           (Rte_GaaDataBuffer2[GucIndex] == *LpExpData++))
          {
            LblStepResult = APP_TC_PASSED;
          }
      else
      {
        GucIndex = 2;
            LblStepResult = STEP_FAILED;     
      }
     }
        Rte_GucDemGlobalCount = 0x00;
        break;
      } /* End case S_VALIDATE: */
    
      /*
       * Case to handle API invocation with multiple Occurrence  (with out any
       * sequence) and to validate parameters of the API with what it has been
       * invoked
       */
      case M_VALIDATE:
      {
        break;
      } /* End case M_VALIDATE: */
    
      /* Case to handle API not invoked for single Occurrence  */
      case S_NOT_INVOKED:
      {   
        if(Rte_GucDemGlobalCount == 0)
        {
          LblStepResult = STEP_PASSED;
        }
        break;
      }
      default:
      {
        LblStepResult = STEP_FAILED;
        break;
      }
    } /* End switch(LucDataValidate) */
  
    return(LblStepResult);
  } /* End TestReadEngineCoolantTemperatureFnc() */
/*******************************************************************************
**                          Rte_ReadIntakeAirTemperatureFnc()                 **
*******************************************************************************/
Std_ReturnType ReadIntakeAirTemperatureFnc(uint8* LpData)
{
  
 for(GucIndex = 0; GucIndex < 1; GucIndex++)
  {
    *LpData++ = Rte_GaaDataBuffer5[GucIndex];
  }
 Rte_GddRetValue = E_OK;
 Rte_GucDemGlobalCount++;
  return(Rte_GddRetValue);
} /* End ReadIntakeAirTemperatureFnc() */
/*******************************************************************************
**                       TestRte_ReadIntakeAirTemperatureFnc()                **
*******************************************************************************/
boolean TestReadIntakeAirTemperatureFnc(App_DataValidateType LddDataValidate,
uint8 *LpExpData)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
 
  switch(LddDataValidate)
    {
      /*
       * Case to handle API invocation with single Occurrence and to validate
       * parameters of the API with what it has been invoked
       */
    case S_VALIDATE:
    {
      for(GucIndex = 0; GucIndex < 1; GucIndex++)
     {
        if((Rte_GucDemGlobalCount != 0x00) &&
           (Rte_GaaDataBuffer5[GucIndex] == *LpExpData++))
          {
            LblStepResult = APP_TC_PASSED;
          }
      else
      {
        GucIndex = 1;
            LblStepResult = STEP_FAILED;     
      }
     }
        Rte_GucDemGlobalCount = 0x00;
        break;
      } /* End case S_VALIDATE: */
    
      /*
       * Case to handle API invocation with multiple Occurrence  (with out any
       * sequence) and to validate parameters of the API with what it has been
       * invoked
       */
      case M_VALIDATE:
      {
        break;
      } /* End case M_VALIDATE: */
    
      /* Case to handle API not invoked for single Occurrence  */
      case S_NOT_INVOKED:
      {   
        if(Rte_GucDemGlobalCount == 0)
        {
          LblStepResult = STEP_PASSED;
        }
        break;
      }
      default:
      {
        LblStepResult = STEP_FAILED;
        break;
      }
    } /* End switch(LucDataValidate) */
  
    return(LblStepResult);
  } /* End TestReadIntakeAirTemperatureFnc() */
  
/*******************************************************************************
**                           UpdateReadUsageModeFnc()                           **
*******************************************************************************/  
void UpdateReadUsageModeFnc(uint16 LucIndex) 
{
  Dem_GusReadUsageModeData = LucIndex;
} 
  
/*******************************************************************************
**                           Rte_ReadUsageModeFnc()                           **
*******************************************************************************/
Std_ReturnType ReadUsageModeFnc(uint8* LpData)
{
 *LpData = (uint8)((Dem_GusReadUsageModeData & 0xFF00) >> 8);
 LpData++;
 *LpData = (uint8)(Dem_GusReadUsageModeData & 0x00FF);
 Rte_GucDemGlobalCount++;
  return(Rte_GddRetValue);
} /* End ReadUsageModeFnc() */
/*******************************************************************************
**                       TestRte_ReadUsageModeFnc()                           **
*******************************************************************************/
boolean TestReadUsageModeFnc(App_DataValidateType LddDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
 
  switch(LddDataValidate)
    {
      /*
       * Case to handle API invocation with single Occurrence and to validate
       * parameters of the API with what it has been invoked
       */
    case S_VALIDATE:
    {
      for(GucIndex = 0; GucIndex < 1; GucIndex++)
     {
        if(Rte_GucDemGlobalCount != 0x00)
          {
            LblStepResult = APP_TC_PASSED;
          }
      else
      {
        GucIndex = 1;
            LblStepResult = STEP_FAILED;     
      }
     }
        break;
      } /* End case S_VALIDATE: */
    
      /*
       * Case to handle API invocation with multiple Occurrence  (with out any
       * sequence) and to validate parameters of the API with what it has been
       * invoked
       */
      case M_VALIDATE:
      {
        break;
      } /* End case M_VALIDATE: */
    
      /* Case to handle API not invoked for single Occurrence  */
      case S_NOT_INVOKED:
      {   
        if(Rte_GucDemGlobalCount == 0)
        {
          LblStepResult = STEP_PASSED;
        }
        break;
      }
      default:
      {
        LblStepResult = STEP_FAILED;
        break;
      }
    } /* End switch(LucDataValidate) */
  
    return(LblStepResult);
  } /* End TestReadUsageModeFnc() */
/*******************************************************************************
**                           UpdateReadDD00Fnc()                              **
*******************************************************************************/  
void UpdateReadDD00Fnc(uint32 LucIndex) 
{
  Dem_GusReadDD00Data = LucIndex;
} 
/*******************************************************************************
**                           Rte_ReadDD00Fnc()                                **
*******************************************************************************/
Std_ReturnType ReadDD00Fnc(uint8* LpData)
{
 *LpData = (uint8)((Dem_GusReadDD00Data & 0xFF000000) >> 24);
 LpData++;
 *LpData = (uint8)((Dem_GusReadDD00Data & 0x00FF0000) >> 16);
 LpData++;
 *LpData = (uint8)((Dem_GusReadDD00Data & 0x0000FF00) >> 8);
 LpData++;
 *LpData = (uint8)(Dem_GusReadDD00Data & 0x000000FF);
 Rte_GucDemGlobalCount++;
  return(Rte_GddRetValue);
} /* End ReadDD00Fnc() */
/*******************************************************************************
**                       TestRte_ReadDD00Fnc()                                **
*******************************************************************************/
boolean TestReadDD00Fnc(App_DataValidateType LddDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
 
  switch(LddDataValidate)
    {
      /*
       * Case to handle API invocation with single Occurrence and to validate
       * parameters of the API with what it has been invoked
       */
    case S_VALIDATE:
    {
      for(GucIndex = 0; GucIndex < 1; GucIndex++)
     {
        if(Rte_GucDemGlobalCount != 0x00)
          {
            LblStepResult = APP_TC_PASSED;
          }
      else
      {
        GucIndex = 1;
            LblStepResult = STEP_FAILED;     
      }
     }
        break;
      } /* End case S_VALIDATE: */
    
      /*
       * Case to handle API invocation with multiple Occurrence  (with out any
       * sequence) and to validate parameters of the API with what it has been
       * invoked
       */
      case M_VALIDATE:
      {
        break;
      } /* End case M_VALIDATE: */
    
      /* Case to handle API not invoked for single Occurrence  */
      case S_NOT_INVOKED:
      {   
        if(Rte_GucDemGlobalCount == 0)
        {
          LblStepResult = STEP_PASSED;
        }
        break;
      }
      default:
      {
        LblStepResult = STEP_FAILED;
        break;
      }
    } /* End switch(LucDataValidate) */
  
    return(LblStepResult);
  } /* End TestReadDD00Fnc() */
/*******************************************************************************
**                           UpdateReadDD01Fnc()                              **
*******************************************************************************/  
void UpdateReadDD01Fnc(uint8 LucIndex1, uint8 LucIndex2, uint8 LucIndex3) 

{
  Dem_GusReadDD01Data[0] = LucIndex1;
  Dem_GusReadDD01Data[1] = LucIndex2;
  Dem_GusReadDD01Data[2] = LucIndex3;
} 
/*******************************************************************************
**                           Rte_ReadDD01Fnc()                                **
*******************************************************************************/
Std_ReturnType ReadDD01Fnc(uint8* LpData)
{
 *LpData =  Dem_GusReadDD01Data[0];
 LpData++;
 *LpData =  Dem_GusReadDD01Data[1];
 LpData++;
 *LpData =  Dem_GusReadDD01Data[2];
 Rte_GucDemGlobalCount++;
  return(Rte_GddRetValue);
} /* End ReadDD01Fnc() */
/*******************************************************************************
**                       TestRte_ReadDD01Fnc()                                **
*******************************************************************************/
boolean TestReadDD01Fnc(App_DataValidateType LddDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
 
  switch(LddDataValidate)
    {
      /*
       * Case to handle API invocation with single Occurrence and to validate
       * parameters of the API with what it has been invoked
       */
    case S_VALIDATE:
    {
      for(GucIndex = 0; GucIndex < 1; GucIndex++)
     {
        if(Rte_GucDemGlobalCount != 0x00)
          {
            LblStepResult = APP_TC_PASSED;
          }
      else
      {
        GucIndex = 1;
            LblStepResult = STEP_FAILED;     
      }
     }
        break;
      } /* End case S_VALIDATE: */
    
      /*
       * Case to handle API invocation with multiple Occurrence  (with out any
       * sequence) and to validate parameters of the API with what it has been
       * invoked
       */
      case M_VALIDATE:
      {
        break;
      } /* End case M_VALIDATE: */
    
      /* Case to handle API not invoked for single Occurrence  */
      case S_NOT_INVOKED:
      {   
        if(Rte_GucDemGlobalCount == 0)
        {
          LblStepResult = STEP_PASSED;
        }
        break;
      }
      default:
      {
        LblStepResult = STEP_FAILED;
        break;
      }
    } /* End switch(LucDataValidate) */
  
    return(LblStepResult);
} /* End TestReadDD01Fnc() */
/*******************************************************************************
**                           UpdateReadDD02Fnc()                              **
*******************************************************************************/  
void UpdateReadDD02Fnc(uint8 LucIndex) 
{
  Dem_GusReadDD02Data = LucIndex;
} 
/*******************************************************************************
**                           Rte_ReadDD02Fnc()                                **
*******************************************************************************/
Std_ReturnType ReadDD02Fnc(uint8* LpData)
{
 *LpData = Dem_GusReadDD02Data;
 Rte_GucDemGlobalCount++;
  return(Rte_GddRetValue);
} /* End ReadDD02Fnc() */
/*******************************************************************************
**                       TestRte_ReadDD02Fnc()                                **
*******************************************************************************/
boolean TestReadDD02Fnc(App_DataValidateType LddDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
 
  switch(LddDataValidate)
    {
      /*
       * Case to handle API invocation with single Occurrence and to validate
       * parameters of the API with what it has been invoked
       */
    case S_VALIDATE:
    {
      for(GucIndex = 0; GucIndex < 1; GucIndex++)
     {
        if(Rte_GucDemGlobalCount != 0x00)
          {
            LblStepResult = APP_TC_PASSED;
          }
      else
      {
        GucIndex = 1;
            LblStepResult = STEP_FAILED;     
      }
     }
        break;
      } /* End case S_VALIDATE: */
    
      /*
       * Case to handle API invocation with multiple Occurrence  (with out any
       * sequence) and to validate parameters of the API with what it has been
       * invoked
       */
      case M_VALIDATE:
      {
        break;
      } /* End case M_VALIDATE: */
    
      /* Case to handle API not invoked for single Occurrence  */
      case S_NOT_INVOKED:
      {   
        if(Rte_GucDemGlobalCount == 0)
        {
          LblStepResult = STEP_PASSED;
        }
        break;
      }
      default:
      {
        LblStepResult = STEP_FAILED;
        break;
      }
    } /* End switch(LucDataValidate) */
  
    return(LblStepResult);
} /* End TestReadDD02Fnc() */
/*******************************************************************************
**                           UpdateReadDD0AFnc()                              **
*******************************************************************************/  
void UpdateReadDD0AFnc(uint8 LucIndex) 
{
  Dem_GusReadDD0AData = LucIndex;
} 
/*******************************************************************************
**                           Rte_ReadDD0AFnc()                                **
*******************************************************************************/
Std_ReturnType ReadDD0AFnc(uint8* LpData)
{
 *LpData = Dem_GusReadDD0AData;
 Rte_GucDemGlobalCount++;
  return(Rte_GddRetValue);
} /* End ReadDD0AFnc() */
/*******************************************************************************
**                       TestRte_ReadDD0AFnc()                                **
*******************************************************************************/
boolean TestReadDD0AFnc(App_DataValidateType LddDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
 
  switch(LddDataValidate)
    {
      /*
       * Case to handle API invocation with single Occurrence and to validate
       * parameters of the API with what it has been invoked
       */
    case S_VALIDATE:
    {
      for(GucIndex = 0; GucIndex < 1; GucIndex++)
     {
        if(Rte_GucDemGlobalCount != 0x00)
          {
            LblStepResult = APP_TC_PASSED;
          }
      else
      {
        GucIndex = 1;
            LblStepResult = STEP_FAILED;     
      }
     }
        break;
      } /* End case S_VALIDATE: */
    
      /*
       * Case to handle API invocation with multiple Occurrence  (with out any
       * sequence) and to validate parameters of the API with what it has been
       * invoked
       */
      case M_VALIDATE:
      {
        break;
      } /* End case M_VALIDATE: */
    
      /* Case to handle API not invoked for single Occurrence  */
      case S_NOT_INVOKED:
      {   
        if(Rte_GucDemGlobalCount == 0)
        {
          LblStepResult = STEP_PASSED;
        }
        break;
      }
      default:
      {
        LblStepResult = STEP_FAILED;
        break;
      }
    } /* End switch(LucDataValidate) */
  
    return(LblStepResult);
} /* End TestReadDD0AFnc() */

/*******************************************************************************
**                           UpdateReadDD00Fnc()                              **
*******************************************************************************/  
void UpdateReadGlobalEngineRPMFnc(uint8 LucIndex) 
{
  Rte_GaaDataBuffer1[0] = LucIndex;
} 

/*******************************************************************************
**                           Rte_ReadVehicleSpeedFnc()                        **
*******************************************************************************/
Std_ReturnType ReadVehicleSpeedFnc(uint8* LpData)
{

 for(GucIndex = 0; GucIndex < 1; GucIndex++)
  {
    *LpData++ = Rte_GaaDataBuffer3[GucIndex];
  }
 Rte_GddRetValue = E_OK;
 Rte_GucDemGlobalCount++;
  return(Rte_GddRetValue);
} /* End ReadVehicleSpeedFnc() */
/*******************************************************************************
**                             TestRte_ReadVehicleSpeedFnc()                  **
*******************************************************************************/
boolean TestReadVehicleSpeedFnc(App_DataValidateType LddDataValidate,
uint8 *LpExpData)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
 
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      for(GucIndex = 0; GucIndex < 1; GucIndex++)
     {
        if((Rte_GucDemGlobalCount != 0x00) &&
           (Rte_GaaDataBuffer3[GucIndex] == *LpExpData++))
          {
            LblStepResult = APP_TC_PASSED;
          }
      else
      {
        GucIndex = 1;
          LblStepResult = STEP_FAILED;     
      }
     }
        Rte_GucDemGlobalCount = 0x00;
        break;
    } /* End case S_VALIDATE: */
    
    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */
    
    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {   
      if(Rte_GucDemGlobalCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  
    return(LblStepResult);
} /* End TestReadVehicleSpeedFnc() */
/*******************************************************************************
**                           Rte_ReadFuelPressureFnc()                        **
*******************************************************************************/
Std_ReturnType ReadFuelPressureFnc(uint8* LpData)
{
  
 for(GucIndex = 0; GucIndex < 3; GucIndex++)
  {
    *LpData++ = Rte_GaaDataBuffer4[GucIndex];
  }
 Rte_GddRetValue = E_OK;
 Rte_GucDemGlobalCount++;
  return(Rte_GddRetValue);
} /* End ReadFuelPressureFnc() */
/*******************************************************************************
**                         TestRte_ReadFuelPressureFnc()                      **
*******************************************************************************/
boolean TestReadFuelPressureFnc(App_DataValidateType LddDataValidate,
uint8 *LpExpData)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
 
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      for(GucIndex = 0; GucIndex < 3; GucIndex++)
     {
        if((Rte_GucDemGlobalCount != 0x00) &&
           (Rte_GaaDataBuffer4[GucIndex] == *LpExpData++))
          {
            LblStepResult = APP_TC_PASSED;
          }
      else
      {
        GucIndex = 3;
          LblStepResult = STEP_FAILED;     
      }
     }
        Rte_GucDemGlobalCount = 0x00;
        break;
    } /* End case S_VALIDATE: */
    
    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */
    
    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {   
      if(Rte_GucDemGlobalCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  
    return(LblStepResult);
} /* End TestReadFuelPressureFnc() */
/*******************************************************************************
**                           Rte_ReadFuelPressureFnc()                        **
*******************************************************************************/
Std_ReturnType ReadAmbienttempWrong(uint8* LpData)
{  
    *LpData = 15;

 Rte_GddRetValue = E_OK;
 Rte_GucDemGlobalCount++;
  return(Rte_GddRetValue);
} /* End ReadAmbienttempWrong() */
/*******************************************************************************
**                           Rte_ReadFuelPressureFnc()                        **
*******************************************************************************/
Std_ReturnType ReadAmbienttemp(uint8* LpData)
{  
    *LpData = 21;

 Rte_GddRetValue = E_OK;
 Rte_GucDemGlobalCount++;
  return(Rte_GddRetValue);
} /* End ReadAmbienttemp() */
/*******************************************************************************
**                         TestRte_ReadFuelPressureFnc()                      **
*******************************************************************************/
boolean TestReadAmbienttemp(App_DataValidateType LddDataValidate,
uint8 *LpExpData)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
 
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      for(GucIndex = 0; GucIndex < 3; GucIndex++)
     {
        if((Rte_GucDemGlobalCount != 0x00) &&
           (Rte_GaaDataBuffer4[GucIndex] == *LpExpData++))
          {
            LblStepResult = APP_TC_PASSED;
          }
      else
      {
        GucIndex = 3;
          LblStepResult = STEP_FAILED;     
      }
     }
        Rte_GucDemGlobalCount = 0x00;
        break;
    } /* End case S_VALIDATE: */
    
    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */
    
    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {   
      if(Rte_GucDemGlobalCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  
    return(LblStepResult);
} /* End TestReadAmbienttemp() */
/*******************************************************************************
**                        Rte_CallbackDemGetFaultDetectionCounter03()         **
*******************************************************************************/
Std_ReturnType Rte_CallbackDemGetFaultDetectionCounter03(sint8* LpEventIdFaultdetectionCounter)
{
  Std_ReturnType LddReturn = E_OK;

  *LpEventIdFaultdetectionCounter = 127;
  
  Rte_CallbackDemGetFaultDetectionCallCnt_3++;

  return LddReturn;
}
/*******************************************************************************
**                        Rte_CallbackDemGetFaultDetectionCounter()           **
*******************************************************************************/
Std_ReturnType Rte_CallbackDemGetFaultDetectionCounter
  (sint8* LpEventIdFaultdetectionCounter)
{
  Std_ReturnType LddReturn = E_NOT_OK;

  *LpEventIdFaultdetectionCounter = 0;
  
  return LddReturn;
}

/*******************************************************************************
**                        Test_Rte_CallbackDemGetFaultDetectionCounter03()    **
*******************************************************************************/
Std_ReturnType Test_Rte_CallbackDemGetFaultDetectionCounter03
  (sint8* LpEventIdFaultdetectionCounter)
{
  *LpEventIdFaultdetectionCounter = 127;

  if(Rte_CallbackDemGetFaultDetectionCallCnt_3>0)
   return E_OK;
  else
  return E_NOT_OK;
}

/*******************************************************************************
**                          No_Data_Available()                               **
*******************************************************************************/
Std_ReturnType No_Data_Available(uint8* LpData)
{
   for(GucIndex = 0; GucIndex < 2; GucIndex++)
  {
    *LpData++ = Rte_GaaObdDataBuffer1[GucIndex];
  }
  return(E_NOT_OK);
} /* End ReadGlobalEngineRPMFnc() */ 

/*******************************************************************************
**                        Test_Rte_CallbackDemGetFaultDetectionCounter()      **
*******************************************************************************/
Std_ReturnType Test_Rte_CallbackDemGetFaultDetectionCounter   
  (sint8* LpEventIdFaultdetectionCounter)
{
  *LpEventIdFaultdetectionCounter = 0;
  return E_NOT_OK;
}
#endif

#ifdef STBM_MODULE_ACTIVE
/*******************************************************************************
**                       TestResetRteInvocationCounts()                       **
*******************************************************************************/
void TestResetRteInvocationCounts(void)
{
  StbM_GddProvider001Count = 0;
  StbM_GddCustomerSyncState001Count = 0;
  StbM_GddCustomerSyncState002Count = 0;
  StbM_GddCustomerGlobalTime001Count = 0;
  StbM_GddCustomerGlobalTime002Count = 0;
  StbM_GddTickProvider001Count = 0;
  StbM_GddTickDurationProvider001Count = 0;
}
/*******************************************************************************
**                       SyncStateProvider001_Callout()                       **
*******************************************************************************/
/* Sync state provider callout */
void SyncStateProvider001_Callout
(StbM_SynchronizedTimeBaseType timeBaseID, StbM_SyncStatusType* syncState)
{
  StbM_GddTimeBaseId001 = timeBaseID;
  *syncState = StbM_GddSyncState001;
  StbM_GddProvider001Count++;
}

void TestSyncStateProvider001_CalloutSetVal(StbM_SyncStatusType syncState)
{
  StbM_GddSyncState001 = syncState;
}

boolean TestSyncStateProvider001_Callout
(App_DataValidateType LucDataValidate, StbM_SynchronizedTimeBaseType timeBaseID,
 StbM_SyncStatusType syncState)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((timeBaseID == StbM_GddTimeBaseId001) &&
      (1 == StbM_GddProvider001Count) && (syncState == StbM_GddSyncState001))
      {
        LblStepResult = STEP_PASSED;
        StbM_GddProvider001Count = 0;
        /* Reset to never used value */
        StbM_GddTimeBaseId001 = 255;
      }
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(StbM_GddProvider001Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
}
/*******************************************************************************
**                       GlobalTimeProvider001_Callout()                      **
*******************************************************************************/
/* Global time provider callout */
void GlobalTimeProvider001_Callout
(StbM_SynchronizedTimeBaseType timeBaseID, StbM_TickType* ticks)
{
  StbM_GddTimeBaseId001 = timeBaseID;
  *ticks = StbM_GddTicks001;
  StbM_GddTickProvider001Count++;
}

void TestGlobalTimeProvider001_CalloutSetVal(StbM_TickType ticks)
{
  StbM_GddTicks001 = ticks;
}

boolean TestTickProvider001_Callout
(App_DataValidateType LucDataValidate, StbM_SynchronizedTimeBaseType timeBaseID,
 StbM_TickType ticks)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((timeBaseID == StbM_GddTimeBaseId001) &&
      (1 == StbM_GddTickProvider001Count) && (ticks == StbM_GddTicks001))
      {
        LblStepResult = STEP_PASSED;
        StbM_GddTickProvider001Count = 0;
        /* Reset to never used value */
        StbM_GddTimeBaseId001 = 255;
      }
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(StbM_GddTickProvider001Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
}
/*******************************************************************************
**                       TickDurationProvider001_Callout()                    **
*******************************************************************************/
/* Tick duration provider callout */
void TickDurationProvider001_Callout
(StbM_SynchronizedTimeBaseType timeBaseID, uint16* tickDuration)
{
  StbM_GddTimeBaseId001 = timeBaseID;
  *tickDuration = StbM_GddTickDuration001;
  StbM_GddTickDurationProvider001Count++;
}

void TestTickDurationProvider001_CalloutSetVal(uint16 tickDuration)
{
  StbM_GddTickDuration001 = tickDuration;
}

boolean TestTickDurationProvider001_Callout
(App_DataValidateType LucDataValidate, StbM_SynchronizedTimeBaseType timeBaseID,
 uint16 tickDuration)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((timeBaseID == StbM_GddTimeBaseId001) &&
      (1 == StbM_GddTickDurationProvider001Count) &&
      (tickDuration == StbM_GddTickDuration001))
      {
        LblStepResult = STEP_PASSED;
        StbM_GddTickDurationProvider001Count = 0;
        /* Reset to never used value */
        StbM_GddTimeBaseId001 = 255;
      }
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(StbM_GddTickDurationProvider001Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
}
/*******************************************************************************
**                       SyncStateCustomer001_CallbackFunction()              **
*******************************************************************************/
/* Sync state customer callout */
void SyncStateCustomer001_CallbackFunction
(StbM_SynchronizedTimeBaseType timeBaseID, StbM_SyncStatusType syncState)
{
  StbM_GddCustomerSyncState001 = syncState;
  StbM_GddCustomerTimeBase001 = timeBaseID;
  StbM_GddCustomerSyncState001Count++;
}

boolean TestSyncStateCustomer001_CallbackFunction
(App_DataValidateType LucDataValidate, StbM_SynchronizedTimeBaseType timeBaseID,
 StbM_SyncStatusType syncState)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((timeBaseID == StbM_GddCustomerTimeBase001) &&
      (StbM_GddCustomerSyncState001 == syncState) &&
      (1 == StbM_GddCustomerSyncState001Count))
      {
        LblStepResult = STEP_PASSED;
        StbM_GddCustomerSyncState001Count = 0x00;
      }
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(StbM_GddCustomerSyncState001Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
}
/*******************************************************************************
**                       SyncStateCustomer002_CallbackFunction()              **
*******************************************************************************/
/* Sync state customer callout */
void SyncStateCustomer002_CallbackFunction
(StbM_SynchronizedTimeBaseType timeBaseID, StbM_SyncStatusType syncState)
{
  StbM_GddCustomerSyncState002 = syncState;
  StbM_GddCustomerTimeBase002 = timeBaseID;
  StbM_GddCustomerSyncState002Count++;
}

boolean TestSyncStateCustomer002_CallbackFunction
(App_DataValidateType LucDataValidate, StbM_SynchronizedTimeBaseType timeBaseID,
 StbM_SyncStatusType syncState)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((timeBaseID == StbM_GddCustomerTimeBase002) &&
      (StbM_GddCustomerSyncState002 == syncState) &&
      (1 == StbM_GddCustomerSyncState002Count))
      {
        LblStepResult = STEP_PASSED;
        StbM_GddCustomerSyncState002Count = 0;
      }
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(StbM_GddCustomerSyncState002Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
}
/*******************************************************************************
**                       GlobalTimeCustomer001_CallbackFunction()             **
*******************************************************************************/
void GlobalTimeCustomer001_CallbackFunction
(StbM_SynchronizedTimeBaseType timeBaseID, StbM_TickType ticks)
{
  StbM_GddCustomerGlobalTime001 = ticks;
  StbM_GddCustomerTimeBase001 = timeBaseID;
  StbM_GddCustomerGlobalTime001Count++;
}

boolean TestGlobalTimeCustomer001_CallbackFunction
(App_DataValidateType LucDataValidate, StbM_SynchronizedTimeBaseType timeBaseID,
 StbM_TickType ticks)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((timeBaseID == StbM_GddCustomerTimeBase001) &&
      (StbM_GddCustomerGlobalTime001 == ticks) &&
      (1 == StbM_GddCustomerGlobalTime001Count))
      {
        LblStepResult = STEP_PASSED;
        StbM_GddCustomerGlobalTime001Count = 0;
      }
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(StbM_GddCustomerGlobalTime001Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
}
/*******************************************************************************
**                       GlobalTimeCustomer002_CallbackFunction()             **
*******************************************************************************/
void GlobalTimeCustomer002_CallbackFunction
(StbM_SynchronizedTimeBaseType timeBaseID, StbM_TickType ticks)
{
  StbM_GddCustomerGlobalTime002 = ticks;
  StbM_GddCustomerTimeBase002 = timeBaseID;
  StbM_GddCustomerGlobalTime002Count++;
}

boolean TestGlobalTimeCustomer002_CallbackFunction
(App_DataValidateType LucDataValidate, StbM_SynchronizedTimeBaseType timeBaseID,
 StbM_TickType ticks)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((timeBaseID == StbM_GddCustomerTimeBase002) &&
      (StbM_GddCustomerGlobalTime002 == ticks) &&
      (1 == StbM_GddCustomerGlobalTime002Count))
      {
        LblStepResult = STEP_PASSED;
        StbM_GddCustomerGlobalTime002Count = 0;
      }
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(StbM_GddCustomerGlobalTime002Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
}
#endif /* #ifdef STBM_MODULE_ACTIVE */

#ifdef NM_MODULE_ACTIVE
/******************************************************************************/
/*             Rte_Nm_CarWakeUpIndication                                     */
/*****************************************************************************/
void Rte_Nm_CarWakeUpIndication(const NetworkHandleType nmChannelHandle)
{
  Nm_GddChnlHandle = nmChannelHandle; 
  Nm_GucChnlHandlCount++;
}

/*******************************************************************************
**                       TestRte_Nm_CarWakeUpIndication()                     **
*******************************************************************************/
boolean TestRte_Nm_CarWakeUpIndication (App_DataValidateType LucDataValidate,
   NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((Nm_GucChnlHandlCount == 0x01)&&
        (ExpChannelHandle == Nm_GddChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Nm_GucChnlHandlCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestRte_Nm_CarWakeUpIndication() */

#endif

/*******************************************************************************
**                         TestRte_DefaultBehavior()                          **
*******************************************************************************/
void TestRte_DefaultBehavior(void)
{
  #ifdef COMM_MODULE_ACTIVE
  uint8 Lucindex;
  Rte_GucComModeIndicationCount = 0;
  Rte_GddMode = 0;
  Rte_GucWriteCount = 0;
  for(Lucindex = 0; Lucindex < 5; Lucindex++)
  {
    Rte_Gddnoofreq[Lucindex] = 0;
    Rte_Gdduserid[Lucindex] = 0;
  }
  #endif
  
  #ifdef DLT_MODULE_ACTIVE
  uint8 LucIndex;
  for(LucIndex = 0; LucIndex < 4; LucIndex++)
  {
    Dlt_GaaSetVal0app_id[LucIndex] = 0;
    Dlt_GaaSetVal1app_id[LucIndex] = 0;
    Dlt_GaaSetVal2app_id[LucIndex] = 0;
    Dlt_GaaSetVal3app_id[LucIndex] = 0;
    Dlt_GaaSetVal0context_id[LucIndex] = 0;
    Dlt_GaaSetVal1context_id[LucIndex] = 0;
    Dlt_GaaSetVal2context_id[LucIndex] = 0;
    Dlt_GaaSetVal3context_id[LucIndex] = 0;
  }
  Dlt_Gddloglevel = DLT_LOG_OFF;
  Dlt_Gblnew_trace_status = 0;
  Dlt_Gblis_verbose_mode = 0;
  Dlt_Gucservice_id = 0;
  Dlt_Gucdata_length = 0;
  #endif
  
  #ifdef COM_MODULE_ACTIVE
  GucSeqCount = 0;
  Com_GblTxTOutS4 = FALSE;
  Com_GblTxTOutS5 = FALSE;
  Com_GblTxTOutS6 = FALSE;
  Com_GblTxTOutS7 = FALSE;
  Com_GblTxTOutS8 = FALSE;
  Com_GblRxTOutS7 = FALSE;
  Com_GblRxTOutS8 = FALSE;
  Com_GblRxTOutS9 = FALSE;
  Com_GblRxTOutS10 = FALSE;
  Com_GblRxTOutS11 = FALSE;
  Com_GblRxTOutS12 = FALSE;
  Com_GblRxTOutS28 = FALSE;
  Com_GblRxTOutS29 = FALSE;
  Com_GblRxTOutS30 = FALSE;
  Com_GblRxTOutS1 = FALSE;
  Com_GblRxTOutS2 = FALSE;
  Com_GblRxTOutS3 = FALSE;
  Com_GblRxTOutS4 = FALSE;
  Com_GblRxTOutS5 = FALSE;
  Com_GblRxTOutS6 = FALSE;
  Com_GblRxTOutS34 = FALSE;
  Com_GblRxTOutS35 = FALSE;
  Com_GblRxTOutS36 = FALSE;
  Com_GblRxTOutS31 = FALSE;
  Com_GblRxTOutS32 = FALSE;
  Com_GblRxTOutS33 = FALSE;
  Com_GblRxTOutSg3 = FALSE;
  Com_GblRxTOutSg2 = FALSE;
  Com_GblRxTOutSg5 = FALSE;
  Com_GblRxTOutSg6 = FALSE;
  Com_GblRxTOutSg1 = FALSE;
  Com_GblTACks3 = FALSE;
  Com_GblTACks4 = FALSE;
  Com_GblTACks5 = FALSE;
  Com_GblTACks6 = FALSE;
  Com_GblTACks2 = FALSE;
  Com_GblTACkSg1 = FALSE;
  Com_GblTACkSg3 = FALSE;
  Com_GblTACkSg4 = FALSE;
  Com_GblTACkSg5 = FALSE;
  Com_GblComCbk3 = FALSE;
  Com_GblCbkInv4 = FALSE;
  Com_GblComCbk5 = FALSE;
  Com_GblComCbk6 = FALSE;
  Com_GblComCbk7 = FALSE;
  Com_GblComCbk8 = FALSE;
  Com_GblComCbk9 = FALSE;
  Com_GblComCbk10 = FALSE;
  Com_GblComCbk14 = FALSE;
  Com_GblComCbk15 = FALSE;
  Com_GblComCbk16 = FALSE;
  Com_GblComCbk17 = FALSE;
  Com_GblComCbk18 = FALSE;
  Com_GblComCbk19 = FALSE;
  Com_GblComCbk20 = FALSE;
  Com_GblComCbk23 = FALSE;
  Com_GblComCbk24 = FALSE;
  Com_GblComCbk25 = FALSE;
  Com_GblComCbk26 = FALSE;
  Com_GblComCbk27 = FALSE;
  Com_GblComCbk28 = FALSE;
  Com_GblComCbk29 = FALSE;
  Com_GblComCbk30 = FALSE;
  Com_GblComCbk31 = FALSE;
  Com_GblComCbk31 = FALSE;
  Com_GblComCbk33 = FALSE;
  Com_GblComCbk34 = FALSE;
  Com_GblComCbk35 = FALSE;
  Com_GblComCbk36 = FALSE;
  Com_GblComCbk37 = FALSE;
  Com_GblComCbk38 = FALSE;
  Com_GblComCbk39 = FALSE;
  Com_GblComCbk40 = FALSE;
  Com_GblComCbk41 = FALSE;
  Com_GblComCbk42 = FALSE;
  Com_GblComCbk43 = FALSE;
  Com_GblComCbk44 = FALSE;
  Com_GblComCbk45 = FALSE;
  Com_GblComCbk46 = FALSE;
  Com_GblComCbk47 = FALSE;
  Com_GblComCbk48 = FALSE;
  Com_GblComCbk49 = FALSE;
  Com_GblComCbk50 = FALSE;
  Com_GblComCbk51 = FALSE;
  Com_GblComCbk52 = FALSE;
  Com_GblComCbk53 = FALSE;
  Com_GblComCbk54 = FALSE;
  Com_GblComCbk55 = FALSE;
  Com_GblComCbk56 = FALSE;
  Com_GblComCbk57 = FALSE;
  Com_GblComCbk58 = FALSE;
  Com_GblComCbk59 = FALSE;
  Com_GblComCbk60 = FALSE;
  Com_GblComCbk61 = FALSE;
  Com_GblComCbk62 = FALSE;
  Com_GblComCbk63 = FALSE;
  Com_GblCbkInv9 = FALSE;
  Com_GblCbkInv14 = FALSE;
  Com_GblCbkInv16 = FALSE;
  Com_GblComCbkSg1 = FALSE;
  Com_GblComCbkSg2 = FALSE;
  Com_GblComCbkSg10 = FALSE;
  Com_GblCbkInvSg3 = FALSE;
  Com_GblCbkInvSg4 = FALSE;
  Com_GblCbkInvSg5 = FALSE;
  Com_GblCbkInvSg6 = FALSE;
  Com_GblCbkInvS1 = FALSE;
  Com_GblCbkInvSg1 = FALSE;
  Com_GblCbkInvSg2 = FALSE;
  Com_GblComCbk1 = FALSE;
  Com_GblTACks1 = FALSE;
  Com_GblTACkSg2 = FALSE;
  Com_GblComCbk2 = FALSE;
  Com_GblTxTOutSg2 = FALSE;
  Com_GblTxTOutS3 = FALSE;
  Com_GblTxTOutS1 = FALSE;
  Com_GblTxTOutS2 = FALSE;
  Com_GblTxTOutSg1 = FALSE;
  Com_GblRxTOutS21 = FALSE;
  Com_GblRxTOutSg8 = FALSE;
  Com_GblTErrS4 = FALSE;
  Com_GblCbkInvS17 = FALSE;
  Com_GblCbkInvS11 = FALSE;
  Com_GblCbkInvS21 = FALSE;
  Com_GblCbkInvS15 = FALSE;
  Com_GblCbkInvS19 = FALSE;
  Com_GblCbkInvS63 = FALSE;
  Com_GblCbkInvS2 = FALSE;
  Com_GblCbkInvS7 = FALSE;
  Com_CallOutRetVal = TRUE;
  Com_CallOutRxRetVal = TRUE;
  Com_CallOutCount = 0;
  Com_Rx_CallOutCount = 0;
  #endif
  
  #ifdef BSWM_MODULE_ACTIVE
  Rte_GucRead_Port1_VariableDataProtoType1Count = 0;
  Rte_GucNotification_Port1_ModeDeclarationGroupProtoType1Count = 0;
  Rte_GucSwitch_Port1_ModeDeclarationGroupProtoType1Count = 0;
  Rte_GucMode_Port1_ModeDeclarationGroupProtoType1Count = 0;
  Rte_GucPartitionResetCount = 0;
  #endif
  
  #ifdef DCM_MODULE_ACTIVE
  Dcm_GddRteGeneralReturn = E_OK;
  Dcm_GucRteGeneralCountkey = 0;
  Dcm_GucRteGeneralCount = 0;
  Dcm_GucRteGeneralCountCheck = 0;
  Dcm_GucRteGeneralCountseed = 0;
  Dcm_GddGeneralOpStatus = DCM_INITIAL;
  Dcm_GddGeneralNegativeError =  0;
  Dcm_GucRteGeneralCount = 0;
  Dcm_GucRteReadCount = 0;
  Dcm_GddRteReadDataReturn = E_OK;
  Dcm_GucRteGeneralCountkey = 0;
  #endif
  
  #ifdef DEM_MODULE_ACTIVE
  Rte_GucDemGlobalCount = 0;
  for(GucIndex = 0; GucIndex < 4; GucIndex++)
  {
    Rte_GaaDataBuffer1[GucIndex] = 0;
  } 
  #endif
  
  #ifdef NM_MODULE_ACTIVE
  Nm_GddChnlHandle = 0; 
  Nm_GucChnlHandlCount = 0;
  #endif
}

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
