/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: IpduM_Cbk.h                                                   **      
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR IpduM_Cbk module                                      **
**                                                                            **
**  PURPOSE   : Declaration of IpduM_Cbk Stub functions                       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/
#ifndef IPDUM_CBK_H
#define IPDUM_CBK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void IpduM_TxConfirmation(PduIdType TxPduId);

extern boolean TestIpduM_TxConfirmation(App_DataValidateType LucDataValidate,
  PduIdType ExpTxPduId);

extern void IpduM_RxIndication(PduIdType RxPduId, 
  PduInfoType *PduInfoPtr);

extern boolean TestIpduM_RxIndication(App_DataValidateType LucDataValidate,
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr);

extern void TestPduR_IpduMRxIndDefBehavior(void);

extern Std_ReturnType IpduM_TriggerTransmit(PduIdType TxPduId,
  PduInfoType *PduInfoPtr);

extern boolean TestIpduM_TriggerTransmit(App_DataValidateType LucDataValidate,
  PduIdType ExpTxPduId, PduInfoType *ExpPduInfoPtr);

extern void TestIpduM_TriggerTransmitSetRetVal(Std_ReturnType RetVal,
  PduInfoType *SetPduInfoPtr);

extern boolean IpduMTest_ValidateData(PduInfoType* LddExpPduInfo,
  PduInfoType* LddActPduInfo);

#endif /* IPDUM_CBK_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
