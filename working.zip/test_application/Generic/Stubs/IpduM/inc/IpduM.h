/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: IpduM.h                                                       **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR IpduM module                                          **
**                                                                            **
**  PURPOSE   : Declaration of IpduM Stub functions                           **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/
#ifndef IPDUM_H
#define IPDUM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define IPDUM_AR_RELEASE_MAJOR_VERSION         0x04
#define IPDUM_AR_RELEASE_MINOR_VERSION         0x00
#define IPDUM_AR_RELEASE_REVISION_VERSION      0x03

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define IPDUM_DATA_LENGTH                      0x08
#define IPDUM_ARRAY_SIZE                       0x04

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
typedef uint8 IpduM_ConfigType;

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Std_ReturnType IpduM_Transmit(PduIdType IpduMTxPduId,
  const PduInfoType *PduInfoPtr);

extern void TestIpduM_TransmitSetRetVal(Std_ReturnType LddRetVal);

extern boolean TestIpduM_Transmit(App_DataValidateType LucDataValidate,
  PduIdType ExpIpduMTxPduId, const PduInfoType *ExpPduInfoPtr);

extern void TestIpduM_DefaultBehavior(void);
extern void IpduM_Init(const IpduM_ConfigType* config);

extern boolean TestIpduM_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
#endif /* IPDUM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
