/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: IpduM.c                                                       **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR IpduM module                                          **
**                                                                            **
**  PURPOSE   : This application file contains the IpduM Stub functions       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "IpduM.h"
#include "IpduM_Cbk.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Version Check                                         **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
PduIdType IpduM_GaaTxConfPduId[IPDUM_ARRAY_SIZE];
uint8 IpduM_GucTxConfCount;
uint8 IpduM_GucTxConfCheckCount;

PduIdType IpduM_GaaRxIndPduId[IPDUM_ARRAY_SIZE];
uint8 IpduM_GaaRxIndSduLength[IPDUM_ARRAY_SIZE];
uint8 IpduM_GaaRxIndSduData[IPDUM_ARRAY_SIZE][IPDUM_DATA_LENGTH];
uint8 IpduM_GucRxIndCount;
uint8 IpduM_GucRxIndCheckCount;

PduIdType IpduM_GddTrigTransTxPduId;
uint8 IpduM_GucTrigTransCount;
uint8 IpduM_GucTrigTransSetSduLength;
uint8 IpduM_GaaTrigTransSetData[IPDUM_DATA_LENGTH];
Std_ReturnType IpduM_GddTrigTransRetVal;

PduIdType IpduM_GddIpduMTxPduId;
uint8 IpduM_GddSduLength;
uint8 IpduM_GaaTransmitData[IPDUM_DATA_LENGTH];
Std_ReturnType IpduM_GddTransmitReturn;
uint8 IpduM_GucTransmitCount;
#ifdef BSWM_MODULE_ACTIVE
uint8 IpduM_GucInitCnt;
uint8 IpduM_GucInitSeqCnt;
#endif
/*******************************************************************************
**                     TestIpduM_DefaultBehavior()                            **
*******************************************************************************/
void TestIpduM_DefaultBehavior(void)
{
  uint8 LucDataIndex;
  
  IpduM_GucTxConfCount = 0x00;
  IpduM_GucTxConfCheckCount = 0x00;
  IpduM_GucRxIndCount = 0x00;
  IpduM_GucRxIndCheckCount = 0x00;
  IpduM_GucTrigTransCount = 0x00;
  IpduM_GddTrigTransRetVal = E_OK;
  IpduM_GucTrigTransSetSduLength = 0x08;
  for(LucDataIndex = 0x00; LucDataIndex < IPDUM_DATA_LENGTH; LucDataIndex++)
  {
    IpduM_GaaTrigTransSetData[LucDataIndex] = LucDataIndex;
  }
  IpduM_GucTransmitCount = 0;
  IpduM_GddTransmitReturn = E_OK;
}/* End TestIpduM_DefaultBehavior() */

/*******************************************************************************
**                         IpduM_TxConfirmation()                             **
*******************************************************************************/
void IpduM_TxConfirmation(PduIdType TxPduId)
{
  /* Load actual PduId into Global variables */
  IpduM_GaaTxConfPduId[IpduM_GucTxConfCount] = TxPduId;
  /* Increment count variable to handle multiple invocations */
  if(IpduM_GucTxConfCount != IPDUM_ARRAY_SIZE)
  {    
    IpduM_GucTxConfCount++;
  }
} /* End IpduM_TxConfirmation() */

/*******************************************************************************
**                       TestIpduM_TxConfirmation()                           **
*******************************************************************************/
boolean TestIpduM_TxConfirmation(App_DataValidateType LucDataValidate,
PduIdType ExpTxPduId)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count and Id */
      if((IpduM_GucTxConfCount == 0x01) && 
        (ExpTxPduId == IpduM_GaaTxConfPduId[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      IpduM_GucTxConfCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(IpduM_GucTxConfCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < IpduM_GucTxConfCount; LucIndex++)
      {
        if(ExpTxPduId == IpduM_GaaTxConfPduId[LucIndex])
        {
          LblRetValue = STEP_PASSED;          
          LucIndex = IpduM_GucTxConfCount;
        } /* End if(ExpTxPduId == IpduM_GaaTxConfPduId[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < IpduM_GucTxConfCount; ...) */
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      IpduM_GucTxConfCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(IpduM_GucTxConfCount == IpduM_GucTxConfCheckCount)
      {
        IpduM_GucTxConfCount = 0;
        IpduM_GucTxConfCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < IpduM_GucTxConfCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpTxPduId == IpduM_GaaTxConfPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestIpduM_TxConfirmation() */

/*******************************************************************************
**                       IpduM_RxIndication()                                 **
*******************************************************************************/
void IpduM_RxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr)
{
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8* LpSduDataPtr;
  
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  IpduM_GaaRxIndPduId[IpduM_GucRxIndCount] = RxPduId;
  IpduM_GaaRxIndSduLength[IpduM_GucRxIndCount] = PduInfoPtr->SduLength;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > IPDUM_DATA_LENGTH)
  {
    LucDataLength = IPDUM_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->SduLength;
  }
  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0x00; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    IpduM_GaaRxIndSduData[IpduM_GucRxIndCount][LucDataIndex] = *LpSduDataPtr;
    LpSduDataPtr++;
  }
  /* Increment count variable to handle multiple invocations */
  if(IpduM_GucRxIndCount != IPDUM_ARRAY_SIZE)
  {    
    IpduM_GucRxIndCount++;
  }
} /* End IpduM_RxIndication()*/

/*******************************************************************************
**                       TestIpduM_RxIndication()                             **
*******************************************************************************/
boolean TestIpduM_RxIndication(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((IpduM_GucRxIndCount == 0x01) && (ExpRxPduId == IpduM_GaaRxIndPduId[0]))
      {
        ActPduInfo.SduLength = IpduM_GaaRxIndSduLength[0];
        ActPduInfo.SduDataPtr = &IpduM_GaaRxIndSduData[0][0];

        /* Validate SduLength and Data */
        if(IpduMTest_ValidateData(ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      IpduM_GucRxIndCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(IpduM_GucRxIndCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < IpduM_GucRxIndCount; LucIndex++)
      {
        if(ExpRxPduId == IpduM_GaaRxIndPduId[LucIndex])
        {
          ActPduInfo.SduLength = IpduM_GaaRxIndSduLength[LucIndex];
          ActPduInfo.SduDataPtr = &IpduM_GaaRxIndSduData[LucIndex][0];

          if(IpduMTest_ValidateData((PduInfoType *)ExpPduInfoPtr, &ActPduInfo))
          {
            LblRetValue = STEP_PASSED;
          }
          LucIndex = IpduM_GucRxIndCount;
        } /* End if(ExpRxPduId == IpduM_GaaRxIndPduId[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < IpduM_GucRxIndCount; ...) */
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      IpduM_GucRxIndCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(IpduM_GucRxIndCount == IpduM_GucRxIndCheckCount)
      {
        IpduM_GucRxIndCount = 0;
        IpduM_GucRxIndCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < IpduM_GucRxIndCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpRxPduId == IpduM_GaaRxIndPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    } /* End case M_NOT_INVOKED: */
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestIpduM_RxIndication() */

/*******************************************************************************
**                       IpduM_TriggerTransmit()                              **
*******************************************************************************/
Std_ReturnType IpduM_TriggerTransmit(PduIdType TxPduId, PduInfoType *PduInfoPtr)
{
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8 *LpSduDataPtr;
  
  /* Load actual PduId, and adress of PduInfoPtr into Global variables */
  IpduM_GddTrigTransTxPduId = TxPduId;
  /* Copy the actual SduLength into actual SduDataPtr from global SduLength  */
  PduInfoPtr->SduLength = IpduM_GucTrigTransSetSduLength;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > IPDUM_DATA_LENGTH)
  {
    LucDataLength = IPDUM_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->SduLength;
  }
  
  /* Copy the actual data into actual SduDataPtr from global array */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    *LpSduDataPtr = IpduM_GaaTrigTransSetData[LucDataIndex];
    LpSduDataPtr++;
  }
  IpduM_GucTrigTransCount++;
  return(IpduM_GddTrigTransRetVal);
}

/*******************************************************************************
**                       TestIpduM_TriggerTransmit()                          **
*******************************************************************************/
boolean TestIpduM_TriggerTransmit(App_DataValidateType LucDataValidate, 
PduIdType ExpTxPduId, PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  UNUSED(ExpPduInfoPtr);

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((IpduM_GucTrigTransCount == 0x01) && 
        (ExpTxPduId == IpduM_GddTrigTransTxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      IpduM_GucTrigTransCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(IpduM_GucTrigTransCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestIpduM_TriggerTransmit() */

/*******************************************************************************
**                       TestIpduM_TriggerTransmitSetRetVal()                 **
*******************************************************************************/
void TestIpduM_TriggerTransmitSetRetVal(Std_ReturnType RetVal, 
  PduInfoType *SetPduInfoPtr)
{
  uint8* LpSduDataPtr;
  uint8 LucDataLength;
  uint8 LucDataIndex;
  IpduM_GddTrigTransRetVal = RetVal;
  IpduM_GucTrigTransSetSduLength = SetPduInfoPtr->SduLength;
  LpSduDataPtr = SetPduInfoPtr->SduDataPtr;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(SetPduInfoPtr->SduLength > IPDUM_DATA_LENGTH)
  {
    LucDataLength = IPDUM_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = SetPduInfoPtr->SduLength;
  }
  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    IpduM_GaaTrigTransSetData[LucDataIndex] = *LpSduDataPtr;
    LpSduDataPtr++;
  }  
} /* End TestIpduM_TriggerTransmitSetRetVal() */

/*******************************************************************************
**                              IpduM_Transmit()                              **
*******************************************************************************/
Std_ReturnType IpduM_Transmit(PduIdType IpduMTxPduId,
const PduInfoType *PduInfoPtr)
{
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8* LpSduDataPtr;
  
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  IpduM_GddIpduMTxPduId = IpduMTxPduId;
  IpduM_GddSduLength = PduInfoPtr->SduLength;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > IPDUM_DATA_LENGTH)
  {
    LucDataLength = IPDUM_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->SduLength;
  }   
  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    IpduM_GaaTransmitData[LucDataIndex] = 
      *LpSduDataPtr;
    LpSduDataPtr++;
  }
  /* Increment count variable to handle multiple invocations */
  if(IpduM_GucTransmitCount != IPDUM_ARRAY_SIZE)
  {    
    IpduM_GucTransmitCount++;
  }
  return(IpduM_GddTransmitReturn);
} /* End IpduM_Transmit() */

/*******************************************************************************
**                            TestIpduM_Transmit()                            **
*******************************************************************************/
boolean TestIpduM_Transmit(App_DataValidateType LucDataValidate,
PduIdType ExpIpduMTxPduId, const PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((IpduM_GucTransmitCount == 0x01) && 
        (ExpIpduMTxPduId == IpduM_GddIpduMTxPduId))
      {
        ActPduInfo.SduLength = IpduM_GddSduLength;
        ActPduInfo.SduDataPtr = &IpduM_GaaTransmitData[0];

        /* Validate SduLength and Data */
        if(IpduMTest_ValidateData((PduInfoType *)ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      IpduM_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(IpduM_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestIpduM_Transmit() */

/*******************************************************************************
**                          TestIpduM_TransmitSetRetVal()                     **
*******************************************************************************/
void TestIpduM_TransmitSetRetVal(Std_ReturnType LddRetVal)
{
  IpduM_GddTransmitReturn = LddRetVal;
}/* End TestIpduM_TransmitSetRetVal() */

/*******************************************************************************
**                       IpduMTest_ValidateData()                             **
*******************************************************************************/
boolean IpduMTest_ValidateData(PduInfoType* LddExpPduInfo, 
  PduInfoType* LddActPduInfo)
{
  uint8 *LpActualDataPtr;
  uint8 *LpExpDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  LddSduCount = LddExpPduInfo->SduLength;
  LpExpDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  if((LddExpPduInfo->SduLength <= IPDUM_DATA_LENGTH) &&
    (LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }

  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    if(*LpActualDataPtr != *LpExpDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualDataPtr++;
    LpExpDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* End IpduMTest_ValidateData() */
#ifdef BSWM_MODULE_ACTIVE
/*******************************************************************************
**                          IpduM_Init()                                      **
*******************************************************************************/

void IpduM_Init(const IpduM_ConfigType* config)
{
  UNUSED(config);
  App_GucApiSeqCnt++;
  IpduM_GucInitSeqCnt = App_GucApiSeqCnt;
  IpduM_GucInitCnt++;
}/* End IpduM_Init() */

/*******************************************************************************
**                           TestIpduM_Init()                                 **
*******************************************************************************/
boolean TestIpduM_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(IpduM_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      IpduM_GucInitCnt = 0;
      IpduM_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(IpduM_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      IpduM_GucInitCnt = 0;
      IpduM_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestIpduM_Init() */

#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

