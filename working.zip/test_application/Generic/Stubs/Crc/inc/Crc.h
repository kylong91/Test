/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Crc.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Crc Library Module                                    **
**                                                                            **
**  PURPOSE   : Provision of Macros and API Prototype Declarations            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     27-Dec-2012   Kiranmai    Initial Version                        *******************************************************************************/
#ifndef CRC_H
#define CRC_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define CRC_AR_RELEASE_MAJOR_VERSION         4
#define CRC_AR_RELEASE_MINOR_VERSION         0
#define CRC_AR_RELEASE_REVISION_VERSION      3

/* Software Version Information */
#define CRC_SW_MAJOR_VERSION      1
#define CRC_SW_MINOR_VERSION      0

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Global Function Prototypes                            **
*******************************************************************************/
extern uint8 Crc_CalculateCRC8(const uint8* Crc_DataPtr, uint32 Crc_Length, 
  uint8 Crc_StartValue8, boolean Crc_IsFirstCall);

extern uint8 Crc_CalculateCRC8H2F(const uint8* Crc_DataPtr, uint32 Crc_Length, 
  uint8 Crc_StartValue8H2F, boolean Crc_IsFirstCall);

extern uint16 Crc_CalculateCRC16(const uint8* Crc_DataPtr, uint32 Crc_Length, 
  uint16 Crc_StartValue16, boolean Crc_IsFirstCall);

extern uint32 Crc_CalculateCRC32(const uint8* Crc_DataPtr, uint32 Crc_Length, 
  uint32 Crc_StartValue32, boolean Crc_IsFirstCall);

extern boolean TestCrc_CalculateCRC8(App_DataValidateType LucDataValidate, 
  const uint8* LpExpCrc_DataPtr, uint32 LucExpCrc8Length, 
  uint8 LucExpCrcStartValue8, boolean Crc_IsFirstCall);
	
extern boolean TestE2E_Crc_CalculateCRC8 (App_DataValidateType LucDataValidate, 
  uint8 LucExpCrcValue, const uint8 *LpExpCrc_DataPtr, uint32 LucExpCrc8Length, 
  uint8 LucExpCrcStartValue8, boolean Crc_IsFirstCall);
	
extern boolean TestCrc_CalculateCRC8H2F(App_DataValidateType LucDataValidate, 
  const uint8* LpExpCrc_DataPtr, uint32 LucExpCrc8Length, 
  uint8 LucExpCrcStartValue8, boolean Crc_IsFirstCall);
 
extern boolean TestE2E_Crc_CalculateCRC8H2F (App_DataValidateType LucDataValidate, 
  uint8 LucExpCrcValue, const uint8 *LpExpCrc_DataPtr, 
	uint32 LucExpCrc8H2FLength, uint8 LucExpCrcStartValue8H2F, 
	boolean Crc_IsFirstCall);
	
extern boolean TestCrc_CalculateCRC16(App_DataValidateType LucDataValidate, 
  const uint8* LpExpCrc_DataPtr, uint32 LucExpCrc16Length, 
  uint16 LucExpCrcStartValue16, boolean Crc_IsFirstCall);
  
extern boolean TestCrc_CalculateCRC32(App_DataValidateType LucDataValidate, 
  const uint8* LpExpCrc_DataPtr, uint32 LucExpCrc32Length, 
  uint32 LucExpCrcStartValue32, boolean Crc_IsFirstCall);

extern void App_TestPrepareCrcVal(uint8 LucCrcVal);
extern void App_TestPrepareCrcVal16(uint8 LucCrcVal);
extern void App_TestPrepareCrcVal32(uint8 LucCrcVal);

extern void TestCRC8_DefaultBehaviour(void);
extern void TestCRC16_DefaultBehaviour(void);
extern void TestCRC32_DefaultBehaviour(void);

extern void TestCrc_Crc_CalculateCRC8DefaultSetBeh(void);

extern void App_TestRestGlobalArrayCount(void);

extern void App_TestRest8H2FGlobalArrayCount(void);

extern void App_TestPrepareCrc8H2FVal(uint8 LucCrcVal);

extern void TestCrc_Crc_CalculateCRC8H2FDefaultSetBeh(void);

#endif  /* CRC_H */

/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
