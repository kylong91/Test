/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Crc_8H2F.c                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Crc Library Module                                    **
**                                                                            **
**  PURPOSE   : Implementation for 8-bit CRC functions with polynomial 0x2F   **
**              of Crc Library Module                                         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     23-Nov-2011   SLM    Initial Version                             **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Crc.h"                     /* Crc Header file */
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define CRC_8H2F_C_AR_RELEASE_MAJOR_VERSION      4
#define CRC_8H2F_C_AR_RELEASE_MINOR_VERSION      0
#define CRC_8H2F_C_AR_RELEASE_REVISION_VERSION   2

/* Software Version Information */
#define CRC_8H2F_C_SW_MAJOR_VERSION      4
#define CRC_8H2F_C_SW_MINOR_VERSION      0

/*******************************************************************************
**                      Version Check                                         **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#ifdef E2E_MODULE_ACTIVE
uint8 GucCrc8H2FCount;
uint8 GucDataIndex;
uint8 GucArrayIndex;
uint8 GucCrcVal;
uint32 GucCrc8H2FLength[50];
uint8 GucCrcStartValue8H2F[50];
uint8 GucCrcValue[50];
boolean GblCRCFirstCall[50];
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
** Function Name        : Crc_CalculateCRC8H2F                                **
**                                                                            **
** Service ID           : 0x05                                                **
**                                                                            **
** Description          : This function returns the 8 bit checksum calculated **
**                        using polynomial 0x2F by runtime and table method.  **
**                                                                            **
** Reentrancy           : Reentrant                                           **
**                                                                            **
** Input Parameters     : Crc_DataPtr, Crc_Length, Crc_StartValue8H2F,        **
**                        Crc_IsFirstCall                                     **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : 8 bit result of CRC calculation                     **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)     : Crc_GaaTable8H2F[]         **
**                        Function(s) invoked    : None                       **
*******************************************************************************/

#define CRC_START_SEC_CODE
#include "MemMap.h"
void TestCrc_Crc_CalculateCRC8H2FDefaultSetBeh(void)
{
  
  uint8 LucIndex;
	GucCrc8H2FCount = 0 ;
  GucDataIndex = 0;
  GucCrcVal = 0;
	GucArrayIndex=0;
 	for (LucIndex = 0; LucIndex < 15; LucIndex++)
	{
	  GucCrc8H2FLength[LucIndex] = 0;
    GucCrcStartValue8H2F[LucIndex] = 0;
    GucCrcValue[LucIndex] = 0;
    GblCRCFirstCall[LucIndex] = 0;
	}
}
#define CRC_STOP_SEC_CODE
#include "MemMap.h"

#define CRC_START_SEC_CODE
#include "MemMap.h"

void App_TestPrepareCrc8H2FVal(uint8 LucCrcVal)
{
  GucCrcVal = LucCrcVal;
} /* End App_TestPrepareCrcVal() */

#define CRC_STOP_SEC_CODE
#include "MemMap.h"

#define CRC_START_SEC_CODE
#include "MemMap.h"

void App_TestRest8H2FGlobalArrayCount(void)
{
  GucDataIndex = 0;
	GucCrc8H2FCount = 0;
	GucArrayIndex = 0;
} /* End App_TestRestGlobalArrayCount */

#define CRC_STOP_SEC_CODE
#include "MemMap.h"

#define CRC_START_SEC_CODE
#include "MemMap.h"

uint8 Test_ValidateDataCrc8H2F(uint8 *LpExpCrc_DataPtr, uint8 *ActData, 
                                                     uint32 LucExpCrc8H2FLength)
{
   uint8 LucIndex;
	 
	  for (LucIndex = 0; LucIndex < LucExpCrc8H2FLength; LucIndex++)
	  {
	    if ( *ActData == *LpExpCrc_DataPtr)
			{
			  ActData++;
				LpExpCrc_DataPtr++;
				GucDataIndex++;
			}
			else
			{
			  return 0;
			}		
		}
	return (1);
}								
#define CRC_STOP_SEC_CODE
#include "MemMap.h"

#define CRC_START_SEC_CODE
#include "MemMap.h"
FUNC(uint8, CRC_CODE) Crc_CalculateCRC8H2F
  (P2CONST(uint8, CRC_CONST, CRC_APPL_CONST)Crc_DataPtr, uint32 Crc_Length,
  uint8 Crc_StartValue8H2F, boolean Crc_IsFirstCall)
{
  P2CONST(uint8, CRC_CONST, CRC_APPL_CONST) LpDataPtr;
	uint8 LucDataIndex;
	/* For testing CRC stub */
	GucCrc8H2FLength[GucCrc8H2FCount] = Crc_Length;
	GucCrcStartValue8H2F[GucCrc8H2FCount] = Crc_StartValue8H2F;
	GblCRCFirstCall[GucCrc8H2FCount] = Crc_IsFirstCall;
	LpDataPtr = Crc_DataPtr;
	/* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0x00; LucDataIndex < GucCrc8H2FLength[GucCrc8H2FCount]; 
	                                                               LucDataIndex++)
  {
    GucCrcValue[GucDataIndex] = *LpDataPtr;
    LpDataPtr++;
		GucDataIndex++;
  }
	GucCrc8H2FCount++;
	/* Return the CRC result */
  return (GucCrcVal);
}
#define CRC_STOP_SEC_CODE
#include "MemMap.h"

#define CRC_START_SEC_CODE
#include "MemMap.h"

boolean TestE2E_Crc_CalculateCRC8H2F (App_DataValidateType LucDataValidate, 
  uint8 LucExpCrcValue, const uint8 *LpExpCrc_DataPtr, 
	uint32 LucExpCrc8H2FLength, uint8 LucExpCrcStartValue8H2F, 
	boolean Crc_IsFirstCall)
{
  boolean LblStepResult;
  uint8 *ActData;
  uint8 LucIndex;
	
  LblStepResult = STEP_FAILED;
	switch(LucDataValidate)
  {
    case S_VALIDATE:
          if ((GucCrc8H2FLength[GucArrayIndex] == LucExpCrc8H2FLength) &&
						 (GucCrcStartValue8H2F[GucArrayIndex] == LucExpCrcStartValue8H2F) &&
						 (GblCRCFirstCall[GucArrayIndex] == Crc_IsFirstCall) &&
						 (GucCrcVal = LucExpCrcValue))
          {
					  ActData = &GucCrcValue[GucDataIndex];
						if (Test_ValidateDataCrc8H2F((uint8 *)LpExpCrc_DataPtr, ActData, 
                LucExpCrc8H2FLength))
						{
						  LblStepResult = STEP_PASSED;
						}
					}	
					GucArrayIndex++;
					break;
    case M_VALIDATE :
          for (LucIndex = 0; LucIndex < GucCrc8H2FCount; LucIndex++)
          {
					  if ((GucCrc8H2FLength[LucIndex] == LucExpCrc8H2FLength) &&
						    (GucCrcStartValue8H2F[LucIndex] == LucExpCrcStartValue8H2F) &&
						    (GblCRCFirstCall[LucIndex] == Crc_IsFirstCall) &&
						    (GucCrcVal== LucExpCrcValue))
            {
					    
							ActData = &GucCrcValue[GucDataIndex];
						  if (Test_ValidateDataCrc8H2F((uint8 *)LpExpCrc_DataPtr, ActData, 
                LucExpCrc8H2FLength))
						  {
						    LblStepResult = STEP_PASSED;
						  }
						} 
          }
					GucCrc8H2FCount = 0;
					break;
    case S_NOT_INVOKED :
          if (GucCrc8H2FCount == 0)
          {
           LblStepResult = STEP_PASSED;
          }
          break;
    default :
          LblStepResult = STEP_FAILED;
          break;		
	}
	return (LblStepResult);
}
#define CRC_STOP_SEC_CODE
#include "MemMap.h"
#endif
/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
