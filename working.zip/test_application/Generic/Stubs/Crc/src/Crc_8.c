/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Crc_8.c                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Crc Library Module                                    **
**                                                                            **
**  PURPOSE   : Implementation for 8-bit CRC functions of Crc Library Module  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By          Description                            **
********************************************************************************
** 1.0.0     27-Dec-2012   Kiranmai    Initial Version                        **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Crc.h"                     /* Crc Header file */
#ifdef NVM_MODULE_ACTIVE
#include "App_NvM_Sub_Functions.h"
#endif
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/*******************************************************************************
**                      Version Check                                         **
*******************************************************************************/
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 GucCrcVal8;
#ifdef E2E_MODULE_ACTIVE
uint8 GucCrc8Count;
uint8 GucDataIdx;
uint8 GucArrayIndex8;
uint32 GucCrc8Length[50];
uint8 GucCrcStartValue8[50];
uint8 GucCrcValue8[50];
boolean GblCRCFirstCall8[50];
#endif

#ifdef NVM_MODULE_ACTIVE
uint8 NvM_GucCrc8Count;
uint32 NvM_GucCrc8Length;
uint8 NvM_GucCrcStartValue8;
#endif
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
/*******************************************************************************
**                           App_TestPrepareCrcVal()                          **
*******************************************************************************/
void App_TestPrepareCrcVal(uint8 LucCrcVal)
{
  GucCrcVal8 = LucCrcVal;
} /* End App_TestPrepareCrcVal() */

#ifdef E2E_MODULE_ACTIVE
/*******************************************************************************
**                      TestCrc_Crc_CalculateCRC8DefaultSetBeh                **
*******************************************************************************/
void TestCrc_Crc_CalculateCRC8DefaultSetBeh(void)
{
  uint8 LucIndex;
	GucCrc8Count = 0 ;
  GucDataIdx = 0;
  GucCrcVal8 = 0;
	GucArrayIndex8=0;
 	for (LucIndex = 0; LucIndex < 15; LucIndex++)
	{
	  GucCrc8Length[LucIndex] = 0;
    GucCrcStartValue8[LucIndex] = 0;
    GucCrcValue8[LucIndex] = 0;
    GblCRCFirstCall8[LucIndex] = 0;
	}
}

/*******************************************************************************
**                           App_TestRestGlobalArrayCount()                   **
*******************************************************************************/
void App_TestRestGlobalArrayCount(void)
{
  GucDataIdx = 0;
	GucCrc8Count = 0;
	GucArrayIndex8 = 0;
} /* End App_TestRestGlobalArrayCount */

/*******************************************************************************
**                           Test_ValidateData()                              **
*******************************************************************************/
uint8 Test_ValidateData(uint8 *LpExpCrc_DataPtr, uint8 *ActData, 
                                                       uint32 LucExpCrc8Length)
{
   uint8 LucIndex;
  
    for (LucIndex = 0; LucIndex < LucExpCrc8Length; LucIndex++)
    {
      if ( *ActData == *LpExpCrc_DataPtr)
      {
        ActData++;
        LpExpCrc_DataPtr++;
        GucDataIdx++;
      }
      else
      {
        return 0;
      }
    }
  return (1);
}
#endif

/*******************************************************************************
**                           Crc_CalculateCRC8()                              **
*******************************************************************************/

uint8 Crc_CalculateCRC8(const uint8* Crc_DataPtr, uint32 Crc_Length, 
  uint8 Crc_StartValue8, boolean Crc_IsFirstCall)
{
  #ifdef E2E_MODULE_ACTIVE
  P2CONST(uint8, CRC_CONST, CRC_APPL_CONST) LpDataPtr;
  uint8 LucDataIndex;
  /* For testing CRC stub */
  GucCrc8Length[GucCrc8Count] = Crc_Length;
  GucCrcStartValue8[GucCrc8Count] = Crc_StartValue8;
  GblCRCFirstCall8[GucCrc8Count] = Crc_IsFirstCall;
  LpDataPtr = Crc_DataPtr;
  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0x00; LucDataIndex < GucCrc8Length[GucCrc8Count]; 
                                                                LucDataIndex++)
  {
    GucCrcValue8[GucDataIdx] = *LpDataPtr;
    LpDataPtr++;
    GucDataIdx++;
  }
  GucCrc8Count++;
  #endif
  
  #ifdef NVM_MODULE_ACTIVE
  uint8 LucDataIndex;
  const uint8* LpDataPtr;
  
  NvM_GucCrc8Length = Crc_Length;
  NvM_GucCrcStartValue8 = Crc_StartValue8;
  LpDataPtr = Crc_DataPtr;
  UNUSED(Crc_IsFirstCall);
  
  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0x00; LucDataIndex < NvM_GucCrc8Length; LucDataIndex++)
  {
    NvM_GaaCrcDataPtr[LucDataIndex] = *LpDataPtr;
    LpDataPtr++;
  }
  NvM_GucCrc8Count++;
  #endif
  /* Return the CRC result */
  return (GucCrcVal8);
}

#ifdef E2E_MODULE_ACTIVE
/*******************************************************************************
**                           TestE2E_Crc_CalculateCRC8()                      **
*******************************************************************************/
boolean TestE2E_Crc_CalculateCRC8 (App_DataValidateType LucDataValidate, 
  uint8 LucExpCrcValue, const uint8 *LpExpCrc_DataPtr, uint32 LucExpCrc8Length, 
  uint8 LucExpCrcStartValue8, boolean Crc_IsFirstCall)
{
  boolean LblStepResult;
  uint8 *ActData;
  uint8 LucIndex;
	
  LblStepResult = STEP_FAILED;
	switch(LucDataValidate)
  {
    case S_VALIDATE:
          if ((GucCrc8Length[GucArrayIndex8] == LucExpCrc8Length) &&
						 (GucCrcStartValue8[GucArrayIndex8] == LucExpCrcStartValue8) &&
						 (GblCRCFirstCall8[GucArrayIndex8] == Crc_IsFirstCall) &&
						 (GucCrcVal8 = LucExpCrcValue))
          {
					  ActData = &GucCrcValue8[GucDataIdx];
						if (Test_ValidateData((uint8 *)LpExpCrc_DataPtr, ActData, 
                LucExpCrc8Length))
						{
						  LblStepResult = STEP_PASSED;
						}
					}	
					GucArrayIndex8++;
					break;
    case M_VALIDATE :
          for (LucIndex = 0; LucIndex < GucCrc8Count; LucIndex++)
          {
					  if ((GucCrc8Length[LucIndex] == LucExpCrc8Length) &&
						    (GucCrcStartValue8[LucIndex] == LucExpCrcStartValue8) &&
						    (GblCRCFirstCall8[LucIndex] == Crc_IsFirstCall) &&
						    (GucCrcVal8== LucExpCrcValue))
            {
					    
							ActData = &GucCrcValue8[GucDataIdx];
						  if (Test_ValidateData((uint8 *)LpExpCrc_DataPtr, ActData, 
                LucExpCrc8Length))
						  {
						    LblStepResult = STEP_PASSED;
						  }
						} 
          }
					GucCrc8Count = 0;
					break;
    case S_NOT_INVOKED :
          if (GucCrc8Count == 0)
          {
           LblStepResult = STEP_PASSED;
          }
          break;
    default :
          LblStepResult = STEP_FAILED;
          break;		
	}
	return (LblStepResult);
}
#endif

#ifdef NVM_MODULE_ACTIVE
/*******************************************************************************
**                          TestCrc_CalculateCRC8()                           **
*******************************************************************************/
boolean TestCrc_CalculateCRC8(App_DataValidateType LucDataValidate, 
  const uint8* LpExpCrc_DataPtr, uint32 LucExpCrc8Length, 
  uint8 LucExpCrcStartValue8, boolean Crc_IsFirstCall)
{
  boolean LblStepResult;
  uint8 *ActData;
  
  LblStepResult = STEP_FAILED;
  UNUSED(Crc_IsFirstCall);
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((NvM_GucCrc8Count == 0x01) 
        && (LucExpCrc8Length == NvM_GucCrc8Length) 
        && (LucExpCrcStartValue8 == NvM_GucCrcStartValue8))
      {
        ActData = &NvM_GaaCrcDataPtr[0];
        
        /* Validating the Data */
        if(NvMTest_ValidateData((uint8 *)LpExpCrc_DataPtr, ActData, 
          LucExpCrc8Length))
        {
          LblStepResult = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      NvM_GucCrc8Count = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(NvM_GucCrc8Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End of TestCrc_CalculateCRC8 */

/*******************************************************************************
**                           TestCRC8_DefaultBehaviour()                      **
*******************************************************************************/
void TestCRC8_DefaultBehaviour(void)
{
  NvM_GucCrc8Count = 0;
}
#endif
/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
