/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Crc_16.c                                                      **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Crc Library Module                                    **
**                                                                            **
**  PURPOSE   : Implementation for 16-bit CRC functions of Crc Library Module **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By          Description                            **
********************************************************************************
** 1.0.0     27-Dec-2012   Kiranmai    Initial Version                        **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Crc.h"                     /* Crc Header file */
#ifdef NVM_MODULE_ACTIVE
#include "App_NvM_Sub_Functions.h"
#endif
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/*******************************************************************************
**                      Version Check                                         **
*******************************************************************************/
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#ifdef NVM_MODULE_ACTIVE
uint16 NvM_GucCrc16Count;
uint32 NvM_GucCrc16Length;
uint16 NvM_GucCrcStartValue16;
uint8 NvM_GucCrcVal16;

/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
/*******************************************************************************
**                           App_TestPrepareCrcVal16()                        **
*******************************************************************************/
void App_TestPrepareCrcVal16(uint8 LucCrcVal)
{
  NvM_GucCrcVal16 = LucCrcVal;
} /* End App_TestPrepareCrcVal() */

/*******************************************************************************
**                            Crc_CalculateCRC16()                            **
*******************************************************************************/
uint16 Crc_CalculateCRC16(const uint8* Crc_DataPtr, uint32 Crc_Length, 
  uint16 Crc_StartValue16, boolean Crc_IsFirstCall)
{
  #ifndef TYPICAL_CONFIG
  const uint8* LpDataPtr;
  uint8 LucDataIndex;
  
  NvM_GucCrc16Length = Crc_Length;
  NvM_GucCrcStartValue16 = Crc_StartValue16;
  LpDataPtr = Crc_DataPtr;
  UNUSED(Crc_IsFirstCall);
  
  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0x00; LucDataIndex < NvM_GucCrc16Length; LucDataIndex++)
  {
    NvM_GaaCrcDataPtr[LucDataIndex] = *LpDataPtr;
    LpDataPtr++;
  }
  
  NvM_GucCrc16Count++;
  
  #endif
  /* Return the CRC result */
  return (NvM_GucCrcVal16);
} /* End of Crc_CalculateCRC16 */

/*******************************************************************************
**                         TestCrc_CalculateCRC16()                           **
*******************************************************************************/
boolean TestCrc_CalculateCRC16(App_DataValidateType LucDataValidate, 
  const uint8* LpExpCrc_DataPtr, uint32 LucExpCrc16Length, 
  uint16 LucExpCrcStartValue16, boolean Crc_IsFirstCall)
{
  boolean LblStepResult;
  uint8 *ActData;
  
  LblStepResult = STEP_FAILED;
  UNUSED(Crc_IsFirstCall);
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((NvM_GucCrc16Count == 0x01) 
        && (LucExpCrc16Length == NvM_GucCrc16Length) 
        && (LucExpCrcStartValue16 == NvM_GucCrcStartValue16))
      {
        ActData = &NvM_GaaCrcDataPtr[0];
        
        /* Validating the Data */
        if(NvMTest_ValidateData((uint8 *)LpExpCrc_DataPtr, ActData, 
          LucExpCrc16Length))
        {
          LblStepResult = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      NvM_GucCrc16Count = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(NvM_GucCrc16Count == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End of TestCrc_CalculateCRC16 */
/*******************************************************************************
**                           TestCRC16_DefaultBehaviour()                     **
*******************************************************************************/
void TestCRC16_DefaultBehaviour(void)
{
  NvM_GucCrc16Count = 0;
}
#endif
/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
