/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: WdgM.c                                                        **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR WatchDog Manger                                       **
**                                                                            **
**  PURPOSE   : This application file contains the WdgM functions             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0         23-Nov-2012       Ankur      Initial version                 **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "WdgM.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 WdgM_GucConfigData;
uint8 WdgM_GucInitSeqCnt;
uint8 WdgM_GucDeInitSeqCnt;
uint8 WdgM_GucDeInitCount;

/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
/* Added to remove compilation warning(empty source file) in WdgM.c */
void WdgM_Init( const WdgM_ConfigType* ConfigPtr )
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  WdgM_GucInitSeqCnt = App_GucApiSeqCnt;
  if (ConfigPtr != NULL_PTR)
  {
    WdgM_GucConfigData = (ConfigPtr->dummy);
  }
  #endif
}

/*******************************************************************************
**                       TestWdgM_Init()                                      **
*******************************************************************************/
boolean TestWdgM_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, uint8 LucData)
{
  boolean LblStepResult;  
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((WdgM_GucInitSeqCnt == 0x01) && 
        (WdgM_GucConfigData == LucData))
      {
        LblStepResult = STEP_PASSED;
      }
      WdgM_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if((WdgM_GucInitSeqCnt == LucSeqNo) && 
        (WdgM_GucConfigData == LucData))
      {
        LblStepResult = STEP_PASSED;
      }
      WdgM_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */    
    
  return(LblStepResult);
} /* End TestWdgM_Init() */

/*******************************************************************************
**                        WdgM_DeInit()                                       **
*******************************************************************************/
void WdgM_DeInit(void)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  WdgM_GucDeInitSeqCnt = App_GucApiSeqCnt;
  WdgM_GucDeInitCount++;
  #endif
}

/*******************************************************************************
**                       TestWdgM_DeInit()                                    **
*******************************************************************************/
boolean TestWdgM_DeInit(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;  
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(WdgM_GucDeInitCount == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      WdgM_GucDeInitCount = 0;
      WdgM_GucDeInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(WdgM_GucDeInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      WdgM_GucDeInitSeqCnt = 0;
      WdgM_GucDeInitCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */    
    
  return(LblStepResult);
} /* End TestWdgM_DeInit() */
/*******************************************************************************
**                       TestWdgM_DefaultBehavior()                           **
*******************************************************************************/
void TestWdgM_DefaultBehavior(void)
{
  WdgM_GucConfigData = 0;
  WdgM_GucInitSeqCnt = 0;
  WdgM_GucDeInitSeqCnt = 0;
  WdgM_GucDeInitCount = 0;
}
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
