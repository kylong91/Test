/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: WdgM.h                                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR WatchDog Manager Stub                                 **
**                                                                            **
**  PURPOSE   : C header for WdgM.c                                           **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision      Date              By           Description                   **
********************************************************************************
** 1.0.0         23-Nov-2012       Ankur      Initial version                 **
*******************************************************************************/

#ifndef WDGM_H
#define WDGM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define WDGM_AR_RELEASE_MAJOR_VERSION         4
#define WDGM_AR_RELEASE_MINOR_VERSION         0
#define WDGM_AR_RELEASE_REVISION_VERSION      3

/* Software Version Information */
#define WDGM_SW_MAJOR_VERSION  1
#define WDGM_SW_MINOR_VERSION  0
/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define INVALID_OSAPPLICATION 0
#define WdgMConfigSet0 &WdgM_GaaConfig[0]
#define WdgMConfigSet1 &WdgM_GaaConfig[1]
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/* Dummy Structure for Icu_ConfigType */
typedef struct STag_WdgM_ConfigType
{
  uint8 dummy;
}WdgM_ConfigType;
extern const WdgM_ConfigType WdgM_GaaConfig[2];
extern uint8 WdgM_GucConfigData;
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void WdgM_Init(const WdgM_ConfigType *ConfigPtr);
extern void WdgM_DeInit(void);

extern boolean TestWdgM_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, uint8 LucData);
extern boolean TestWdgM_DeInit(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
  
extern void TestWdgM_DefaultBehavior(void);
#endif /* WDGM_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
