/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE:  LinTrcv.c                                                    **
**                                                                            **
**  TARGET    :  ALL                                                          **
**                                                                            **
**  PRODUCT   : AUTOSAR LIN Transceiver Module                                **
**                                                                            **
**  PURPOSE   : This file is a stub for LIN Transceiver Driver Component      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     11/01/2011    NKD    Creation of Lin.c module                    **
*******************************************************************************/

/******************************************************************************
**                      Include Section                                      **
******************************************************************************/
#include "LinTrcv.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#ifdef LINIF_MODULE_ACTIVE
/* Variables used for LinIf module  */
Std_ReturnType LinTrcv_GaaSetOpModeRet[LINTRCV_ARRAY_SIZE];
Std_ReturnType LinTrcv_GaaGetOpModeRet[LINTRCV_ARRAY_SIZE];
Std_ReturnType LinTrcv_GaaGetBusWuReasonRet[LINTRCV_ARRAY_SIZE];
Std_ReturnType LinTrcv_GaasetWakeupModeRet[LINTRCV_ARRAY_SIZE];
Std_ReturnType LinTrcv_GaaGetCheckWakeupRet[LINTRCV_ARRAY_SIZE];

uint8 LinTrcv_GucSetOpModeCount;
uint8 LinTrcv_GucGetOpModeCount;
uint8 LinTrcv_GucGetBusWuReasonCount;
uint8 LinTrcv_GucSetOpModeCheckCount;
uint8 LinTrcv_GucGetOpModeCheckCount;

uint8 LinTrcv_GucCheckWakeupCount;
uint8 LinTrcv_GucCheckWakeupCheckCount;
uint8 LinTrcv_GucSetWakeupModeCount;
uint8 LinTrcv_GucSetWakeupModeCheckCount;

uint8 LinTrcv_GucGetBusWuReasChkCount;
uint8 LinTrcv_GaaSetOpModeNw[LINTRCV_ARRAY_SIZE];
uint8 LinTrcv_GaaSetWakeupModeNw[LINTRCV_ARRAY_SIZE];
uint8 LinTrcv_GaaGetOpModeNw[LINTRCV_ARRAY_SIZE];

uint8 LinTrcv_GaaCheckWakeupNw[LINTRCV_ARRAY_SIZE];
LinTrcv_TrcvWakeupModeType LinTrcv_GaaSetWakeupMode[LINTRCV_ARRAY_SIZE];

LinTrcv_TrcvWakeupReasonType LinTrcv_GaaGetBusWuReason[LINTRCV_ARRAY_SIZE];
uint8 LinTrcv_GaaGetBusWuReasonNw[LINTRCV_ARRAY_SIZE];
LinTrcv_TrcvModeType LinTrcv_GaaSetOpMode[LINTRCV_ARRAY_SIZE];
LinTrcv_TrcvModeType LinTrcv_GaaGetOpMode[LINTRCV_ARRAY_SIZE];

/* Variables used for LinIf module  */
/*******************************************************************************
**                       TestLinTrcv_DefaultBehavior()                        **
*******************************************************************************/
void TestLinTrcv_DefaultBehavior(void)
{
  uint8 LucCount;  
  
  for(LucCount = 0x00; LucCount < LINTRCV_ARRAY_SIZE; LucCount++)
  {
    LinTrcv_GaaSetOpModeRet[LucCount] = E_OK;
    LinTrcv_GaaGetOpModeRet[LucCount] = E_OK;
    LinTrcv_GaaGetBusWuReasonRet[LucCount] = E_OK; 
    
    LinTrcv_GaasetWakeupModeRet[LucCount] = E_OK;
    LinTrcv_GaaGetCheckWakeupRet[LucCount] = E_OK;    
  }
  LinTrcv_GucSetOpModeCount = 0x00;
  LinTrcv_GucGetOpModeCount = 0x00;
  
  LinTrcv_GucCheckWakeupCount = 0x00;
  LinTrcv_GucSetWakeupModeCount = 0x00;
  LinTrcv_GucSetWakeupModeCheckCount = 0x00;
  LinTrcv_GucCheckWakeupCheckCount = 0x00;
  
  LinTrcv_GucGetBusWuReasonCount = 0x00;
  LinTrcv_GucSetOpModeCheckCount = 0x00;
  LinTrcv_GucGetOpModeCheckCount = 0x00;
  LinTrcv_GucGetBusWuReasChkCount = 0x00;  
} /* End TestLinTrcv_DefaultBehavior() */

/*******************************************************************************
**                       LinTrcv_SetOpMode()                                  **
*******************************************************************************/
Std_ReturnType LinTrcv_SetOpMode(uint8 LinNetwork, LinTrcv_TrcvModeType OpMode)
{
  #ifndef TYPICAL_CONFIG
  LinTrcv_GaaSetOpModeNw[LinTrcv_GucSetOpModeCount] = LinNetwork;
  LinTrcv_GaaSetOpMode[LinTrcv_GucSetOpModeCount] = OpMode;  
  /* Increment count variable to handle multiple invocations */
  if(LinTrcv_GucSetOpModeCount != LINTRCV_ARRAY_SIZE)
  {    
    LinTrcv_GucSetOpModeCount++;
  } 
  return(LinTrcv_GaaSetOpModeRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcv_SetOpMode() */

/*******************************************************************************
**                       TestLinTrcv_SetOpMode()                              **
*******************************************************************************/
boolean TestLinTrcv_SetOpMode(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork, LinTrcv_TrcvModeType ExpOpMode)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcv_GucSetOpModeCount == 0x01) && 
        (ExpLinNetwork == LinTrcv_GaaSetOpModeNw[0]) && 
        (ExpOpMode == LinTrcv_GaaSetOpMode[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcv_GucSetOpModeCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcv_GucSetOpModeCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcv_GucSetOpModeCheckCount <= LinTrcv_GucSetOpModeCount) &&
        (ExpLinNetwork == LinTrcv_GaaSetOpModeNw[LinTrcv_GucSetOpModeCheckCount]) && 
        (ExpOpMode == 
        LinTrcv_GaaSetOpMode[LinTrcv_GucSetOpModeCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcv_GucSetOpModeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcv_GucSetOpModeCheckCount == LinTrcv_GucSetOpModeCount)
      {
        LinTrcv_GucSetOpModeCount = 0;
        LinTrcv_GucSetOpModeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcv_GucSetOpModeCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcv_GaaSetOpModeNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcv_SetOpMode() */

/*******************************************************************************
**                       TestSetLinTrcv_SetOpModeRetVal()                     **
*******************************************************************************/
void TestSetLinTrcv_SetOpModeRetVal(uint8 LinNetwork, Std_ReturnType RetVal)
{
  LinTrcv_GaaSetOpModeRet[LinNetwork] = RetVal;
} /* End TestSetLinTrcv_SetOpModeRetVal()  */

/*******************************************************************************
**                       LinTrcv_SetWakeupMode()                              **
*******************************************************************************/
Std_ReturnType LinTrcv_SetWakeupMode ( uint8 LinNetwork, 
LinTrcv_TrcvWakeupModeType TrcvWakupMode)
{
  #ifndef TYPICAL_CONFIG
  LinTrcv_GaaSetWakeupModeNw[LinTrcv_GucSetWakeupModeCount] = LinNetwork;
  LinTrcv_GaaSetWakeupMode[LinTrcv_GucSetWakeupModeCount] = TrcvWakupMode;  
  /* Increment count variable to handle multiple invocations */
  if(LinTrcv_GucSetWakeupModeCount != LINTRCV_ARRAY_SIZE)
  {    
    LinTrcv_GucSetWakeupModeCount++;
  } 
  return(LinTrcv_GaasetWakeupModeRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcv_SetOpMode() */
/*******************************************************************************
**                       TestLinTrcv_SetWakeupMode()                          **
*******************************************************************************/
Std_ReturnType TestLinTrcv_SetWakeupMode(App_DataValidateType LucDataValidate,
 uint8 ExpLinNetwork, LinTrcv_TrcvWakeupModeType ExpOpMode)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcv_GucSetWakeupModeCount == 0x01) && 
        (ExpLinNetwork == LinTrcv_GaaSetWakeupModeNw[0]) && 
        (ExpOpMode == LinTrcv_GaaSetWakeupMode[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcv_GucSetWakeupModeCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcv_GucSetWakeupModeCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcv_GucSetWakeupModeCheckCount <= LinTrcv_GucSetWakeupModeCount) &&
        (ExpLinNetwork == LinTrcv_GaaSetWakeupModeNw[LinTrcv_GucSetWakeupModeCheckCount]) && 
        (ExpOpMode == 
        LinTrcv_GaaSetWakeupMode[LinTrcv_GucSetWakeupModeCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcv_GucSetWakeupModeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcv_GucSetWakeupModeCheckCount == LinTrcv_GucSetWakeupModeCount)
      {
        LinTrcv_GucSetWakeupModeCount = 0;
        LinTrcv_GucSetWakeupModeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcv_GucSetWakeupModeCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcv_GaaSetWakeupModeNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcv_SetWakeupMode() */

/*******************************************************************************
**                       TestSetLinTrcv_SetWakeupModeRetVal()                 **
*******************************************************************************/
void TestSetLinTrcv_SetWakeupModeRetVal(uint8 LinNetwork, Std_ReturnType RetVal)
{
  LinTrcv_GaasetWakeupModeRet[LinNetwork] = RetVal;
} /* End TestSetLinTrcv_SetWakeupModeRetVal()  */

/*******************************************************************************
**                       LinTrcv_GetOpMode()                                  **
*******************************************************************************/
Std_ReturnType LinTrcv_GetOpMode(uint8 LinNetwork, 
  LinTrcv_TrcvModeType* OpMode)
{
  #ifndef TYPICAL_CONFIG
  LinTrcv_GaaGetOpModeNw[LinTrcv_GucGetOpModeCount] = LinNetwork;
  *OpMode = LinTrcv_GaaGetOpMode[LinNetwork];  
  /* Increment count variable to handle multiple invocations */
  if(LinTrcv_GucGetOpModeCount != LINTRCV_ARRAY_SIZE)
  {    
    LinTrcv_GucGetOpModeCount++;
  } 
  return(LinTrcv_GaaGetOpModeRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcv_GetOpMode() */

/*******************************************************************************
**                       TestLinTrcv_GetOpMode()                              **
*******************************************************************************/
boolean TestLinTrcv_GetOpMode(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcv_GucGetOpModeCount == 0x01) && 
        (ExpLinNetwork == LinTrcv_GaaGetOpModeNw[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcv_GucGetOpModeCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcv_GucGetOpModeCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcv_GucGetOpModeCheckCount <= LinTrcv_GucGetOpModeCount) &&
        (ExpLinNetwork == LinTrcv_GaaGetOpModeNw[LinTrcv_GucGetOpModeCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcv_GucGetOpModeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcv_GucGetOpModeCheckCount == LinTrcv_GucGetOpModeCount)
      {
        LinTrcv_GucGetOpModeCount = 0;
        LinTrcv_GucGetOpModeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcv_GucGetOpModeCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcv_GaaGetOpModeNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcv_GetOpMode() */

/*******************************************************************************
**                       LinTrcv_CheckWakeup()                                **
*******************************************************************************/
Std_ReturnType LinTrcv_CheckWakeup(uint8 LinNetwork )
{
  #ifndef TYPICAL_CONFIG
  LinTrcv_GaaCheckWakeupNw[LinTrcv_GucCheckWakeupCount] = LinNetwork;
  /* Increment count variable to handle multiple invocations */
  if(LinTrcv_GucCheckWakeupCount != LINTRCV_ARRAY_SIZE)
  {    
    LinTrcv_GucCheckWakeupCount++;
  } 
  return(LinTrcv_GaaGetCheckWakeupRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcv_CheckWakeup() */

/*******************************************************************************
**                       TestLinTrcv_CheckWakeup()                            **
*******************************************************************************/
boolean TestLinTrcv_CheckWakeup(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcv_GucCheckWakeupCount == 0x01) && 
        (ExpLinNetwork == LinTrcv_GaaCheckWakeupNw[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcv_GucCheckWakeupCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcv_GucCheckWakeupCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcv_GucCheckWakeupCheckCount <= LinTrcv_GucCheckWakeupCount) &&
        (ExpLinNetwork == LinTrcv_GaaCheckWakeupNw[LinTrcv_GucCheckWakeupCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcv_GucCheckWakeupCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcv_GucCheckWakeupCheckCount == LinTrcv_GucCheckWakeupCount)
      {
        LinTrcv_GucCheckWakeupCount = 0;
        LinTrcv_GucCheckWakeupCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcv_GucCheckWakeupCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcv_GaaCheckWakeupNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcv_CheckWakeup() */

/*******************************************************************************
**                       TestSetLinTrcv_GetOpModeRetVal()                     **
*******************************************************************************/
void TestSetLinTrcv_GetOpModeRetVal(uint8 SetLinNetwork, 
  LinTrcv_TrcvModeType SetOpMode, Std_ReturnType RetVal)
{
  LinTrcv_GaaGetOpMode[SetLinNetwork] = SetOpMode;
  LinTrcv_GaaGetOpModeRet[SetLinNetwork] = RetVal;  
} /* End TestSetLinTrcv_GetOpModeRetVal()  */
/*******************************************************************************
**                       LinTrcv_GetBusWuReason()                             **
*******************************************************************************/
Std_ReturnType LinTrcv_GetBusWuReason(uint8 LinNetwork, 
  LinTrcv_TrcvWakeupReasonType* Reason)
{
  #ifndef TYPICAL_CONFIG  
  LinTrcv_GaaGetBusWuReasonNw[LinTrcv_GucGetBusWuReasonCount] = LinNetwork;
  *Reason = LinTrcv_GaaGetBusWuReason[LinNetwork];  
  /* Increment count variable to handle multiple invocations */
  if(LinTrcv_GucGetBusWuReasonCount != LINTRCV_ARRAY_SIZE)
  {    
    LinTrcv_GucGetBusWuReasonCount++;
  } 
  return(LinTrcv_GaaGetBusWuReasonRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcv_GetBusWuReason() */

/*******************************************************************************
**                            TestLinTrcv_GetBusWuReason()                    **
*******************************************************************************/
boolean TestLinTrcv_GetBusWuReason(App_DataValidateType LucDataValidate,
  uint8 ExpLinNetwork)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcv_GucGetBusWuReasonCount == 0x01) && 
        (ExpLinNetwork == LinTrcv_GaaGetBusWuReasonNw[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcv_GucGetBusWuReasonCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcv_GucGetBusWuReasonCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcv_GucGetBusWuReasChkCount <= LinTrcv_GucGetBusWuReasonCount) &&
        (ExpLinNetwork == 
          LinTrcv_GaaGetBusWuReasonNw[LinTrcv_GucGetBusWuReasChkCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcv_GucGetBusWuReasChkCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcv_GucGetBusWuReasChkCount == LinTrcv_GucGetBusWuReasonCount)
      {
        LinTrcv_GucGetBusWuReasonCount = 0;
        LinTrcv_GucGetBusWuReasChkCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcv_GucGetBusWuReasonCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcv_GaaGetBusWuReasonNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcv_GetBusWuReason() */

/*******************************************************************************
**                       TestSetLinTrcv_GtBusWuReasRetVal()                   **
*******************************************************************************/
void TestSetLinTrcv_GetBusWuReasonRetVal(uint8 SetLinNetwork, 
  LinTrcv_TrcvWakeupReasonType SetReason, Std_ReturnType RetVal)
{
  LinTrcv_GaaGetBusWuReason[SetLinNetwork] = SetReason;
  LinTrcv_GaaGetBusWuReasonRet[SetLinNetwork] = RetVal;  
} /* End TestSetLinTrcv_GtBusWuReasRetVal()  */
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
