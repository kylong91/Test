/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE:  LinTrcv.h                                                    **
**                                                                            **
**  TARGET    :  ALL                                                          **
**                                                                            **
**  PRODUCT   : AUTOSAR LIN Transceiver Module                                **
**                                                                            **
**  PURPOSE   : Provision of Macros, extern declaration of APIs               **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     11/01/2011    NKD    Creation of Lin.c module                    **
*******************************************************************************/

#ifndef LINTRCV_H
#define LINTRCV_H

/*******************************************************************************
**                      Include Section                                      **
*******************************************************************************/
#include "TC_Generic.h"
#include "Lin_GeneralTypes.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define LINTRCV_AR_RELEASE_MAJOR_VERSION         0x04
#define LINTRCV_AR_RELEASE_MINOR_VERSION         0x00
#define LINTRCV_AR_RELEASE_REVISION_VERSION      0x02

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define LINTRCV_DATA_LENGTH                      0x08
/* Channel value should be less than LIN_ARRAY_SIZE */
#define LINTRCV_ARRAY_SIZE                       0x04 

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void TestLinTrcv_DefaultBehavior(void);
extern Std_ReturnType LinTrcv_SetOpMode(uint8 LinNetwork, 
  LinTrcv_TrcvModeType OpMode);
extern boolean TestLinTrcv_SetOpMode(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork, LinTrcv_TrcvModeType ExpOpMode);
extern void TestSetLinTrcv_SetOpModeRetVal(uint8 LinNetwork, 
  Std_ReturnType RetVal);
  
extern Std_ReturnType LinTrcv_SetWakeupMode(uint8 LinNetwork, 
  LinTrcv_TrcvWakeupModeType TrcvWakupMode);
extern void TestSetLinTrcv_SetWakeupModeRetVal(uint8 LinNetwork, 
  Std_ReturnType RetVal);
  
extern Std_ReturnType TestLinTrcv_SetWakeupMode(
  App_DataValidateType LucDataValidate, uint8 LinNetwork, 
  LinTrcv_TrcvWakeupModeType TrcvWakupMode);

extern  Std_ReturnType TestLinTrcv_CheckWakeup(
  App_DataValidateType LucDataValidate, uint8 LinNetwork );

extern  Std_ReturnType LinTrcv_CheckWakeup( uint8 LinNetwork );
  
extern Std_ReturnType LinTrcv_GetOpMode(uint8 LinNetwork, 
  LinTrcv_TrcvModeType* OpMode);
extern boolean TestLinTrcv_GetOpMode(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork);
extern void TestSetLinTrcv_GetOpModeRetVal(uint8 SetLinNetwork, 
  LinTrcv_TrcvModeType SetOpMode, Std_ReturnType RetVal);
extern Std_ReturnType LinTrcv_GetBusWuReason(uint8 LinNetwork, 
  LinTrcv_TrcvWakeupReasonType* Reason);
extern boolean TestLinTrcv_GetBusWuReason(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork);
extern void TestSetLinTrcv_GetBusWuReasonRetVal(uint8 SetLinNetwork, 
  LinTrcv_TrcvWakeupReasonType SetReason, Std_ReturnType RetVal);
  
#endif  /* LINTRCV_H */

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
