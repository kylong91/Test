/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Fr.c                                                          **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FR Stub                                               **
**                                                                            **
**  PURPOSE   : This application file contains the Fr Stub functions          **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Fr.h"
#include "FrIf.h"
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#ifdef BSWM_MODULE_ACTIVE
uint8 Fr_GucInitCnt;
uint8 Fr_GucInitSeqCnt;
#endif

#ifdef FRIF_MODULE_ACTIVE
uint8 Fr_GucPrepareLPdu = 0;
uint8 Fr_GaaSduData[250];
uint8 Fr_GucCtrlIdx;
uint8 Fr_GucReceiveRxLPdu = 0;
uint8 Fr_GucStartCommunication;
uint8 Fr_GucHaltCommunication;
uint8 Fr_GucAbortCommunication;
uint8 Fr_GucAllowColdstart;
uint8 Fr_GucAllSlots;
uint8 Fr_GucAbsTimerIdx;
uint8 Fr_Guccycle;
uint16 Fr_GusOffset;
uint8 Fr_GucAbsoluteTimer;
uint8 Fr_GucEnableAbsoluteTimerIRQ;
boolean* Fr_GpIRQStatusPtr;
Fr_ChannelType FrIf_GddChnlIdx;
uint8 Fr_GucSetWakeupChannel;
uint8 Fr_GucSendWUP;
FrTrcv_TrcvModeType FrIf_GddTrcvMode;
uint8 Fr_GucSetTransceiverMode;
uint8 Fr_GucTransceivermodecount;
uint8 Fr_GucGetChannelStatus;
sint16* Fr_GpRateCorrectionPtr;
sint32* Fr_GpOffsetCorrectionPtr;
uint8 Fr_GucGetClockCorrection;
uint8 Fr_GucListSize;
uint8 Fr_GucLSduLength;
uint16* Fr_GpChannelAEvenListPtr;
uint16* Fr_GpChannelBEvenListPtr;
uint16* Fr_GpChannelAOddListPtr;
uint16* Fr_GpChannelBOddListPtr;
uint8 Fr_GucGetSyncFrameList;
uint8* Fr_GpNumOfStartupFramesPtr;
uint8 Fr_GucLSduPtr;
uint8 Fr_GucGetNumOfStartupFrames;
uint8 Fr_GucDisableLPdu;
uint8* Fr_GpWakeupRxStatusPtr;
uint8 Fr_GucGetWakeupRxStatus;
uint16 Fr_GusFrameId;
uint8 Fr_GucCycleRepetition; 
uint8 Fr_GucCycleOffset;
uint8 Fr_GucControllerInit = 0;
uint8 Fr_GucPayloadLength;
uint16 Fr_GusHeaderCRC;
uint8 Fr_GucReconfigLPdu;
uint8* Fr_GpNmVectorPtr;
uint8 Fr_GucGetNmVector;
uint8 Fr_GucConfigParamIdx;
uint32* Fr_GpConfigParamValuePtr;
uint8 Fr_GucReadCCConfig;
Fr_POCStatusType* Fr_GpPOCStatusPtr; 
uint8 Fr_GucGetPOCStatus;
uint8* Fr_GpCyclePtr;
uint16* Fr_GpMacroTickPtr;
uint8 Fr_GucGetGlobalTime;
uint8 Fr_GucAckAbsoluteTimerIRQ;
uint8 Fr_GucStartCommunicationRetVal;
uint8 Fr_GucHaltCommunicationRetVal;
uint8 Fr_GucAbortCommunicationRetVal;
uint8 Fr_GucSetWakeupChannelRetVal;
uint8 Fr_GucSendWUPRetVal;
uint8 Fr_GucGetPOCStatusRetVal;
uint8 Fr_GucGetGlobalTimeRetVal;
uint8 Fr_GucAllowColdstartRetVal;
uint8 Fr_GucAllSlotsRetVal;
uint8 Fr_GucGetClockCorrectionRetVal;
uint8 Fr_GucGetChannelStatusRetVal;
uint8 Fr_GucGetSyncFrameListRetVal;
uint8 Fr_GucGetNumOfStartupFramesRetVal;
uint8 Fr_GucGetWakeupRxStatusRetVal;
uint8 Fr_GucDisableLPduRetVal;
uint8 Fr_GucReconfigLPduRetVal;
uint8 Fr_GucGetNmVectorRetVal;
uint8 Fr_GucReadCCConfigRetVal;
uint8 Fr_GucSetAbsoluteTimerRetVal;
uint8 Fr_GucEnableAbsoluteTimerIRQRetVal;
uint8 Fr_GucAckAbsoluteTimerIRQRetVal;
uint8 Fr_GucCancelAbsoluteTimerRetVal;
uint8 Fr_GucGetAbsoluteTimerIRQRetVal;
uint8 Fr_GucDisableAbsoluteTimerIRQRetVal;
uint16 Fr_GusLPduIdx;
uint8 Fr_GucCancelTxLPdu;
uint8 Fr_GucCheckTxLPduStatus;
uint8 Fr_GucTransmitTxLPduStatus;
uint8 Fr_GucReceiveTxLPduStatus;
uint16* Fr_GpChannelAStatusPtr;
uint16* Fr_GpChannelBStatusPtr;  
uint8 Fr_GucCheckTxLPduRetVal;
uint8 Fr_GucDriverASetAbsoluteTimer;
uint8 Fr_GucTrcvCtrlIdx;
uint8 Fr_GucTrcvCheckWakeupByTransceiver;
#endif
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

#ifdef BSWM_MODULE_ACTIVE
/*******************************************************************************
**                          Fr_Init()                                        **
*******************************************************************************/

void Fr_Init(const Fr_ConfigType* Fr_ConfigPtr)
{
	UNUSED(Fr_ConfigPtr);
  App_GucApiSeqCnt++;
	Fr_GucInitSeqCnt = App_GucApiSeqCnt;
	Fr_GucInitCnt++;
}/* End Fr_Init() */

/*******************************************************************************
**                           TestFr_Init()                                   **
*******************************************************************************/
boolean TestFr_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Fr_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucInitCnt = 0;
      Fr_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(Fr_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucInitCnt = 0;
      Fr_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFr_Init() */
#endif

#ifdef FRIF_MODULE_ACTIVE
/*******************************************************************************
**                     Fr_Init()                                              **
*******************************************************************************/
void TestFr_InitSetBeh(void)
{
  //uint8 LusCount=0;
  //while(LusCount == FRIF_MAX_TX_PDU_ID)
  //{
  //FrIf_GaaRamPduTxDataTbl[LusCount].usFrIfTxConfCounter =0;
  //FrIf_GaaRamPduTxDataTbl[LusCount].usFrIfTrigTxCounter = 0;
  //FrIf_GaaRamPduTxDataTbl[LusCount].ddFrIfSduLength = 0;
  //FrIf_GaaRamPduTxDataTbl[LusCount].pFrIfSduDataPtr = 0;
  //FrIf_GaaRamPduTxDataTbl[LusCount].blTransmitFlg = 0;
  //LusCount++;
  //}
  //LusCount=0;
  //while(LusCount == FRIF_MAX_RX_PDU_ID)
  //{
  //FrIf_GaaRamPduRxDataTbl[LusCount].ddFrIfSduLength = 0;
  //FrIf_GaaRamPduRxDataTbl[LusCount].pFrIfSduDataPtr = 0;
  //FrIf_GaaRamPduRxDataTbl[LusCount].blFrIfRxPduUpdtFlg = 0;
  //LusCount++;
  //}
}
/*******************************************************************************
**                     Fr_GetNmVector()                                       **
*******************************************************************************/
Std_ReturnType Fr_GetNmVector(uint8 Fr_CtrlIdx, uint8* Fr_NmVectorPtr)
{
  Fr_GucCtrlIdx = Fr_CtrlIdx;
  Fr_GpNmVectorPtr = Fr_NmVectorPtr;
  Fr_GucGetNmVector++;
  return(Fr_GucGetNmVectorRetVal);
}
void TestFr_GetNmVectorSetBeh(Std_ReturnType LddReturnVal)
{
   Fr_GucGetNmVectorRetVal = LddReturnVal;
}
/*******************************************************************************
**               TestFr_39_GetNmVector()                                      **
*******************************************************************************/
boolean TestFr_39_GetNmVector(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint8* Fr_NmVectorPtr)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucGetNmVector == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpNmVectorPtr == Fr_NmVectorPtr)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucGetNmVector = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucGetNmVector == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucGetNmVector = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
/*******************************************************************************
**                     Fr_ReadCCConfig()                            **
*******************************************************************************/
Std_ReturnType Fr_ReadCCConfig(uint8 Fr_CtrlIdx,
  uint8 FrIf_CCLLParamIndex, uint32* FrIf_CCLLParamValue)
{ 
  Fr_GucCtrlIdx = Fr_CtrlIdx;
  Fr_GucConfigParamIdx = FrIf_CCLLParamIndex;
  Fr_GpConfigParamValuePtr = FrIf_CCLLParamValue;
  Fr_GucReadCCConfig++;
  return(Fr_GucReadCCConfigRetVal);
}
void TestFr_ReadCCConfigSetBeh(Std_ReturnType LddReturnVal)
{
   Fr_GucReadCCConfigRetVal = LddReturnVal;
}
/*******************************************************************************
**               TestFr_39_DriverAReadCCConfig()                              **
*******************************************************************************/
boolean TestFr_ReadCCConfig (App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint8 FrIf_CCLLParamIndex,
  uint32* FrIf_CCLLParamValue) 
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucReadCCConfig == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucConfigParamIdx == FrIf_CCLLParamIndex) &&
        (Fr_GpConfigParamValuePtr == FrIf_CCLLParamValue)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucReadCCConfig = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucReadCCConfig == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucReadCCConfig = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
/*******************************************************************************
**                     Fr_ReconfigLPdu()                                      **
*******************************************************************************/
Std_ReturnType Fr_ReconfigLPdu(uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx, 
  uint16 Fr_FrameId, Fr_ChannelType Fr_ChnlIdx, uint8 Fr_CycleRepetition, 
  uint8 Fr_CycleOffset, uint8 Fr_PayloadLength, uint16 Fr_HeaderCRC)
{
  Fr_GucCtrlIdx = Fr_CtrlIdx;
  Fr_GusLPduIdx = Fr_LPduIdx;
  Fr_GusFrameId = Fr_FrameId;
  FrIf_GddChnlIdx = Fr_ChnlIdx;
  Fr_GucCycleRepetition = Fr_CycleRepetition;
  Fr_GucCycleOffset = Fr_CycleOffset;
  Fr_GucPayloadLength = Fr_PayloadLength;
  Fr_GusHeaderCRC = Fr_HeaderCRC;
  Fr_GucReconfigLPdu++;
  return(Fr_GucReconfigLPduRetVal);
}
void TestFr_ReconfigLPduSetBeh(Std_ReturnType LddReturnVal)
{
   Fr_GucReconfigLPduRetVal = LddReturnVal;
}
/*******************************************************************************
**               TestFr_39_ReconfigLPdu()                                     **
*******************************************************************************/
boolean TestFr_ReconfigLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx, uint16 Fr_FrameId,
  Fr_ChannelType Fr_ChnlIdx, uint8 Fr_CycleRepetition, uint8 Fr_CycleOffset,
  uint8 Fr_PayloadLength, uint16 Fr_HeaderCRC)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucReconfigLPdu == 0x01) &&
        (Fr_GusLPduIdx == Fr_LPduIdx) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) && 
        (Fr_GusFrameId == Fr_FrameId) &&
        (FrIf_GddChnlIdx == Fr_ChnlIdx) && 
        (Fr_GucCycleRepetition == Fr_CycleRepetition) &&
        (Fr_GucCycleOffset == Fr_CycleOffset) &&
        (Fr_GucPayloadLength == Fr_PayloadLength) &&
        (Fr_GusHeaderCRC == Fr_HeaderCRC))
        {
        LblStepResult = STEP_PASSED;
        }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucTransceivermodecount = 0;
      
      /* Reset API invocation Count after validating the API invocation */
      Fr_GucReconfigLPdu = 0;
      break;
    }/* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucReconfigLPdu == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucReconfigLPdu = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*******************************************************************************
**                           Fr_StartCommunication()                          **
*******************************************************************************/
Std_ReturnType Fr_StartCommunication(uint8 Fr_CtrlIdx)
{
  
    Fr_GucCtrlIdx = Fr_CtrlIdx;
    Fr_GucStartCommunication++;
    return(Fr_GucStartCommunicationRetVal);
}  
void TestFr_StartCommunicationSetBeh(uint8 LddReturnVal)
{
   Fr_GucStartCommunicationRetVal = LddReturnVal;
}


/*******************************************************************************
**                         TestFr_StartCommunication()                        **
*******************************************************************************/
boolean TestFr_StartCommunication(App_DataValidateType LddDataValidate
  , uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucStartCommunication == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucStartCommunication = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucStartCommunication == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucStartCommunication = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*******************************************************************************
**                            Fr_HaltCommunication()                          **
*******************************************************************************/
Std_ReturnType Fr_HaltCommunication(uint8 Fr_CtrlIdx)
{
  
    Fr_GucCtrlIdx = Fr_CtrlIdx;
    Fr_GucHaltCommunication++;
    return(Fr_GucHaltCommunicationRetVal); 
}
void TestFr_HaltCommunicationSetBeh(Std_ReturnType LddReturnVal)
{
   Fr_GucHaltCommunicationRetVal = LddReturnVal;
}

/*******************************************************************************
**                         TestFr_HaltCommunication()                         **
*******************************************************************************/
boolean TestFr_HaltCommunication(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucHaltCommunication == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucHaltCommunication = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucHaltCommunication == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucHaltCommunication = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*******************************************************************************
**                            Fr_AbortCommunication()                         **
*******************************************************************************/
Std_ReturnType Fr_AbortCommunication(uint8 Fr_CtrlIdx)
{
  Fr_GucCtrlIdx = Fr_CtrlIdx;
  Fr_GucAbortCommunication++;
  return(Fr_GucAbortCommunicationRetVal);
}
void TestFr_AbortCommunicationSetBeh(Std_ReturnType LddReturnVal)
{
   Fr_GucAbortCommunicationRetVal = LddReturnVal;
}

/*******************************************************************************
**                         TestFr_AbortCommunication()                        **
*******************************************************************************/
boolean TestFr_AbortCommunication(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucAbortCommunication == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucAbortCommunication = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucAbortCommunication == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucAbortCommunication = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*******************************************************************************
**                            Fr_39_DriverAGetMacroticksPerCycle()            **
*******************************************************************************/
uint16 Fr_39_DriverAGetMacroticksPerCycle(uint8 Fr_CtrlIdx)
{
Fr_GucCtrlIdx = Fr_CtrlIdx;

return 294; 
}

/*******************************************************************************
**                            Fr_AllowColdstart()                             **
*******************************************************************************/
Std_ReturnType Fr_AllowColdstart(uint8 Fr_CtrlIdx)
{
  Fr_GucCtrlIdx = Fr_CtrlIdx;
  Fr_GucAllowColdstart++;
  return(Fr_GucAllowColdstartRetVal); 
}
void TestFr_AllowColdstartSetBeh(Std_ReturnType LddReturnVal)
{
   Fr_GucAllowColdstartRetVal = LddReturnVal;
}
/*******************************************************************************
**                         TestFr_AllowColdstart()                            **
*******************************************************************************/
boolean TestFr_AllowColdstart(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucAllowColdstart == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucAllowColdstart = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucAllowColdstart == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucAllowColdstart = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 


/*******************************************************************************
**                            Fr_AllSlots()                                   **
*******************************************************************************/
Std_ReturnType Fr_AllSlots(uint8 Fr_CtrlIdx)
{
  Fr_GucCtrlIdx = Fr_CtrlIdx;
  Fr_GucAllSlots++;
  return(Fr_GucAllSlotsRetVal);
}
void TestFr_AllSlotsSetBeh(Std_ReturnType LddReturnVal)
{
   Fr_GucAllSlotsRetVal = LddReturnVal;
}
/*******************************************************************************
**                         TestFr_AllSlots()                                  **
*******************************************************************************/
boolean TestFr_AllSlots(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucAllSlots == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucAllSlots = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucAllSlots == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucAllSlots = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
Std_ReturnType Fr_ControllerInit(uint8 Fr_CtrlIdx)
{
  Fr_GucCtrlIdx = Fr_CtrlIdx;
  Fr_GucAllSlots++;
  return(Fr_GucAllSlots);
}
/*******************************************************************************
**                            TestFr_ControllerInit()                         **
*******************************************************************************/
boolean TestFr_ControllerInit(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucAllSlots == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucAbsoluteTimer = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucControllerInit == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucAbsoluteTimer = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*******************************************************************************
**                            Fr_SetAbsoluteTimer()                           **
*******************************************************************************/
Std_ReturnType Fr_SetAbsoluteTimer(uint8 Fr_CtrlIdx,uint8 Fr_AbsTimerIdx,
  uint8 Fr_Cycle,uint16 Fr_Offset)
{
    Fr_GucCtrlIdx = Fr_CtrlIdx;
    Fr_GucAbsTimerIdx = Fr_AbsTimerIdx;
    Fr_Guccycle = Fr_Cycle;
    Fr_GusOffset = Fr_Offset;
    Fr_GucAbsoluteTimer++;
    return(Fr_GucSetAbsoluteTimerRetVal); 
}
/*******************************************************************************
**                            TestFr_SetAbsoluteTimerSetBeh()                 **
*******************************************************************************/
void TestFr_SetAbsoluteTimerSetBeh(Std_ReturnType LddReturnVal)
{
    Fr_GucSetAbsoluteTimerRetVal = LddReturnVal;
}
/*******************************************************************************
**                         TestFr_SetAbsoluteTimer()                          **
*******************************************************************************/
boolean TestFr_SetAbsoluteTimer(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx, uint8 Fr_Cycle, uint16 Fr_Offset)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucAbsoluteTimer == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucAbsTimerIdx == Fr_AbsTimerIdx) &&
        (Fr_Guccycle == Fr_Cycle) &&
        (Fr_GusOffset == Fr_Offset))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucAbsoluteTimer = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucAbsoluteTimer == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucAbsoluteTimer = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*******************************************************************************
**                            Fr_EnableAbsoluteTimerIRQ()                     **
*******************************************************************************/
Std_ReturnType Fr_EnableAbsoluteTimerIRQ(uint8 Fr_CtrlIdx,
  uint8 Fr_AbsTimerIdx)
  {
    Fr_GucCtrlIdx = Fr_CtrlIdx;
    Fr_GucAbsTimerIdx = Fr_AbsTimerIdx;
    Fr_GucEnableAbsoluteTimerIRQ++;
    return(Fr_GucEnableAbsoluteTimerIRQRetVal);
  }
void TestFr_EnableAbsoluteTimerIRQSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucEnableAbsoluteTimerIRQRetVal = LddReturnVal;
    Fr_GucEnableAbsoluteTimerIRQ = 0;
  }
/*******************************************************************************
**                         TestFr_EnableAbsoluteTimerIRQ()                    **
*******************************************************************************/
boolean TestFr_EnableAbsoluteTimerIRQ(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucEnableAbsoluteTimerIRQ == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucAbsTimerIdx == Fr_AbsTimerIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucEnableAbsoluteTimerIRQ = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucEnableAbsoluteTimerIRQ == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucEnableAbsoluteTimerIRQ = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*******************************************************************************
**                            Fr_AckAbsoluteTimerIRQ()                        **
*******************************************************************************/  
  Std_ReturnType Fr_AckAbsoluteTimerIRQ(uint8 Fr_CtrlIdx,
  uint8 Fr_AbsTimerIdx)
  {
    Fr_GucCtrlIdx = Fr_CtrlIdx;
    Fr_GucAbsTimerIdx = Fr_AbsTimerIdx;
    Fr_GucAckAbsoluteTimerIRQ++;
    return(Fr_GucAckAbsoluteTimerIRQRetVal); 
  }
  void TestFr_AckAbsoluteTimerIRQSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucAckAbsoluteTimerIRQRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_AckAbsoluteTimerIRQ()                       **
*******************************************************************************/
boolean TestFr_AckAbsoluteTimerIRQ(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucAckAbsoluteTimerIRQ == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucAbsTimerIdx == Fr_AbsTimerIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucAckAbsoluteTimerIRQ = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucAckAbsoluteTimerIRQ == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucAckAbsoluteTimerIRQ = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
/*******************************************************************************
**                            Fr_CancelAbsoluteTimer()                        **
*******************************************************************************/  
  Std_ReturnType Fr_CancelAbsoluteTimer(uint8 Fr_CtrlIdx,
  uint8 Fr_AbsTimerIdx)
  {
    Fr_GucCtrlIdx = Fr_CtrlIdx;
    Fr_GucAbsTimerIdx = Fr_AbsTimerIdx;
    Fr_GucEnableAbsoluteTimerIRQ++;
    return(Fr_GucCancelAbsoluteTimerRetVal);
  }
void TestFr_CancelAbsoluteTimerSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucCancelAbsoluteTimerRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_CancelAbsoluteTimer()                       **
*******************************************************************************/
boolean TestFr_CancelAbsoluteTimer(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucEnableAbsoluteTimerIRQ == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucAbsTimerIdx == Fr_AbsTimerIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucEnableAbsoluteTimerIRQ = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucEnableAbsoluteTimerIRQ == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucEnableAbsoluteTimerIRQ = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
/*******************************************************************************
**                            Fr_GetAbsoluteTimerIRQStatus()        **
*******************************************************************************/ 
  Std_ReturnType Fr_GetAbsoluteTimerIRQStatus(uint8 Fr_CtrlIdx,
  uint8 Fr_AbsTimerIdx, boolean* FrIf_IRQStatusPtr)
  {
    Fr_GucCtrlIdx = Fr_CtrlIdx;
    Fr_GucAbsTimerIdx = Fr_AbsTimerIdx;
    Fr_GpIRQStatusPtr = FrIf_IRQStatusPtr;
    Fr_GucEnableAbsoluteTimerIRQ++;
    return(Fr_GucGetAbsoluteTimerIRQRetVal);
  }
void TestFr_GetAbsoluteTimerIRQStatusSetBeh(
  Std_ReturnType LddReturnVal)
  {
    Fr_GucGetAbsoluteTimerIRQRetVal = LddReturnVal;
  }
  /*****************************************************************************
**                        TestFr_GetAbsoluteTimerIRQStatus()                  **
*******************************************************************************/
boolean TestFr_GetAbsoluteTimerIRQStatus(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx, 
  boolean* FrIf_IRQStatusPtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucEnableAbsoluteTimerIRQ == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucAbsTimerIdx == Fr_AbsTimerIdx) &&
        (Fr_GpIRQStatusPtr == FrIf_IRQStatusPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucEnableAbsoluteTimerIRQ = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucEnableAbsoluteTimerIRQ == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucEnableAbsoluteTimerIRQ = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
/*******************************************************************************
**                            Fr_DisableAbsoluteTimerIRQ()   **
*******************************************************************************/ 
  Std_ReturnType Fr_DisableAbsoluteTimerIRQ(uint8 Fr_CtrlIdx,
  uint8 Fr_AbsTimerIdx)
  {
    Fr_GucCtrlIdx = Fr_CtrlIdx;
    Fr_GucAbsTimerIdx = Fr_AbsTimerIdx;
    Fr_GucEnableAbsoluteTimerIRQ++;
    return(Fr_GucDisableAbsoluteTimerIRQRetVal);
  }
void TestFr_DisableAbsoluteTimerIRQSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDisableAbsoluteTimerIRQRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_DisableAbsoluteTimerIRQ()  **
*******************************************************************************/
boolean TestFr_DisableAbsoluteTimerIRQ(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucEnableAbsoluteTimerIRQ == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucAbsTimerIdx == Fr_AbsTimerIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucEnableAbsoluteTimerIRQ = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucEnableAbsoluteTimerIRQ == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucEnableAbsoluteTimerIRQ = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
 
/*******************************************************************************
**                            Fr_SetWakeupChannel()                 **
*******************************************************************************/  
  Std_ReturnType Fr_SetWakeupChannel(uint8 Fr_CtrlIdx,
    Fr_ChannelType Fr_ChnlIdx)
  {
    Fr_GucCtrlIdx = Fr_CtrlIdx;
    FrIf_GddChnlIdx = Fr_ChnlIdx;
    Fr_GucSetWakeupChannel++;
    return(Fr_GucSetWakeupChannelRetVal);
  }
  void TestFr_SetWakeupChannelSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucSetWakeupChannelRetVal = LddReturnVal;
  }

/*******************************************************************************
**                         TestFr_SetWakeupChannel()                **
*******************************************************************************/
boolean TestFr_SetWakeupChannel(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx,
  Fr_ChannelType Fr_ChnlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if(( Fr_GucSetWakeupChannel == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (FrIf_GddChnlIdx == Fr_ChnlIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucSetWakeupChannel = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucSetWakeupChannel == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}   
/*******************************************************************************
**                            Fr_SendWUP()                          **
*******************************************************************************/ 
  
  Std_ReturnType Fr_SendWUP(uint8 Fr_CtrlIdx)
  {
    Fr_GucCtrlIdx = Fr_CtrlIdx;
    Fr_GucSendWUP++;
    return(Fr_GucSendWUPRetVal);
  }
  void TestFr_SendWUPSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucSendWUPRetVal = LddReturnVal;
  }
  
/*******************************************************************************
**                         TestFr_SendWUP()                         **
*******************************************************************************/
boolean TestFr_SendWUP(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucSendWUP == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucSendWUP = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucSendWUP == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucSendWUP = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}  
  
/*******************************************************************************
**                            Fr_39_DriverASetTransceiverMode()               **
*******************************************************************************/  
  Std_ReturnType Fr_39_DriverASetTransceiverMode(uint8 Fr_CtrlIdx,
    Fr_ChannelType Fr_ChnlIdx, FrTrcv_TrcvModeType FrIf_TrcvMode)
  {
    Fr_GucCtrlIdx = Fr_CtrlIdx;
    FrIf_GddChnlIdx = Fr_ChnlIdx;
    FrIf_GddTrcvMode = FrIf_TrcvMode;
    Fr_GucSetTransceiverMode++;
    return(E_OK);
  }  

/*******************************************************************************
**                            Fr_GetPOCStatus()                     **
*******************************************************************************/  
  Std_ReturnType Fr_GetPOCStatus(uint8 Fr_CtrlIdx,
    Fr_POCStatusType* FrIf_POCStatusPtr)
  {
    Fr_GucCtrlIdx = Fr_CtrlIdx;
    Fr_GpPOCStatusPtr = FrIf_POCStatusPtr;
    Fr_GucGetPOCStatus++;
    return(Fr_GucGetPOCStatusRetVal);    
  }
  void TestFr_GetPOCStatusSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucGetPOCStatusRetVal = LddReturnVal;
  }
  
/*******************************************************************************
**                         TestFr_GetPOCStatus()                              **
*******************************************************************************/
boolean TestFr_GetPOCStatus(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, Fr_POCStatusType* FrIf_POCStatusPtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucGetPOCStatus == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpPOCStatusPtr == FrIf_POCStatusPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucGetPOCStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucGetPOCStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
/*******************************************************************************
**                            Fr_GetGlobalTime()                    **
*******************************************************************************/
Std_ReturnType Fr_GetGlobalTime(uint8 Fr_CtrlIdx,P2VAR(uint8,AUTOMATIC,
                      FRIF_APPL_DATA)Fr_CyclePtr, P2VAR(uint16,AUTOAMTIC,
                      FRIF_APPL_DATA)Fr_MacroTickPtr)
{
static uint8 LucIndex=0;
LucIndex++;
if(Fr_GucGetGlobalTimeRetVal == 2)
{
Fr_GucGetGlobalTimeRetVal =0;
Fr_GucGetGlobalTime++;
Fr_GpCyclePtr = Fr_CyclePtr;
Fr_GpMacroTickPtr = Fr_MacroTickPtr;
return E_OK;
}
if(Fr_CtrlIdx == 1)
{
  return E_OK;
}
if(LucIndex < 15)
return E_NOT_OK;
if((LucIndex == 15) || (LucIndex == 16) || (LucIndex == 21))
{
//*Fr_CyclePtr= 5;
//*Fr_MacroTickPtr =320;
*Fr_CyclePtr= 2;
*Fr_MacroTickPtr =228;
return E_OK; 
}
if((LucIndex == 17) || (LucIndex == 22))
{
*Fr_CyclePtr= 8;
*Fr_MacroTickPtr =519;
return E_OK; 
} 
if(LucIndex == 18) 
{
*Fr_CyclePtr= 13;
*Fr_MacroTickPtr =320;
return E_OK; 
}
if((LucIndex == 19) || (LucIndex == 23))
{
*Fr_CyclePtr= 12;
*Fr_MacroTickPtr =479;
return E_OK; 
//return E_NOT_OK; 
}
if(LucIndex == 20)
{
*Fr_CyclePtr= 2;
*Fr_MacroTickPtr =100;
return E_OK; 
}
if(LucIndex == 24) 
{
*Fr_CyclePtr= 8;
*Fr_MacroTickPtr =400;
return E_OK; 
}
if(LucIndex == 25) 
{
*Fr_CyclePtr= 12;
*Fr_MacroTickPtr =400;
return E_OK; 
}
if((LucIndex == 26) || (LucIndex == 27))
{
*Fr_CyclePtr= 2;
*Fr_MacroTickPtr =10;
return E_OK; 
}
if(LucIndex == 28) 
{
*Fr_CyclePtr= 15;
*Fr_MacroTickPtr =400;
return E_OK; 
}
return E_OK; 
}
  void TestFr_GetGlobalTimeSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucGetGlobalTimeRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_GetGlobalTime()                   **
*******************************************************************************/
boolean TestFr_GetGlobalTime(App_DataValidateType LddDataValidate,
uint8 Fr_CtrlIdx,uint8* FrIf_CyclePtr, uint16* FrIf_MacroTickPtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucGetGlobalTime == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (*Fr_GpCyclePtr == *FrIf_CyclePtr) &&
        (*Fr_GpMacroTickPtr == *FrIf_MacroTickPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucGetGlobalTime = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucGetGlobalTime == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
  
/*******************************************************************************
**                            Fr_GetChannelStatus()                           **
*******************************************************************************/  
Std_ReturnType Fr_GetChannelStatus(uint8 Fr_CtrlIdx, 
             P2VAR(uint16,AUTOAMTIC,FRIF_APPL_DATA)Fr_ChannelAStatusPtr, 
             P2VAR(uint16,AUTOAMTIC,FRIF_APPL_DATA)Fr_ChannelBStatusPtr)
{
 static uint8 LucIndex=0;
  Fr_GucCtrlIdx  = Fr_CtrlIdx;
  Fr_GpChannelAStatusPtr = Fr_ChannelAStatusPtr;
  Fr_GpChannelBStatusPtr = Fr_ChannelBStatusPtr;
 Fr_GucGetChannelStatus++;
 
 if(Fr_GucGetChannelStatusRetVal == E_NOT_OK)
 {
    return E_NOT_OK;
 }
 if((LucIndex == 0) || (LucIndex == 1))
 {
   *Fr_ChannelAStatusPtr = 0x3E36;
   *Fr_ChannelBStatusPtr =0x3E36;
    LucIndex++;
 }
 else if (LucIndex == 2) 
 {
    *Fr_ChannelAStatusPtr = 1;
    *Fr_ChannelBStatusPtr =1;
     LucIndex++;
 }
 else if (LucIndex == 3)
 {
     *Fr_ChannelAStatusPtr = 1;
    *Fr_ChannelBStatusPtr =1;
    LucIndex =0;
 }
 /*if(LucIndex % 2)
 {
    *Fr_ChannelAStatusPtr = 1;
    *Fr_ChannelBStatusPtr =1;
 }
 else
 {
    *Fr_ChannelAStatusPtr = 0x3E36;
    *Fr_ChannelBStatusPtr =0x3E36;
 }*/

   return E_OK;
}
/*******************************************************************************
**                         TestFr_GetChannelStatus()                       **
*******************************************************************************/
boolean TestFr_GetChannelStatus(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx,P2VAR(uint16, AUTOMATIC, FRIF_APPL_DATA)
  FrIf_ChannelAStatusPtr, P2VAR(uint16, AUTOMATIC, FRIF_APPL_DATA)
  FrIf_ChannelBStatusPtr)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {

   /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      
	  /* Validate invocation count and Mode  */
      if((Fr_GucGetChannelStatus == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) && (Fr_GpChannelAStatusPtr == 
        FrIf_ChannelAStatusPtr) && (Fr_GpChannelBStatusPtr ==
        FrIf_ChannelBStatusPtr)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucGetChannelStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucGetChannelStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
	default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestFr_GetChannelStatus() */

void TestFr_GetChannelStatusSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucGetChannelStatusRetVal = LddReturnVal;
  }
/*******************************************************************************
**                            Fr_GetClockCorrection()               **
*******************************************************************************/
Std_ReturnType Fr_GetClockCorrection(uint8 Fr_CtrlIdx,
  sint16* FrIf_RateCorrectionPtr, sint32* FrIf_OffsetCorrectionPtr)
{
    Fr_GucCtrlIdx = Fr_CtrlIdx;
    Fr_GpRateCorrectionPtr = FrIf_RateCorrectionPtr;
    Fr_GpOffsetCorrectionPtr = FrIf_OffsetCorrectionPtr;
    Fr_GucGetClockCorrection++;
    return(Fr_GucGetClockCorrectionRetVal);
}
/*******************************************************************************
**                         TestFr_GetClockCorrectionSetBeh()                  **
*******************************************************************************/
void TestFr_GetClockCorrectionSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucGetClockCorrectionRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_GetClockCorrection()              **
*******************************************************************************/ 
boolean TestFr_GetClockCorrection(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx,
  sint16* FrIf_RateCorrectionPtr, sint32* FrIf_OffsetCorrectionPtr)
{
    boolean LblStepResult;

    LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucGetClockCorrection == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpRateCorrectionPtr == FrIf_RateCorrectionPtr) &&
        (Fr_GpOffsetCorrectionPtr == FrIf_OffsetCorrectionPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucGetClockCorrection = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucGetClockCorrection == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}   

/*******************************************************************************
**                            Fr_GetSyncFrameList()                 **
*******************************************************************************/
Std_ReturnType Fr_GetSyncFrameList(uint8 Fr_CtrlIdx,uint8 Fr_ListSize,
  uint16* FrIf_ChannelAEvenListPtr, uint16* FrIf_ChannelBEvenListPtr,
  uint16* FrIf_ChannelAOddListPtr, uint16* FrIf_ChannelBOddListPtr)
  {
    Fr_GucCtrlIdx = Fr_CtrlIdx;
    Fr_GucListSize = Fr_ListSize;
    Fr_GpChannelAEvenListPtr = FrIf_ChannelAEvenListPtr;
    Fr_GpChannelBEvenListPtr = FrIf_ChannelBEvenListPtr;
    Fr_GpChannelAOddListPtr = FrIf_ChannelAOddListPtr;
    Fr_GpChannelBOddListPtr = FrIf_ChannelBOddListPtr;
    Fr_GucGetSyncFrameList++;
    return(Fr_GucGetSyncFrameListRetVal);
  }
void TestFr_GetSyncFrameListSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucGetSyncFrameListRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_GetSyncFrameList()                **
*******************************************************************************/ 
boolean TestFr_GetSyncFrameList(App_DataValidateType LddDataValidate, 
  uint8 Fr_CtrlIdx,uint8 Fr_ListSize,
  uint16* FrIf_ChannelAEvenListPtr, uint16* FrIf_ChannelBEvenListPtr,
  uint16* FrIf_ChannelAOddListPtr, uint16* FrIf_ChannelBOddListPtr)
{
    boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucGetSyncFrameList == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpChannelAEvenListPtr == FrIf_ChannelAEvenListPtr) &&
        (Fr_GpChannelBEvenListPtr == FrIf_ChannelBEvenListPtr) &&
        (Fr_GucListSize == Fr_ListSize) &&
        (Fr_GpChannelAOddListPtr == FrIf_ChannelAOddListPtr) &&
        (Fr_GpChannelBOddListPtr == FrIf_ChannelBOddListPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucGetSyncFrameList = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucGetSyncFrameList == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}   
/*******************************************************************************
**                            Fr_GetNumOfStartupFrames()            **
*******************************************************************************/
Std_ReturnType Fr_GetNumOfStartupFrames(uint8 Fr_CtrlIdx,
  uint8* FrIf_NumOfStartupFramesPtr)
{
  Fr_GucCtrlIdx = Fr_CtrlIdx;
  Fr_GpNumOfStartupFramesPtr = FrIf_NumOfStartupFramesPtr;
  Fr_GucGetNumOfStartupFrames++;
  return(Fr_GucGetNumOfStartupFramesRetVal);
}
void TestFr_GetNumOfStartupFramesSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucGetNumOfStartupFramesRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_GetNumOfStartupFrames()                     **
*******************************************************************************/ 
boolean TestFr_GetNumOfStartupFrames(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, uint8* FrIf_NumOfStartupFramesPtr)
{
    boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucGetNumOfStartupFrames == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpNumOfStartupFramesPtr == FrIf_NumOfStartupFramesPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucGetNumOfStartupFrames = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucGetNumOfStartupFrames == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}   
/*******************************************************************************
**                            Fr_DisableLPdu()                      **
*******************************************************************************/
Std_ReturnType Fr_DisableLPdu(uint8 Fr_CtrlIdx,
  uint16 Fr_LPduIdx)
{
  Fr_GucCtrlIdx = Fr_CtrlIdx;
  Fr_GusLPduIdx = Fr_LPduIdx;
  Fr_GucDisableLPdu++;
  return(Fr_GucDisableLPduRetVal);
}
/*******************************************************************************
**                         TestFr_DisableLPduSetBeh()                     **
*******************************************************************************/
void TestFr_DisableLPduSetBeh(Std_ReturnType LddReturnVal)
{
    Fr_GucDisableLPduRetVal = LddReturnVal;
}
/*******************************************************************************
**                         TestFr_DisableLPdu()                     **
*******************************************************************************/ 
boolean TestFr_DisableLPdu(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx)
{
    boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDisableLPdu == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GusLPduIdx == Fr_LPduIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDisableLPdu = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDisableLPdu == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}   
/*******************************************************************************
**                            Fr_GetWakeupRxStatus()                          **
*******************************************************************************/
Std_ReturnType Fr_GetWakeupRxStatus(uint8 Fr_CtrlIdx,
  uint8* FrIf_WakeupRxStatusPtr)
{
  Fr_GucCtrlIdx = Fr_CtrlIdx;
  Fr_GpWakeupRxStatusPtr = FrIf_WakeupRxStatusPtr;
  Fr_GucGetWakeupRxStatus++;
  return(Fr_GucGetWakeupRxStatusRetVal);
}
/*******************************************************************************
**                            TestFr_GetWakeupRxStatusSetBeh()                **
*******************************************************************************/
void TestFr_GetWakeupRxStatusSetBeh(Std_ReturnType LddReturnVal)
{
    Fr_GucGetWakeupRxStatusRetVal = LddReturnVal;
}
/*******************************************************************************
**                         TestFr_GetWakeupRxStatus()                         **
*******************************************************************************/ 
boolean TestFr_GetWakeupRxStatus(App_DataValidateType
           LddDataValidate, uint8 Fr_CtrlIdx, uint8* FrIf_WakeupRxStatusPtr)
{
  boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucGetWakeupRxStatus == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpWakeupRxStatusPtr == FrIf_WakeupRxStatusPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucGetWakeupRxStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucGetWakeupRxStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*******************************************************************************
**                         Fr_TransmitTxLPdu()                                **
*******************************************************************************/
Std_ReturnType Fr_TransmitTxLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx,
  P2CONST(uint8,AUTOMATIC,FRIF_APPL_DATA)Fr_LSduPtr,
  uint8 Fr_LSduLength)
{
  Fr_GucCtrlIdx = Fr_CtrlIdx;
  Fr_GusLPduIdx = Fr_LPduIdx;
  Fr_GucLSduPtr = *Fr_LSduPtr;
  Fr_GucLSduLength = Fr_LSduLength;
  Fr_GucTransmitTxLPduStatus++;
  return E_OK;
}

/*******************************************************************************
**                         TestFr_TransmitTxLPdu()                            **
*******************************************************************************/ 
boolean TestFr_TransmitTxLPdu(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx,
  P2CONST(uint8,AUTOMATIC,FRIF_APPL_DATA)Fr_LSduPtr, uint8 Fr_LSduLength)
{
  boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucTransmitTxLPduStatus == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GusLPduIdx == Fr_LPduIdx) && 
        (Fr_GucLSduPtr == *Fr_LSduPtr) &&
        (Fr_GucLSduLength == Fr_LSduLength))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucTransmitTxLPduStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucTransmitTxLPduStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    case M_VALIDATE:
    {
	if(Fr_LSduLength == 1)
		{
		LblStepResult = STEP_PASSED;
		}
	}
    Fr_GucTransmitTxLPduStatus = 0;
	//FrIf_GaaRamPduTxDataTbl[6].usFrIfTrigTxCounter = 0;
  /*FrIf_GaaRamPduTxDataTbl[6].usFrIfTrigTxCounter to Zero */
  FrIf_CancelTransmit(6);
	break;
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
  
/*******************************************************************************
**                            Fr_CancelTxLPdu()                               **
*******************************************************************************/ 
Std_ReturnType Fr_CancelTxLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx)
{
Fr_GusLPduIdx =Fr_LPduIdx;
Fr_GucCtrlIdx =Fr_CtrlIdx;
Fr_GucCancelTxLPdu++;
return E_OK; 
}
void TestFr_CancelTxLPduSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucCheckTxLPduRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_CancelTxLPdu()                              **
*******************************************************************************/ 
boolean TestFr_CancelTxLPdu(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx)
{
  boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucCancelTxLPdu == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GusLPduIdx == Fr_LPduIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucGetWakeupRxStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucCancelTxLPdu == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
  
 														
/*******************************************************************************
**                            Fr_ReceiveRxLPdu()                              **
*******************************************************************************/
Std_ReturnType Fr_ReceiveRxLPdu(uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx, 
            P2VAR(uint8,AUTOMATIC,FRIF_APPL_DATA)Fr_LSduPtr, 
            P2VAR(Fr_RxLPduStatusType,AUTOMATIC,FRIF_APPL_DATA)Fr_LPduStatusPtr, 
            P2VAR(uint8,AUTOMATIC,FRIF_APPL_DATA)Fr_LSduLengthPtr)
{
uint8 LucIndex;
Fr_GucCtrlIdx = Fr_CtrlIdx;
Fr_GucReceiveRxLPdu++;
*Fr_LSduLengthPtr = 6;
for(LucIndex=0; LucIndex < ((*Fr_LSduLengthPtr) -1) ; LucIndex++, Fr_LSduPtr++)
    {
    *Fr_LSduPtr =LucIndex +1;
    Fr_GaaSduData[LucIndex] =*Fr_LSduPtr;
    }
*Fr_LSduPtr = 0x8;
Fr_GaaSduData[LucIndex] =*Fr_LSduPtr;
if(Fr_LPduIdx == 7)
    {
    *Fr_LPduStatusPtr = FR_NOT_RECEIVED;
    return(E_NOT_OK);
    }
else if(Fr_LPduIdx == 12)
    {
    *Fr_LPduStatusPtr = FR_RECEIVED_MORE_DATA_AVAILABLE;
	Fr_LSduPtr[27] =0x01;
    Fr_LSduPtr[5] =0x01;	
    return(E_OK);
    }
else if(Fr_LPduIdx == 8)
	{
	*Fr_LPduStatusPtr = FR_RECEIVED;
	Fr_LSduPtr[9] =0x80;	
	return(E_OK);
	}
else if(Fr_LPduIdx == 10)
	{
	*Fr_LPduStatusPtr = FR_RECEIVED;
	Fr_LSduPtr[27] =0x02;	
    return(E_OK);
	}
else
    {
    *Fr_LPduStatusPtr = FR_RECEIVED;
    return(E_OK);
    }

}
/*******************************************************************************
**                         TestFr_ReceiveRxLPdu()                       **
*******************************************************************************/
boolean TestFr_ReceiveRxLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx,uint8 PduIength,P2CONST(uint8,AUTOMATIC,FRIF_APPL_DATA)SduPtr)
{
  boolean LblStepResult;
  uint8   LucIndex;
  uint8 LblRetValue;
  LblStepResult = STEP_FAILED;
  LblRetValue = 0;
  
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
    for(LucIndex=0; LucIndex < PduIength ; LucIndex++, SduPtr++)
	  {
	    if(Fr_GaaSduData[LucIndex] != *SduPtr)
		{
		 LblRetValue =1;
         LucIndex = PduIength;
		}
	  }
    
      /* Validate invocation count and Mode  */
      if((Fr_GucReceiveRxLPdu == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) && (LblRetValue == 0)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucReceiveRxLPdu = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucReceiveRxLPdu == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucReceiveRxLPdu = 0;
      break;
    }
    case M_VALIDATE:
    {
   /*for(LucIndex=0; LucIndex < PduIength ; LucIndex++, SduPtr++)
	  {
	    if(Fr_GaaSduData[LucIndex] != *SduPtr)
		{
		 LblRetValue =1;
         LucIndex = PduIength;
		}
	  }
	 Validate invocation count and Mode && (LblRetValue == 0) */
      if((Fr_GucReceiveRxLPdu > 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) ) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucReceiveRxLPdu = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestFr_ReceiveRxLPdu() */

/*******************************************************************************
**                         TestFrTp_FrIfRxIndication()                        **
*******************************************************************************/
boolean TestFrTp_FrIfRxIndication(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx)
{
  boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucReceiveTxLPduStatus == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GusLPduIdx == Fr_LPduIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucReceiveTxLPduStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucReceiveTxLPduStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
/*******************************************************************************
**                         TestFrNm_FrIfRxIndication()                        **
*******************************************************************************/
boolean TestFrNm_FrIfRxIndication(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx)
{
  boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucReceiveTxLPduStatus == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GusLPduIdx == Fr_LPduIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucReceiveTxLPduStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucReceiveTxLPduStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*******************************************************************************
**                         TestFrTp_FrIfTransmitTxLPdu()                      **
*******************************************************************************/
boolean TestFrTp_FrIfTransmitTxLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucTransmitTxLPduStatus == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucTransmitTxLPduStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucTransmitTxLPduStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
/*******************************************************************************
**                         TestFrNm_FrIfTransmitTxLPdu()                      **
*******************************************************************************/
boolean TestFrNm_FrIfTransmitTxLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucTransmitTxLPduStatus == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucTransmitTxLPduStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucTransmitTxLPduStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
/*******************************************************************************
**                         TestPduR_FrIfTransmitTxLPdu()                      **
*******************************************************************************/
boolean TestPduR_FrIfTransmitTxLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucTransmitTxLPduStatus == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucTransmitTxLPduStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucTransmitTxLPduStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*******************************************************************************
**                         TestXcp_FrIfTransmitTxLPdu()                       **
*******************************************************************************/
boolean TestXcp_FrIfTransmitTxLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucTransmitTxLPduStatus == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucTransmitTxLPduStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucTransmitTxLPduStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*******************************************************************************
**                            Fr_CheckTxLPduStatus()                          **
*******************************************************************************/

Std_ReturnType Fr_CheckTxLPduStatus(uint8 Fr_CtrlIdx,
  uint16 Fr_LPduIdx, P2VAR(Fr_TxLPduStatusType,AUTOMATIC,FRIF_APPL_DATA)
  Fr_TxLPduStatusPtr)
{
Fr_GucCtrlIdx =Fr_CtrlIdx;
Fr_GucLSduPtr = 0;
if(Fr_GucCheckTxLPduRetVal)
{
Fr_GucCheckTxLPduRetVal =0;
*Fr_TxLPduStatusPtr = FR_TRANSMITTED;
Fr_GucCheckTxLPduStatus++;
return E_OK;
}
if(Fr_LPduIdx == 1)
*Fr_TxLPduStatusPtr = FR_NOT_TRANSMITTED;
else
*Fr_TxLPduStatusPtr = FR_TRANSMITTED;
Fr_GucCheckTxLPduStatus++;
return E_OK;   
}
 void TestFr_CheckTxLPduSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucCheckTxLPduRetVal = LddReturnVal;
  }

/*******************************************************************************
**                            TestFr_CheckTxLPduStatus()                **
*******************************************************************************/
boolean TestFr_CheckTxLPduStatus(App_DataValidateType LddDataValidate
    ,uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx,
    P2VAR(Fr_TxLPduStatusType,AUTOMATIC,FRIF_APPL_DATA) Fr_TxLPduStatusPtr) 
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {

   /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

     /* Validate invocation count and Mode  */
      if(Fr_GucCheckTxLPduStatus == 0x01) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucCheckTxLPduStatus = 0;
      break;
    } /* End case S_VALIDATE: */
     /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucCheckTxLPduStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      if (Fr_CtrlIdx == Fr_LPduIdx)
      {		
        UNUSED(Fr_TxLPduStatusPtr);
      }
      break;
    } /* Case to handle API not invoked for single occurance */
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
    	
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestFr_StartCommunication() */

/*******************************************************************************
**                         Fr_PrepareLPdu()                                   **
*******************************************************************************/
Std_ReturnType Fr_PrepareLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx)
{
Fr_GucCtrlIdx =Fr_CtrlIdx;
Fr_GusLPduIdx = Fr_LPduIdx;
Fr_GucPrepareLPdu++;
return E_OK;  
}

/*******************************************************************************
**                         TestFr_PrepareLPdu()                               **
*******************************************************************************/
boolean TestFr_PrepareLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx)
{

  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
   /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      
	  
	  /* Validate invocation count and Mode  */
      if((Fr_GucPrepareLPdu == 0x01) && (Fr_GucCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GusLPduIdx == Fr_LPduIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucPrepareLPdu = 0;
      break;
    } /* End case S_VALIDATE: */
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
    	
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestFr_CheckTxLPduStatus() */ 


/*******************************************************************************
**                         TestFrTp_FrIfTxConfirmation()                     **
*******************************************************************************/ 
boolean TestFrTp_FrIfTxConfirmation (App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucCheckTxLPduStatus == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucCheckTxLPduStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucCheckTxLPduStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
/*******************************************************************************
**                         TestFrNm_FrIfTxConfirmation()                     **
*******************************************************************************/ 
boolean TestFrNm_FrIfTxConfirmation (App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucCheckTxLPduStatus == 0x01) &&
        (Fr_GucCtrlIdx == Fr_CtrlIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucCheckTxLPduStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucCheckTxLPduStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*******************************************************************************
**                       TestFr_DefaultBehavior()                             **
*******************************************************************************/
void TestFrIf_DefaultBehavior(void)
{
  Fr_GucTransmitTxLPduStatus = 0;
  Fr_GucCheckTxLPduStatus = 0;
  Fr_GucReceiveRxLPdu = 0;
  Fr_GucPrepareLPdu = 0;
} /* End TestFr_DefaultBehavior() */

/*******************************************************************************
**                            FrTrcv_TrcvCheckWakeupByTransceiver()           **
*******************************************************************************/
void FrTrcv_TrcvCheckWakeupByTransceiver(uint8 FrTrcv_TrcvIdx)
{
  Fr_GucTrcvCtrlIdx = FrTrcv_TrcvIdx;
  Fr_GucTrcvCheckWakeupByTransceiver++;
}

/*******************************************************************************
**                  TestFrTrcv_TrcvCheckWakeupByTransceiver()                 **
*******************************************************************************/
boolean TestFrTrcv_TrcvCheckWakeupByTransceiver(App_DataValidateType 
LddDataValidate, uint8 FrTrcv_TrcvIdx)
{

  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
   /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      
	  
	  /* Validate invocation count and Mode  */
      if((Fr_GucTrcvCheckWakeupByTransceiver == 0x01) && 
          (Fr_GucTrcvCtrlIdx == FrTrcv_TrcvIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucTrcvCheckWakeupByTransceiver = 0;
      break;
    } /* End case S_VALIDATE: */
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }

  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestFrTrcv_TrcvCheckWakeupByTransceiver() */
/*******************************************************************************
**                            FrIf_39_DriverASetAbsoluteTimer()               **
*******************************************************************************/
  
Std_ReturnType FrIf_39_DriverASetAbsoluteTimer(uint8 Fr_CtrlIdx)
{
  Fr_GucCtrlIdx = Fr_CtrlIdx;
  Fr_GucDriverASetAbsoluteTimer++;
  return E_OK;
}

/*******************************************************************************
**                  TestFrIf_39_DriverASetAbsoluteTimer()                     **
*******************************************************************************/
boolean TestFrIf_39_DriverASetAbsoluteTimer(App_DataValidateType 
LddDataValidate, uint8 Fr_CtrlIdx)
{

  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
   /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      
	  
	  /* Validate invocation count and Mode  */
      if((Fr_GucDriverASetAbsoluteTimer == 0x01) && 
          (Fr_GucCtrlIdx == Fr_CtrlIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDriverASetAbsoluteTimer = 0;
      break;
    } /* End case S_VALIDATE: */
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }

  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestFrIf_39_DriverASetAbsoluteTimer() */
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
