/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Fr.h                                                          **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FR Stub                                               **
**                                                                            **
**  PURPOSE   : Declaration of Fr Stub  functions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef FR_H
#define FR_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
/*
 * This header file includes all the standard data types, platform dependent
 * header file and common return types
 */
#include "Std_Types.h"
#include "Fr_GeneralTypes.h"
#include "ComStack_Types.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define FR_AR_RELEASE_MAJOR_VERSION      0x04
#define FR_AR_RELEASE_MINOR_VERSION      0x00
#define FR_AR_RELEASE_REVISION_VERSION   0x03

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/*
 * Defining the structure to store the parameters of Det Report Error function
 */
typedef uint8 Fr_ConfigType;

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
/*Fr_39_DriverA Dummy files needs to be moved to Fr_39_DriverA*/
extern Std_ReturnType Fr_ControllerInit(uint8 Fr_CtrlIdx);

extern Std_ReturnType FrIf_39_DriverASetAbsoluteTimer(uint8 Fr_CtrlIdx);

extern Std_ReturnType Fr_SetAbsoluteTimer(uint8 Fr_CtrlIdx,
  uint8 FrIf_AbsTimerIdx, uint8 FrIf_Cycle, uint16 FrIf_Offset);

extern Std_ReturnType Fr_EnableAbsoluteTimerIRQ(uint8 Fr_CtrlIdx,
  uint8 Fr_AbsTimerIdx);

extern Std_ReturnType Fr_AckAbsoluteTimerIRQ(uint8 Fr_CtrlIdx,
  uint8 Fr_AbsTimerIdx);

extern Std_ReturnType Fr_StartCommunication(uint8 Fr_CtrlIdx);

extern Std_ReturnType Fr_HaltCommunication (uint8 Fr_CtrlIdx);

extern Std_ReturnType Fr_AbortCommunication (uint8 Fr_CtrlIdx);

extern Std_ReturnType Fr_SetWakeupChannel(uint8 Fr_CtrlIdx,
   Fr_ChannelType Fr_ChnlIdx);

extern Std_ReturnType Fr_SendWUP(uint8 Fr_CtrlIdx);

extern Std_ReturnType Fr_GetPOCStatus(uint8 Fr_CtrlIdx,
  Fr_POCStatusType* FrIf_POCStatusPtr);

extern Std_ReturnType Fr_GetGlobalTime(uint8 Fr_CtrlIdx,
  uint8* FrIf_CyclePtr, uint16* FrIf_MacroTickPtr);

extern Std_ReturnType Fr_AllowColdstart(uint8 Fr_CtrlIdx);

extern Std_ReturnType Fr_CancelAbsoluteTimer(uint8 Fr_CtrlIdx,
   uint8 Fr_AbsTimerIdx);

extern Std_ReturnType Fr_CancelAbsoluteTimerIRQ(uint8 Fr_CtrlIdx,
   uint8 Fr_AbsTimerIdx);

extern Std_ReturnType Fr_DisableAbsoluteTimerIRQ(uint8 Fr_CtrlIdx,
   uint8 Fr_AbsTimerIdx);

extern Std_ReturnType Fr_GetAbsoluteTimerIRQStatus(uint8 Fr_CtrlIdx,
   uint8 Fr_AbsTimerIdx, boolean* FrIf_IRQStatusPtr);

extern Std_ReturnType Fr_AllSlots(uint8 Fr_CtrlIdx);

extern Std_ReturnType Fr_GetChannelStatus(uint8 Fr_CtrlIdx,
   uint16* FrIf_ChannelAStatusPtr, uint16* FrIf_ChannelBStatusPtr);

extern Std_ReturnType Fr_GetClockCorrection(uint8 Fr_CtrlIdx,
  sint16* FrIf_RateCorrectionPtr, sint32* FrIf_OffsetCorrectionPtr);

extern Std_ReturnType Fr_GetSyncFrameList(uint8 Fr_CtrlIdx,uint8 Fr_ListSize,
  uint16* FrIf_ChannelAEvenListPtr, uint16* FrIf_ChannelBEvenListPtr,
  uint16* FrIf_ChannelAOddListPtr, uint16* FrIf_ChannelBOddListPtr);

extern Std_ReturnType Fr_GetNumOfStartupFrames(uint8 Fr_CtrlIdx,
  uint8* FrIf_NumOfStartupFramesPtr);

extern Std_ReturnType Fr_GetWakeupRxStatus(uint8 Fr_CtrlIdx,
  uint8* FrIf_WakeupRxStatusPtr);

extern Std_ReturnType Fr_CancelTxLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx);

extern Std_ReturnType Fr_DisableLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx);

extern Std_ReturnType Fr_ReconfigLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx,
   uint16 Fr_FrameId, Fr_ChannelType Fr_ChnlIdx, uint8 Fr_CycleRepetition,
     uint8 Fr_CycleOffset, uint8 Fr_PayloadLength,  uint16 Fr_HeaderCRC );
extern Std_ReturnType Fr_GetNmVector(uint8 Fr_CtrlIdx, uint8* Fr_NmVectorPtr);

extern Std_ReturnType Fr_TransmitTxLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx,
   P2CONST(uint8,AUTOMATIC,FRIF_APPL_DATA)Fr_LSduPtr,uint8 Fr_LSduLength);

extern Std_ReturnType Fr_ReceiveRxLPdu(uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx,
  P2VAR(uint8,AUTOMATIC,FRIF_APPL_DATA)Fr_LSduPtr,
  P2VAR(Fr_RxLPduStatusType,AUTOMATIC,FRIF_APPL_DATA)Fr_LPduStatusPtr,
  P2VAR(uint8,AUTOMATIC,FRIF_APPL_DATA)Fr_LSduLengthPtr);

extern Std_ReturnType Fr_CheckTxLPduStatus(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx,
  P2VAR(Fr_TxLPduStatusType,AUTOMATIC,FRIF_APPL_DATA)Fr_TxLPduStatusPtr);
extern Std_ReturnType Fr_PrepareLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx);

extern Std_ReturnType Fr_ReadCCConfig(uint8 Fr_CtrlIdx,
  uint8 FrIf_CCLLParamIndex, uint32* FrIf_CCLLParamValue);

extern void TestFr_StartCommunicationSetBeh(Std_ReturnType LddReturnVal);

extern void TestFr_HaltCommunicationSetBeh(Std_ReturnType LddReturnVal);

extern void TestFr_AbortCommunicationSetBeh(Std_ReturnType LddReturnVal);

extern void TestFr_SetWakeupChannelSetBeh(Std_ReturnType LddReturnVal);

extern void TestFr_SendWUPSetBeh(Std_ReturnType LddReturnVal);

extern void TestFr_GetPOCStatusSetBeh(Std_ReturnType LddReturnVal);

extern void TestFr_GetGlobalTimeSetBeh(Std_ReturnType LddReturnVal);

extern void TestFr_AllowColdstartSetBeh(Std_ReturnType LddReturnVal);

extern void TestFr_AllSlotsSetBeh(Std_ReturnType LddReturnVal);

extern void TestFr_GetChannelStatusSetBeh(
  Std_ReturnType LddReturnVal);

extern void TestFr_GetClockCorrectionSetBeh(
  Std_ReturnType LddReturnVal);

extern void TestFr_GetSyncFrameListSetBeh(
  Std_ReturnType LddReturnVal);

extern void TestFr_GetNumOfStartupFramesSetBeh(
  Std_ReturnType LddReturnVal);

extern void TestFr_GetWakeupRxStatusSetBeh(
  Std_ReturnType LddReturnVal);

extern void TestFr_DisableLPduSetBeh(Std_ReturnType LddReturnVal);

extern void TestFr_ReconfigLPduSetBeh(Std_ReturnType LddReturnVal);

extern void TestFr_GetNmVectorSetBeh(Std_ReturnType LddReturnVal);

extern void TestFr_ReadCCConfigSetBeh(Std_ReturnType LddReturnVal);

extern void TestFr_SetAbsoluteTimerSetBeh(Std_ReturnType LddReturnVal);

extern void TestFr_EnableAbsoluteTimerIRQSetBeh(
  Std_ReturnType LddReturnVal);


extern void TestFr_AckAbsoluteTimerIRQSetBeh(
  Std_ReturnType LddReturnVal);

extern void TestFr_CancelAbsoluteTimerIRQSetBeh(
  Std_ReturnType LddReturnVal);

extern void TestFr_GetAbsoluteTimerIRQStatusSetBeh(
  Std_ReturnType LddReturnVal);

extern void TestFr_DisableAbsoluteTimerIRQSetBeh(
  Std_ReturnType LddReturnVal);

extern void TestFr_CancelAbsoluteTimerSetBeh(
  Std_ReturnType LddReturnVal);

extern boolean TestFr_ControllerInit(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx);

extern boolean TestFr_StartCommunication(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx);

extern boolean TestFr_HaltCommunication(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx);

extern boolean TestFr_AbortCommunication(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx);

extern boolean TestFr_AllowColdstart(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx);

extern boolean TestFr_SetWakeupChannel(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx,
  Fr_ChannelType Fr_ChnlIdx);

extern boolean TestFr_SendWUP(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx);

extern boolean TestFr_TransmitTxLPdu(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx,
  P2CONST(uint8,AUTOMATIC,FRIF_APPL_DATA)Fr_LSduPtr, uint8 Fr_LSduLength);

extern boolean TestFr_AllSlots(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx);

extern boolean TestFr_CancelTxLPdu(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx);

extern boolean TestFr_GetChannelStatus(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx,
  uint16* FrIf_ChannelAStatusPtr, uint16* FrIf_ChannelBStatusPtr);

extern boolean TestFr_GetClockCorrection(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx,
  sint16* FrIf_RateCorrectionPtr, sint32* FrIf_OffsetCorrectionPtr);

extern boolean TestFr_GetSyncFrameList(
  App_DataValidateType LddDataValidate,uint8 Fr_CtrlIdx,uint8 Fr_ListSize,
  uint16* FrIf_ChannelAEvenListPtr, uint16* FrIf_ChannelBEvenListPtr,
  uint16* FrIf_ChannelAOddListPtr, uint16* FrIf_ChannelBOddListPtr);

extern boolean TestFr_GetNumOfStartupFrames(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, uint8* FrIf_NumOfStartupFramesPtr);

extern boolean TestFr_DisableLPdu(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx);

extern boolean TestFr_ReconfigLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx, uint16 Fr_FrameId,
  Fr_ChannelType Fr_ChnlIdx, uint8 Fr_CycleRepetition, uint8 Fr_CycleOffset,
  uint8 Fr_PayloadLength, uint16 Fr_HeaderCRC);

extern boolean TestFr_ReadCCConfig (App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint8 FrIf_CCLLParamIndex,
  uint32* FrIf_CCLLParamValue);

extern boolean TestFr_39_ReconfigLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx, uint16 Fr_FrameId,
  Fr_ChannelType Fr_ChnlIdx, uint8 Fr_CycleRepetition, uint8 Fr_CycleOffset,
  uint8 Fr_PayloadLength, uint16 Fr_HeaderCRC);

extern boolean TestFr_39_GetNmVector(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint8* Fr_NmVectorPtr);

extern boolean TestFr_GetPOCStatus(
  App_DataValidateType LddDataValidate,uint8 Fr_CtrlIdx,
  Fr_POCStatusType* FrIf_POCStatusPtr);

extern boolean TestFr_GetWakeupRxStatus(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx,
  uint8* FrIf_WakeupRxStatusPtr);

extern boolean TestFr_GetGlobalTime(App_DataValidateType LddDataValidate,
uint8 Fr_CtrlIdx,uint8* FrIf_CyclePtr, uint16* FrIf_MacroTickPtr);

extern boolean TestFr_SetAbsoluteTimer(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx,
  uint8 Fr_Cycle, uint16 Fr_Offset);

extern boolean TestFr_EnableAbsoluteTimerIRQ(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx);

extern boolean TestFr_AckAbsoluteTimerIRQ(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx);

extern boolean TestFr_CancelAbsoluteTimer(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx);

extern boolean TestFr_GetAbsoluteTimerIRQStatus(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx,
  boolean* FrIf_IRQStatusPtr);

extern boolean TestFr_DisableAbsoluteTimerIRQ(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx);

extern boolean TestFrTp_FrIfRxIndication(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx);

extern boolean TestFrNm_FrIfRxIndication(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx);

extern boolean TestFrNm_FrIfTxConfirmation(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx);

extern boolean TestFrTp_FrIfTxConfirmation(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx);

extern boolean TestFrTp_FrIfTransmitTxLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx);

extern boolean TestFrNm_FrIfTransmitTxLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx);

extern boolean TestPduR_FrIfTransmitTxLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx);

extern boolean TestXcp_FrIfTransmitTxLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx);
  
extern boolean TestFr_PrepareLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx);

extern boolean TestFr_CheckTxLPduStatus(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx,
  P2VAR(Fr_TxLPduStatusType,AUTOMATIC,FRIF_APPL_DATA) Fr_TxLPduStatusPtr);

extern boolean TestFr_ReceiveRxLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx,uint8 PduIength,
  P2CONST(uint8,AUTOMATIC,FRIF_APPL_DATA)SduPtr);

extern void TestFr_CheckTxLPduSetBeh(Std_ReturnType LddReturnVal);

extern void TestFr_InitSetBeh(void);

extern void TestFr_CancelTxLPduSetBeh(Std_ReturnType LddReturnVal);

extern void Fr_Init(const Fr_ConfigType* Fr_ConfigPtr);

extern boolean TestFr_Init(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo);
#endif /* FR_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

