/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: FrTrcv_DriverB.h                                              **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FrTrcv_DriverB Stub                                   **
**                                                                            **
**  PURPOSE   : Declaration of FrTrcv_DriverB Stub functions                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/

#ifndef FR_TRCVB_H
#define FR_TRCVB_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
/*
 * This header file includes all the standard data types, platform dependent
 * header file and common return types
 */
#include "Std_Types.h"
#include "Fr_GeneralTypes.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define FRTRCV_AR_RELEASE_MAJOR_VERSION      0x04
#define FRTRCV_AR_RELEASE_MINOR_VERSION      0x00
#define FRTRCV_AR_RELEASE_REVISION_VERSION   0x03

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/


/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern boolean TestFrTrcv_TransceiverBCheckWakeupByTransceiver(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx, Fr_ChannelType 
  FrIf_ChnlIdx);
  
extern boolean TestFrTrcv_TransceiverBClearTransceiverWakeup(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx, 
  Fr_ChannelType FrIf_ChnlIdx);
  
extern boolean TestFrTrcv_TransceiverBGetTransceiverMode(
  App_DataValidateType LddDataValidate,uint8 FrTrcv_TrcvIdx, 
  Fr_ChannelType FrIf_ChnlIdx, FrTrcv_TrcvModeType* FrIf_TrcvModePtr);
  
extern Std_ReturnType TestFrTrcv_TransceiverBSetTransceiverMode(
  App_DataValidateType LddDataValidate,uint8 FrTrcv_TrcvIdx,
  Fr_ChannelType FrIf_ChnlIdx,  FrTrcv_TrcvModeType FrTrcv_TrcvMode);
  
extern Std_ReturnType TestFrTrcv_TransceiverBDisableTransceiverBranch(
  App_DataValidateType LddDataValidate,uint8 FrTrcv_TrcvIdx,
  Fr_ChannelType FrIf_ChnlIdx, uint8 FrTrcv_BranchIdx);
  
extern Std_ReturnType TestFrTrcv_TransceiverBEnableTransceiverBranch(
  App_DataValidateType LddDataValidate,uint8 FrTrcv_TrcvIdx,
  Fr_ChannelType FrIf_ChnlIdx, uint8 FrTrcv_BranchIdx);
  
extern Std_ReturnType TestFrTrcv_TransceiverBGetTransceiverError(
  App_DataValidateType LddDataValidate,uint8 FrTrcv_TrcvIdx,
  Fr_ChannelType FrIf_ChnlIdx, uint8 FrTrcv_BranchIdx,uint32* FrIf_BusErrorState);
  
  #endif /* End FR_TRCVB_H */  
/*******************************************************************************
**                      End of Function Prototypes                            **
*******************************************************************************/
