/****************************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,                  **
**  Hyundai MOBIS Company and KEFICO Corporation                                       **
**  Confidential Proprietary Information. Distribution Limited.                        **
**  Do Not Copy Without Prior Permission                                               **
**                                                                                     **
**  SRC-MODULE: FrTrcv_39_DriverB.c                                                    **
**                                                                                     **
**  TARGET    : All                                                                    **
**                                                                                     **
**  PRODUCT   : AUTOSAR FrTrcv_39_DriverB Stub                                         **
**                                                                                     **
**  PURPOSE   : This application file contains the FrTrcv_39_DriverB Stub functions    **
**                                                                                     **
**  PLATFORM DEPENDANT [yes/no]: no                                           	       **
**                                                                            	       **
**  TO BE CHANGED BY USER [yes/no]: no                                        	       **
**                                                                            	       **
****************************************************************************************/

/***************************************************************************************/
**                      Revision History                                      	       **
*****************************************************************************************
** Revision  Date          By     			   Description                             **
*****************************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                         **
****************************************************************************************/

/****************************************************************************************
**                      Include Section                                                **
****************************************************************************************/
#include "Fr.h"
#include "FrTrcv_39_DriverB.h"

/*****************************************************************************************
**                      Global Data Types                                     	        **
*****************************************************************************************/




/*****************************************************************************************
**               TestFrTrcv_TransceiverBGetTransceiverMode()                            **
*****************************************************************************************/
boolean TestFrTrcv_TransceiverBGetTransceiverMode(
  App_DataValidateType LddDataValidate,uint8 FrTrcv_TrcvIdx, 
  FrTrcv_TrcvModeType* FrIf_TrcvModePtr) 
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((GucGetTransceiverMode == 0x01) &&
        (GucFrTrcv_TrcvIdx == FrTrcv_TrcvIdx) &&
        (FrIf_GucTrcvModePtr == FrIf_TrcvModePtr)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      GucGetTransceiverMode = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(GucGetTransceiverMode == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      GucGetTransceiverMode = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*****************************************************************************************
**                         TestFrTrcv_TransceiverBSetTransceiverMode()                  **
*****************************************************************************************/
boolean TestFrTrcv_TransceiverBSetTransceiverMode(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx,
  FrTrcv_TrcvModeType FrTrcv_TrcvMode)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Transceivermodecount == 0x01) &&
        (GucFrTrcv_TrcvIdx == FrTrcv_TrcvIdx) &&
        (FrTrcvGuc_TrcvMode == FrTrcv_TrcvMode)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Transceivermodecount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Transceivermodecount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Transceivermodecount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*****************************************************************************************
**               TestFrTrcv_TransceiverBDisableTransceiverBranch()                      **
*****************************************************************************************/
boolean TestFrTrcv_TransceiverBDisableTransceiverBranch(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx,
  uint8 FrTrcv_BranchIdx)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((GucTrcvDisableTransceiverBranch == 0x01) &&
        (GucFrTrcv_TrcvIdx == FrTrcv_TrcvIdx) &&
        (GucFrTrcv_BranchIdx == FrTrcv_BranchIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      GucTrcvDisableTransceiverBranch = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(GucTrcvDisableTransceiverBranch == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      GucTrcvDisableTransceiverBranch = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*****************************************************************************************
**               TestFrTrcv_TransceiverBEnableTransceiverBranch()                       **
*****************************************************************************************/
boolean TestFrTrcv_TransceiverBEnableTransceiverBranch(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx,
  uint8 FrTrcv_BranchIdx)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((GucTrcvDisableTransceiverBranch == 0x01) &&
        (GucFrTrcv_TrcvIdx == FrTrcv_TrcvIdx) &&
        (GucFrTrcv_BranchIdx == FrTrcv_BranchIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      GucTrcvDisableTransceiverBranch = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(GucTrcvDisableTransceiverBranch == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      GucTrcvDisableTransceiverBranch = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*****************************************************************************************
**                   TestFrTrcv_TransceiverBGetTransceiverError()                       **
*****************************************************************************************/
boolean TestFrTrcv_TransceiverBGetTransceiverError(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx,
  uint8 FrTrcv_BranchIdx,uint32* FrIf_BusErrorState)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((TrcvGetTransceiverError == 0x01) &&
        (GucFrTrcv_TrcvIdx == FrTrcv_TrcvIdx) &&
        (GucFrTrcv_BranchIdx == FrTrcv_BranchIdx) &&
        (GucFrIf_BusErrorState == FrIf_BusErrorState))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      TrcvGetTransceiverError = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(TrcvGetTransceiverError == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      TrcvGetTransceiverError = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*****************************************************************************************
**                    TestFrTrcv_TransceiverBClearTransceiverWakeup()                   **
*****************************************************************************************/
boolean TestFrTrcv_TransceiverBClearTransceiverWakeup(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Transceivermodecount == 0x01) &&
        (GucFrTrcv_TrcvIdx == FrTrcv_TrcvIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Transceivermodecount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Transceivermodecount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Transceivermodecount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
