/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: EthSM_Cbk.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Ethernet State Manager Module                         **
**                                                                            **
**  PURPOSE   : Declaration of EthSM functions                                **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By             Description                         **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M        Initial version                     **
*******************************************************************************/
#ifndef ETHSM_CBK_H
#define ETHSM_CBK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/


#include "ComStack_Types.h"
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/
#define ETHSM_NO_COMMUNICATION       0x01      
#define ETHSM_FULL_COMMUNICATION     0x02  
#define ETHSM_INVALID_NETWORKID	     0x02
#define ETHSM_INVALID_CURRENTSTATE   0x00

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/


extern void EthSm_CtrlModeIndication(uint8 CtrlIdx,Eth_ModeType CtrlMode);

extern void EthSm_TrcvModeIndication(uint8 TrcIdx, EthTrcv_ModeType TrcvMode);
extern Std_ReturnType EthSM_LinkStateChange(uint8 CtrlIdx, 
  EthTrcv_LinkStateType LinkState);
extern boolean TestEthSM_LinkStateChange(App_DataValidateType LddDataValidate,
  uint8* LucExpController, EthTrcv_LinkStateType* LddExpLinkState);
  
#endif /*ETHSM_CBK_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
