/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: EthSM.h                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Ethernet State Manager Module                         **
**                                                                            **
**  PURPOSE   : Declaration of EthSM functions                                **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By             Description                         **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M        Initial version                     **
*******************************************************************************/
#ifndef ETHSM_H
#define ETHSM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

#include "TC_Generic.h"
#include "ComStack_Types.h"
#include "ComM.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR specification version information */
#define ETHSM_AR_RELEASE_MAJOR_VERSION  4
#define ETHSM_AR_RELEASE_MINOR_VERSION  0
#define ETHSM_AR_RELEASE_REVISION_VERSION  3

/* Software version information */
#define ETHSM_SW_MAJOR_VERSION  1
#define ETHSM_SW_MINOR_VERSION  0
#define ETHSM_SW_PATCH_VERSION  0

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/
#define ETHSM_NO_COMMUNICATION       0x01      
#define ETHSM_FULL_COMMUNICATION     0x02  
#define ETHSM_INVALID_NETWORKID	     0x02
#define ETHSM_INVALID_CURRENTSTATE   0x00

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
typedef uint8 EthSM_NetworkModeStateType;

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern void TestEthSM_DefaultBehavior(void);

extern Std_ReturnType EthSM_RequestComMode(NetworkHandleType NetworkHandle, 
ComM_ModeType ComM_Mode);

extern Std_ReturnType EthSM_GetCurrentComMode(NetworkHandleType NetworkHandle, 
P2VAR(ComM_ModeType, AUTOMATIC, COMM_APPL_DATA)ComM_ModePtr); 


extern boolean TestEthSM_RequestComMode(App_DataValidateType LucDataValidate,
NetworkHandleType LddExpNetworkHandle, ComM_ModeType LddExpComM_Mode);

extern boolean TestEthSM_GetCurrentComMode(App_DataValidateType LucDataValidate,
NetworkHandleType LddExpNetworkHandle, 
P2VAR(ComM_ModeType, AUTOMATIC, COMM_APPL_DATA) LddExpComM_ModePtr); 

extern void TestEthSM_RequestComModeSetBeh(Std_ReturnType LddReturnVal);

extern void TestEthSM_GetCurrentComModeSetBeh(Std_ReturnType LddReturnVal);

extern void TestEthSM_GetCurrentComModeSetMode(ComM_ModeType LddComMMode);

#endif /* ETHSM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
