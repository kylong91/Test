/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: EthSM.c                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Ethernet State Manager Module                         **
**                                                                            **
**  PURPOSE   : Declaration of EthSM stub functions                           **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#ifdef ETHIF_MODULE_ACTIVE
#include "EthIf.h"
#include "EthSM_Cbk.h"
#endif
#include "EthSM.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
uint8 EthSM_GucRequestComModeCount;
uint8 EthSM_GucGetCurrentComModeCount;
NetworkHandleType EthSM_GddNetworkHandle;
Std_ReturnType EthSM_GddGetCurrentRetVal;
Std_ReturnType EthSM_GddReqComRetVal;
#ifdef COMM_MODULE_ACTIVE
ComM_ModeType EthSM_GddComM_Mode;
ComM_ModeType EthSM_GddGetCurComM_Mode;
#endif

#ifdef ETHIF_MODULE_ACTIVE
uint8  EthSM_GucCntrlModeIndiCount = 0;
Eth_ModeType  EthSM_GddControllerMode ;
uint8  EthSM_GucControllerId;

uint8  EthSM_GucTrcvLinkCount = 0;
uint8  EthSM_GucTrcvLinkCheckCount = 0;
EthTrcv_LinkStateType  EthSM_GddTransceiverLinkState[5] ;
uint8  EthSM_GucTrcvLinkTrcvIdx[5];
Std_ReturnType EthSM_LinkStateRetVal;
#endif
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
**                         TestEthSM_DefaultBehavior()                         **
*******************************************************************************/
void TestEthSM_DefaultBehavior(void)
{
  EthSM_GucGetCurrentComModeCount = 0;
  EthSM_GucRequestComModeCount = 0;
  #ifdef COMM_MODULE_ACTIVE
  EthSM_GddGetCurComM_Mode = COMM_NO_COMMUNICATION;
  #endif
  EthSM_GddReqComRetVal = 0;
  EthSM_GddGetCurrentRetVal = 0;
}
#ifdef COMM_MODULE_ACTIVE
/*******************************************************************************
**                      EthSM_RequestComMode()                                **
*******************************************************************************/
Std_ReturnType EthSM_RequestComMode(NetworkHandleType NetworkHandle, 
  ComM_ModeType ComM_Mode)
{
  #ifndef TYPICAL_CONFIG
  EthSM_GucRequestComModeCount++;
  EthSM_GddNetworkHandle = NetworkHandle;
  EthSM_GddComM_Mode = ComM_Mode;
  #endif
  return(EthSM_GddReqComRetVal);
}/* End EthSM_RequestComMode() */

/*******************************************************************************
**                       TestEthSM_RequestComMode()                           **
*******************************************************************************/
boolean TestEthSM_RequestComMode(App_DataValidateType LucDataValidate,
NetworkHandleType LddExpNetworkHandle, ComM_ModeType LddExpComM_Mode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((EthSM_GucRequestComModeCount == 0x01) && 
        (EthSM_GddNetworkHandle == LddExpNetworkHandle) && 
        (EthSM_GddComM_Mode == LddExpComM_Mode))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      EthSM_GucRequestComModeCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEthSM_RequestComMode() */

/*******************************************************************************
**                       TestEthSM_GetCurrentComModeSetMode()                 **
*******************************************************************************/

void TestEthSM_GetCurrentComModeSetMode(ComM_ModeType LddComMMode)
{
  EthSM_GddGetCurComM_Mode = LddComMMode;
}/* End TestEthSM_GetCurrentComModeSetMode() */

/*******************************************************************************
**                       EthSM_GetCurrentComMode()                            **
*******************************************************************************/
Std_ReturnType EthSM_GetCurrentComMode(NetworkHandleType NetworkHandle, 
P2VAR(ComM_ModeType, AUTOMATIC, COMM_APPL_DATA)ComM_ModePtr)
{
  #ifndef TYPICAL_CONFIG
  EthSM_GucGetCurrentComModeCount++;
  EthSM_GddNetworkHandle = NetworkHandle;
	*ComM_ModePtr = EthSM_GddGetCurComM_Mode ;
  #endif
	return(EthSM_GddGetCurrentRetVal);
}/* End EthSM_GetCurrentComMode() */

/*******************************************************************************
**                       TestEthSM_GetCurrentComMode()                        **
*******************************************************************************/
boolean TestEthSM_GetCurrentComMode(App_DataValidateType LucDataValidate,
NetworkHandleType LddExpNetworkHandle, 
P2VAR(ComM_ModeType, AUTOMATIC, COMM_APPL_DATA) LddExpComM_ModePtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {  
      if((EthSM_GucGetCurrentComModeCount != 0x00) && 
        (EthSM_GddNetworkHandle == LddExpNetworkHandle) && 
        (EthSM_GddGetCurComM_Mode == *LddExpComM_ModePtr))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      EthSM_GucGetCurrentComModeCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEthSM_GetCurrentComMode() */

/*******************************************************************************
**                         TestEthSM_SetBehavior()                            **
*******************************************************************************/
void TestEthSM_RequestComModeSetBeh(Std_ReturnType LddReturnVal)
{
  EthSM_GucGetCurrentComModeCount = 0;
  EthSM_GucRequestComModeCount = 0;
  EthSM_GddReqComRetVal = LddReturnVal;
}

void TestEthSM_GetCurrentComModeSetBeh(Std_ReturnType LddReturnVal)
{
  EthSM_GucGetCurrentComModeCount = 0;
  EthSM_GucRequestComModeCount = 0;
  EthSM_GddGetCurrentRetVal = LddReturnVal;
}
#endif
#ifdef ETHIF_MODULE_ACTIVE
/*******************************************************************************
**                       EthSm_CtrlModeIndication()                           **
*******************************************************************************/
void EthSm_CtrlModeIndication(uint8 CtrlIdx,
Eth_ModeType CtrlMode)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual CtrlIdx and CtrlMode into Global variables */
  EthSM_GucCntrlModeIndiCount++;
  EthSM_GucControllerId = CtrlIdx;
  EthSM_GddControllerMode = CtrlMode;
  #endif

} /* End EthSm_CtrlModeIndication() */
/*******************************************************************************
**                   TestEthSm_CtrlModeIndication()                           **
*******************************************************************************/
boolean TestEthSm_CtrlModeIndication(App_DataValidateType LddDataValidate,
  uint8 ExpControllerId, Eth_ModeType ExpControllerMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ControllerId and ControllerMode */
      if((EthSM_GucCntrlModeIndiCount == 0x01) &&
        (EthSM_GucControllerId == ExpControllerId) &&
        (EthSM_GddControllerMode == ExpControllerMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      EthSM_GucCntrlModeIndiCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(EthSM_GucCntrlModeIndiCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
      EthSM_GucCntrlModeIndiCount = 0;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCanSM_ControllerModeIndication */

uint8  EthSM_GucTrcvModeIndiCount = 0;
EthTrcv_ModeType  EthSM_GddTransceiverMode ;
uint8  EthSM_GucTransceiverId;
/*******************************************************************************
**                    EthSm_TrcvModeIndication()                              **
*******************************************************************************/
void EthSm_TrcvModeIndication(uint8 TrcIdx, EthTrcv_ModeType TrcvMode)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual TrcIdx and TrcvMode into Global variables */
  EthSM_GucTransceiverId = TrcIdx;
  EthSM_GddTransceiverMode = TrcvMode;
  EthSM_GucTrcvModeIndiCount++;
  #endif
} /* End EthSm_TrcvModeIndication() */

/*******************************************************************************
**                   TestEthSm_TrcvModeIndication()                           **
*******************************************************************************/
boolean TestEthSm_TrcvModeIndication(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiverId, EthTrcv_ModeType ExpTransceiverMode)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TransceiverId and TransceiverMode */
      if((EthSM_GucTrcvModeIndiCount == 0x01) &&
        (EthSM_GucTransceiverId == ExpTransceiverId) &&
        (EthSM_GddTransceiverMode == ExpTransceiverMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      EthSM_GucTrcvModeIndiCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(EthSM_GucTrcvModeIndiCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      
      /* Reset API invocation Count after validating the API invocation */
      EthSM_GucTrcvModeIndiCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestEthSm_TrcvModeIndication */

/*******************************************************************************
**                    EthSM_TrcvLinkStateChg()                                **
*******************************************************************************/

Std_ReturnType EthSM_LinkStateChange(uint8 CtrlIdx,
  EthTrcv_LinkStateType LinkState)
{
  #ifndef TYPICAL_CONFIG
  EthSM_GucTrcvLinkTrcvIdx[EthSM_GucTrcvLinkCount] = CtrlIdx;
  EthSM_GddTransceiverLinkState[EthSM_GucTrcvLinkCount] = LinkState;
  EthSM_GucTrcvLinkCount++;
  #endif
  return(EthSM_LinkStateRetVal);
}
/*******************************************************************************
**                     TestEthSM_LinkStateChange()                            **
*******************************************************************************/

boolean TestEthSM_LinkStateChange(App_DataValidateType LddDataValidate,
  uint8* LucExpController, EthTrcv_LinkStateType* LddExpLinkState)
{
  boolean LblStepResult;
  uint8 lucCheck;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  lucCheck = 0x00;
  
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((EthSM_GucTrcvLinkCount > 0x00) &&
        (EthSM_GucTrcvLinkTrcvIdx[0] == *LucExpController) &&
        (EthSM_GddTransceiverLinkState[0] == *LddExpLinkState))
      {
        LblStepResult = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      EthSM_GucTrcvLinkCount = 0;
      break;
    } /* End case S_VALIDATE: */
   
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < EthSM_GucTrcvLinkCount; LucIndex++)
      {
        /* Validate Network and CurrentState */
        if((EthSM_GucTrcvLinkTrcvIdx[LucIndex] == *LucExpController) &&
          (EthSM_GddTransceiverLinkState[LucIndex] == *LddExpLinkState)&&
          (lucCheck == 0x00))
        {
          LblStepResult = STEP_PASSED;          
        }
        else
        {
          lucCheck = 0x01;
        }
        LucExpController++;
        LddExpLinkState++;
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      EthSM_GucTrcvLinkCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(EthSM_GucTrcvLinkCheckCount == EthSM_GucTrcvLinkCount)
      {
        EthSM_GucTrcvLinkCount = 0;
        EthSM_GucTrcvLinkCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(EthSM_GucTrcvLinkCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      EthSM_GucTrcvLinkCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End  TestEthSM_LinkStateChange() */

#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
