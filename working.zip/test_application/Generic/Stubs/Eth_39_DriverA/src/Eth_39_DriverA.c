/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Eth.c                                                         **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR ETH Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Eth stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     22-Jun-2011   BJV    Initial version                             **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Eth_39_DriverA.h"    

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_DrvAGuc_CtrlInit_Controller;
uint8 Eth_DrvAGuc_CtrlInit_CfgIdx;
uint8 Eth_DrvAGucControllerintCount;
Std_ReturnType Eth_DrvAGdControllerintRetVal;



/*******************************************************************************
**                     Eth_39_DriverA_ControllerInit()                        **
*******************************************************************************/

Std_ReturnType Eth_39_DriverA_ControllerInit( uint8 CtrlIdx, uint8 CfgIdx )
{
  /* Load actual Controller and Transition into Global variables */
  Eth_DrvAGuc_CtrlInit_Controller = CtrlIdx;
  Eth_DrvAGuc_CtrlInit_CfgIdx = CfgIdx;
  Eth_DrvAGucControllerintCount++;

  return(Eth_DrvAGdControllerintRetVal);
} /* End Eth_39_DriverA_ControllerInit() */
/*******************************************************************************/

boolean TestEth_39_DriverA_ControllerInit(App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,uint8 LucExpCfgIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_DrvAGucControllerintCount > 0x00) &&
        (Eth_DrvAGuc_CtrlInit_Controller == LucExpCtrlIdx) &&
        (Eth_DrvAGuc_CtrlInit_CfgIdx == LucExpCfgIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_DrvAGucControllerintCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_DrvAGucControllerintCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_DrvAGucControllerintCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}
/*******************************************************************************
**            END OF Eth_39_DriverA_ControllerInit()                          **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_DrvAGucGetCtrlModeCount;
uint8 Eth_DrvAGucGetController;
Eth_ModeType* Eth_DrvAGdd_GetCtrl_Mode;
Std_ReturnType Eth_DrvAGetCtrlModeRetVal;


/*******************************************************************************
**                    Eth_39_DriverA_GetControllerMode()                      **
*******************************************************************************/
Std_ReturnType Eth_39_DriverA_GetControllerMode(
    uint8 CtrlIdx,
    Eth_ModeType* CtrlModePtr
)
/* Load actual Controller and Transition into Global variables */
{
  Eth_DrvAGucGetController = CtrlIdx;
  Eth_DrvAGdd_GetCtrl_Mode = CtrlModePtr;
  Eth_DrvAGucGetCtrlModeCount++;
  return(Eth_DrvAGetCtrlModeRetVal);
}
/* End Eth_DrvAGetCtrlModeRetVal */
/*******************************************************************************
**                     TestEth_39_DriverA_GetControllerMode()                 **
*******************************************************************************/

boolean TestEth_39_DriverA_GetControllerMode(App_DataValidateType LddDataValidate,
  uint8 LucExpController, Eth_ModeType* LddExpMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_DrvAGucGetCtrlModeCount > 0x00) &&
        (Eth_DrvAGucGetController == LucExpController) &&
        (Eth_DrvAGdd_GetCtrl_Mode != LddExpMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_DrvAGucGetCtrlModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_DrvAGucGetCtrlModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_DrvAGucGetCtrlModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestEth_39_DriverA_GetControllerMode() */
/*******************************************************************************
**            END OF TestEth_39_DriverA_GetControllerMode()                   **
*******************************************************************************/
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_DrvAGucCtrlIdx;
uint8  *Eth_DrvAGucBufIdxPtr;
uint8 **Eth_DrvAGucBufPtr;
uint16 *Eth_DrvAGucLenBytePtr;
uint8 Eth_DrvAGucPrvdTxBufCount;
Std_ReturnType Eth_DrvAGdPrvdTxBufRetVal;

/*******************************************************************************
**                        Eth_39_DriverA_ProvideTxBuffer()                    **
*******************************************************************************/
    
BufReq_ReturnType Eth_39_DriverA_ProvideTxBuffer(
    uint8 CtrlIdx,
    uint8* BufIdxPtr,
    uint8** BufPtr,
    uint16* LenBytePtr
)


{
  /* Load actual Controller and Transition into Global variables */
  Eth_DrvAGucCtrlIdx = CtrlIdx;
  Eth_DrvAGucBufIdxPtr = BufIdxPtr;
  Eth_DrvAGucBufPtr = BufPtr;
  Eth_DrvAGucLenBytePtr = LenBytePtr;
  Eth_DrvAGucPrvdTxBufCount++;

  return(Eth_DrvAGdPrvdTxBufRetVal);
} /* End Eth_DrvAGucTrasRceModeCount */
/*******************************************************************************/

boolean TestEth_39_DriverA_ProvideTxBuffer(App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,uint8* LucExpBufIdxPtr,
  uint8** LucExpBufPtr, uint16* LucExpLenBytePtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_DrvAGucPrvdTxBufCount > 0x00) &&
         (Eth_DrvAGucCtrlIdx == LucExpCtrlIdx) &&
         (Eth_DrvAGucBufIdxPtr != LucExpBufIdxPtr)&&
         (Eth_DrvAGucBufPtr != LucExpBufPtr) &&
         (Eth_DrvAGucLenBytePtr != LucExpLenBytePtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_DrvAGucPrvdTxBufCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_DrvAGucPrvdTxBufCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_DrvAGucPrvdTxBufCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}
/*******************************************************************************
**           END OF  EthIf_ProvideTxBuffer()                                  **
*******************************************************************************/
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_DrvAGucSetCtrlModeCount;
uint8 Eth_DrvAGucSetController;
Eth_ModeType Eth_DrvAGdd_SetCtrl_Mode;
Std_ReturnType Eth_DrvAGdSetCtrlModeRetVal;
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
**                     Eth_39_DriverA_SetControllerMode()                     **
*******************************************************************************/
Std_ReturnType Eth_39_DriverA_SetControllerMode( uint8 CtrlIdx, 
                                                        Eth_ModeType CtrlMode )
{
  /* Load actual Controller and Transition into Global variables */
  Eth_DrvAGucSetController = CtrlIdx;
  Eth_DrvAGdd_SetCtrl_Mode = CtrlMode;
  Eth_DrvAGucSetCtrlModeCount++;

  return(Eth_DrvAGdSetCtrlModeRetVal);
} /* End Eth_SetControllerMode() */

/*******************************************************************************
**                     TestEth_39_DriverA_SetControllerMode()                 **
*******************************************************************************/
boolean TestEth_39_DriverA_SetControllerMode(App_DataValidateType LddDataValidate,
  uint8 LucExpController, Eth_ModeType LddExpMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_DrvAGucSetCtrlModeCount > 0x00) &&
        (Eth_DrvAGucSetController == LucExpController) &&
        (Eth_DrvAGdd_SetCtrl_Mode == LddExpMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_DrvAGucSetCtrlModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_DrvAGucSetCtrlModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_DrvAGucSetCtrlModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCan_SetControllerMode() */

/*******************************************************************************
**             END OF Eth_SetControllerMode()                                 **
*******************************************************************************/
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_DrvAGucCtrlIdx;
Eth_FrameType Eth_DrvAGucFrameType;
uint8 Eth_DrvAGucBufIdx;
uint16 Eth_DrvAGucLenByte;
boolean Eth_DrvAGucTxConfirmation;
uint8*  Eth_DrvAGucPhysAddrPtr;
uint8 Eth_DrvAGucTransmitCount;
Std_ReturnType Eth_DrvAGdTransmitRetVal;

/*******************************************************************************
**                  Eth_39_DriverA_Transmit()                                 **
*******************************************************************************/

Std_ReturnType Eth_39_DriverA_Transmit(
    uint8 CtrlIdx,
    uint8 BufIdx,
    Eth_FrameType FrameType,
    boolean TxConfirmation,
    uint16 LenByte,
    uint8* PhysAddrPtr
)
{
  /* Load actual Controller and Transition into Global variables */
  Eth_DrvAGucCtrlIdx = CtrlIdx;
  Eth_DrvAGucFrameType = FrameType;
  Eth_DrvAGucBufIdx = BufIdx;
  Eth_DrvAGucTxConfirmation = TxConfirmation;
  Eth_DrvAGucLenByte = LenByte;
  Eth_DrvAGucTransmitCount++;
  Eth_DrvAGucPhysAddrPtr = PhysAddrPtr;
   return(Eth_DrvAGdTransmitRetVal);
} /* End Eth_39_DriverA_Transmit()  */
/*******************************************************************************/

boolean TestEth_39_DriverA_Transmit(App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,uint8 LucExpBufIdx,Eth_FrameType LddExpFrameType,
  boolean LucExpTxConfirmation,uint16  LucExpLenByte,uint8* LucExpPhysAddrPtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_DrvAGucTransmitCount > 0x00) &&
        (Eth_DrvAGucCtrlIdx == LucExpCtrlIdx) &&
        (Eth_DrvAGucFrameType == LddExpFrameType)&&
        (Eth_DrvAGucBufIdx == LucExpBufIdx)&&
        (Eth_DrvAGucTxConfirmation == LucExpTxConfirmation)&&
        (Eth_DrvAGucPhysAddrPtr!= LucExpPhysAddrPtr)&&
        (Eth_DrvAGucLenByte == LucExpLenByte))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_DrvAGucTransmitCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_DrvAGucTransmitCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_DrvAGucTransmitCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_DrvAGucGetPhyCtrlIdx;
uint8*  Eth_DrvAGucPhysAddrPtr;
uint8 Eth_DrvAGucGetPhyCount;

/*******************************************************************************
**                  Eth_39_DriverA_Transmit()                                 **
*******************************************************************************/
void Eth_39_DriverA_GetPhysAddr(uint8 CtrlIdx, uint8* PhysAddrPtr)
{
  /* Load actual Controller and Transition into Global variables */
  Eth_DrvAGucGetPhyCtrlIdx = CtrlIdx;
  Eth_DrvAGucGetPhyCount++;
  Eth_DrvAGucPhysAddrPtr = PhysAddrPtr;
} /* End Eth_39_DriverA_Transmit()  */
/*******************************************************************************/

boolean  TestEth_39_DriverA_GetPhysAddr(App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,uint8* LucExpPhysAddrPtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_DrvAGucGetPhyCount > 0x00) &&
        (Eth_DrvAGucGetPhyCtrlIdx == LucExpCtrlIdx)&&
        (Eth_DrvAGucPhysAddrPtr!= LucExpPhysAddrPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_DrvAGucGetPhyCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_DrvAGucGetPhyCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_DrvAGucGetPhyCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}

void Eth_39_DriverA_Receive(
    uint8 CtrlIdx,
    Eth_RxStatusType* RxStatusPtr
){
UNUSED(CtrlIdx);
UNUSED(RxStatusPtr);
}

void Eth_39_DriverA_TxConfirmation(
    uint8 CtrlIdx
){
UNUSED(CtrlIdx);
}
/*******************************************************************************
**             END OF  EthIf_Transmit()                                       **
*******************************************************************************/

