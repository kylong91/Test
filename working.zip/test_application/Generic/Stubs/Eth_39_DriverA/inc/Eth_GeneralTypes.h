/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Eth_GeneralTypes.h                                            **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR ETH Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Eth stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     10-Aug-2012   BCC    Initial version                             **
*******************************************************************************/
#ifndef ETHGENERAL_TYPES_H
#define ETHGENERAL_TYPES_H
/*******************************************************************************
**                      Global Data Types (ECU independent)                   **
*******************************************************************************/
typedef uint16 Eth_FrameType;
typedef uint16 Eth_DataType;
typedef enum
{
  ETH_MODE_DOWN,
  ETH_MODE_ACTIVE
} Eth_ModeType;

typedef enum
{
   /** Ethernet frame has been received, no further frames available */
   ETH_RECEIVED,
   /** Ethernet frame has not been received, no further frames available */
   ETH_NOT_RECEIVED,
   /** Ethernet frame has been received, More frames are available */
   ETH_RECEIVED_MORE_DATA_AVAILABLE
} Eth_RxStatusType;

typedef enum
{
  ETH_STATE_UNINIT,
  ETH_STATE_INIT,
  ETH_STATE_ACTIVE
} Eth_StateType;
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#endif

