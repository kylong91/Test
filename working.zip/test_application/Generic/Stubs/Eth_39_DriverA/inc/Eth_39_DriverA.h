/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Eth_39_DriverA.h                                              **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR ETH Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Eth stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     22-Jun-2011   BJV    Initial version                             **
*******************************************************************************/

#ifndef ETH_39_DRIVERA_H
#define ETH_39_DRIVERA_H

/*******************************************************************************
**                      Include Section                                      **
*******************************************************************************/
#include "TC_Generic.h"
#include "ComStack_Types.h"
#include "Eth_GeneralTypes.h"   
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                     Eth_39_DriverA_ControllerInit()                        **
*******************************************************************************/
extern Std_ReturnType Eth_39_DriverA_ControllerInit( uint8 CtrlIdx, 
                                                                 uint8 CfgIdx );

extern boolean TestEth_39_DriverA_ControllerInit
 (App_DataValidateType LddDataValidate, uint8 LucExpCtrlIdx,uint8 LucExpCfgIdx);

/*******************************************************************************
**            END OF Eth_39_DriverA_ControllerInit()                          **
*******************************************************************************/

/*******************************************************************************
**                    Eth_39_DriverA_GetControllerMode()                      **
*******************************************************************************/
extern Std_ReturnType Eth_39_DriverA_GetControllerMode(
    uint8 CtrlIdx,
    Eth_ModeType* CtrlModePtr
);

/*******************************************************************************
**                     TestEth_39_DriverA_GetControllerMode()                 **
*******************************************************************************/

extern boolean TestEth_39_DriverA_GetControllerMode
(App_DataValidateType LddDataValidate,uint8 LucExpController, 
                                                      Eth_ModeType* LddExpMode);
/*******************************************************************************
**            END OF TestEth_39_DriverA_GetControllerMode()                   **
*******************************************************************************/
/*******************************************************************************
**                        Eth_39_DriverA_ProvideTxBuffer()                    **
*******************************************************************************/
extern BufReq_ReturnType Eth_39_DriverA_ProvideTxBuffer(
    uint8 CtrlIdx,
    uint8* BufIdxPtr,
    uint8** BufPtr,
    uint16* LenBytePtr
);
/*******************************************************************************/

extern boolean TestEth_39_DriverA_ProvideTxBuffer
(App_DataValidateType LddDataValidate,uint8 LucExpCtrlIdx,uint8* LucExpBufIdxPtr
  ,uint8** LucExpBufPtr, uint16* LucExpLenBytePtr);
/*******************************************************************************
**           END OF  EthIf_ProvideTxBuffer()                                  **
*******************************************************************************/
/*******************************************************************************
**                     Eth_39_DriverA_SetControllerMode()                     **
*******************************************************************************/
extern Std_ReturnType Eth_39_DriverA_SetControllerMode( uint8 CtrlIdx, 
                                                        Eth_ModeType CtrlMode );

/*******************************************************************************
**                     TestEth_39_DriverA_SetControllerMode()                 **
*******************************************************************************/
extern boolean TestEth_39_DriverA_SetControllerMode
(App_DataValidateType LddDataValidate,uint8 LucExpController, 
                                                       Eth_ModeType LddExpMode);

/*******************************************************************************
**             END OF Eth_SetControllerMode()                                 **
*******************************************************************************/
/*******************************************************************************
**                  Eth_39_DriverA_Transmit()                                 **
*******************************************************************************/

extern Std_ReturnType Eth_39_DriverA_Transmit(
    uint8 CtrlIdx,
    uint8 BufIdx,
    Eth_FrameType FrameType,
    boolean TxConfirmation,
    uint16 LenByte,
    uint8 *PhysAddrPtr
);
/******************************************************************************/

extern boolean TestEth_39_DriverA_Transmit(App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,uint8 LucExpBufIdx,Eth_FrameType LddExpFrameType,
  boolean LucExpTxConfirmation,uint16  LucExpLenByte,uint8* LucExpPhysAddrPtr);
/*******************************************************************************
**                  Eth_39_DriverA_Transmit()                                 **
*******************************************************************************/
extern void Eth_39_DriverA_GetPhysAddr(uint8 CtrlIdx, uint8* PhysAddrPtr);

/*******************************************************************************/

extern boolean  TestEth_39_DriverA_GetPhysAddr(App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,uint8* LucExpPhysAddrPtr);
  
  
extern void Eth_39_DriverA_Receive(
    uint8 CtrlIdx,
    Eth_RxStatusType* RxStatusPtr
);

extern void Eth_39_DriverA_TxConfirmation(
    uint8 CtrlIdx
);


#endif
/*******************************************************************************
**             END OF  EthIf_Transmit()                                       **
*******************************************************************************/

