/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Eth.c                                                         **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR ETH Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Eth stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     22-Jun-2011   BJV    Initial version                             **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "EthTrcv.h"    


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 EthTrcv_GucGetLinkTrcvIdx[5];
EthTrcv_LinkStateType EthTrcv_GddGetLinkPtr[5];
uint8 EthTrcv_GucGetLinkCount;
uint8 Eth_GucGetLinkCheckCount;
Std_ReturnType EthTrcv_GdTGetLinkRetVal;

Std_ReturnType EthTrcv_GetLinkState(
    uint8 TrcvIdx,
    EthTrcv_LinkStateType* LinkStatePtr
)
{
  /* Load actual Controller and Transition into Global variables */
  EthTrcv_GucGetLinkTrcvIdx[EthTrcv_GucGetLinkCount] = TrcvIdx;
  *LinkStatePtr = ETHTRCV_LINK_STATE_ACTIVE ;
  EthTrcv_GddGetLinkPtr[EthTrcv_GucGetLinkCount] = *LinkStatePtr;
  EthTrcv_GucGetLinkCount++;

  return(EthTrcv_GdTGetLinkRetVal);
} /* End EthTrcv_GetLinkState ()  */


boolean TestEthTrcv_GetLinkState(App_DataValidateType LddDataValidate,
  uint8* LucExpTrcvIdx,EthTrcv_LinkStateType* LddExpLinkState )
{
  boolean LblStepResult;
  uint8 lucCheck;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  lucCheck = 0x00;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((EthTrcv_GucGetLinkCount > 0x00) &&
        (EthTrcv_GucGetLinkTrcvIdx[0] == *LucExpTrcvIdx) &&
        (EthTrcv_GddGetLinkPtr[0] == *LddExpLinkState))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      EthTrcv_GucGetLinkCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < EthTrcv_GucGetLinkCount; LucIndex++)
      {
        /* Validate Network and CurrentState */
        if((EthTrcv_GucGetLinkTrcvIdx[LucIndex] == *LucExpTrcvIdx)&&
         ((EthTrcv_GddGetLinkPtr[LucIndex] == *LddExpLinkState)) &&(0x00 == lucCheck))
        {
          LblStepResult = STEP_PASSED;          
        }
         else
        {
          lucCheck = 0x01;
        }
        LucExpTrcvIdx++;
        LddExpLinkState++;
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Eth_GucGetLinkCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(EthTrcv_GucGetLinkCount == Eth_GucGetLinkCheckCount)
      {
        Eth_GucGetLinkCheckCount = 0;
        EthTrcv_GucGetLinkCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(EthTrcv_GucGetLinkCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      EthTrcv_GucGetLinkCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 EthTrcv_GucGetTrcvIdx;
EthTrcv_ModeType EthTrcv_GddMode;
uint8 EthTrcv_GucTrasRceModeCount;
Std_ReturnType EthTrcv_GdTrasRceModeRetVal;

/*******************************************************************************
**                        EthTrcv_GetTransceiverMode ()                       **
*******************************************************************************/

Std_ReturnType EthTrcv_GetTransceiverMode( uint8 TrcvIdx,EthTrcv_ModeType* TrcvModePtr)
{
  /* Load actual Controller and Transition into Global variables */
  
  EthTrcv_GucGetTrcvIdx = TrcvIdx;
  *TrcvModePtr = ETHTRCV_MODE_ACTIVE ;
  EthTrcv_GddMode = *TrcvModePtr;
  EthTrcv_GucTrasRceModeCount++;

  return(EthTrcv_GdTrasRceModeRetVal);
} /* End EthTrcv_GetTransceiverMode ()  */
/*******************************************************************************/

boolean TestEthTrcv_GetTransceiverMode(App_DataValidateType LddDataValidate,
  uint8 LucExpTrcvIdx,EthTrcv_ModeType* LddExpMode )
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((EthTrcv_GucTrasRceModeCount > 0x00) &&
        (EthTrcv_GucGetTrcvIdx == LucExpTrcvIdx) &&
        (EthTrcv_GddMode == *LddExpMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      EthTrcv_GucTrasRceModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(EthTrcv_GucTrasRceModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      EthTrcv_GucTrasRceModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 EthTrcv_GucSetTrcvIdx;
EthTrcv_ModeType EthTrcv_GddSetMode;


/*******************************************************************************
**                  	EthIf_SetTransceiverMode ()                              **
*******************************************************************************/

Std_ReturnType EthTrcv_SetTransceiverMode(uint8 TrcvIdx,EthTrcv_ModeType TrcvMode)
{
  /* Load actual Controller and Transition into Global variables */
  EthTrcv_GucSetTrcvIdx = TrcvIdx;
  EthTrcv_GddSetMode = TrcvMode;
  EthTrcv_GucTrasRceModeCount++;

  return(EthTrcv_GdTrasRceModeRetVal);
} /* End EthIf_SetTransceiverMode () () */
/*******************************************************************************/

boolean TestEthTrcv_SetTransceiverMode(App_DataValidateType LddDataValidate,
  uint8 LucExpTrcvIdx,EthTrcv_ModeType LddExpMode )
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((EthTrcv_GucTrasRceModeCount > 0x00) &&
        (EthTrcv_GucSetTrcvIdx == LucExpTrcvIdx) &&
        (EthTrcv_GddSetMode == LddExpMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      EthTrcv_GucTrasRceModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(EthTrcv_GucTrasRceModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      EthTrcv_GucTrasRceModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}
/*******************************************************************************
**             END OF  EthIf_SetTransceiverMode ()                            **
*******************************************************************************/
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 EthTrcv_GucTrcvIdx;
uint8 EthTrcv_GucCfgIdx;
uint8 EthTrcv_GucTransceiverInitCount;
Std_ReturnType EthTrcv_GdTransceiverInitRetVal;



/*******************************************************************************
**                  	EthIf_TransceiverInit ()                              **
*******************************************************************************/

Std_ReturnType EthTrcv_TransceiverInit( uint8 TrcvIdx,uint8 CfgIdx)

{
  /* Load actual Controller and Transition into Global variables */
  EthTrcv_GucTrcvIdx = TrcvIdx;
  EthTrcv_GucCfgIdx = CfgIdx;
  EthTrcv_GucTransceiverInitCount++;

  return(EthTrcv_GdTransceiverInitRetVal);
} /* End EthIf_TransceiverInit() */
/*******************************************************************************/

boolean TestEthTrcv_TransceiverInit(App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,uint8 LucExpCfgIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((EthTrcv_GucTransceiverInitCount > 0x00) &&
        (EthTrcv_GucTrcvIdx == LucExpCtrlIdx) &&
        (EthTrcv_GucCfgIdx == LucExpCfgIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      EthTrcv_GucTransceiverInitCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(EthTrcv_GucTransceiverInitCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      EthTrcv_GucTransceiverInitCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}
/*******************************************************************************
**             END OF  EthIf_TransceiverInit ()                            **
*******************************************************************************/

