/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: EthTrcv_GeneralTypes.h                                        **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR ETH Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Eth stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     10-Aug-2012   BCC    Initial version                             **
*******************************************************************************/
/*******************************************************************************
**                      Global Data Types (ECU independent)                   **
*******************************************************************************/
#ifndef ETHTRCVGENERAL_TYPES_H
#define ETHTRCVGENERAL_TYPES_H

typedef enum
{
  ETHTRCV_STATE_UNINIT,
  ETHTRCV_STATE_INIT,
  ETHTRCV_STATE_ACTIVE
} EthTrcv_StateType;

typedef enum
{
  ETHTRCV_MODE_DOWN,
  ETHTRCV_MODE_ACTIVE
} EthTrcv_ModeType;

typedef enum
{
  ETHTRCV_LINK_STATE_DOWN,
  ETHTRCV_LINK_STATE_ACTIVE
} EthTrcv_LinkStateType;

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#endif /* ETHTRCVGENERAL_TYPES_H */


