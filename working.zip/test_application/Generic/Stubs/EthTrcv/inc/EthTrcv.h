/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Eth.c                                                         **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR ETH Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Eth stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     22-Jun-2011   BJV    Initial version                             **
*******************************************************************************/
#ifndef ETHTRCV_H
#define ETHTRCV_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h" 
#include "TC_Generic.h"
#include "EthTrcv_GeneralTypes.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR specification version information */
#define ETHTRCV_AR_RELEASE_MAJOR_VERSION     4
#define ETHTRCV_AR_RELEASE_MINOR_VERSION     0
#define ETHTRCV_AR_RELEASE_REVISION_VERSION  3

/* Software version information */
#define ETH_SW_MAJOR_VERSION  1
#define ETH_SW_MINOR_VERSION  0
#define ETH_SW_PATCH_VERSION  0
/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/
/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
extern Std_ReturnType EthTrcv_GetTransceiverMode( uint8 TrcvIdx,EthTrcv_ModeType* TrcvModePtr);
extern boolean TestEthTrcv_GetTransceiverMode(App_DataValidateType LddDataValidate,
  uint8 LucExpTrcvIdx,EthTrcv_ModeType* LddExpMode );

extern Std_ReturnType EthTrcv_SetTransceiverMode(uint8 TrcvIdx,EthTrcv_ModeType TrcvMode);

extern boolean TestEthTrcv_SetTransceiverMode(App_DataValidateType LddDataValidate,
  uint8 LucExpTrcvIdx,EthTrcv_ModeType LddExpMode );


extern Std_ReturnType EthTrcv_TransceiverInit( uint8 TrcvIdx,uint8 CfgIdx);
extern boolean TestEthTrcv_TransceiverInit(App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,uint8 LucExpCfgIdx);
  
extern Std_ReturnType EthTrcv_GetLinkState(
    uint8 TrcvIdx,
    EthTrcv_LinkStateType* LinkStatePtr
);

extern boolean TestEthTrcv_GetLinkState(App_DataValidateType LddDataValidate,
  uint8* LucExpTrcvIdx,EthTrcv_LinkStateType* LddExpLinkState );
#endif

