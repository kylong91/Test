/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Ea.c                                                          **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Ea Module                                             **
**                                                                            **
**  PURPOSE   : Provision of Ea.c for testing applications                    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Ea.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Ea_GucCancelCount;
uint8 Ea_GucEraseImmediateBlkCount;
uint16 Ea_GusBlockNumber;
Std_ReturnType Ea_GddEarImmdiBlkRetVal;
uint8 Ea_GucGetJobResultCount;
uint8 Ea_GucGetStatusCount;
uint8 Ea_TestBlockLength = 10;
uint8 Ea_GaaDataBuffer[10];
uint8 Ea_GucInvalidateBlockCount;
Std_ReturnType Ea_GddInvBlockRetVal;
uint8 Ea_GucReadCount;
Std_ReturnType Ea_GddReadRetVal;
uint16 Ea_GusBlockOffset;
uint8 Ea_GucDataBufferPtr;
uint16 Ea_GusLength;
uint8 Ea_GucSetModeCount;
MemIf_ModeType Ea_GddMode;
MemIf_JobResultType Ea_GddJobResult;
MemIf_StatusType Ea_GddStatus;
uint8 Ea_GucWriteCount;
Std_ReturnType Ea_GddWriteRetVal;

/*******************************************************************************
**                         Ea_Cancel                                          **
*******************************************************************************/
void Ea_Cancel(void)
{
  Ea_GucCancelCount++;
}
/*******************************************************************************
**                         TestEa_Cancel()                                    **
*******************************************************************************/
boolean TestEa_Cancel(App_DataValidateType LucDataValidate)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if(Ea_GucCancelCount == 0x01)
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Ea_GucCancelCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Ea_GucCancelCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEa_Cancel() */
/******************************************************************************/
/*                       Ea_EraseImmediateBlock()                             */
/******************************************************************************/
Std_ReturnType Ea_EraseImmediateBlock(uint16 BlockNumber)
{
  Ea_GusBlockNumber = BlockNumber;
  Ea_GucEraseImmediateBlkCount++;
  return(Ea_GddEarImmdiBlkRetVal);
}
/*******************************************************************************
**                       TestEa_EraseImmediateBlock()                          **
*******************************************************************************/
boolean TestEa_EraseImmediateBlock(App_DataValidateType LucDataValidate,
  uint16 LddExpBlockNumber)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((Ea_GucEraseImmediateBlkCount == 0x01)&&
        (LddExpBlockNumber == Ea_GusBlockNumber))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Ea_GucEraseImmediateBlkCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Ea_GucEraseImmediateBlkCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEa_EraseImmediateBlock() */
/*******************************************************************************
**                     TestEa_EraseImmediateBlockSetRetVal()                  **
*******************************************************************************/
void TestEa_EraseImmediateBlockSetRetVal(Std_ReturnType ReturnValue)
{
  Ea_GddEarImmdiBlkRetVal = ReturnValue;
} /* End TestEa_EraseImmediateBlockSetRetVal() */
/******************************************************************************/
/*                          Ea_GetJobResult()                                 */
/******************************************************************************/
MemIf_JobResultType Ea_GetJobResult(void)
{
  Ea_GucGetJobResultCount++;
  return(Ea_GddJobResult);
} /* End Ea_GetJobResult() */
/*******************************************************************************
**                           TestEa_GetJobResult()                            **
*******************************************************************************/
boolean TestEa_GetJobResult(App_DataValidateType LucDataValidate)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if(Ea_GucGetJobResultCount == 0x01)
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Ea_GucGetJobResultCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Ea_GucGetJobResultCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEa_GetJobResult() */
/******************************************************************************/
/*                           Ea_GetStatus()                                   */
/******************************************************************************/
MemIf_StatusType Ea_GetStatus(void)
{
  Ea_GucGetStatusCount++;
  return(Ea_GddStatus);
} /* End Ea_GetStatus() */
/*******************************************************************************
**                       TestEa_GetStatus()                                   **
*******************************************************************************/
boolean TestEa_GetStatus(App_DataValidateType LucDataValidate)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Ea_GucGetStatusCount == 0x01)
       {
         LblStepResult = STEP_PASSED;
       }
      /* Reset API invocation Count after validating the API invocation */
      Ea_GucGetStatusCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Ea_GucGetStatusCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEa_GetStatus() */
/******************************************************************************/
/*                           Ea_InvalidateBlock()                             */
/******************************************************************************/
Std_ReturnType Ea_InvalidateBlock(uint16 BlockNumber)
{
  Ea_GusBlockNumber = BlockNumber;
  Ea_GucInvalidateBlockCount++;
  return(Ea_GddInvBlockRetVal);
} /* End Ea_InvalidateBlock() */
/*******************************************************************************
**                          TestEa_InvalidateBlock()                          **
*******************************************************************************/
boolean TestEa_InvalidateBlock(App_DataValidateType LucDataValidate,
  uint16 LddExpBlockNumber)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Ea_GucInvalidateBlockCount == 0x01)&&
        (LddExpBlockNumber == Ea_GusBlockNumber))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Ea_GucInvalidateBlockCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Ea_GucInvalidateBlockCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEa_InvalidateBlock() */
/*******************************************************************************
**                       TestEa_InvalidateBlockSetRetVal()                    **
*******************************************************************************/
void TestEa_InvalidateBlockSetRetVal(Std_ReturnType ReturnValue)
{
  Ea_GddInvBlockRetVal = ReturnValue;
} /* End TestEa_InvalidateBlockSetRetVal() */
/******************************************************************************/
/*                       Ea_Read()                                            */
/******************************************************************************/
Std_ReturnType Ea_Read(uint16 BlockNumber, uint16 BlockOffset,
  uint8* DataBufferPtr, uint16 Length)
{
  uint8 LucCount;
  Ea_GusBlockNumber = BlockNumber;
  Ea_GusBlockOffset = BlockOffset;
  for(LucCount = 0; LucCount < Length; LucCount++)
  {
    Ea_GaaDataBuffer[LucCount]= *DataBufferPtr;
  }
  Ea_GusLength = Length;
  Ea_GucReadCount++;
  return(Ea_GddReadRetVal);
} /* End Ea_Read() */
/*******************************************************************************
**                              TestEa_Read()                                 **
*******************************************************************************/
boolean TestEa_Read(App_DataValidateType LucDataValidate,
uint16 LddExpBlockNumber, uint16 LddExpBlockOffset,
uint8 *LddExpDataBufferPtr, uint16 LddExpLength)
{
  boolean  LblStepResult;
  uint8 LucCount;
  LucCount = 0;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Ea_GucReadCount == 0x01)&&
        (LddExpBlockNumber == Ea_GusBlockNumber)&&
        (LddExpBlockOffset == Ea_GusBlockOffset)&&
        (LddExpLength == Ea_GusLength))
        {
          while(LucCount != Ea_GusLength)
          {
            if(*LddExpDataBufferPtr != Ea_GaaDataBuffer[LucCount])
            {
              break;
            }
            LucCount++;
          }
          if(LucCount == Ea_GusLength)
          {
            LblStepResult = STEP_PASSED;
          }
        }
      /* Reset API invocation Count after validating the API invocation */
      Ea_GucReadCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Ea_GucReadCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEa_Read() */
/*******************************************************************************
**                       TestEa_ReadSetRetVal()                               **
*******************************************************************************/
void TestSetEa_ReadRetVal(Std_ReturnType ReturnValue)
{
  Ea_GddReadRetVal = ReturnValue;
} /* End TestEa_ReadSetRetVal() */
/******************************************************************************/
/*                              Ea_SetMode()                                  */
/******************************************************************************/
void Ea_SetMode(MemIf_ModeType Mode)
{
  Ea_GddMode = Mode;
  Ea_GucSetModeCount++;
} /* End Ea_SetMode() */
/*******************************************************************************
**                                  TestEa_SetMode()                          **
*******************************************************************************/
boolean TestEa_SetMode(App_DataValidateType LucDataValidate,
  MemIf_ModeType LddExpMode)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Ea_GucSetModeCount == 0x01)&&
        (LddExpMode == Ea_GddMode))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Ea_GucSetModeCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Ea_GucReadCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEa_SetMode() */
/******************************************************************************/
/*                                 Ea_Write()                                 */
/******************************************************************************/
Std_ReturnType Ea_Write(uint16 BlockNumber, uint8* DataBufferPtr)
{
  uint8 LucCount;
  Ea_GusBlockNumber = BlockNumber;
  Ea_GucDataBufferPtr = *DataBufferPtr;
  for(LucCount = 0; LucCount < Ea_TestBlockLength; LucCount++)
  {
    Ea_GaaDataBuffer[LucCount]= *DataBufferPtr;
  }
  Ea_GucWriteCount++;
  return(Ea_GddWriteRetVal);
}  /* End Ea_Write() */
/*******************************************************************************
**                             TestEa_Write()                                 **
*******************************************************************************/
boolean TestEa_Write(App_DataValidateType LucDataValidate,
  uint16 LddExpBlockNumber, uint8 *LddExpDataBufferPtr)
{
  boolean  LblStepResult;
  uint8 LucCount;
  LblStepResult = STEP_FAILED;
  LucCount = 0;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Ea_GucWriteCount == 0x01)&&
        (LddExpBlockNumber == Ea_GusBlockNumber))
        {
          while(LucCount != Ea_TestBlockLength)
          {
            if(*LddExpDataBufferPtr != Ea_GaaDataBuffer[LucCount])
            {
              break;
            }
            LucCount++;
          }
          if(LucCount == Ea_GusLength)
          {
            LblStepResult = STEP_PASSED;
          }
        }
      /* Reset API invocation Count after validating the API invocation */
      Ea_GucWriteCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Ea_GucWriteCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEa_Write() */
/*******************************************************************************
**                       TestSetEa_WriteRetVal()                              **
*******************************************************************************/
void TestSetEa_WriteRetVal(Std_ReturnType ReturnValue)
{
  Ea_GddWriteRetVal = ReturnValue;
} /* End TestSetEa_WriteRetVal() */
/*******************************************************************************
**                       TestSetEa_GetJobResultRetVal()                       **
*******************************************************************************/
void TestSetEa_GetJobResultRetVal(MemIf_JobResultType JobResult)
{
  Ea_GddJobResult = JobResult;
}/* End TestSetEa_GetJobResultRetVal */
/*******************************************************************************
**                       TestSetEa_GetStatusRetVal()                          **
*******************************************************************************/
void TestSetEa_GetStatusRetVal(MemIf_StatusType Status)
{
  Ea_GddStatus = Status;
} /* End TestSetEa_GetStatusRetVal */
/*******************************************************************************
**                       TestEa_DefaultBehavior()                             **
*******************************************************************************/
void TestEa_DefaultBehavior(void)
{
  Ea_GucCancelCount = 0;
  Ea_GucEraseImmediateBlkCount = 0;
  Ea_GucGetJobResultCount = 0;
  Ea_GucGetStatusCount = 0;
  Ea_GucInvalidateBlockCount = 0;
  Ea_GucReadCount = 0;
  Ea_GucSetModeCount = 0;
  Ea_GucWriteCount = 0;
  Ea_GddEarImmdiBlkRetVal = E_OK;
  Ea_GddInvBlockRetVal = E_OK;
  Ea_GddReadRetVal = E_OK;
  Ea_GddWriteRetVal = E_OK;
  Ea_GddMode = MEMIF_MODE_SLOW;
  Ea_GddJobResult = MEMIF_JOB_OK;
  Ea_GddStatus = MEMIF_IDLE;
} /* End TestEa_DefaultBehavior() */
/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
