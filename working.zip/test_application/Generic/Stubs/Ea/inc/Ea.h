/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Ea.h                                                          **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Ea Module                                             **
**                                                                            **
**  PURPOSE   : Provision of header for Ea.c                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef EA_H
#define EA_H

/*******************************************************************************
* I N C L U D E S
*******************************************************************************/
#include "Std_Types.h"
#include "MemIf_Types.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define EA_AR_RELEASE_MAJOR_VERSION  4
#define EA_AR_RELEASE_MINOR_VERSION  0
#define EA_AR_RELEASE_REVISION_VERSION  3

/*******************************************************************************
**                      Function Prototype                                    **
*******************************************************************************/
extern void Ea_Cancel(void);
extern  boolean TestEa_Cancel(App_DataValidateType LucDataValidate);

extern Std_ReturnType Ea_EraseImmediateBlock(uint16 BlockNumber);
extern  boolean TestEa_EraseImmediateBlock(App_DataValidateType LucDataValidate,
  uint16 LddExpBlockNumber);
extern void TestEa_EraseImmediateBlockSetRetVal(Std_ReturnType ReturnValue);

extern MemIf_JobResultType Ea_GetJobResult(void);
extern boolean TestEa_GetJobResult(App_DataValidateType LucDataValidate);
extern void TestSetEa_GetJobResultRetVal(MemIf_JobResultType JobResult);

extern MemIf_StatusType Ea_GetStatus(void);
extern boolean TestEa_GetStatus(App_DataValidateType LucDataValidate);
extern void TestSetEa_GetStatusRetVal(MemIf_StatusType StatusType);

extern Std_ReturnType Ea_InvalidateBlock(uint16 BlockNumber);
extern  boolean TestEa_InvalidateBlock (App_DataValidateType
  LucDataValidate, uint16 LddExpBlockNumber);
extern void TestEa_InvalidateBlockSetRetVal(Std_ReturnType ReturnValue);

extern Std_ReturnType Ea_Read(uint16 BlockNumber, uint16 BlockOffset,
  uint8* DataBufferPtr, uint16 Length);
extern  boolean TestEa_Read(App_DataValidateType
  LucDataValidate, uint16 LddExpBlockNumber, uint16 LddExpBlockOffset,
  uint8 *LddExpDataBufferPtr, uint16 LddExpLength);
extern void TestEa_ReadSetRetVal(Std_ReturnType ReturnValue);

extern void Ea_SetMode(MemIf_ModeType Mode);
extern  boolean TestEa_SetMode(App_DataValidateType LucDataValidate,
  MemIf_ModeType LddExpMode);

extern Std_ReturnType Ea_Write(uint16 BlockNumber, uint8* DataBufferPtr);
extern  boolean TestEa_Write(App_DataValidateType LucDataValidate,
  uint16 LddExpBlockNumber, uint8 *LddExpDataBufferPtr);
extern void TestEa_WriteSetRetVal(Std_ReturnType ReturnValue);

extern void TestEa_DefaultBehavior(void);
#endif /* EA_H */
/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
