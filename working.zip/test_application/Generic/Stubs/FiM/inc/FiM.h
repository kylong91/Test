/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: FiM.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FiM Stub                                              **
**                                                                            **
**  PURPOSE   : Declaration of FiM Stub functions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     05-Apr-2012   RPS    Initial version                             **
*******************************************************************************/

#ifndef FIM_H
#define FIM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define FIM_AR_RELEASE_MAJOR_VERSION  4
#define FIM_AR_RELEASE_MINOR_VERSION  0
#define FIM_AR_RELEASE_REVISION_VERSION  2
/* Software Version Information */
#define FIM_SW_MAJOR_VERSION  4
#define FIM_SW_MINOR_VERSION  0

/******************************************************************************
*                       Macros
******************************************************************************/

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#ifdef DEM_MODULE_ACTIVE
extern void FiM_DemTriggerOnEventStatus(Dem_EventIdType EventId, 
uint8 EventStatusOld, uint8 EventStatusNew);

extern boolean TestFiM_DemTriggerOnEventStatus(App_DataValidateType 
LucDataValidate, Dem_EventIdType ExpEventId, uint8 ExpEventStatusOld,
uint8 ExpEventStatusNew);
#endif

#endif /* FIM_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
