/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: FiM.c                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FiM Module                                            **
**                                                                            **
**  PURPOSE   : Declaration of FiM functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     05-Apr-2012   RPS    Initial version                             **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#ifdef DEM_MODULE_ACTIVE
#include "Dem.h"
#include "FiM.h"
#endif
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/

#ifdef DEM_MODULE_ACTIVE
Dem_EventIdType Dem_GddFiMEventId;
uint8 Dem_GucFiMEventStatusOld;
uint8 Dem_GucFiMEventStatusNew;
uint8 Dem_GucFiMTriggerCounter;
#endif
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

#ifdef DEM_MODULE_ACTIVE

/*******************************************************************************
**                       FiM_DemTriggerOnEventStatus()                        **
*******************************************************************************/
void FiM_DemTriggerOnEventStatus(Dem_EventIdType EventId, 
uint8 EventStatusOld, uint8 EventStatusNew)
{
  #ifndef TYPICAL_CONFIG
  Dem_GddFiMEventId = EventId;
  Dem_GucFiMEventStatusOld = EventStatusOld;
  Dem_GucFiMEventStatusNew = EventStatusNew;
  #endif
  Dem_GucFiMTriggerCounter++;

}/* End FiM_DemTriggerOnEventStatus() */
/*******************************************************************************
**                        TestFiM_DemTriggerOnEventStatus()                   **
*******************************************************************************/
boolean TestFiM_DemTriggerOnEventStatus(App_DataValidateType LucDataValidate,
Dem_EventIdType ExpEventId, uint8 ExpEventStatusOld, uint8 ExpEventStatusNew)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {     
      if((Dem_GucFiMTriggerCounter == 0x01) && (Dem_GddFiMEventId == ExpEventId) 
        && (Dem_GucFiMEventStatusOld == ExpEventStatusOld) 
        && (Dem_GucFiMEventStatusNew == ExpEventStatusNew)) 
      {
        LblStepResult = APP_TC_PASSED;
      }
      Dem_GucFiMTriggerCounter = 0;
      break;
    }
            
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Dem_GucFiMTriggerCounter == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
     
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFiM_DemTriggerOnEventStatus() */
#endif

/*******************************************************************************
**                         TestFiM_DefaultBehavior()                          **
*******************************************************************************/
void TestFiM_DefaultBehavior(void)
{
  Dem_GucFiMTriggerCounter = 0;
}

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
