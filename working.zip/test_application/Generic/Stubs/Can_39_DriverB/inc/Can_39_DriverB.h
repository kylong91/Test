/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Can_39_DriverB.h                                              **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Can_39_DriverB Interface module                       **
**                                                                            **
**  PURPOSE   : Declaration of Can_39_DriverB functions                       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     10/06/2011    BJV    Creation of Can_39_DriverB.h module         **
** 4.0.1     20-Dec-2011   RPS    General inclusions are updated              **
*******************************************************************************/
#ifndef CAN_39_DRIVERB
#define CAN_39_DRIVERB

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"
#include "Can_GeneralTypes.h"
#include "Can_GenericTypes.h"
#include "TC_Generic.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define CAN_39_DRIVERB_AR_RELEASE_MAJOR_VERSION    0x04
#define CAN_39_DRIVERB_AR_RELEASE_MINOR_VERSION    0x00

#define CAN_DRVB_ARRAY_SIZE 0x08
#define CAN_DRVB_DATA_LENGTH 0x08

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Can_ReturnType Can_39_DriverB_SetControllerMode(uint8 Controller,
  Can_StateTransitionType Transition);

extern Can_ReturnType Can_39_DriverB_Write(Can_HwHandleType LddHth,
  const Can_PduType *LstPduInfo);

extern Can_ReturnType Can_39_DriverB_CheckWakeup(uint8 Controller);

extern boolean TestCan_39_DriverB_SetControllerMode(
  App_DataValidateType LddDataValidate, uint8 LucExpController,
  Can_StateTransitionType LddExpTransition);

extern boolean TestCan_39_DriverB_Write(App_DataValidateType LddDataValidate,
  Can_HwHandleType ExpHth, const Can_PduType *ExpPduInfo);

extern boolean TestCan_39_DriverB_CheckWakeup(App_DataValidateType LddDataValidate,
  uint8 LucExpController);

extern void TestCan_39_DriverB_SetCtrlRetVal(Can_ReturnType LddCanReturnVal);

extern void TestCan_39_DriverB_SetCheckWakeupRetVal(Can_ReturnType
  LddCanReturnVal);

extern void TestCan_39_DriverB_SetWriteRetVal(Can_ReturnType LddCanReturnVal);

extern void TestCan_39_DriverB_DefaultBehavior(void);

extern boolean Can_39_DriverB_Test_ValidateData(uint8* LpExpSdu,
  uint8* LpActSdu);
  
extern Std_ReturnType Can_39_DriverB_ChangeBaudrate (uint8 ControllerId,
                                            CONST(uint16, CANIF_CONST) Baudrate);

extern boolean TestCan_39_DriverB_ChangeBaudrate (App_DataValidateType LddDataValidate, uint8 ControllerId,
                                            CONST(uint16, CANIF_CONST) Baudrate);    

extern Std_ReturnType Can_39_DriverB_CheckBaudrate (uint8 ControllerId,
                                            CONST(uint16, CANIF_CONST) Baudrate);

extern boolean TestCan_39_DriverB_CheckBaudrate (App_DataValidateType LddDataValidate, uint8 ControllerId,
                                            CONST(uint16, CANIF_CONST) Baudrate);                                              

#endif /* CAN_39_DRIVERB */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
