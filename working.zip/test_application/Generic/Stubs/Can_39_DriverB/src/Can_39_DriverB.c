/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Can_39_DriverB.c                                              **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Can_39_DriverB Stub                                   **
**                                                                            **
**  PURPOSE   : This application file contains the Can_39_DriverB stub        **
**              functions                                                     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     22-Jun-2011   BJV    Initial version                             **
**                                                                            **
** 4.0.1     20-Sep-2011   BPT    Updated for CanIf                           **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include"Can_39_DriverB.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Can_GucCheckControllerId;
uint16 Can_GddBaudRate;
uint8 Can_GucCheckBaudRateCount;

uint8 Can_GucDrvBSetCtrlModeCount;
uint8 Can_GucDrvBSetController;
Can_StateTransitionType Can_GddDrvBTransition;

uint8 Can_GucDrvBCheckWakeupCount;
uint8 Can_GucDrvBWakupController;
uint8 Can_GucDrvBCheckWakeupCheckCount;

uint8 Can_GucDrvBWriteCount;
Can_HwHandleType Can_GddDrvBHth;
PduIdType Can_GddDrvBWriteswPduhandle;
Can_IdType Can_GucDrvBWriteCanId;
uint8 Can_GucDrvBWriteLength;
uint8 Can_GaaDrvBWriteSdu[CAN_DRVB_DATA_LENGTH];

Can_ReturnType Can_GddDrvBSetCtrlRetVal;
Can_ReturnType Can_GddDrvBCheckWakeupRetVal;
Can_ReturnType Can_GddDrvBWriteRetVal;

/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/


/*******************************************************************************
**                           Can_39_DriverB_CheckBaudrate()                   **
*******************************************************************************/
Std_ReturnType Can_39_DriverB_ChangeBaudrate (uint8 ControllerId,
                                            CONST(uint16, CANIF_CONST) Baudrate)
{
  Can_GucCheckControllerId = ControllerId;
  Can_GddBaudRate = Baudrate;
  Can_GucCheckBaudRateCount++;

  return(E_OK);
}  /* End Can_39_DriverA_CheckWakeup() */

/*******************************************************************************
**                        TestCan_39_DriverB_CheckBaudrate()                  **
*******************************************************************************/
boolean TestCan_39_DriverB_ChangeBaudrate (App_DataValidateType LddDataValidate, uint8 ControllerId,
                                            CONST(uint16, CANIF_CONST) Baudrate)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  UNUSED(Baudrate);

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller  */
      if((Can_GucCheckBaudRateCount == 0x01) &&
        (ControllerId == Can_GucCheckControllerId))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Can_GucCheckBaudRateCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Can_GucCheckBaudRateCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Can_GucCheckBaudRateCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCan_39_DriverB_ChangeBaudrate() */



/*******************************************************************************
**                           Can_39_DriverB_CheckBaudrate()                       **
*******************************************************************************/
Std_ReturnType Can_39_DriverB_CheckBaudrate (uint8 ControllerId,
                                            CONST(uint16, CANIF_CONST) Baudrate)
{
  Can_GucCheckControllerId = ControllerId;
  Can_GddBaudRate = Baudrate;
  Can_GucCheckBaudRateCount++;

  return(E_OK);
}  /* End Can_39_DriverA_CheckWakeup() */

/*******************************************************************************
**                        TestCan_39_DriverB_CheckBaudrate()                      **
*******************************************************************************/
boolean TestCan_39_DriverB_CheckBaudrate (App_DataValidateType LddDataValidate, uint8 ControllerId,
                                            CONST(uint16, CANIF_CONST) Baudrate)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  UNUSED(Baudrate);

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller  */
      if((Can_GucCheckBaudRateCount == 0x01) &&
        (ControllerId == Can_GucCheckControllerId))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Can_GucCheckBaudRateCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Can_GucCheckBaudRateCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Can_GucCheckBaudRateCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCan_39_DriverB_CheckBaudRate() */





/*******************************************************************************
**                     Can_39_DriverB_SetControllerMode()                     **
*******************************************************************************/
Can_ReturnType Can_39_DriverB_SetControllerMode(uint8 Controller,
  Can_StateTransitionType Transition)
{
  /* Load actual Controller and Transition into Global variables */
  Can_GucDrvBSetController = Controller;
  Can_GddDrvBTransition = Transition;
  Can_GucDrvBSetCtrlModeCount++;

  return(Can_GddDrvBSetCtrlRetVal);
} /* End Can_39_DriverB_SetControllerMode() */

/*******************************************************************************
**                     TestCan_39_DriverB_SetControllerMode()                 **
*******************************************************************************/
boolean TestCan_39_DriverB_SetControllerMode(
  App_DataValidateType LddDataValidate, uint8 LucExpController,
  Can_StateTransitionType LddExpTransition)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Can_GucDrvBSetCtrlModeCount == 0x01) &&
        (Can_GucDrvBSetController == LucExpController) &&
        (Can_GddDrvBTransition == LddExpTransition))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Can_GucDrvBSetCtrlModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Can_GucDrvBSetCtrlModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Can_GucDrvBSetCtrlModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCan_39_DriverB_SetControllerMode() */

/*******************************************************************************
**                           Can_39_DriverB_CheckWakeup()                     **
*******************************************************************************/
Can_ReturnType Can_39_DriverB_CheckWakeup(uint8 Controller)
{
  /* Load actual Controller into Global variables */
  Can_GucDrvBCheckWakeupCount++;
  Can_GucDrvBWakupController = Controller;

  return(Can_GddDrvBCheckWakeupRetVal);
}  /* End Can_39_DriverB_CheckWakeup() */

/*******************************************************************************
**                        TestCan_39_DriverB_CheckWakeup()                    **
*******************************************************************************/
boolean TestCan_39_DriverB_CheckWakeup(App_DataValidateType LddDataValidate,
  uint8 LucExpController)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller  */
      if((Can_GucDrvBCheckWakeupCount == 0x01) &&
        (Can_GucDrvBWakupController == LucExpController))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Can_GucDrvBCheckWakeupCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Can_GucDrvBCheckWakeupCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Can_GucDrvBCheckWakeupCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCan_39_DriverB_CheckWakeup() */

/*******************************************************************************
**                           Can_39_DriverB_Write()                           **
*******************************************************************************/
Can_ReturnType Can_39_DriverB_Write(Can_HwHandleType LddHth,
  const Can_PduType *LstPduInfo)
{
  uint8 LucDataIndex;
  uint8 *LpWriteSdu;

  /* Load actual Hth and SduDataPtr into Global variables */
  Can_GddDrvBHth = LddHth;
  Can_GddDrvBWriteswPduhandle = LstPduInfo->swPduHandle;
  LpWriteSdu = LstPduInfo->sdu;
  Can_GucDrvBWriteCanId = LstPduInfo->id;
  if(LstPduInfo->length > CAN_DRVB_DATA_LENGTH)
  {
    Can_GucDrvBWriteLength = CAN_DRVB_DATA_LENGTH;
  }
  else
  {
    Can_GucDrvBWriteLength = LstPduInfo->length;
  }

  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0; LucDataIndex < Can_GucDrvBWriteLength; LucDataIndex++)
  {
    Can_GaaDrvBWriteSdu[LucDataIndex] = *LpWriteSdu;
    LpWriteSdu++;
  }
  Can_GucDrvBWriteCount++;
  return(Can_GddDrvBWriteRetVal);
} /* End Can_39_DriverB_Write() */

/*******************************************************************************
**                           TestCan_39_DriverB_Write()                       **
*******************************************************************************/
boolean TestCan_39_DriverB_Write(App_DataValidateType LddDataValidate,
  Can_HwHandleType ExpHth, const Can_PduType *ExpPduInfo)
{
  boolean LblRetValue;
  uint8 *LpSduPtr;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and HTH */
      if((Can_GucDrvBWriteCount == 0x01) && (Can_GddDrvBHth == ExpHth) &&
        (ExpPduInfo->length == Can_GucDrvBWriteLength) &&
        (ExpPduInfo->id == Can_GucDrvBWriteCanId) &&
        (ExpPduInfo->swPduHandle == Can_GddDrvBWriteswPduhandle))
      {
        LpSduPtr = ExpPduInfo->sdu;
        /* Validate SduLength and Data */
        if(Can_39_DriverB_Test_ValidateData(LpSduPtr, &Can_GaaDrvBWriteSdu[0]))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      Can_GucDrvBWriteCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Can_GucDrvBWriteCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      Can_GucDrvBWriteCount = 0;
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCan_39_DriverB_Write() */

/*******************************************************************************
**                       Can_39_DriverB_Test_ValidateData()                   **
*******************************************************************************/
boolean Can_39_DriverB_Test_ValidateData(uint8* LpExpSdu, uint8* LpActSdu)
{
  uint8 LddSduCount;
  uint8 *LpExpSduData;
  uint8 *LpActSduData;
  boolean LblReturnValue;

  LpExpSduData = LpExpSdu;
  LpActSduData = LpActSdu;
  LblReturnValue = TRUE;
  LddSduCount = Can_GucDrvBWriteLength;

  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    LddSduCount--;
    if(*LpActSduData != *LpExpSduData)
    {
      LblReturnValue = FALSE;
    }
    LpActSduData++;
    LpExpSduData++;

  }
  return(LblReturnValue);
} /* End Can_39_DriverB_Test_ValidateData()  */

/*******************************************************************************
**                    TestCan_39_DriverB_SetCtrlRetVal()                      **
*******************************************************************************/
void TestCan_39_DriverB_SetCtrlRetVal(Can_ReturnType LddCanReturnVal)
{
  Can_GddDrvBSetCtrlRetVal = LddCanReturnVal;
}
/* End TestCan_39_DriverB_SetCtrlRetVal() */

/*******************************************************************************
**                  TestCan_39_DriverB_SetCheckWakeupRetVal()                 **
*******************************************************************************/
void TestCan_39_DriverB_SetCheckWakeupRetVal(Can_ReturnType LddCanReturnVal)
{
  Can_GddDrvBCheckWakeupRetVal = LddCanReturnVal;
}
/* End TestCan_39_DriverB_SetCheckWakeupRetVal() */

/*******************************************************************************
**                    TestCan_39_DriverB_SetWriteRetVal()                     **
*******************************************************************************/
void TestCan_39_DriverB_SetWriteRetVal(Can_ReturnType LddCanReturnVal)
{
  Can_GddDrvBWriteRetVal = LddCanReturnVal;
}
/* End TestCan_39_DriverB_SetWriteRetVal() */

/*******************************************************************************
**                     TestCan_39_DriverB_DefaultBehavior()                   **
*******************************************************************************/
void TestCan_39_DriverB_DefaultBehavior(void)
{
 Can_GddDrvBSetCtrlRetVal = CAN_OK;
 Can_GddDrvBCheckWakeupRetVal = CAN_OK;
 Can_GddDrvBWriteRetVal = CAN_OK;
 Can_GddDrvBTransition = CAN_T_STOP;
 Can_GucDrvBSetCtrlModeCount = 0;
 Can_GucDrvBSetController = 0;
 Can_GucDrvBCheckWakeupCount = 0;
 Can_GucDrvBWakupController = 0;
 Can_GucDrvBCheckWakeupCheckCount = 0;
 Can_GucDrvBWriteCount = 0;
 Can_GddDrvBWriteswPduhandle = 0;
 Can_GucDrvBWriteCanId = 0;
 Can_GucDrvBWriteLength = 0;
 Can_GddDrvBHth = 0;
 Can_GucCheckControllerId = 0;
 Can_GddBaudRate = 0; 
 Can_GucCheckBaudRateCount = 0;
} /* End TestCan_39_DriverB_DefaultBehavior() */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

