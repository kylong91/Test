/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Wdg.c                                                         **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Wdg Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Wdg stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By             Description                          **
********************************************************************************
** 1.0.0     24-Dec-2012   Jaison John    Initial version                      **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Wdg.h"
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Wdg_GucSetModeCount;
WdgIf_ModeType Wdg_GddMode;

uint8 Wdg_GucSetTriggerCondCount;
uint16 Wdg_Guctimeout;

Std_ReturnType Wdg_GddSetModeRetVal;
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
**                            Wdg_SetMode()                                   **
*******************************************************************************/
Std_ReturnType Wdg_SetMode(WdgIf_ModeType Mode)
{
  /* Load actual Mode into Global variables */
  Wdg_GddMode = Mode;
  Wdg_GucSetModeCount++;

  return(Wdg_GddSetModeRetVal);
} /* End Wdg_SetMode() */

/*******************************************************************************
**                         TestWdg_SetMode()                                  **
*******************************************************************************/
boolean TestWdg_SetMode(App_DataValidateType LddDataValidate,
  WdgIf_ModeType LddExpMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Wdg_GucSetModeCount == 0x01) &&
        (Wdg_GddMode == LddExpMode)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Wdg_GucSetModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Wdg_GucSetModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Wdg_GucSetModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestWdg_SetMode() */

/*******************************************************************************
**                           Wdg_SetTriggerCondition()                        **
*******************************************************************************/
void Wdg_SetTriggerCondition(uint16 timeout)
{
  /* Load actual timeout into Global variables */
  Wdg_GucSetTriggerCondCount++;
  Wdg_Guctimeout = timeout;
}  /* End Wdg_CheckWakeup() */

/*******************************************************************************
**                        TestWdg_SetTriggerCondition()                       **
*******************************************************************************/
boolean TestWdg_SetTriggerCondition(App_DataValidateType LddDataValidate,
  uint16 LddExptimeout)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and timeout  */
      if((Wdg_GucSetTriggerCondCount == 0x01) &&
        (Wdg_Guctimeout == LddExptimeout))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Wdg_GucSetTriggerCondCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Wdg_GucSetTriggerCondCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Wdg_GucSetTriggerCondCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestWdg_SetTriggerCondition() */
/*******************************************************************************
**                    TestSetWdg_SetModeRetVal()                                 **
*******************************************************************************/
void TestSetWdg_SetModeRetVal(Std_ReturnType LddWdgReturnVal)
{
  Wdg_GddSetModeRetVal = LddWdgReturnVal;
}
/* End TestSetWdg_SetModeRetVal() */
/*******************************************************************************
**                     TestWdg_DefaultBehavior()                              **
*******************************************************************************/
void TestWdg_DefaultBehavior(void)
{
  Wdg_GddSetModeRetVal = E_OK;
  Wdg_GucSetModeCount = 0; 
  Wdg_GucSetTriggerCondCount = 0;
  Wdg_Guctimeout = 0;
} /* End TestWdg_DefaultBehavior() */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

