/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Wdg.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Wdg Interface module                                  **
**                                                                            **
**  PURPOSE   : Declaration of Wdg functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date           By             Description                        **
********************************************************************************
** 1.0.0     24-Dec-2012    Jaison John    Intial version                     **
*******************************************************************************/
#ifndef WDG_H
#define WDG_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "WdgIf_Types.h"
#include "Std_Types.h"
#include "TC_Generic.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define WDG_AR_RELEASE_MAJOR_VERSION    4
#define WDG_AR_RELEASE_MINOR_VERSION    0
#define WDG_AR_RELEASE_REVISION_VERSION 3

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Std_ReturnType Wdg_SetMode(WdgIf_ModeType Mode);

extern boolean TestWdg_SetMode(App_DataValidateType LddDataValidate,
  WdgIf_ModeType LddExpMode);
  
extern void Wdg_SetTriggerCondition(uint16 timeout);

extern boolean TestWdg_SetTriggerCondition(App_DataValidateType LddDataValidate,
  uint16 LddExptimeout);
  
extern void TestSetWdg_SetModeRetVal(Std_ReturnType LddWdgReturnVal);

extern void TestWdg_DefaultBehavior(void);

#endif /* Wdg_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
