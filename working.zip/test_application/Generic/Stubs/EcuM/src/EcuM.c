/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: EcuM.c                                                        **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR EcuM Stub                                             **
**                                                                            **
**  PURPOSE   : This application file contains the EcuM Stub functions        **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

#include "EcuM.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 EcuM_GucSetWakeupEventCount;
uint8 EcuM_GucSetWakeupEventCheckCount;
EcuM_WakeupSourceType EcuM_Gddsources;
EcuM_WakeupSourceType EcuM_Gaasources[ECUM_ARRAY_SIZE];
uint8 EcuM_GucValidWakupEvCount;
uint8 EcuM_GucValidWakupEvCheckCount;

uint8 EcuM_CheckWakeupCount;
uint8 EcuM_CheckWakeupCheckCount;
EcuM_WakeupSourceType EcuM_Gddsource;

#ifdef BSWM_MODULE_ACTIVE
EcuM_StateType EcuM_GddTarget;
uint8 EcuM_GddMode;
uint8 EcuM_GucGoDownCount;
uint8 EcuM_GucSelectShutdownCount;
uint16 EcuM_GddModuleId;
uint8 EcuM_GucGoHaltCount;
uint8 EcuM_GucGoPollCount;
Std_ReturnType EcuM_GddReturnVal;
#endif

/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
#ifdef BSWM_MODULE_ACTIVE

Std_ReturnType EcuM_GoHalt(void)
{
  EcuM_GucGoHaltCount++;
  return(EcuM_GddReturnVal);
}

Std_ReturnType EcuM_GoPoll(void)
{
  EcuM_GucGoPollCount++;
  return(EcuM_GddReturnVal);
}

void EcuM_GoDown(uint16 ddModuleId)
{
	EcuM_GddModuleId = ddModuleId;
	EcuM_GucGoDownCount++;
}


Std_ReturnType EcuM_SelectShutdownTarget(EcuM_StateType target, uint8 mode)
{
	EcuM_GddTarget = target;
	EcuM_GddMode = mode;
	EcuM_GucSelectShutdownCount++;
	return(EcuM_GddReturnVal);
}

/*******************************************************************************
**                       TestEcuM_GoPoll()                                    **
*******************************************************************************/
boolean TestEcuM_GoPoll(App_DataValidateType  LucDataValidate)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if(EcuM_GucGoPollCount != 0x00)
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      EcuM_GucGoPollCount = 0;
      break;
    }
		case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */
		
		case M_VALIDATE_SEQ:
    {
      break;
    } /* End case M_VALIDATE_SEQ: */
		
		case S_NOT_INVOKED:
    {
      break;
    } /* End case S_NOT_INVOKED: */
		
		case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */
		
		
		case S_VALIDATE_SEQ:
    {
      break;
    } /* End case S_VALIDATE_SEQ: */
		
		default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEcuM_GoHalt() */

/*******************************************************************************
**                       TestEcuM_GoHalt()                                    **
*******************************************************************************/
boolean TestEcuM_GoHalt(App_DataValidateType  LucDataValidate)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if(EcuM_GucGoHaltCount != 0x00)
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      EcuM_GucGoHaltCount = 0;
      break;
    }
		case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */
		
		case M_VALIDATE_SEQ:
    {
      break;
    } /* End case M_VALIDATE_SEQ: */
		
		case S_NOT_INVOKED:
    {
      break;
    } /* End case S_NOT_INVOKED: */
		
		case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */
		
		
		case S_VALIDATE_SEQ:
    {
      break;
    } /* End case S_VALIDATE_SEQ: */
		
		default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEcuM_GoHalt() */

/*******************************************************************************
**                       TestEcuM_SelectShutdownTarget()                      **
*******************************************************************************/
boolean TestEcuM_SelectShutdownTarget(App_DataValidateType  
  LucDataValidate, EcuM_StateType target, uint8 mode)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((EcuM_GucSelectShutdownCount != 0x00) && (EcuM_GddTarget == target) && 
         (EcuM_GddMode == mode))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      EcuM_GucSelectShutdownCount = 0;
      break;
    }
		case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */
		
		case M_VALIDATE_SEQ:
    {
      break;
    } /* End case M_VALIDATE_SEQ: */
		
		case S_NOT_INVOKED:
    {
      break;
    } /* End case S_NOT_INVOKED: */
		
		case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */
		
		
		case S_VALIDATE_SEQ:
    {
      break;
    } /* End case S_VALIDATE_SEQ: */
		
		default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEcuM_SelectShutdownTarget() */

/*******************************************************************************
**                       TestEcuM_GoDown()                                    **
*******************************************************************************/
boolean TestEcuM_GoDown(App_DataValidateType  LucDataValidate, uint16 ddModuleId)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((EcuM_GucGoDownCount != 0x00) && (EcuM_GddModuleId == ddModuleId))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      EcuM_GucGoDownCount = 0;
      break;
    }
		case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */
		
		case M_VALIDATE_SEQ:
    {
      break;
    } /* End case M_VALIDATE_SEQ: */
		
		case S_NOT_INVOKED:
    {
      break;
    } /* End case S_NOT_INVOKED: */
		
		case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */
		
		
		case S_VALIDATE_SEQ:
    {
      break;
    } /* End case S_VALIDATE_SEQ: */
		
		default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEcuM_GoDown() */

#endif

/*******************************************************************************
**                     EcuM_SetWakeupEvent()                                  **
*******************************************************************************/
void EcuM_SetWakeupEvent(EcuM_WakeupSourceType sources)
{
  /* Load actual sources into Global variables */
  EcuM_Gaasources[EcuM_GucSetWakeupEventCount] = sources;
  EcuM_GucSetWakeupEventCount++;
}
/* End of EcuM_SetWakeupEvent() */

/*******************************************************************************
**                     TestEcuM_SetWakeupEvent()                              **
*******************************************************************************/
boolean TestEcuM_SetWakeupEvent(App_DataValidateType LddDataValidate,
EcuM_WakeupSourceType Expsources)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, sources  */
      if((EcuM_GucSetWakeupEventCount == 0x01) &&
         (EcuM_Gaasources[0] == Expsources))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      EcuM_GucSetWakeupEventCount = 0;
      EcuM_GucSetWakeupEventCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < EcuM_GucSetWakeupEventCount; LucIndex++)
      {
        /* Validate  */
        if(EcuM_Gaasources[LucIndex] == Expsources)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = EcuM_GucSetWakeupEventCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      EcuM_GucSetWakeupEventCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(EcuM_GucSetWakeupEventCheckCount == EcuM_GucSetWakeupEventCount)
      {
        EcuM_GucSetWakeupEventCount = 0;
        EcuM_GucSetWakeupEventCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(EcuM_GucSetWakeupEventCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestEcuM_SetWakeupEvent() */

/*******************************************************************************
**                       EcuM_ValidateWakeupEvent()                           **
*******************************************************************************/
void EcuM_ValidateWakeupEvent(EcuM_WakeupSourceType sources)
{
  /* Load actual sources into Global variables */
  EcuM_Gddsources = sources;
  EcuM_GucValidWakupEvCount++;
}
/* End of EcuM_ValidateWakeupEvent() */

/*******************************************************************************
**                   TestEcuM_ValidateWakeupEvent()                           **
*******************************************************************************/
boolean TestEcuM_ValidateWakeupEvent(App_DataValidateType LddDataValidate,
EcuM_WakeupSourceType Expsources)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, sources */
      if((EcuM_GucValidWakupEvCount == 0x01) &&
        (EcuM_Gddsources == Expsources))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      EcuM_GucValidWakupEvCount = 0;
      EcuM_GucValidWakupEvCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < EcuM_GucValidWakupEvCount; LucIndex++)
      {
        /* Validate sources */
        if((EcuM_Gddsources == Expsources))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = EcuM_GucValidWakupEvCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      EcuM_GucValidWakupEvCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(EcuM_GucValidWakupEvCheckCount ==
        EcuM_GucValidWakupEvCount)
      {
        EcuM_GucValidWakupEvCount = 0;
        EcuM_GucValidWakupEvCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(EcuM_GucValidWakupEvCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestEcuM_ValidateWakeupEvent() */

/*******************************************************************************
**                     EcuM_CheckWakeup()                                     **
*******************************************************************************/
void EcuM_CheckWakeup(EcuM_WakeupSourceType source)
{
  #ifndef TYPICAL_CONFIG
 /* Load actual source into Global variables */
  EcuM_Gddsource = source;
  EcuM_CheckWakeupCount++;
  #endif /* TYPICAL_CONFIG */
}
/* End of EcuM_CheckWakeup() */
/*******************************************************************************
**                        TestEcuM_CheckWakeup()                              **
*******************************************************************************/
boolean TestEcuM_CheckWakeup(App_DataValidateType LucDataValidate,
EcuM_WakeupSourceType Expsource)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, source  */
      if((EcuM_CheckWakeupCount == 0x01) &&
         (EcuM_Gddsource == Expsource))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      EcuM_CheckWakeupCount = 0;
      EcuM_CheckWakeupCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < EcuM_CheckWakeupCount; LucIndex++)
      {
        /* Validate  */
        if(EcuM_Gddsource == Expsource)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = EcuM_CheckWakeupCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      EcuM_CheckWakeupCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(EcuM_CheckWakeupCheckCount == EcuM_CheckWakeupCount)
      {
        EcuM_CheckWakeupCount = 0;
        EcuM_CheckWakeupCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(EcuM_CheckWakeupCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End of TestEcuM_CheckWakeup() */

/*******************************************************************************
**                        TestEcuM_DefaultBehavior()                          **
*******************************************************************************/
void TestEcuM_DefaultBehavior(void)
{  
  EcuM_GucSetWakeupEventCount = 0;
  EcuM_GucSetWakeupEventCheckCount = 0;
  EcuM_GucValidWakupEvCount = 0;
  EcuM_GucValidWakupEvCheckCount = 0;
  EcuM_CheckWakeupCount = 0;
  EcuM_CheckWakeupCheckCount = 0;
}

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

