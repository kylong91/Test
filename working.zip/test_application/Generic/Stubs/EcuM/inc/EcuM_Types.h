/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: EcuM_Types.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR EcuM Stub                                             **
**                                                                            **
**  PURPOSE   : Declaration of EcuM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef ECUM_TYPES_H
#define ECUM_TYPES_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Std_Types.h"
/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/

/* Variable for Wakeup source */
typedef uint32 EcuM_WakeupSourceType;
typedef uint8 EcuM_StateType;
typedef uint8 EcuM_WakeupStatusType;

#define ECUM_WKSOURCE_POWER               (EcuM_WakeupSourceType)1
#define ECUM_WKSOURCE_RESET               (EcuM_WakeupSourceType)2
#define ECUM_WKSOURCE_INTERNAL_RESET      (EcuM_WakeupSourceType)4
#define ECUM_WKSOURCE_INTERNAL_WDG        (EcuM_WakeupSourceType)8
#define ECUM_WKSOURCE_EXTERNAL_WDG        (EcuM_WakeupSourceType)16

/* EcuM_StateType */
#define ECUM_STATE_STARTUP_TWO                0x12
#define ECUM_STATE_WAKEUP_ONE                 0x21
#define ECUM_STATE_WAKEUP_VALIDATION          0x22
#define ECUM_STATE_WAKEUP_REACTION            0x23
#define ECUM_STATE_WAKEUP_TWO                 0x24 
#define ECUM_STATE_WAKEUP_WAKESLEEP           0x25
#define ECUM_STATE_WAKEUP_TTII                0x26
#define ECUM_STATE_APP_RUN                    0x32
#define ECUM_STATE_APP_POST_RUN               0x33
#define ECUM_STATE_PREP_SHUTDOWN              0x44
#define ECUM_STATE_GO_SLEEP                   0x49
#define ECUM_STATE_GO_OFF_ONE                 0x4d
#define ECUM_STATE_GO_OFF_TWO                 0x4e
#define ECUM_STATE_SLEEP                      0x50
#define ECUM_INVALID_CURRENTSTATE             0x00
#define ECUM_INVALID_CURRENTWAKEUP            0x00   
#define ECUM_SUBSTATE_MASK                    0x0f   
#define ECUM_STATE_STARTUP_ONE                0x11   
#define ECUM_STATE_RESET                      0x90   
#define ECUM_STATE_WAKEUP                     0x20   
#define ECUM_STATE_RUN                        0x30   
#define ECUM_STATE_SHUTDOWN                   0x40   
#define ECUM_STATE_OFF                        0x80     
#define ECUM_STATE_STARTUP                    0x10     

/* EcuM_WakeupStatusType */
#define ECUM_WKSTATUS_NONE                    0x00   
#define ECUM_WKSTATUS_PENDING                 0x01   
#define ECUM_WKSTATUS_VALIDATED               0x02   
#define ECUM_WKSTATUS_EXPIRED                 0x03   
#define ECUM_WKSTATUS_DISABLED                0x04 
/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/


#endif /* ECUM_TYPES_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
