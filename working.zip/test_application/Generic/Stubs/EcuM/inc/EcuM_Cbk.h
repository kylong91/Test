/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: EcuM_Cbk.h                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR EcuM Stub                                             **
**                                                                            **
**  PURPOSE   : Declaration of EcuM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef ECUM_CBK_H
#define ECUM_CBK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
#include "EcuM_Types.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define ECUM_AR_RELEASE_MAJOR_VERSION    4
#define ECUM_AR_RELEASE_MINOR_VERSION    0
#define ECUM_AR_RELEASE_REVISION_VERSION 2

#define EcuMConf_EcuMWakeupSource_EcuMWakeupSource0                      0
#define EcuMConf_EcuMWakeupSource_EcuMWakeupSource1                      1
#define EcuMConf_EcuMWakeupSource_EcuMWakeupSource2                      2
#define EcuMConf_EcuMWakeupSource_EcuMWakeupSource3                      3
#define EcuMConf_EcuMWakeupSource_EcuMWakeupSource4                      4

#define ECUM_ARRAY_SIZE      0x20

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void EcuM_SetWakeupEvent(EcuM_WakeupSourceType sources);

extern void EcuM_ValidateWakeupEvent(EcuM_WakeupSourceType sources);

extern boolean TestEcuM_SetWakeupEvent(App_DataValidateType LddDataValidate,
  EcuM_WakeupSourceType Expsources);

extern boolean TestEcuM_ValidateWakeupEvent(
  App_DataValidateType LddDataValidate, EcuM_WakeupSourceType Expsources);
  
extern void EcuM_CheckWakeup(EcuM_WakeupSourceType source);

extern boolean TestEcuM_CheckWakeup(App_DataValidateType LucDataValidate,
  EcuM_WakeupSourceType Expsource);

#endif /* ECUM_CBK_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
