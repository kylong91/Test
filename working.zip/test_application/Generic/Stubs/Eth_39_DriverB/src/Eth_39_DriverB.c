/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Eth.c                                                         **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR ETH Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Eth stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     22-Jun-2011   BJV    Initial version                             **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Eth_39_DriverB.h"    

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_DrvBGuc_CtrlInit_Controller;
uint8 Eth_DrvBGuc_CtrlInit_CfgIdx;
uint8 Eth_DrvBGucControllerintCount;
Std_ReturnType Eth_DrvBGdControllerintRetVal;



/*******************************************************************************
**                     Eth_39_DriverB_ControllerInit()                        **
*******************************************************************************/

Std_ReturnType Eth_39_DriverB_ControllerInit( uint8 CtrlIdx, uint8 CfgIdx )
{
  /* Load actual Controller and Transition into Global variables */
  Eth_DrvBGuc_CtrlInit_Controller = CtrlIdx;
  Eth_DrvBGuc_CtrlInit_CfgIdx = CfgIdx;
  Eth_DrvBGucControllerintCount++;

  return(Eth_DrvBGdControllerintRetVal);
} /* End Eth_39_DriverB_ControllerInit() */
/*******************************************************************************/

boolean TestEth_39_DriverB_ControllerInit(App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,uint8 LucExpCfgIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_DrvBGucControllerintCount > 0x00) &&
        (Eth_DrvBGuc_CtrlInit_Controller == LucExpCtrlIdx) &&
        (Eth_DrvBGuc_CtrlInit_CfgIdx == LucExpCfgIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_DrvBGucControllerintCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_DrvBGucControllerintCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_DrvBGucControllerintCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}
/*******************************************************************************
**            END OF Eth_39_DriverB_ControllerInit()                          **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_DrvBGucGetCtrlModeCount;
uint8 Eth_DrvBGucGetController;
Eth_ModeType* Eth_DrvBGdd_GetCtrl_Mode;
Std_ReturnType Eth_DrvBGetCtrlModeRetVal;


/*******************************************************************************
**                    Eth_39_DriverB_GetControllerMode()                      **
*******************************************************************************/
Std_ReturnType Eth_39_DriverB_GetControllerMode(
    uint8 CtrlIdx,
    Eth_ModeType* CtrlModePtr
)
/* Load actual Controller and Transition into Global variables */
{
  Eth_DrvBGucGetController = CtrlIdx;
  Eth_DrvBGdd_GetCtrl_Mode = CtrlModePtr;
  Eth_DrvBGucGetCtrlModeCount++;
  return(Eth_DrvBGetCtrlModeRetVal);
}
/* End Eth_DrvBGetCtrlModeRetVal */
/*******************************************************************************
**                     TestEth_39_DriverB_GetControllerMode()                 **
*******************************************************************************/

boolean TestEth_39_DriverB_GetControllerMode(App_DataValidateType LddDataValidate,
  uint8 LucExpController, Eth_ModeType* LddExpMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_DrvBGucGetCtrlModeCount > 0x00) &&
        (Eth_DrvBGucGetController == LucExpController) &&
        (Eth_DrvBGdd_GetCtrl_Mode != LddExpMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_DrvBGucGetCtrlModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_DrvBGucGetCtrlModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_DrvBGucGetCtrlModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestEth_39_DriverB_GetControllerMode() */
/*******************************************************************************
**            END OF TestEth_39_DriverB_GetControllerMode()                   **
*******************************************************************************/
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_DrvBGucCtrlIdx;
uint8  *Eth_DrvBGucBufIdxPtr;
uint8 **Eth_DrvBGucBufPtr;
uint16 *Eth_DrvBGucLenBytePtr;
uint8 Eth_DrvBGucPrvdTxBufCount;
Std_ReturnType Eth_DrvBGdPrvdTxBufRetVal;

/*******************************************************************************
**                        Eth_39_DriverB_ProvideTxBuffer()                    **
*******************************************************************************/
    
BufReq_ReturnType Eth_39_DriverB_ProvideTxBuffer(
    uint8 CtrlIdx,
    uint8* BufIdxPtr,
    uint8** BufPtr,
    uint16* LenBytePtr
)


{
  /* Load actual Controller and Transition into Global variables */
  Eth_DrvBGucCtrlIdx = CtrlIdx;
  Eth_DrvBGucBufIdxPtr = BufIdxPtr;
  Eth_DrvBGucBufPtr = BufPtr;
  Eth_DrvBGucLenBytePtr = LenBytePtr;
  Eth_DrvBGucPrvdTxBufCount++;

  return(Eth_DrvBGdPrvdTxBufRetVal);
} /* End Eth_DrvBGucTrasRceModeCount */
/*******************************************************************************/

boolean TestEth_39_DriverB_ProvideTxBuffer(App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,uint8* LucExpBufIdxPtr,
  uint8** LucExpBufPtr, uint16* LucExpLenBytePtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_DrvBGucPrvdTxBufCount > 0x00) &&
         (Eth_DrvBGucCtrlIdx == LucExpCtrlIdx) &&
         (Eth_DrvBGucBufIdxPtr != LucExpBufIdxPtr)&&
         (Eth_DrvBGucBufPtr != LucExpBufPtr) &&
         (Eth_DrvBGucLenBytePtr != LucExpLenBytePtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_DrvBGucPrvdTxBufCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_DrvBGucPrvdTxBufCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_DrvBGucPrvdTxBufCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}
/*******************************************************************************
**           END OF  EthIf_ProvideTxBuffer()                                  **
*******************************************************************************/
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_DrvBGucSetCtrlModeCount;
uint8 Eth_DrvBGucSetController;
Eth_ModeType Eth_DrvBGdd_SetCtrl_Mode;
Std_ReturnType Eth_DrvBGdSetCtrlModeRetVal;
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
**                     Eth_39_DriverB_SetControllerMode()                     **
*******************************************************************************/
Std_ReturnType Eth_39_DriverB_SetControllerMode( uint8 CtrlIdx, 
                                                        Eth_ModeType CtrlMode )
{
  /* Load actual Controller and Transition into Global variables */
  Eth_DrvBGucSetController = CtrlIdx;
  Eth_DrvBGdd_SetCtrl_Mode = CtrlMode;
  Eth_DrvBGucSetCtrlModeCount++;

  return(Eth_DrvBGdSetCtrlModeRetVal);
} /* End Eth_SetControllerMode() */

/*******************************************************************************
**                     TestEth_39_DriverB_SetControllerMode()                 **
*******************************************************************************/
boolean TestEth_39_DriverB_SetControllerMode(App_DataValidateType LddDataValidate,
  uint8 LucExpController, Eth_ModeType LddExpMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_DrvBGucSetCtrlModeCount > 0x00) &&
        (Eth_DrvBGucSetController == LucExpController) &&
        (Eth_DrvBGdd_SetCtrl_Mode == LddExpMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_DrvBGucSetCtrlModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_DrvBGucSetCtrlModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_DrvBGucSetCtrlModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCan_SetControllerMode() */

/*******************************************************************************
**             END OF Eth_SetControllerMode()                                 **
*******************************************************************************/
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_DrvBGucCtrlIdx;
Eth_FrameType Eth_DrvBGucFrameType;
uint8 Eth_DrvBGucBufIdx;
uint16 Eth_DrvBGucLenByte;
boolean Eth_DrvBGucTxConfirmation;
uint8*  Eth_DrvBGucPhysAddrPtr;
uint8 Eth_DrvBGucTransmitCount;
Std_ReturnType Eth_DrvBGdTransmitRetVal;

/*******************************************************************************
**                  Eth_39_DriverB_Transmit()                                 **
*******************************************************************************/

Std_ReturnType Eth_39_DriverB_Transmit(
    uint8 CtrlIdx,
    uint8 BufIdx,
    Eth_FrameType FrameType,
    boolean TxConfirmation,
    uint16 LenByte,
    uint8* PhysAddrPtr
)
{
  /* Load actual Controller and Transition into Global variables */
  Eth_DrvBGucCtrlIdx = CtrlIdx;
  Eth_DrvBGucFrameType = FrameType;
  Eth_DrvBGucBufIdx = BufIdx;
  Eth_DrvBGucTxConfirmation = TxConfirmation;
  Eth_DrvBGucLenByte = LenByte;
  Eth_DrvBGucTransmitCount++;
  Eth_DrvBGucPhysAddrPtr = PhysAddrPtr;
   return(Eth_DrvBGdTransmitRetVal);
} /* End Eth_39_DriverB_Transmit()  */
/*******************************************************************************/

boolean TestEth_39_DriverB_Transmit(App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,uint8 LucExpBufIdx,Eth_FrameType LddExpFrameType,
  boolean LucExpTxConfirmation,uint16  LucExpLenByte,uint8* LucExpPhysAddrPtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_DrvBGucTransmitCount > 0x00) &&
        (Eth_DrvBGucCtrlIdx == LucExpCtrlIdx) &&
        (Eth_DrvBGucFrameType == LddExpFrameType)&&
        (Eth_DrvBGucBufIdx == LucExpBufIdx)&&
        (Eth_DrvBGucTxConfirmation == LucExpTxConfirmation)&&
        (Eth_DrvBGucPhysAddrPtr!= LucExpPhysAddrPtr)&&
        (Eth_DrvBGucLenByte == LucExpLenByte))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_DrvBGucTransmitCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_DrvBGucTransmitCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_DrvBGucTransmitCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_DrvBGucGetPhyCtrlIdx;
uint8*  Eth_DrvBGucPhysAddrPtr;
uint8 Eth_DrvBGucGetPhyCount;

/*******************************************************************************
**                  Eth_39_DriverB_Transmit()                                 **
*******************************************************************************/
void Eth_39_DriverB_GetPhysAddr(uint8 CtrlIdx, uint8* PhysAddrPtr)
{
  /* Load actual Controller and Transition into Global variables */
  Eth_DrvBGucGetPhyCtrlIdx = CtrlIdx;
  Eth_DrvBGucGetPhyCount++;
  Eth_DrvBGucPhysAddrPtr = PhysAddrPtr;
} /* End Eth_39_DriverB_Transmit()  */
/*******************************************************************************/

boolean  TestEth_39_DriverB_GetPhysAddr(App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,uint8* LucExpPhysAddrPtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_DrvBGucGetPhyCount > 0x00) &&
        (Eth_DrvBGucGetPhyCtrlIdx == LucExpCtrlIdx)&&
        (Eth_DrvBGucPhysAddrPtr!= LucExpPhysAddrPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_DrvBGucGetPhyCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_DrvBGucGetPhyCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_DrvBGucGetPhyCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}

void Eth_39_DriverB_Receive(
  uint8 CtrlIdx,
  Eth_RxStatusType* RxStatusPtr
){
UNUSED(CtrlIdx);
UNUSED(RxStatusPtr);
}

void Eth_39_DriverB_TxConfirmation(
    uint8 CtrlIdx
){
UNUSED(CtrlIdx);
}
/*******************************************************************************
**             END OF  EthIf_Transmit()                                       **
*******************************************************************************/

