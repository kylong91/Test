/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: PduR_CanTp.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PduR_CanTp  Stub                                      **
**                                                                            **
**  PURPOSE   : Provision of external declaration of APIs and Service IDs     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/

#ifndef PDUR_CANTP_H
#define PDUR_CANTP_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/


/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void PduR_CanTpRxIndication(PduIdType RxPduId, NotifResultType Result);

extern boolean TestPduR_CanTpRxIndication(App_DataValidateType LucDataValidate,
  PduIdType ExpRxPduId, NotifResultType ExpResult);

extern void PduR_CanTpTxConfirmation(PduIdType TxPduId, NotifResultType Result);

extern boolean TestPduR_CanTpTxConfirmation(App_DataValidateType LucDataValidate,
  PduIdType ExpTxPduId, NotifResultType ExpResult);

extern BufReq_ReturnType PduR_CanTpStartOfReception(PduIdType RxPduId,
  PduLengthType TpSduLength, PduLengthType *RxBufferSizePtr);

extern  boolean TestPduR_CanTpStartOfReception(App_DataValidateType LucDataValidate,
  PduIdType ExpRxPduId, PduLengthType ExpTpSduLength,
  PduLengthType *RxBufferSizePtr);

extern  void TestPduR_CanTpStartOfReceptionSetVal(BufReq_ReturnType RetVal,
  PduLengthType RxBufferSize);

extern  BufReq_ReturnType PduR_CanTpCopyRxData(PduIdType RxPduId,
  PduInfoType *PduInfoPtr, PduLengthType *RxBufferSizePtr);

extern  boolean TestPduR_CanTpCopyRxData(App_DataValidateType LucDataValidate,
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr,
  PduLengthType *ExpRxBufferSizePtr);

extern  void TestPduR_CanTpCopyRxDataSetVal(BufReq_ReturnType RetVal,
  PduLengthType RxBufferSize);

extern  BufReq_ReturnType PduR_CanTpCopyTxData(PduIdType TxPduId,
  PduInfoType* PduInfoPtr, RetryInfoType* RetryInfoPtr,
  PduLengthType* TxDataCntPtr);

extern  boolean TestPduR_CanTpCopyTxData(App_DataValidateType LucDataValidate,
  PduIdType TxPduId, PduInfoType* PduInfoPtr, RetryInfoType* RetryInfoPtr,
  PduLengthType* TxDataCntPtr);

extern  void TestPduR_CanTpCopyTxDataSetVal(BufReq_ReturnType RetVal, uint8 *TxData,
  PduLengthType TxDataCnt);

  
extern  void PduR_CanTpChangeParameterConfirmation(PduIdType id, NotifResultType result);

boolean TestPduR_CanTpChangeParameterConfirmation(App_DataValidateType LucDataValidate, PduIdType ExId, NotifResultType ExpResult);
#endif /* PDUR_CANTP_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
