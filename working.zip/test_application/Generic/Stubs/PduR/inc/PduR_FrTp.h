/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: PduR_FrTp.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PduR_FrTp  Stub                                      **
**                                                                            **
**  PURPOSE   : Provision of external declaration of APIs and Service IDs     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By      Description                                **
********************************************************************************
** 1.0.0    29-Dec-2012   Kavya    Initial version                            **
*******************************************************************************/

#ifndef PDUR_FRTP_H
#define PDUR_FRTP_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/


/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void PduR_FrTpRxIndication(PduIdType RxPduId, NotifResultType Result);

extern boolean TestPduR_FrTpRxIndication(App_DataValidateType LucDataValidate,
  PduIdType ExpRxPduId, NotifResultType ExpResult);

extern void PduR_FrTpTxConfirmation(PduIdType TxPduId, NotifResultType Result);

extern boolean TestPduR_FrTpTxConfirmation(App_DataValidateType LucDataValidate,
  PduIdType ExpTxPduId, NotifResultType ExpResult);

extern BufReq_ReturnType PduR_FrTpStartOfReception(PduIdType RxPduId,
  PduLengthType TpSduLength, PduLengthType *RxBufferSizePtr);

extern  boolean TestPduR_FrTpStartOfReception(App_DataValidateType LucDataValidate,
  PduIdType ExpRxPduId, PduLengthType ExpTpSduLength);

extern  void TestPduR_FrTpStartOfReceptionSetVal(BufReq_ReturnType RetVal,
  PduLengthType RxBufferSize);

extern  BufReq_ReturnType PduR_FrTpCopyRxData(PduIdType RxPduId,
  PduInfoType *PduInfoPtr, PduLengthType *RxBufferSizePtr);

extern  boolean TestPduR_FrTpCopyRxData(App_DataValidateType LucDataValidate,
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr);

extern  void TestPduR_FrTpCopyRxDataSetVal(BufReq_ReturnType RetVal,
  PduLengthType RxBufferSize);

extern  BufReq_ReturnType PduR_FrTpCopyTxData(PduIdType TxPduId,
  PduInfoType* PduInfoPtr, RetryInfoType* RetryInfoPtr,
  PduLengthType* TxDataCntPtr);

extern  boolean TestPduR_FrTpCopyTxData(App_DataValidateType LucDataValidate,
  PduIdType TxPduId, PduInfoType* PduInfoPtr, RetryInfoType* RetryInfoPtr,
  PduLengthType* TxDataCntPtr);

extern  void TestPduR_FrTpCopyTxDataSetVal(BufReq_ReturnType RetVal, uint8 *TxData,
  PduLengthType TxDataCnt);
  
extern  void PduR_FrTpChangeParameterConfirmation(PduIdType id,
  NotifResultType result);

boolean TestPduR_FrTpChangeParameterConfirmation(App_DataValidateType
  LucDataValidate, PduIdType ExId, NotifResultType ExpResult);
#endif /* PDUR_FRTP_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
