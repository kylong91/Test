/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: PduR_DltCom.h                                                 **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PDUR Stub                                             **
**                                                                            **
**  PURPOSE   : Provision of external declaration of APIs and Service IDs     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/

#ifndef PDUR_DLTCOM_H
#define PDUR_DLTCOM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Std_ReturnType PduR_DltComTransmit(PduIdType id, PduInfoType* info);

extern boolean TestPduR_DltComTransmit(App_DataValidateType LucDataValidate,
  PduIdType id, PduInfoType* info);

extern Std_ReturnType PduR_DltComCancelTransmit(PduIdType id);

extern boolean TestPduR_DltComCancelTransmit(App_DataValidateType LucDataValidate, 
  PduIdType id);

#endif /* PDUR_DLTCOM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
