/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: PduR_LinIf.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PDUR Stub                                             **
**                                                                            **
**  PURPOSE   : Provision of external declaration of APIs and Service IDs     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/

#ifndef PDUR_LINIF_H
#define PDUR_LINIF_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

#include "TC_Generic.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void PduR_LinIfTxConfirmation(PduIdType TxPduId);

extern void PduR_LinIfRxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr);

extern boolean TestPduR_LinIfTxConfirmation(
  App_DataValidateType LddDataValidate, PduIdType ExpTxPduId);

extern boolean TestPduR_LinIfRxIndication(App_DataValidateType LddDataValidate,
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr);

extern Std_ReturnType PduR_LinIfTriggerTransmit(PduIdType TxPduId,
  PduInfoType *PduInfoPtr);

extern boolean TestPduR_LinIfTriggerTransmit(App_DataValidateType 
  LucDataValidate, PduIdType ExpTxPduId);

extern void TestSetPduR_LinIfTriggerTransmitRetVal(Std_ReturnType RetVal,
  PduInfoType *SetPduInfoPtr);

#endif /* PDUR_LINIF_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
