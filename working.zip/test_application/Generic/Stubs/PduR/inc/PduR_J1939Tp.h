/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: PduR_J1939Tp.h                                                **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PduR_J1939Tp  Stub                                    **
**                                                                            **
**  PURPOSE   : Provision of external declaration of APIs and Service IDs     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/

#ifndef PDUR_J1939TP_H
#define PDUR_J1939TP_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/


/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void PduR_J1939TpRxIndication(PduIdType RxPduId, NotifResultType Result);

extern boolean TestPduR_J1939TpRxIndication(App_DataValidateType LucDataValidate,
  PduIdType ExpRxPduId, NotifResultType ExpResult);

extern void PduR_J1939TpTxConfirmation(PduIdType TxPduId, NotifResultType Result);

extern boolean TestPduR_J1939TpTxConfirmation(App_DataValidateType LucDataValidate,
  PduIdType ExpTxPduId, NotifResultType ExpResult);

extern BufReq_ReturnType PduR_J1939TpStartOfReception(PduIdType RxPduId,
  PduLengthType TpSduLength, PduLengthType *RxBufferSizePtr);

extern  boolean TestPduR_J1939TpStartOfReception(App_DataValidateType LucDataValidate,
  PduIdType ExpRxPduId, PduLengthType ExpTpSduLength,
  PduLengthType *RxBufferSizePtr);

extern  void TestPduR_J1939TpStartOfReceptionSetVal(BufReq_ReturnType RetVal,
  PduLengthType RxBufferSize);

extern  BufReq_ReturnType PduR_J1939TpCopyRxData(PduIdType RxPduId,
  PduInfoType *PduInfoPtr, PduLengthType *RxBufferSizePtr);

extern  boolean TestPduR_J1939TpCopyRxData(App_DataValidateType LucDataValidate,
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr,
  PduLengthType *ExpRxBufferSizePtr);

extern  void TestPduR_J1939TpCopyRxDataSetVal(BufReq_ReturnType RetVal,
  PduLengthType RxBufferSize);

extern  BufReq_ReturnType PduR_J1939TpCopyTxData(PduIdType TxPduId,
  PduInfoType* PduInfoPtr, RetryInfoType* RetryInfoPtr,
  PduLengthType* TxDataCntPtr);

extern  boolean TestPduR_J1939TpCopyTxData(App_DataValidateType LucDataValidate,
  PduIdType TxPduId, PduInfoType* PduInfoPtr, RetryInfoType* RetryInfoPtr,
  PduLengthType* TxDataCntPtr);

extern  void TestPduR_J1939TpCopyTxDataSetVal(BufReq_ReturnType RetVal, uint8 *TxData,
  PduLengthType TxDataCnt);

#endif 
 /* PDUR_J1939TP_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
