/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: PduR_LinTp.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PduR_LinTp  Stub                                      **
**                                                                            **
**  PURPOSE   : Provision of external declaration of APIs and Service IDs     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/

#ifndef PDUR_LINTP_H
#define PDUR_LINTP_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "PduR.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void PduR_LinTpRxIndication(PduIdType RxPduId, NotifResultType Result);

extern boolean TestPduR_LinTpRxIndication(App_DataValidateType LucDataValidate,
  PduIdType ExpRxPduId, NotifResultType ExpResult);

extern void PduR_LinTpTxConfirmation(PduIdType TxPduId, NotifResultType Result);

extern boolean TestPduR_LinTpTxConfirmation(App_DataValidateType 
  LucDataValidate, PduIdType ExpTxPduId, NotifResultType ExpResult);

extern BufReq_ReturnType PduR_LinTpStartOfReception(PduIdType RxPduId,
  PduLengthType TpSduLength, PduLengthType *RxBufferSizePtr);

extern  boolean TestPduR_LinTpStartOfReception(App_DataValidateType 
  LucDataValidate, PduIdType ExpRxPduId, PduLengthType ExpTpSduLength,
  PduLengthType *RxBufferSizePtr);

extern void TestSetPduR_LinTpStartOfReceptionRetVal(PduIdType RxPduId, 
  PduLengthType RxBufferSize, BufReq_ReturnType RetVal);

extern  BufReq_ReturnType PduR_LinTpCopyRxData(PduIdType RxPduId,
  PduInfoType *PduInfoPtr, PduLengthType *RxBufferSizePtr);

extern  boolean TestPduR_LinTpCopyRxData(App_DataValidateType LucDataValidate,
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr,
  PduLengthType *ExpRxBufferSizePtr);

extern  void TestSetPduR_LinTpCopyRxDataRetVal(PduIdType RxPduId, 
  PduLengthType RxBufferSize, BufReq_ReturnType RetVal);

extern  BufReq_ReturnType PduR_LinTpCopyTxData(PduIdType TxPduId,
  PduInfoType* PduInfoPtr, RetryInfoType* RetryInfoPtr,
  PduLengthType* TxDataCntPtr);

extern  boolean TestPduR_LinTpCopyTxData(App_DataValidateType LucDataValidate,
  PduIdType TxPduId, PduInfoType* PduInfoPtr, RetryInfoType* RetryInfoPtr,
  PduLengthType* TxDataCntPtr);

extern void TestSetPduR_LinTpCopyTxDataRetVal(PduIdType TxPduId, 
  uint8 *TxData, BufReq_ReturnType RetVal);

extern void TestSetPduR_DefaultBuffer(PduLengthType BuffSize);
  
#endif /* PDUR_LINTP_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
