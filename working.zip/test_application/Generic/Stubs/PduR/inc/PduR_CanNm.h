/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: PduR_CanNm.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PduR Stub                                             **
**                                                                            **
**  PURPOSE   : C header for PduR_CanNm.c                                     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/

#ifndef PDUR_CANNM_H
#define PDUR_CANNM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void TestSetPduR_CanNmTriggerTransmit(PduInfoType* PduInfoPtr);

extern Std_ReturnType PduR_CanNmTriggerTransmit(PduIdType TxPduId,
  PduInfoType* PduInfoPtr);

extern boolean TestPduR_CanNmTriggerTransmit(
  App_DataValidateType LucDataValidate,
  PduIdType ExpCanTxPduId, PduInfoType* ExpPduInfoPtr);

extern void PduR_CanNmTxConfirmation(PduIdType TxPduId);

extern boolean TestPduR_CanNmTxConfirmation(
  App_DataValidateType LucDataValidate, PduIdType ExpCanTxPduId);

extern void PduR_CanNmRxIndication( PduIdType RxPduId, PduInfoType* PduInfoPtr);

extern boolean TestPduR_CanNmRxIndication(App_DataValidateType LddDataValidate,
PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr);

#endif /* PDUR_CANNM_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
