/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: PduR_Com.h                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PDUR Stub                                             **
**                                                                            **
**  PURPOSE   : Provision of external declaration of APIs and Service IDs     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/

#ifndef PDUR_COM_H
#define PDUR_COM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void TestSetPduR_ComTxRetVal(Std_ReturnType LddRetVal);

extern void TestSetPduR_ComPduIdForRet(PduIdType LddPduIdForRet);

extern Std_ReturnType PduR_ComTransmit(PduIdType LddPduId,
  PduInfoType* LddPduInfo);

extern Std_ReturnType PduR_DbgTransmit(PduIdType LddPduId,
  PduInfoType* LddPduInfo);

extern boolean TestPduR_ComTransmit(App_DataValidateType LucDataValidate,
  PduIdType ExpPduId, PduInfoType* ExpPduInfo);

extern boolean TestPduR_DbgTransmit(App_DataValidateType LucDataValidate,
  PduIdType ExpPduId, PduInfoType* ExpPduInfo);

#endif /* PDUR_COM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
