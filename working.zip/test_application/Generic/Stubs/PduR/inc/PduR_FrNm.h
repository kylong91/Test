/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: PduR_FrNm.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PduR Stub                                             **
**                                                                            **
**  PURPOSE   : C header for PduR_FrNm.c                                      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/

#ifndef PDUR_FRNM_H
#define PDUR_FRNM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void TestSetPduR_FrNmTriggerTransmit(PduInfoType* PduInfoPtr);

extern Std_ReturnType PduR_FrNmTriggerTransmit(PduIdType TxPduId,
  PduInfoType* PduInfoPtr);

extern boolean TestPduR_FrNmTriggerTransmit(
  App_DataValidateType LucDataValidate,
  PduIdType ExpCanTxPduId, PduInfoType* ExpPduInfoPtr);

extern void PduR_FrNmTxConfirmation(PduIdType TxPduId);

extern boolean TestPduR_FrNmTxConfirmation(
  App_DataValidateType LucDataValidate, PduIdType ExpCanTxPduId);

extern void PduR_FrNmRxIndication( PduIdType RxPduId, PduInfoType* PduInfoPtr);

extern boolean TestPduR_FrNmRxIndication(App_DataValidateType LddDataValidate,
PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr);

#endif /* PDUR_FRNM_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
