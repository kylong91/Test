/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: PduR_FrIf.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PduR Stub                                             **
**                                                                            **
**  PURPOSE   : C header for PduR_FrIf.c                                      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/

#ifndef PDUR_FRIF_H
#define PDUR_FRIF_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern Std_ReturnType PduR_FrIfTriggerTransmit(PduIdType TxPduId,
  PduInfoType* PduInfoPtr);

extern void PduR_FrIfTxConfirmation(PduIdType TxPduId);


extern void PduR_FrIfRxIndication(PduIdType RxPduId, PduInfoType* PduInfoPtr);

extern boolean TestPduR_FrIfRxIndication(App_DataValidateType LucDataValidate,
  PduIdType RxPduId, uint8 PduIength, 
  P2CONST(uint8,AUTOMATIC,FRIF_APPL_DATA)SduPtr);
  
extern boolean TestPduR_FrIfTriggerTransmit(App_DataValidateType LucDataValidate,
PduIdType TxPduId);

extern boolean TestPduR_FrIfTxConfirmation(App_DataValidateType LucDataValidate,
PduIdType TxPduId);
#endif /* PDUR_FRIF_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
