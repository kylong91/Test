/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: PduR.h                                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PDUR  Stub                                            **
**                                                                            **
**  PURPOSE   : Provision of external declaration of APIs and Service IDs     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/

#ifndef PDUR_H
#define PDUR_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"             /* Com Stack header */
#include "PduR_Types.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define PDUR_AR_RELEASE_MAJOR_VERSION            4
#define PDUR_AR_RELEASE_MINOR_VERSION            0
#define PDUR_AR_RELEASE_REVISION_VERSION         3

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
typedef uint8 PduR_PBConfigType;

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#if defined (FRTP_MODULE_ACTIVE)
  #define PDUR_DATA_LENGTH                         0xF8
#else
  #define PDUR_DATA_LENGTH                         0x09
#endif

#define PDUR_DATA_LENGTH_IPDUM                   0x0B
#define PDUR_ARRAY_SIZE                          0x28

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern boolean PduRTest_ValidateData(PduInfoType* LddExpPduInfo,
  PduInfoType* LddActPduInfo);
  
extern void PduR_EnableRouting(PduR_RoutingPathGroupIdType id);
extern void PduR_DisableRouting(PduR_RoutingPathGroupIdType id);

extern void TestPduR_DefaultBehavior(void);

extern boolean TestPduR_EnableRouting(
  App_DataValidateType LucDataValidate, PduR_RoutingPathGroupIdType LddExpid);
extern boolean TestPduR_DisableRouting(
  App_DataValidateType LucDataValidate, PduR_RoutingPathGroupIdType LddExpid);

extern void PduR_Init(const PduR_PBConfigType* ConfigPtr);

extern boolean TestPduR_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);

#endif /* PDUR_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
