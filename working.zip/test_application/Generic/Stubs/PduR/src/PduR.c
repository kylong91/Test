/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR IPDU Multiplexer                                      **
**                                                                            **
**  PURPOSE   : This file contains PduR stub functionality for the I-PDUM     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     26-Nov-2012   Kiranmai    Initial version                        **
** 1.0.1     26-Sep-2011   BPT    Updated for               Com               **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "PduR.h"
#ifdef CANNM_MODULE_ACTIVE
#include "PduR_CanNm.h"
#endif

#ifdef CANTP_MODULE_ACTIVE
#include "PduR_CanTp.h"
#endif

#ifdef J1939TP_MODULE_ACTIVE
#include "PduR_J1939Tp.h"
#endif

#ifdef CANIF_MODULE_ACTIVE
#include "PduR_CanIf.h"
#endif

#ifdef COM_MODULE_ACTIVE
#include "PduR_Com.h"
#endif

#ifdef IPDUM_MODULE_ACTIVE
#include "PduR_IpduM.h"
#endif

#ifdef LINIF_MODULE_ACTIVE
#include "PduR_LinIf.h"
#endif

#ifdef DCM_MODULE_ACTIVE
#include "PduR_Dcm.h"
#endif

#ifdef FRIF_MODULE_ACTIVE
#include "PduR_FrIf.h"
#endif

#ifdef FRNM_MODULE_ACTIVE
#include "PduR_FrNm.h"
#endif
#ifdef DBG_MODULE_ACTIVE
#include "PduR_Dbg.h"
#endif
#ifdef DLT_MODULE_ACTIVE
#include "PduR_DltCom.h"
#endif

#ifdef FRTP_MODULE_ACTIVE
#include "Platform_Types.h"
#include "PduR_FrTp.h"
#endif
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#ifdef FRTP_MODULE_ACTIVE
PduIdType PduR_GddFrTpRxIndPduId[PDUR_ARRAY_SIZE];
NotifResultType PduR_GddFrTpRxIndResult[PDUR_ARRAY_SIZE];
uint8 PduR_GucFrTpRxIndCount;
uint8 PduR_GucFrTpRxIndCheckCount;

PduIdType PduR_GddFrTpTxConfPduId[PDUR_ARRAY_SIZE];
NotifResultType PduR_GddFrTpTxConfResult[PDUR_ARRAY_SIZE];
uint8 PduR_GucFrTpTxConfCount;
uint8 PduR_GucFrTpTxConfCheckCount;

PduIdType PduR_GddFrTpSorPduId[PDUR_ARRAY_SIZE];
PduLengthType PduR_GddFrTpSorTpSduLength[PDUR_ARRAY_SIZE];
PduLengthType PduR_GddFrTpSorRxBuffer;
BufReq_ReturnType PduR_GddFrTpSorRetVal;
uint8 PduR_GucFrTpSorCount;
uint8 PduR_GucFrTpSorCheckCount;

PduIdType PduR_GddFrTpCopyRxDataPduId[PDUR_ARRAY_SIZE];
uint8 PduR_GddFrTpCopyRxDataSduLength[PDUR_ARRAY_SIZE];
uint8 PduR_GaaFrTpCopyRxDataSduData[PDUR_DATA_LENGTH];
PduLengthType PduR_GddFrTpCopyRxDataRxBuffer;
BufReq_ReturnType PduR_GddFrTpCopyRxDataRetVal;
uint8 PduR_GucFrTpCopyRxDataCount;
uint8 PduR_GucFrTpCopyRxDataCheckCount;

PduIdType PduR_GddFrTpCopyTxDataPduId[PDUR_ARRAY_SIZE];
uint8 PduR_GddFrTpCopyTxDataSduLength[PDUR_ARRAY_SIZE];
uint8 PduR_GaaFrTpCopyTxDataSduData[PDUR_DATA_LENGTH];
RetryInfoType PduR_GddFrTpCopyTxDataRetryInfo[PDUR_ARRAY_SIZE];
PduLengthType PduR_GddFrTpCopyTxDataTxDataCnt = 0;
BufReq_ReturnType PduR_GddFrTpCopyTxDataRetVal;
uint8 PduR_GucFrTpCopyTxDataCount;
uint8 PduR_GucFrTpCopyTxDataCheckCount;

PduIdType PduR_GddFrTpChngeParConfPduId[PDUR_ARRAY_SIZE];
NotifResultType PduR_GddFrTpChngeParConfResult[PDUR_ARRAY_SIZE];
uint8 PduR_GucFrTpChngeParConfCount;
uint8 PduR_GucFrTpChngeParConfCheckCount;

#endif
#ifdef IPDUM_MODULE_ACTIVE
Std_ReturnType PduR_GddIpduMTxRetVal;
uint8 PduR_GucIpduMTxCount;
PduIdType PduR_GucIpduMTxPduId;
uint8 PduR_GucIpduMTxSduLength;
uint8 PduR_GucIpduMTxSduData[PDUR_DATA_LENGTH_IPDUM];

Std_ReturnType PduR_GddIpduMTrigTxRetVal = E_OK;
uint8 PduR_GucIpduMTrigTxCount = 0x00;
uint8 PduR_GucPduRIpduMTrigTxCheckCount = 0x00;
PduIdType PduR_GucIpduMTrigTxPduId[PDUR_ARRAY_SIZE];

PduIdType PduR_GucIpduMTrigSetTxPduId[PDUR_ARRAY_SIZE];
uint8 PduR_GucIpduMTrigSetTxSduLength[PDUR_ARRAY_SIZE];
uint8 PduR_GucIpduMTrigSetTxSduData[PDUR_ARRAY_SIZE][PDUR_DATA_LENGTH_IPDUM];

uint8 PduR_GucIpduMTxConfCount = 0x00;
uint8 PduR_GucIpduMTxConfCheckCount = 0x00;
PduIdType PduR_GucIpduMTxConfPduId[PDUR_ARRAY_SIZE];

uint8 PduR_GucIpduMRxIndCount = 0x00;
uint8 PduR_GucIpduMRxIndCheckCount = 0x00;
PduIdType PduR_GucIpduMRxIndPduId[PDUR_ARRAY_SIZE];
uint8 PduR_GucIpduMRxIndSduLength[PDUR_ARRAY_SIZE];
uint8 PduR_GucIpduMRxIndSduData[PDUR_ARRAY_SIZE][PDUR_DATA_LENGTH_IPDUM];
#endif

#ifdef COM_MODULE_ACTIVE

PduR_ReturnType PduR_GddComTxRetVal;
uint8 PduR_GucComTxCount;
uint8 PduR_GucComTxCheckCount;
uint8 PduR_GucComActSduData[PDUR_ARRAY_SIZE][PDUR_DATA_LENGTH];
uint8 PduR_GucComActPduId[PDUR_ARRAY_SIZE];
uint8 PduR_GucComActSduLength[PDUR_ARRAY_SIZE];
#endif

#ifdef CANNM_MODULE_ACTIVE
PduIdType PduR_GddCanNmCanTxPduId;
uint8 PduR_GddCanNmTrigTxSduLength;
uint8 PduR_GaaCanNmTrigTxData[PDUR_ARRAY_SIZE];
uint8 PduR_GucCanNmTrigTxCount;
uint8 PduR_GucCanNmTxConfirmCount;
uint8 PduR_GucCanNmRxIndiCount;
PduIdType PduR_GucCanNmRxPduId;
uint8 PduR_GaaCanNmRxIndSduData[PDUR_DATA_LENGTH];
uint8 PduR_GucCanNmRxIndSduLength;
#endif

#ifdef FRNM_MODULE_ACTIVE
PduIdType PduR_GddFrNmCanTxPduId;
uint8 PduR_GddFrNmTrigTxSduLength;
uint8 PduR_GaaFrNmTrigTxData[PDUR_ARRAY_SIZE];
uint8 PduR_GucFrNmTrigTxCount;
uint8 PduR_GucFrNmTxConfirmCount;
uint8 PduR_GucFrNmRxIndiCount;
PduIdType PduR_GucFrNmRxPduId;
uint8 PduR_GaaFrNmRxIndSduData[PDUR_DATA_LENGTH];
uint8 PduR_GucFrNmRxIndSduLength;
#endif

#ifdef BSWM_MODULE_ACTIVE
uint8 PduR_GucEnableRoutingCount;
uint8 PduR_GucDisableRoutingCount;
PduR_RoutingPathGroupIdType PduR_Gddid;
uint8 PduR_GucInitCnt;
uint8 PduR_GucInitSeqCnt;
#endif

#ifdef CANIF_MODULE_ACTIVE
/* Variables used for CanIf module  */
uint8 PduR_GucCanIfTxConfirmCount;
uint8 PduR_GucCanIfTxConfirmCheckCount;
PduIdType PduR_GucCanIfTxPduId;
uint8 PduR_GucCanIfRxIndiCount;
PduIdType PduR_GucCanIfRxPduId;
uint8 PduR_GaaCanIfRxIndSduData[PDUR_DATA_LENGTH];
uint8 PduR_GucCanIfRxIndSduLength;
#endif


#ifdef CANTP_MODULE_ACTIVE
PduIdType PduR_GddCanTpRxIndPduId[PDUR_ARRAY_SIZE];
NotifResultType PduR_GddCanTpRxIndResult[PDUR_ARRAY_SIZE];
uint8 PduR_GucCanTpRxIndCount;
uint8 PduR_GucCanTpRxIndCheckCount;

PduIdType PduR_GddCanTpTxConfPduId;
NotifResultType PduR_GddCanTpTxConfResult;
uint8 PduR_GucCanTpTxConfCount;

PduIdType PduR_GddCanTpSorPduId[PDUR_ARRAY_SIZE];
PduLengthType PduR_GddCanTpSorTpSduLength[PDUR_ARRAY_SIZE];
PduLengthType PduR_GddCanTpSorRxBuffer;
BufReq_ReturnType PduR_GddCanTpSorRetVal;
uint8 PduR_GucCanTpSorCount;
uint8 PduR_GucCanTpSorCheckCount;

PduIdType PduR_GddCanTpCopyRxDataPduId[PDUR_ARRAY_SIZE];
uint8 PduR_GddCanTpCopyRxDataSduLength[PDUR_ARRAY_SIZE];
uint8 PduR_GaaCanTpCopyRxDataSduData[PDUR_DATA_LENGTH];
PduLengthType PduR_GddCanTpCopyRxDataRxBuffer;
BufReq_ReturnType PduR_GddCanTpCopyRxDataRetVal;
uint8 PduR_GucCanTpCopyRxDataCount;
uint8 PduR_GucCanTpCopyRxDataCheckCount;

PduIdType PduR_GddCanTpCopyTxDataPduId[PDUR_ARRAY_SIZE];
uint8 PduR_GddCanTpCopyTxDataSduLength[PDUR_ARRAY_SIZE];
uint8 PduR_GaaCanTpCopyTxDataSduData[PDUR_DATA_LENGTH];
RetryInfoType PduR_GddCanTpCopyTxDataRetryInfo[PDUR_ARRAY_SIZE];
PduLengthType PduR_GddCanTpCopyTxDataTxDataCnt;
BufReq_ReturnType PduR_GddCanTpCopyTxDataRetVal;
uint8 PduR_GucCanTpCopyTxDataCount;
uint8 PduR_GucCanTpCopyTxDataCheckCount;

PduIdType PduR_GddCanTpChngeParConfPduId[PDUR_ARRAY_SIZE];
NotifResultType PduR_GddCanTpChngeParConfResult[PDUR_ARRAY_SIZE];
uint8 PduR_GucCanTpChngeParConfCount;
uint8 PduR_GucCanTpChngeParConfCheckCount;
#endif

#ifdef J1939TP_MODULE_ACTIVE
PduIdType PduR_GddJ1939TpRxIndPduId[PDUR_ARRAY_SIZE];
NotifResultType PduR_GddJ1939TpRxIndResult[PDUR_ARRAY_SIZE];
uint8 PduR_GucJ1939TpRxIndCount;
uint8 PduR_GucJ1939TpRxIndCheckCount;

PduIdType PduR_GddJ1939TpTxConfPduId;
NotifResultType PduR_GddJ1939TpTxConfResult;
uint8 PduR_GucJ1939TpTxConfCount;

PduIdType PduR_GddJ1939TpSorPduId[PDUR_ARRAY_SIZE];
PduLengthType PduR_GddJ1939TpSorTpSduLength[PDUR_ARRAY_SIZE];
PduLengthType PduR_GddJ1939TpSorRxBuffer;

BufReq_ReturnType PduR_GddJ1939TpSorRetVal;
uint8 PduR_GucJ1939TpSorCount;
uint8 PduR_GucJ1939TpSorCheckCount;
PduLengthType PduR_GddJ1939TpCopyRxDataRxBuffer;

PduIdType PduR_GddJ1939TpCopyRxDataPduId[PDUR_ARRAY_SIZE];
uint8 PduR_GddJ1939TpCopyRxDataSduLength[PDUR_ARRAY_SIZE];
uint8 PduR_GaaJ1939TpCopyRxDataSduData[PDUR_DATA_LENGTH];
PduLengthType PduR_GddCanTpCopyRxDataRxBuffer;
BufReq_ReturnType PduR_GddJ1939TpCopyRxDataRetVal;
uint8 PduR_GucJ1939TpCopyRxDataCount;
uint8 PduR_GucJ1939TpCopyRxDataCheckCount;

PduIdType PduR_GddJ1939TpCopyTxDataPduId[PDUR_ARRAY_SIZE];
uint8 PduR_GddJ1939TpCopyTxDataSduLength[PDUR_ARRAY_SIZE];
uint8 PduR_GaaJ1939TpCopyTxDataSduData[PDUR_DATA_LENGTH];
RetryInfoType PduR_GddJ1939TpCopyTxDataRetryInfo[PDUR_ARRAY_SIZE];
PduLengthType PduR_GddJ1939TpCopyTxDataTxDataCnt;
BufReq_ReturnType PduR_GddJ1939TpCopyTxDataRetVal;
uint8 PduR_GucJ1939TpCopyTxDataCount;
uint8 PduR_GucJ1939TpCopyTxDataCheckCount;

PduIdType PduR_GddJ1939TpChngeParConfPduId[PDUR_ARRAY_SIZE];
NotifResultType PduR_GddJ1939TpChngeParConfResult[PDUR_ARRAY_SIZE];
uint8 PduR_GucJ1939TpChngeParConfCount;
uint8 PduR_GucJ1939TpChngeParConfCheckCount;
#endif


#ifdef LINIF_MODULE_ACTIVE
PduIdType PduR_GucLinIfTxConfPduId[PDUR_ARRAY_SIZE];
uint8 PduR_GucLinIfTxConfCount;
uint8 PduR_GucLinIfTxConfCheckCount;
BufReq_ReturnType PduR_GaaLinTpCopyRxDataRetVal[PDUR_ARRAY_SIZE];
BufReq_ReturnType PduR_GaaLinTpCopyTxDataRetVal[PDUR_ARRAY_SIZE];
BufReq_ReturnType PduR_GaaLinTpSorRetVal[PDUR_ARRAY_SIZE];

PduIdType PduR_GaaLinIfRxIndPduId[PDUR_ARRAY_SIZE];
PduLengthType PduR_GaaLinIfRxIndSduLength[PDUR_ARRAY_SIZE];
uint8 PduR_GaaLinIfRxIndSduData[PDUR_ARRAY_SIZE][PDUR_DATA_LENGTH];
uint8 PduR_GucLinIfRxIndCount;
uint8 PduR_GucLinIfRxIndCheckCount;

PduIdType PduR_GaaLinIfTrigTxPduId[PDUR_ARRAY_SIZE];
uint8 PduR_GucLinIfTrigTxCount;
uint8 PduR_GucPduRLinIfTrigTxCheckCount;
PduIdType PduR_GaaLinIfTrigSetTxPduId[PDUR_ARRAY_SIZE];
PduLengthType PduR_GaaLinIfTrigSetTxSduLength[PDUR_ARRAY_SIZE];
uint8 PduR_GaaLinIfTrigSetTxSduData[PDUR_ARRAY_SIZE][PDUR_DATA_LENGTH];
/* Variables used for LinTp module  */
PduIdType PduR_GaaLinTpRxIndPduId[PDUR_ARRAY_SIZE];
NotifResultType PduR_GaaLinTpRxIndResult[PDUR_ARRAY_SIZE];
uint8 PduR_GucLinTpRxIndCount;
uint8 PduR_GucLinTpRxIndCheckCount;

PduIdType PduR_GaaLinTpTxConfPduId[PDUR_ARRAY_SIZE];
NotifResultType PduR_GaaLinTpTxConfResult[PDUR_ARRAY_SIZE];
uint8 PduR_GucLinTpTxConfCount;
uint8 PduR_GucLinTpTxConfCheckCount;
PduLengthType PduR_GucLinTpAvblBuff;
PduIdType PduR_GaaLinTpSorPduId[PDUR_ARRAY_SIZE];
PduLengthType PduR_GaaLinTpSorTpSduLength[PDUR_ARRAY_SIZE];
PduLengthType PduR_GaaLinTpSorRxBuffer[PDUR_ARRAY_SIZE];
uint8 PduR_GucLinTpSorCount;
uint8 PduR_GucLinTpSorCheckCount;

PduIdType PduR_GaaLinTpCopyRxDataPduId[PDUR_ARRAY_SIZE];
PduLengthType PduR_GaaLinTpCopyRxDataSduLength[PDUR_ARRAY_SIZE];
uint8 PduR_GaaLinTpCopyRxDataSduData[PDUR_ARRAY_SIZE][PDUR_DATA_LENGTH];
PduLengthType PduR_GaaLinTpCopyRxDataRxBuffer[PDUR_ARRAY_SIZE];
uint8 PduR_GucLinTpCopyRxDataCount;
uint8 PduR_GucLinTpCopyRxDataCheckCount;

PduIdType PduR_GaaLinTpCopyTxDataPduId[PDUR_ARRAY_SIZE];
PduLengthType PduR_GaaLinTpCopyTxDataSduLength[PDUR_ARRAY_SIZE];
uint8 PduR_GaaLinTpCopyTxDataSduData[PDUR_ARRAY_SIZE][PDUR_DATA_LENGTH];
RetryInfoType* PduR_GaaLinTpCopyTxDataRetryInfo[PDUR_ARRAY_SIZE];
PduLengthType PduR_GaaLinTpCopyTxDataTxDataCnt[PDUR_ARRAY_SIZE];
uint8 PduR_GucLinTpCopyTxDataCount;
uint8 PduR_GucLinTpCopyTxDataCheckCount;

PduIdType PduR_GaaLinTpChngeParConfPduId[PDUR_ARRAY_SIZE];
NotifResultType PduR_GaaLinTpChngeParConfResult[PDUR_ARRAY_SIZE];
uint8 PduR_GucLinTpChngeParConfCount;
uint8 PduR_GucLinTpChngeParConfCheckCount;
/* Variables used for LinTp module  */
#endif

#ifdef FRIF_MODULE_ACTIVE
uint8 PduR_GucFrIfTriggerTransmit;
uint8 Pdu_PduR_GucFrIfTxPduId;
uint8 Pdu_GucTxConfirmCount;
uint8 PduR_GucFrIfTxConfirmationCount=0;
PduIdType PduR_GucFrIfTxPduId;
PduIdType PduR_GucFrIfRxPduId;
uint32 PduR_GulSduLength;
uint8 PduR_GaaSduData[25]; 
uint8 PduR_GucFrIfRxIndicationCount=0;
uint8 PduR_GucIndex=0;
#endif

#ifdef DBG_MODULE_ACTIVE
PduIdType PduR_GddDbgTxPduId;
uint8 PduR_GucDbgTransmitSduLength[PDUR_ARRAY_SIZE];
uint8 PduR_GucDbgTransmitSduData[PDUR_ARRAY_SIZE][PDUR_DATA_LENGTH];
uint8 PduR_GucDbgTxCount;
uint8 PduR_GucDbgTxCheckCount;
Std_ReturnType PduR_GddDbgTxRetVal;
#endif

#ifdef DCM_MODULE_ACTIVE
PduR_ReturnType PduR_GddDcmTxRetVal;
uint8 PduR_GucDcmPduid;
uint8 PduR_GucDcmSduLength;
uint8 PduR_GucDcmTxCount;
#endif

#ifdef DLT_MODULE_ACTIVE
PduIdType PduR_GddDltPduId;
Std_ReturnType PduR_DltComTransmitRetVal;
uint32 PduR_GulDltSduLength;
uint8 PduR_GucDltTxCount;
#endif

#ifdef FRTP_MODULE_ACTIVE
/*******************************************************************************
**                       PduR_FrTpRxIndication()                             **
*******************************************************************************/
void PduR_FrTpRxIndication(PduIdType RxPduId, NotifResultType Result)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual PduId and result into Global variables */
  PduR_GddFrTpRxIndPduId[PduR_GucFrTpRxIndCount] = RxPduId;
  PduR_GddFrTpRxIndResult[PduR_GucFrTpRxIndCount] = Result;
  /* Increment count variable to handle multiple invocations */
  PduR_GucFrTpRxIndCount++;
  #endif
} /* End PduR_FrTpRxIndication() */

/*******************************************************************************
**                       TestPduR_FrTpRxIndication()                         **
*******************************************************************************/
boolean TestPduR_FrTpRxIndication(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, NotifResultType ExpResult)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, RxPduId and Result */
      if((PduR_GucFrTpRxIndCount == 0x01) &&
        (PduR_GddFrTpRxIndPduId[0] == ExpRxPduId) && 
        (PduR_GddFrTpRxIndResult[0] == ExpResult))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucFrTpRxIndCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucFrTpRxIndCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < PduR_GucFrTpRxIndCount; LucIndex++)
      {
        /* Validate the PduId */
        if((PduR_GddFrTpRxIndPduId[LucIndex] == ExpRxPduId) && 
        (PduR_GddFrTpRxIndResult[LucIndex] == ExpResult))
        {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
          */
          LucIndex = PduR_GucFrTpRxIndCount;
        } /* End if((PduR_GddFrTpRxIndPduId[LucIndex] == ExpRxPduId) &&  */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucFrTpRxIndCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucFrTpRxIndCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucFrTpRxIndCheckCount == PduR_GucFrTpRxIndCount)
      {
        PduR_GucFrTpRxIndCount = 0;
        PduR_GucFrTpRxIndCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);

} /* End TestPduR_FrTpRxIndication() */
/*******************************************************************************
**                       PduR_FrTpTxConfirmation()                           **
*******************************************************************************/
void PduR_FrTpTxConfirmation(PduIdType TxPduId, NotifResultType Result)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual PduId and result into Global variables */
  PduR_GddFrTpTxConfPduId[PduR_GucFrTpTxConfCount] = TxPduId;
  PduR_GddFrTpTxConfResult[PduR_GucFrTpTxConfCount] = Result;
  /* Increment count variable to handle multiple invocations */
  PduR_GucFrTpTxConfCount++;
  #endif
} /* End PduR_FrTpTxConfirmation() */

/*******************************************************************************
**                       TestPduR_FrTpTxConfirmation()                       **
*******************************************************************************/
boolean TestPduR_FrTpTxConfirmation(App_DataValidateType LucDataValidate, 
  PduIdType ExpTxPduId, NotifResultType ExpResult)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count and Id */
      if((PduR_GucFrTpTxConfCount == 0x01) && (ExpTxPduId == PduR_GddFrTpTxConfPduId[0]) && 
        (PduR_GddFrTpTxConfResult[0] == ExpResult))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucFrTpTxConfCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucFrTpTxConfCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < PduR_GucFrTpTxConfCount; LucIndex++)
      {
        /* Validate the PduId */
        if((PduR_GddFrTpTxConfPduId[LucIndex] == ExpTxPduId) && 
        (PduR_GddFrTpTxConfResult[LucIndex] == ExpResult))
        {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
          */
          LucIndex = PduR_GucFrTpTxConfCount;
        } /* End if((PduR_GddFrTpRxIndPduId[LucIndex] == ExpRxPduId) &&  */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucFrTpTxConfCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucFrTpTxConfCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucFrTpTxConfCheckCount == PduR_GucFrTpTxConfCount)
      {
        PduR_GucFrTpTxConfCount = 0;
        PduR_GucFrTpTxConfCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);

} /* End TestPduR_FrTpTxConfirmation() */

/*******************************************************************************
**                       PduR_FrTpStartOfReception()                         **
*******************************************************************************/
BufReq_ReturnType PduR_FrTpStartOfReception(PduIdType RxPduId, 
  PduLengthType TpSduLength, PduLengthType *RxBufferSizePtr)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual PduId, TpSduLength into Global variables */
  PduR_GddFrTpSorPduId[PduR_GucFrTpSorCount] = RxPduId;
  PduR_GddFrTpSorTpSduLength[PduR_GucFrTpSorCount] = TpSduLength;
  /* Load RxBufferSizePtr with data of PduR_GddFrTpSorRxBuffer  */
  *RxBufferSizePtr = PduR_GddFrTpSorRxBuffer;
  /* Increment count variable to handle multiple invocations */
  PduR_GucFrTpSorCount++;
  #endif
  return(PduR_GddFrTpSorRetVal);
} /* End PduR_FrTpStartOfReception() */

/*******************************************************************************
**                       TestPduR_FrTpStartOfReception()                     **
*******************************************************************************/
boolean TestPduR_FrTpStartOfReception(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, PduLengthType ExpTpSduLength)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, Id and TpSduLength */
      if((PduR_GucFrTpSorCount == 0x01) && 
      (PduR_GddFrTpSorPduId[0] == ExpRxPduId) && 
      (PduR_GddFrTpSorTpSduLength[0] == ExpTpSduLength))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucFrTpSorCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucFrTpSorCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < PduR_GucFrTpSorCount; LucIndex++)
      {
        /* Validate the PduId */
        if((PduR_GddFrTpSorPduId[LucIndex] == ExpRxPduId) && 
        (PduR_GddFrTpSorTpSduLength[LucIndex] == ExpTpSduLength))
        {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
          */
          LucIndex = PduR_GucFrTpSorCount;
        } /* End if((PduR_GddFrTpRxIndPduId[LucIndex] == ExpRxPduId) &&  */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucFrTpSorCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucFrTpSorCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucFrTpSorCheckCount == PduR_GucFrTpSorCount)
      {
        PduR_GucFrTpSorCount = 0;
        PduR_GucFrTpSorCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestPduR_FrTpStartOfReception() */

/*******************************************************************************
**                       TestPduR_FrTpStartOfReceptionSetVal()               **
*******************************************************************************/
void TestPduR_FrTpStartOfReceptionSetVal(BufReq_ReturnType RetVal, 
  PduLengthType RxBufferSize)
{
  PduR_GddFrTpSorRetVal = RetVal;
  PduR_GddFrTpSorRxBuffer = RxBufferSize;
} /* End TestPduR_FrTpStartOfReceptionSetVal() */

/*******************************************************************************
**                       PduR_FrTpCopyRxData()                               **
*******************************************************************************/
BufReq_ReturnType PduR_FrTpCopyRxData(PduIdType RxPduId,
  PduInfoType *PduInfoPtr, PduLengthType *RxBufferSizePtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8 *LpSduDataPtr;
  /* Load the address of SduDataPtr into Local Variable */
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  
  /* Load actual PduId, SduLength into Global variables */
  PduR_GddFrTpCopyRxDataPduId[PduR_GucFrTpCopyRxDataCount] = RxPduId;
  PduR_GddFrTpCopyRxDataSduLength[PduR_GucFrTpCopyRxDataCount] = (uint8)(PduInfoPtr->SduLength);
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > PDUR_DATA_LENGTH)
  {
    LucDataLength = PDUR_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = (uint8) PduInfoPtr->SduLength;
  }
  /* 
   * Load PduR_GaaFrTpCopyRxDataSduData with SduDataPtr and RxBufferSizePtr 
   * with data of PduR_GddFrTpCopyRxDataRxBuffer  
   */
  /* Load the SduDataPtr with the global array */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    PduR_GaaFrTpCopyRxDataSduData[LucDataIndex] = *LpSduDataPtr;
    LpSduDataPtr++;
  }
  *RxBufferSizePtr = PduR_GddFrTpCopyRxDataRxBuffer;
  /* Increment count variable to handle multiple invocations */
  PduR_GucFrTpCopyRxDataCount++;
  #endif
  return(PduR_GddFrTpCopyRxDataRetVal);
} /* End PduR_FrTpCopyRxData() */

/*******************************************************************************
**                       TestPduR_FrTpCopyRxData()                           **
*******************************************************************************/
boolean TestPduR_FrTpCopyRxData(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, Id and SduLength */
      if((PduR_GucFrTpCopyRxDataCount == 0x01) && 
      (PduR_GddFrTpCopyRxDataPduId[0] == ExpRxPduId))
      {
        ActPduInfo.SduLength = PduR_GddFrTpCopyRxDataSduLength[0];
        ActPduInfo.SduDataPtr = &PduR_GaaFrTpCopyRxDataSduData[0];
        /* Validate SduLength and Data */
        if(PduRTest_ValidateData(ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
     }
     /* Reset API invocation Count after validating the API invocation */
     PduR_GucFrTpCopyRxDataCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucFrTpCopyRxDataCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < PduR_GucFrTpCopyRxDataCount; LucIndex++)
      {
        /* Validate the PduId */
        if((PduR_GddFrTpCopyRxDataPduId[LucIndex] == ExpRxPduId) && 
        (PduR_GddFrTpCopyRxDataSduLength[LucIndex] == ExpPduInfoPtr->SduLength))
        {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
          */
          LucIndex = PduR_GucFrTpCopyRxDataCount;
        } /* End if((PduR_GddFrTpRxIndPduId[LucIndex] == ExpRxPduId) &&  */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucFrTpCopyRxDataCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucFrTpCopyRxDataCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucFrTpCopyRxDataCheckCount == PduR_GucFrTpCopyRxDataCount)
      {
        PduR_GucFrTpCopyRxDataCount = 0;
        PduR_GucFrTpCopyRxDataCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestPduR_FrTpCopyRxData() */

/*******************************************************************************
**                       TestPduR_FrTpCopyRxDataSetVal()                     **
*******************************************************************************/
void TestPduR_FrTpCopyRxDataSetVal(BufReq_ReturnType RetVal, PduLengthType RxBufferSize)
{
  PduR_GddFrTpCopyRxDataRetVal = RetVal;

  PduR_GddFrTpCopyRxDataRxBuffer = RxBufferSize;
} /* End TestPduR_FrTpCopyRxDataSetVal() */

/*******************************************************************************
**                       PduR_FrTpCopyTxData()                               **
*******************************************************************************/
BufReq_ReturnType PduR_FrTpCopyTxData(PduIdType TxPduId, PduInfoType* PduInfoPtr, 
  RetryInfoType* RetryInfoPtr, PduLengthType* TxDataCntPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex=0;
  uint8 LucDataLength;
  uint8 *LpSduDataPtr;
  
  /* Load the address of SduDataPtr into Local Variable */
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  
  /* Load actual PduId, SduLength and RetryInfoPtr into Global variables */
  PduR_GddFrTpCopyTxDataPduId[PduR_GucFrTpCopyTxDataCount] = TxPduId;
  PduR_GddFrTpCopyTxDataSduLength[PduR_GucFrTpCopyTxDataCount] = (uint8) PduInfoPtr->SduLength;
  LucDataLength = (uint8) PduInfoPtr->SduLength;
  
  if(LucDataLength !=0)
  {
    if(RetryInfoPtr->TpDataState == TP_DATARETRY)
    {
     for(LucDataIndex=0; LucDataIndex < LucDataLength; LucDataIndex++)
      {
        *LpSduDataPtr = PduR_GaaFrTpCopyTxDataSduData[LucDataIndex];
        LpSduDataPtr++;
      }
      *TxDataCntPtr = PduR_GddFrTpCopyTxDataTxDataCnt;
      
      /* Increment count variable to handle multiple invocations */
      PduR_GucFrTpCopyTxDataCount++;
    }
    else
    {
      PduR_GddFrTpCopyTxDataRetryInfo[PduR_GucFrTpCopyTxDataCount].TpDataState = RetryInfoPtr->TpDataState;
      PduR_GddFrTpCopyTxDataRetryInfo[PduR_GucFrTpCopyTxDataCount].TxTpDataCnt = RetryInfoPtr->TxTpDataCnt;
      /* 
       * Load SduDataPtr with data of PduR_GaaFrTpCopyTxDataSduData and 
       * TxDataCntPtr with data of PduR_GddFrTpCopyTxDataTxDataCnt  
       */
       PduInfoPtr->SduDataPtr = &PduR_GaaFrTpCopyTxDataSduData[0];
      /* Load the SduDataPtr with the global array */
      for(LucDataIndex=0; LucDataIndex < LucDataLength; LucDataIndex++)
      {
        *LpSduDataPtr = PduR_GaaFrTpCopyTxDataSduData[LucDataIndex];
        LpSduDataPtr++;
      }
      *TxDataCntPtr = PduR_GddFrTpCopyTxDataTxDataCnt - LucDataLength;
      PduR_GddFrTpCopyTxDataTxDataCnt = PduR_GddFrTpCopyTxDataTxDataCnt - LucDataLength;
      /* Increment count variable to handle multiple invocations */
      PduR_GucFrTpCopyTxDataCount++;
      
      if((App_GucTestIndex == 3)  &&  (App_GddTestStepId == 2))
      {
        PduR_GddFrTpCopyTxDataTxDataCnt = 4;
      }
    }
  }
  else
  {
  
    /* Load actual PduId, SduLength and RetryInfoPtr into Global variables */
    PduR_GddFrTpCopyTxDataPduId[PduR_GucFrTpCopyTxDataCount] = TxPduId;
    PduR_GddFrTpCopyTxDataSduLength[PduR_GucFrTpCopyTxDataCount] =(uint8) PduInfoPtr->SduLength;
    PduInfoPtr->SduLength = PduR_GddFrTpCopyTxDataTxDataCnt;
    *TxDataCntPtr = PduR_GddFrTpCopyTxDataTxDataCnt;
    PduR_GucFrTpCopyTxDataCount++;
    PduR_GddFrTpCopyTxDataRetVal = BUFREQ_OK;
  } 

  #endif
  return(PduR_GddFrTpCopyTxDataRetVal);
} /* End PduR_FrTpCopyTxData() */

/*******************************************************************************
**                       TestPduR_FrTpCopyTxData()                           **
*******************************************************************************/
boolean TestPduR_FrTpCopyTxData(App_DataValidateType LucDataValidate, 
  PduIdType ExpTxPduId, PduInfoType* ExpPduInfoPtr, 
  RetryInfoType* ExpRetryInfoPtr, PduLengthType* ExpTxDataCntPtr)
{
  
  uint8 LucIndex;
  boolean LblRetValue;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, Id, SduLength and RetryInfoPtr */
      if((PduR_GucFrTpCopyTxDataCount == 0x01) && 
      (PduR_GddFrTpCopyTxDataPduId[0] == ExpTxPduId) && 
      (PduR_GddFrTpCopyTxDataSduLength[0] == ExpPduInfoPtr->SduLength))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucFrTpCopyTxDataCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucFrTpCopyTxDataCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
     /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
     /* Validate invocation count, Id, SduLength and RetryInfoPtr */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < PduR_GucFrTpCopyTxDataCount; LucIndex++)
      {
        /* Validate ControllerId and ControllerMode */
      if((PduR_GddFrTpCopyTxDataPduId[LucIndex] == ExpTxPduId) && 
      (PduR_GddFrTpCopyTxDataSduLength[LucIndex] == ExpPduInfoPtr->SduLength))
      {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = PduR_GucFrTpCopyTxDataCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucFrTpCopyTxDataCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucFrTpCopyTxDataCheckCount == PduR_GucFrTpCopyTxDataCount)
      {
        PduR_GucFrTpCopyTxDataCount = 0;
        PduR_GucFrTpCopyTxDataCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((PduR_GucFrTpCopyTxDataCheckCount <= PduR_GucFrTpCopyTxDataCount) &&
        (ExpTxPduId == PduR_GddFrTpCopyTxDataPduId[PduR_GucFrTpCopyTxDataCheckCount]) &&
        (ExpPduInfoPtr->SduLength == PduR_GddFrTpCopyTxDataSduLength[PduR_GucFrTpCopyTxDataCheckCount]))
      {
        LblRetValue = STEP_PASSED;
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucFrTpCopyTxDataCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucFrTpCopyTxDataCheckCount == PduR_GucFrTpCopyTxDataCount)
      {
        PduR_GucFrTpCopyTxDataCount = 0;
        PduR_GucFrTpCopyTxDataCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  UNUSED(ExpTxDataCntPtr);
  UNUSED(ExpRetryInfoPtr);
  return(LblRetValue);
} /* End TestPduR_FrTpCopyTxData() */

/*******************************************************************************
**                       TestPduR_FrTpCopyTxDataSetVal()                     **
*******************************************************************************/
void TestPduR_FrTpCopyTxDataSetVal(BufReq_ReturnType RetVal, uint8 *TxData,
  PduLengthType TxDataCnt)
{
  uint8 LucDataIndex;
  PduR_GddFrTpCopyTxDataRetVal = RetVal;
  for(LucDataIndex = 0x00; LucDataIndex < PDUR_DATA_LENGTH; LucDataIndex++)
  {
    PduR_GaaFrTpCopyTxDataSduData[LucDataIndex] = *TxData;
    TxData++;
  }
  PduR_GddFrTpCopyTxDataTxDataCnt = TxDataCnt;
} /* End TestPduR_FrTpCopyTxDataSetVal() */

#endif

#ifdef IPDUM_MODULE_ACTIVE
/*******************************************************************************
**                         PduR_IpduMTransmit()                               **
*******************************************************************************/
Std_ReturnType PduR_IpduMTransmit(PduIdType PduId, const PduInfoType* info)
{
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8* LpSduDataPtr;

  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  PduR_GucIpduMTxPduId = PduId;
  PduR_GucIpduMTxSduLength = info->SduLength;
  LpSduDataPtr = info->SduDataPtr;

  /* Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduR_GucIpduMTxSduLength > PDUR_DATA_LENGTH_IPDUM)
  {
    LucDataLength = PDUR_DATA_LENGTH_IPDUM;
  }
  else
  {
    LucDataLength = PduR_GucIpduMTxSduLength;
  }

  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    PduR_GucIpduMTxSduData[LucDataIndex] = *LpSduDataPtr;
    LpSduDataPtr++;
  }

  /* Increment count variable to handle multiple invocations */
  if(PduR_GucIpduMTxCount != PDUR_ARRAY_SIZE)
  {
    PduR_GucIpduMTxCount++;
  }
  return(PduR_GddIpduMTxRetVal);
} /* End PduR_IpduMTransmit()*/

/*******************************************************************************
**                       TestPduR_IpduMTransmit()                             **
*******************************************************************************/
boolean TestPduR_IpduMTransmit(App_DataValidateType LddDataValidate,
  PduIdType ExpPduId, const PduInfoType* ExpPduInfo)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((PduR_GucIpduMTxCount == 0x01) && (ExpPduId == PduR_GucIpduMTxPduId))
      {
        ActPduInfo.SduLength = PduR_GucIpduMTxSduLength;
        ActPduInfo.SduDataPtr = &PduR_GucIpduMTxSduData[0];

        /* Validate SduLength and Data */
        if(PduRTest_ValidateData((PduInfoType *)ExpPduInfo, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucIpduMTxCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucIpduMTxCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestPduR_IpduMTransmit() */

/*******************************************************************************
**                     TestSetPduR_IpduMTxRetVal()                            **
*******************************************************************************/
void TestSetPduR_IpduMTxRetVal(Std_ReturnType LddRetVal)
{
  PduR_GddIpduMTxRetVal = LddRetVal;
}/* End TestSetPduR_IpduMTxRetVal() */

/*******************************************************************************
**                         PduR_IpduMTriggerTransmit()                        **
*******************************************************************************/
Std_ReturnType PduR_IpduMTriggerTransmit (PduIdType TxPduId,
  PduInfoType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 *LpSduDataPtr;
  uint8 LucCount;
  uint8 LucSduLength = 0x00;

  boolean LblValue = FALSE;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  PduR_GucIpduMTrigTxPduId[PduR_GucIpduMTrigTxCount] = TxPduId;
  for(LucCount = 0x00;(LucCount < PDUR_ARRAY_SIZE) && (LblValue == FALSE);
    LucCount++)
  {
    if(TxPduId == PduR_GucIpduMTrigSetTxPduId[LucCount])
    {
      PduInfoPtr->SduLength = PduR_GucIpduMTrigSetTxSduLength[LucCount];
      while(LucSduLength < PduInfoPtr->SduLength)
      {
        *LpSduDataPtr =
          PduR_GucIpduMTrigSetTxSduData[LucCount][LucSduLength];
        LpSduDataPtr++;
        LucSduLength++;
      }
      PduR_GucIpduMTrigTxCount++;
      LblValue = TRUE;
    }
  }
  #endif
  return(PduR_GddIpduMTrigTxRetVal);
} /* End PduR_IpduMTriggerTransmit() */

/*******************************************************************************
**                       TestPduR_IpduMTriggerTransmit()                      **
*******************************************************************************/
boolean TestPduR_IpduMTriggerTransmit (App_DataValidateType LddDataValidate,
PduIdType ExpTxPduId)
{
  uint8 LucIndex;
  boolean LblRetValue;
  //ExpPduInfoPtr++;
  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
    */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((PduR_GucIpduMTrigTxCount == 0x01) &&
        (ExpTxPduId == PduR_GucIpduMTrigTxPduId[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucIpduMTrigTxCount = 0x00;
      PduR_GucPduRIpduMTrigTxCheckCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucIpduMTrigTxCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < PduR_GucIpduMTrigTxCount; LucIndex++)
      {
        /* Validate the PduId */
        if((ExpTxPduId == PduR_GucIpduMTrigTxPduId[LucIndex]))
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = PduR_GucIpduMTrigTxCount;
        } /* End if(ExpPduId == PduR_GucComActPduId[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucIpduMTrigTxCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucPduRIpduMTrigTxCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucPduRIpduMTrigTxCheckCount == PduR_GucIpduMTrigTxCount)
      {
        PduR_GucIpduMTrigTxCount = 0;
        PduR_GucPduRIpduMTrigTxCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with sequnce)
     * and to validate parameters of the API with what it has been invoked
     */

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;

      /* Loop through the global array and check for the expected ID */
      for(LucIndex = 0; (LucIndex < PduR_GucIpduMTrigTxCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpTxPduId == PduR_GucIpduMTrigTxPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}  /* End TestPduR_IpduMTriggerTransmit() */

/*******************************************************************************
**                     TestSetPduR_IpduMTrigTxVal()                           **
*******************************************************************************/
void TestSetPduR_IpduMTrigTxVal(uint8 ApiInvokeIndx, PduIdType TxPduId,
  PduInfoType *PduInfoPtr)
{
  uint8 LucSduLength = 0x00;
  uint8* LpSduDataPtr;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;

  PduR_GucIpduMTrigSetTxPduId[ApiInvokeIndx] = TxPduId;
  PduR_GucIpduMTrigSetTxSduLength[ApiInvokeIndx] = PduInfoPtr->SduLength;
  while(LucSduLength < PduR_GucIpduMTrigSetTxSduLength[ApiInvokeIndx])
  {
    PduR_GucIpduMTrigSetTxSduData[ApiInvokeIndx][LucSduLength] =
      *LpSduDataPtr;
    LpSduDataPtr++;
    LucSduLength++;
  }
}/* End TestSetPduR_IpduMTrigTxVal() */

/*******************************************************************************
**                         PduR_IpduMTxConfirmation()                         **
*******************************************************************************/
void PduR_IpduMTxConfirmation (PduIdType TxPduId)
{
  #ifndef TYPICAL_CONFIG
  PduR_GucIpduMTxConfPduId[PduR_GucIpduMTxConfCount] = TxPduId;
  PduR_GucIpduMTxConfCount++;
  #endif
} /* End PduR_IpduMTxConfirmation() */

/*******************************************************************************
**                       TestPduR_IpduMTxConfirmation()                       **
*******************************************************************************/
boolean TestPduR_IpduMTxConfirmation (App_DataValidateType LddDataValidate,
PduIdType ExpTxPduId)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    case S_VALIDATE:
    {
      if((PduR_GucIpduMTxConfCount == 0x01) &&
        (ExpTxPduId == PduR_GucIpduMTxConfPduId[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      PduR_GucIpduMTxConfCount = 0;
      break;
    } /* End case S_VALIDATE: */
    case S_NOT_INVOKED:
    {
      if(PduR_GucIpduMTxConfCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < PduR_GucIpduMTxConfCount; LucIndex++)
      {
        if(ExpTxPduId == PduR_GucIpduMTxConfPduId[LucIndex])
        {
          LblRetValue = STEP_PASSED;
          LucIndex = PduR_GucIpduMTxConfCount;
        } /* End if(ExpTxPduId == PduR_GucIpduMTxConfPduId[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucIpduMTxConfCount; ...) */
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucIpduMTxConfCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucIpduMTxConfCount == PduR_GucIpduMTxConfCheckCount)
      {
        PduR_GucIpduMTxConfCount = 0;
        PduR_GucIpduMTxConfCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < PduR_GucIpduMTxConfCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpTxPduId == PduR_GucIpduMTxConfPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestPduR_IpduMTxConfirmation() */

/*******************************************************************************
**                         PduR_IpduMRxIndication()                           **
*******************************************************************************/
void PduR_IpduMRxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8* LpSduDataPtr;

  PduR_GucIpduMRxIndPduId[PduR_GucIpduMRxIndCount] = RxPduId;
  PduR_GucIpduMRxIndSduLength[PduR_GucIpduMRxIndCount] = PduInfoPtr->SduLength;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;

  for(LucDataIndex = 0x00; LucDataIndex < PduInfoPtr->SduLength; LucDataIndex++)
  {
    PduR_GucIpduMRxIndSduData[PduR_GucIpduMRxIndCount][LucDataIndex] =
      *LpSduDataPtr;
    LpSduDataPtr++;
  }
  PduR_GucIpduMRxIndCount++;
  #endif
} /* End PduR_IpduMTransmit()*/

/*******************************************************************************
**                       TestPduR_IpduMRxIndication()                         **
*******************************************************************************/
boolean TestPduR_IpduMRxIndication(App_DataValidateType LddDataValidate,
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((PduR_GucIpduMRxIndCount == 0x01) &&
        (ExpRxPduId == PduR_GucIpduMRxIndPduId[0]))
      {
        ActPduInfo.SduLength = PduR_GucIpduMRxIndSduLength[0];
        ActPduInfo.SduDataPtr = &PduR_GucIpduMRxIndSduData[0][0];

        /* Validate SduLength and Data */
        if(PduRTest_ValidateData(ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucIpduMRxIndCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucIpduMRxIndCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < PduR_GucIpduMRxIndCount; LucIndex++)
      {
        if(ExpRxPduId == PduR_GucIpduMRxIndPduId[LucIndex])
        {
          ActPduInfo.SduLength = PduR_GucIpduMRxIndSduLength[LucIndex];
          ActPduInfo.SduDataPtr = &PduR_GucIpduMRxIndSduData[LucIndex][0];

          if(PduRTest_ValidateData((PduInfoType *)ExpPduInfoPtr, &ActPduInfo))
          {
            LblRetValue = STEP_PASSED;
          }
          LucIndex = PduR_GucIpduMRxIndCount;
        } /* End if(ExpRxPduId == PduR_GucIpduMRxIndPduId[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucIpduMRxIndCount; ...) */
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucIpduMRxIndCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucIpduMRxIndCount == PduR_GucIpduMRxIndCheckCount)
      {
        PduR_GucIpduMRxIndCount = 0;
        PduR_GucIpduMRxIndCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < PduR_GucIpduMRxIndCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpRxPduId == PduR_GucIpduMRxIndPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestPduR_IpduMRxIndication() */

#endif

/*******************************************************************************
**                       PduRTest_ValidateData()                             **
*******************************************************************************/
boolean PduRTest_ValidateData(PduInfoType* LddExpPduInfo, 
  PduInfoType* LddActPduInfo)
{
  uint8 *LpActualDataPtr;
  uint8 *LpExpDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  /* Load the ExpPduInfo to local variables */
  LddSduCount = LddExpPduInfo->SduLength;
  LpExpDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  /* Check the sdu length */
  if((LddExpPduInfo->SduLength <= PDUR_DATA_LENGTH) &&
    (LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }
   /* Check the sdu data */
  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    if(*LpActualDataPtr != *LpExpDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualDataPtr++;
    LpExpDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* End PduRTest_ValidateData() */

#ifdef COM_MODULE_ACTIVE
/*******************************************************************************
**                     TestSetPduR_ComTxRetVal()                              **
*******************************************************************************/
void TestSetPduR_ComTxRetVal(Std_ReturnType LddRetVal)
{
  PduR_GddComTxRetVal = LddRetVal;
}

/*******************************************************************************
**                     PduR_ComTransmit()                                     **
*******************************************************************************/
Std_ReturnType PduR_ComTransmit(PduIdType LddPduId,
  const PduInfoType* LddPduInfo)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8* LpSduDataPtr;

  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  PduR_GucComActPduId[PduR_GucComTxCount] = LddPduId;
  PduR_GucComActSduLength[PduR_GucComTxCount] = LddPduInfo->SduLength;
  LpSduDataPtr = LddPduInfo->SduDataPtr;

  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0; LucDataIndex < LddPduInfo->SduLength; LucDataIndex++)
  {
    PduR_GucComActSduData[PduR_GucComTxCount][LucDataIndex] = *LpSduDataPtr;
    LpSduDataPtr++;
  }

  /* Increment count variable to handle multiple invocations */
  if(PduR_GucComTxCount != PDUR_ARRAY_SIZE)
  {
    PduR_GucComTxCount++;
  }
  #endif
  return(PduR_GddComTxRetVal);
} /* End PduR_ComTransmit()*/

/*******************************************************************************
**                       TestPduR_ComTransmit()                               **
*******************************************************************************/
boolean TestPduR_ComTransmit(App_DataValidateType LucDataValidate,
  PduIdType ExpPduId, PduInfoType* ExpPduInfo)
{
  uint8 LucIndex;
  boolean LblRetValue;
  PduInfoType ActPduInfo;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((PduR_GucComTxCount == 0x01) && (ExpPduId == PduR_GucComActPduId[0]))
      {
        ActPduInfo.SduLength = PduR_GucComActSduLength[0];
        ActPduInfo.SduDataPtr = &PduR_GucComActSduData[0][0];

        /* Validate SduLength and Data */
        if(PduRTest_ValidateData(ExpPduInfo, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }

      /* Reset API invocation Count after validating the API invocation */
      PduR_GucComTxCount = 0;
      PduR_GucComTxCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucComTxCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < PduR_GucComTxCount; LucIndex++)
      {
        /* Validate the PduId */
        if(ExpPduId == PduR_GucComActPduId[LucIndex])
        {
          ActPduInfo.SduLength = PduR_GucComActSduLength[LucIndex];
          ActPduInfo.SduDataPtr = &PduR_GucComActSduData[LucIndex][0];

          /* Validate SduLength and Data */
          if(PduRTest_ValidateData(ExpPduInfo, &ActPduInfo))
          {
            LblRetValue = STEP_PASSED;
          }

          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = PduR_GucComTxCount;
        } /* End if(ExpPduId == PduR_GucComActPduId[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucComTxCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucComTxCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucComTxCheckCount == PduR_GucComTxCount)
      {
        PduR_GucComTxCount = 0;
        PduR_GucComTxCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;

      /* Loop through the global array and check for the expected ID */
      for(LucIndex = 0; (LucIndex < PduR_GucComTxCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpPduId == PduR_GucComActPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestPduR_ComTransmit() */
#endif
#ifdef FRIF_MODULE_ACTIVE
/*******************************************************************************
**                     PduR_FrIfTriggerTransmit()                             **
*******************************************************************************/
Std_ReturnType PduR_FrIfTriggerTransmit(PduIdType TxPduId,
  PduInfoType* PduInfoPtr)
{
    PduR_GucFrIfTxPduId = TxPduId;
    PduR_GucFrIfTriggerTransmit++;
    if(TxPduId == 0)
{
	PduInfoPtr->SduLength = 6;
	*(PduInfoPtr->SduDataPtr) =0x01;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x02;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x03;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x04;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x05;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x06;
	PduInfoPtr->SduDataPtr++;
}
if(TxPduId == 1)
{
	PduInfoPtr->SduLength = 7;
	
	*(PduInfoPtr->SduDataPtr) =0x07;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x08;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x09;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x0A;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x0B;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x0C;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x0D;
	PduInfoPtr->SduDataPtr++;

}
if((TxPduId == 2) || (TxPduId == 3))
{
	PduInfoPtr->SduLength = 8;
	
	*(PduInfoPtr->SduDataPtr) =0xFF;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x08;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x09;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x0A;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x0B;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x0C;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x0D;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0xFF;
	PduInfoPtr->SduDataPtr++;

}
if((TxPduId == 4) || (TxPduId == 5) || (TxPduId == 8) )
{
	PduInfoPtr->SduLength = 3;
	
	*(PduInfoPtr->SduDataPtr) =0x07;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x08;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x09;
	PduInfoPtr->SduDataPtr++;

}
if(TxPduId == 6)
{
	PduInfoPtr->SduLength = 5;
	
	*(PduInfoPtr->SduDataPtr) =0xFF;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x08;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x09;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x0A;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x0B;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x0C;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0x0D;
	PduInfoPtr->SduDataPtr++;
	*(PduInfoPtr->SduDataPtr) =0xFF;
	PduInfoPtr->SduDataPtr++;

}
if(TxPduId == 7)
{
 return(E_NOT_OK);
}
    return(E_OK);
  }
/*******************************************************************************
**                       TestPduR_FrIfTriggerTransmit()                       **
*******************************************************************************/
boolean TestPduR_FrIfTriggerTransmit(App_DataValidateType LucDataValidate,
PduIdType TxPduId)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((PduR_GucFrIfTriggerTransmit == 0x01) && 
        (PduR_GucFrIfTxPduId == TxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucFrIfTriggerTransmit = 0;      
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucFrIfTriggerTransmit == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}
/*******************************************************************************
**                     PduR_FrIfTxConfirmation()                              **
*******************************************************************************/
void PduR_FrIfTxConfirmation(PduIdType TxPduId)
{
    Pdu_PduR_GucFrIfTxPduId = TxPduId;
    Pdu_GucTxConfirmCount++;
}
/*******************************************************************************
**                       TestPduR_FrIfTxConfirmation()                        **
*******************************************************************************/
boolean TestPduR_FrIfTxConfirmation(App_DataValidateType LucDataValidate,
PduIdType TxPduId)
{
  boolean LblRetValue;
  UNUSED(TxPduId);
  LblRetValue = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Pdu_GucTxConfirmCount >= 0x01)
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Pdu_GucTxConfirmCount = 0;      
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Pdu_GucTxConfirmCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}
/*******************************************************************************
**                  TestPduR_FrIfRxIndication()                               **
*******************************************************************************/
boolean TestPduR_FrIfRxIndication(App_DataValidateType LddDataValidate, 
                                 PduIdType RxPduId, uint8 PduIength, 
                                 P2CONST(uint8,AUTOMATIC,FRIF_APPL_DATA)SduPtr)
{
  boolean LblStepResult;
  uint8 LucIndex;
  boolean LblRetValue = 0;
	
  LblStepResult = STEP_FAILED;
  PduR_GucIndex =0;
  switch(LddDataValidate)
  {

	
   /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      
	  for(LucIndex=0; LucIndex < PduIength ; LucIndex++, SduPtr++)
	  {
	    if(PduR_GaaSduData[LucIndex] != *SduPtr)
		{
		 LblRetValue =1;
         LucIndex = PduIength;
		}
	  }
	  /* Validate invocation count and Mode  */
     if((PduR_GucFrIfRxIndicationCount == 0x01)&& (PduR_GucFrIfRxPduId == RxPduId) 
       & (PduR_GulSduLength == PduIength) && (LblRetValue == 0))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      PduR_GucFrIfRxIndicationCount = 0;
      break;
    } /* End case S_VALIDATE: */
     /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucFrIfRxIndicationCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      PduR_GucFrIfRxIndicationCount = 0;
      break;
    } /* Case to handle API not invoked for single occurance */
    case M_VALIDATE:
    {
     for(LucIndex=0; LucIndex < PduIength ; LucIndex++, SduPtr++)
	  {
	    if(PduR_GaaSduData[LucIndex] != *SduPtr)
		{
		 LblRetValue =1;
         LucIndex = PduIength;
		}
	  }
	  /* Validate invocation count and Mode  */
     if((PduR_GucFrIfRxIndicationCount > 0x01)&& (PduR_GucFrIfRxPduId == RxPduId) 
         && (PduR_GulSduLength == PduIength) && (LblRetValue == 0))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      PduR_GucFrIfRxIndicationCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
    	
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End */
/*******************************************************************************
**                      PduR_FrIfRxIndication()                           **
*******************************************************************************/
void PduR_FrIfRxIndication(PduIdType RxPduId,
  PduInfoType* PduInfoPtr)
  {
  PduR_GucFrIfRxIndicationCount ++;
  uint8 LucIndex;
  PduR_GucFrIfRxPduId = RxPduId;
  PduR_GulSduLength   = PduInfoPtr->SduLength;
  for(LucIndex=0;LucIndex < PduR_GulSduLength; LucIndex++, 
                                PduInfoPtr->SduDataPtr++)
  {
	PduR_GaaSduData[PduR_GucIndex] = *(PduInfoPtr->SduDataPtr);
	PduR_GucIndex++;
  }
 }
  
  
#endif

#ifdef CANNM_MODULE_ACTIVE

/*******************************************************************************
**                      TestSetPduR_CanNmTriggerTransmit()                    **
*******************************************************************************/
void TestSetPduR_CanNmTriggerTransmit(PduInfoType* PduInfoPtr)
{
  uint8 LucCount;
  uint8* LpLocalSduPtr;

  LucCount = 0;
  LpLocalSduPtr = PduInfoPtr->SduDataPtr;

  PduR_GddCanNmTrigTxSduLength = PduInfoPtr->SduLength;
  while(LucCount < PduR_GddCanNmTrigTxSduLength)
  {
   PduR_GaaCanNmTrigTxData[LucCount] = *LpLocalSduPtr;
   LucCount++;
   LpLocalSduPtr++;
  }
} /* End TestSetPduR_CanNmTriggerTransmit() */

/*******************************************************************************
**                      PduR_CanNmTriggerTransmit()                           **
*******************************************************************************/
Std_ReturnType PduR_CanNmTriggerTransmit(PduIdType TxPduId,
PduInfoType* PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucCount;
  uint8* LpLocalSduPtr;

  LucCount = 0;
  LpLocalSduPtr = PduInfoPtr->SduDataPtr;

  PduR_GddCanNmCanTxPduId = TxPduId;
  PduInfoPtr->SduLength = PduR_GddCanNmTrigTxSduLength;
  while(LucCount < PduR_GddCanNmTrigTxSduLength)
  {
   *LpLocalSduPtr = PduR_GaaCanNmTrigTxData[LucCount];
   LucCount++;
   LpLocalSduPtr++;
  }
  PduR_GucCanNmTrigTxCount++;
  #endif /* TYPICAL_CONFIG */
  return(E_OK);
} /* End PduR_CanNmTriggerTransmit() */

/*******************************************************************************
**                     TestPduR_CanNmTriggerTransmit()                        **
*******************************************************************************/
boolean TestPduR_CanNmTriggerTransmit (App_DataValidateType LucDataValidate,
PduIdType ExpCanTxPduId, PduInfoType* ExpPduInfoPtr)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    case S_VALIDATE:
    {
      /* Validate the channel handle and states */
      if((PduR_GucCanNmTrigTxCount == 0x01) &&
      (PduR_GddCanNmCanTxPduId == ExpCanTxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API Invocation Count to Zero */
      PduR_GucCanNmTrigTxCount = 0;
      ExpPduInfoPtr++;
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestPduR_CanNmTriggerTransmit() */

/*******************************************************************************
**                         PduR_CanNmTxConfirmation()                         **
*******************************************************************************/
void PduR_CanNmTxConfirmation(PduIdType TxPduId)
{
  #ifndef TYPICAL_CONFIG
  PduR_GddCanNmCanTxPduId = TxPduId;
  PduR_GucCanNmTxConfirmCount++;
  #endif
} /* End PduR_CanNmTxConfirmation() */

/*******************************************************************************
**                      TestPduR_CanNmTxConfirmation()                        **
*******************************************************************************/
boolean TestPduR_CanNmTxConfirmation(App_DataValidateType LucDataValidate,
  PduIdType ExpCanTxPduId)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    case S_VALIDATE:
    {
      /* Validate the channel handle and states */
      if((PduR_GucCanNmTxConfirmCount == 0x01)
        && (PduR_GddCanNmCanTxPduId == ExpCanTxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API Invocation Count to Zero */
      PduR_GucCanNmTxConfirmCount= 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucCanNmTrigTxCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestPduR_CanNmTxConfirmation() */

/*******************************************************************************
**                       PduR_CanNmRxIndication()                             **
*******************************************************************************/
void PduR_CanNmRxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8* LpSduDataPtr;

  /* Load actual TxPduId  Sdulength and SduDataPt into Global variables */
  PduR_GucCanNmRxIndiCount++;
  PduR_GucCanNmRxPduId = RxPduId;

  PduR_GucCanNmRxIndSduLength = PduInfoPtr->SduLength;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;

  for(LucDataIndex = 0x00; LucDataIndex < PduInfoPtr->SduLength; LucDataIndex++)
  {
    PduR_GaaCanNmRxIndSduData[LucDataIndex] = *LpSduDataPtr;
    LpSduDataPtr++;
  }
  #endif
}
/* End of PduR_CanNmRxIndication() */

/*******************************************************************************
**                   TestPduR_CanNmRxIndication()                             **
*******************************************************************************/
boolean TestPduR_CanNmRxIndication(App_DataValidateType LddDataValidate,
PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType LstActPduInfo;
  uint8 LucPdurCnt;
  
  LucPdurCnt = PduR_GucCanNmRxIndiCount;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if(((PduR_GucCanNmRxIndiCount == 0x01))&&
        (PduR_GucCanNmRxPduId == ExpRxPduId))
      {
        LstActPduInfo.SduLength = PduR_GucCanNmRxIndSduLength;
        LstActPduInfo.SduDataPtr = &PduR_GaaCanNmRxIndSduData[0];

        /* Validate SduLength and Data */
        if(PduRTest_ValidateData((PduInfoType *)ExpPduInfoPtr,
          &LstActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucCanNmRxIndiCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucCanNmRxIndiCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
     /* Case to handle API invoked for single occurance */
    case M_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((PduR_GucCanNmRxIndiCount == 0x02)&&
        (PduR_GucCanNmRxPduId == ExpRxPduId))
      {
        LstActPduInfo.SduLength = PduR_GucCanNmRxIndSduLength;
        LstActPduInfo.SduDataPtr = &PduR_GaaCanNmRxIndSduData[0];

        /* Validate SduLength and Data */
        if(PduRTest_ValidateData((PduInfoType *)ExpPduInfoPtr,
          &LstActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucCanNmRxIndiCount = 0;
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End of TestPduR_CanNmRxIndication() */

#endif

#ifdef FRNM_MODULE_ACTIVE

/*******************************************************************************
**                      TestSetPduR_FrNmTriggerTransmit()                    **
*******************************************************************************/
void TestSetPduR_FrNmTriggerTransmit(PduInfoType* PduInfoPtr)
{
  uint8 LucCount;
  uint8* LpLocalSduPtr;

  LucCount = 0;
  LpLocalSduPtr = PduInfoPtr->SduDataPtr;

  PduR_GddFrNmTrigTxSduLength = PduInfoPtr->SduLength;
  while(LucCount < PduR_GddFrNmTrigTxSduLength)
  {
   PduR_GaaFrNmTrigTxData[LucCount] = *LpLocalSduPtr;
   LucCount++;
   LpLocalSduPtr++;
  }
} /* End TestSetPduR_FrNmTriggerTransmit() */

/*******************************************************************************
**                      PduR_FrNmTriggerTransmit()                           **
*******************************************************************************/
Std_ReturnType PduR_FrNmTriggerTransmit(PduIdType TxPduId,
PduInfoType* PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucCount;
  uint8* LpLocalSduPtr;

  LucCount = 0;
  LpLocalSduPtr = PduInfoPtr->SduDataPtr;

  PduR_GddFrNmCanTxPduId = TxPduId;
  PduInfoPtr->SduLength = PduR_GddFrNmTrigTxSduLength;
  while(LucCount < PduR_GddFrNmTrigTxSduLength)
  {
   *LpLocalSduPtr = PduR_GaaFrNmTrigTxData[LucCount];
   LucCount++;
   LpLocalSduPtr++;
  }
  PduR_GucFrNmTrigTxCount++;
  #endif /* TYPICAL_CONFIG */
  return(E_OK);
} /* End PduR_FrNmTriggerTransmit() */

/*******************************************************************************
**                     TestPduR_FrNmTriggerTransmit()                        **
*******************************************************************************/
boolean TestPduR_FrNmTriggerTransmit (App_DataValidateType LucDataValidate,
PduIdType ExpCanTxPduId, PduInfoType* ExpPduInfoPtr)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    case S_VALIDATE:
    {
      /* Validate the channel handle and states */
      if((PduR_GucFrNmTrigTxCount == 0x01) &&
      (PduR_GddFrNmCanTxPduId == ExpCanTxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API Invocation Count to Zero */
      PduR_GucFrNmTrigTxCount = 0;
      ExpPduInfoPtr++;
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestPduR_FrNmTriggerTransmit() */

/*******************************************************************************
**                         PduR_FrNmTxConfirmation()                         **
*******************************************************************************/
void PduR_FrNmTxConfirmation(PduIdType TxPduId)
{
  #ifndef TYPICAL_CONFIG
  PduR_GddFrNmCanTxPduId = TxPduId;
  PduR_GucFrNmTxConfirmCount++;
  #endif
} /* End PduR_FrNmTxConfirmation() */

/*******************************************************************************
**                      TestPduR_FrNmTxConfirmation()                        **
*******************************************************************************/
boolean TestPduR_FrNmTxConfirmation(App_DataValidateType LucDataValidate,
  PduIdType ExpCanTxPduId)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    case S_VALIDATE:
    {
      /* Validate the channel handle and states */
      if((PduR_GucFrNmTxConfirmCount == 0x01)
        && (PduR_GddFrNmCanTxPduId == ExpCanTxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API Invocation Count to Zero */
      PduR_GucFrNmTxConfirmCount= 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucFrNmTrigTxCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestPduR_FrNmTxConfirmation() */

/*******************************************************************************
**                       PduR_FrNmRxIndication()                             **
*******************************************************************************/
void PduR_FrNmRxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8* LpSduDataPtr;

  /* Load actual TxPduId  Sdulength and SduDataPt into Global variables */
  PduR_GucFrNmRxIndiCount++;
  PduR_GucFrNmRxPduId = RxPduId;

  PduR_GucFrNmRxIndSduLength = PduInfoPtr->SduLength;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;

  for(LucDataIndex = 0x00; LucDataIndex < PduInfoPtr->SduLength; LucDataIndex++)
  {
    PduR_GaaFrNmRxIndSduData[LucDataIndex] = *LpSduDataPtr;
    LpSduDataPtr++;
  }
  #endif
}
/* End of PduR_FrNmRxIndication() */

/*******************************************************************************
**                   TestPduR_FrNmRxIndication()                             **
*******************************************************************************/
boolean TestPduR_FrNmRxIndication(App_DataValidateType LddDataValidate,
PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType LstActPduInfo;
  uint8 LucPdurCnt;
  
  LucPdurCnt = PduR_GucFrNmRxIndiCount;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if(((PduR_GucFrNmRxIndiCount == 0x01))&&
        (PduR_GucFrNmRxPduId == ExpRxPduId))
      {
        LstActPduInfo.SduLength = PduR_GucFrNmRxIndSduLength;
        LstActPduInfo.SduDataPtr = &PduR_GaaFrNmRxIndSduData[0];

        /* Validate SduLength and Data */
        if(PduRTest_ValidateData((PduInfoType *)ExpPduInfoPtr,
          &LstActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucFrNmRxIndiCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucFrNmRxIndiCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
     /* Case to handle API invoked for single occurance */
    case M_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((PduR_GucFrNmRxIndiCount == 0x02)&&
        (PduR_GucFrNmRxPduId == ExpRxPduId))
      {
        LstActPduInfo.SduLength = PduR_GucFrNmRxIndSduLength;
        LstActPduInfo.SduDataPtr = &PduR_GaaFrNmRxIndSduData[0];

        /* Validate SduLength and Data */
        if(PduRTest_ValidateData((PduInfoType *)ExpPduInfoPtr,
          &LstActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucFrNmRxIndiCount = 0;
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End of TestPduR_FrNmRxIndication() */

#endif

#ifdef CANIF_MODULE_ACTIVE
/*******************************************************************************
**                     PduR_CanIfTxConfirmation()                             **
*******************************************************************************/
void PduR_CanIfTxConfirmation(PduIdType TxPduId)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual TxPduId into Global variables */
  PduR_GucCanIfTxPduId = TxPduId;
  PduR_GucCanIfTxConfirmCount++;
  #endif
} /* End of PduR_CanIfTxConfirmation() */

/*******************************************************************************
**                     TestPduR_CanIfTxConfirmation()                         **
*******************************************************************************/
boolean TestPduR_CanIfTxConfirmation(App_DataValidateType LddDataValidate,
PduIdType ExpTxPduId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TxPduId */
      if((PduR_GucCanIfTxConfirmCount == 0x01) &&
       (PduR_GucCanIfTxPduId == ExpTxPduId))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      PduR_GucCanIfTxConfirmCount = 0;
      PduR_GucCanIfTxConfirmCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < PduR_GucCanIfTxConfirmCount; LucIndex++)
      {
        /* Validate TxPduId */
        if(PduR_GucCanIfTxPduId == ExpTxPduId)

        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = PduR_GucCanIfTxConfirmCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucCanIfTxConfirmCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucCanIfTxConfirmCheckCount == PduR_GucCanIfTxConfirmCount)
      {
        PduR_GucCanIfTxConfirmCount = 0;
        PduR_GucCanIfTxConfirmCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucCanIfTxConfirmCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestPduR_CanIfTxConfirmation() */

/*******************************************************************************
**                       PduR_CanIfRxIndication()                             **
*******************************************************************************/
void PduR_CanIfRxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8* LpSduDataPtr;

  /* Load actual TxPduId  Sdulength and SduDataPt into Global variables */
  PduR_GucCanIfRxIndiCount++;
  PduR_GucCanIfRxPduId = RxPduId;

  PduR_GucCanIfRxIndSduLength = PduInfoPtr->SduLength;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;

  for(LucDataIndex = 0x00; LucDataIndex < PduInfoPtr->SduLength; LucDataIndex++)
  {
    PduR_GaaCanIfRxIndSduData[LucDataIndex] = *LpSduDataPtr;
    LpSduDataPtr++;
  }
  #endif
}
/* End of PduR_CanIfRxIndication() */

/*******************************************************************************
**                   TestPduR_CanIfRxIndication()                             **
*******************************************************************************/
boolean TestPduR_CanIfRxIndication(App_DataValidateType LddDataValidate,
PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType LstActPduInfo;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((PduR_GucCanIfRxIndiCount == 0x01) &&
        (PduR_GucCanIfRxPduId == ExpRxPduId))
      {
        LstActPduInfo.SduLength = PduR_GucCanIfRxIndSduLength;
        LstActPduInfo.SduDataPtr = &PduR_GaaCanIfRxIndSduData[0];

        /* Validate SduLength and Data */
        if(PduRTest_ValidateData((PduInfoType *)ExpPduInfoPtr,
          &LstActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucCanIfRxIndiCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucCanIfRxIndiCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End of TestPduR_CanIfRxIndication() */
#endif

#ifdef CANTP_MODULE_ACTIVE
/*******************************************************************************
**                       PduR_CanTpRxIndication()                             **
*******************************************************************************/
void PduR_CanTpRxIndication(PduIdType RxPduId, NotifResultType Result)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual PduId and result into Global variables */
  PduR_GddCanTpRxIndPduId[PduR_GucCanTpRxIndCount] = RxPduId;
  PduR_GddCanTpRxIndResult[PduR_GucCanTpRxIndCount] = Result;
  /* Increment count variable to handle multiple invocations */
  PduR_GucCanTpRxIndCount++;
  #endif
} /* End PduR_CanTpRxIndication() */

/*******************************************************************************
**                       TestPduR_CanTpRxIndication()                         **
*******************************************************************************/
boolean TestPduR_CanTpRxIndication(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, NotifResultType ExpResult)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, RxPduId and Result */
      if((PduR_GucCanTpRxIndCount == 0x01) &&
        (PduR_GddCanTpRxIndPduId[0] == ExpRxPduId) && 
        (PduR_GddCanTpRxIndResult[0] == ExpResult))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucCanTpRxIndCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucCanTpRxIndCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < PduR_GucCanTpRxIndCount; LucIndex++)
      {
        /* Validate the PduId */
        if((PduR_GddCanTpRxIndPduId[LucIndex] == ExpRxPduId) && 
        (PduR_GddCanTpRxIndResult[LucIndex] == ExpResult))
        {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
          */
          LucIndex = PduR_GucCanTpRxIndCount;
        } /* End if((PduR_GddCanTpRxIndPduId[LucIndex] == ExpRxPduId) &&  */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucCanTpRxIndCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucCanTpRxIndCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucCanTpRxIndCheckCount == PduR_GucCanTpRxIndCount)
      {
        PduR_GucCanTpRxIndCount = 0;
        PduR_GucCanTpRxIndCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);

} /* End TestPduR_CanTpRxIndication() */
/*******************************************************************************
**                       PduR_CanTpTxConfirmation()                           **
*******************************************************************************/
void PduR_CanTpTxConfirmation(PduIdType TxPduId, NotifResultType Result)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual PduId and result into Global variables */
  PduR_GddCanTpTxConfPduId = TxPduId;
  PduR_GddCanTpTxConfResult = Result;
  /* Increment count variable to handle multiple invocations */
  PduR_GucCanTpTxConfCount++;
  #endif
} /* End PduR_CanTpTxConfirmation() */

/*******************************************************************************
**                       TestPduR_CanTpTxConfirmation()                       **
*******************************************************************************/
boolean TestPduR_CanTpTxConfirmation(App_DataValidateType LucDataValidate, 
  PduIdType ExpTxPduId, NotifResultType ExpResult)
{
  boolean LblRetValue;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count and Id */
      if((PduR_GucCanTpTxConfCount == 0x01) && (ExpTxPduId == PduR_GddCanTpTxConfPduId) && 
        (PduR_GddCanTpTxConfResult == ExpResult))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucCanTpTxConfCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucCanTpTxConfCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);

} /* End TestPduR_CanTpTxConfirmation() */

/*******************************************************************************
**                       PduR_CanTpStartOfReception()                         **
*******************************************************************************/
BufReq_ReturnType PduR_CanTpStartOfReception(PduIdType RxPduId, 
  PduLengthType TpSduLength, PduLengthType *RxBufferSizePtr)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual PduId, TpSduLength into Global variables */
  PduR_GddCanTpSorPduId[PduR_GucCanTpSorCount] = RxPduId;
  PduR_GddCanTpSorTpSduLength[PduR_GucCanTpSorCount] = TpSduLength;
  /* Load RxBufferSizePtr with data of PduR_GddCanTpSorRxBuffer  */
  *RxBufferSizePtr = PduR_GddCanTpSorRxBuffer;
  /* Increment count variable to handle multiple invocations */
  PduR_GucCanTpSorCount++;
  #endif
  return(PduR_GddCanTpSorRetVal);
} /* End PduR_CanTpStartOfReception() */

/*******************************************************************************
**                       TestPduR_CanTpStartOfReception()                     **
*******************************************************************************/
boolean TestPduR_CanTpStartOfReception(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, PduLengthType ExpTpSduLength, 
  PduLengthType *RxBufferSizePtr)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, Id and TpSduLength */
      if((PduR_GucCanTpSorCount == 0x01) && 
      (PduR_GddCanTpSorPduId[0] == ExpRxPduId) && 
      (PduR_GddCanTpSorTpSduLength[0] == ExpTpSduLength))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucCanTpSorCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucCanTpSorCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < PduR_GucCanTpSorCount; LucIndex++)
      {
        /* Validate the PduId */
        if((PduR_GddCanTpSorPduId[LucIndex] == ExpRxPduId) && 
        (PduR_GddCanTpSorTpSduLength[LucIndex] == ExpTpSduLength))
        {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
          */
          LucIndex = PduR_GucCanTpSorCount;
        } /* End if((PduR_GddCanTpRxIndPduId[LucIndex] == ExpRxPduId) &&  */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucCanTpSorCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucCanTpSorCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucCanTpSorCheckCount == PduR_GucCanTpSorCount)
      {
        PduR_GucCanTpSorCount = 0;
        PduR_GucCanTpSorCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  RxBufferSizePtr++;
  return(LblRetValue);
} /* End TestPduR_CanTpStartOfReception() */

/*******************************************************************************
**                       TestPduR_CanTpStartOfReceptionSetVal()               **
*******************************************************************************/
void TestPduR_CanTpStartOfReceptionSetVal(BufReq_ReturnType RetVal, 
  PduLengthType RxBufferSize)
{
  PduR_GddCanTpSorRetVal = RetVal;
  PduR_GddCanTpSorRxBuffer = RxBufferSize;
} /* End TestPduR_CanTpStartOfReceptionSetVal() */

/*******************************************************************************
**                       PduR_CanTpCopyRxData()                               **
*******************************************************************************/
BufReq_ReturnType PduR_CanTpCopyRxData(PduIdType RxPduId,
  PduInfoType *PduInfoPtr, PduLengthType *RxBufferSizePtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8 *LpSduDataPtr;
  /* Load the address of SduDataPtr into Local Variable */
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  
  /* Load actual PduId, SduLength into Global variables */
  PduR_GddCanTpCopyRxDataPduId[PduR_GucCanTpCopyRxDataCount] = RxPduId;
  PduR_GddCanTpCopyRxDataSduLength[PduR_GucCanTpCopyRxDataCount] = PduInfoPtr->SduLength;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > PDUR_DATA_LENGTH)
  {
    LucDataLength = PDUR_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->SduLength;
  }
  /* 
   * Load PduR_GaaCanTpCopyRxDataSduData with SduDataPtr and RxBufferSizePtr 
   * with data of PduR_GddCanTpCopyRxDataRxBuffer  
   */
  /* Load the SduDataPtr with the global array */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    PduR_GaaCanTpCopyRxDataSduData[LucDataIndex] = *LpSduDataPtr;
    LpSduDataPtr++;
  }
  *RxBufferSizePtr = PduR_GddCanTpCopyRxDataRxBuffer;
  /* Increment count variable to handle multiple invocations */
  PduR_GucCanTpCopyRxDataCount++;
  #endif
  return(PduR_GddCanTpCopyRxDataRetVal);
} /* End PduR_CanTpCopyRxData() */

/*******************************************************************************
**                       TestPduR_CanTpCopyRxData()                           **
*******************************************************************************/
boolean TestPduR_CanTpCopyRxData(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr, 
   PduLengthType *ExpRxBufferSizePtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, Id and SduLength */
      if((PduR_GucCanTpCopyRxDataCount == 0x01) && 
      (PduR_GddCanTpCopyRxDataPduId[0] == ExpRxPduId))
      {
        ActPduInfo.SduLength = PduR_GddCanTpCopyRxDataSduLength[0];
        ActPduInfo.SduDataPtr = &PduR_GaaCanTpCopyRxDataSduData[0];
        /* Validate SduLength and Data */
        if(PduRTest_ValidateData(ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
     }
     /* Reset API invocation Count after validating the API invocation */
     PduR_GucCanTpCopyRxDataCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucCanTpCopyRxDataCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < PduR_GucCanTpCopyRxDataCount; LucIndex++)
      {
        /* Validate the PduId */
        if((PduR_GddCanTpCopyRxDataPduId[LucIndex] == ExpRxPduId) && 
        (PduR_GddCanTpCopyRxDataSduLength[LucIndex] == ExpPduInfoPtr->SduLength))
        {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
          */
          LucIndex = PduR_GucCanTpCopyRxDataCount;
        } /* End if((PduR_GddCanTpRxIndPduId[LucIndex] == ExpRxPduId) &&  */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucCanTpCopyRxDataCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucCanTpCopyRxDataCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucCanTpCopyRxDataCheckCount == PduR_GucCanTpCopyRxDataCount)
      {
        PduR_GucCanTpCopyRxDataCount = 0;
        PduR_GucCanTpCopyRxDataCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  ExpRxBufferSizePtr++;
  return(LblRetValue);
} /* End TestPduR_CanTpCopyRxData() */

/*******************************************************************************
**                       TestPduR_CanTpCopyRxDataSetVal()                     **
*******************************************************************************/
void TestPduR_CanTpCopyRxDataSetVal(BufReq_ReturnType RetVal, PduLengthType RxBufferSize)
{
  PduR_GddCanTpCopyRxDataRetVal = RetVal;

  PduR_GddCanTpCopyRxDataRxBuffer = RxBufferSize;
} /* End TestPduR_CanTpCopyRxDataSetVal() */

/*******************************************************************************
**                       PduR_CanTpCopyTxData()                               **
*******************************************************************************/
BufReq_ReturnType PduR_CanTpCopyTxData(PduIdType TxPduId, PduInfoType* PduInfoPtr, 
  RetryInfoType* RetryInfoPtr, PduLengthType* TxDataCntPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8 *LpSduDataPtr;
  
  /* Load the address of SduDataPtr into Local Variable */
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  
  /* Load actual PduId, SduLength and RetryInfoPtr into Global variables */
  PduR_GddCanTpCopyTxDataPduId[PduR_GucCanTpCopyTxDataCount] = TxPduId;
  PduR_GddCanTpCopyTxDataSduLength[PduR_GucCanTpCopyTxDataCount] = PduInfoPtr->SduLength;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > PDUR_DATA_LENGTH)
  {
    LucDataLength = PDUR_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->SduLength;
  }
  PduR_GddCanTpCopyTxDataRetryInfo[PduR_GucCanTpCopyTxDataCount].TpDataState = RetryInfoPtr->TpDataState;
  PduR_GddCanTpCopyTxDataRetryInfo[PduR_GucCanTpCopyTxDataCount].TxTpDataCnt = RetryInfoPtr->TxTpDataCnt;
  /* 
   * Load SduDataPtr with data of PduR_GaaCanTpCopyTxDataSduData and 
   * TxDataCntPtr with data of PduR_GddCanTpCopyTxDataTxDataCnt  
   */
  /* Load the SduDataPtr with the global array */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    *LpSduDataPtr = PduR_GaaCanTpCopyTxDataSduData[LucDataIndex];
    LpSduDataPtr++;
  }
  *TxDataCntPtr = PduR_GddCanTpCopyTxDataTxDataCnt;
  /* Increment count variable to handle multiple invocations */
  PduR_GucCanTpCopyTxDataCount++;
  
  if((App_GucTestIndex == 3)  &&  (App_GddTestStepId == 2))
  {
    PduR_GddCanTpCopyTxDataTxDataCnt = 4;
  }
  #endif
  return(PduR_GddCanTpCopyTxDataRetVal);
} /* End PduR_CanTpCopyTxData() */

/*******************************************************************************
**                       TestPduR_CanTpCopyTxData()                           **
*******************************************************************************/
boolean TestPduR_CanTpCopyTxData(App_DataValidateType LucDataValidate, 
  PduIdType ExpTxPduId, PduInfoType* ExpPduInfoPtr, 
  RetryInfoType* ExpRetryInfoPtr, PduLengthType* ExpTxDataCntPtr)
{
  
  uint8 LucIndex;
  boolean LblRetValue;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, Id, SduLength and RetryInfoPtr */
      if((PduR_GucCanTpCopyTxDataCount == 0x01) && 
      (PduR_GddCanTpCopyTxDataPduId[0] == ExpTxPduId) && 
      (PduR_GddCanTpCopyTxDataSduLength[0] == ExpPduInfoPtr->SduLength) &&
      (PduR_GddCanTpCopyTxDataRetryInfo[0].TpDataState == ExpRetryInfoPtr->TpDataState) && 
      (PduR_GddCanTpCopyTxDataRetryInfo[0].TxTpDataCnt == ExpRetryInfoPtr->TxTpDataCnt))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucCanTpCopyTxDataCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucCanTpCopyTxDataCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
     /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
     /* Validate invocation count, Id, SduLength and RetryInfoPtr */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < PduR_GucCanTpCopyTxDataCount; LucIndex++)
      {
        /* Validate ControllerId and ControllerMode */
      if((PduR_GddCanTpCopyTxDataPduId[LucIndex] == ExpTxPduId) && 
      (PduR_GddCanTpCopyTxDataSduLength[LucIndex] == ExpPduInfoPtr->SduLength) &&
      (PduR_GddCanTpCopyTxDataRetryInfo[LucIndex].TpDataState == ExpRetryInfoPtr->TpDataState) && 
      (PduR_GddCanTpCopyTxDataRetryInfo[LucIndex].TxTpDataCnt == ExpRetryInfoPtr->TxTpDataCnt))
      {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = PduR_GucCanTpCopyTxDataCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucCanTpCopyTxDataCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucCanTpCopyTxDataCheckCount == PduR_GucCanTpCopyTxDataCount)
      {
        PduR_GucCanTpCopyTxDataCount = 0;
        PduR_GucCanTpCopyTxDataCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  ExpTxDataCntPtr++;
  return(LblRetValue);
} /* End TestPduR_CanTpCopyTxData() */

/*******************************************************************************
**                       TestPduR_CanTpCopyTxDataSetVal()                     **
*******************************************************************************/
void TestPduR_CanTpCopyTxDataSetVal(BufReq_ReturnType RetVal, uint8 *TxData,
  PduLengthType TxDataCnt)
{
  uint8 LucDataIndex;
  PduR_GddCanTpCopyTxDataRetVal = RetVal;
  for(LucDataIndex = 0x00; LucDataIndex < PDUR_DATA_LENGTH; LucDataIndex++)
  {
    PduR_GaaCanTpCopyTxDataSduData[LucDataIndex] = *TxData;
    TxData++;
  }
  PduR_GddCanTpCopyTxDataTxDataCnt = TxDataCnt;
} /* End TestPduR_CanTpCopyTxDataSetVal() */

#endif

#ifdef CANTP_MODULE_ACTIVE
/*******************************************************************************
**                       PduR_CanTpChangeParameterConfirmation()              **
*******************************************************************************/
void PduR_CanTpChangeParameterConfirmation(PduIdType id, NotifResultType result)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual PduId and result into Global variables */
  PduR_GddCanTpChngeParConfPduId[PduR_GucCanTpChngeParConfCount] = id;
  PduR_GddCanTpChngeParConfResult[PduR_GucCanTpChngeParConfCount] = result;
  /* Increment count variable to handle multiple invocations */
  PduR_GucCanTpChngeParConfCount++;
  #endif
} /* End PduR_CanTpChangeParameterConfirmation() */


/*******************************************************************************
**            TestPduR_CanTpChangeParameterConfirmation()                     **
*******************************************************************************/
boolean TestPduR_CanTpChangeParameterConfirmation(App_DataValidateType 
LucDataValidate, PduIdType ExpRxPduId, NotifResultType ExpResult)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, RxPduId and Result */
      if((PduR_GucCanTpChngeParConfCount == 0x01) &&
        (PduR_GddCanTpChngeParConfPduId[0] == ExpRxPduId) && 
        (PduR_GddCanTpChngeParConfResult[0] == ExpResult))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucCanTpChngeParConfCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucCanTpChngeParConfCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < PduR_GucCanTpChngeParConfCount; LucIndex++)
      {
        /* Validate the PduId */
        if((PduR_GddCanTpChngeParConfPduId[LucIndex] == ExpRxPduId) && 
        (PduR_GddCanTpChngeParConfResult[LucIndex] == ExpResult))
        {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
          */
          LucIndex = PduR_GucCanTpChngeParConfCount;
        } /* End if((PduR_GddCanTpChngeParConfPduId[LucIndex] == ExpRxPduId) &&  */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucCanTpChngeParConfCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucCanTpChngeParConfCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucCanTpChngeParConfCheckCount == PduR_GucCanTpChngeParConfCount)
      {
        PduR_GucCanTpChngeParConfCount = 0;
        PduR_GucCanTpChngeParConfCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);  
}
#endif

#ifdef J1939TP_MODULE_ACTIVE
/*******************************************************************************
**                       PduR_J1939TpRxIndication()                             **
*******************************************************************************/
void PduR_J1939TpRxIndication(PduIdType RxPduId, NotifResultType Result)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual PduId and result into Global variables */
  PduR_GddJ1939TpRxIndPduId[PduR_GucJ1939TpRxIndCount] = RxPduId;
  PduR_GddJ1939TpRxIndResult[PduR_GucJ1939TpRxIndCount] = Result;
  /* Increment count variable to handle multiple invocations */
  PduR_GucJ1939TpRxIndCount++;
  #endif
} /* End PduR_J1939TpRxIndication() */

/*******************************************************************************
**                       TestPduR_J1939TpRxIndication()                         **
*******************************************************************************/
boolean TestPduR_J1939TpRxIndication(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, NotifResultType ExpResult)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, RxPduId and Result */
      if((PduR_GucJ1939TpRxIndCount == 0x01) &&
        (PduR_GddJ1939TpRxIndPduId[0] == ExpRxPduId) && 
        (PduR_GddJ1939TpRxIndResult[0] == ExpResult))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucJ1939TpRxIndCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucJ1939TpRxIndCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < PduR_GucJ1939TpRxIndCount; LucIndex++)
      {
        /* Validate the PduId */
        if((PduR_GddJ1939TpRxIndPduId[LucIndex] == ExpRxPduId) && 
        (PduR_GddJ1939TpRxIndResult[LucIndex] == ExpResult))
        {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
          */
          LucIndex = PduR_GucJ1939TpRxIndCount;
        } /* End if((PduR_GddJ1939TpRxIndPduId[LucIndex] == ExpRxPduId) &&  */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucJ1939TpRxIndCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucJ1939TpRxIndCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucJ1939TpRxIndCheckCount == PduR_GucJ1939TpRxIndCount)
      {
        PduR_GucJ1939TpRxIndCount = 0;
        PduR_GucJ1939TpRxIndCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);

} /* End TestPduR_J1939TpRxIndication() */
/*******************************************************************************
**                       PduR_J1939TpTxConfirmation()                           **
*******************************************************************************/
void PduR_J1939TpTxConfirmation(PduIdType TxPduId, NotifResultType Result)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual PduId and result into Global variables */
  PduR_GddJ1939TpTxConfPduId = TxPduId;
  PduR_GddJ1939TpTxConfResult = Result;
  /* Increment count variable to handle multiple invocations */
  PduR_GucJ1939TpTxConfCount++;
  #endif
} /* End PduR_J1939TpTxConfirmation() */

/*******************************************************************************
**                       TestPduR_J1939TpTxConfirmation()                       **
*******************************************************************************/
boolean TestPduR_J1939TpTxConfirmation(App_DataValidateType LucDataValidate, 
  PduIdType ExpTxPduId, NotifResultType ExpResult)
{
  boolean LblRetValue;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count and Id */
      if((PduR_GucJ1939TpTxConfCount == 0x01) && (ExpTxPduId == PduR_GddJ1939TpTxConfPduId) && 
        (PduR_GddJ1939TpTxConfResult == ExpResult))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucJ1939TpTxConfCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucJ1939TpTxConfCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);

} /* End TestPduR_J1939TpTxConfirmation() */

/*******************************************************************************
**                       PduR_J1939TpStartOfReception()                         **
*******************************************************************************/
BufReq_ReturnType PduR_J1939TpStartOfReception(PduIdType RxPduId, 
  PduLengthType TpSduLength, PduLengthType *RxBufferSizePtr)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual PduId, TpSduLength into Global variables */
  PduR_GddJ1939TpSorPduId[PduR_GucJ1939TpSorCount] = RxPduId;
  PduR_GddJ1939TpSorTpSduLength[PduR_GucJ1939TpSorCount] = TpSduLength;
  /* Load RxBufferSizePtr with data of PduR_GddJ1939TpSorRxBuffer  */
  *RxBufferSizePtr = PduR_GddJ1939TpSorRxBuffer;
  /* Increment count variable to handle multiple invocations */
  PduR_GucJ1939TpSorCount++;
  #endif
  return(PduR_GddJ1939TpSorRetVal);
} /* End PduR_J1939TpStartOfReception() */

/*******************************************************************************
**                       TestPduR_J1939TpStartOfReception()                     **
*******************************************************************************/
boolean TestPduR_J1939TpStartOfReception(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, PduLengthType ExpTpSduLength, 
  PduLengthType *RxBufferSizePtr)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, Id and TpSduLength */
      if((PduR_GucJ1939TpSorCount == 0x01) && 
      (PduR_GddJ1939TpSorPduId[0] == ExpRxPduId) && 
      (PduR_GddJ1939TpSorTpSduLength[0] == ExpTpSduLength))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucJ1939TpSorCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucJ1939TpSorCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < PduR_GucJ1939TpSorCount; LucIndex++)
      {
        /* Validate the PduId */
        if((PduR_GddJ1939TpSorPduId[LucIndex] == ExpRxPduId) && 
        (PduR_GddJ1939TpSorTpSduLength[LucIndex] == ExpTpSduLength))
        {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
          */
          LucIndex = PduR_GucJ1939TpSorCount;
        } /* End if((PduR_GddJ1939TpRxIndPduId[LucIndex] == ExpRxPduId) &&  */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucJ1939TpSorCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucJ1939TpSorCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucJ1939TpSorCheckCount == PduR_GucJ1939TpSorCount)
      {
        PduR_GucJ1939TpSorCount = 0;
        PduR_GucJ1939TpSorCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  RxBufferSizePtr++;
  return(LblRetValue);
} /* End TestPduR_J1939TpStartOfReception() */

/*******************************************************************************
**                       TestPduR_J1939TpStartOfReceptionSetVal()             **
*******************************************************************************/
void TestPduR_J1939TpStartOfReceptionSetVal(BufReq_ReturnType RetVal, 
  PduLengthType RxBufferSize)
{
  PduR_GddJ1939TpSorRetVal = RetVal;
  PduR_GddJ1939TpSorRxBuffer = RxBufferSize;
} /* End TestPduR_J1939TpStartOfReceptionSetVal() */

/*******************************************************************************
**                       PduR_J1939TpCopyRxData()                               **
*******************************************************************************/
BufReq_ReturnType PduR_J1939TpCopyRxData(PduIdType RxPduId,
  PduInfoType *PduInfoPtr, PduLengthType *RxBufferSizePtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8 *LpSduDataPtr;
  /* Load the address of SduDataPtr into Local Variable */
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  
  /* Load actual PduId, SduLength into Global variables */
  PduR_GddJ1939TpCopyRxDataPduId[PduR_GucJ1939TpCopyRxDataCount] = RxPduId;
  PduR_GddJ1939TpCopyRxDataSduLength[PduR_GucJ1939TpCopyRxDataCount] = PduInfoPtr->SduLength;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > PDUR_DATA_LENGTH)
  {
    LucDataLength = PDUR_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->SduLength;
  }
  /* 
   * Load PduR_GaaJ1939TpCopyRxDataSduData with SduDataPtr and RxBufferSizePtr 
   * with data of PduR_GddJ1939TpCopyRxDataRxBuffer  
   */
  /* Load the SduDataPtr with the global array */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    PduR_GaaJ1939TpCopyRxDataSduData[LucDataIndex] = *LpSduDataPtr;
    LpSduDataPtr++;
  }
  *RxBufferSizePtr = PduR_GddJ1939TpCopyRxDataRxBuffer;
  /* Increment count variable to handle multiple invocations */
  PduR_GucJ1939TpCopyRxDataCount++;
  #endif
  return(PduR_GddJ1939TpCopyRxDataRetVal);
} /* End PduR_J1939TpCopyRxData() */

/*******************************************************************************
**                       TestPduR_J1939TpCopyRxData()                           **
*******************************************************************************/
boolean TestPduR_J1939TpCopyRxData(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr, 
   PduLengthType *ExpRxBufferSizePtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, Id and SduLength */
      if((PduR_GucJ1939TpCopyRxDataCount == 0x01) && 
      (PduR_GddJ1939TpCopyRxDataPduId[0] == ExpRxPduId))
      {
        ActPduInfo.SduLength = PduR_GddJ1939TpCopyRxDataSduLength[0];
        ActPduInfo.SduDataPtr = &PduR_GaaJ1939TpCopyRxDataSduData[0];
        /* Validate SduLength and Data */
        if(PduRTest_ValidateData(ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
     }
     /* Reset API invocation Count after validating the API invocation */
     PduR_GucJ1939TpCopyRxDataCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucJ1939TpCopyRxDataCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < PduR_GucJ1939TpCopyRxDataCount; LucIndex++)
      {
        /* Validate the PduId */
        if((PduR_GddJ1939TpCopyRxDataPduId[LucIndex] == ExpRxPduId) && 
        (PduR_GddJ1939TpCopyRxDataSduLength[LucIndex] == ExpPduInfoPtr->SduLength))
        {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
          */
          LucIndex = PduR_GucJ1939TpCopyRxDataCount;
        } /* End if((PduR_GddJ1939TpRxIndPduId[LucIndex] == ExpRxPduId) &&  */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucJ1939TpCopyRxDataCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucJ1939TpCopyRxDataCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucJ1939TpCopyRxDataCheckCount == PduR_GucJ1939TpCopyRxDataCount)
      {
        PduR_GucJ1939TpCopyRxDataCount = 0;
        PduR_GucJ1939TpCopyRxDataCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  ExpRxBufferSizePtr++;
  return(LblRetValue);
} /* End TestPduR_J1939TpCopyRxData() */

/*******************************************************************************
**                       TestPduR_J1939TpCopyRxDataSetVal()                     **
*******************************************************************************/
void TestPduR_J1939TpCopyRxDataSetVal(BufReq_ReturnType RetVal, PduLengthType RxBufferSize)
{
  PduR_GddJ1939TpCopyRxDataRetVal = RetVal;

  PduR_GddJ1939TpCopyRxDataRxBuffer = RxBufferSize;
} /* End TestPduR_J1939TpCopyRxDataSetVal() */

/*******************************************************************************
**                       PduR_J1939TpCopyTxData()                               **
*******************************************************************************/
BufReq_ReturnType PduR_J1939TpCopyTxData(PduIdType TxPduId, PduInfoType* PduInfoPtr, 
  RetryInfoType* RetryInfoPtr, PduLengthType* TxDataCntPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8 *LpSduDataPtr;
  
  /* Load the address of SduDataPtr into Local Variable */
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  
  /* Load actual PduId, SduLength and RetryInfoPtr into Global variables */
  PduR_GddJ1939TpCopyTxDataPduId[PduR_GucJ1939TpCopyTxDataCount] = TxPduId;
  PduR_GddJ1939TpCopyTxDataSduLength[PduR_GucJ1939TpCopyTxDataCount] = PduInfoPtr->SduLength;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > PDUR_DATA_LENGTH)
  {
    LucDataLength = PDUR_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->SduLength;
  }
  // PduR_GddJ1939TpCopyTxDataRetryInfo[PduR_GucJ1939TpCopyTxDataCount].TpDataState = RetryInfoPtr->TpDataState;
  // PduR_GddJ1939TpCopyTxDataRetryInfo[PduR_GucJ1939TpCopyTxDataCount].TxTpDataCnt = RetryInfoPtr->TxTpDataCnt;
  /* 
   * Load SduDataPtr with data of PduR_GaaJ1939TpCopyTxDataSduData and 
   * TxDataCntPtr with data of PduR_GddJ1939TpCopyTxDataTxDataCnt  
   */
  /* Load the SduDataPtr with the global array */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    *LpSduDataPtr = PduR_GaaJ1939TpCopyTxDataSduData[LucDataIndex];
    LpSduDataPtr++;
  }
  *TxDataCntPtr = PduR_GddJ1939TpCopyTxDataTxDataCnt;
  /* Increment count variable to handle multiple invocations */
  PduR_GucJ1939TpCopyTxDataCount++;
  
  if((App_GucTestIndex == 3)  &&  (App_GddTestStepId == 2))
  {
    PduR_GddJ1939TpCopyTxDataTxDataCnt = 4;
  }
  #endif
  UNUSED(RetryInfoPtr);
  return(PduR_GddJ1939TpCopyTxDataRetVal);
} /* End PduR_J1939TpCopyTxData() */

/*******************************************************************************
**                       TestPduR_J1939TpCopyTxData()                         **
*******************************************************************************/
boolean TestPduR_J1939TpCopyTxData(App_DataValidateType LucDataValidate, 
  PduIdType ExpTxPduId, PduInfoType* ExpPduInfoPtr, 
  RetryInfoType* ExpRetryInfoPtr, PduLengthType* ExpTxDataCntPtr)
{
  
  uint8 LucIndex;
  boolean LblRetValue;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, Id, SduLength and RetryInfoPtr */
      if((PduR_GucJ1939TpCopyTxDataCount == 0x01) && 
      (PduR_GddJ1939TpCopyTxDataPduId[0] == ExpTxPduId) && 
      (PduR_GddJ1939TpCopyTxDataSduLength[0] == ExpPduInfoPtr->SduLength))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucJ1939TpCopyTxDataCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucJ1939TpCopyTxDataCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
     /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
     /* Validate invocation count, Id, SduLength and RetryInfoPtr */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < PduR_GucJ1939TpCopyTxDataCount; LucIndex++)
      {
        /* Validate ControllerId and ControllerMode */
      if((PduR_GddJ1939TpCopyTxDataPduId[LucIndex] == ExpTxPduId) && 
      (PduR_GddJ1939TpCopyTxDataSduLength[LucIndex] == ExpPduInfoPtr->SduLength) &&
      (PduR_GddJ1939TpCopyTxDataRetryInfo[LucIndex].TpDataState == ExpRetryInfoPtr->TpDataState) && 
      (PduR_GddJ1939TpCopyTxDataRetryInfo[LucIndex].TxTpDataCnt == ExpRetryInfoPtr->TxTpDataCnt))
      {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = PduR_GucJ1939TpCopyTxDataCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucJ1939TpCopyTxDataCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucJ1939TpCopyTxDataCheckCount == PduR_GucJ1939TpCopyTxDataCount)
      {
        PduR_GucJ1939TpCopyTxDataCount = 0;
        PduR_GucJ1939TpCopyTxDataCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  ExpTxDataCntPtr++;
  return(LblRetValue);
} /* End TestPduR_J1939TpCopyTxData() */
/*******************************************************************************
**                       TestPduR_J1939TpCopyTxDataSetVal()                     **
*******************************************************************************/
void TestPduR_J1939TpCopyTxDataSetVal(BufReq_ReturnType RetVal, uint8 *TxData,
  PduLengthType TxDataCnt)
{
  uint8 LucDataIndex;
  PduR_GddJ1939TpCopyTxDataRetVal = RetVal;
  for(LucDataIndex = 0x00; LucDataIndex < PDUR_DATA_LENGTH; LucDataIndex++)
  {
    PduR_GaaJ1939TpCopyTxDataSduData[LucDataIndex] = *TxData;
    TxData++;
  }
  PduR_GddJ1939TpCopyTxDataTxDataCnt = TxDataCnt;
} /* End TestPduR_J1939TpCopyTxDataSetVal() */

#endif

#ifdef LINIF_MODULE_ACTIVE
/*******************************************************************************
**                         PduR_LinIfTriggerTransmit()                        **
*******************************************************************************/
Std_ReturnType PduR_LinIfTriggerTransmit (PduIdType TxPduId,
  PduInfoType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 *LpSduDataPtr;
  uint8 LucCount;
  uint8 LucSduLength = 0x00;

  boolean LblValue = FALSE;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  PduR_GaaLinIfTrigTxPduId[PduR_GucLinIfTrigTxCount] = TxPduId;
  for(LucCount = 0x00;(LucCount < PDUR_ARRAY_SIZE) && (LblValue == FALSE);
    LucCount++)
  {
    if(TxPduId == PduR_GaaLinIfTrigSetTxPduId[LucCount])
    {
      PduInfoPtr->SduLength = PduR_GaaLinIfTrigSetTxSduLength[LucCount];
      while(LucSduLength < PduInfoPtr->SduLength)
      {
        *LpSduDataPtr =
          PduR_GaaLinIfTrigSetTxSduData[LucCount][LucSduLength];
        LpSduDataPtr++;
        LucSduLength++;
      }      
      LblValue = TRUE;
    }
    if((LblValue != TRUE) && (LucCount == (PDUR_ARRAY_SIZE - 1)))
    {
      PduInfoPtr->SduLength = PduR_GaaLinIfTrigSetTxSduLength[LucCount];
      while(LucSduLength < PduInfoPtr->SduLength)
      {
        *LpSduDataPtr =
          PduR_GaaLinIfTrigSetTxSduData[LucCount][LucSduLength];
        LpSduDataPtr++;
        LucSduLength++;
      }      
    }
  }
  PduR_GucLinIfTrigTxCount++;
  #endif
  return(E_OK);
} /* End PduR_LinIfTriggerTransmit() */

/*******************************************************************************
**                       TestPduR_LinIfTriggerTransmit()                      **
*******************************************************************************/
boolean TestPduR_LinIfTriggerTransmit (App_DataValidateType LddDataValidate,
PduIdType ExpTxPduId)
{
  uint8 LucIndex;
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
    */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((PduR_GucLinIfTrigTxCount == 0x01) &&
        (ExpTxPduId == PduR_GaaLinIfTrigTxPduId[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucLinIfTrigTxCount = 0x00;
      PduR_GucPduRLinIfTrigTxCheckCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucLinIfTrigTxCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < PduR_GucLinIfTrigTxCount; LucIndex++)
      {
        /* Validate the PduId */
        if((ExpTxPduId == PduR_GaaLinIfTrigTxPduId[LucIndex]))
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = PduR_GucLinIfTrigTxCount;
        } /* End if(ExpPduId == PduR_GucComActPduId[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucLinIfTrigTxCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucPduRLinIfTrigTxCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucPduRLinIfTrigTxCheckCount == PduR_GucLinIfTrigTxCount)
      {
        PduR_GucLinIfTrigTxCount = 0;
        PduR_GucPduRLinIfTrigTxCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with sequnce)
     * and to validate parameters of the API with what it has been invoked
     */

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;

      /* Loop through the global array and check for the expected ID */
      for(LucIndex = 0; (LucIndex < PduR_GucLinIfTrigTxCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpTxPduId == PduR_GaaLinIfTrigTxPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}  /* End TestPduR_LinIfTriggerTransmit() */

/*******************************************************************************
**                     TestSetPduR_LinIfTrigTxVal()                           **
*******************************************************************************/
void TestSetPduR_LinIfTrigTxVal(uint8 ApiInvokeIndx, PduIdType TxPduId,
  PduInfoType *PduInfoPtr)
{
  uint8 LucSduLength = 0x00;
  uint8* LpSduDataPtr;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;

  PduR_GaaLinIfTrigSetTxPduId[ApiInvokeIndx] = TxPduId;
  PduR_GaaLinIfTrigSetTxSduLength[ApiInvokeIndx] = PduInfoPtr->SduLength;
  while(LucSduLength < PduR_GaaLinIfTrigSetTxSduLength[ApiInvokeIndx])
  {
    PduR_GaaLinIfTrigSetTxSduData[ApiInvokeIndx][LucSduLength] =
      *LpSduDataPtr;
    LpSduDataPtr++;
    LucSduLength++;
  }
}/* End TestSetPduR_LinIfTrigTxVal() */

/*******************************************************************************
**                         PduR_LinIfTxConfirmation()                         **
*******************************************************************************/
void PduR_LinIfTxConfirmation (PduIdType TxPduId)
{
  #ifndef TYPICAL_CONFIG
  PduR_GucLinIfTxConfPduId[PduR_GucLinIfTxConfCount] = TxPduId;
  PduR_GucLinIfTxConfCount++;
  #endif
} /* End PduR_LinIfTxConfirmation() */

/*******************************************************************************
**                       TestPduR_LinIfTxConfirmation()                       **
*******************************************************************************/
boolean TestPduR_LinIfTxConfirmation (App_DataValidateType LddDataValidate,
PduIdType ExpTxPduId)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    case S_VALIDATE:
    {
      if((PduR_GucLinIfTxConfCount == 0x01) &&
        (ExpTxPduId == PduR_GucLinIfTxConfPduId[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      PduR_GucLinIfTxConfCount = 0;
      break;
    } /* End case S_VALIDATE: */
    case S_NOT_INVOKED:
    {
      if(PduR_GucLinIfTxConfCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < PduR_GucLinIfTxConfCount; LucIndex++)
      {
        if(ExpTxPduId == PduR_GucLinIfTxConfPduId[LucIndex])
        {
          LblRetValue = STEP_PASSED;
          LucIndex = PduR_GucLinIfTxConfCount;
        } /* End if(ExpTxPduId == PduR_GucLinIfTxConfPduId[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucLinIfTxConfCount; ...) */
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucLinIfTxConfCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucLinIfTxConfCount == PduR_GucLinIfTxConfCheckCount)
      {
        PduR_GucLinIfTxConfCount = 0;
        PduR_GucLinIfTxConfCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < PduR_GucLinIfTxConfCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpTxPduId == PduR_GucLinIfTxConfPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestPduR_LinIfTxConfirmation() */

/*******************************************************************************
**                         PduR_LinIfRxIndication()                           **
*******************************************************************************/
void PduR_LinIfRxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8* LpSduDataPtr;
  PduLengthType LucDataLength;

  PduR_GaaLinIfRxIndPduId[PduR_GucLinIfRxIndCount] = RxPduId;
  PduR_GaaLinIfRxIndSduLength[PduR_GucLinIfRxIndCount] = PduInfoPtr->SduLength;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > PDUR_DATA_LENGTH)
  {
    LucDataLength = PDUR_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->SduLength;
  }
  /* Copy the actual data from actual SduDataPtr into global array */
  for(LucDataIndex = 0x00; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    PduR_GaaLinIfRxIndSduData[PduR_GucLinIfRxIndCount][LucDataIndex] =
      *LpSduDataPtr;
    LpSduDataPtr++;
  }
  PduR_GucLinIfRxIndCount++;
  #endif
} /* End PduR_LinIfTransmit()*/

/*******************************************************************************
**                       TestPduR_LinIfRxIndication()                         **
*******************************************************************************/
boolean TestPduR_LinIfRxIndication(App_DataValidateType LddDataValidate,
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((PduR_GucLinIfRxIndCount == 0x01) &&
        (ExpRxPduId == PduR_GaaLinIfRxIndPduId[0]))
      {
        ActPduInfo.SduLength = PduR_GaaLinIfRxIndSduLength[0];
        ActPduInfo.SduDataPtr = &PduR_GaaLinIfRxIndSduData[0][0];

        /* Validate SduLength and Data */
        if(PduRTest_ValidateData(ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucLinIfRxIndCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucLinIfRxIndCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < PduR_GucLinIfRxIndCount; LucIndex++)
      {
        if(ExpRxPduId == PduR_GaaLinIfRxIndPduId[LucIndex])
        {
          ActPduInfo.SduLength = PduR_GaaLinIfRxIndSduLength[LucIndex];
          ActPduInfo.SduDataPtr = &PduR_GaaLinIfRxIndSduData[LucIndex][0];

          if(PduRTest_ValidateData((PduInfoType *)ExpPduInfoPtr, &ActPduInfo))
          {
            LblRetValue = STEP_PASSED;
          }
          LucIndex = PduR_GucLinIfRxIndCount;
        } /* End if(ExpRxPduId == PduR_GaaLinIfRxIndPduId[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucLinIfRxIndCount; ...) */
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucLinIfRxIndCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucLinIfRxIndCount == PduR_GucLinIfRxIndCheckCount)
      {
        PduR_GucLinIfRxIndCount = 0;
        PduR_GucLinIfRxIndCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < PduR_GucLinIfRxIndCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpRxPduId == PduR_GaaLinIfRxIndPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestPduR_LinIfRxIndication() */
/*******************************************************************************
**                       PduR_LinTpRxIndication()                             **
*******************************************************************************/
void PduR_LinTpRxIndication(PduIdType RxPduId, NotifResultType Result)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual PduId and result into Global variables */
  PduR_GaaLinTpRxIndPduId[PduR_GucLinTpRxIndCount] = RxPduId;
  PduR_GaaLinTpRxIndResult[PduR_GucLinTpRxIndCount] = Result;
  /* Increment count variable to handle multiple invocations */
  if(PduR_GucLinTpRxIndCount != PDUR_ARRAY_SIZE)
  {    
    PduR_GucLinTpRxIndCount++;
  }  
  #endif
} /* End PduR_LinTpRxIndication() */

/*******************************************************************************
**                       TestPduR_LinTpRxIndication()                         **
*******************************************************************************/
boolean TestPduR_LinTpRxIndication(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, NotifResultType ExpResult)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, RxPduId and Result */
      if((PduR_GucLinTpRxIndCount == 0x01) &&
        (PduR_GaaLinTpRxIndPduId[0] == ExpRxPduId) && 
        (PduR_GaaLinTpRxIndResult[0] == ExpResult))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucLinTpRxIndCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucLinTpRxIndCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < PduR_GucLinTpRxIndCount; LucIndex++)
      {
        /* Validate the PduId */
        if((PduR_GaaLinTpRxIndPduId[LucIndex] == ExpRxPduId) && 
        (PduR_GaaLinTpRxIndResult[LucIndex] == ExpResult))
        {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
          */
          LucIndex = PduR_GucLinTpRxIndCount;
        } /* End if((PduR_GaaLinTpRxIndPduId[LucIndex] == ExpRxPduId) &&  */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucLinTpRxIndCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucLinTpRxIndCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucLinTpRxIndCheckCount == PduR_GucLinTpRxIndCount)
      {
        PduR_GucLinTpRxIndCount = 0;
        PduR_GucLinTpRxIndCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;

      /* Loop through the global array and check for the expected ID */
      for(LucIndex = 0; (LucIndex < PduR_GucLinTpRxIndCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpRxPduId == PduR_GaaLinTpRxIndPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    } /* End case M_NOT_INVOKED: */
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);

} /* End TestPduR_LinTpRxIndication() */
/*******************************************************************************
**                       PduR_LinTpTxConfirmation()                           **
*******************************************************************************/
void PduR_LinTpTxConfirmation(PduIdType TxPduId, NotifResultType Result)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual PduId and result into Global variables */
  PduR_GaaLinTpTxConfPduId[PduR_GucLinTpTxConfCount] = TxPduId;
  PduR_GaaLinTpTxConfResult[PduR_GucLinTpTxConfCount] = Result;
  /* Increment count variable to handle multiple invocations */
  if(PduR_GucLinTpTxConfCount != PDUR_ARRAY_SIZE)
  {    
    PduR_GucLinTpTxConfCount++;
  }
  #endif
} /* End PduR_LinTpTxConfirmation() */

/*******************************************************************************
**                       TestPduR_LinTpTxConfirmation()                       **
*******************************************************************************/
boolean TestPduR_LinTpTxConfirmation(App_DataValidateType LucDataValidate, 
  PduIdType ExpTxPduId, NotifResultType ExpResult)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, RxPduId and Result */
      if((PduR_GucLinTpTxConfCount == 0x01) &&
        (PduR_GaaLinTpTxConfPduId[0] == ExpTxPduId) && 
        (PduR_GaaLinTpTxConfResult[0] == ExpResult))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucLinTpTxConfCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucLinTpTxConfCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < PduR_GucLinTpTxConfCount; LucIndex++)
      {
        /* Validate the PduId */
        if((PduR_GaaLinTpTxConfPduId[LucIndex] == ExpTxPduId) && 
        (PduR_GaaLinTpTxConfResult[LucIndex] == ExpResult))
        {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
          */
          LucIndex = PduR_GucLinTpTxConfCount;
        } /* End if((PduR_GaaLinTpTxConfPduId[LucIndex] == ExpTxPduId) &&  */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucLinTpTxConfCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucLinTpTxConfCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucLinTpTxConfCheckCount == PduR_GucLinTpTxConfCount)
      {
        PduR_GucLinTpTxConfCount = 0;
        PduR_GucLinTpTxConfCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;

      /* Loop through the global array and check for the expected ID */
      for(LucIndex = 0; (LucIndex < PduR_GucLinTpTxConfCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpTxPduId == PduR_GaaLinTpTxConfPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    } /* End case M_NOT_INVOKED: */
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);

} /* End TestPduR_LinTpTxConfirmation() */

/*******************************************************************************
**                       PduR_LinTpStartOfReception()                         **
*******************************************************************************/
BufReq_ReturnType PduR_LinTpStartOfReception(PduIdType RxPduId, 
  PduLengthType TpSduLength, PduLengthType *RxBufferSizePtr)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual PduId, TpSduLength into Global variables */
  PduR_GaaLinTpSorPduId[PduR_GucLinTpSorCount] = RxPduId;
  PduR_GaaLinTpSorTpSduLength[PduR_GucLinTpSorCount] = TpSduLength;
  /* Load RxBufferSizePtr with data of PduR_GaaLinTpSorRxBuffer  */
  *RxBufferSizePtr = PduR_GaaLinTpSorRxBuffer[RxPduId];
  /* Increment count variable to handle multiple invocations */
  if(PduR_GucLinTpSorCount != PDUR_ARRAY_SIZE)
  {    
    PduR_GucLinTpSorCount++;
  }  
  return(PduR_GaaLinTpSorRetVal[RxPduId]);
  #else
  return(BUFREQ_OK);
  #endif
} /* End PduR_LinTpStartOfReception() */

/*******************************************************************************
**                       TestPduR_LinTpStartOfReception()                     **
*******************************************************************************/
boolean TestPduR_LinTpStartOfReception(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, PduLengthType ExpTpSduLength, 
  PduLengthType *RxBufferSizePtr)
{
  boolean LblRetValue;
  uint8 LucIndex;
  UNUSED(RxBufferSizePtr);
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, Id and TpSduLength */
      if((PduR_GucLinTpSorCount == 0x01) && 
      (PduR_GaaLinTpSorPduId[0] == ExpRxPduId) && 
      (PduR_GaaLinTpSorTpSduLength[0] == ExpTpSduLength))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucLinTpSorCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucLinTpSorCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < PduR_GucLinTpSorCount; LucIndex++)
      {
        /* Validate the PduId */
        if((PduR_GaaLinTpSorPduId[LucIndex] == ExpRxPduId) && 
        (PduR_GaaLinTpSorTpSduLength[LucIndex] == ExpTpSduLength))
        {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
          */
          LucIndex = PduR_GucLinTpSorCount;
        } /* End if((PduR_GaaLinTpSorPduId[LucIndex] == ExpRxPduId) &&  */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucLinTpSorCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucLinTpSorCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucLinTpSorCheckCount == PduR_GucLinTpSorCount)
      {
        PduR_GucLinTpSorCount = 0;
        PduR_GucLinTpSorCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;

      /* Loop through the global array and check for the expected ID */
      for(LucIndex = 0; (LucIndex < PduR_GucLinTpSorCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpRxPduId == PduR_GaaLinTpSorPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    } /* End case M_NOT_INVOKED: */
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestPduR_LinTpStartOfReception() */

/*******************************************************************************
**                       TestSetPduR_LinTpStartOfReceptionRetVal()            **
*******************************************************************************/
void TestSetPduR_LinTpStartOfReceptionRetVal(PduIdType RxPduId, 
  PduLengthType RxBufferSize, BufReq_ReturnType RetVal)
{
  PduR_GaaLinTpSorRetVal[RxPduId] = RetVal;
  PduR_GaaLinTpSorRxBuffer[RxPduId] = RxBufferSize;
} /* End TestSetPduR_LinTpStartOfReceptionRetVal() */

/*******************************************************************************
**                       PduR_LinTpCopyRxData()                               **
*******************************************************************************/
BufReq_ReturnType PduR_LinTpCopyRxData(PduIdType RxPduId,
  PduInfoType *PduInfoPtr, PduLengthType *RxBufferSizePtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  PduLengthType LucDataLength;
  uint8 *LpSduDataPtr;
  /* Load the address of SduDataPtr into Local Variable */
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  
  /* Load actual PduId, SduLength into Global variables */
  PduR_GaaLinTpCopyRxDataPduId[PduR_GucLinTpCopyRxDataCount] = RxPduId;
  PduR_GaaLinTpCopyRxDataSduLength[PduR_GucLinTpCopyRxDataCount] = PduInfoPtr->SduLength;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > PDUR_DATA_LENGTH)
  {
    LucDataLength = PDUR_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->SduLength;
  }
  /* 
   * Load PduR_GaaLinTpCopyRxDataSduData with SduDataPtr and RxBufferSizePtr 
   * with data of PduR_GaaLinTpCopyRxDataRxBuffer  
   */
  /* Load the SduDataPtr with the global array */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    PduR_GaaLinTpCopyRxDataSduData[PduR_GucLinTpCopyRxDataCount][LucDataIndex] = 
      *LpSduDataPtr;
    LpSduDataPtr++;
  }
  *RxBufferSizePtr = PduR_GucLinTpAvblBuff;
  /* Increment count variable to handle multiple invocations */
  if(PduR_GucLinTpCopyRxDataCount != PDUR_ARRAY_SIZE)
  {    
    PduR_GucLinTpCopyRxDataCount++;
  }
  return(PduR_GaaLinTpCopyRxDataRetVal[RxPduId]);
  #else
  return(BUFREQ_OK);
  #endif
} /* End PduR_LinTpCopyRxData() */

/*******************************************************************************
**                       TestPduR_LinTpCopyRxData()                           **
*******************************************************************************/
boolean TestPduR_LinTpCopyRxData(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr, 
   PduLengthType *ExpRxBufferSizePtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;
  UNUSED(ExpRxBufferSizePtr);
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, Id and SduLength */
      if((PduR_GucLinTpCopyRxDataCount == 0x01) && 
      (PduR_GaaLinTpCopyRxDataPduId[0] == ExpRxPduId))
      {
        ActPduInfo.SduLength = PduR_GaaLinTpCopyRxDataSduLength[0];
        ActPduInfo.SduDataPtr = &PduR_GaaLinTpCopyRxDataSduData[0][0];
        /* Validate SduLength and Data */
        if(PduRTest_ValidateData(ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
     }
     /* Reset API invocation Count after validating the API invocation */
     PduR_GucLinTpCopyRxDataCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucLinTpCopyRxDataCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < PduR_GucLinTpCopyRxDataCount; LucIndex++)
      {
        /* Validate the PduId */
        if((PduR_GaaLinTpCopyRxDataPduId[LucIndex] == ExpRxPduId) && 
        (PduR_GaaLinTpCopyRxDataSduLength[LucIndex] == ExpPduInfoPtr->SduLength))
        {
          ActPduInfo.SduLength = PduR_GaaLinTpCopyRxDataSduLength[LucIndex];
          ActPduInfo.SduDataPtr = &PduR_GaaLinTpCopyRxDataSduData[LucIndex][0];
          /* Validate SduLength and Data */
          if(PduRTest_ValidateData(ExpPduInfoPtr, &ActPduInfo))
          {
            LblRetValue = STEP_PASSED;
          }
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
          */
          LucIndex = PduR_GucLinTpCopyRxDataCount;
        } /* End if((PduR_GaaLinTpCopyRxDataPduId[LucIndex] == ExpRxPduId) &&  */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucLinTpCopyRxDataCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucLinTpCopyRxDataCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucLinTpCopyRxDataCheckCount == PduR_GucLinTpCopyRxDataCount)
      {
        PduR_GucLinTpCopyRxDataCount = 0;
        PduR_GucLinTpCopyRxDataCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;

      /* Loop through the global array and check for the expected ID */
      for(LucIndex = 0; (LucIndex < PduR_GucLinTpCopyRxDataCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpRxPduId == PduR_GaaLinTpCopyRxDataPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    } /* End case M_NOT_INVOKED: */
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestPduR_LinTpCopyRxData() */

/*******************************************************************************
**                       TestSetPduR_LinTpCopyRxDataRetVal()                  **
*******************************************************************************/
void TestSetPduR_LinTpCopyRxDataRetVal(PduIdType RxPduId, 
  PduLengthType RxBufferSize, BufReq_ReturnType RetVal)
{
  PduR_GaaLinTpCopyRxDataRetVal[RxPduId] = RetVal;
  PduR_GaaLinTpCopyRxDataRxBuffer[RxPduId] = RxBufferSize;
} /* End TestSetPduR_LinTpCopyRxDataRetVal() */

/*******************************************************************************
**                       PduR_LinTpCopyTxData()                               **
*******************************************************************************/
BufReq_ReturnType PduR_LinTpCopyTxData(PduIdType TxPduId, 
  PduInfoType* PduInfoPtr, RetryInfoType* RetryInfoPtr, 
  PduLengthType* TxDataCntPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  PduLengthType LucDataLength;
  uint8 *LpSduDataPtr;
  
  /* Load the address of SduDataPtr into Local Variable */
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  
  /* Load actual PduId, SduLength and RetryInfoPtr into Global variables */
  PduR_GaaLinTpCopyTxDataPduId[PduR_GucLinTpCopyTxDataCount] = TxPduId;
  PduR_GaaLinTpCopyTxDataSduLength[PduR_GucLinTpCopyTxDataCount] = PduInfoPtr->SduLength;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > PDUR_DATA_LENGTH)
  {
    LucDataLength = PDUR_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->SduLength;
  }
  
  PduR_GaaLinTpCopyTxDataRetryInfo[PduR_GucLinTpCopyTxDataCount] = RetryInfoPtr;
  /* 
   * Load SduDataPtr with data of PduR_GaaLinTpCopyTxDataSduData and 
   * TxDataCntPtr with data of PduR_GaaLinTpCopyTxDataTxDataCnt  
   */
  /* Load the SduDataPtr with the global array */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    *LpSduDataPtr = PduR_GaaLinTpCopyTxDataSduData[TxPduId][LucDataIndex];
    LpSduDataPtr++;
  }
  UNUSED(TxDataCntPtr);
  /* Increment count variable to handle multiple invocations */
  if(PduR_GucLinTpCopyTxDataCount != PDUR_ARRAY_SIZE)
  {    
    PduR_GucLinTpCopyTxDataCount++;
  }  
  return(PduR_GaaLinTpCopyTxDataRetVal[TxPduId]);
  #else
  return(BUFREQ_OK);
  #endif
} /* End PduR_LinTpCopyTxData() */

/*******************************************************************************
**                       TestPduR_LinTpCopyTxData()                           **
*******************************************************************************/
boolean TestPduR_LinTpCopyTxData(App_DataValidateType LucDataValidate, 
  PduIdType ExpTxPduId, PduInfoType* ExpPduInfoPtr, 
  RetryInfoType* ExpRetryInfoPtr, PduLengthType* ExpTxDataCntPtr)
{
  
  uint8 LucIndex;
  boolean LblRetValue;

  /* To fix compilation warning */
  UNUSED(ExpTxDataCntPtr);
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, Id, SduLength and RetryInfoPtr */
      if((PduR_GucLinTpCopyTxDataCount == 0x01) && 
      (PduR_GaaLinTpCopyTxDataPduId[0] == ExpTxPduId) && 
      (PduR_GaaLinTpCopyTxDataSduLength[0] == ExpPduInfoPtr->SduLength) &&
      (PduR_GaaLinTpCopyTxDataRetryInfo[0]== ExpRetryInfoPtr))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucLinTpCopyTxDataCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucLinTpCopyTxDataCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
     /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
     /* Validate invocation count, Id, SduLength and RetryInfoPtr */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < PduR_GucLinTpCopyTxDataCount; LucIndex++)
      {
        /* Validate ControllerId and ControllerMode */
      if((PduR_GaaLinTpCopyTxDataPduId[LucIndex] == ExpTxPduId) && 
      (PduR_GaaLinTpCopyTxDataSduLength[LucIndex] == ExpPduInfoPtr->SduLength) &&
      (PduR_GaaLinTpCopyTxDataRetryInfo[0]== ExpRetryInfoPtr))
      {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = PduR_GucLinTpCopyTxDataCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucLinTpCopyTxDataCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucLinTpCopyTxDataCheckCount == PduR_GucLinTpCopyTxDataCount)
      {
        PduR_GucLinTpCopyTxDataCount = 0;
        PduR_GucLinTpCopyTxDataCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;

      /* Loop through the global array and check for the expected ID */
      for(LucIndex = 0; (LucIndex < PduR_GucLinTpCopyTxDataCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpTxPduId == PduR_GaaLinTpCopyTxDataPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    } /* End case M_NOT_INVOKED: */
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestPduR_LinTpCopyTxData() */

/*******************************************************************************
**                       TestSetPduR_LinTpCopyTxDataRetVal()                  **
*******************************************************************************/
void TestSetPduR_LinTpCopyTxDataRetVal(PduIdType TxPduId, 
  uint8 *TxData, BufReq_ReturnType RetVal)
{
  uint8 LucDataIndex;
  PduR_GaaLinTpCopyTxDataRetVal[TxPduId] = RetVal;
  for(LucDataIndex = 0x00; LucDataIndex < PDUR_DATA_LENGTH; LucDataIndex++)
  {
    PduR_GaaLinTpCopyTxDataSduData[TxPduId][LucDataIndex] = *TxData;
    TxData++;
  }
} /* End TestSetPduR_LinTpCopyTxDataRetVal() */

/*******************************************************************************
**                       PduR_LinTpChangeParameterConfirmation()              **
*******************************************************************************/
void PduR_LinTpChangeParameterConfirmation(PduIdType id, NotifResultType result)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual PduId and result into Global variables */
  PduR_GaaLinTpChngeParConfPduId[PduR_GucLinTpChngeParConfCount] = id;
  PduR_GaaLinTpChngeParConfResult[PduR_GucLinTpChngeParConfCount] = result;
  /* Increment count variable to handle multiple invocations */
  if(PduR_GucLinTpChngeParConfCount != PDUR_ARRAY_SIZE)
  {    
    PduR_GucLinTpChngeParConfCount++;
  } 
  #endif
} /* End PduR_LinTpChangeParameterConfirmation() */

/*******************************************************************************
**            TestPduR_LinTpChangeParameterConfirmation()                     **
*******************************************************************************/
boolean TestPduR_LinTpChangeParameterConfirmation(App_DataValidateType 
LucDataValidate, PduIdType ExpRxPduId, NotifResultType ExpResult)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, RxPduId and Result */
      if((PduR_GucLinTpChngeParConfCount == 0x01) &&
        (PduR_GaaLinTpChngeParConfPduId[0] == ExpRxPduId) && 
        (PduR_GaaLinTpChngeParConfResult[0] == ExpResult))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      PduR_GucLinTpChngeParConfCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucLinTpChngeParConfCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < PduR_GucLinTpChngeParConfCount; LucIndex++)
      {
        /* Validate the PduId */
        if((PduR_GaaLinTpChngeParConfPduId[LucIndex] == ExpRxPduId) && 
        (PduR_GaaLinTpChngeParConfResult[LucIndex] == ExpResult))
        {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
          */
          LucIndex = PduR_GucLinTpChngeParConfCount;
        } /* End if((PduR_GaaLinTpChngeParConfPduId[LucIndex] == ExpRxPduId) &&  */
      } /* End for(LucIndex = 0; LucIndex < PduR_GucLinTpChngeParConfCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucLinTpChngeParConfCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucLinTpChngeParConfCheckCount == PduR_GucLinTpChngeParConfCount)
      {
        PduR_GucLinTpChngeParConfCount = 0;
        PduR_GucLinTpChngeParConfCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;

      /* Loop through the global array and check for the expected ID */
      for(LucIndex = 0; (LucIndex < PduR_GucLinTpChngeParConfCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpRxPduId == PduR_GaaLinTpChngeParConfPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    } /* End case M_NOT_INVOKED: */
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);  
}/* End TestPduR_LinTpChangeParameterConfirmation() */

/*******************************************************************************
**                     TestSetPduR_DefaultBuffer()                            **
*******************************************************************************/

void TestSetPduR_DefaultBuffer(PduLengthType BuffSize)
{ 
  PduR_GucLinTpAvblBuff = BuffSize;
}
#endif

#ifdef DCM_MODULE_ACTIVE

/*******************************************************************************
**                     SimulatePduR_DcmTransmit()                                     **
*******************************************************************************/
void SimulatePduR_DcmTransmit(Std_ReturnType LddReturnType)
{
  PduR_GddDcmTxRetVal = LddReturnType;
}

/*******************************************************************************
**                     PduR_DcmTransmit()                                     **
*******************************************************************************/
Std_ReturnType PduR_DcmTransmit(PduIdType LddPduId,
  const PduInfoType* LddPduInfo)
{
	PduR_GucDcmPduid = LddPduId;
	PduR_GucDcmSduLength = LddPduInfo->SduLength;
	PduR_GucDcmTxCount++;
	
	return(PduR_GddDcmTxRetVal);
}
	
/*******************************************************************************
**                     TestPduR_DcmTransmit()                                     **
*******************************************************************************/
boolean TestPduR_DcmTransmit(App_DataValidateType LucDataValidate,
  PduIdType ExpPduId, PduInfoType* ExpPduInfo)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((PduR_GucDcmTxCount == 0x01) && (ExpPduId == PduR_GucDcmPduid) && 
				((ExpPduInfo->SduLength) == PduR_GucDcmSduLength))
      {
				LblRetValue = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      PduR_GucDcmTxCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucDcmTxCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
		
		case M_VALIDATE :
			break;
		
		case M_NOT_INVOKED :
			break;
		
		case S_VALIDATE_SEQ :
			break;
			
		case M_VALIDATE_SEQ :
			break;
		
	}	
		return(LblRetValue);
	}	

#endif
/*******************************************************************************
**                     TestPduR_DefaultBehavior()                             **
*******************************************************************************/
void TestPduR_DefaultBehavior(void)
{
  #ifdef J1939TP_MODULE_ACTIVE
  uint8 LucDataIndex;
  #endif
  #ifdef CANTP_MODULE_ACTIVE
  uint8 LucDataIndex;
  #endif
  #ifdef LINIF_MODULE_ACTIVE
  uint8 LucDataIndex;
  uint8 LucDataCount;
  #endif
  #ifdef IPDUM_MODULE_ACTIVE
  PduR_GucIpduMRxIndCount = 0x00;
  PduR_GucIpduMRxIndCheckCount = 0x00;
  PduR_GucIpduMTxConfCount = 0x00;
  PduR_GucIpduMTxConfCheckCount = 0x00;
  PduR_GucIpduMTrigTxCount = 0x00;
  PduR_GucPduRIpduMTrigTxCheckCount = 0x00;
  PduR_GucIpduMTxCount = 0x00;
  PduR_GddIpduMTxRetVal = E_OK;
  PduR_GddIpduMTrigTxRetVal = E_OK;
  #endif
  
  #ifdef DBG_MODULE_ACTIVE
  PduR_GddDbgTxRetVal = E_OK;
  PduR_GucDbgTxCount = 0;
  PduR_GucDbgTxCheckCount = 0;
  #endif
  
  #ifdef COM_MODULE_ACTIVE
  PduR_GddComTxRetVal = E_OK;
  PduR_GucComTxCount = 0;
  PduR_GucComTxCheckCount = 0;
  #endif
  
  #ifdef CANNM_MODULE_ACTIVE
  PduR_GucCanNmTrigTxCount = 0;
  PduR_GucCanNmTxConfirmCount = 0;
  PduR_GucCanNmRxIndiCount = 0;
  #endif

  #ifdef FRNM_MODULE_ACTIVE
  PduR_GucFrNmTrigTxCount = 0;
  PduR_GucFrNmTxConfirmCount = 0;
  PduR_GucFrNmRxIndiCount = 0;
  #endif
  
  #ifdef CANIF_MODULE_ACTIVE
  PduR_GucCanIfTxConfirmCount = 0;
  PduR_GucCanIfTxConfirmCheckCount = 0;
  PduR_GucCanIfRxIndiCount = 0;
  PduR_GucCanIfRxIndSduLength = 0;
  #endif
  
  #ifdef CANTP_MODULE_ACTIVE
  PduR_GucCanTpRxIndCount = 0x00;
  PduR_GucCanTpRxIndCheckCount = 0x00;
  PduR_GucCanTpTxConfCount = 0x00;
  PduR_GucCanTpSorCount = 0x00;
  PduR_GucCanTpSorCheckCount = 0x00;
  PduR_GddCanTpSorRetVal = BUFREQ_OK;
  PduR_GucCanTpChngeParConfCount = 0x00;
  PduR_GucCanTpChngeParConfCheckCount = 0x00;
  for(LucDataIndex = 0x00; LucDataIndex < PDUR_DATA_LENGTH; LucDataIndex++)
  {
    PduR_GaaCanTpCopyRxDataSduData[LucDataIndex] = LucDataIndex;
  }
  PduR_GddCanTpCopyRxDataRxBuffer = 0x00;
  PduR_GddCanTpCopyRxDataRetVal = BUFREQ_OK;
  PduR_GucCanTpCopyRxDataCount = 0x00;
  PduR_GucCanTpCopyRxDataCheckCount = 0x00;
  for(LucDataIndex = 0x00; LucDataIndex < PDUR_DATA_LENGTH; LucDataIndex++)
  {
    PduR_GaaCanTpCopyTxDataSduData[LucDataIndex] = LucDataIndex;
  }
  PduR_GddCanTpCopyTxDataTxDataCnt = 0x00;
  PduR_GddCanTpCopyTxDataRetVal = BUFREQ_OK;
  PduR_GucCanTpCopyTxDataCount = 0x00;
  #endif
  
  #ifdef J1939TP_MODULE_ACTIVE
  //uint8 LucDataIndex;
  PduR_GucJ1939TpRxIndCount = 0x00;
  PduR_GucJ1939TpRxIndCheckCount = 0x00;
  PduR_GucJ1939TpTxConfCount = 0x00;
  PduR_GucJ1939TpSorCount = 0x00;
  PduR_GucJ1939TpSorCheckCount = 0x00;
  PduR_GddJ1939TpSorRetVal = BUFREQ_OK;
  PduR_GucJ1939TpChngeParConfCount = 0x00;
  PduR_GucJ1939TpChngeParConfCheckCount = 0x00;
  for(LucDataIndex = 0x00; LucDataIndex < PDUR_DATA_LENGTH; LucDataIndex++)
  {
    PduR_GaaJ1939TpCopyRxDataSduData[LucDataIndex] = LucDataIndex;
  }
  PduR_GddJ1939TpCopyRxDataRxBuffer = 0x00;
  PduR_GddJ1939TpCopyRxDataRetVal = BUFREQ_OK;
  PduR_GucJ1939TpCopyRxDataCount = 0x00;
  PduR_GucJ1939TpCopyRxDataCheckCount = 0x00;
  for(LucDataIndex = 0x00; LucDataIndex < PDUR_DATA_LENGTH; LucDataIndex++)
  {
    PduR_GaaJ1939TpCopyTxDataSduData[LucDataIndex] = LucDataIndex;
  }
  PduR_GddJ1939TpCopyTxDataTxDataCnt = 0x00;
  PduR_GddJ1939TpCopyTxDataRetVal = BUFREQ_OK;
  PduR_GucJ1939TpCopyTxDataCount = 0x00;
  #endif
  
  #ifdef BSWM_MODULE_ACTIVE
  PduR_GucEnableRoutingCount = 0;
  PduR_GucDisableRoutingCount = 0;
  #endif
  
  #ifdef LINIF_MODULE_ACTIVE
  PduR_GucLinIfTxConfCount = 0x00;
  PduR_GucLinIfTxConfCheckCount = 0x00;
  PduR_GucLinIfRxIndCount = 0x00;
  PduR_GucLinIfRxIndCheckCount = 0x00;
  PduR_GucLinIfTrigTxCount = 0x00;
  PduR_GucPduRLinIfTrigTxCheckCount = 0x00;
  PduR_GucLinTpAvblBuff = 0x64;
  for(LucDataIndex = 0x00; LucDataIndex < PDUR_ARRAY_SIZE ; LucDataIndex++)
  {
    PduR_GaaLinIfTrigSetTxPduId[LucDataIndex] = 0xFF;
    PduR_GaaLinIfTrigSetTxSduLength[LucDataIndex] = 0x08;
    PduR_GaaLinTpSorRetVal[LucDataIndex] = BUFREQ_OK;
    PduR_GaaLinTpCopyRxDataRetVal[LucDataIndex] = BUFREQ_OK;
    PduR_GaaLinTpCopyTxDataRetVal[LucDataIndex] = BUFREQ_OK;
    for(LucDataCount = 0x00; LucDataCount < PDUR_DATA_LENGTH ; LucDataCount++)
    {
      PduR_GaaLinIfTrigSetTxSduData[LucDataIndex][LucDataCount] = LucDataCount;
    }    
  }
  PduR_GucLinTpRxIndCount = 0;
  PduR_GucLinTpRxIndCheckCount = 0;
  PduR_GucLinTpTxConfCount = 0;
  PduR_GucLinTpTxConfCheckCount = 0;
  PduR_GucLinTpSorCount = 0;
  PduR_GucLinTpSorCheckCount = 0;
  PduR_GucLinTpCopyRxDataCount = 0;
  PduR_GucLinTpCopyRxDataCheckCount = 0;
  PduR_GucLinTpCopyTxDataCount = 0;
  PduR_GucLinTpCopyTxDataCheckCount = 0;
  PduR_GucLinTpChngeParConfCount = 0;
  PduR_GucLinTpChngeParConfCheckCount = 0;
  for(LucDataCount = 0x00; LucDataCount < PDUR_ARRAY_SIZE; LucDataCount++)
  {
    PduR_GaaLinTpSorRxBuffer[LucDataCount] = 100;
  }
  #endif
  
  #ifdef DCM_MODULE_ACTIVE
  PduR_GddDcmTxRetVal = E_OK;
  PduR_GucDcmSduLength=0;
  PduR_GucDcmPduid=0;
  PduR_GucDcmTxCount=0;
  #endif
  
  #ifdef DLT_MODULE_ACTIVE
  PduR_DltComTransmitRetVal = E_OK;
  PduR_GucDltTxCount = 0;
  PduR_GddDltPduId = 0;
  PduR_GulDltSduLength = 0;
  #endif
  
  #ifdef FRTP_MODULE_ACTIVE
  PduR_GucFrTpRxIndCount = 0;
  PduR_GucFrTpRxIndCheckCount = 0;
  PduR_GucFrTpTxConfCount = 0;
  PduR_GucFrTpTxConfCheckCount = 0;
  PduR_GucFrTpSorCount = 0;
  PduR_GucFrTpSorCheckCount = 0;
  PduR_GucFrTpCopyRxDataCount = 0;
  PduR_GucFrTpCopyRxDataCheckCount = 0;
  PduR_GucFrTpCopyTxDataCount = 0;
  PduR_GucFrTpCopyTxDataCheckCount = 0;
  PduR_GucFrTpChngeParConfCount = 0;
  PduR_GucFrTpChngeParConfCheckCount = 0;
  #endif
 
}/* End TestPduR_DefaultBehavior() */

#ifdef BSWM_MODULE_ACTIVE

/*******************************************************************************
**                      PduR_EnableRouting()                                  **
*******************************************************************************/
void PduR_EnableRouting(PduR_RoutingPathGroupIdType id)
{
  /* Load actual TxPduId into Global variables */
  PduR_Gddid = id;
  PduR_GucEnableRoutingCount++;
} /* End of PduR_EnableRouting() */

/*******************************************************************************
**                     TestPduR_EnableRouting()                               **
*******************************************************************************/
boolean TestPduR_EnableRouting(
  App_DataValidateType LucDataValidate, PduR_RoutingPathGroupIdType LddExpid)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TxPduId */
      if((PduR_GucEnableRoutingCount != 0x00) &&
       (PduR_Gddid == LddExpid))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      PduR_GucEnableRoutingCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End of TestPduR_EnableRouting() */

/*******************************************************************************
**                     PduR_DisableRouting()                                  **
*******************************************************************************/
void PduR_DisableRouting(PduR_RoutingPathGroupIdType id)
{
  /* Load actual TxPduId into Global variables */
  PduR_Gddid = id;
  PduR_GucDisableRoutingCount++;
} /* End ofPduR_DisableRouting() */

/*******************************************************************************
**                     TestPduR_DisableRouting()                              **
*******************************************************************************/
boolean TestPduR_DisableRouting(
  App_DataValidateType LucDataValidate, PduR_RoutingPathGroupIdType LddExpid)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TxPduId */
      if((PduR_GucDisableRoutingCount != 0x00) &&
       ( PduR_Gddid == LddExpid))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      PduR_GucDisableRoutingCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End of TestPduR_DisableRouting() */
#endif

#ifdef DBG_MODULE_ACTIVE

/*******************************************************************************
**                     PduR_DbgTransmit()                                     **
*******************************************************************************/
Std_ReturnType PduR_DbgTransmit(PduIdType LddPduId,
  PduInfoType* LddPduInfo)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8* LpSduDataPtr;

  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  PduR_GddDbgTxPduId = LddPduId;
  PduR_GucDbgTransmitSduLength[PduR_GucDbgTxCount] = (uint8)LddPduInfo->SduLength;
  LpSduDataPtr = LddPduInfo->SduDataPtr;

  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0; LucDataIndex < LddPduInfo->SduLength; LucDataIndex++)
  {
    PduR_GucDbgTransmitSduData[PduR_GucDbgTxCount][LucDataIndex] = 
      *LpSduDataPtr;
    LpSduDataPtr++;
  }
  
  /* Increment count variable to handle multiple invocations */
  if(PduR_GucDbgTxCount != PDUR_ARRAY_SIZE)
  {
    PduR_GucDbgTxCount++;
  }

  #endif
  return(PduR_GddDbgTxRetVal);

} /* End PduR_DbgTransmit()*/

/*******************************************************************************
**                       TestPduR_DbgTransmit()                               **
*******************************************************************************/
boolean TestPduR_DbgTransmit(App_DataValidateType LucDataValidate,
  PduIdType ExpPduId, PduInfoType* ExpPduInfo)
{
  uint8 LucIndex;
  boolean LblRetValue;
  PduInfoType ActPduInfo;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((PduR_GucDbgTxCount == 0x01) && (ExpPduId == PduR_GddDbgTxPduId))
      {
        ActPduInfo.SduLength = PduR_GucDbgTransmitSduLength[0];
        ActPduInfo.SduDataPtr = &PduR_GucDbgTransmitSduData[0][0];

        /* Validate SduLength and Data */
        if(PduRTest_ValidateData(ExpPduInfo, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }

      /* Reset API invocation Count after validating the API invocation */
      PduR_GucDbgTxCount = 0;
      PduR_GucDbgTxCheckCount = 0;      
      break;
    } /* End case S_VALIDATE: */
    
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < PduR_GucDbgTxCount; LucIndex++)
      {
          ActPduInfo.SduLength = PduR_GucDbgTransmitSduLength
            [PduR_GucDbgTxCheckCount];
          ActPduInfo.SduDataPtr = &PduR_GucDbgTransmitSduData
            [PduR_GucDbgTxCheckCount][0];

          /* Validate SduLength and Data */
          if(PduRTest_ValidateData(ExpPduInfo, &ActPduInfo))
          {
            LblRetValue = STEP_PASSED;
          }

          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = PduR_GucDbgTxCount;
      } /* End for(LucIndex = 0; LucIndex < PduR_GucDbgTxCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      PduR_GucDbgTxCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(PduR_GucDbgTxCheckCount == PduR_GucDbgTxCount)
      {
        PduR_GucDbgTxCount = 0;
        PduR_GucDbgTxCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    case S_NOT_INVOKED:
    {
      /* Validate invocation count and Id */
      if((PduR_GucDbgTxCount == 0x00) && (ExpPduId == PduR_GddDbgTxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestPduR_DbgTransmit() */
#endif

#ifdef SOAD_MODULE_ACTIVE
/*******************************************************************************
**                       PduR_SoAdIfTxConfirmation()                         **
*******************************************************************************/
PduIdType GddIfTxConfPduId;
uint8 GucSoAd_IfTxConfirmCnt;
void PduR_SoAdIfTxConfirmation(PduIdType TxPduId)
{
  GddIfTxConfPduId = TxPduId;
  GucSoAd_IfTxConfirmCnt++;
}
/*******************************************************************************
**                       TestPduR_SoAdIfTxConfirmation()                     **
*******************************************************************************/
boolean TestPduR_SoAdIfTxConfirmation(App_DataValidateType LddDataValidate, PduIdType ExpTxPduId)
{
  boolean LblStepResult;
  uint8 LucIndex;
  

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ControllerId */
      if((GucSoAd_IfTxConfirmCnt == 0x01) &&
        (GddIfTxConfPduId == ExpTxPduId))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      GucSoAd_IfTxConfirmCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(GucSoAd_IfTxConfirmCnt == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}
#endif
#ifdef BSWM_MODULE_ACTIVE

/*******************************************************************************
**                          PduR_Init()                                        **
*******************************************************************************/

void PduR_Init(const PduR_PBConfigType* ConfigPtr)
{
	UNUSED(ConfigPtr);
  App_GucApiSeqCnt++;
	PduR_GucInitSeqCnt = App_GucApiSeqCnt;
	PduR_GucInitCnt++;
}/* End PduR_Init() */

/*******************************************************************************
**                           TestPduR_Init()                                  **
*******************************************************************************/
boolean TestPduR_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(PduR_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      PduR_GucInitCnt = 0;
      PduR_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(PduR_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      PduR_GucInitCnt = 0;
      PduR_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestPduR_Init() */

#endif

#ifdef DLT_MODULE_ACTIVE
/*******************************************************************************
**                         PduR_DltComTransmit()                              **
*******************************************************************************/
Std_ReturnType PduR_DltComTransmit(PduIdType id, PduInfoType* info)
{
  #ifndef TYPICAL_CONFIG
  PduR_GddDltPduId = id;
  PduR_GulDltSduLength = info->SduLength;
  PduR_GucDltTxCount++;
  #endif
  return(PduR_DltComTransmitRetVal);
} /* End PduR_IpduMTransmit()*/

/*******************************************************************************
**                         TestPduR_DltComTransmit()                          **
*******************************************************************************/
boolean TestPduR_DltComTransmit(App_DataValidateType LucDataValidate,
  PduIdType id, PduInfoType* info)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((PduR_GucDltTxCount == 0x01) && (id == PduR_GddDltPduId) && 
        ((info->SduLength) == PduR_GulDltSduLength))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      PduR_GucDltTxCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucDltTxCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    
    case M_VALIDATE :
      break;
      
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
    
  }  
  return(LblStepResult);
} /* End TestPduR_DltComTransmit()*/

/*******************************************************************************
**                         PduR_IpduMTriggerTransmit()                        **
*******************************************************************************/
Std_ReturnType PduR_DltComCancelTransmit( PduIdType id )
{
  #ifndef TYPICAL_CONFIG
  PduR_GddDltPduId = id;
  PduR_GucDltTxCount++;
  #endif
  return(PduR_DltComTransmitRetVal);
} /* End PduR_IpduMTriggerTransmit() */

/*******************************************************************************
**                         TestPduR_DltComCancelTransmit()                    **
*******************************************************************************/
boolean TestPduR_DltComCancelTransmit(App_DataValidateType LucDataValidate, 
  PduIdType id)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((PduR_GucDltTxCount == 0x01) && (id == PduR_GddDltPduId))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      PduR_GucDltTxCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(PduR_GucDltTxCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    
    case M_VALIDATE :
      break;
      
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
    
  }  
  return(LblStepResult);
} /* End TestPduR_DltComCancelTransmit() */
#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
