/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Dem_Types.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR DEM Stub                                              **
**                                                                            **
**  PURPOSE   : Declaration of Dem Stub functions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef DEM_TYPES_H
#define DEM_TYPES_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Rte_Dem_Type.h"   /* Rte Header File for Dem Types */
#include "Std_Types.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR SPECIFICATION VERSION */
#define DEM_TYPES_AR_RELEASE_MAJOR_VERSION      4
#define DEM_TYPES_AR_RELEASE_MINOR_VERSION      0
#define DEM_TYPES_AR_RELEASE_REVISION_VERSION   3

/* SOFTWARE VERSION INFORMATION */
#define DEM_TYPES_SW_MAJOR_VERSION       1
#define DEM_TYPES_SW_MINOR_VERSION       0
/*******************************************************************************
**                         Global Data Types                                  **
*******************************************************************************/

typedef uint32 Dem_DTCGroupType;
#define DEM_DTC_GROUP_BODY_DTCS                                   0x8000FF
#define DEM_DTC_GROUP_CHASSIS_DTCS                                0x4000FF
#define DEM_DTC_GROUP_NETWORK_COM_DTCS                            0xC000FF
#define DEM_DTC_GROUP_POWERTRAIN_DTCS                             0x0000FF
#define DEM_DTC_GROUP_EMISSION_REL_DTCS                           0x000000
#define DEM_DTC_GROUP_ALL_DTCS                                    0xFFFFFF

typedef uint8 Dem_DTCKindType;
#define DEM_DTC_KIND_ALL_DTCS                                     0x01
#define DEM_DTC_KIND_EMISSION_REL_DTCS                            0x02

typedef uint8 Dem_DTCOriginType;
#define DEM_DTC_ORIGIN_PRIMARY_MEMORY                             0x01
#define DEM_DTC_ORIGIN_SECONDARY_MEMORY                           0x04
#define DEM_DTC_ORIGIN_MIRROR_MEMORY                              0x02
#define DEM_DTC_ORIGIN_PERMANENT_MEMORY                           0x03

typedef uint8 Dem_DTCRequestType;
#define DEM_FIRST_FAILED_DTC                                      0x01
#define DEM_MOST_RECENT_FAILED_DTC                                0x02
#define DEM_FIRST_DET_CONFIRMED_DTC                               0x03
#define DEM_MOST_REC_DET_CONFIRMED_DTC                            0x04

typedef uint8 Dem_DTCTranslationFormatType;
#define DEM_DTC_TRANSLATION_ISO15031_6                             0x00
#define DEM_DTC_TRANSLATION_ISO14229_1                             0x01
#define DEM_DTC_TRANSLATION_SAEJ1939_73                            0x02
#define DEM_DTC_TRANSLATION_ISO11992_4                             0x03

typedef uint8 Dem_DTCSeverityType;
#define DEM_DTC_SEV_CHECK_AT_NEXT_HALT                            0x02
#define DEM_DTC_SEV_IMMEDIATELY                                   0x04
#define DEM_DTC_SEV_MAINTENANCE_ONLY                              0x08
#define DEM_DTC_SEV_NO_SEVERITY                                   0x00

typedef uint8 Dem_FilterForFDCType;
#define DEM_FILTER_FOR_FDC_YES                                    0x00
#define DEM_FILTER_FOR_FDC_NO                                     0x01

typedef uint8 Dem_FilterWithSeverityType;
#define DEM_FILTER_WITH_SEVERITY_YES                              0x00
#define DEM_FILTER_WITH_SEVERITY_NO                               0x01

typedef uint8 Dem_RatioIdType;

typedef uint8 Dem_ReturnSetFilterType;
#define DEM_FILTER_ACCEPTED                                       0x00
#define DEM_WRONG_FILTER                                          0x01

typedef uint8 Dem_ReturnGetStatusOfDTCType;
#define DEM_STATUS_OK                                             0x00
#define DEM_STATUS_WRONG_DTC                                      0x01
#define DEM_STATUS_WRONG_DTCORIGIN                                0x02
#define DEM_STATUS_FAILED                                         0x03
#define DEM_STATUS_PENDING                                        0x04

typedef uint8 Dem_ReturnGetNextFilteredDTCType;
#define DEM_FILTERED_OK                                           0x00
#define DEM_FILTERED_NO_MATCHING_DTC                              0x01
#define DEM_FILTERED_PENDING                                      0x02

typedef uint8 Dem_ReturnGetNumberOfFilteredDTCType;
#define DEM_NUMBER_OK                                              0x00
#define DEM_NUMBER_FAILED                                          0x01
#define DEM_NUMBER_PENDING                                         0x02

typedef uint8 Dem_ReturnClearDTCType;
#define DEM_CLEAR_OK                                              0x00
#define DEM_CLEAR_WRONG_DTC                                       0x01
#define DEM_CLEAR_WRONG_DTCORIGIN                                 0x02
#define DEM_CLEAR_FAILED                                          0x03
#define DEM_CLEAR_PENDING                                         0x04

typedef uint8 Dem_ReturnControlDTCSettingType;
#define DEM_CONTROL_DTC_SETTING_OK                                0x00
#define DEM_CONTROL_DTC_SETTING_N_OK                              0x01
#define DEM_CONTROL_DTC_WRONG_DTCGROUP                            0x02

typedef uint8 Dem_ReturnDisableDTCRecordUpdateType;
#define DEM_DISABLE_DTCRECUP_OK                                   0x00
#define DEM_DISABLE_DTCRECUP_WRONG_DTC                            0x01
#define DEM_DISABLE_DTCRECUP_WRONG_DTCORIGIN                      0x02
#define DEM_DISABLE_DTCRECUP_PENDING                              0x03

typedef uint8 Dem_ReturnGetFreezeFrameDataByRecordType;
#define DEM_GET_FFBYRECORD_OK                                     0x00
#define DEM_GET_FFBYRECORD_WRONG_RECORD                           0x01
#define DEM_GET_FFBYRECORD_NO_DTC_FOR_RECORD                      0x02

typedef uint8 Dem_ReturnGetExtendedDataRecordByDTCType;
#define DEM_RECORD_OK                                             0x00
#define DEM_RECORD_WRONG_DTC                                      0x01
#define DEM_RECORD_WRONG_DTCORIGIN                                0x02
#define DEM_RECORD_WRONG_NUMBER                                   0x03
#define DEM_RECORD_WRONG_BUFFERSIZE                               0x04
#define DEM_RECORD_PENDING                                        0x05

typedef uint8 Dem_ReturnGetDTCByOccurrenceTimeType;
#define DEM_OCCURR_OK                                             0x00
#define DEM_OCCURR_NOT_AVAILABLE                                  0x01

typedef uint8 Dem_ReturnGetFreezeFrameDataByDTCType;
#define DEM_GET_FFDATABYDTC_OK                                    0x00
#define DEM_GET_FFDATABYDTC_WRONG_DTC                             0x01
#define DEM_GET_FFDATABYDTC_WRONG_DTCORIGIN                       0x02
#define DEM_GET_FFDATABYDTC_WRONG_RECORDNUMBER                    0x03
#define DEM_GET_FFDATABYDTC_WRONG_BUFFERSIZE                      0x04
#define DEM_GET_FFDATABYDTC_PENDING                               0x05

typedef uint8 Dem_ReturnGetSizeOfExtendedDataRecordByDTCType;
#define DEM_GET_SIZEOFEDRBYDTC_OK                                 0x00
#define DEM_GET_SIZEOFEDRBYDTC_W_DTC                              0x01
#define DEM_GET_SIZEOFEDRBYDTC_W_DTCOR                            0x02
#define DEM_GET_SIZEOFEDRBYDTC_W_RNUM                             0x03
#define DEM_GET_SIZEOFEDRBYDTC_PENDING                            0x04

typedef uint8 Dem_ReturnGetSizeOfFreezeFrameByDTCType;
#define DEM_GET_SIZEOFFF_OK                                       0x00
#define DEM_GET_SIZEOFFF_WRONG_DTC                                0x01
#define DEM_GET_SIZEOFFF_WRONG_DTCOR                              0x02
#define DEM_GET_SIZEOFFF_WRONG_RNUM                               0x03
#define DEM_GET_SIZEOFFF_PENDING                                  0x04

typedef uint8 Dem_ReturnGetSeverityOfDTCType;
#define DEM_GET_SEVERITYOFDTC_OK                                  0x00
#define DEM_GET_SEVERITYOFDTC_WRONG_DTC                           0x01
#define DEM_GET_SEVERITYOFDTC_NOSEVERITY                          0x02
#define DEM_GET_SEVERITYOFDTC_PENDING                             0x03

typedef uint8 Dem_ReturnGetFunctionalUnitOfDTCType;
#define DEM_GET_FUNCTIONALUNITOFDTC_OK                            0x00
#define DEM_GET_FUNCTIONALUNITOFDTC_WRONG_DTC                     0x01

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/


#endif /* DEM_TYPES_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
