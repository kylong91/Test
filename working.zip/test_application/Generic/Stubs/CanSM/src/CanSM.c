/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: CanSm.c                                                       **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CanSm Stub                                            **
**                                                                            **
**  PURPOSE   : This application file contains the CanSm  Stub  functions     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "CanSM.h"
#include "Can_GeneralTypes.h"
#include "CanSM_Cbk.h"
#include "CanIf.h"
#include "CanSM_ComM.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 CanSM_GucCntrlBusOffCount;
uint8 CanTrcv_GucChkTrcvWakeFlagIndCount;
uint8 CanTrcv_GucWakeFlagIndCount;
uint8 CanSM_GucCntrlBusOffCheckCount;
uint8 CanSM_GucControllerId;

uint8 CanSM_GucCntrlModeIndiCount;
uint8 CanSM_GucCntrlModeIndiCheckCount;
CanIf_ControllerModeType CanSM_GddControllerMode;

uint8 CanSM_GucTrcvModeIndiCount;
uint8 CanSM_GucTrcvModeIndiCheckCount;
uint8 CanSM_GucTransceiverId;
CanTrcv_TrcvModeType CanSM_GddTransceiverMode;
uint8 CanSM_GucRequestComModeCount;
uint8 CanSM_GucGetCurrentComModeCount;
uint8 CanSM_GucTxTimeoutExceptionCount;
NetworkHandleType CanSM_GddNetwork;

uint8 CanSM_GucCheckTrcvWakeFlagIndiCount;
uint8 CanSM_GucCheckTrcvWakeFlagIndiCheckCount;

uint8 CanSM_GucClearTrcvWakeFlagIndiCount;
uint8 CanSM_GucClearTrcvWakeFlagIndiCheckCount;

uint8 CanSM_GucCnfrmPnCount ;
uint8 CanSM_GucCnfrmPnCheckCount;
#ifdef COMM_MODULE_ACTIVE
ComM_ModeType CanSM_GddComM_Mode;
ComM_ModeType CanSM_GddGetCurComM_Mode;
#endif
Std_ReturnType CanSM_GddGetCurrentRetVal;
Std_ReturnType CanSM_GddReqComRetVal;
uint8 CanTrcv_GucTransceiverID;

#ifdef BSWM_MODULE_ACTIVE
uint8 CanSM_GucInitSeqCnt;
uint8 CanSM_GucInitCnt;
#endif
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
**                     CanSM_CheckTransceiverWakeFlagIndication()             **
*******************************************************************************/
void CanSM_CheckTransceiverWakeFlagIndication(uint8 Transceiver)
{
  /* Load actual Transceiver into Global variables */
  CanTrcv_GucTransceiverID = Transceiver;
  CanTrcv_GucChkTrcvWakeFlagIndCount++;
} /* End CanSM_CheckTransceiverWakeFlagIndication() */

/*******************************************************************************
**                     TestCanSM_CheckTransceiverWakeFlagIndication()         **
*******************************************************************************/
boolean TestCanSM_CheckTransceiverWakeFlagIndication(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count,Transceiver  */
      if((CanTrcv_GucChkTrcvWakeFlagIndCount == 0x01) &&
      (CanTrcv_GucTransceiverID == ExpTransceiver))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucChkTrcvWakeFlagIndCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucChkTrcvWakeFlagIndCount; LucIndex++)
      {
        /* Validate Transceiver */
        if(CanTrcv_GucTransceiverID == ExpTransceiver)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucChkTrcvWakeFlagIndCount;
        }
      }
      /*
      * Reset all the count variables once after verifying the API invocation
      * for maximum number of API invocations
      */
   
      CanTrcv_GucChkTrcvWakeFlagIndCount = 0;
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucChkTrcvWakeFlagIndCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestCanSM_CheckTransceiverWakeFlagIndication() */

/*******************************************************************************
**                     CanSM_ControllerBusOff()                               **
*******************************************************************************/
void CanSM_ControllerBusOff(uint8 ControllerId)
{
  /* Load actual ControllerId into Global variables */
  CanSM_GucControllerId = ControllerId;
  CanSM_GucCntrlBusOffCount++;
} /* End CanSM_ControllerBusOff() */

/*******************************************************************************
**                     TestCanSM_ControllerBusOff()                           **
*******************************************************************************/
boolean TestCanSM_ControllerBusOff(App_DataValidateType LddDataValidate,
  uint8 ExpControllerId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ControllerId */
      if((CanSM_GucCntrlBusOffCount == 0x01) &&
        (CanSM_GucControllerId == ExpControllerId))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanSM_GucCntrlBusOffCount = 0;
      CanSM_GucCntrlBusOffCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanSM_GucCntrlBusOffCount; LucIndex++)
      {
        /* Validate ControllerId */
        if(CanSM_GucControllerId == ExpControllerId)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanSM_GucCntrlBusOffCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanSM_GucCntrlBusOffCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanSM_GucCntrlBusOffCheckCount == CanSM_GucCntrlBusOffCount)
      {
        CanSM_GucCntrlBusOffCount = 0;
        CanSM_GucCntrlBusOffCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanSM_GucCntrlBusOffCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCanSM_ControllerBusOff() */

/*******************************************************************************
**                       CanSM_ControllerModeIndication()                     **
*******************************************************************************/
void CanSM_ControllerModeIndication(uint8 ControllerId,
CanIf_ControllerModeType ControllerMode)
{
  /* Load actual ControllerId and ControllerMode into Global variables */
  CanSM_GucCntrlModeIndiCount++;
  CanSM_GucControllerId = ControllerId;
  CanSM_GddControllerMode = ControllerMode;

} /* End CanSM_ControllerModeIndication() */

/*******************************************************************************
**                   TestCanSM_ControllerModeIndication()                     **
*******************************************************************************/
boolean TestCanSM_ControllerModeIndication(App_DataValidateType LddDataValidate,
  uint8 ExpControllerId, CanIf_ControllerModeType ExpControllerMode)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ControllerId and ControllerMode */
      if((CanSM_GucCntrlModeIndiCount == 0x01) &&
        (CanSM_GucControllerId == ExpControllerId) &&
        (CanSM_GddControllerMode == ExpControllerMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanSM_GucCntrlModeIndiCount = 0;
      CanSM_GucCntrlModeIndiCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanSM_GucCntrlModeIndiCount; LucIndex++)
      {
        /* Validate ControllerId and ControllerMode */
        if((CanSM_GucControllerId == ExpControllerId) &&
          (CanSM_GddControllerMode == ExpControllerMode))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanSM_GucCntrlModeIndiCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanSM_GucCntrlModeIndiCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanSM_GucCntrlModeIndiCheckCount == CanSM_GucCntrlModeIndiCount)
      {
        CanSM_GucCntrlModeIndiCount = 0;
        CanSM_GucCntrlModeIndiCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanSM_GucCntrlModeIndiCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCanSM_ControllerModeIndication */

/*******************************************************************************
**                    CanSM_TransceiverModeIndication()                       **
*******************************************************************************/
void CanSM_TransceiverModeIndication(uint8 TransceiverId,
CanTrcv_TrcvModeType TransceiverMode)
{
  /* Load actual TransceiverId and TransceiverMode into Global variables */
  CanSM_GucTransceiverId = TransceiverId;
  CanSM_GddTransceiverMode = TransceiverMode;
  CanSM_GucTrcvModeIndiCount++;
} /* End CanSM_TrcvModeIndication() */

/*******************************************************************************
**                   TestCanSM_TransceiverModeIndication()                    **
*******************************************************************************/
boolean TestCanSM_TransceiverModeIndication(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiverId, CanTrcv_TrcvModeType ExpTransceiverMode)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TransceiverId and TransceiverMode */
      if((CanSM_GucTrcvModeIndiCount == 0x01) &&
        (CanSM_GucTransceiverId == ExpTransceiverId) &&
        (CanSM_GddTransceiverMode == ExpTransceiverMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanSM_GucTrcvModeIndiCount = 0;
      CanSM_GucTrcvModeIndiCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanSM_GucTrcvModeIndiCount; LucIndex++)
      {
        /* Validate TransceiverId and TransceiverMode */
        if((CanSM_GucTransceiverId == ExpTransceiverId) &&
          (CanSM_GddTransceiverMode == ExpTransceiverMode))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanSM_GucTrcvModeIndiCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanSM_GucTrcvModeIndiCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanSM_GucTrcvModeIndiCheckCount == CanSM_GucTrcvModeIndiCount)
        {
        CanSM_GucTrcvModeIndiCount = 0;
        CanSM_GucTrcvModeIndiCheckCount = 0;
        }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanSM_GucTrcvModeIndiCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCanSM_TransceiverModeIndication */

/*******************************************************************************
**                       CanSM_RequestComMode()                               **
*******************************************************************************/
#ifdef COMM_MODULE_ACTIVE
Std_ReturnType CanSM_RequestComMode(NetworkHandleType network, 
  ComM_ModeType ComM_Mode)
{
  #ifndef TYPICAL_CONFIG
  CanSM_GucRequestComModeCount++;
  CanSM_GddNetwork = network;
  CanSM_GddComM_Mode = ComM_Mode;
  #endif
  return(CanSM_GddReqComRetVal);
}/* End CanSM_RequestComMode() */

/*******************************************************************************
**                       TestCanSM_RequestComMode()                           **
*******************************************************************************/
boolean TestCanSM_RequestComMode(App_DataValidateType LucDataValidate, 
  NetworkHandleType LddExpnetwork, ComM_ModeType LddExpComM_Mode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Network and CurrentState */
      if((CanSM_GucRequestComModeCount == 0x01) &&
        (CanSM_GddNetwork == LddExpnetwork) &&
        (CanSM_GddComM_Mode == LddExpComM_Mode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanSM_GucRequestComModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanSM_GucRequestComModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestCanSM_RequestComMode() */

/*******************************************************************************
**                       TestCanSM_GetCurrentComModeSetMode()                   **
*******************************************************************************/

void TestCanSM_GetCurrentComModeSetMode(ComM_ModeType LddComMMode)
{
  CanSM_GddGetCurComM_Mode = LddComMMode;
}/* End TestCanSM_GetCurrentComModeSetMode() */

/*******************************************************************************
**                       CanSM_GetCurrentComMode()                            **
*******************************************************************************/

Std_ReturnType CanSM_GetCurrentComMode(NetworkHandleType network, 
  P2VAR(ComM_ModeType, AUTOMATIC, COMM_APPL_DATA)ComM_ModePtr)
{
  #ifndef TYPICAL_CONFIG
  CanSM_GucGetCurrentComModeCount++;
  CanSM_GddNetwork = network;
  *ComM_ModePtr = CanSM_GddGetCurComM_Mode;
  #endif
  return(CanSM_GddGetCurrentRetVal);
}/* End CanSM_GetCurrentComMode() */

/*******************************************************************************
**                       TestCanSM_GetCurrentComMode()                        **
*******************************************************************************/
boolean TestCanSM_GetCurrentComMode(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpnetwork, P2VAR(ComM_ModeType, AUTOMATIC, COMM_APPL_DATA)
  LddExpComM_ModePtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((CanSM_GucGetCurrentComModeCount != 0x00) && 
        (CanSM_GddNetwork == LddExpnetwork) && 
        (CanSM_GddGetCurComM_Mode == *LddExpComM_ModePtr))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      CanSM_GucGetCurrentComModeCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanSM_GetCurrentComMode() */
#endif

/*******************************************************************************
**                   TestCanSM_CheckTrcvWakeFlagIndication()                  **
*******************************************************************************/
boolean TestCanSM_CheckTrcvWakeFlagIndication(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiverId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TransceiverId and TransceiverMode */
      if((CanSM_GucCheckTrcvWakeFlagIndiCount == 0x01) &&
        (CanSM_GucTransceiverId == ExpTransceiverId))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanSM_GucCheckTrcvWakeFlagIndiCount = 0;
      CanSM_GucCheckTrcvWakeFlagIndiCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanSM_GucCheckTrcvWakeFlagIndiCount; LucIndex++)
      {
        /* Validate TransceiverId and TransceiverMode */
        if(CanSM_GucTransceiverId == ExpTransceiverId)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanSM_GucCheckTrcvWakeFlagIndiCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanSM_GucCheckTrcvWakeFlagIndiCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanSM_GucCheckTrcvWakeFlagIndiCheckCount == CanSM_GucCheckTrcvWakeFlagIndiCount)
        {
        CanSM_GucCheckTrcvWakeFlagIndiCount = 0;
        CanSM_GucCheckTrcvWakeFlagIndiCheckCount = 0;
        }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanSM_GucCheckTrcvWakeFlagIndiCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCanSM_TransceiverModeIndication */

/*******************************************************************************
**                    CanSM_ClearTrcvWufFlagIndication()                      **
*******************************************************************************/
void CanSM_ClearTrcvWufFlagIndication(uint8 TransceiverId)
{
  /* Load actual TransceiverId and TransceiverMode into Global variables */
  CanSM_GucTransceiverId = TransceiverId;
  CanSM_GucClearTrcvWakeFlagIndiCount++;
} /* End CanSM_ClearTrcvWufFlagIndication() */

/*******************************************************************************
**                   TestCanSm_ClearTrcvWufFlagIndication()                   **
*******************************************************************************/
boolean TestCanSM_ClearTrcvWufFlagIndication(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiverId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TransceiverId and TransceiverMode */
      if((CanSM_GucClearTrcvWakeFlagIndiCount == 0x01) &&
        (CanSM_GucTransceiverId == ExpTransceiverId))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanSM_GucClearTrcvWakeFlagIndiCount = 0;
      CanSM_GucClearTrcvWakeFlagIndiCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanSM_GucClearTrcvWakeFlagIndiCount; LucIndex++)
      {
        /* Validate TransceiverId and TransceiverMode */
        if(CanSM_GucTransceiverId == ExpTransceiverId)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanSM_GucClearTrcvWakeFlagIndiCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanSM_GucClearTrcvWakeFlagIndiCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanSM_GucClearTrcvWakeFlagIndiCheckCount == CanSM_GucClearTrcvWakeFlagIndiCount)
        {
        CanSM_GucClearTrcvWakeFlagIndiCount = 0;
        CanSM_GucClearTrcvWakeFlagIndiCheckCount = 0;
        }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanSM_GucClearTrcvWakeFlagIndiCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCanSM_TransceiverModeIndication */


/*******************************************************************************
**                    CanSm_ConfirmPnAvailability()                           **
*******************************************************************************/
void CanSM_ConfirmPnAvailability(uint8 TransceiverId)
{
  /* Load actual TransceiverId and TransceiverMode into Global variables */
  CanSM_GucTransceiverId = TransceiverId;
  CanSM_GucCnfrmPnCount++;
} /* End CanSm_ConfirmPnAvailability() */

/*******************************************************************************
**                   TestCanSm_ConfirmPnAvailability()                        **
*******************************************************************************/
boolean TestCanSM_ConfirmPnAvailability(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiverId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TransceiverId and TransceiverMode */
      if((CanSM_GucCnfrmPnCount == 0x01) &&
        (CanSM_GucTransceiverId == ExpTransceiverId))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanSM_GucCnfrmPnCount = 0;
      CanSM_GucCnfrmPnCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanSM_GucCnfrmPnCount; LucIndex++)
      {
        /* Validate TransceiverId and TransceiverMode */
        if(CanSM_GucTransceiverId == ExpTransceiverId)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanSM_GucCnfrmPnCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanSM_GucCnfrmPnCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanSM_GucCnfrmPnCheckCount == CanSM_GucCnfrmPnCount)
        {
        CanSM_GucCnfrmPnCount = 0;
        CanSM_GucCnfrmPnCheckCount = 0;
        }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanSM_GucCnfrmPnCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCanSM_TransceiverModeIndication */

/*******************************************************************************
**                       CanSM_TxTimeoutException()                            **
*******************************************************************************/

void CanSM_TxTimeoutException(NetworkHandleType network)
{   
  #ifndef TYPICAL_CONFIG
  CanSM_GucTxTimeoutExceptionCount++;
  CanSM_GddNetwork = network;
  #endif
}/* End CanSM_GetCurrentComMode() */

/*******************************************************************************
**                       TestCanSM_TxTimeoutException()                        **
*******************************************************************************/
boolean TestCanSM_TxTimeoutException(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpnetwork)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((CanSM_GucTxTimeoutExceptionCount != 0x00) && 
        (CanSM_GddNetwork == LddExpnetwork))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      CanSM_GucTxTimeoutExceptionCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanSM_TxTimeoutException() */

/*******************************************************************************
**                        TestCanSM_DefaultBehavior()                         **
*******************************************************************************/
void TestCanSM_DefaultBehavior(void)
{
  CanSM_GucCntrlBusOffCount = 0;
  CanTrcv_GucChkTrcvWakeFlagIndCount = 0;
  CanTrcv_GucWakeFlagIndCount = 0;
  CanSM_GucCntrlBusOffCheckCount = 0;
  CanSM_GucCntrlModeIndiCount = 0;
  CanSM_GucCntrlModeIndiCheckCount = 0;
  CanSM_GucTrcvModeIndiCount = 0;
  CanSM_GucTrcvModeIndiCheckCount = 0;
  CanSM_GucCheckTrcvWakeFlagIndiCount = 0;
  CanSM_GucClearTrcvWakeFlagIndiCount = 0;
  CanSM_GucCnfrmPnCount = 0;
  CanSM_GucCheckTrcvWakeFlagIndiCheckCount = 0;
  CanSM_GucClearTrcvWakeFlagIndiCheckCount = 0;
  CanSM_GucCnfrmPnCheckCount = 0;
  
  CanSM_GucGetCurrentComModeCount = 0;
  CanSM_GucTxTimeoutExceptionCount = 0;
  CanSM_GucRequestComModeCount = 0;
  #ifdef COMM_MODULE_ACTIVE
  CanSM_GddGetCurComM_Mode = COMM_NO_COMMUNICATION;
  #endif
  CanSM_GddReqComRetVal = 0;
  CanSM_GddGetCurrentRetVal = 0;
}

/*******************************************************************************
**                         TestCanSM_SetBehavior()                         **
*******************************************************************************/
void TestCanSM_RequestComModeSetBeh(Std_ReturnType LddReturnVal)
{
  CanSM_GucGetCurrentComModeCount = 0;
  CanSM_GucRequestComModeCount = 0;
  CanSM_GddReqComRetVal = LddReturnVal;
}

void TestCanSM_GetCurrentComModeSetBeh(Std_ReturnType LddReturnVal)
{
  CanSM_GucGetCurrentComModeCount = 0;
  CanSM_GucRequestComModeCount = 0;
  CanSM_GddGetCurrentRetVal = LddReturnVal;
}

#ifdef BSWM_MODULE_ACTIVE

/*******************************************************************************
**                          CanSM_Init()                                      **
*******************************************************************************/

void CanSM_Init(const CanSM_ConfigType* ConfigPtr)
{
  UNUSED(ConfigPtr);
	App_GucApiSeqCnt++;
	CanSM_GucInitSeqCnt = App_GucApiSeqCnt;
	CanSM_GucInitCnt++;
}/* End CanSM_Init() */

/*******************************************************************************
**                           TestCanSM_Init()                                 **
*******************************************************************************/
boolean TestCanSM_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(CanSM_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      CanSM_GucInitCnt = 0;
      CanSM_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(CanSM_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      CanSM_GucInitCnt = 0;
      CanSM_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanSM_Init() */

#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

