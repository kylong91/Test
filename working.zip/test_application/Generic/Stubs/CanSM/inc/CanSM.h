/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: CanSM.h                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CanSM Stub                                            **
**                                                                            **
**  PURPOSE   : Declaration of CanSM Stub functions                           **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef CANSM_H
#define CANSM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"            /* Com Stack header */
#include "TC_Generic.h"
#include "ComM.h"
/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define CANSM_AR_RELEASE_MAJOR_VERSION  4
#define CANSM_AR_RELEASE_MINOR_VERSION  0
#define CANSM_AR_RELEASE_REVISION_VERSION  2

/* Software Version Information */
#define CANSM_SW_MAJOR_VERSION  4
#define CANSM_SW_MINOR_VERSION  0

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
typedef uint8 CanSM_ConfigType;

/* This is used to notify the BswM module (Can specific communication modes) */
typedef enum
{
  CANSM_BSWM_NO_COMMUNICATION,
  CANSM_BSWM_CHANGE_BAUDRATE,
  CANSM_BSWM_SILENT_COMMUNICATION,
  CANSM_BSWM_FULL_COMMUNICATION,
  CANSM_BSWM_BUS_OFF,
  CANSM_BSWM_BUS_OFF_LEVEL1,
  CANSM_BSWM_BUS_OFF_LEVEL2
} CanSM_BswMCurrentStateType;


/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern void TestCanSM_DefaultBehavior(void);
extern void CanSM_TxTimeoutException(NetworkHandleType network);
extern boolean TestCanSM_TxTimeoutException(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpnetwork);
  
extern void CanSM_Init(const CanSM_ConfigType* ConfigPtr);

extern boolean TestCanSM_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);  
#endif /* CANSM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

