/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: CanSM_Cbk.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CanSM_Cbk Stub                                        **
**                                                                            **
**  PURPOSE   : Declaration of CanSM_Cbk Stub functions                       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef CANSM_CBK_H
#define CANSM_CBK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
#include "Can_GeneralTypes.h"
#include "CanIf.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/


/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void CanSM_ConfirmPnAvailability(uint8 TransceiverId);
extern void CanSM_CheckTransceiverWakeFlagIndication(uint8 Transceiver);

extern boolean TestCanSM_CheckTransceiverWakeFlagIndication(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver);

extern boolean TestCanSM_ConfirmPnAvailability(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiverId);
extern void CanSM_ControllerBusOff(uint8 ControllerId);

extern void CanSM_ControllerModeIndication(uint8 ControllerId,
  CanIf_ControllerModeType ControllerMode);

extern void CanSM_TransceiverModeIndication(uint8 TransceiverId,
  CanTrcv_TrcvModeType TransceiverMode);
  
extern void CanSM_CheckTrcvWakeFlagIndication(uint8 TransceiverId);
  
extern void CanSM_ClearTrcvWufFlagIndication(uint8 TransceiverId);

extern boolean TestCanSM_ControllerBusOff(App_DataValidateType LddDataValidate,
  uint8 ExpControllerId);

extern boolean TestCanSM_ControllerModeIndication(
  App_DataValidateType LddDataValidate, uint8 ExpControllerId,
  CanIf_ControllerModeType ExpControllerMode);

extern boolean TestCanSM_TransceiverModeIndication(
  App_DataValidateType LddDataValidate, uint8 ExpTransceiverId,
  CanTrcv_TrcvModeType ExpTransceiverMode);
  
extern boolean TestCanSM_CheckTrcvWakeFlagIndication(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiverId);
  
extern boolean TestCanSM_ClearTrcvWufFlagIndication(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiverId);

#endif /* CANSM_CBK_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
