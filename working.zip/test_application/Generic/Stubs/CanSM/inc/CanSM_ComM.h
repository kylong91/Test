/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: CanSM_ComM.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CanSM_ComM Stub                                       **
**                                                                            **
**  PURPOSE   : Declaration of  CanSM_ComM Stub functions                     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef CANSM_COMM_H
#define CANSM_COMM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define CANSM_COMM_H_AR_MAJOR_VERSION  4
#define CANSM_COMM_H_AR_MINOR_VERSION  0
#define CANSM_COMM_H_AR_RELEASE_REVISION_VERSION  2

/* Software Version Information */
#define CANSM_COMM_H_SW_MAJOR_VERSION  4
#define CANSM_COMM_H_SW_MINOR_VERSION  0

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
extern uint8 CanSM_GucRequestComModeCount;
extern uint8 CanSM_GucGetCurrentComModeCount;
extern NetworkHandleType CanSM_GddNetwork;
extern ComM_ModeType CanSM_GddGetCurComM_Mode;
extern Std_ReturnType CanSM_GddReqComRetVal;
extern Std_ReturnType CanSM_GddGetCurrentRetVal;
extern ComM_ModeType CanSM_GddComM_Mode;
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Std_ReturnType CanSM_RequestComMode( NetworkHandleType network, 
  ComM_ModeType ComM_Mode);
extern Std_ReturnType CanSM_GetCurrentComMode(NetworkHandleType network, 
  P2VAR(ComM_ModeType, AUTOMATIC, COMM_APPL_DATA)ComM_ModePtr);

extern boolean TestCanSM_RequestComMode(App_DataValidateType LucDataValidate, 
  NetworkHandleType LddExpnetwork, ComM_ModeType LddExpComM_Mode);
extern boolean TestCanSM_GetCurrentComMode(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpnetwork, P2VAR(ComM_ModeType, AUTOMATIC, COMM_APPL_DATA)
  LddExpComM_ModePtr);              
  
extern void TestCanSM_GetCurrentComModeSetMode(ComM_ModeType LddComMMode);
extern void TestCanSM_RequestComModeSetBeh(Std_ReturnType LddReturnVal);
extern void TestCanSM_GetCurrentComModeSetBeh(Std_ReturnType LddReturnVal);
#endif /* CANSM_COMM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

