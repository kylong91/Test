/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: CanNm_Cbk.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CanNm Module                                          **
**                                                                            **
**  PURPOSE   : Declaration of CanNm Stub functions                           **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef CANNM_CBK_H
#define CANNM_CBK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void CanNm_TxConfirmation(PduIdType TxPduId);

extern void CanNm_RxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr);

extern boolean TestCanNm_TxConfirmation(App_DataValidateType LddDataValidate,
  PduIdType ExpTxPduId);

extern boolean TestCanNm_RxIndication(App_DataValidateType LddDataValidate,
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr);

extern boolean CanNmTest_ValidateData(PduInfoType* LddExpPduInfo, 
  PduInfoType* LddActPduInfo);

#endif /* CANNM_CBK_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
