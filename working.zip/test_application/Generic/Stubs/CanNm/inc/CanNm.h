/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: CanNm.h                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CanNm Module                                          **
**                                                                            **
**  PURPOSE   : Declaration of CanNm Stub functions                           **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

#ifndef CANNM_H
#define CANNM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"
#include "NmStack_Types.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define CANNM_AR_RELEASE_MAJOR_VERSION    4
#define CANNM_AR_RELEASE_MINOR_VERSION    0
#define CANNM_AR_RELEASE_REVISION_VERSION   3

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
typedef uint8 CanNm_ConfigType;

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define CANNM_ARRAY_SIZE                  0x08
#define CANNM_DATA_LENGTH                 0x08
/*******************************************************************************
**                      Function Prototype                                    **
*******************************************************************************/
extern Std_ReturnType CanNm_PassiveStartUp(const NetworkHandleType 
  nmChannelHandle); 

extern  boolean TestCanNm_PassiveStartUp(App_DataValidateType LucDataValidate, 
  const NetworkHandleType LddExpChannelHandle); 
  
extern void TestCanNm_PassiveStartSetRetVal(Std_ReturnType ReturnValue);

extern Std_ReturnType CanNm_NetworkRequest(const NetworkHandleType 
  nmChannelHandle);

extern  boolean TestCanNm_NetworkRequest(App_DataValidateType LucDataValidate, 
  const NetworkHandleType LddExpChannelHandle); 
  
extern void TestCanNm_NetworkReqSetRetVal(Std_ReturnType ReturnValue);  

extern Std_ReturnType CanNm_NetworkRelease(const NetworkHandleType 
  nmChannelHandle);

extern  boolean TestCanNm_NetworkRelease(App_DataValidateType LucDataValidate, 
const NetworkHandleType LddExpChannelHandle);

extern void TestCanNm_NetworkRelSetRetVal(Std_ReturnType ReturnValue);

extern Std_ReturnType CanNm_DisableCommunication(const NetworkHandleType 
  nmChannelHandle);

extern  boolean TestCanNm_DisableCommunication(App_DataValidateType 
  LucDataValidate, const NetworkHandleType LddExpChannelHandle);
  
extern void TestCanNm_DisableCommnSetRetVal(Std_ReturnType ReturnValue);

extern Std_ReturnType CanNm_EnableCommunication(const NetworkHandleType 
  nmChannelHandle);

extern  boolean TestCanNm_EnableCommunication (App_DataValidateType 
  LucDataValidate, const NetworkHandleType LddExpChannelHandle);
  
extern void TestCanNm_EnableCommnSetRetVal(Std_ReturnType ReturnValue);

extern Std_ReturnType CanNm_RepeatMessageRequest(const NetworkHandleType 
  nmChannelHandle);
  
extern  boolean TestCanNm_RepeatMessageRequest(App_DataValidateType 
  LucDataValidate, const NetworkHandleType LddExpChannelHandle); 
  
extern void TestCanNm_RptMsgReqSetRetVal(Std_ReturnType ReturnValue);

extern Std_ReturnType CanNm_SetUserData(const NetworkHandleType nmChannelHandle, 
  const uint8 * const nmUserDataPtr);

extern  boolean TestCanNm_SetUserData (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle, const uint8 * const ExpUserDataPtr);

extern Std_ReturnType CanNm_GetUserData(const NetworkHandleType nmChannelHandle,
uint8 * const nmUserDataPtr);

extern  boolean TestCanNm_GetUserData (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle);
  
extern void TestCanNm_GetUserDataSetVal(Std_ReturnType RetVal, uint8 UserData);

extern Std_ReturnType CanNm_GetPduData(const NetworkHandleType nmChannelHandle,
  uint8 * const nmPduData);

extern  boolean TestCanNm_GetPduData (App_DataValidateType LucDataValidate, 
  const NetworkHandleType ExpChannelHandle);
  
extern void TestCanNm_GetPduDataSetVal(Std_ReturnType RetVal, uint8 PduData);

extern Std_ReturnType CanNm_GetNodeIdentifier(const NetworkHandleType 
  nmChannelHandle, uint8 * const nmNodeIdPtr);

extern  boolean TestCanNm_GetNodeIdentifier(App_DataValidateType 
  LucDataValidate, const NetworkHandleType ExpChannelHandle);
  
extern void TestCanNm_GetNodeIdDataSetVal(Std_ReturnType RetVal, uint8 NodeId);

extern Std_ReturnType CanNm_GetLocalNodeIdentifier(const NetworkHandleType 
  nmChannelHandle,uint8 * const nmNodeIdPtr);
         
extern  boolean TestCanNm_GetLocalNodeIdentifier(App_DataValidateType 
  LucDataValidate, const NetworkHandleType ExpChannelHandle);
  
extern void TestCanNm_GetLocalNodeIdDataSetVal(Std_ReturnType RetVal, uint8 NodeId);

extern Std_ReturnType CanNm_CheckRemoteSleepIndication(const NetworkHandleType 
nmChannelHandle, boolean * const nmRemoteSleepIndPtr);

extern  boolean TestCanNm_CheckRemoteSleepIndication(App_DataValidateType 
  LucDataValidate, const NetworkHandleType ExpChannelHandle);
  
extern void TestCanNm_CheckRemSleepIndDataSetVal(Std_ReturnType RetVal, 
  boolean SleepInd);
  
extern Std_ReturnType CanNm_GetState(const NetworkHandleType nmChannelHandle,
  Nm_StateType * const nmStatePtr,Nm_ModeType * const nmModePtr);
 
extern  boolean TestCanNm_GetState(App_DataValidateType LucDataValidate, 
  const NetworkHandleType ExpChannelHandle);
  
extern void TestCanNm_GetStateDataSetVal(Std_ReturnType RetVal, Nm_StateType State, 
  Nm_ModeType Mode);

extern Std_ReturnType CanNm_RequestBusSynchronization
  (const NetworkHandleType nmChannelHandle);

extern boolean TestCanNm_RequestBusSynchronization (App_DataValidateType 
  LucDataValidate, const NetworkHandleType ExpChannelHandle);
  
extern void TestCanNm_ReqBusSynchSetRetVal(Std_ReturnType ReturnValue);

extern void TestCanNm_ModeSetUp(Nm_ModeType Mode);
 
extern void TestCanNm_DefaultBehavior(void);

extern Std_ReturnType CanNm_SetSleepReadyBit(const NetworkHandleType
  nmChannelHandle, const boolean nmSleepReadyBit);
extern boolean TestCanNm_SetSleepReadyBit(App_DataValidateType
  LucDataValidate, const NetworkHandleType ExpChannelHandle, 
  const boolean ExpnmSleepReadyBit);

extern void CanNm_ConfirmPnAvailability( const NetworkHandleType nmChannelHandle);
extern void CanNm_Init(const CanNm_ConfigType* const cannmConfigPtr);
extern boolean TestCanNm_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
#endif /* CANNM_H */

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
