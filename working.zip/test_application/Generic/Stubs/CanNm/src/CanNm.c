/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: CanNm.c                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CanNm Stub                                            **
**                                                                            **
**  PURPOSE   : This application file contains the CanNm Stub functions       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "CanNm.h"
#include "CanNm_Cbk.h"
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
NetworkHandleType CanNm_GddPassStartChnlHandle;
NetworkHandleType CanNm_GddNwReqChnlHandle;
NetworkHandleType CanNm_GddNwRelChnlHandle;
NetworkHandleType CanNm_GddDisCommnChnlHandle;
NetworkHandleType CanNm_GddEnCommnChnlHandle;
NetworkHandleType CanNm_GddSetUserDataChnlHandle;
NetworkHandleType CanNm_GddGetUserDataChnlHandle;
NetworkHandleType CanNm_GddRptMsgReqChnlHandle;
NetworkHandleType CanNm_GddGetNodeIdChnlHandle;
NetworkHandleType CanNm_GddGetLocNodeIdChnlHandle;
NetworkHandleType CanNm_GddCheckRemSleepIndChnlHandle;
NetworkHandleType CanNm_GddGetStateIndChnlHandle;
NetworkHandleType CanNm_GddReqBusSynchChnlHandle;
NetworkHandleType CanNm_GddGetPduDataChnlHandle;
NetworkHandleType CanNm_GddReqExpulChnlHandle;
#ifdef NM_MODULE_ACTIVE
NetworkHandleType CanNm_GddSetSleepBitChnlHandle;
#endif
uint8 CanNm_GucSetUserData;
boolean * CanNm_GblRemoteSleepIndPtr;
Nm_StateType * CanNm_GddStatePtr;
Nm_ModeType * CanNm_GddModePtr;
uint8 CanNm_GucPassiveStartCount;
uint8 CanNm_GucNetworkReqCount;
uint8 CanNm_GucNetworkRelCount;
uint8 CanNm_GucDisableCommnCount;
uint8 CanNm_GucEnableCommnCount;
uint8 CanNm_GucRptMsgReqCount;
uint8 CanNm_GucSetUserDataCount;
uint8 CanNm_GucGetUserDataCount;
uint8 CanNm_GucGetPduDataCount;
uint8 CanNm_GucGetNodeIdCount;
uint8 CanNm_GucGetLocalNodeIdCount;
uint8 CanNm_GucCheckRemSleepIndCount;
uint8 CanNm_GucGetStateCount;
uint8 CanNm_GucReqBusSynchCount;
uint8 CanNm_GucReqExpulCount;
#ifdef NM_MODULE_ACTIVE
uint8 CanNm_GucSetSleepBitCount;
uint8 CanNm_GddSetSleepBitRetVal;
#endif
Std_ReturnType CanNm_GddPassiveStartRetVal;
Std_ReturnType CanNm_GddNetworkReqRetVal;
Std_ReturnType CanNm_GddNetworkRelRetVal;
Std_ReturnType CanNm_GddDisableCommnRetVal;
Std_ReturnType CanNm_GddEnableCommnRetVal;
Std_ReturnType CanNm_GddRptMsgReqRetVal;
Std_ReturnType CanNm_GddSetUserDataRetVal;
Std_ReturnType CanNm_GddGetUserDataRetVal;
Std_ReturnType CanNm_GddGetPduDataRetVal;
Std_ReturnType CanNm_GddGetNodeIdRetVal;
Std_ReturnType CanNm_GddGetLocalNodeIdRetVal;
Std_ReturnType CanNm_GddCheckRemSleepIndRetVal;
Std_ReturnType CanNm_GddGetStateRetVal;
Std_ReturnType CanNm_GddReqBusSynchRetVal;
Std_ReturnType CanNm_GddReqExpulRetVal;
uint8 CanNm_GucGetUserData;
uint8 CanNm_GucPduData;
uint8 CanNm_GucNodeId;
uint8 CanNm_GucLocalNodeId;
boolean CanNm_GblRemSleep;
#ifdef NM_MODULE_ACTIVE
boolean CanNm_GblnmSleepReadyBit;
#endif
Nm_StateType CanNm_GddState;
Nm_ModeType CanNm_GddMode;

#ifdef BSWM_MODULE_ACTIVE
uint8 CanNm_GucInitCnt;
uint8 CanNm_GucInitSeqCnt;
#endif

/* Variables used for CanIf module */
uint8 CanNm_GucTxConfirmCount;
uint8 CanNm_GucTxConfirmCheckCount;
PduIdType CanNm_GucTxPduId;
uint8 CanNm_GucRxIndiCount;
PduIdType CanNm_GucRxPduId;
uint8 CanNm_GaaRxIndSduData[CANNM_DATA_LENGTH];
uint8 CanNm_GucRxIndSduLength;
/******************************************************************************/
/*             CanNm_PassiveStartUp                                           */
/*****************************************************************************/
Std_ReturnType CanNm_PassiveStartUp(const NetworkHandleType nmChannelHandle)
{
  CanNm_GddPassStartChnlHandle = nmChannelHandle;
  CanNm_GucPassiveStartCount++;
  return(CanNm_GddPassiveStartRetVal);
}
/*******************************************************************************
**                       TestCanNm_PassiveStartUp ()                          **
*******************************************************************************/
boolean TestCanNm_PassiveStartUp (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((CanNm_GucPassiveStartCount == 0x01)&&
        (ExpChannelHandle == CanNm_GddPassStartChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      CanNm_GucPassiveStartCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanNm_PassiveStartUp() */
/*******************************************************************************
**                       TestCanNm_PassiveStartSetRetVal()                    **
*******************************************************************************/
void TestCanNm_PassiveStartSetRetVal(Std_ReturnType ReturnValue)
{
  CanNm_GddPassiveStartRetVal = ReturnValue;
} /* End TestCanNm_PassiveStartSetRetVal() */
/******************************************************************************/
/*                       CanNm_NetworkRequest()                               */
/******************************************************************************/
Std_ReturnType CanNm_NetworkRequest(const NetworkHandleType nmChannelHandle)
{
  CanNm_GddNwReqChnlHandle = nmChannelHandle;
  CanNm_GucNetworkReqCount++;
  return(CanNm_GddNetworkReqRetVal);
}
/*******************************************************************************
**                       TestCanNm_NetworkRequest ()                          **
*******************************************************************************/
boolean TestCanNm_NetworkRequest (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((CanNm_GucNetworkReqCount == 0x01)&&
        (ExpChannelHandle == CanNm_GddNwReqChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      CanNm_GucNetworkReqCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanNm_NetworkRequest() */
/*******************************************************************************
**                       TestCanNm_NetworkReqSetRetVal()                **
*******************************************************************************/
void TestCanNm_NetworkReqSetRetVal(Std_ReturnType ReturnValue)
{
  CanNm_GddNetworkReqRetVal = ReturnValue;
} /* End TestCanNm_NetworkReqSetRetVal() */
/******************************************************************************/
/*                       CanNm_NetworkRelease()                               */
/******************************************************************************/
Std_ReturnType CanNm_NetworkRelease(const NetworkHandleType nmChannelHandle)
{
  CanNm_GddNwRelChnlHandle = nmChannelHandle;
  CanNm_GucNetworkRelCount++;
  return(CanNm_GddNetworkRelRetVal);
} /* End CanNm_NetworkRelease() */
/*******************************************************************************
**                       TestCanNm_NetworkRelease ()                          **
*******************************************************************************/
boolean TestCanNm_NetworkRelease (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((CanNm_GucNetworkRelCount == 0x01)&&
        (ExpChannelHandle == CanNm_GddNwRelChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      CanNm_GucNetworkRelCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanNm_GucNetworkRelCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanNm_NetworkRelease() */
/*******************************************************************************
**                       TestCanNm_NetworkRelSetRetVal()                      **
*******************************************************************************/
void TestCanNm_NetworkRelSetRetVal(Std_ReturnType ReturnValue)
{
  CanNm_GddNetworkRelRetVal = ReturnValue;
} /* End TestCanNm_NetworkRelSetRetVal() */
/******************************************************************************/
/*                       CanNm_DisableCommunication()                         */
/******************************************************************************/
Std_ReturnType CanNm_DisableCommunication(const NetworkHandleType
  nmChannelHandle)
{
  CanNm_GddDisCommnChnlHandle = nmChannelHandle;
  CanNm_GucDisableCommnCount++;
  return(CanNm_GddDisableCommnRetVal);
} /* End CanNm_DisableCommunication() */
/*******************************************************************************
**                       TestCanNm_DisableCommunication()                     **
*******************************************************************************/
boolean TestCanNm_DisableCommunication (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((CanNm_GucDisableCommnCount == 0x01)&&
        (ExpChannelHandle == CanNm_GddDisCommnChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      CanNm_GucDisableCommnCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanNm_DisableCommunication() */
/*******************************************************************************
**                       TestCanNm_DisableCommnSetRetVal()                    **
*******************************************************************************/
void TestCanNm_DisableCommnSetRetVal(Std_ReturnType ReturnValue)
{
  CanNm_GddDisableCommnRetVal = ReturnValue;
} /* End TestCanNm_DisableCommnReturnValSetUp() */
/******************************************************************************/
/*                       CanNm_EnableCommunication()                          */
/******************************************************************************/
Std_ReturnType CanNm_EnableCommunication(const NetworkHandleType 
                                       nmChannelHandle)
{
  CanNm_GddEnCommnChnlHandle = nmChannelHandle;
  CanNm_GucEnableCommnCount++;
  return(CanNm_GddEnableCommnRetVal);
} /* End CanNm_EnableCommunication() */
/*******************************************************************************
**                       TestCanNm_EnableCommunication()                     **
*******************************************************************************/
boolean TestCanNm_EnableCommunication (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((CanNm_GucEnableCommnCount == 0x01)&&
        (ExpChannelHandle == CanNm_GddEnCommnChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      CanNm_GucEnableCommnCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanNm_EnableCommunication() */
/*******************************************************************************
**                       TestCanNm_EnableCommnSetRetVal()                     **
*******************************************************************************/
void TestCanNm_EnableCommnSetRetVal(Std_ReturnType ReturnValue)
{
  CanNm_GddEnableCommnRetVal = ReturnValue;
} /* End TestCanNm_EnableCommnSetRetVal() */
/******************************************************************************/
/*                       CanNm_RepeatMessageRequest()                         */
/******************************************************************************/
Std_ReturnType CanNm_RepeatMessageRequest(const NetworkHandleType
  nmChannelHandle)
{
  CanNm_GddRptMsgReqChnlHandle = nmChannelHandle;
  CanNm_GucRptMsgReqCount++;
  return(CanNm_GddRptMsgReqRetVal);
} /* End CanNm_RepeatMessageRequest() */
/*******************************************************************************
**                       TestCanNm_RepeatMessageRequest()                     **
*******************************************************************************/
boolean TestCanNm_RepeatMessageRequest(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((CanNm_GucRptMsgReqCount == 0x01)&&
        (ExpChannelHandle == CanNm_GddRptMsgReqChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      CanNm_GucRptMsgReqCount = 0;
      break;
      default:
      {
        break;
      }
    }

  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanNm_RepeatMessageRequest() */
/*******************************************************************************
**                       TestCanNm_RptMsgReqSetRetVal()                       **
*******************************************************************************/
void TestCanNm_RptMsgReqSetRetVal(Std_ReturnType ReturnValue)
{
  CanNm_GddRptMsgReqRetVal = ReturnValue;
} /* End TestCanNm_RptMsgReqSetRetVal() */
/******************************************************************************/
/*                       CanNm_RequestBusSynchronization()                    */
/******************************************************************************/
Std_ReturnType CanNm_RequestBusSynchronization(const NetworkHandleType
  nmChannelHandle)
{
  CanNm_GddReqBusSynchChnlHandle = nmChannelHandle;
  CanNm_GucReqBusSynchCount++;
  return(CanNm_GddReqBusSynchRetVal);
} /* End CanNm_RequestBusSynchronization() */
/*******************************************************************************
**                       TestCanNm_RequestBusSynchronization()                **
*******************************************************************************/
boolean TestCanNm_RequestBusSynchronization(App_DataValidateType
  LucDataValidate, const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((CanNm_GucReqBusSynchCount == 0x01)&&
        (ExpChannelHandle == CanNm_GddReqBusSynchChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      CanNm_GucReqBusSynchCount = 0;
      break;
      default:
      {
        break;
      }
    }

  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanNm_RequestBusSynchronization() */
/*******************************************************************************
**                       TestCanNm_ReqBusSynchSetRetVal()                     **
*******************************************************************************/
void TestCanNm_ReqBusSynchSetRetVal(Std_ReturnType ReturnValue)
{
  CanNm_GddReqBusSynchRetVal = ReturnValue;
}
#ifdef NM_MODULE_ACTIVE
/******************************************************************************/
/*                         CanNm_SetSleepReadyBit()                           */
/******************************************************************************/
Std_ReturnType CanNm_SetSleepReadyBit(const NetworkHandleType
  nmChannelHandle, const boolean nmSleepReadyBit)
{
  CanNm_GddSetSleepBitChnlHandle = nmChannelHandle;
  CanNm_GblnmSleepReadyBit = nmSleepReadyBit;
  CanNm_GucSetSleepBitCount++;
  return(CanNm_GddSetSleepBitRetVal);
} /* End CanNm_SetSleepReadyBit() */
/*******************************************************************************
**                       TestCanNm_SetSleepReadyBit()                **
*******************************************************************************/
boolean TestCanNm_SetSleepReadyBit(App_DataValidateType
  LucDataValidate, const NetworkHandleType ExpChannelHandle, 
  const boolean ExpnmSleepReadyBit)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((CanNm_GucSetSleepBitCount == 0x01)&&
        (ExpChannelHandle == CanNm_GddSetSleepBitChnlHandle) && 
        (ExpnmSleepReadyBit == CanNm_GblnmSleepReadyBit))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      CanNm_GucSetSleepBitCount = 0;
      break;      
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanNm_GucSetSleepBitCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }    
  

  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanNm_SetSleepReadyBit() */

#endif
/******************************************************************************/
/*                       CanNm_SetUserData()                                  */
/******************************************************************************/
Std_ReturnType CanNm_SetUserData(const NetworkHandleType nmChannelHandle,
  const uint8 * const nmUserDataPtr)
{
  CanNm_GddSetUserDataChnlHandle = nmChannelHandle;
  CanNm_GucSetUserData = *nmUserDataPtr;
  CanNm_GucSetUserDataCount++;
  return(CanNm_GddSetUserDataRetVal);
}  /* End CanNm_SetUserData() */

/*******************************************************************************
**                       TestCanNm_SetUserData()                     **
*******************************************************************************/
boolean TestCanNm_SetUserData (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle, const uint8 * const ExpUserDataPtr)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((CanNm_GucSetUserDataCount == 0x01)&&
        (ExpChannelHandle == CanNm_GddSetUserDataChnlHandle) &&
        (*ExpUserDataPtr == CanNm_GucSetUserData))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      CanNm_GucSetUserDataCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanNm_SetUserData() */

/******************************************************************************/
/*                       CanNm_GetUserData()                                  */
/******************************************************************************/
Std_ReturnType CanNm_GetUserData(const NetworkHandleType nmChannelHandle,
  uint8 * const nmUserDataPtr)
{
  CanNm_GddGetUserDataChnlHandle = nmChannelHandle;
  *nmUserDataPtr = CanNm_GucGetUserData;
  CanNm_GucGetUserDataCount++;
  return(CanNm_GddGetUserDataRetVal);
} /* End CanNm_GetUserData() */
/*******************************************************************************
**                       TestCanNm_GetUserData()                              **
*******************************************************************************/
boolean TestCanNm_GetUserData(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((CanNm_GucGetUserDataCount == 0x01)&&
        (ExpChannelHandle == CanNm_GddGetUserDataChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      CanNm_GucGetUserDataCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanNm_GetUserData() */
/*******************************************************************************
**                       TestCanNm_GetUserDataSetVal()                        **
*******************************************************************************/
void TestCanNm_GetUserDataSetVal(Std_ReturnType RetVal, uint8 UserData)
{
  CanNm_GddGetUserDataRetVal = RetVal;
  CanNm_GucGetUserData = UserData;
} /* End TestCanNm_GetUserDataSetVal() */
/******************************************************************************/
/*                       CanNm_GetPduData()                                  */
/******************************************************************************/
Std_ReturnType CanNm_GetPduData(const NetworkHandleType nmChannelHandle,
  uint8 *const nmPduData)
{
  CanNm_GddGetPduDataChnlHandle = nmChannelHandle;
  *nmPduData = CanNm_GucPduData;
  CanNm_GucGetPduDataCount++;

  return(CanNm_GddGetPduDataRetVal);
} /* End CanNm_GetPduData() */
/*******************************************************************************
**                       TestCanNm_GetPduData()                              **
*******************************************************************************/
boolean TestCanNm_GetPduData (App_DataValidateType LucDataValidate, const
  NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((CanNm_GucGetPduDataCount == 0x01)&&
        (ExpChannelHandle == CanNm_GddGetPduDataChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      CanNm_GucGetPduDataCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanNm_GetUserData() */
/*******************************************************************************
**                       TestCanNm_GetPduDataSetVal()                         **
*******************************************************************************/
void TestCanNm_GetPduDataSetVal(Std_ReturnType RetVal, uint8 PduData)
{
  CanNm_GddGetPduDataRetVal = RetVal;
  CanNm_GucPduData = PduData;
} /* End TestCanNm_GetPduDataSetVal() */
/******************************************************************************/
/*                       CanNm_GetNodeIdentifier()                            */
/******************************************************************************/
Std_ReturnType CanNm_GetNodeIdentifier(const NetworkHandleType nmChannelHandle,
  uint8 * const nmNodeIdPtr)
{
  CanNm_GddGetNodeIdChnlHandle = nmChannelHandle;
  *nmNodeIdPtr = CanNm_GucNodeId;
  CanNm_GucGetNodeIdCount++;
  return(CanNm_GddGetNodeIdRetVal);
} /* End CanNm_GetNodeIdentifier() */
/*******************************************************************************
**                       TestCanNm_GetNodeIdentifier()                        **
*******************************************************************************/
boolean TestCanNm_GetNodeIdentifier(App_DataValidateType LucDataValidate,const
  NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((CanNm_GucGetNodeIdCount == 0x01)&&
        (ExpChannelHandle == CanNm_GddGetNodeIdChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      CanNm_GucGetNodeIdCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanNm_GetNodeIdentifier() */
/*******************************************************************************
**                       TestCanNm_GetNodeIdDataSetVal()                      **
*******************************************************************************/
void TestCanNm_GetNodeIdDataSetVal(Std_ReturnType RetVal, uint8 NodeId)
{
  CanNm_GddGetNodeIdRetVal = RetVal;
  CanNm_GucNodeId = NodeId;
} /* End TestCanNm_GetNodeIdDataSetUp() */
/******************************************************************************/
/*                       CanNm_GetLocalNodeIdentifier()                       */
/******************************************************************************/
Std_ReturnType CanNm_GetLocalNodeIdentifier(const NetworkHandleType nmChannelHandle,
  uint8 * const nmNodeIdPtr)
{
  CanNm_GddGetLocNodeIdChnlHandle = nmChannelHandle;
  *nmNodeIdPtr = CanNm_GucLocalNodeId;
  CanNm_GucGetLocalNodeIdCount++;
  return(CanNm_GddGetLocalNodeIdRetVal);
} /* End CanNm_GetLocalNodeIdentifier() */
/*******************************************************************************
**                       TestCanNm_GetLocalNodeIdentifier()                   **
*******************************************************************************/
boolean TestCanNm_GetLocalNodeIdentifier(App_DataValidateType LucDataValidate,const
  NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((CanNm_GucGetLocalNodeIdCount == 0x01)&&
        (ExpChannelHandle == CanNm_GddGetLocNodeIdChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      CanNm_GucGetLocalNodeIdCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanNm_GetLocalNodeIdentifier() */

/*******************************************************************************
**                       TestCanNm_GetLocalNodeIdDataSetVal()                 **
*******************************************************************************/
void TestCanNm_GetLocalNodeIdDataSetVal(Std_ReturnType RetVal, uint8 NodeId)
{
  CanNm_GddGetLocalNodeIdRetVal = RetVal;
  CanNm_GucLocalNodeId = NodeId;
} /* End TestCanNm_GetLocalNodeIdDataSetVal() */

/*******************************************************************************
**             CanNm_CheckRemoteSleepIndication()                             **
*******************************************************************************/
Std_ReturnType CanNm_CheckRemoteSleepIndication(const NetworkHandleType
  nmChannelHandle, boolean * const nmRemoteSleepIndPtr)
{
  CanNm_GddCheckRemSleepIndChnlHandle = nmChannelHandle;
  *nmRemoteSleepIndPtr = CanNm_GblRemSleep;
  CanNm_GucCheckRemSleepIndCount++;
  return(CanNm_GddCheckRemSleepIndRetVal);
} /* End CanNm_CheckRemoteSleepIndication() */

/*******************************************************************************
**                       TestCanNm_CheckRemoteSleepIndication()               **
*******************************************************************************/
boolean TestCanNm_CheckRemoteSleepIndication(App_DataValidateType
  LucDataValidate,const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((CanNm_GucCheckRemSleepIndCount == 0x01)&&
        (ExpChannelHandle == CanNm_GddCheckRemSleepIndChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      CanNm_GucCheckRemSleepIndCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanNm_CheckRemoteSleepIndication() */

/*******************************************************************************
**                       TestCanNm_CheckRemSleepIndDataSetVal()             **
*******************************************************************************/
void TestCanNm_CheckRemSleepIndDataSetVal(Std_ReturnType RetVal,
  boolean SleepInd)
{
  CanNm_GddCheckRemSleepIndRetVal = RetVal;
  CanNm_GblRemSleep = SleepInd;
} /* End TestCanNm_CheckRemSleepIndDataSetVal() */

/*******************************************************************************
**              Function Name :CanNm_GetState()                               **
*******************************************************************************/
Std_ReturnType CanNm_GetState(const NetworkHandleType nmChannelHandle,
  Nm_StateType * const nmStatePtr, Nm_ModeType * const nmModePtr)
{
  CanNm_GddGetStateIndChnlHandle = nmChannelHandle;
  *nmStatePtr = CanNm_GddState;
  *nmModePtr = CanNm_GddMode;
  CanNm_GucGetStateCount++;
  return(CanNm_GddGetStateRetVal);
} /* End CanNm_GetState() */
/*******************************************************************************
**                       TestCanNm_GetState()                              **
*******************************************************************************/
boolean TestCanNm_GetState(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((CanNm_GucGetStateCount == 0x01)&&
        (ExpChannelHandle == CanNm_GddGetStateIndChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      CanNm_GucGetStateCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanNm_GetState() */
/*******************************************************************************
**                       TestCanNm_GetStateDataSetVal()                       **
*******************************************************************************/
void TestCanNm_GetStateDataSetVal(Std_ReturnType RetVal, Nm_StateType State,
  Nm_ModeType Mode)
{
  CanNm_GddGetStateRetVal = RetVal;
  CanNm_GddMode = Mode;
  CanNm_GddState = State;
} /* End TestCanNm_GetStateDataSetVal() */
/*******************************************************************************
**                       TestCanNm_ModeSetUp()                                **
*******************************************************************************/
void TestCanNm_ModeSetUp(Nm_ModeType Mode)
{
  CanNm_GddMode = Mode;
} /* End TestCanNm_ModeSetUp() */

/*******************************************************************************
**                     CanNm_TxConfirmation()                                  **
*******************************************************************************/
void CanNm_TxConfirmation(PduIdType TxPduId)
{
  /* Load actual TxPduId into Global variables */
  CanNm_GucTxPduId = TxPduId;
  CanNm_GucTxConfirmCount++;
} /* End of CanNm_TxConfirmation() */

/*******************************************************************************
**                     TestCanNm_TxConfirmation()                             **
*******************************************************************************/
boolean TestCanNm_TxConfirmation(App_DataValidateType LddDataValidate,
  PduIdType ExpTxPduId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TxPduId */
      if((CanNm_GucTxConfirmCount == 0x01) &&
        (CanNm_GucTxPduId == ExpTxPduId))

      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanNm_GucTxConfirmCount = 0;
      CanNm_GucTxConfirmCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanNm_GucTxConfirmCount; LucIndex++)
      {
        /* Validate TxPduId */
        if(CanNm_GucTxPduId == ExpTxPduId)

        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanNm_GucTxConfirmCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanNm_GucTxConfirmCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanNm_GucTxConfirmCheckCount == CanNm_GucTxConfirmCount)
      {
        CanNm_GucTxConfirmCount = 0;
        CanNm_GucTxConfirmCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanNm_GucTxConfirmCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCanNm_TxConfirmation() */

/*******************************************************************************
**                       CanNm_RxIndication()                                 **
*******************************************************************************/
void CanNm_RxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr)
{
  uint8 LucDataIndex;
  uint8* LpSduDataPtr;

  /* Load actual TxPduId  Sdulength and SduDataPt into Global variables */
  CanNm_GucRxIndiCount++;
  CanNm_GucRxPduId = RxPduId;

  CanNm_GucRxIndSduLength = (uint8)(PduInfoPtr->SduLength);
  LpSduDataPtr = PduInfoPtr->SduDataPtr;

  for(LucDataIndex = 0x00; LucDataIndex < CanNm_GucRxIndSduLength;
    LucDataIndex++)
  {
    CanNm_GaaRxIndSduData[LucDataIndex] = *LpSduDataPtr;
    LpSduDataPtr++;
  }
}
/* End of CanNm_RxIndication() */

/*******************************************************************************
**                   TestCanNm_RxIndication()                                 **
*******************************************************************************/
boolean TestCanNm_RxIndication(App_DataValidateType LddDataValidate,
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType LstActPduInfo;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((CanNm_GucRxIndiCount == 0x01) && (CanNm_GucRxPduId == ExpRxPduId))
      {
        LstActPduInfo.SduLength = CanNm_GucRxIndSduLength;
        LstActPduInfo.SduDataPtr = &CanNm_GaaRxIndSduData[0];

        /* Validate SduLength and Data */
        if(CanNmTest_ValidateData((PduInfoType *)ExpPduInfoPtr,
          &LstActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      CanNm_GucRxIndiCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanNm_GucRxIndiCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
       default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End of TestCanNm_RxIndication() */

/*******************************************************************************
**                       CanNmTest_ValidateData()                            **
*******************************************************************************/
boolean CanNmTest_ValidateData(PduInfoType* LddExpPduInfo,
  PduInfoType* LddActPduInfo)
{
  uint8 *LpActualSduDataPtr;
  uint8 *LpExpSduDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  LddSduCount = LddExpPduInfo->SduLength;
  LpExpSduDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualSduDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  if((LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }

  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    if(*LpActualSduDataPtr != *LpExpSduDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualSduDataPtr++;
    LpExpSduDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* CanNmTest_ValidateData() */

/*******************************************************************************
**                       CanNm_ConfirmPnAvailability()                        **
*******************************************************************************/
void CanNm_ConfirmPnAvailability( const NetworkHandleType nmChannelHandle)
{
 UNUSED(nmChannelHandle);
}

/*******************************************************************************
**                       TestCanNm_DefaultBehavior()                          **
*******************************************************************************/
void TestCanNm_DefaultBehavior(void)
{
  CanNm_GddMode = NM_MODE_BUS_SLEEP;
  CanNm_GddState = NM_STATE_UNINIT;
  #ifdef NM_MODULE_ACTIVE
  CanNm_GblnmSleepReadyBit = 0;
  CanNm_GddSetSleepBitChnlHandle = 0;
  CanNm_GucSetSleepBitCount = 0;
  #endif
  CanNm_GucPassiveStartCount = 0;
  CanNm_GucNetworkReqCount = 0;
  CanNm_GucNetworkRelCount = 0;
  CanNm_GucDisableCommnCount = 0;
  CanNm_GucEnableCommnCount = 0;
  CanNm_GucRptMsgReqCount = 0;
  CanNm_GucSetUserDataCount = 0;
  CanNm_GucGetUserDataCount = 0;
  CanNm_GucGetPduDataCount = 0;
  CanNm_GucGetNodeIdCount = 0;
  CanNm_GucGetLocalNodeIdCount = 0;
  CanNm_GucCheckRemSleepIndCount = 0;
  CanNm_GucGetStateCount = 0;
  CanNm_GucReqBusSynchCount = 0;
  CanNm_GucReqExpulCount = 0;
  CanNm_GddPassiveStartRetVal = E_OK;
  CanNm_GddNetworkReqRetVal = E_OK;
  CanNm_GddNetworkRelRetVal = E_OK;
  CanNm_GddDisableCommnRetVal = E_OK;
  CanNm_GddEnableCommnRetVal = E_OK;
  CanNm_GddRptMsgReqRetVal = E_OK;
  CanNm_GddSetUserDataRetVal = E_OK;
  CanNm_GddGetUserDataRetVal = E_OK;
  CanNm_GddGetPduDataRetVal = E_OK;
  CanNm_GddGetNodeIdRetVal = E_OK;
  CanNm_GddGetLocalNodeIdRetVal = E_OK;
  CanNm_GddCheckRemSleepIndRetVal = E_OK;
  CanNm_GddGetStateRetVal = E_OK;
  CanNm_GddReqBusSynchRetVal = E_OK;
  CanNm_GddReqExpulRetVal = E_OK;

  CanNm_GucTxConfirmCount = 0;
  CanNm_GucTxConfirmCheckCount = 0;
  CanNm_GucTxPduId = 0;
  CanNm_GucRxIndiCount = 0;
  CanNm_GucRxPduId = 0;
  CanNm_GucRxIndSduLength = 0;
} /* End TestCanNm_DefaultBehavior() */

#ifdef BSWM_MODULE_ACTIVE

/*******************************************************************************
**                          CanNm_Init()                                        **
*******************************************************************************/

void CanNm_Init(const CanNm_ConfigType* const cannmConfigPtr)
{
  UNUSED(cannmConfigPtr);
	App_GucApiSeqCnt++;  
	CanNm_GucInitSeqCnt = App_GucApiSeqCnt;
	CanNm_GucInitCnt++;
}/* End CanNm_Init() */

/*******************************************************************************
**                           TestCanNm_Init()                                   **
*******************************************************************************/
boolean TestCanNm_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(CanNm_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      CanNm_GucInitCnt = 0;
      CanNm_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(CanNm_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      CanNm_GucInitCnt = 0;
      CanNm_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanNm_Init() */

#endif
/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
