/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: FrSM.h                                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FlexRay State Manager Module                          **
**                                                                            **
**  PURPOSE   : Declaration of FrSM stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/
#ifndef FRSM_H
#define FRSM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"
#include "ComM.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define FRSM_AR_RELEASE_MAJOR_VERSION  4
#define FRSM_AR_RELEASE_MINOR_VERSION  0
#define FRSM_AR_RELEASE_REVISION_VERSION  3

/* Software Version Information */
#define FRSM_SW_MAJOR_VERSION  1
#define FRSM_SW_MINOR_VERSION  0

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
typedef uint8 FrSM_ConfigType;

typedef enum
{
FRSM_BSWM_READY = 0,
FRSM_BSWM_READY_ECU_PASSIVE,
FRSM_BSWM_STARTUP,
FRSM_BSWM_STARTUP_ECU_PASSIVE,
FRSM_BSWM_WAKEUP,
FRSM_BSWM_WAKEUP_ECU_PASSIVE,
FRSM_BSWM_HALT_REQ,
FRSM_BSWM_HALT_REQ_ECU_PASSIVE,
FRSM_BSWM_KEYSLOT_ONLY,
FRSM_BSWM_KEYSLOT_ONLY_ECU_PASSIVE,
FRSM_BSWM_ONLINE,
FRSM_BSWM_ONLINE_ECU_PASSIVE,
FRSM_BSWM_ONLINE_PASSIVE,
FRSM_BSWM_ONLINE_PASSIVE_ECU_PASSIVE,
FRSM_LOW_NUMBER_OF_COLDSTARTERS,
FRSM_LOW_NUMBER_OF_COLDSTARTERS_ECU_PASSIVE
}FrSM_BswM_StateType;

extern uint8 FrSM_GucRequestComModeCount;
extern uint8 FrSM_GucGetCurrentComModeCount;
extern NetworkHandleType FrSM_GddNetworkHandle;
extern ComM_ModeType FrSM_GddComM_Mode;
extern ComM_ModeType FrSM_GddGetCurComM_Mode;
extern Std_ReturnType FrSM_GddReqComRetVal;
extern Std_ReturnType FrSM_GddGetCurrentRetVal;
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Std_ReturnType FrSM_RequestComMode(NetworkHandleType NetworkHandle, 
  ComM_ModeType ComM_Mode);
  
extern Std_ReturnType FrSM_GetCurrentComMode(NetworkHandleType NetworkHandle, 
  P2VAR(ComM_ModeType, AUTOMATIC, COMM_APPL_DATA)ComM_ModePtr);


extern boolean TestFrSM_RequestComMode(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpNetworkHandle, ComM_ModeType LddExpComM_Mode);
  
extern boolean TestFrSM_GetCurrentComMode(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpNetworkHandle, 
  P2VAR(ComM_ModeType, AUTOMATIC, COMM_APPL_DATA)LddExpComM_ModePtr);
 
extern void TestFrSM_DefaultBehavior(void);
extern void TestFrSM_GetCurrentComModeSetBeh(Std_ReturnType LddReturnVal);  

extern void TestFrSM_RequestComModeSetBeh(Std_ReturnType LddReturnVal);  

extern void TestFrSM_GetCurrentComModeSetMode(ComM_ModeType LddComMMode);

extern void FrSM_Init(const FrSM_ConfigType* FrSM_ConfigPtr);

extern boolean TestFrSM_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
  
extern void FrSM_AllSlots(NetworkHandleType NetworkHandle);

extern boolean TestFrSM_AllSlots(App_DataValidateType LucDataValidate, 
  NetworkHandleType NetworkHandle);
  
Std_ReturnType FrSM_SetEcuPassive(boolean FrSM_Passive);

extern boolean TestFrSM_SetEcuPassive(App_DataValidateType LucDataValidate, 
  boolean FrSM_Passive);
#endif /* FRSM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
