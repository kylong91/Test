/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: FrSM.c                                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FlexRay State Manager Module                          **
**                                                                            **
**  PURPOSE   : Declaration of FrSM stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "FrSM.h"
#include "ComM_BusSM.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
uint8 FrSM_GucRequestComModeCount;
uint8 FrSM_GucGetCurrentComModeCount;
NetworkHandleType FrSM_GddNetworkHandle;
ComM_ModeType FrSM_GddComM_Mode;
ComM_ModeType FrSM_GddGetCurComM_Mode;
Std_ReturnType FrSM_GddReqComRetVal;
Std_ReturnType FrSM_GddGetCurrentRetVal;
#ifdef BSWM_MODULE_ACTIVE
Std_ReturnType FrSM_GddSetEcuPassiveRetVal;
uint8 FrSM_GucInitCnt;
uint8 FrSM_GucAllSlotsCnt;
uint8 FrSM_GucAllSlotsNwk;
uint8 FrSM_GucSetPassiveCnt;
uint8 FrSM_GucInitSeqCnt;
boolean FrSM_GblPassiveEnable;
#endif
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
**                      FrSM_RequestComMode()                                 **
*******************************************************************************/
Std_ReturnType FrSM_RequestComMode(NetworkHandleType NetworkHandle, 
  ComM_ModeType ComM_Mode)
{
  #ifndef TYPICAL_CONFIG
  FrSM_GucRequestComModeCount++;
  FrSM_GddNetworkHandle = NetworkHandle;
	FrSM_GddComM_Mode = ComM_Mode;
  #endif
	return(FrSM_GddReqComRetVal);
}/* End FrSM_RequestComMode() */

/*******************************************************************************
**                       TestFrSM_RequestComMode()                            **
*******************************************************************************/
boolean TestFrSM_RequestComMode(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpNetworkHandle, ComM_ModeType LddExpComM_Mode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((FrSM_GucRequestComModeCount == 0x01) && 
        (FrSM_GddNetworkHandle == LddExpNetworkHandle) &&  
        (FrSM_GddComM_Mode == LddExpComM_Mode))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      FrSM_GucRequestComModeCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestFrSM_RequestComMode() */

/*******************************************************************************
**                       TestFrSM_GetCurrentComModeSetMode()                  **
*******************************************************************************/

void TestFrSM_GetCurrentComModeSetMode(ComM_ModeType LddComMMode)
{
  FrSM_GddGetCurComM_Mode = LddComMMode;
}/* End TestEthSM_GetCurrentComModeSetMode() */

/*******************************************************************************
**                       FrSM_GetCurrentComMode()                             **
*******************************************************************************/
Std_ReturnType FrSM_GetCurrentComMode(NetworkHandleType NetworkHandle, 
  P2VAR(ComM_ModeType, AUTOMATIC, COMM_APPL_DATA)ComM_ModePtr)
{
  #ifndef TYPICAL_CONFIG
  FrSM_GucGetCurrentComModeCount++;
  FrSM_GddNetworkHandle = NetworkHandle;
	*ComM_ModePtr = FrSM_GddGetCurComM_Mode;
  #endif
	return(FrSM_GddGetCurrentRetVal);
}/* End FrSM_GetCurrentComMode() */
/*******************************************************************************
**                       TestFrSM_GetCurrentComMode()                         **
*******************************************************************************/
boolean TestFrSM_GetCurrentComMode(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpNetworkHandle, 
  P2VAR(ComM_ModeType, AUTOMATIC, COMM_APPL_DATA)LddExpComM_ModePtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {   
      if((FrSM_GucGetCurrentComModeCount == 0x01) && 
        (FrSM_GddNetworkHandle == LddExpNetworkHandle) && 
        (FrSM_GddComM_Mode == *LddExpComM_ModePtr))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      FrSM_GucGetCurrentComModeCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestFrSM_GetCurrentComMode() */

/*******************************************************************************
**                         TestFrSM_DefaultBehavior()                         **
*******************************************************************************/
void TestFrSM_DefaultBehavior(void)
{
  FrSM_GucGetCurrentComModeCount = 0;
  FrSM_GucRequestComModeCount = 0;
  FrSM_GddGetCurComM_Mode = COMM_NO_COMMUNICATION;
  FrSM_GddReqComRetVal = 0;
  FrSM_GddGetCurrentRetVal = 0;
}

/*******************************************************************************
**                         TestFrSM_SetBehavior()                             **
*******************************************************************************/
void TestFrSM_RequestComModeSetBeh(Std_ReturnType LddReturnVal)
{
  FrSM_GucGetCurrentComModeCount = 0;
  FrSM_GucRequestComModeCount = 0;
  FrSM_GddReqComRetVal = LddReturnVal;
}

void TestFrSM_GetCurrentComModeSetBeh(Std_ReturnType LddReturnVal)
{
  FrSM_GucGetCurrentComModeCount = 0;
  FrSM_GucRequestComModeCount = 0;
  FrSM_GddGetCurrentRetVal = LddReturnVal;
}
#ifdef BSWM_MODULE_ACTIVE
/*******************************************************************************
**                          FrSM_Init()                                       **
*******************************************************************************/

void FrSM_Init(const FrSM_ConfigType* FrSM_ConfigPtr)
{
	UNUSED(FrSM_ConfigPtr);
    App_GucApiSeqCnt++;
	FrSM_GucInitSeqCnt = App_GucApiSeqCnt;
	FrSM_GucInitCnt++;
}/* End FrSM_Init() */

/*******************************************************************************
**                           TestFrSM_Init()                                  **
*******************************************************************************/
boolean TestFrSM_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(FrSM_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      FrSM_GucInitCnt = 0;
      FrSM_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(FrSM_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      FrSM_GucInitCnt = 0;
      FrSM_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrSM_Init() */

/*******************************************************************************
**                          FrSM_AllSlots()                                   **
*******************************************************************************/

void FrSM_AllSlots(NetworkHandleType NetworkHandle)
{
  FrSM_GucAllSlotsCnt++;
  FrSM_GucAllSlotsNwk = NetworkHandle;
  
}/* End FrSM_AllSlots() */

/*******************************************************************************
**                           TestFrSM_AllSlots()                              **
*******************************************************************************/
boolean TestFrSM_AllSlots(App_DataValidateType LucDataValidate, 
  NetworkHandleType NetworkHandle)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((FrSM_GucAllSlotsCnt != 0x00) &&(FrSM_GucAllSlotsNwk == NetworkHandle))
      {
        LblStepResult = STEP_PASSED;
      }
      FrSM_GucAllSlotsCnt = 0;
      FrSM_GucAllSlotsNwk = 0;
      break;
    } /* End case S_VALIDATE: */    
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrSM_AllSlots() */

/*******************************************************************************
**                          FrSM_SetEcuPassive()                              **
*******************************************************************************/

Std_ReturnType FrSM_SetEcuPassive( boolean FrSM_Passive )
{
  FrSM_GucSetPassiveCnt++;
  FrSM_GblPassiveEnable = FrSM_Passive;
  
  return(FrSM_GddSetEcuPassiveRetVal);  
}/* End FrSM_AllSlots() */

/*******************************************************************************
**                           TestFrSM_AllSlots()                              **
*******************************************************************************/
boolean TestFrSM_SetEcuPassive(App_DataValidateType LucDataValidate, 
  boolean FrSM_Passive)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((FrSM_GucSetPassiveCnt != 0x00) && 
      (FrSM_GblPassiveEnable == FrSM_Passive))
      {
        LblStepResult = STEP_PASSED;
      }
      FrSM_GucSetPassiveCnt = 0;
      FrSM_GblPassiveEnable = 0;
      break;
    } /* End case S_VALIDATE: */    
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrSM_SetEcuPassive() */
#endif


/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
