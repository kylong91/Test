/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: UdpNm.c                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Nm Module                                             **
**                                                                            **
**  PURPOSE   : Provision of UdpNm.c for testing applications                 **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "UdpNm.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
NetworkHandleType UdpNm_GddPassStartChnlHandle;
NetworkHandleType UdpNm_GddNwReqChnlHandle;
NetworkHandleType UdpNm_GddNwRelChnlHandle;
NetworkHandleType UdpNm_GddDisCommnChnlHandle;
NetworkHandleType UdpNm_GddEnCommnChnlHandle;
NetworkHandleType UdpNm_GddSetUserDataChnlHandle;
NetworkHandleType UdpNm_GddGetUserDataChnlHandle;
NetworkHandleType UdpNm_GddRptMsgReqChnlHandle;
NetworkHandleType UdpNm_GddGetNodeIdChnlHandle;
NetworkHandleType UdpNm_GddGetLocNodeIdChnlHandle;
NetworkHandleType UdpNm_GddCheckRemSleepIndChnlHandle;
NetworkHandleType UdpNm_GddGetStateIndChnlHandle;
NetworkHandleType UdpNm_GddReqBusSynchChnlHandle;
NetworkHandleType UdpNm_GddGetPduDataChnlHandle;
NetworkHandleType UdpNm_GddReqExpulChnlHandle;
#ifdef NM_MODULE_ACTIVE
NetworkHandleType UdpNm_GddSetSleepBitChnlHandle;
#endif
uint8 UdpNm_GucSetUserData;
boolean * UdpNm_GblRemoteSleepIndPtr;
Nm_StateType * UdpNm_GddStatePtr; 
Nm_ModeType * UdpNm_GddModePtr;
uint8 UdpNm_GucPassiveStartCount;
uint8 UdpNm_GucNetworkReqCount;
uint8 UdpNm_GucNetworkRelCount;
uint8 UdpNm_GucDisableCommnCount;
uint8 UdpNm_GucEnableCommnCount;
uint8 UdpNm_GucRptMsgReqCount;
uint8 UdpNm_GucSetUserDataCount;
uint8 UdpNm_GucGetUserDataCount;
uint8 UdpNm_GucGetPduDataCount;
uint8 UdpNm_GucGetNodeIdCount;
uint8 UdpNm_GucGetLocalNodeIdCount;
uint8 UdpNm_GucCheckRemSleepIndCount;
uint8 UdpNm_GucGetStateCount;
uint8 UdpNm_GucReqBusSynchCount;
uint8 UdpNm_GucReqExpulCount;
#ifdef NM_MODULE_ACTIVE
uint8 UdpNm_GucSetSleepBitCount;
uint8 UdpNm_GddSetSleepBitRetVal;
#endif
Std_ReturnType UdpNm_GddPassiveStartRetVal;
Std_ReturnType UdpNm_GddNetworkReqRetVal;
Std_ReturnType UdpNm_GddNetworkRelRetVal;
Std_ReturnType UdpNm_GddDisableCommnRetVal;
Std_ReturnType UdpNm_GddEnableCommnRetVal;
Std_ReturnType UdpNm_GddRptMsgReqRetVal;
Std_ReturnType UdpNm_GddSetUserDataRetVal;
Std_ReturnType UdpNm_GddGetUserDataRetVal;
Std_ReturnType UdpNm_GddGetPduDataRetVal;
Std_ReturnType UdpNm_GddGetNodeIdRetVal;
Std_ReturnType UdpNm_GddGetLocalNodeIdRetVal;
Std_ReturnType UdpNm_GddCheckRemSleepIndRetVal;
Std_ReturnType UdpNm_GddGetStateRetVal;
Std_ReturnType UdpNm_GddReqBusSynchRetVal;
Std_ReturnType UdpNm_GddReqExpulRetVal;
uint8 UdpNm_GucGetUserData;
uint8 UdpNm_GucPduData;
uint8 UdpNm_GucNodeId;
uint8 UdpNm_GucLocalNodeId;
boolean UdpNm_GblRemSleep;
#ifdef NM_MODULE_ACTIVE
boolean UdpNm_GblnmSleepReadyBit;
#endif
Nm_StateType UdpNm_GddState;
Nm_ModeType UdpNm_GddMode;
/******************************************************************************/
/*             UdpNm_PassiveStartUp                                           */
/*****************************************************************************/
Std_ReturnType UdpNm_PassiveStartUp(const NetworkHandleType nmChannelHandle)
{
  UdpNm_GddPassStartChnlHandle = nmChannelHandle; 
  UdpNm_GucPassiveStartCount++;
  return(UdpNm_GddPassiveStartRetVal);
}
/*******************************************************************************
**                       TestUdpNm_PassiveStartUp ()                          **
*******************************************************************************/
boolean TestUdpNm_PassiveStartUp (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((UdpNm_GucPassiveStartCount == 0x01)&&
        (ExpChannelHandle == UdpNm_GddPassStartChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      UdpNm_GucPassiveStartCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestUdpNm_PassiveStartUp() */
/*******************************************************************************
**                       TestUdpNm_PassiveStartSetRetVal()                    **
*******************************************************************************/
void TestUdpNm_PassiveStartSetRetVal(Std_ReturnType ReturnValue)
{
  UdpNm_GddPassiveStartRetVal = ReturnValue;
} /* End TestUdpNm_PassiveStartSetRetVal() */
/******************************************************************************/
/*                       UdpNm_NetworkRequest()                               */
/******************************************************************************/
Std_ReturnType UdpNm_NetworkRequest(const NetworkHandleType nmChannelHandle)
{
  UdpNm_GddNwReqChnlHandle = nmChannelHandle; 
  UdpNm_GucNetworkReqCount++;
  return(UdpNm_GddNetworkReqRetVal);
}
/*******************************************************************************
**                       TestUdpNm_NetworkRequest ()                          **
*******************************************************************************/
boolean TestUdpNm_NetworkRequest (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((UdpNm_GucNetworkReqCount == 0x01)&&
        (ExpChannelHandle == UdpNm_GddNwReqChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      UdpNm_GucNetworkReqCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestUdpNm_NetworkRequest() */
/*******************************************************************************
**                       TestUdpNm_NetworkReqSetRetVal()                      **
*******************************************************************************/
void TestUdpNm_NetworkReqSetRetVal(Std_ReturnType ReturnValue)
{
  UdpNm_GddNetworkReqRetVal = ReturnValue;
} /* End TestUdpNm_NetworkReqSetRetVal() */
/******************************************************************************/
/*                       UdpNm_NetworkRelease()                               */
/******************************************************************************/
Std_ReturnType UdpNm_NetworkRelease(const NetworkHandleType nmChannelHandle)
{
  UdpNm_GddNwRelChnlHandle = nmChannelHandle; 
  UdpNm_GucNetworkRelCount++;
  return(UdpNm_GddNetworkRelRetVal);
} /* End UdpNm_NetworkRelease() */
/*******************************************************************************
**                       TestUdpNm_NetworkRelease ()                          **
*******************************************************************************/
boolean TestUdpNm_NetworkRelease (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((UdpNm_GucNetworkRelCount == 0x01)&&
        (ExpChannelHandle == UdpNm_GddNwRelChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      UdpNm_GucNetworkRelCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(UdpNm_GucNetworkRelCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestUdpNm_NetworkRelease() */
/*******************************************************************************
**                       TestUdpNm_NetworkRelSetRetVal()                      **
*******************************************************************************/
void TestUdpNm_NetworkRelSetRetVal(Std_ReturnType ReturnValue)
{
  UdpNm_GddNetworkRelRetVal = ReturnValue;
} /* End TestUdpNm_NetworkRelSetRetVal() */
/******************************************************************************/
/*                       UdpNm_DisableCommunication()                         */
/******************************************************************************/
Std_ReturnType UdpNm_DisableCommunication(const NetworkHandleType 
  nmChannelHandle)
{
  UdpNm_GddDisCommnChnlHandle = nmChannelHandle; 
  UdpNm_GucDisableCommnCount++;
  return(UdpNm_GddDisableCommnRetVal);
} /* End UdpNm_DisableCommunication() */
/*******************************************************************************
**                       TestUdpNm_DisableCommunication()                     **
*******************************************************************************/
boolean TestUdpNm_DisableCommunication (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((UdpNm_GucDisableCommnCount == 0x01)&&
        (ExpChannelHandle == UdpNm_GddDisCommnChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      UdpNm_GucDisableCommnCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestUdpNm_DisableCommunication() */
/*******************************************************************************
**                       TestUdpNm_DisableCommnSetRetVal()                    **
*******************************************************************************/
void TestUdpNm_DisableCommnSetRetVal(Std_ReturnType ReturnValue)
{
  UdpNm_GddDisableCommnRetVal = ReturnValue;
} /* End TestUdpNm_DisableCommnReturnValSetUp() */
/******************************************************************************/
/*                       UdpNm_EnableCommunication()                          */
/******************************************************************************/
Std_ReturnType UdpNm_EnableCommunication(const NetworkHandleType nmChannelHandle)
{
  UdpNm_GddEnCommnChnlHandle = nmChannelHandle;
  UdpNm_GucEnableCommnCount++;
  return(UdpNm_GddEnableCommnRetVal);
} /* End UdpNm_EnableCommunication() */
/*******************************************************************************
**                       TestUdpNm_EnableCommunication()                     **
*******************************************************************************/
boolean TestUdpNm_EnableCommunication (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((UdpNm_GucEnableCommnCount == 0x01)&&
        (ExpChannelHandle == UdpNm_GddEnCommnChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      UdpNm_GucEnableCommnCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestUdpNm_EnableCommunication() */
/*******************************************************************************
**                       TestUdpNm_EnableCommnSetRetVal()                     **
*******************************************************************************/
void TestUdpNm_EnableCommnSetRetVal(Std_ReturnType ReturnValue)
{
  UdpNm_GddEnableCommnRetVal = ReturnValue;
} /* End TestUdpNm_EnableCommnSetRetVal() */
/******************************************************************************/
/*                       UdpNm_RepeatMessageRequest()                         */
/******************************************************************************/
Std_ReturnType UdpNm_RepeatMessageRequest(const NetworkHandleType 
  nmChannelHandle)
{
  UdpNm_GddRptMsgReqChnlHandle = nmChannelHandle;
  UdpNm_GucRptMsgReqCount++;
  return(UdpNm_GddRptMsgReqRetVal);
} /* End UdpNm_RepeatMessageRequest() */
/*******************************************************************************
**                       TestUdpNm_RepeatMessageRequest()                     **
*******************************************************************************/
boolean TestUdpNm_RepeatMessageRequest(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((UdpNm_GucRptMsgReqCount == 0x01)&&
        (ExpChannelHandle == UdpNm_GddRptMsgReqChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      UdpNm_GucRptMsgReqCount = 0;
      break;
      default:
      {
        break;
      }
    }
    
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestUdpNm_RepeatMessageRequest() */
/*******************************************************************************
**                       TestUdpNm_RptMsgReqSetRetVal()                       **
*******************************************************************************/
void TestUdpNm_RptMsgReqSetRetVal(Std_ReturnType ReturnValue)
{
  UdpNm_GddRptMsgReqRetVal = ReturnValue;
} /* End TestUdpNm_RptMsgReqSetRetVal() */
/******************************************************************************/
/*                       UdpNm_RequestBusSynchronization()                    */
/******************************************************************************/
Std_ReturnType UdpNm_RequestBusSynchronization(const NetworkHandleType 
  nmChannelHandle)
{
  UdpNm_GddReqBusSynchChnlHandle = nmChannelHandle; 
  UdpNm_GucReqBusSynchCount++;
  return(UdpNm_GddReqBusSynchRetVal);
} /* End UdpNm_RequestBusSynchronization() */
/*******************************************************************************
**                       TestUdpNm_RequestBusSynchronization()                **
*******************************************************************************/
boolean TestUdpNm_RequestBusSynchronization(App_DataValidateType 
  LucDataValidate, const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((UdpNm_GucReqBusSynchCount == 0x01)&&
        (ExpChannelHandle == UdpNm_GddReqBusSynchChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      UdpNm_GucReqBusSynchCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(UdpNm_GucReqBusSynchCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }    
    default:
    {
      break;
    }   
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestUdpNm_RequestBusSynchronization() */
/*******************************************************************************
**                       TestUdpNm_ReqBusSynchSetRetVal()                     **
*******************************************************************************/
void TestUdpNm_ReqBusSynchSetRetVal(Std_ReturnType ReturnValue)
{
  UdpNm_GddReqBusSynchRetVal = ReturnValue;
}
#ifdef NM_MODULE_ACTIVE
/******************************************************************************/
/*                         UdpNm_SetSleepReadyBit()                           */
/******************************************************************************/
Std_ReturnType UdpNm_SetSleepReadyBit(const NetworkHandleType
  nmChannelHandle, const boolean nmSleepReadyBit)
{
  UdpNm_GddSetSleepBitChnlHandle = nmChannelHandle;
  UdpNm_GblnmSleepReadyBit = nmSleepReadyBit;
  UdpNm_GucSetSleepBitCount++;
  return(UdpNm_GddSetSleepBitRetVal);
} /* End LinNm_SetSleepReadyBit() */
/*******************************************************************************
**                       TestUdpNm_SetSleepReadyBit()                         **
*******************************************************************************/
boolean TestUdpNm_SetSleepReadyBit(App_DataValidateType
  LucDataValidate, const NetworkHandleType ExpChannelHandle,
  const boolean ExpnmSleepReadyBit)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((UdpNm_GucSetSleepBitCount == 0x01)&&
        (ExpChannelHandle == UdpNm_GddSetSleepBitChnlHandle)&& 
        (ExpnmSleepReadyBit == UdpNm_GblnmSleepReadyBit))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      UdpNm_GucSetSleepBitCount = 0;
      break;
      default:
      {
        break;
      }
    }

  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestUdpNm_SetSleepReadyBit() */
#endif
/******************************************************************************/
/*                       UdpNm_SetUserData()                                  */
/******************************************************************************/
Std_ReturnType UdpNm_SetUserData(const NetworkHandleType nmChannelHandle, 
  const uint8 * nmUserDataPtr)
{
  UdpNm_GddSetUserDataChnlHandle = nmChannelHandle; 
  UdpNm_GucSetUserData = *nmUserDataPtr;
  UdpNm_GucSetUserDataCount++;
  return(UdpNm_GddSetUserDataRetVal);
}  /* End UdpNm_SetUserData() */

/*******************************************************************************
**                       TestUdpNm_SetUserData()                     **
*******************************************************************************/
boolean TestUdpNm_SetUserData (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle, const uint8 * ExpUserDataPtr)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((UdpNm_GucSetUserDataCount == 0x01)&&
        (ExpChannelHandle == UdpNm_GddSetUserDataChnlHandle) && 
        (*ExpUserDataPtr == UdpNm_GucSetUserData))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      UdpNm_GucSetUserDataCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestUdpNm_SetUserData() */

/******************************************************************************/
/*                       UdpNm_GetUserData()                                  */
/******************************************************************************/
Std_ReturnType UdpNm_GetUserData(const NetworkHandleType nmChannelHandle, 
  uint8 * const nmUserDataPtr)
{
  UdpNm_GddGetUserDataChnlHandle = nmChannelHandle; 
  *nmUserDataPtr = UdpNm_GucGetUserData;
  UdpNm_GucGetUserDataCount++;
  return(UdpNm_GddGetUserDataRetVal);
} /* End UdpNm_GetUserData() */
/*******************************************************************************
**                       TestUdpNm_GetUserData()                              **
*******************************************************************************/
boolean TestUdpNm_GetUserData(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((UdpNm_GucGetUserDataCount == 0x01)&&
        (ExpChannelHandle == UdpNm_GddGetUserDataChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      UdpNm_GucGetUserDataCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestUdpNm_GetUserData() */
/*******************************************************************************
**                       TestUdpNm_GetUserDataSetVal()                        **
*******************************************************************************/
void TestUdpNm_GetUserDataSetVal(Std_ReturnType RetVal, uint8 UserData)
{
  UdpNm_GddGetUserDataRetVal = RetVal;
  UdpNm_GucGetUserData = UserData;
} /* End TestUdpNm_GetUserDataSetVal() */
/******************************************************************************/
/*                       UdpNm_GetPduData()                                  */
/******************************************************************************/
Std_ReturnType UdpNm_GetPduData(const NetworkHandleType nmChannelHandle,
  uint8 *const nmPduData)
{
  UdpNm_GddGetPduDataChnlHandle = nmChannelHandle; 
  *nmPduData = UdpNm_GucPduData;
  UdpNm_GucGetPduDataCount++;
  
  return(UdpNm_GddGetPduDataRetVal);
} /* End UdpNm_GetPduData() */
/*******************************************************************************
**                       TestUdpNm_GetPduData()                              **
*******************************************************************************/
boolean TestUdpNm_GetPduData (App_DataValidateType LucDataValidate, const 
  NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((UdpNm_GucGetPduDataCount == 0x01)&&
        (ExpChannelHandle == UdpNm_GddGetPduDataChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      UdpNm_GucGetPduDataCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestUdpNm_GetUserData() */
/*******************************************************************************
**                       TestUdpNm_GetPduDataSetVal()                         **
*******************************************************************************/
void TestUdpNm_GetPduDataSetVal(Std_ReturnType RetVal, uint8 PduData)
{
  UdpNm_GddGetPduDataRetVal = RetVal;
  UdpNm_GucPduData = PduData;
} /* End TestUdpNm_GetPduDataSetVal() */
/******************************************************************************/
/*                       UdpNm_GetNodeIdentifier()                            */
/******************************************************************************/
Std_ReturnType UdpNm_GetNodeIdentifier(const NetworkHandleType nmChannelHandle,
  uint8 * const nmNodeIdPtr)
{
  UdpNm_GddGetNodeIdChnlHandle = nmChannelHandle; 
  *nmNodeIdPtr = UdpNm_GucNodeId;
  UdpNm_GucGetNodeIdCount++;
  return(UdpNm_GddGetNodeIdRetVal);
} /* End UdpNm_GetNodeIdentifier() */
/*******************************************************************************
**                       TestUdpNm_GetNodeIdentifier()                        **
*******************************************************************************/
boolean TestUdpNm_GetNodeIdentifier(App_DataValidateType LucDataValidate,const 
  NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((UdpNm_GucGetNodeIdCount == 0x01)&&
        (ExpChannelHandle == UdpNm_GddGetNodeIdChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      UdpNm_GucGetNodeIdCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestUdpNm_GetNodeIdentifier() */
/*******************************************************************************
**                       TestUdpNm_GetNodeIdDataSetVal()                      **
*******************************************************************************/
void TestUdpNm_GetNodeIdDataSetVal(Std_ReturnType RetVal, uint8 NodeId)
{
  UdpNm_GddGetNodeIdRetVal = RetVal;
  UdpNm_GucNodeId = NodeId;
} /* End TestUdpNm_GetNodeIdDataSetUp() */
/******************************************************************************/
/*                       UdpNm_GetLocalNodeIdentifier()                       */
/******************************************************************************/
Std_ReturnType UdpNm_GetLocalNodeIdentifier(const NetworkHandleType nmChannelHandle,
  uint8 * const nmNodeIdPtr)
{
  UdpNm_GddGetLocNodeIdChnlHandle = nmChannelHandle; 
  *nmNodeIdPtr = UdpNm_GucLocalNodeId;
  UdpNm_GucGetLocalNodeIdCount++;
  return(UdpNm_GddGetLocalNodeIdRetVal);
} /* End UdpNm_GetLocalNodeIdentifier() */
/*******************************************************************************
**                       TestUdpNm_GetLocalNodeIdentifier()                   **
*******************************************************************************/
boolean TestUdpNm_GetLocalNodeIdentifier(App_DataValidateType LucDataValidate,const 
  NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((UdpNm_GucGetLocalNodeIdCount == 0x01)&&
        (ExpChannelHandle == UdpNm_GddGetLocNodeIdChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      UdpNm_GucGetLocalNodeIdCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestUdpNm_GetLocalNodeIdentifier() */

/*******************************************************************************
**                       TestUdpNm_GetLocalNodeIdDataSetVal()                 **
*******************************************************************************/
void TestUdpNm_GetLocalNodeIdDataSetVal(Std_ReturnType RetVal, uint8 NodeId)
{
  UdpNm_GddGetLocalNodeIdRetVal = RetVal;
  UdpNm_GucLocalNodeId = NodeId;
} /* End TestUdpNm_GetLocalNodeIdDataSetVal() */

/*******************************************************************************
**             UdpNm_CheckRemoteSleepIndication()                             **
*******************************************************************************/
Std_ReturnType UdpNm_CheckRemoteSleepIndication(const NetworkHandleType 
  nmChannelHandle, boolean * const nmRemoteSleepIndPtr)
{
  UdpNm_GddCheckRemSleepIndChnlHandle = nmChannelHandle; 
  *nmRemoteSleepIndPtr = UdpNm_GblRemSleep;
  UdpNm_GucCheckRemSleepIndCount++;
  return(UdpNm_GddCheckRemSleepIndRetVal);
} /* End UdpNm_CheckRemoteSleepIndication() */

/*******************************************************************************
**                       TestUdpNm_CheckRemoteSleepIndication()               **
*******************************************************************************/
boolean TestUdpNm_CheckRemoteSleepIndication(App_DataValidateType 
  LucDataValidate,const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((UdpNm_GucCheckRemSleepIndCount == 0x01)&&
        (ExpChannelHandle == UdpNm_GddCheckRemSleepIndChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      UdpNm_GucCheckRemSleepIndCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestUdpNm_CheckRemoteSleepIndication() */

/*******************************************************************************
**                       TestUdpNm_CheckRemSleepIndDataSetVal()             **
*******************************************************************************/
void TestUdpNm_CheckRemSleepIndDataSetVal(Std_ReturnType RetVal, 
  boolean SleepInd)
{
  UdpNm_GddCheckRemSleepIndRetVal = RetVal;
  UdpNm_GblRemSleep = SleepInd;
} /* End TestUdpNm_CheckRemSleepIndDataSetVal() */

/*******************************************************************************
**              Function Name :UdpNm_GetState()                               **
*******************************************************************************/
Std_ReturnType UdpNm_GetState(const NetworkHandleType nmChannelHandle, 
  Nm_StateType * const nmStatePtr, Nm_ModeType * const nmModePtr)
{
  UdpNm_GddGetStateIndChnlHandle = nmChannelHandle; 
  *nmStatePtr = UdpNm_GddState;
  *nmModePtr = UdpNm_GddMode;
  UdpNm_GucGetStateCount++;
  return(UdpNm_GddGetStateRetVal);
} /* End UdpNm_GetState() */
/*******************************************************************************
**                       TestUdpNm_GetState()                              **
*******************************************************************************/
boolean TestUdpNm_GetState(App_DataValidateType LucDataValidate, 
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((UdpNm_GucGetStateCount == 0x01)&&
        (ExpChannelHandle == UdpNm_GddGetStateIndChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      UdpNm_GucGetStateCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestUdpNm_GetState() */
/*******************************************************************************
**                       TestUdpNm_GetStateDataSetVal()                       **
*******************************************************************************/
void TestUdpNm_GetStateDataSetVal(Std_ReturnType RetVal, Nm_StateType State, 
  Nm_ModeType Mode)
{
  UdpNm_GddGetStateRetVal = RetVal;
  UdpNm_GddMode = Mode;
  UdpNm_GddState = State;
} /* End TestUdpNm_GetStateDataSetVal() */
/*******************************************************************************
**                       TestUdpNm_ModeSetUp()                                **
*******************************************************************************/
void TestUdpNm_ModeSetUp(Nm_ModeType Mode)
{
  UdpNm_GddMode = Mode;
} /* End TestUdpNm_ModeSetUp() */
/*******************************************************************************
**                       TestUdpNm_DefaultBehavior()                          **
*******************************************************************************/
void TestUdpNm_DefaultBehavior(void)
{
  UdpNm_GddMode = NM_MODE_BUS_SLEEP;
  UdpNm_GddState = NM_STATE_UNINIT;
  #ifdef NM_MODULE_ACTIVE
  UdpNm_GblnmSleepReadyBit = 0;
  UdpNm_GddSetSleepBitChnlHandle = 0;
  #endif
  UdpNm_GucPassiveStartCount = 0;
  UdpNm_GucNetworkReqCount = 0;
  UdpNm_GucNetworkRelCount = 0;
  UdpNm_GucDisableCommnCount = 0;
  UdpNm_GucEnableCommnCount = 0;
  UdpNm_GucRptMsgReqCount = 0;
  UdpNm_GucSetUserDataCount = 0;
  UdpNm_GucGetUserDataCount = 0;
  UdpNm_GucGetPduDataCount = 0;
  UdpNm_GucGetNodeIdCount = 0;
  UdpNm_GucGetLocalNodeIdCount = 0;
  UdpNm_GucCheckRemSleepIndCount = 0;
  UdpNm_GucGetStateCount = 0;
  UdpNm_GucReqBusSynchCount = 0;
  UdpNm_GucReqExpulCount = 0;
  #ifdef NM_MODULE_ACTIVE
  UdpNm_GucSetSleepBitCount = 0;
  #endif
  UdpNm_GddPassiveStartRetVal = E_OK;
  UdpNm_GddNetworkReqRetVal = E_OK;
  UdpNm_GddNetworkRelRetVal = E_OK;
  UdpNm_GddDisableCommnRetVal = E_OK;
  UdpNm_GddEnableCommnRetVal = E_OK;
  UdpNm_GddRptMsgReqRetVal = E_OK;
  UdpNm_GddSetUserDataRetVal = E_OK;
  UdpNm_GddGetUserDataRetVal = E_OK;
  UdpNm_GddGetPduDataRetVal = E_OK;
  UdpNm_GddGetNodeIdRetVal = E_OK;
  UdpNm_GddGetLocalNodeIdRetVal = E_OK;
  UdpNm_GddCheckRemSleepIndRetVal = E_OK;
  UdpNm_GddGetStateRetVal = E_OK;
  UdpNm_GddReqBusSynchRetVal = E_OK;
  UdpNm_GddReqExpulRetVal = E_OK;
} /* End TestUdpNm_DefaultBehavior() */

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
