/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: UdpNm.h                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Nm Module                                             **
**                                                                            **
**  PURPOSE   : Provision of header for UdpNm.c                               **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/

#ifndef UDPNM_H
#define UDPNM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h" 
#include "NmStack_Types.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define UDPNM_AR_RELEASE_MAJOR_VERSION  4
#define UDPNM_AR_RELEASE_MINOR_VERSION  0
#define UDPNM_AR_RELEASE_REVISION_VERSION  2

/*******************************************************************************
**                      Function Prototype                                    **
*******************************************************************************/
extern Std_ReturnType UdpNm_PassiveStartUp(const NetworkHandleType 
  nmChannelHandle); 

extern  boolean TestUdpNm_PassiveStartUp(App_DataValidateType LucDataValidate, 
  const NetworkHandleType LddExpChannelHandle); 
  
extern void TestUdpNm_PassiveStartSetRetVal(Std_ReturnType ReturnValue);
                                 
extern Std_ReturnType UdpNm_NetworkRequest(const NetworkHandleType 
  nmChannelHandle);

extern  boolean TestUdpNm_NetworkRequest(App_DataValidateType LucDataValidate, 
  const NetworkHandleType LddExpChannelHandle); 
  
extern void TestUdpNm_NetworkReqSetRetVal(Std_ReturnType ReturnValue);  

extern Std_ReturnType UdpNm_NetworkRelease(const NetworkHandleType 
  nmChannelHandle);

extern  boolean TestUdpNm_NetworkRelease(App_DataValidateType LucDataValidate, 
const NetworkHandleType LddExpChannelHandle);

extern void TestUdpNm_NetworkRelSetRetVal(Std_ReturnType ReturnValue);

extern Std_ReturnType UdpNm_DisableCommunication(const NetworkHandleType 
  nmChannelHandle);

extern  boolean TestUdpNm_DisableCommunication(App_DataValidateType 
  LucDataValidate, const NetworkHandleType LddExpChannelHandle);
  
extern void TestUdpNm_DisableCommnSetRetVal(Std_ReturnType ReturnValue);
                                   
extern Std_ReturnType UdpNm_EnableCommunication(const NetworkHandleType 
  nmChannelHandle);

extern  boolean TestUdpNm_EnableCommunication (App_DataValidateType 
  LucDataValidate, const NetworkHandleType LddExpChannelHandle);
  
extern void TestUdpNm_EnableCommnSetRetVal(Std_ReturnType ReturnValue);

extern Std_ReturnType UdpNm_RepeatMessageRequest(const NetworkHandleType 
  nmChannelHandle);
                                   
extern  boolean TestUdpNm_RepeatMessageRequest(App_DataValidateType 
  LucDataValidate, const NetworkHandleType LddExpChannelHandle); 
  
extern void TestUdpNm_RptMsgReqSetRetVal(Std_ReturnType ReturnValue);

extern Std_ReturnType UdpNm_SetUserData(const NetworkHandleType nmChannelHandle, 
  const uint8 * nmUserDataPtr);

extern  boolean TestUdpNm_SetUserData (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle, const uint8 * ExpUserDataPtr);

extern Std_ReturnType UdpNm_GetUserData(const NetworkHandleType nmChannelHandle,
uint8 * const nmUserDataPtr);

extern  boolean TestUdpNm_GetUserData (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle);
  
extern void TestUdpNm_GetUserDataSetVal(Std_ReturnType RetVal, uint8 UserData);
                         
extern Std_ReturnType UdpNm_GetPduData(const NetworkHandleType nmChannelHandle,
  uint8 * const nmPduData);

extern  boolean TestUdpNm_GetPduData (App_DataValidateType LucDataValidate, 
  const NetworkHandleType ExpChannelHandle);
  
extern void TestUdpNm_GetPduDataSetVal(Std_ReturnType RetVal, uint8 PduData);
           
extern Std_ReturnType UdpNm_GetNodeIdentifier(const NetworkHandleType 
  nmChannelHandle, uint8 * const nmNodeIdPtr);

extern  boolean TestUdpNm_GetNodeIdentifier(App_DataValidateType 
  LucDataValidate, const NetworkHandleType ExpChannelHandle);
  
extern void TestUdpNm_GetNodeIdDataSetVal(Std_ReturnType RetVal, uint8 NodeId);
         
extern Std_ReturnType UdpNm_GetLocalNodeIdentifier(const NetworkHandleType 
  nmChannelHandle,uint8 * const nmNodeIdPtr);
         
extern  boolean TestUdpNm_GetLocalNodeIdentifier(App_DataValidateType 
  LucDataValidate, const NetworkHandleType ExpChannelHandle);
  
extern void TestUdpNm_GetLocalNodeIdDataSetVal(Std_ReturnType RetVal, uint8 NodeId);
         
extern Std_ReturnType UdpNm_CheckRemoteSleepIndication(const NetworkHandleType 
nmChannelHandle, boolean * const nmRemoteSleepIndPtr);

extern  boolean TestUdpNm_CheckRemoteSleepIndication(App_DataValidateType 
  LucDataValidate, const NetworkHandleType ExpChannelHandle);
  
extern void TestUdpNm_CheckRemSleepIndDataSetVal(Std_ReturnType RetVal, 
  boolean SleepInd);
                          
extern Std_ReturnType UdpNm_GetState(const NetworkHandleType nmChannelHandle,
  Nm_StateType * const nmStatePtr,Nm_ModeType * const nmModePtr);
 
extern  boolean TestUdpNm_GetState(App_DataValidateType LucDataValidate, 
  const NetworkHandleType ExpChannelHandle);
  
extern void TestUdpNm_GetStateDataSetVal(Std_ReturnType RetVal, Nm_StateType State, 
  Nm_ModeType Mode);

extern Std_ReturnType UdpNm_RequestBusSynchronization
  (const NetworkHandleType nmChannelHandle);

extern boolean TestUdpNm_RequestBusSynchronization (App_DataValidateType 
  LucDataValidate, const NetworkHandleType ExpChannelHandle);
  
extern void TestUdpNm_ReqBusSynchSetRetVal(Std_ReturnType ReturnValue);
   
extern void TestUdpNm_ModeSetUp(Nm_ModeType Mode);
 
extern void TestUdpNm_DefaultBehavior(void);

extern boolean TestUdpNm_SetSleepReadyBit(App_DataValidateType
  LucDataValidate, const NetworkHandleType ExpChannelHandle, 
  const boolean ExpnmSleepReadyBit);

extern Std_ReturnType UdpNm_SetSleepReadyBit(const NetworkHandleType
  nmChannelHandle, const boolean nmSleepReadyBit);  

#endif /* UDPNM_H */

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
