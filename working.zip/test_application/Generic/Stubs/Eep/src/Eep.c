/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Eep.c                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Eep Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Eep stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By             Description                         **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M        Initial version                     **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Eep.h"

/*******************************************************************************
**                         Global Data                                        **
*******************************************************************************/
Eep_AddressType Eep_GddWriteAddress;
Eep_LengthType Eep_GddWriteLength;
uint8* Eep_GpWriteDataBuffPtr;
uint8* Eep_GpReadDataBuffPtr;
uint8 Eep_GucWriteCount;
Eep_AddressType Eep_GddReadAddress;
Eep_LengthType Eep_GddReadLength;
MemIf_ModeType Eep_GddMode;
uint8* Eep_GpReadeDataBuffPtr;
uint8 Eep_GucReadCount;
Eep_AddressType Eep_GddEraseAddress;
Eep_LengthType Eep_GddEraseLength;
uint8 Eep_GucEraseCount = 0;
uint8 Eep_GucCancelCount = 0;
uint8 Eep_GucSetModeCount = 0;
uint8 Eep_GucGetStatCount = 0;
uint8 Eep_GucGetJobResCount = 0;
Std_ReturnType Eep_GddWriteRetVal = E_OK;
Std_ReturnType Eep_GddReadRetVal = E_OK;
Std_ReturnType Eep_GddEraseRetVal = E_OK;
MemIf_StatusType Eep_GddGetStatRetVal = MEMIF_IDLE;
MemIf_JobResultType Eep_GddJobResRetVal = MEMIF_JOB_OK;

uint8 Eep_GucInitSeqCnt;
#ifdef BSWM_MODULE_ACTIVE
uint8 Eep_GucInitCnt;
#endif
#ifdef ECUM_MODULE_ACTIVE
uint8 Eep_GucConfigData;
uint8 Eep_GucInitCount;
#endif
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/******************************************************************************/
/*                   Eep_Write                                                */
/******************************************************************************/
Std_ReturnType Eep_Write(Eep_AddressType EepromAddress,
  const uint8* DataBufferPtr, Eep_LengthType Length)
{
  Eep_GddWriteAddress = EepromAddress;
  Eep_GddWriteLength = Length;
  Eep_GpWriteDataBuffPtr = (uint8 *)DataBufferPtr;
  Eep_GucWriteCount++;
  return(Eep_GddWriteRetVal);
}

/*******************************************************************************
**                       TestEep_Write ()                                     **
*******************************************************************************/
boolean TestEep_Write(App_DataValidateType LucDataValidate, 
  Eep_AddressType ExpEepromAddress, const uint8* ExpDataBufferPtr, 
  Eep_LengthType ExpLength)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((Eep_GucWriteCount == 0x01)&&
        (ExpEepromAddress == Eep_GddWriteAddress) && 
        (ExpDataBufferPtr == Eep_GpWriteDataBuffPtr) && (ExpLength == 
        Eep_GddWriteLength))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Eep_GucWriteCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEep_Write() */

/******************************************************************************/
/*                   Eep_Read                                                 */
/******************************************************************************/
Std_ReturnType Eep_Read(Eep_AddressType EepromAddress,
  uint8* DataBufferPtr,Eep_LengthType Length)
{
  Eep_GddReadAddress = EepromAddress;
  Eep_GddReadLength = Length;
  Eep_GpReadDataBuffPtr = DataBufferPtr;
  Eep_GucReadCount++;
  return(Eep_GddReadRetVal);
}

/*******************************************************************************
**                       TestEep_Read()                                       **
*******************************************************************************/
boolean TestEep_Read(App_DataValidateType LucDataValidate, 
  Eep_AddressType ExpEepromAddress, uint8* ExpDataBufferPtr, 
  Eep_LengthType ExpLength)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((Eep_GucReadCount == 0x01)&&
        (ExpEepromAddress == Eep_GddReadAddress) && 
        (ExpDataBufferPtr == Eep_GpReadDataBuffPtr) && 
        (ExpLength == Eep_GddReadLength))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Eep_GucReadCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEep_Read() */

/******************************************************************************/
/*                   Eep_Erase                                                */
/******************************************************************************/
/* API declaration for EEPROM driver erase function */
Std_ReturnType Eep_Erase(Eep_AddressType EepromAddress,Eep_LengthType Length)
{
  Eep_GddEraseAddress = EepromAddress;
  Eep_GddEraseLength = Length;
  Eep_GucEraseCount++;
  return(Eep_GddEraseRetVal);
}

/*******************************************************************************
**                       TestEep_Erase()                                       **
*******************************************************************************/
boolean TestEep_Erase(App_DataValidateType LucDataValidate, 
  Eep_AddressType ExpEepromAddress, Eep_LengthType ExpLength)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((Eep_GucEraseCount == 0x01)&&
        (ExpEepromAddress == Eep_GddEraseAddress) && 
        (ExpLength == Eep_GddEraseLength))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Eep_GucEraseCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEep_Erase() */
/******************************************************************************/
/*                   Eep_Cancel                                               */
/******************************************************************************/
  /* API declaration for EEPROM driver Cancel function */
void Eep_Cancel(void)
{
  Eep_GucCancelCount++;
}

/*******************************************************************************
**                       TestEep_Cancel()                                     **
*******************************************************************************/
boolean TestEep_Cancel(App_DataValidateType LucDataValidate)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if(Eep_GucCancelCount == 0x01)
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Eep_GucCancelCount = 0;
      break;
    }
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eep_GucCancelCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEep_Cancel() */

/******************************************************************************/
/*                   Eep_SetMode                                              */
/******************************************************************************/
/* API declaration to set the mode of EEPROM driver */
void Eep_SetMode(MemIf_ModeType Mode)
{
  Eep_GddMode = Mode;
  Eep_GucSetModeCount++;
}

/*******************************************************************************
**                       TestEep_SetMode()                                    **
*******************************************************************************/
boolean TestEep_SetMode(App_DataValidateType LucDataValidate, 
  MemIf_ModeType ExpMode)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((Eep_GucSetModeCount == 0x01) && (ExpMode == Eep_GddMode))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Eep_GucSetModeCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEep_SetMode() */

/******************************************************************************/
/*                   Eep_GetStatus                                             */
/******************************************************************************/
/* API declaration for EEPROM driver get status function */
MemIf_StatusType Eep_GetStatus(void)
{
 Eep_GucGetStatCount++;
 return(Eep_GddGetStatRetVal);
}

/*******************************************************************************
**                       TestEep_GetStatus()                                  **
*******************************************************************************/
boolean TestEep_GetStatus(App_DataValidateType LucDataValidate)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if(Eep_GucGetStatCount == 0x01) 
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Eep_GucGetStatCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEep_SetMode() */
/******************************************************************************/
/*                   Eep_GetJobResult                                         */
/******************************************************************************/

/* API declaration for EEPROM driver get job result function */
MemIf_JobResultType Eep_GetJobResult(void)
{
  Eep_GucGetJobResCount++;
  return(Eep_GddJobResRetVal);
}

/*******************************************************************************
**                       TestEep_GetJobResult()                                    **
*******************************************************************************/
boolean TestEep_GetJobResult(App_DataValidateType LucDataValidate)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if(Eep_GucGetJobResCount == 0x01) 
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Eep_GucGetJobResCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEep_GetJobResult() */

void TestEep_DefaultBehavior(void)
{
  Eep_GucEraseCount = 0;
  Eep_GucCancelCount = 0;
  Eep_GucSetModeCount = 0;
  Eep_GucGetStatCount = 0;
  Eep_GucGetJobResCount = 0;
  Eep_GddWriteRetVal = E_OK;
  Eep_GddReadRetVal = E_OK;
  Eep_GddEraseRetVal = E_OK;
  Eep_GddGetStatRetVal = MEMIF_IDLE;
  Eep_GddJobResRetVal = MEMIF_JOB_OK;
  Eep_GucInitSeqCnt = 0;
  #ifdef ECUM_MODULE_ACTIVE
  Eep_GucConfigData = 0;
  Eep_GucInitCount = 0;
  #endif
}

void TestEep_JobResultSetRetVal(MemIf_JobResultType Result)
{
  Eep_GddJobResRetVal = Result;
}


/*******************************************************************************
**                          Eep_Init()                                        **
*******************************************************************************/

void Eep_Init(const Eep_ConfigType* ConfigPtr)
{
  App_GucApiSeqCnt++;
  Eep_GucInitSeqCnt = App_GucApiSeqCnt;
  #ifndef ECUM_MODULE_ACTIVE
  UNUSED(ConfigPtr);
  #endif
  #ifdef BSWM_MODULE_ACTIVE
  Eep_GucInitCnt++;
  #endif
  #ifdef ECUM_MODULE_ACTIVE
  Eep_GucInitCount++;
  if (ConfigPtr != NULL_PTR)
  {
    Eep_GucConfigData = (ConfigPtr->dummy);
  }
  #endif
}/* End Eep_Init() */
#ifdef ECUM_MODULE_ACTIVE
/*******************************************************************************
**                        TestEep_Init()                                      **
*******************************************************************************/
boolean TestEep_InitPB(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, uint8 LucData)
{
  boolean LblStepResult;  
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Eep_GucInitCount == 0x01) && 
        (Eep_GucConfigData == LucData))
      {
        LblStepResult = STEP_PASSED;
      }
      Eep_GucInitCount = 0;
      Eep_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if((Eep_GucInitSeqCnt == LucSeqNo) && 
        (Eep_GucConfigData == LucData))
      {
        LblStepResult = STEP_PASSED;
      }
      Eep_GucInitSeqCnt = 0;
      Eep_GucInitCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */    
  return(LblStepResult); 
} /* End TestEep_Init() */
#endif
#ifdef BSWM_MODULE_ACTIVE
/*******************************************************************************
**                           TestEep_Init()                                   **
*******************************************************************************/
boolean TestEep_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Eep_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Eep_GucInitCnt = 0;
      Eep_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(Eep_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Eep_GucInitCnt = 0;
      Eep_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestEep_Init() */

#endif
/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
