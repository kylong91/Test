/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Eep.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Eep Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Eep stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By             Description                         **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M        Initial version                     **
*******************************************************************************/
#ifndef EEP_H
#define EEP_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Std_Types.h"
#include "MemIf_Types.h"
#include "Eep_Types.h"
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define EEP_AR_RELEASE_MAJOR_VERSION  4
#define EEP_AR_RELEASE_MINOR_VERSION  0
#define EEP_AR_RELEASE_REVISION_VERSION  3

/*******************************************************************************
**                      Version Check                                         **
*******************************************************************************/

/*******************************************************************************
**                         Global Data                                        **
*******************************************************************************/
typedef struct STag_Eep_ConfigType
{
  uint8 dummy;
}Eep_ConfigType;
extern const Eep_ConfigType Eep_GaaConfig[2];
extern uint8 Eep_GucConfigData;
/*******************************************************************************
**                      Function Prototypes                                  **
*******************************************************************************/
/* API declaration for EEPROM driver Read function */
extern Std_ReturnType Eep_Read(Eep_AddressType EepromAddress,
  uint8* DataBufferPtr, Eep_LengthType Length);
  
extern boolean TestEep_Read(App_DataValidateType LucDataValidate, 
  Eep_AddressType EepromAddress, uint8* DataBufferPtr, Eep_LengthType Length); 
  
/* API declaration for EEPROM driver Write function */
extern Std_ReturnType Eep_Write(Eep_AddressType EepromAddress,
  const uint8* DataBufferPtr, Eep_LengthType Length);
  
extern boolean TestEep_Write(App_DataValidateType LucDataValidate, 
  Eep_AddressType ExpEepromAddress, const uint8* ExpDataBufferPtr, 
  Eep_LengthType Length);

/* API declaration for EEPROM driver Cancel function */
extern void Eep_Cancel(void);

extern boolean TestEep_Cancel(App_DataValidateType LucDataValidate);

/* API declaration to set the mode of EEPROM driver */
extern void Eep_SetMode(MemIf_ModeType Mode);

extern boolean TestEep_SetMode(App_DataValidateType LucDataValidate, 
  MemIf_ModeType ExpMode);

/* API declaration for EEPROM driver get status function */
extern MemIf_StatusType Eep_GetStatus(void);

extern boolean TestEep_GetStatus(App_DataValidateType LucDataValidate);

/* API declaration for EEPROM driver get job result function */
extern MemIf_JobResultType Eep_GetJobResult(void);

extern boolean TestEep_GetJobResult(App_DataValidateType LucDataValidate);

/* API declaration for EEPROM driver errase function */
extern Std_ReturnType Eep_Erase(Eep_AddressType EepromAddress,
  Eep_LengthType Length);

extern boolean TestEep_Erase(App_DataValidateType LucDataValidate, 
  Eep_AddressType EepromAddress, Eep_LengthType Length);

extern void TestEep_DefaultBehavior(void);
  
extern void TestEep_JobResultSetRetVal(MemIf_JobResultType Result);

extern void Eep_Init(const Eep_ConfigType* ConfigPtr);

extern boolean TestEep_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
extern boolean TestEep_InitPB(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, uint8 LucData);
#endif
/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
