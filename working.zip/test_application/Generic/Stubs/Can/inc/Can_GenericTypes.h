/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Can_GenericTypes.h                                            **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CAN Stub                                              **
**                                                                            **
**  PURPOSE   : Declaration of Can Stub functions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef CAN_GENERICTYPES_H
#define CAN_GENERICTYPES_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
typedef uint32 Can_IdType;
typedef uint32 Can_HwHandleType;

/* This is used to provide CAN-ID, DLC and SDU from CanIf to CAN Driver */
typedef struct Can_PduType
{
  /* CAN-ID */
  Can_IdType id;
  /* DLC */
  uint8 length;
  /* Pointer to L-SDU */
  uint8 *sdu;
  /* swPduHandle */
  PduIdType swPduHandle ;
} Can_PduType;

/* State transitions that are used by the function Can_SetControllerMode */
typedef enum
{
  CAN_T_START = 0,
  CAN_T_STOP,
  CAN_T_SLEEP,
  CAN_T_WAKEUP
}Can_StateTransitionType;

/* Return values of CAN Driver API */
typedef enum
{
  CAN_OK = 0,
  CAN_NOT_OK,
  CAN_BUSY
}Can_ReturnType;

#endif /* CAN_GENERICTYPES_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
