/*******************************************************************************
** (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,          **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Can.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CAN Stub                                              **
**                                                                            **
**  PURPOSE   : Declaration of Can Stub functions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
 Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef CAN_H
#define CAN_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

#include "ComStack_Types.h"
#include "Can_GeneralTypes.h"
#include "Can_GenericTypes.h"
#include "TC_Generic.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define CAN_AR_RELEASE_MAJOR_VERSION    4
#define CAN_AR_RELEASE_MINOR_VERSION    0
#define CAN_AR_RELEASE_REVISION_VERSION 3

#define CAN_ARRAY_SIZE 0x08
#define CAN_DATA_LENGTH 0x08

#define CanConfigSet0 &Can_GaaConfig[0]
#define CanConfigSet1 &Can_GaaConfig[1]
/*******************************************************************************
**                         Global Data                                        **
*******************************************************************************/
typedef struct STag_Can_ConfigType
{
  uint8 dummy;
}Can_ConfigType;

extern const Can_ConfigType Can_GaaConfig[2];
extern uint8 Can_GucConfigData;
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Can_ReturnType Can_SetControllerMode(uint8 Controller,
  Can_StateTransitionType Transition);

extern Can_ReturnType Can_Write(Can_HwHandleType Hth,
  const Can_PduType *PduInfo);

extern Can_ReturnType Can_CheckWakeup(uint8 Controller);

extern boolean TestCan_SetControllerMode(App_DataValidateType LddDataValidate,
  uint8 LucExpController, Can_StateTransitionType LddExpTransition);

extern boolean TestCan_Write(App_DataValidateType LddDataValidate,
  Can_HwHandleType ExpHth, const Can_PduType *ExpPduInfo);

extern boolean TestCan_CheckWakeup(App_DataValidateType LddDataValidate,
  uint8 LucExpController);

extern void TestCan_SetCtrlRetVal(Can_ReturnType LddCanReturnVal);

extern void TestCan_SetCheckWakeupRetVal(Can_ReturnType LddCanReturnVal);

extern void TestCan_SetWriteRetVal(Can_ReturnType LddCanReturnVal);

extern void TestCan_DefaultBehavior(void);

extern void Can_Init(const Can_ConfigType* Config);

extern boolean TestCan_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);

extern boolean TestCan_InitPB(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, uint8 LucData);

extern boolean Can_Test_ValidateData(uint8* LpExpSdu, uint8* LpActSdu);

extern Std_ReturnType Can_CheckBaudrate(uint8 ControllerId,
                                           CONST(uint16, CANIF_CONST) Baudrate);

extern boolean TestCan_CheckBaudrate(App_DataValidateType LddDataValidate, 
                        uint8 ControllerId, CONST(uint16, CANIF_CONST) Baudrate);

extern Std_ReturnType Can_ChangeBaudrate(uint8 ControllerId,
                                            CONST(uint16, CANIF_CONST) Baudrate);

extern boolean TestCan_ChangeBaudrate(App_DataValidateType LddDataValidate, 
                        uint8 ControllerId, CONST(uint16, CANIF_CONST) Baudrate);
#endif /* CAN_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
