/*******************************************************************************
** (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,          **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Can.c                                                         **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CAN Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Can stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
 Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     13-Dec-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Can.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Can_GucSetCtrlModeCount;
uint8 Can_GucCheckControllerId1;
uint16 Can_GddBaudRate1;
uint8 Can_GucCheckBaudRateCnt;
uint8 Can_GucSetController;
Can_StateTransitionType Can_GddTransition;

uint8 Can_GucCheckWakeupCount;
uint8 Can_GucWakupController;
uint8 Can_GucCheckWakeupCheckCount;

uint8 Can_GucWriteCount;
Can_HwHandleType Can_GddHth;
PduIdType Can_GddWriteswPduhandle;
Can_IdType Can_GucWriteCanId;
uint8 Can_GucWriteLength;
uint8 Can_GaaWriteSdu[CAN_DATA_LENGTH];

Can_ReturnType Can_GddSetCtrlRetVal;
Can_ReturnType Can_GddCheckWakeupRetVal;
Can_ReturnType Can_GddWriteRetVal;
Std_ReturnType LenStdRetVal;

#ifdef BSWM_MODULE_ACTIVE
uint8 Can_GucInitCnt;
#endif
uint8 Can_GucInitSeqCnt;

#ifdef ECUM_MODULE_ACTIVE
uint8 Can_GucConfigData;
uint8 Can_GucInitCount;
#endif
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
#ifdef ECUM_MODULE_ACTIVE
/*******************************************************************************
**                           TestCan_Init()                                   **
*******************************************************************************/
boolean TestCan_InitPB(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, uint8 LucData)
{
  boolean LblStepResult;  
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Can_GucInitCount == 0x01) && 
        (Can_GucConfigData == LucData))
      {
        LblStepResult = STEP_PASSED;
      }
      Can_GucInitCount = 0;
      Can_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if((Can_GucInitSeqCnt == LucSeqNo) && 
        (Can_GucConfigData == LucData))
      {
        LblStepResult = STEP_PASSED;
      }
      Can_GucInitSeqCnt = 0;
      Can_GucInitCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    case M_VALIDATE:
    {
      if(Can_GucConfigData == LucData)
      {
        LblStepResult = STEP_PASSED;
      }
      Can_GucInitCount = 0;
      Can_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */    
    
  return(LblStepResult);
} /* End TestCan_Init() */
#endif
#ifdef CANIF_MODULE_ACTIVE
/*******************************************************************************
**                     Can_CheckBaudrate()                                    **
*******************************************************************************/
Std_ReturnType Can_CheckBaudrate(uint8 ControllerId,
                                            CONST(uint16, CANIF_CONST) Baudrate)
{
  /* Load actual Controller and Transition into Global variables */
  
  Can_GucCheckControllerId1 = ControllerId;
  Can_GddBaudRate1 = Baudrate;
  Can_GucCheckBaudRateCnt++;

  return(LenStdRetVal);
} /* End CanIf_SetControllerMode() */

/*******************************************************************************
**                           TestCan_CheckBaudrate()                          **
*******************************************************************************/
boolean TestCan_CheckBaudrate(App_DataValidateType LddDataValidate, 
                        uint8 ControllerId, CONST(uint16, CANIF_CONST) Baudrate)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and HTH */
      if((Can_GucCheckBaudRateCnt == 0x01) && (Baudrate == Can_GddBaudRate1) && (ControllerId == Can_GucCheckControllerId1)) 
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Can_GucCheckBaudRateCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Can_GucCheckBaudRateCnt == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      Can_GucCheckBaudRateCnt = 0;
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCan_CheckBaudrate() */

/*******************************************************************************
**                     Can_ChangeBaudrate()                                    **
*******************************************************************************/
Std_ReturnType Can_ChangeBaudrate(uint8 ControllerId,
                                            CONST(uint16, CANIF_CONST) Baudrate)
{
  /* Load actual Controller and Transition into Global variables */
  
  Can_GucCheckControllerId1 = ControllerId;
  Can_GddBaudRate1 = Baudrate;
  Can_GucCheckBaudRateCnt++;

  return(LenStdRetVal);
} /* End Can_ChangeBaudrate() */

/*******************************************************************************
**                           TestCan_ChangeBaudrate()                          **
*******************************************************************************/
boolean TestCan_ChangeBaudrate(App_DataValidateType LddDataValidate, 
                        uint8 ControllerId, CONST(uint16, CANIF_CONST) Baudrate)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and HTH */
      if((Can_GucCheckBaudRateCnt == 0x01) && (Baudrate == Can_GddBaudRate1) && (ControllerId == Can_GucCheckControllerId1)) 
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Can_GucCheckBaudRateCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Can_GucCheckBaudRateCnt == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      Can_GucCheckBaudRateCnt = 0;
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCan_ChangeBaudrate() */
#endif
/*******************************************************************************
**                     Can_SetControllerMode()                                **
*******************************************************************************/
Can_ReturnType Can_SetControllerMode(uint8 Controller,
  Can_StateTransitionType Transition)
{
  /* Load actual Controller and Transition into Global variables */
  Can_GucSetController = Controller;
  Can_GddTransition = Transition;
  Can_GucSetCtrlModeCount++;

  return(Can_GddSetCtrlRetVal);
} /* End CanIf_SetControllerMode() */

/*******************************************************************************
**                     TestCan_SetControllerMode()                            **
*******************************************************************************/
boolean TestCan_SetControllerMode(App_DataValidateType LddDataValidate,
  uint8 LucExpController, Can_StateTransitionType LddExpTransition)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Can_GucSetCtrlModeCount == 0x01) &&
        (Can_GucSetController == LucExpController) &&
        (Can_GddTransition == LddExpTransition))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Can_GucSetCtrlModeCount = 0;
      break;
    } /* End case S_VALIDATE: */
	
	case M_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Can_GucSetCtrlModeCount == 0x02) &&
        (Can_GucSetController == LucExpController) &&
        (Can_GddTransition == LddExpTransition))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Can_GucSetCtrlModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Can_GucSetCtrlModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Can_GucSetCtrlModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCan_SetControllerMode() */

/*******************************************************************************
**                           Can_CheckWakeup()                                **
*******************************************************************************/
Can_ReturnType Can_CheckWakeup(uint8 Controller)
{
  /* Load actual Controller into Global variables */
  Can_GucCheckWakeupCount++;
  Can_GucWakupController = Controller;

  return(Can_GddCheckWakeupRetVal);
}  /* End Can_CheckWakeup() */

/*******************************************************************************
**                        TestCan_CheckWakeup()                               **
*******************************************************************************/
boolean TestCan_CheckWakeup(App_DataValidateType LddDataValidate,
  uint8 LucExpController)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller  */
      if((Can_GucCheckWakeupCount == 0x01) &&
        (Can_GucWakupController == LucExpController))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Can_GucCheckWakeupCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Can_GucCheckWakeupCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Can_GucCheckWakeupCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCan_CheckWakeup() */

/*******************************************************************************
**                           Can_Write()                                      **
*******************************************************************************/
Can_ReturnType Can_Write(Can_HwHandleType LddHth, const Can_PduType *LstPduInfo)
{
  uint8 LucDataIndex;
  uint8 *LpWriteSdu;

  /* Load actual Hth and SduDataPtr into Global variables */
  Can_GddHth = LddHth;
  Can_GddWriteswPduhandle = LstPduInfo->swPduHandle;  
  LpWriteSdu = LstPduInfo->sdu;
  Can_GucWriteCanId = LstPduInfo->id;  
  if(LstPduInfo->length > CAN_DATA_LENGTH)
  {
    Can_GucWriteLength = CAN_DATA_LENGTH;
  }
  else
  {
    Can_GucWriteLength = LstPduInfo->length;
  }

  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0; LucDataIndex < Can_GucWriteLength; LucDataIndex++)
  {
    Can_GaaWriteSdu[LucDataIndex] = *LpWriteSdu;
    LpWriteSdu++;
  }
  Can_GucWriteCount++;
  return(Can_GddWriteRetVal);
} /* End Can_Write() */

/*******************************************************************************
**                           TestCan_Write()                                  **
*******************************************************************************/
boolean TestCan_Write(App_DataValidateType LddDataValidate,
Can_HwHandleType ExpHth, const Can_PduType *ExpPduInfo)
{
  boolean LblRetValue;
  uint8 *LpSduPtr;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and HTH */
      if((Can_GucWriteCount == 0x01) && (Can_GddHth == ExpHth) &&
        (ExpPduInfo->length == Can_GucWriteLength) &&
        (ExpPduInfo->id == Can_GucWriteCanId) &&
        (ExpPduInfo->swPduHandle == Can_GddWriteswPduhandle))
      {
        LpSduPtr = ExpPduInfo->sdu;
        /* Validate SduLength and Data */
        if(Can_Test_ValidateData(LpSduPtr, &Can_GaaWriteSdu[0]))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      Can_GucWriteCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Can_GucWriteCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      Can_GucWriteCount = 0;
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCan_Write() */

/*******************************************************************************
**                       Can_Test_ValidateData()                              **
*******************************************************************************/
boolean Can_Test_ValidateData(uint8* LpExpSdu, uint8* LpActSdu)
{
  uint8 LddSduCount;
  uint8 *LpExpSduData;
  uint8 *LpActSduData;
  boolean LblReturnValue;

  LpExpSduData = LpExpSdu;
  LpActSduData = LpActSdu;
  LblReturnValue = TRUE;
  LddSduCount = Can_GucWriteLength;

  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    LddSduCount--;
    if(*LpActSduData != *LpExpSduData)
    {
      LblReturnValue = FALSE;
    }
    LpActSduData++;
    LpExpSduData++;
    
  }
  return(LblReturnValue);
} /* End Can_Test_ValidateData()  */

/*******************************************************************************
**                    TestCan_SetCtrlRetVal()                              **
*******************************************************************************/
void TestCan_SetCtrlRetVal(Can_ReturnType LddCanReturnVal)
{
  Can_GddSetCtrlRetVal = LddCanReturnVal;
}
/* End TestCan_SetCtrlRetVal() */

/*******************************************************************************
**                  TestCan_SetCheckWakeupRetVal()                            **
*******************************************************************************/
void TestCan_SetCheckWakeupRetVal(Can_ReturnType LddCanReturnVal)
{
  Can_GddCheckWakeupRetVal = LddCanReturnVal;
}
/* End TestCan_SetCheckWakeupRetVal() */

/*******************************************************************************
**                    TestCan_SetWriteRetVal()                                **
*******************************************************************************/
void TestCan_SetWriteRetVal(Can_ReturnType LddCanReturnVal)
{
  Can_GddWriteRetVal = LddCanReturnVal;
}
/* End TestCan_SetWriteRetVal() */

/*******************************************************************************
**                     TestCan_DefaultBehavior()                              **
*******************************************************************************/
void TestCan_DefaultBehavior(void)
{
  Can_GddSetCtrlRetVal = CAN_OK;
  Can_GddCheckWakeupRetVal = CAN_OK;
  Can_GddWriteRetVal = CAN_OK;
  Can_GddTransition = CAN_T_STOP;
  Can_GucSetCtrlModeCount = 0;
  Can_GucSetController = 0;
  Can_GucCheckWakeupCount = 0;
  Can_GucWakupController = 0;
  Can_GucCheckWakeupCheckCount = 0;
  Can_GucWriteCount = 0;
  Can_GddWriteswPduhandle = 0;
  Can_GucWriteCanId = 0;
  Can_GucWriteLength = 0;
  Can_GddHth = 0;
  LenStdRetVal = E_OK;
  Can_GucCheckBaudRateCnt = 0;
  Can_GucCheckControllerId1 = 0;
  Can_GddBaudRate1 = 0;
  Can_GucInitSeqCnt = 0;
  #ifdef ECUM_MODULE_ACTIVE
  Can_GucConfigData = 0;
  Can_GucInitCount = 0;
  #endif
} /* End TestCan_DefaultBehavior() */

/*******************************************************************************
**                          Can_Init()                                        **
*******************************************************************************/

void Can_Init(const Can_ConfigType* Config)
{
  App_GucApiSeqCnt++;
  Can_GucInitSeqCnt = App_GucApiSeqCnt;
  #ifndef ECUM_MODULE_ACTIVE
  UNUSED(Config);
  #endif
  #ifdef BSWM_MODULE_ACTIVE
  Can_GucInitCnt++;
  #endif
  #ifdef ECUM_MODULE_ACTIVE
  Can_GucInitCount++;
  if (Config != NULL_PTR)
  {
    Can_GucConfigData = (Config->dummy);
  }
  #endif
}/* End Can_Init() */
#ifdef BSWM_MODULE_ACTIVE
/*******************************************************************************
**                           TestCan_Init()                                   **
*******************************************************************************/
boolean TestCan_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Can_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Can_GucInitCnt = 0;
      Can_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(Can_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Can_GucInitCnt = 0;
      Can_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCan_Init() */
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

