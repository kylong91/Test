/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: ComM.c                                                        **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR ComM Stub                                             **
**                                                                            **
**  PURPOSE   : This application file contains the ComM functions             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComM.h"
#include "ComM_BusSM.h"
#ifdef NM_MODULE_ACTIVE
#include "ComM_Nm.h"
#endif
#ifdef DCM_MODULE_ACTIVE
#include "ComM_Dcm.h"
#endif
#ifdef ECUM_MODULE_ACTIVE
#include "ComM_EcuMBswM.h"
#endif
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

uint8 ComM_GucModeIndiCount;
uint8 ComM_GucModeIndiCheckCount;
NetworkHandleType ComM_GaaChannel[COMM_ARRAY_SIZE];
ComM_ModeType ComM_GaaComMMode[COMM_ARRAY_SIZE];

#ifdef NM_MODULE_ACTIVE
uint8 ComM_GucNwStartIndCount;
uint8 ComM_GucNwModeCount;
uint8 ComM_GucBusSleepModeCount;
uint8 ComM_GucPrepBusSleepModeCount;
uint8 ComM_GucRestartIndCount;
uint8 ComM_GucRestartIndCheckCount;
NetworkHandleType ComM_GddNwStartChnlHandle;
NetworkHandleType ComM_GddNwModeChnlHandle;
NetworkHandleType ComM_GddPrepBusChnlHandle;
NetworkHandleType ComM_GddBusSleepChnlHandle;
NetworkHandleType ComM_GddRestartIndChnlHandle;
#endif /* NM_MODULE_ACTIVE */

NetworkHandleType ComM_GddChannel;
#ifdef BSWM_MODULE_ACTIVE
ComM_UserHandleType ComM_GddUser ;
NetworkHandleType ComM_GddNetChannel;
boolean ComM_GddAllowed ;
boolean ComM_GblStatus ;
ComM_ModeType ComM_GddGetReqComMode;
NetworkHandleType ComM_GddnmNetworkHandle;
uint8 ComM_GucGetRequestedComModeCount;
uint8 ComM_GucCommunicationAllowedCount;
uint8 ComM_GucLimitChannelToNoComModeCount;
uint8 ComM_GucRequestExpulsionCount;
Std_ReturnType ComM_GddReturnVal;
uint8 ComM_GucInitCnt;
uint8 ComM_GucInitSeqCnt;
#endif /* BSWM_MODULE_ACTIVE */

#ifdef ECUM_MODULE_ACTIVE
uint8 ComM_GucWakeUpCount;
#endif
#ifdef DCM_MODULE_ACTIVE
NetworkHandleType Dcm_ComM_GddNWHandleType;
uint8 Dcm_ComMCount;
#endif /* DCM_MODULE_ACTIVE */
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
#ifdef ECUM_MODULE_ACTIVE

/*******************************************************************************
**               ComM_EcuM_WakeUpIndication()                                 **
*******************************************************************************/
void ComM_EcuM_WakeUpIndication(NetworkHandleType Channel)
{
  #ifndef TYPICAL_CONFIG
  ComM_GddChannel = Channel;
  ComM_GucWakeUpCount++;
  #endif  
}

/*******************************************************************************
**                TestComM_EcuM_WakeUpIndication()                            **
*******************************************************************************/
boolean TestComM_EcuM_WakeUpIndication(App_DataValidateType LucDataValidate,
  NetworkHandleType LddChannel)
{
  boolean LblStepResult;  
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(ComM_GddChannel == LddChannel)
      {
        LblStepResult = STEP_PASSED;
      }
      ComM_GucWakeUpCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_NOT_INVOKED:
    {
      if(ComM_GucWakeUpCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */    
  return(LblStepResult);
} /* End TestComM_EcuM_WakeUpIndication() */

#endif
/*******************************************************************************
**                     ComM_BusSM_ModeIndication()                            **
*******************************************************************************/
void ComM_BusSM_ModeIndication(NetworkHandleType Channel,
                                                        ComM_ModeType *ComMMode)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual Channel and ComMMode into Global variables */
  ComM_GaaChannel[ComM_GucModeIndiCount] = Channel;
  ComM_GaaComMMode[ComM_GucModeIndiCount] = *ComMMode;

  /* Increment count variable to handle multiple invocations */
  if(ComM_GucModeIndiCount < COMM_ARRAY_SIZE)
  {
    ComM_GucModeIndiCount++;
  }
  #endif /* TYPICAL_CONFIG */
}

/*******************************************************************************
**                       TestComM_BusSM_ModeIndication()                      **
*******************************************************************************/
boolean TestComM_BusSM_ModeIndication(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpChannel, ComM_ModeType LddExpComMMode)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Channel and ComMMode */
      if((ComM_GucModeIndiCount == 0x01) &&
        (ComM_GaaChannel[0] == LddExpChannel) &&
        (ComM_GaaComMMode[0] == LddExpComMMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      ComM_GucModeIndiCount = 0;
      ComM_GucModeIndiCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < ComM_GucModeIndiCount; LucIndex++)
      {
        /* Validate Channel and ComMMode */
        if((ComM_GaaChannel[LucIndex] == LddExpChannel) &&
          (ComM_GaaComMMode[LucIndex] == LddExpComMMode))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = ComM_GucModeIndiCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      ComM_GucModeIndiCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(ComM_GucModeIndiCheckCount == ComM_GucModeIndiCount)
      {
        ComM_GucModeIndiCount = 0;
        ComM_GucModeIndiCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(ComM_GucModeIndiCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestComM_BusSM_ModeIndication() */

#ifdef NM_MODULE_ACTIVE
/******************************************************************************/
/*             ComM_Nm_NetworkStartIndication                                 */
/******************************************************************************/
void ComM_Nm_NetworkStartIndication(NetworkHandleType channel)
{
 ComM_GddNwStartChnlHandle = channel;
 ComM_GucNwStartIndCount++;
}

/******************************************************************************/
/*             TestComM_Nm_NetworkStartIndication                             */
/******************************************************************************/
boolean TestComM_Nm_NetworkStartIndication(App_DataValidateType LucDataValidate,
 const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((ComM_GucNwStartIndCount == 0x01)&&
        (ExpChannelHandle == ComM_GddNwStartChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      ComM_GucNwStartIndCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
}

/******************************************************************************/
/*             ComM_Nm_NetworkMode                                            */
/******************************************************************************/
void ComM_Nm_NetworkMode(NetworkHandleType channel)
{
  ComM_GddNwModeChnlHandle = channel;
  ComM_GucNwModeCount++;
}

/******************************************************************************/
/*             TestComM_Nm_NetworkMode                             */
/******************************************************************************/
 boolean TestComM_Nm_NetworkMode(App_DataValidateType LucDataValidate,
 const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((ComM_GucNwModeCount == 0x01)&&
        (ExpChannelHandle == ComM_GddNwModeChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      ComM_GucNwModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
}

/******************************************************************************/
/*             ComM Nm PrepareBusSleepMode                                    */
/******************************************************************************/
void ComM_Nm_PrepareBusSleepMode(NetworkHandleType channel)
{
  ComM_GddPrepBusChnlHandle = channel;
  ComM_GucPrepBusSleepModeCount++;
}

/******************************************************************************/
/*             TestComM_Nm_PrepareBusSleepMode                             */
/******************************************************************************/
 boolean TestComM_Nm_PrepareBusSleepMode(App_DataValidateType LucDataValidate,
 const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((ComM_GucPrepBusSleepModeCount == 0x01)&&
        (ExpChannelHandle == ComM_GddPrepBusChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      ComM_GucPrepBusSleepModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
}

/******************************************************************************/
/*             ComM_Nm_BusSleepMode                                           */
/******************************************************************************/
void ComM_Nm_BusSleepMode(NetworkHandleType channel)
{
  ComM_GddBusSleepChnlHandle = channel;
  ComM_GucBusSleepModeCount++;
}

/******************************************************************************/
/*             TestComM_Nm_BusSleepMode()                                     */
/******************************************************************************/
 boolean TestComM_Nm_BusSleepMode(App_DataValidateType LucDataValidate,
 const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((ComM_GucBusSleepModeCount == 0x01)&&
        (ExpChannelHandle == ComM_GddBusSleepChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      ComM_GucBusSleepModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
}

/******************************************************************************/
/*             ComM_Nm_RestartIndication()                                    */
/******************************************************************************/
void ComM_Nm_RestartIndication(NetworkHandleType channel)
{
  ComM_GddRestartIndChnlHandle = channel;
  ComM_GucRestartIndCount++;
}

/******************************************************************************/
/*             TestComM_Nm_RestartIndication                                  */
/******************************************************************************/
 boolean TestComM_Nm_RestartIndication(App_DataValidateType LucDataValidate,
 const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((ComM_GucRestartIndCount == 0x01)&&
        (ExpChannelHandle == ComM_GddRestartIndChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      ComM_GucRestartIndCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestComM_Nm_RestartIndication() */
#endif /* End NM_MODULE_ACTIVE */

/*******************************************************************************
**                     TestComM_DefaultBehavior()                             **
*******************************************************************************/
void TestComM_DefaultBehavior(void)
{

  ComM_GucModeIndiCount = 0;
  ComM_GucModeIndiCheckCount = 0;

  #ifdef NM_MODULE_ACTIVE  
  ComM_GucNwStartIndCount = 0;
  ComM_GucNwModeCount = 0;
  ComM_GucBusSleepModeCount = 0;
  ComM_GucPrepBusSleepModeCount = 0;
  ComM_GucRestartIndCount = 0;
  ComM_GucRestartIndCheckCount = 0;
  #endif /* NM_MODULE_ACTIVE */
  ComM_GddChannel =0;
  #ifdef ECUM_MODULE_ACTIVE
  ComM_GucWakeUpCount = 0;
  #endif
  #ifdef BSWM_MODULE_ACTIVE  
  ComM_GddReturnVal = E_OK;
  ComM_GddGetReqComMode = COMM_FULL_COMMUNICATION;
  #endif /* BSWM_MODULE_ACTIVE */
  
  #ifdef DCM_MODULE_ACTIVE  
  Dcm_ComMCount = 0;
  #endif
}

#ifdef BSWM_MODULE_ACTIVE
/*******************************************************************************
**                          ComM_Init()                                      **
*******************************************************************************/

void ComM_Init(void)
{
  App_GucApiSeqCnt++;
  ComM_GucInitSeqCnt = App_GucApiSeqCnt;
  ComM_GucInitCnt++;
}/* End ComM_Init() */

/*******************************************************************************
**                           TestComM_Init()                                 **
*******************************************************************************/
boolean TestComM_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(ComM_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      ComM_GucInitCnt = 0;
      ComM_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(ComM_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      ComM_GucInitCnt = 0;
      ComM_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestComM_Init() */

/*******************************************************************************
**                          ComM_DeInit()                                      **
*******************************************************************************/

void ComM_DeInit(void)
{
  App_GucApiSeqCnt++;
  ComM_GucInitSeqCnt = App_GucApiSeqCnt;
  ComM_GucInitCnt++;
}/* End ComM_DeInit() */

/*******************************************************************************
**                           TestComM_Init()                                 **
*******************************************************************************/
boolean TestComM_DeInit(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(ComM_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      ComM_GucInitCnt = 0;
      ComM_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(ComM_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      ComM_GucInitCnt = 0;
      ComM_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestComM_DeInit() */
/*******************************************************************************
**                         ComM_GetRequestedComMode                           **
*******************************************************************************/
Std_ReturnType ComM_RequestComMode(ComM_UserHandleType User, 
  ComM_ModeType ComMode)
{
  ComM_GddUser = User; 
  ComM_GddGetReqComMode= ComMode;
  ComM_GucGetRequestedComModeCount++;
  return(ComM_GddReturnVal);
}/* End ComM_GetRequestedComMode() */

/*******************************************************************************
**                   AppComM_SetBehaviorGetRequestedComMode                   **
*******************************************************************************/
void AppComM_SetBehaviorGetRequestedComMode(Std_ReturnType LddSetRetVal, 
  ComM_ModeType ComMode)
{  
  ComM_GddGetReqComMode = ComMode;
  ComM_GddReturnVal = LddSetRetVal;
}/* End ComM_GetRequestedComMode() */

/*******************************************************************************
**                       TestComM_RequestComMode()                            **
*******************************************************************************/
boolean TestComM_RequestComMode(App_DataValidateType LucDataValidate, 
ComM_UserHandleType LddExpUser, ComM_ModeType LddExpComMode)
{

  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((ComM_GucGetRequestedComModeCount != 0x00) && 
        (ComM_GddUser == LddExpUser) && 
        (ComM_GddGetReqComMode == LddExpComMode))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      ComM_GucGetRequestedComModeCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestComM_RequestComMode() */

/*******************************************************************************
**                         ComM_CommunicationAllowed                          **
*******************************************************************************/
void ComM_CommunicationAllowed(NetworkHandleType Channel, boolean Allowed)
{
  ComM_GddChannel = Channel; 
  ComM_GddAllowed = Allowed;
  ComM_GucCommunicationAllowedCount++;
}/* End ComM_CommunicationAllowed() */
/*******************************************************************************
**                       TestComM_CommunicationAllowed()                      **
*******************************************************************************/
boolean TestComM_CommunicationAllowed(App_DataValidateType  
  LucDataValidate, NetworkHandleType LddExpChannel, boolean LddExpAllowed)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((ComM_GucCommunicationAllowedCount != 0x00) && 
        (ComM_GddChannel == LddExpChannel) && 
        (ComM_GddAllowed == LddExpAllowed))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      ComM_GucCommunicationAllowedCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestComM_CommunicationAllowed() */
/*******************************************************************************
**                         ComM_LimitChannelToNoComMode()                     **
*******************************************************************************/
Std_ReturnType ComM_LimitChannelToNoComMode(NetworkHandleType Channel, 
  boolean Status)
{
  ComM_GddNetChannel = Channel;
  ComM_GblStatus = Status;
  ComM_GucLimitChannelToNoComModeCount++;
  return(ComM_GddReturnVal);
}

/*******************************************************************************
**                       TestComM_LimitChannelToNoComMode()                   **
*******************************************************************************/
boolean TestComM_LimitChannelToNoComMode(App_DataValidateType  
  LucDataValidate, NetworkHandleType Channel, boolean Status)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((ComM_GucLimitChannelToNoComModeCount != 0x00) && 
        (ComM_GddNetChannel == Channel) && 
        (ComM_GblStatus == Status))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      ComM_GucLimitChannelToNoComModeCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    if(ComM_GucLimitChannelToNoComModeCount == 0x00)
      {
      LblStepResult = APP_TC_PASSED;
      }  
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestComM_LimitChannelToNoComMode() */

#endif /* BSWM_MODULE_ACTIVE */

#ifdef DCM_MODULE_ACTIVE
/*******************************************************************************
**                     ComM_DCM_InactiveDiagnostic()                          **
*******************************************************************************/
void ComM_DCM_InactiveDiagnostic(NetworkHandleType LddHandleType)
{
  Dcm_ComM_GddNWHandleType = LddHandleType;
  Dcm_ComMCount++;
}

/*******************************************************************************
**                     ComM_DCM_ActiveDiagnostic()                            **
*******************************************************************************/
void ComM_DCM_ActiveDiagnostic(NetworkHandleType LddHandleType)
{
  Dcm_ComM_GddNWHandleType = LddHandleType;
  Dcm_ComMCount++;
}

/*******************************************************************************
**                     TestComM_DCM_ActiveDiagnostic()                                     **
*******************************************************************************/
boolean TestComM_DCM_ActiveDiagnostic(App_DataValidateType LddDataValidate,
  NetworkHandleType LddHandleType)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Handle Type */
      if((Dcm_ComMCount == 0x02) && (Dcm_ComM_GddNWHandleType == LddHandleType))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_ComMCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_ComMCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    
    case M_VALIDATE :
      break;
    
    case M_NOT_INVOKED :
      break;
    
    case S_VALIDATE_SEQ :
      break;
      
    case M_VALIDATE_SEQ :
      break;
    
  }  
    return(LblRetValue);
  }

#endif /* DCM_MODULE_ACTIVE */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

