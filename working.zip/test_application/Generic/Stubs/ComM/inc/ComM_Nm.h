/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: ComM_Nm.h                                                     **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR ComM Module                                           **
**                                                                            **
**  PURPOSE   : Declaration of ComM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

#ifndef COMM_NM_H
#define COMM_NM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototype                                    **
*******************************************************************************/
/* Extern for ComM_Nm_NetworkStartIndication */
extern void ComM_Nm_NetworkStartIndication(NetworkHandleType channel);

extern  boolean TestComM_Nm_NetworkStartIndication
  (App_DataValidateType LucDataValidate,
  NetworkHandleType ExpChannelHandle);

/* Extern for ComM_Nm_NetworkMode */
extern void ComM_Nm_NetworkMode (NetworkHandleType Channel);

extern  boolean TestComM_Nm_NetworkMode (App_DataValidateType LucDataValidate,
  NetworkHandleType ExpChannelHandle);

/* Extern for ComM_Nm_PrepareBusSleepMode */
extern void ComM_Nm_PrepareBusSleepMode (NetworkHandleType Channel);

extern  boolean TestComM_Nm_PrepareBusSleepMode
 (App_DataValidateType LucDataValidate,
   NetworkHandleType ExpChannelHandle);

/* Extern for ComM_Nm_BusSleepMode */
extern void ComM_Nm_BusSleepMode (NetworkHandleType Channel);

extern  boolean TestComM_Nm_BusSleepMode(App_DataValidateType LucDataValidate,
  NetworkHandleType ExpChannelHandle);

/* Extern for ComM_Nm_RestartIndication  */
extern void ComM_Nm_RestartIndication (NetworkHandleType Channel);

extern  boolean TestComM_Nm_RestartIndication
  (App_DataValidateType LucDataValidate,
  NetworkHandleType ExpChannelHandle);

#endif /*COMM_NM_H*/

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
