/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: ComM_BusSM.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR ComM Stub                                             **
**                                                                            **
**  PURPOSE   : Declaration of ComM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

#ifndef COMM_BUSSM_H
#define COMM_BUSSM_H


/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                     Version Information                                    **
*******************************************************************************/
#define COMM_BUSSM_AR_RELEASE_MAJOR_VERSION    4
#define COMM_BUSSM_AR_RELEASE_MINOR_VERSION    0
#define COMM_BUSSM_AR_RELEASE_REVISION_VERSION 3
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void ComM_BusSM_ModeIndication(NetworkHandleType Channel,
                                                        ComM_ModeType *ComMode);

extern boolean TestComM_BusSM_ModeIndication(
  App_DataValidateType LucDataValidate, NetworkHandleType LddExpChannel,
  ComM_ModeType LddExpComMMode);


#endif /* COMM_BUSSM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
