/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: ComM_Dcm.h                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR ComM Stub                                             **
**                                                                            **
**  PURPOSE   : Declaration of ComM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

#ifndef COMM_DCM_H
#define COMM_DCM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototype                                    **
*******************************************************************************/
extern void ComM_DCM_ActiveDiagnostic(NetworkHandleType LddHandleType);

extern boolean TestComM_DCM_ActiveDiagnostic(
  App_DataValidateType LddDataValidate, NetworkHandleType LddHandleType);
	
extern void ComM_DCM_InactiveDiagnostic( NetworkHandleType Channel);

#endif /*COMM_DCM_H*/

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
