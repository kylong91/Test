/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: ComM_EcuMBswM.h                                               **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR ComM Stub                                             **
**                                                                            **
**  PURPOSE   : Declaration of ComM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

#ifndef COMM_ECUMBSWM_H
#define COMM_ECUMBSWM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"
#include "TC_Generic.h"
/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern void ComM_EcuM_WakeUpIndication(NetworkHandleType Channel);

extern boolean TestComM_EcuM_WakeUpIndication(
  App_DataValidateType LucDataValidate, NetworkHandleType LddChannel);
  
extern void ComM_CommunicationAllowed(NetworkHandleType Channel, 
  boolean Allowed);
  
extern  boolean TestComM_CommunicationAllowed(App_DataValidateType  
  LucDataValidate,  NetworkHandleType LddExpChannel, boolean LddExpAllowed);
#endif /* COMM_ECUMBSWM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
