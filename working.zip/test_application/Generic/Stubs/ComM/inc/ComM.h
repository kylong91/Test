/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: ComM.h                                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR ComM Stub                                             **
**                                                                            **
**  PURPOSE   : Declaration of ComM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

#ifndef COMM_H
#define COMM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

#include "ComStack_Types.h"   /* ComStack types header file */
#include "TC_Generic.h"
#if defined(BSWM_MODULE_ACTIVE) || defined(ECUM_MODULE_ACTIVE)
#include "ComM_EcuMBswM.h"
#endif

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
typedef uint8 ComM_ModeType;
typedef uint8 ComM_UserHandleType;
typedef uint8 ComM_PncModeType;

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define COMM_AR_RELEASE_MAJOR_VERSION    4
#define COMM_AR_RELEASE_MINOR_VERSION    0
#define COMM_AR_RELEASE_REVISION_VERSION 3
#define COMM_ARRAY_SIZE                  0x08
#define COMM_INVALID_NETWORKID        0x02
#define COMM_INVALID_COMMUNICATION    0x00
#define PNC_REQUESTED    0x00
#define PNC_READY_SLEEP    0x01
#define PNC_PREPARE_SLEEP    0x02
#define PNC_NO_COMMUNICATION    0x03

#define COMM_NO_COMMUNICATION 0x00
#define COMM_SILENT_COMMUNICATION 0x01
#define COMM_FULL_COMMUNICATION 0x02
#define COMM_NO_COM_REQUEST_PENDING 0x03
#define PNC_FULL_COMMUNICATION 0x04
#define NO_OF_CHANNELS 0x03
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Std_ReturnType ComM_GetRequestedComMode(ComM_UserHandleType User, 
  P2VAR(ComM_ModeType, AUTOMATIC, COMM_APPL_DATA)ComMode);
  
extern Std_ReturnType ComM_LimitChannelToNoComMode(NetworkHandleType Channel, 
  boolean Status);
  
extern Std_ReturnType TestComM_LimitChannelToNoComMode(App_DataValidateType  
  LucDataValidate, NetworkHandleType Channel, boolean Status);
  
extern Std_ReturnType ComM_RequestComMode(ComM_UserHandleType User, 
  ComM_ModeType ComMode);
  
extern void TestComM_DefaultBehavior(void);

extern Std_ReturnType TestComM_RequestComMode(App_DataValidateType  
  LucDataValidate, ComM_UserHandleType User, ComM_ModeType ComMode);

extern  boolean TestComM_GetRequestedComMode(App_DataValidateType  
  LucDataValidate, ComM_UserHandleType LddExpUser, ComM_ModeType LddExpComMode); 
  
extern void AppComM_SetBehaviorGetRequestedComMode(Std_ReturnType LddSetRetVal, 
  ComM_ModeType ComMode);
  
extern void ComM_Init(void);

extern boolean TestComM_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
  
extern void ComM_DeInit(void);

extern boolean TestComM_DeInit(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);

#endif /* COMM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
