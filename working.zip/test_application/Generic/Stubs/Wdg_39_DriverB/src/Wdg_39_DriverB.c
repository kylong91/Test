/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Wdg_39_DriverB.c                                              **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Wdg_39_DriverB Stub                                   **
**                                                                            **
**  PURPOSE   : This application file contains the Wdg_39_DriverB stub        **
**              functions                                                     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By             Description                         **
********************************************************************************
** 1.0.0     05-Dec-2012   JAISON JOHN    Initial version                     **

*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Wdg_39_DriverB.h"
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Wdg_GucDrvBSetModeCount;
WdgIf_ModeType Wdg_GddDrvBMode;

uint8 Wdg_GucDrvBSetTriggerCondCount;
uint16 Wdg_GucDrvBtimeout;

Std_ReturnType Wdg_GddDrvBSetModeRetVal;
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
**                            Wdg_39_DriverB_SetMode()                        **
*******************************************************************************/
Std_ReturnType Wdg_39_DriverB_SetMode(WdgIf_ModeType Mode)
{
  /* Load actual Mode into Global variables */
  Wdg_GddDrvBMode = Mode;
  Wdg_GucDrvBSetModeCount++;

  return(Wdg_GddDrvBSetModeRetVal);
} /* End Wdg_39_DriverB_SetMode() */

/*******************************************************************************
**                         TestWdg_39_DriverB_SetMode()                       **
*******************************************************************************/
boolean TestWdg_39_DriverB_SetMode(App_DataValidateType LddDataValidate,
  WdgIf_ModeType LddExpMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Wdg_GucDrvBSetModeCount == 0x01) &&
        (Wdg_GddDrvBMode == LddExpMode)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Wdg_GucDrvBSetModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Wdg_GucDrvBSetModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Wdg_GucDrvBSetModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestWdg_39_DriverB_SetMode() */

/*******************************************************************************
**                          Wdg_39_DriverB_SetTriggerCondition()              **
*******************************************************************************/
void Wdg_39_DriverB_SetTriggerCondition(uint16 timeout)
{
  /* Load actual timeout into Global variables */
  Wdg_GucDrvBSetTriggerCondCount++;
  Wdg_GucDrvBtimeout = timeout;
}  /* End Wdg_39_DriverB_SetTriggerCondition() */

/*******************************************************************************
**                        TestWdg_39_DriverB_SetTriggerCondition()            **
*******************************************************************************/
boolean TestWdg_39_DriverB_SetTriggerCondition(App_DataValidateType 
  LddDataValidate,uint16 LddExptimeout)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and timeout  */
      if((Wdg_GucDrvBSetTriggerCondCount == 0x01) &&
        (Wdg_GucDrvBtimeout == LddExptimeout))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Wdg_GucDrvBSetTriggerCondCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Wdg_GucDrvBSetTriggerCondCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Wdg_GucDrvBSetTriggerCondCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestWdg_39_DriverB_SetTriggerCondition() */
/*******************************************************************************
**                    TestWdg_39_DriverB_SetModeRetVal()                      **
*******************************************************************************/
void TestWdg_39_DriverB_SetModeRetVal(Std_ReturnType LddWdgReturnVal)
{
  Wdg_GddDrvBSetModeRetVal = LddWdgReturnVal;
}
/* End TestWdg_39_DriverB_SetModeRetVal() */
/*******************************************************************************
**                     TestWdg_39_DriverB_DefaultBehavior()                   **
*******************************************************************************/
void TestWdg_39_DriverB_DefaultBehavior(void)
{
 Wdg_GddDrvBSetModeRetVal = E_OK;
 Wdg_GucDrvBSetModeCount = 0;
 Wdg_GucDrvBSetTriggerCondCount = 0;
 Wdg_GucDrvBtimeout = 0;
} /* End TestWdg_39_DriverB_DefaultBehavior() */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

