/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE:  Lin.c                                                        **
**                                                                            **
**  TARGET    :  ALL                                                          **
**                                                                            **
**  PRODUCT   : AUTOSAR LIN Module                                            **
**                                                                            **
**  PURPOSE   : This file is a stub for LIN Driver Component                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     03-Jan-2012   NKD    Creation of Lin.c module                    **
** 4.0.1     12-Jan-2012   RPS    Updated for LinIf                           **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Lin_39_DriverC.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#ifdef LINIF_MODULE_ACTIVE
/* Variables used for LinIf module  */
Lin_StatusType LinDrvC_GaaGetStatRet[LIN_39_DRIVERC_ARRAY_SIZE];
Std_ReturnType LinDrvC_GaaGetCheckWakeupRet[LIN_39_DRIVERC_ARRAY_SIZE];
uint8 LinDrvC_GucWakeupValCount;
uint8 LinDrvC_GucWakeupCount;
uint8 LinDrvC_GucSendFrameCount;
uint8 LinDrvC_GucGoToSleepCount;
uint8 LinDrvC_GucGoToSleepIntCount;
uint8 LinDrvC_GucGetStatCount;

uint8 LinDrvC_GucCheckWakeupCheckCount;
uint8 LinDrvC_GucCheckWakeupCount;

uint8 LinDrvC_GucWakeupCheckCount;
uint8 LinDrvC_GucSendFrameCheckCount;
uint8 LinDrvC_GucGoToSleepCheckCount;
uint8 LinDrvC_GucGoToSleepIntCheckCount;
uint8 LinDrvC_GucCheckGetStatCount;
uint8 LinDrvC_GaaWakeupChnl[LIN_39_DRIVERC_ARRAY_SIZE];
uint8 LinDrvC_GaaSendFrameChnl[LIN_39_DRIVERC_ARRAY_SIZE];

uint8 LinDrvC_GaaCheckWakeupNw[LIN_39_DRIVERC_ARRAY_SIZE];

uint8 LinDrvC_GaaGoToSleepChnl[LIN_39_DRIVERC_ARRAY_SIZE];
uint8 LinDrvC_GaaGoToSleepIntChnl[LIN_39_DRIVERC_ARRAY_SIZE];
uint8 LinDrvC_GaaGetStatChnl[LIN_39_DRIVERC_ARRAY_SIZE];
uint8 LinDrvC_GaaSendFrameSduData[LIN_39_DRIVERC_ARRAY_SIZE][LIN_39_DRIVERC_DATA_LENGTH];
uint8 LinDrvC_GaaGetStatSduData[LIN_39_DRIVERC_ARRAY_SIZE][LIN_39_DRIVERC_DATA_LENGTH];
Lin_FramePidType LinDrvC_GaaSendFramePid[LIN_39_DRIVERC_ARRAY_SIZE];
Lin_FrameCsModelType LinDrvC_GaaSendFrameCs[LIN_39_DRIVERC_ARRAY_SIZE];
Lin_FrameResponseType LinDrvC_GaaSendFrameResp[LIN_39_DRIVERC_ARRAY_SIZE];
Lin_FrameDlType LinDrvC_GaaSendFrameDl[LIN_39_DRIVERC_ARRAY_SIZE];
/* Variables used for LinIf module  */


/*******************************************************************************
**                       TestLin_39_DriverCDefaultBehavior()                  **
*******************************************************************************/
void TestLin_39_DriverCDefaultBehavior(void)
{
  uint8 LucCount;
  uint8 LucDataCount;
  
  for(LucCount = 0x00; LucCount < LIN_39_DRIVERC_ARRAY_SIZE ; LucCount++)
  {
    LinDrvC_GaaGetStatRet[LucCount] = LIN_OPERATIONAL;
    LinDrvC_GaaSendFrameChnl[LucCount] = 0xFF;
    LinDrvC_GaaGoToSleepChnl[LucCount] = 0xFF;
    LinDrvC_GaaGoToSleepIntChnl[LucCount] = 0xFF;
    LinDrvC_GaaGetStatChnl[LucCount] = 0xFF;
    
    LinDrvC_GaaGetCheckWakeupRet[LucCount] = E_OK;
    
    LinDrvC_GaaSendFramePid[LucCount] = 0xFF;
    LinDrvC_GaaSendFrameCs[LucCount] = LIN_ENHANCED_CS;
    LinDrvC_GaaSendFrameResp[LucCount] = LIN_MASTER_RESPONSE;
    LinDrvC_GaaSendFrameDl[LucCount] = 0xFF;
    for(LucDataCount = 0x00; LucDataCount < LIN_39_DRIVERC_DATA_LENGTH ; 
      LucDataCount++)
    {
      LinDrvC_GaaSendFrameSduData[LucCount][LucDataCount] = 0x00;
      LinDrvC_GaaGetStatSduData[LucCount][LucDataCount] = LucDataCount;
    }    
  }
  LinDrvC_GucWakeupValCount = 0x00;
  LinDrvC_GucWakeupCount = 0x00;
  LinDrvC_GucSendFrameCount = 0x00;
  LinDrvC_GucGoToSleepCount = 0x00;
  LinDrvC_GucGoToSleepIntCount = 0x00;
  
  LinDrvC_GucCheckWakeupCheckCount = 0x00;
  LinDrvC_GucCheckWakeupCount = 0x00;
  
  LinDrvC_GucGetStatCount = 0x00;
  LinDrvC_GucWakeupCheckCount = 0x00;
  LinDrvC_GucSendFrameCheckCount = 0x00;
  LinDrvC_GucGoToSleepCheckCount = 0x00;
  LinDrvC_GucGoToSleepIntCheckCount = 0x00;
  LinDrvC_GucCheckGetStatCount = 0x00;  
} /* End TestLin_39_DriverCDefaultBehavior() */

/*******************************************************************************
**                       Lin_39_DriverCWakeupValidation()                     **
*******************************************************************************/
void Lin_39_DriverC_WakeupValidation(void)
{
  #ifndef TYPICAL_CONFIG
  /* Increment count variable to handle multiple invocations */
  if(LinDrvC_GucWakeupValCount != LIN_39_DRIVERC_ARRAY_SIZE)
  {    
    LinDrvC_GucWakeupValCount++;
  } 
  #endif
} /* End Lin_39_DriverCWakeupValidation() */

/*******************************************************************************
**                       TestLin_39_DriverCWakeupValidation()                 **
*******************************************************************************/
boolean TestLin_39_DriverCWakeupValidation(App_DataValidateType LucDataValidate)
{
  boolean LblRetValue;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if(LinDrvC_GucWakeupValCount == 0x01)
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvC_GucWakeupValCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvC_GucWakeupValCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverCWakeupValidation() */

/*******************************************************************************
**                       Lin_39_DriverCWakeup()                               **
*******************************************************************************/
Std_ReturnType Lin_39_DriverC_Wakeup(uint8 Channel)
{
  #ifndef TYPICAL_CONFIG
  LinDrvC_GaaWakeupChnl[LinDrvC_GucWakeupCount] = Channel;
  /* Increment count variable to handle multiple invocations */
  if(LinDrvC_GucWakeupCount != LIN_39_DRIVERC_ARRAY_SIZE)
  {    
    LinDrvC_GucWakeupCount++;
  }
  #endif
  return(E_OK);
} /* End Lin_39_DriverCWakeup() */

/*******************************************************************************
**                       TestLin_39_DriverCWakeup()                           **
*******************************************************************************/
boolean TestLin_39_DriverCWakeup(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinDrvC_GucWakeupCount == 0x01) && 
        (ExpChannel == LinDrvC_GaaWakeupChnl[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvC_GucWakeupCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvC_GucWakeupCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinDrvC_GucWakeupCheckCount <= LinDrvC_GucWakeupCount) &&
        (ExpChannel == LinDrvC_GaaWakeupChnl[LinDrvC_GucWakeupCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinDrvC_GucWakeupCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinDrvC_GucWakeupCheckCount == LinDrvC_GucWakeupCount)
      {
        LinDrvC_GucWakeupCount = 0;
        LinDrvC_GucWakeupCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinDrvC_GucWakeupCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == LinDrvC_GaaWakeupChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverCWakeup() */

/*******************************************************************************
**                       Lin_39_DriverC_CheckWakeup()                         **
*******************************************************************************/
Std_ReturnType Lin_39_DriverC_CheckWakeup(uint8 LinNetwork )
{
  #ifndef TYPICAL_CONFIG
  LinDrvC_GaaCheckWakeupNw[LinDrvC_GucCheckWakeupCount] = LinNetwork;
  /* Increment count variable to handle multiple invocations */
  if(LinDrvC_GucCheckWakeupCount != LIN_39_DRIVERC_ARRAY_SIZE)
  {    
    LinDrvC_GucCheckWakeupCount++;
  } 
  return(LinDrvC_GaaGetCheckWakeupRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcv_CheckWakeup() */

/*******************************************************************************
**                       TestLin_39_DriverC_CheckWakeup()                     **
*******************************************************************************/
boolean TestLin_39_DriverC_CheckWakeup(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinDrvC_GucCheckWakeupCount == 0x01) && 
        (ExpLinNetwork == LinDrvC_GaaCheckWakeupNw[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvC_GucCheckWakeupCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvC_GucCheckWakeupCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinDrvC_GucCheckWakeupCheckCount <= LinDrvC_GucCheckWakeupCount) &&
        (ExpLinNetwork == LinDrvC_GaaCheckWakeupNw[LinDrvC_GucCheckWakeupCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinDrvC_GucCheckWakeupCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinDrvC_GucCheckWakeupCheckCount == LinDrvC_GucCheckWakeupCount)
      {
        LinDrvC_GucCheckWakeupCount = 0;
        LinDrvC_GucCheckWakeupCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinDrvC_GucCheckWakeupCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinDrvC_GaaCheckWakeupNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcv_CheckWakeup() */

/*******************************************************************************
**                       Lin_39_DriverCSendFrame()                            **
*******************************************************************************/
Std_ReturnType Lin_39_DriverC_SendFrame(uint8 Channel, Lin_PduType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8 *LpSduPtr;
  LinDrvC_GaaSendFrameChnl[LinDrvC_GucSendFrameCount] = Channel;
  LinDrvC_GaaSendFramePid[LinDrvC_GucSendFrameCount] = PduInfoPtr->Pid;
  LinDrvC_GaaSendFrameCs[LinDrvC_GucSendFrameCount] = PduInfoPtr->Cs;
  LinDrvC_GaaSendFrameResp[LinDrvC_GucSendFrameCount] = PduInfoPtr->Drc;
  LinDrvC_GaaSendFrameDl[LinDrvC_GucSendFrameCount] = PduInfoPtr->Dl;
  /*Check whether Frame Length is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->Dl > LIN_39_DRIVERC_DATA_LENGTH)
  {
    LucDataLength = LIN_39_DRIVERC_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->Dl;
  }
  if(PduInfoPtr->Drc == LIN_MASTER_RESPONSE)
  {
    LpSduPtr = PduInfoPtr->SduPtr;
    /* Copy the actual data into global array from actual SduPtr */
    for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
    {
      LinDrvC_GaaSendFrameSduData[LinDrvC_GucSendFrameCount][LucDataIndex] = 
        *LpSduPtr;
      LpSduPtr++;
    }
  }
  /* Increment count variable to handle multiple invocations */
  if(LinDrvC_GucSendFrameCount != LIN_39_DRIVERC_ARRAY_SIZE)
  {    
    LinDrvC_GucSendFrameCount++;
  }  
  #endif
  return(E_OK);
} /* End Lin_39_DriverCSendFrame() */

/*******************************************************************************
**                            TestLin_39_DriverCSendFrame()                   **
*******************************************************************************/
boolean TestLin_39_DriverCSendFrame(App_DataValidateType LucDataValidate,
  uint8 ExpChannel, Lin_PduType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  PduInfoType ExpPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinDrvC_GucSendFrameCount == 0x01) && 
        (ExpChannel == LinDrvC_GaaSendFrameChnl[0]) && 
        (ExpPduInfoPtr->Pid == LinDrvC_GaaSendFramePid[0]) && 
        (ExpPduInfoPtr->Cs == LinDrvC_GaaSendFrameCs[0]) && 
        (ExpPduInfoPtr->Drc == LinDrvC_GaaSendFrameResp[0]))
      {
        if(ExpPduInfoPtr->SduPtr != NULL_PTR)
        {
        ActPduInfo.SduLength = LinDrvC_GaaSendFrameDl[0];
        ActPduInfo.SduDataPtr = &LinDrvC_GaaSendFrameSduData[0][0];
        ExpPduInfo.SduLength = ExpPduInfoPtr->Dl;
        ExpPduInfo.SduDataPtr = ExpPduInfoPtr->SduPtr;

        /* Validate Data Length and Data */
        if(LinDriverCTest_ValidateData(&ExpPduInfo, &ActPduInfo))
          {
            LblRetValue = STEP_PASSED;
          }
        }
        else
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvC_GucSendFrameCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvC_GucSendFrameCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinDrvC_GucSendFrameCheckCount <= LinDrvC_GucSendFrameCount) &&
        (ExpChannel == LinDrvC_GaaSendFrameChnl[LinDrvC_GucSendFrameCheckCount])&& 
        (ExpPduInfoPtr->Pid == LinDrvC_GaaSendFramePid[LinDrvC_GucSendFrameCheckCount]) 
        && (ExpPduInfoPtr->Cs == LinDrvC_GaaSendFrameCs[LinDrvC_GucSendFrameCheckCount]) 
        && (ExpPduInfoPtr->Drc == 
        LinDrvC_GaaSendFrameResp[LinDrvC_GucSendFrameCheckCount]))
      {
        if(ExpPduInfoPtr->SduPtr != NULL_PTR)
        {
        ActPduInfo.SduLength = LinDrvC_GaaSendFrameDl[LinDrvC_GucSendFrameCheckCount];
        ActPduInfo.SduDataPtr = 
          &LinDrvC_GaaSendFrameSduData[LinDrvC_GucSendFrameCheckCount][0];
        ExpPduInfo.SduLength = ExpPduInfoPtr->Dl;
        ExpPduInfo.SduDataPtr = ExpPduInfoPtr->SduPtr;

        /* Validate Data Length and Data */
        if(LinDriverCTest_ValidateData(&ExpPduInfo, &ActPduInfo))
          {
            LblRetValue = STEP_PASSED;
          }
        }
        else
        {
          LblRetValue = STEP_PASSED;
        }
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinDrvC_GucSendFrameCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinDrvC_GucSendFrameCheckCount == LinDrvC_GucSendFrameCount)
      {
        LinDrvC_GucSendFrameCount = 0;
        LinDrvC_GucSendFrameCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinDrvC_GucSendFrameCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == LinDrvC_GaaSendFrameChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverCSendFrame() */

/*******************************************************************************
**                       Lin_39_DriverCGoToSleep()                            **
*******************************************************************************/
Std_ReturnType Lin_39_DriverC_GoToSleep(uint8 Channel)
{
  #ifndef TYPICAL_CONFIG
  LinDrvC_GaaGoToSleepChnl[LinDrvC_GucGoToSleepCount] = Channel;
  /* Increment count variable to handle multiple invocations */
  if(LinDrvC_GucGoToSleepCount != LIN_39_DRIVERC_ARRAY_SIZE)
  {    
    LinDrvC_GucGoToSleepCount++;
  }
  #endif
  return(E_OK);
} /* End Lin_39_DriverCGoToSleep() */

/*******************************************************************************
**                       TestLin_39_DriverCGoToSleep()                        **
*******************************************************************************/
boolean TestLin_39_DriverCGoToSleep(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinDrvC_GucGoToSleepCount == 0x01) && 
        (ExpChannel == LinDrvC_GaaGoToSleepChnl[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvC_GucGoToSleepCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvC_GucGoToSleepCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinDrvC_GucGoToSleepCheckCount <= LinDrvC_GucGoToSleepCount) &&
        (ExpChannel == LinDrvC_GaaGoToSleepChnl[LinDrvC_GucGoToSleepCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinDrvC_GucGoToSleepCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinDrvC_GucGoToSleepCheckCount == LinDrvC_GucGoToSleepCount)
      {
        LinDrvC_GucGoToSleepCount = 0;
        LinDrvC_GucGoToSleepCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinDrvC_GucGoToSleepCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == LinDrvC_GaaGoToSleepChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverCGoToSleep() */

/*******************************************************************************
**                       Lin_39_DriverCGoToSleepInternal()                    **
*******************************************************************************/
Std_ReturnType Lin_39_DriverC_GoToSleepInternal(uint8 Channel)
{
  #ifndef TYPICAL_CONFIG
  LinDrvC_GaaGoToSleepIntChnl[LinDrvC_GucGoToSleepIntCount] = Channel;
  /* Increment count variable to handle multiple invocations */
  if(LinDrvC_GucGoToSleepIntCount != LIN_39_DRIVERC_ARRAY_SIZE)
  {    
    LinDrvC_GucGoToSleepIntCount++;
  }
  #endif
  return(E_OK);
} /* End Lin_39_DriverCGoToSleepInternal() */

/*******************************************************************************
**                       TestLin_39_DriverCGoToSleepInternal()                **
*******************************************************************************/
boolean TestLin_39_DriverCGoToSleepInternal(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinDrvC_GucGoToSleepIntCount == 0x01) && 
        (ExpChannel == LinDrvC_GaaGoToSleepIntChnl[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvC_GucGoToSleepIntCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvC_GucGoToSleepIntCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinDrvC_GucGoToSleepIntCheckCount <= LinDrvC_GucGoToSleepIntCount) &&
        (ExpChannel == LinDrvC_GaaGoToSleepIntChnl[LinDrvC_GucGoToSleepIntCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinDrvC_GucGoToSleepIntCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinDrvC_GucGoToSleepIntCheckCount == LinDrvC_GucGoToSleepIntCount)
      {
        LinDrvC_GucGoToSleepIntCount = 0;
        LinDrvC_GucGoToSleepIntCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinDrvC_GucGoToSleepIntCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == LinDrvC_GaaGoToSleepIntChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverCGoToSleepInternal() */

/*******************************************************************************
**                       Lin_39_DriverCGetStatus()                            **
*******************************************************************************/
Lin_StatusType Lin_39_DriverC_GetStatus(uint8 Channel, uint8 **Lin_SduPtr)
{
  #ifndef TYPICAL_CONFIG
  LinDrvC_GaaGetStatChnl[LinDrvC_GucGetStatCount] = Channel;
  /* Copy the actual data into actual SduPtr from global array  */
  *Lin_SduPtr = &LinDrvC_GaaGetStatSduData[Channel][0];
  /* Increment count variable to handle multiple invocations */
  if(LinDrvC_GucGetStatCount != LIN_39_DRIVERC_ARRAY_SIZE)
  {    
    LinDrvC_GucGetStatCount++;
  }
  return(LinDrvC_GaaGetStatRet[Channel]);
  #else
  return(LIN_TX_OK);
  #endif
  
} /* End Lin_39_DriverCGetStatus() */

/*******************************************************************************
**                       TestLin_39_DriverCGetStatus()                        **
*******************************************************************************/
boolean TestLin_39_DriverCGetStatus(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinDrvC_GucGetStatCount == 0x01) && 
        (ExpChannel == LinDrvC_GaaGetStatChnl[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvC_GucGetStatCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvC_GucGetStatCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinDrvC_GucCheckGetStatCount <= LinDrvC_GucGetStatCount) &&
        (ExpChannel == LinDrvC_GaaGetStatChnl[LinDrvC_GucCheckGetStatCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinDrvC_GucCheckGetStatCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinDrvC_GucCheckGetStatCount == LinDrvC_GucGetStatCount)
      {
        LinDrvC_GucGetStatCount = 0;
        LinDrvC_GucCheckGetStatCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinDrvC_GucGetStatCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == LinDrvC_GaaGetStatChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverCGetStatus() */

/*******************************************************************************
**                     TestSetLin_39_DriverCGetStatusRetVal()                 **
*******************************************************************************/
void TestSetLin_39_DriverCGetStatusRetVal(uint8 LucChannel, uint8 *LpSduData, 
  Lin_StatusType LddRetVal)
{
  uint8 LucCount;
  LinDrvC_GaaGetStatRet[LucChannel] = LddRetVal;
  if( LpSduData != NULL_PTR)
  {
    for(LucCount = 0 ; LucCount < LIN_39_DRIVERC_DATA_LENGTH ; LucCount++)
    {
      LinDrvC_GaaGetStatSduData[LucChannel][LucCount] = *LpSduData;
      LpSduData++;
    }
  }  
} /* End TestSetLin_39_DriverCGetStatusRetVal */

/*******************************************************************************
**                       LinDriverCTest_ValidateData()                               **
*******************************************************************************/
boolean LinDriverCTest_ValidateData(PduInfoType *LddExpPduInfo, 
  PduInfoType *LddActPduInfo)
{
  uint8 *LpActualDataPtr;
  uint8 *LpExpDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  /* Load the ExpPduInfo to local variables */
  LddSduCount = LddExpPduInfo->SduLength;
  LpExpDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  /* Check the Data length */
  if((LddExpPduInfo->SduLength <= LIN_39_DRIVERC_DATA_LENGTH) &&
    (LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }
   /* Check the sdu data */
  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    if(*LpActualDataPtr != *LpExpDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualDataPtr++;
    LpExpDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* End LinDriverCTest_ValidateData() */
#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
