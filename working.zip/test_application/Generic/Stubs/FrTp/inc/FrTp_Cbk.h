/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: FrTp_Cbk.h                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FrTp_Cbk Stub                                         **
**                                                                            **
**  PURPOSE   : Declaration of FrTp_Cbk stub functions                        **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/

#ifndef FRTP_CBK_H
#define FRTP_CBK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"   /* ComStack types header file */
#include "TC_Generic.h"


/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define FRTP_DATA_LENGTH                      0x40
#define FRTP_ARRAY_SIZE                       0x04

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void TestFrTp_DefaultBehavior(void);

extern void TestSetFrTp_TxPduIdForRet(PduIdType LddPduIdForRet);

extern Std_ReturnType FrTp_TriggerTransmit(PduIdType FrTpTxSduId,
        PduInfoType *FrTpTxInfoPtr);

extern void TestFrTp_TransmitSetRetVal(Std_ReturnType LddRetVal);

extern void FrTp_TxConfirmation(PduIdType TxPduId);

extern boolean TestFrTp_TriggerTransmit(App_DataValidateType LucDataValidate,
  PduIdType TxPduId);

extern boolean TestFrTp_TxConfirmation(App_DataValidateType LucDataValidate,
PduIdType TxPduId);

extern boolean TestFrTp_Transmit(App_DataValidateType LucDataValidate,
  PduIdType ExpFrTpTxSduId, const PduInfoType *ExpFrTpTxInfoPtr);

extern boolean FrTpTest_ValidateData(PduInfoType* LddExpPduInfo,
  PduInfoType* LddActPduInfo);
  
extern void FrTp_RxIndication(PduIdType RxPduId, PduInfoType* PduInfoPtr);

extern boolean TestFrTp_RxIndication(App_DataValidateType LucDataValidate,
PduIdType RxPduId);

#endif /* FRTP_CBK_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
