/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: FrTp.h                                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FrTp Stub                                             **
**                                                                            **
**  PURPOSE   : Declaration of FrTp stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/

#ifndef FrTp_H
#define FrTp_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"   /* ComStack types header file */
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define FRTP_AR_RELEASE_MAJOR_VERSION         4
#define FRTP_AR_RELEASE_MINOR_VERSION         0
#define FRTP_AR_RELEASE_REVISION_VERSION      3

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define FRTP_DATA_LENGTH                      0x40
#define FRTP_ARRAY_SIZE                       0x04

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
typedef uint8 FrTp_ConfigType;

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void TestFrTp_DefaultBehavior(void);

extern void TestSetFrTp_TxPduIdForRet(PduIdType LddPduIdForRet);

extern Std_ReturnType FrTp_Transmit(PduIdType FrTpTxSduId,
const PduInfoType *FrTpTxInfoPtr);

extern void TestFrTp_TransmitSetRetVal(Std_ReturnType LddRetVal);

extern boolean TestFrTp_Transmit(App_DataValidateType LucDataValidate,
  PduIdType ExpFrTpTxSduId, const PduInfoType *ExpFrTpTxInfoPtr);

extern boolean FrTpTest_ValidateData(PduInfoType* LddExpPduInfo,
  PduInfoType* LddActPduInfo);
extern Std_ReturnType FrTp_ChangeParameter(PduIdType id,
    TPParameterType parameter, uint16 value);
    
extern Std_ReturnType FrTp_CancelTransmit(PduIdType id);
extern boolean TestFrTp_ChangeParameter(App_DataValidateType LucDataValidate,
  PduIdType ExpFrTpTxSduId, TPParameterType ExpParameter, uint16 Expvalue);
extern void TestFrTp_CancelTransmitSetRetVal(Std_ReturnType LddRetVal);
extern Std_ReturnType FrTp_CancelReceive(PduIdType id);
extern boolean TestFrTp_CancelReceive(App_DataValidateType LucDataValidate,
  PduIdType ExpFrTpRxSduId);
extern void TestFrTp_CancelReceiveSetRetVal(Std_ReturnType LddRetVal);

extern void FrTp_Init(const FrTp_ConfigType* configPtr);
extern boolean TestFrTp_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
#endif /* FRTP_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
