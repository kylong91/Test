/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: FrTp.c                                                        **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FrTp Module                                           **
**                                                                            **
**  PURPOSE   : This application file contains the FrTp stub functions        **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0    30-Aug-2012   Ravi Tiwari    Initial version                      **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#ifdef FRIF_MODULE_ACTIVE
#include "FrTp_Cbk.h"
#else
#include "FrTp.h"
#endif
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
PduIdType FrTp_GaaFrTpTxSduId[FRTP_ARRAY_SIZE];
PduIdType FrTp_GaaFrTpRxSduId[FRTP_ARRAY_SIZE];
PduIdType FrTp_GaaFrTpParameter[FRTP_ARRAY_SIZE];
PduIdType FrTp_GaaFrTpValue[FRTP_ARRAY_SIZE];
uint32 FrTp_GaaSduLength[FRTP_ARRAY_SIZE];
uint8 FrTp_GaaTransmitData[FRTP_ARRAY_SIZE][FRTP_DATA_LENGTH];
Std_ReturnType FrTp_GddTransmitReturn;
Std_ReturnType FrTp_GddChangeParameterReturn;
Std_ReturnType FrTp_GddCancelTransmitReturn;
Std_ReturnType FrTp_GddCancelReceiveReturn;
uint8 FrTp_GucTransmitCount;
uint8 FrTp_GucTransmitCheckCount;
PduIdType FrTp_GddPduIdForRet;

#ifdef BSWM_MODULE_ACTIVE
uint8 FrTp_GucInitCnt;
uint8 FrTp_GucInitSeqCnt;
#endif

#ifdef FRIF_MODULE_ACTIVE
PduIdType FrTp_FrIfGucTxPduId;
uint8 FrTp_FrIfGucTxConfirmationcount;  

PduIdType FrTp_FrIfGucRxPduId;
uint8 FrTp_FrIfGucRxConfirmationcount;
#endif
/*******************************************************************************
**                       TestFrTp_DefaultBehavior()                           **
*******************************************************************************/
void TestFrTp_DefaultBehavior(void)
{
  FrTp_GddTransmitReturn = E_OK;
  FrTp_GucTransmitCount = 0;
  FrTp_GucTransmitCheckCount = 0;
  FrTp_GddPduIdForRet = (PduIdType)0xFFFF;
} /* End TestFrTp_DefaultBehavior() */

/*******************************************************************************
**                     TestSetFrTp_TxPduIdForRet()                            **
*******************************************************************************/
void TestSetFrTp_TxPduIdForRet(PduIdType LddPduIdForRet)
{
  FrTp_GddPduIdForRet = LddPduIdForRet;
} /* End TestSetFrTp_TxPduIdForRet() */

#ifdef FRIF_MODULE_ACTIVE
/*******************************************************************************
**                              FrTp_TriggerTransmit()                        **
*******************************************************************************/
Std_ReturnType FrTp_TriggerTransmit(PduIdType FrTpTxSduId,
      PduInfoType *FrTpTxInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint32 LulDataLength;
  uint8* LpSduDataPtr;
  
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  FrTp_GaaFrTpTxSduId[FrTp_GucTransmitCount] = FrTpTxSduId;
  FrTp_GaaSduLength[FrTp_GucTransmitCount] = FrTpTxInfoPtr->SduLength;
  LpSduDataPtr = FrTpTxInfoPtr->SduDataPtr;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(FrTpTxInfoPtr->SduLength > FRTP_DATA_LENGTH)
  {
    LulDataLength = FRTP_DATA_LENGTH;    
  }
  else
  {
    LulDataLength = FrTpTxInfoPtr->SduLength;
  }
  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0; LucDataIndex < LulDataLength; LucDataIndex++)
  {
    FrTp_GaaTransmitData[FrTp_GucTransmitCount][LucDataIndex] = 
      *LpSduDataPtr;
    LpSduDataPtr++;
  }
  /* Increment count variable to handle multiple invocations */
  if(FrTp_GucTransmitCount != FRTP_ARRAY_SIZE)
  {    
    FrTp_GucTransmitCount++;
  }
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((FrTp_GddPduIdForRet == FrTpTxSduId) ||
    (FrTp_GddTransmitReturn == E_NOT_OK))
  {
    FrTp_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif
  #endif
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(FrTp_GddTransmitReturn);
  #endif
} /* End FrTp_Transmit() */


/*******************************************************************************
**                            TestFrTp_TriggerTransmit()                      **
*******************************************************************************/
boolean TestFrTp_TriggerTransmit(App_DataValidateType LucDataValidate,
PduIdType TxPduId)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((FrTp_GucTransmitCount == 0x01) && 
        (FrTp_GaaFrTpTxSduId[FrTp_GucTransmitCount - 1] == TxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrTp_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrTp_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}
/*******************************************************************************
**                       FrTp_RxIndication()                                  **
*******************************************************************************/
void FrTp_RxIndication(PduIdType RxPduId, PduInfoType* PduInfoPtr)
{
  UNUSED(PduInfoPtr);
  FrTp_FrIfGucRxPduId = RxPduId;
  FrTp_FrIfGucRxConfirmationcount++;  
} /* End FrTp_RxIndication() */
/*******************************************************************************
**                       TestFrTp_RxIndication()                              **
*******************************************************************************/
boolean TestFrTp_RxIndication(App_DataValidateType LucDataValidate,
PduIdType RxPduId)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((FrTp_FrIfGucRxConfirmationcount == 0x01) && 
        (FrTp_FrIfGucRxPduId == RxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrTp_FrIfGucRxConfirmationcount = 0;      
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrTp_FrIfGucRxConfirmationcount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}
/*******************************************************************************
**                            FrTp_TxConfirmation()                           **
*******************************************************************************/
void FrTp_TxConfirmation(PduIdType TxPduId)
{
  FrTp_FrIfGucTxPduId = TxPduId;
  FrTp_FrIfGucTxConfirmationcount++;  
}

boolean TestFrTp_TxConfirmation(App_DataValidateType LucDataValidate,
PduIdType TxPduId)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((FrTp_FrIfGucTxConfirmationcount == 0x01) && 
        (FrTp_FrIfGucTxPduId == TxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrTp_FrIfGucTxConfirmationcount = 0;      
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrTp_FrIfGucTxConfirmationcount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}
#endif

/*******************************************************************************
**                              FrTp_Transmit()                               **
*******************************************************************************/
Std_ReturnType FrTp_Transmit(PduIdType FrTpTxSduId,
const PduInfoType *FrTpTxInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint32 LulDataLength;
  uint8* LpSduDataPtr;
  
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  FrTp_GaaFrTpTxSduId[FrTp_GucTransmitCount] = FrTpTxSduId;
  FrTp_GaaSduLength[FrTp_GucTransmitCount] = FrTpTxInfoPtr->SduLength;
  LpSduDataPtr = FrTpTxInfoPtr->SduDataPtr;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(FrTpTxInfoPtr->SduLength > FRTP_DATA_LENGTH)
  {
    LulDataLength = FRTP_DATA_LENGTH;    
  }
  else
  {
    LulDataLength = FrTpTxInfoPtr->SduLength;
  }
  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0; LucDataIndex < LulDataLength; LucDataIndex++)
  {
    FrTp_GaaTransmitData[FrTp_GucTransmitCount][LucDataIndex] = 
      *LpSduDataPtr;
    LpSduDataPtr++;
  }
  /* Increment count variable to handle multiple invocations */
  if(FrTp_GucTransmitCount != FRTP_ARRAY_SIZE)
  {    
    FrTp_GucTransmitCount++;
  }
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((FrTp_GddPduIdForRet == FrTpTxSduId) ||
    (FrTp_GddTransmitReturn == E_NOT_OK))
  {
    FrTp_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif
  #endif
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(FrTp_GddTransmitReturn);
  #endif
} /* End FrTp_Transmit() */

/*******************************************************************************
**                            TestFrTp_Transmit()                             **
*******************************************************************************/
boolean TestFrTp_Transmit(App_DataValidateType LucDataValidate,
PduIdType ExpFrTpTxSduId, const PduInfoType *ExpFrTpTxInfoPtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrTp_GucTransmitCount == 0x01) && 
        (ExpFrTpTxSduId == FrTp_GaaFrTpTxSduId[0]))
      {
        ActPduInfo.SduLength = FrTp_GaaSduLength[0];
        ActPduInfo.SduDataPtr = &FrTp_GaaTransmitData[0][0];

        /* Validate SduLength and Data */
        if(FrTpTest_ValidateData((PduInfoType *)ExpFrTpTxInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      FrTp_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrTp_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((FrTp_GucTransmitCheckCount <= FrTp_GucTransmitCount) &&
        (ExpFrTpTxSduId == FrTp_GaaFrTpTxSduId[FrTp_GucTransmitCheckCount]))
      {
        ActPduInfo.SduLength =
          FrTp_GaaSduLength[FrTp_GucTransmitCheckCount];
        ActPduInfo.SduDataPtr =
          &FrTp_GaaTransmitData[FrTp_GucTransmitCheckCount][0];

        /* Validate the SduLength and Data */
        if(FrTpTest_ValidateData((PduInfoType *)ExpFrTpTxInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrTp_GucTransmitCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrTp_GucTransmitCheckCount == FrTp_GucTransmitCount)
      {
        FrTp_GucTransmitCount = 0;
        FrTp_GucTransmitCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrTp_GucTransmitCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpFrTpTxSduId == FrTp_GaaFrTpTxSduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrTp_Transmit() */

/*******************************************************************************
**                          TestFrTp_TransmitSetRetVal()                      **
*******************************************************************************/
void TestFrTp_TransmitSetRetVal(Std_ReturnType LddRetVal)
{
  FrTp_GddTransmitReturn = LddRetVal;
}/* End TestFrTp_TransmitSetRetVal() */

/*******************************************************************************
**                       FrTpTest_ValidateData()                              **
*******************************************************************************/
boolean FrTpTest_ValidateData(PduInfoType* LddExpPduInfo, 
PduInfoType* LddActPduInfo)
{
  uint8 *LpActualDataPtr;
  uint8 *LpExpDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  LddSduCount = LddExpPduInfo->SduLength;
  LpExpDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  if((LddExpPduInfo->SduLength <= FRTP_DATA_LENGTH) &&
    (LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }
  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    if(*LpActualDataPtr != *LpExpDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualDataPtr++;
    LpExpDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* End FrTpTest_ValidateData() */
#ifdef BSWM_MODULE_ACTIVE
/*******************************************************************************
**                          FrTp_Init()                                       **
*******************************************************************************/

void FrTp_Init(const FrTp_ConfigType* configPtr)
{
	UNUSED(configPtr);
  App_GucApiSeqCnt++;
	FrTp_GucInitSeqCnt = App_GucApiSeqCnt;
	FrTp_GucInitCnt++;
}/* End FrTp_Init() */

/*******************************************************************************
**                           TestFrTp_Init()                                  **
*******************************************************************************/
boolean TestFrTp_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(FrTp_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      FrTp_GucInitCnt = 0;
      FrTp_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(FrTp_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      FrTp_GucInitCnt = 0;
      FrTp_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrTp_Init() */
#endif
/*******************************************************************************
**                       FrTp_CancelTransmit()                                **
*******************************************************************************/
Std_ReturnType FrTp_CancelTransmit(PduIdType id)
{
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  FrTp_GaaFrTpTxSduId[FrTp_GucTransmitCount] = id;
  /* Increment count variable to handle multiple invocations */
  if(FrTp_GucTransmitCount != FRTP_ARRAY_SIZE)
  {    
    FrTp_GucTransmitCount++;
  }
  
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((FrTp_GddPduIdForRet == id) ||
    (FrTp_GddCancelTransmitReturn == E_NOT_OK))
  {
    FrTp_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(FrTp_GddCancelTransmitReturn);
  #endif
}
/*******************************************************************************
**                            TestFrTp_CancelTransmit()                       **
*******************************************************************************/
boolean TestFrTp_CancelTransmit(App_DataValidateType LucDataValidate,
  PduIdType ExpFrTpTxSduId)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrTp_GucTransmitCount == 0x01) && 
        (ExpFrTpTxSduId == FrTp_GaaFrTpTxSduId[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrTp_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrTp_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrTp_Transmit() */

/*******************************************************************************
**                          TestFrTp_CancelTransmitSetRetVal()                **
*******************************************************************************/
void TestFrTp_CancelTransmitSetRetVal(Std_ReturnType LddRetVal)
{
  FrTp_GddCancelTransmitReturn = LddRetVal;
}/* End TestFrTp_TransmitSetRetVal() */

/*******************************************************************************
**                       FrTp_CancelReceive()                                 **
*******************************************************************************/
Std_ReturnType FrTp_CancelReceive(PduIdType id)
{
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  FrTp_GaaFrTpRxSduId[FrTp_GucTransmitCount] = id;
  /* Increment count variable to handle multiple invocations */
  if(FrTp_GucTransmitCount != FRTP_ARRAY_SIZE)
  {    
    FrTp_GucTransmitCount++;
  }
  
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((FrTp_GddPduIdForRet == id) ||
    (FrTp_GddCancelReceiveReturn == E_NOT_OK))
  {
    FrTp_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(FrTp_GddCancelReceiveReturn);
  #endif
}
/*******************************************************************************
**                            TestFrTp_CancelReceive()                        **
*******************************************************************************/
boolean TestFrTp_CancelReceive(App_DataValidateType LucDataValidate,
  PduIdType ExpFrTpRxSduId)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrTp_GucTransmitCount == 0x01) && 
        (ExpFrTpRxSduId == FrTp_GaaFrTpRxSduId[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrTp_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrTp_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrTp_CancelReceive() */

/*******************************************************************************
**                          TestFrTp_CancelReceiveSetRetVal()                 **
*******************************************************************************/
void TestFrTp_CancelReceiveSetRetVal(Std_ReturnType LddRetVal)
{
  FrTp_GddCancelReceiveReturn = LddRetVal;
}/* End TestFrTp_CancelReceiveSetRetVal() */
/*******************************************************************************
**                       FrTp_ChangeParameter()                               **
*******************************************************************************/
Std_ReturnType FrTp_ChangeParameter(PduIdType id,
    TPParameterType parameter, uint16 value)
{  
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  FrTp_GaaFrTpTxSduId[FrTp_GucTransmitCount] = id;
  FrTp_GaaFrTpParameter[FrTp_GucTransmitCount] = parameter;
  FrTp_GaaFrTpValue[FrTp_GucTransmitCount] = (uint8)value;
  /* Increment count variable to handle multiple invocations */
  if(FrTp_GucTransmitCount != FRTP_ARRAY_SIZE)
  {    
    FrTp_GucTransmitCount++;
  }
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((FrTp_GddPduIdForRet == id) ||
    (FrTp_GddChangeParameterReturn == E_NOT_OK))
  {
    FrTp_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(FrTp_GddChangeParameterReturn);
  #endif
}

/*******************************************************************************
**                            TestFrTp_ChangeParameter()                      **
*******************************************************************************/
boolean TestFrTp_ChangeParameter(App_DataValidateType LucDataValidate,
  PduIdType ExpFrTpTxSduId, TPParameterType ExpParameter, uint16 Expvalue)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrTp_GucTransmitCount == 0x01) && 
        (ExpFrTpTxSduId == FrTp_GaaFrTpTxSduId[0]) && 
        (ExpParameter == FrTp_GaaFrTpParameter[0]) && 
        (Expvalue == FrTp_GaaFrTpValue[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrTp_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrTp_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrTp_Transmit() */

/*******************************************************************************
**                          TestFrTp_ChangeParameterSetRetVal()               **
*******************************************************************************/
void TestFrTp_ChangeParameterSetRetVal(Std_ReturnType LddRetVal)
{
  FrTp_GddChangeParameterReturn = LddRetVal;
}/* End TestFrTp_TransmitSetRetVal() */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
