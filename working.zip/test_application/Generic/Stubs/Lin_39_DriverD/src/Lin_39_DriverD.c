/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE:  Lin.c                                                        **
**                                                                            **
**  TARGET    :  ALL                                                          **
**                                                                            **
**  PRODUCT   : AUTOSAR LIN Module                                            **
**                                                                            **
**  PURPOSE   : This file is a stub for LIN Driver Component                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     03-Jan-2012   NKD    Creation of Lin.c module                    **
** 4.0.1     12-Jan-2012   RPS    Updated for LinIf                           **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Lin_39_DriverD.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#ifdef LINIF_MODULE_ACTIVE
/* Variables used for LinIf module  */
Lin_StatusType LinDrvD_GaaGetStatRet[LIN_39_DRIVERD_ARRAY_SIZE];
Std_ReturnType LinDrvD_GaaGetCheckWakeupRet[LIN_39_DRIVERD_ARRAY_SIZE];
uint8 LinDrvD_GucWakeupValCount;
uint8 LinDrvD_GucWakeupCount;
uint8 LinDrvD_GucSendFrameCount;
uint8 LinDrvD_GucGoToSleepCount;
uint8 LinDrvD_GucGoToSleepIntCount;
uint8 LinDrvD_GucGetStatCount;

uint8 LinDrvD_GucCheckWakeupCheckCount;
uint8 LinDrvD_GucCheckWakeupCount;


uint8 LinDrvD_GucWakeupCheckCount;
uint8 LinDrvD_GucSendFrameCheckCount;
uint8 LinDrvD_GucGoToSleepCheckCount;
uint8 LinDrvD_GucGoToSleepIntCheckCount;
uint8 LinDrvD_GucCheckGetStatCount;
uint8 LinDrvD_GaaWakeupChnl[LIN_39_DRIVERD_ARRAY_SIZE];
uint8 LinDrvD_GaaSendFrameChnl[LIN_39_DRIVERD_ARRAY_SIZE];
uint8 LinDrvD_GaaGoToSleepChnl[LIN_39_DRIVERD_ARRAY_SIZE];

uint8 LinDrvD_GaaCheckWakeupNw[LIN_39_DRIVERD_ARRAY_SIZE];

uint8 LinDrvD_GaaGoToSleepIntChnl[LIN_39_DRIVERD_ARRAY_SIZE];
uint8 LinDrvD_GaaGetStatChnl[LIN_39_DRIVERD_ARRAY_SIZE];
uint8 LinDrvD_GaaSendFrameSduData[LIN_39_DRIVERD_ARRAY_SIZE][LIN_39_DRIVERD_DATA_LENGTH];
uint8 LinDrvD_GaaGetStatSduData[LIN_39_DRIVERD_ARRAY_SIZE][LIN_39_DRIVERD_DATA_LENGTH];
Lin_FramePidType LinDrvD_GaaSendFramePid[LIN_39_DRIVERD_ARRAY_SIZE];
Lin_FrameCsModelType LinDrvD_GaaSendFrameCs[LIN_39_DRIVERD_ARRAY_SIZE];
Lin_FrameResponseType LinDrvD_GaaSendFrameResp[LIN_39_DRIVERD_ARRAY_SIZE];
Lin_FrameDlType LinDrvD_GaaSendFrameDl[LIN_39_DRIVERD_ARRAY_SIZE];
/* Variables used for LinIf module  */


/*******************************************************************************
**                       TestLin_39_DriverDDefaultBehavior()                  **
*******************************************************************************/
void TestLin_39_DriverDDefaultBehavior(void)
{
  uint8 LucCount;
  uint8 LucDataCount;
  
  for(LucCount = 0x00; LucCount < LIN_39_DRIVERD_ARRAY_SIZE ; LucCount++)
  {
    LinDrvD_GaaGetStatRet[LucCount] = LIN_OPERATIONAL;
    LinDrvD_GaaSendFrameChnl[LucCount] = 0xFF;
    LinDrvD_GaaGoToSleepChnl[LucCount] = 0xFF;
    LinDrvD_GaaGoToSleepIntChnl[LucCount] = 0xFF;
    LinDrvD_GaaGetStatChnl[LucCount] = 0xFF;
    LinDrvD_GaaSendFramePid[LucCount] = 0xFF;
    LinDrvD_GaaSendFrameCs[LucCount] = LIN_ENHANCED_CS;
    LinDrvD_GaaSendFrameResp[LucCount] = LIN_MASTER_RESPONSE;
    LinDrvD_GaaSendFrameDl[LucCount] = 0xFF;
    for(LucDataCount = 0x00; LucDataCount < LIN_39_DRIVERD_DATA_LENGTH ; 
      LucDataCount++)
    {
      LinDrvD_GaaSendFrameSduData[LucCount][LucDataCount] = 0x00;
      LinDrvD_GaaGetStatSduData[LucCount][LucDataCount] = LucDataCount;
    }    
  }
  LinDrvD_GucWakeupValCount = 0x00;
  LinDrvD_GucWakeupCount = 0x00;
  LinDrvD_GucSendFrameCount = 0x00;
  LinDrvD_GucGoToSleepCount = 0x00;
  LinDrvD_GucGoToSleepIntCount = 0x00;
  LinDrvD_GucGetStatCount = 0x00;
  LinDrvD_GucWakeupCheckCount = 0x00;
  LinDrvD_GucSendFrameCheckCount = 0x00;
  LinDrvD_GucGoToSleepCheckCount = 0x00;
  LinDrvD_GucGoToSleepIntCheckCount = 0x00;
  LinDrvD_GucCheckGetStatCount = 0x00;  
} /* End TestLin_39_DriverDDefaultBehavior() */

/*******************************************************************************
**                       Lin_39_DriverDWakeupValidation()                     **
*******************************************************************************/
void Lin_39_DriverD_WakeupValidation(void)
{
  #ifndef TYPICAL_CONFIG
  /* Increment count variable to handle multiple invocations */
  if(LinDrvD_GucWakeupValCount != LIN_39_DRIVERD_ARRAY_SIZE)
  {    
    LinDrvD_GucWakeupValCount++;
  } 
  #endif
} /* End Lin_39_DriverDWakeupValidation() */

/*******************************************************************************
**                       TestLin_39_DriverDWakeupValidation()                 **
*******************************************************************************/
boolean TestLin_39_DriverDWakeupValidation(App_DataValidateType LucDataValidate)
{
  boolean LblRetValue;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if(LinDrvD_GucWakeupValCount == 0x01)
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvD_GucWakeupValCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvD_GucWakeupValCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverDWakeupValidation() */

/*******************************************************************************
**                       Lin_39_DriverDWakeup()                               **
*******************************************************************************/
Std_ReturnType Lin_39_DriverD_Wakeup(uint8 Channel)
{
  #ifndef TYPICAL_CONFIG
  LinDrvD_GaaWakeupChnl[LinDrvD_GucWakeupCount] = Channel;
  /* Increment count variable to handle multiple invocations */
  if(LinDrvD_GucWakeupCount != LIN_39_DRIVERD_ARRAY_SIZE)
  {    
    LinDrvD_GucWakeupCount++;
  }
  #endif
  return(E_OK);
} /* End Lin_39_DriverDWakeup() */

/*******************************************************************************
**                       TestLin_39_DriverDWakeup()                           **
*******************************************************************************/
boolean TestLin_39_DriverDWakeup(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinDrvD_GucWakeupCount == 0x01) && 
        (ExpChannel == LinDrvD_GaaWakeupChnl[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvD_GucWakeupCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvD_GucWakeupCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinDrvD_GucWakeupCheckCount <= LinDrvD_GucWakeupCount) &&
        (ExpChannel == LinDrvD_GaaWakeupChnl[LinDrvD_GucWakeupCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinDrvD_GucWakeupCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinDrvD_GucWakeupCheckCount == LinDrvD_GucWakeupCount)
      {
        LinDrvD_GucWakeupCount = 0;
        LinDrvD_GucWakeupCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinDrvD_GucWakeupCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == LinDrvD_GaaWakeupChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverDWakeup() */

/*******************************************************************************
**                       Lin_39_DriverD_CheckWakeup()                         **
*******************************************************************************/
Std_ReturnType Lin_39_DriverD_CheckWakeup(uint8 LinNetwork )
{
  #ifndef TYPICAL_CONFIG
  LinDrvD_GaaCheckWakeupNw[LinDrvD_GucCheckWakeupCount] = LinNetwork;
  /* Increment count variable to handle multiple invocations */
  if(LinDrvD_GucCheckWakeupCount != LIN_39_DRIVERD_ARRAY_SIZE)
  {    
    LinDrvD_GucCheckWakeupCount++;
  } 
  return(LinDrvD_GaaGetCheckWakeupRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End Lin_39_DriverD_CheckWakeup() */

/*******************************************************************************
**                       TestLin_39_DriverD_CheckWakeup()                     **
*******************************************************************************/
boolean TestLin_39_DriverD_CheckWakeup(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinDrvD_GucCheckWakeupCount == 0x01) && 
        (ExpLinNetwork == LinDrvD_GaaCheckWakeupNw[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvD_GucCheckWakeupCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvD_GucCheckWakeupCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinDrvD_GucCheckWakeupCheckCount <= LinDrvD_GucCheckWakeupCount) &&
        (ExpLinNetwork == LinDrvD_GaaCheckWakeupNw[LinDrvD_GucCheckWakeupCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinDrvD_GucCheckWakeupCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinDrvD_GucCheckWakeupCheckCount == LinDrvD_GucCheckWakeupCount)
      {
        LinDrvD_GucCheckWakeupCount = 0;
        LinDrvD_GucCheckWakeupCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinDrvD_GucCheckWakeupCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinDrvD_GaaCheckWakeupNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverD_CheckWakeup() */

/*******************************************************************************
**                       Lin_39_DriverDSendFrame()                            **
*******************************************************************************/
Std_ReturnType Lin_39_DriverD_SendFrame(uint8 Channel, Lin_PduType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8 *LpSduPtr;
  LinDrvD_GaaSendFrameChnl[LinDrvD_GucSendFrameCount] = Channel;
  LinDrvD_GaaSendFramePid[LinDrvD_GucSendFrameCount] = PduInfoPtr->Pid;
  LinDrvD_GaaSendFrameCs[LinDrvD_GucSendFrameCount] = PduInfoPtr->Cs;
  LinDrvD_GaaSendFrameResp[LinDrvD_GucSendFrameCount] = PduInfoPtr->Drc;
  LinDrvD_GaaSendFrameDl[LinDrvD_GucSendFrameCount] = PduInfoPtr->Dl;
  /*Check whether Frame Length is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->Dl > LIN_39_DRIVERD_DATA_LENGTH)
  {
    LucDataLength = LIN_39_DRIVERD_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->Dl;
  }
  if(PduInfoPtr->Drc == LIN_MASTER_RESPONSE)
  {
    LpSduPtr = PduInfoPtr->SduPtr;
    /* Copy the actual data into global array from actual SduPtr */
    for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
    {
      LinDrvD_GaaSendFrameSduData[LinDrvD_GucSendFrameCount][LucDataIndex] = 
        *LpSduPtr;
      LpSduPtr++;
    }
  }
  /* Increment count variable to handle multiple invocations */
  if(LinDrvD_GucSendFrameCount != LIN_39_DRIVERD_ARRAY_SIZE)
  {    
    LinDrvD_GucSendFrameCount++;
  }  
  #endif
  return(E_OK);
} /* End Lin_39_DriverDSendFrame() */

/*******************************************************************************
**                            TestLin_39_DriverDSendFrame()                   **
*******************************************************************************/
boolean TestLin_39_DriverDSendFrame(App_DataValidateType LucDataValidate,
  uint8 ExpChannel, Lin_PduType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  PduInfoType ExpPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinDrvD_GucSendFrameCount == 0x01) && 
        (ExpChannel == LinDrvD_GaaSendFrameChnl[0]) && 
        (ExpPduInfoPtr->Pid == LinDrvD_GaaSendFramePid[0]) && 
        (ExpPduInfoPtr->Cs == LinDrvD_GaaSendFrameCs[0]) && 
        (ExpPduInfoPtr->Drc == LinDrvD_GaaSendFrameResp[0]))
      {
        if(ExpPduInfoPtr->SduPtr != NULL_PTR)
        {
        ActPduInfo.SduLength = LinDrvD_GaaSendFrameDl[0];
        ActPduInfo.SduDataPtr = &LinDrvD_GaaSendFrameSduData[0][0];
        ExpPduInfo.SduLength = ExpPduInfoPtr->Dl;
        ExpPduInfo.SduDataPtr = ExpPduInfoPtr->SduPtr;

        /* Validate Data Length and Data */
        if(LinDriverDTest_ValidateData(&ExpPduInfo, &ActPduInfo))
          {
            LblRetValue = STEP_PASSED;
          }
        }
        else
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvD_GucSendFrameCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvD_GucSendFrameCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinDrvD_GucSendFrameCheckCount <= LinDrvD_GucSendFrameCount) &&
        (ExpChannel == LinDrvD_GaaSendFrameChnl[LinDrvD_GucSendFrameCheckCount])&& 
        (ExpPduInfoPtr->Pid == LinDrvD_GaaSendFramePid[LinDrvD_GucSendFrameCheckCount]) 
        && (ExpPduInfoPtr->Cs == LinDrvD_GaaSendFrameCs[LinDrvD_GucSendFrameCheckCount]) 
        && (ExpPduInfoPtr->Drc == 
        LinDrvD_GaaSendFrameResp[LinDrvD_GucSendFrameCheckCount]))
      {
        if(ExpPduInfoPtr->SduPtr != NULL_PTR)
        {
        ActPduInfo.SduLength = LinDrvD_GaaSendFrameDl[LinDrvD_GucSendFrameCheckCount];
        ActPduInfo.SduDataPtr = 
          &LinDrvD_GaaSendFrameSduData[LinDrvD_GucSendFrameCheckCount][0];
        ExpPduInfo.SduLength = ExpPduInfoPtr->Dl;
        ExpPduInfo.SduDataPtr = ExpPduInfoPtr->SduPtr;

        /* Validate Data Length and Data */
        if(LinDriverDTest_ValidateData(&ExpPduInfo, &ActPduInfo))
          {
            LblRetValue = STEP_PASSED;
          }
        }
        else
        {
          LblRetValue = STEP_PASSED;
        }
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinDrvD_GucSendFrameCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinDrvD_GucSendFrameCheckCount == LinDrvD_GucSendFrameCount)
      {
        LinDrvD_GucSendFrameCount = 0;
        LinDrvD_GucSendFrameCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinDrvD_GucSendFrameCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == LinDrvD_GaaSendFrameChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverDSendFrame() */

/*******************************************************************************
**                       Lin_39_DriverDGoToSleep()                            **
*******************************************************************************/
Std_ReturnType Lin_39_DriverD_GoToSleep(uint8 Channel)
{
  #ifndef TYPICAL_CONFIG
  LinDrvD_GaaGoToSleepChnl[LinDrvD_GucGoToSleepCount] = Channel;
  /* Increment count variable to handle multiple invocations */
  if(LinDrvD_GucGoToSleepCount != LIN_39_DRIVERD_ARRAY_SIZE)
  {    
    LinDrvD_GucGoToSleepCount++;
  }
  #endif
  return(E_OK);
} /* End Lin_39_DriverDGoToSleep() */

/*******************************************************************************
**                       TestLin_39_DriverDGoToSleep()                        **
*******************************************************************************/
boolean TestLin_39_DriverDGoToSleep(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinDrvD_GucGoToSleepCount == 0x01) && 
        (ExpChannel == LinDrvD_GaaGoToSleepChnl[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvD_GucGoToSleepCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvD_GucGoToSleepCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinDrvD_GucGoToSleepCheckCount <= LinDrvD_GucGoToSleepCount) &&
        (ExpChannel == LinDrvD_GaaGoToSleepChnl[LinDrvD_GucGoToSleepCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinDrvD_GucGoToSleepCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinDrvD_GucGoToSleepCheckCount == LinDrvD_GucGoToSleepCount)
      {
        LinDrvD_GucGoToSleepCount = 0;
        LinDrvD_GucGoToSleepCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinDrvD_GucGoToSleepCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == LinDrvD_GaaGoToSleepChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverDGoToSleep() */

/*******************************************************************************
**                       Lin_39_DriverDGoToSleepInternal()                    **
*******************************************************************************/
Std_ReturnType Lin_39_DriverD_GoToSleepInternal(uint8 Channel)
{
  #ifndef TYPICAL_CONFIG
  LinDrvD_GaaGoToSleepIntChnl[LinDrvD_GucGoToSleepIntCount] = Channel;
  /* Increment count variable to handle multiple invocations */
  if(LinDrvD_GucGoToSleepIntCount != LIN_39_DRIVERD_ARRAY_SIZE)
  {    
    LinDrvD_GucGoToSleepIntCount++;
  }
  #endif
  return(E_OK);
} /* End Lin_39_DriverDGoToSleepInternal() */

/*******************************************************************************
**                       TestLin_39_DriverDGoToSleepInternal()                **
*******************************************************************************/
boolean TestLin_39_DriverDGoToSleepInternal(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinDrvD_GucGoToSleepIntCount == 0x01) && 
        (ExpChannel == LinDrvD_GaaGoToSleepIntChnl[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvD_GucGoToSleepIntCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvD_GucGoToSleepIntCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinDrvD_GucGoToSleepIntCheckCount <= LinDrvD_GucGoToSleepIntCount) &&
        (ExpChannel == LinDrvD_GaaGoToSleepIntChnl[LinDrvD_GucGoToSleepIntCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinDrvD_GucGoToSleepIntCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinDrvD_GucGoToSleepIntCheckCount == LinDrvD_GucGoToSleepIntCount)
      {
        LinDrvD_GucGoToSleepIntCount = 0;
        LinDrvD_GucGoToSleepIntCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinDrvD_GucGoToSleepIntCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == LinDrvD_GaaGoToSleepIntChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverDGoToSleepInternal() */

/*******************************************************************************
**                       Lin_39_DriverDGetStatus()                            **
*******************************************************************************/
Lin_StatusType Lin_39_DriverD_GetStatus(uint8 Channel, uint8 **Lin_SduPtr)
{
  #ifndef TYPICAL_CONFIG
  LinDrvD_GaaGetStatChnl[LinDrvD_GucGetStatCount] = Channel;
  /* Copy the actual data into actual SduPtr from global array  */
  *Lin_SduPtr = &LinDrvD_GaaGetStatSduData[Channel][0];
  /* Increment count variable to handle multiple invocations */
  if(LinDrvD_GucGetStatCount != LIN_39_DRIVERD_ARRAY_SIZE)
  {    
    LinDrvD_GucGetStatCount++;
  }
  return(LinDrvD_GaaGetStatRet[Channel]);
  #else
  return(LIN_TX_OK);
  #endif
  
} /* End Lin_39_DriverDGetStatus() */

/*******************************************************************************
**                       TestLin_39_DriverDGetStatus()                        **
*******************************************************************************/
boolean TestLin_39_DriverDGetStatus(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinDrvD_GucGetStatCount == 0x01) && 
        (ExpChannel == LinDrvD_GaaGetStatChnl[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvD_GucGetStatCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvD_GucGetStatCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinDrvD_GucCheckGetStatCount <= LinDrvD_GucGetStatCount) &&
        (ExpChannel == LinDrvD_GaaGetStatChnl[LinDrvD_GucCheckGetStatCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinDrvD_GucCheckGetStatCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinDrvD_GucCheckGetStatCount == LinDrvD_GucGetStatCount)
      {
        LinDrvD_GucGetStatCount = 0;
        LinDrvD_GucCheckGetStatCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinDrvD_GucGetStatCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == LinDrvD_GaaGetStatChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverDGetStatus() */

/*******************************************************************************
**                     TestSetLin_39_DriverDGetStatusRetVal()                 **
*******************************************************************************/
void TestSetLin_39_DriverDGetStatusRetVal(uint8 LucChannel, uint8 *LpSduData, 
  Lin_StatusType LddRetVal)
{
  uint8 LucCount;
  LinDrvD_GaaGetStatRet[LucChannel] = LddRetVal;
  if( LpSduData != NULL_PTR)
  {
    for(LucCount = 0 ; LucCount < LIN_39_DRIVERD_DATA_LENGTH ; LucCount++)
    {
      LinDrvD_GaaGetStatSduData[LucChannel][LucCount] = *LpSduData;
      LpSduData++;
    }
  }  
} /* End TestSetLin_39_DriverDGetStatusRetVal */

/*******************************************************************************
**                       LinDriverDTest_ValidateData()                               **
*******************************************************************************/
boolean LinDriverDTest_ValidateData(PduInfoType *LddExpPduInfo, 
  PduInfoType *LddActPduInfo)
{
  uint8 *LpActualDataPtr;
  uint8 *LpExpDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  /* Load the ExpPduInfo to local variables */
  LddSduCount = LddExpPduInfo->SduLength;
  LpExpDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  /* Check the Data length */
  if((LddExpPduInfo->SduLength <= LIN_39_DRIVERD_DATA_LENGTH) &&
    (LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }
   /* Check the sdu data */
  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    if(*LpActualDataPtr != *LpExpDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualDataPtr++;
    LpExpDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* End LinDriverDTest_ValidateData() */
#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
