/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE:  Lin.h                                                        **
**                                                                            **
**  TARGET    :  ALL                                                          **
**                                                                            **
**  PRODUCT   : AUTOSAR LIN Module                                            **
**                                                                            **
**  PURPOSE   : Provision of AUTOSAR LIN Types and extern datatypes           **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     03-Jan-2012   NKD    Creation of Lin.c module                    **
*******************************************************************************/

#ifndef LIN_39_DRIVERD_H
#define LIN_39_DRIVERD_H

/*******************************************************************************
**                      Include Section                                      **
*******************************************************************************/
#include "TC_Generic.h"
#include "Lin_GeneralTypes.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define LIN_39_DRIVERD_AR_RELEASE_MAJOR_VERSION         0x04
#define LIN_39_DRIVERD_AR_RELEASE_MINOR_VERSION         0x00
#define LIN_39_DRIVERD_AR_RELEASE_REVISION_VERSION      0x02

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define LIN_39_DRIVERD_DATA_LENGTH                      0x08
/* Channel value should be less than LIN_ARRAY_SIZE */
#define LIN_39_DRIVERD_ARRAY_SIZE                       0x04 

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern void Lin_39_DriverD_WakeupValidation(void);
extern Std_ReturnType Lin_39_DriverD_Wakeup(uint8 Channel);
extern Std_ReturnType Lin_39_DriverD_SendFrame(uint8 Channel, Lin_PduType* PduInfoPtr);
extern Std_ReturnType Lin_39_DriverD_GoToSleep(uint8 Channel);
extern Std_ReturnType Lin_39_DriverD_GoToSleepInternal(uint8 Channel);
extern Lin_StatusType Lin_39_DriverD_GetStatus(uint8 Channel, uint8 **Lin_SduPtr);

extern  Std_ReturnType Lin_39_DriverD_CheckWakeup( uint8 LinNetwork );

extern  Std_ReturnType TestLin_39_DriverD_CheckWakeup(
  App_DataValidateType LucDataValidate, uint8 LinNetwork );

extern void TestLin_39_DriverDDefaultBehavior(void);
extern boolean TestLin_39_DriverDWakeupValidation(App_DataValidateType LucDataValidate);
extern boolean TestLin_39_DriverDWakeup(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel);
extern boolean TestLin_39_DriverDSendFrame(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel, Lin_PduType *ExpPduInfoPtr);
extern boolean TestLin_39_DriverDGoToSleep(App_DataValidateType LucDataValidate,   
  uint8 ExpChannel);
extern boolean TestLin_39_DriverDGoToSleepInternal(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel);
extern boolean TestLin_39_DriverDGetStatus(App_DataValidateType LucDataValidate,   
  uint8 ExpChannel);
extern void TestSetLin_39_DriverDGetStatusRetVal(uint8 LucChannel, uint8 *LpSduData, 
  Lin_StatusType LddRetVal);
extern boolean LinDriverDTest_ValidateData(PduInfoType *LddExpPduInfo, 
  PduInfoType *LddActPduInfo);


#endif  /* LIN_39_DRIVERD_H */

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
