/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: NvM.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Ea Module                                             **
**                                                                            **
**  PURPOSE   : Provision of header for NvM.c                                 **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0    30-Aug-2012   Ravi Tiwari    Initial version                      **
*******************************************************************************/

#ifndef NVM_CBK_H
#define NVM_CBK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/* For MemIf job end notification without error */
extern void NvM_JobEndNotification(void);
extern boolean TestNvM_JobEndNotification(App_DataValidateType DataValidate);
/* For MemIf job end notification with error */
extern void NvM_JobErrorNotification(void);
extern boolean TestNvM_JobErrorNotification(App_DataValidateType DataValidate);
extern void TestNvM_SetNvMData(void);

/* Added to remove compilation warning(empty source file) in NvM_Cbk.c */
extern void NvM_Test_API(void);
#endif /* NVM_CBK_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

