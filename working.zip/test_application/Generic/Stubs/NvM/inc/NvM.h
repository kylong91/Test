/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: NvM.h                                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR NvM Module                                             **
**                                                                            **
**  PURPOSE   : Provision of header for NvM.c                                 **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0    30-Aug-2012   Ravi Tiwari    Initial version                      **
*******************************************************************************/
#ifndef NVM_H
#define NVM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
#include "NvM_Types.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define NVM_AR_RELEASE_MAJOR_VERSION  4
#define NVM_AR_RELEASE_MINOR_VERSION  0
#define NVM_AR_RELEASE_REVISION_VERSION  3

/* Software Version Information */
#define NVM_SW_MAJOR_VERSION  1
#define NVM_SW_MINOR_VERSION  0
/******************************************************************************
*                       Macros
******************************************************************************/
#define NVM_RESULT_TYPE_SIZE  (uint8)0x03
#define NVM_BLOCKID_RANGE     (uint8)0x06
#define NVM_REQ_OK            (uint8)0x00
#define NVM_REQ_NOT_OK        (uint8)0x01
#define NVM_REQ_PENDING       (uint8)0x02
#define NVM_REQ_INTEGRITY_FAILED       (uint8)0x03
#define NVM_REQ_BLOCK_SKIPPED       (uint8)0x04
#define NVM_REQ_NV_INVALIDATED       (uint8)0x05
#define NVM_REQ_CANCELED       (uint8)0x06
#define NVM_MAXVALUE          (uint8)0XFF
#define NVM_REQ_REDUNDANCY_FAILED          (uint8)0X07
#define NVM_REQ_RESTORED_FROM_ROM          (uint8)0X08
#define  NvMConf_NvMBlockDescriptor_NvMBlockDescriptor5  (NvM_BlockIdType)2
#define  NvMConf_NvMBlockDescriptor_NvMBlockDescriptor3  (NvM_BlockIdType)3
#define  NvMConf_NvMBlockDescriptor_NvMBlockDescriptor0  (NvM_BlockIdType)4
#define  NvMConf_NvMBlockDescriptor_NvMBlockDescriptor2  (NvM_BlockIdType)5
#define  NvMConf_NvMBlockDescriptor_NvMBlockDescriptor1  (NvM_BlockIdType)6
#define  NvMConf_NvMBlockDescriptor_NvMBlockDescriptor4  (NvM_BlockIdType)7

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
extern NvM_BlockIdType NvM_GddGeneralBlockId;
extern NvM_BlockIdType NvM_GddChnBlockId[];
extern NvM_RequestResultType NvM_GaaRequestResultPtr[NVM_RESULT_TYPE_SIZE];
extern Std_ReturnType NvM_GddReturnVal;
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void NvM_GetErrorStatus_Return_Nk(void);
extern Std_ReturnType NvM_GetErrorStatus( NvM_BlockIdType BlockId, 
  NvM_RequestResultType *RequestResultPtr);

extern boolean TestNvM_GetErrorStatus(App_DataValidateType LucDataValidate,
 NvM_BlockIdType ExpBlockId);
 
extern void TestNvM_DefaultBehavior(void);
extern void TestNvM_SetBehavior(Std_ReturnType LddReturnVal);

extern void TestSetNvM_ReadBlock(Std_ReturnType LddReadReturn);

extern void SetNvM_ReadBlockReturn(Std_ReturnType LddReadReturn);

extern void SetNvM_ReadBlock(uint8 *LpData, uint8 LucLength);
  
extern Std_ReturnType NvM_ReadBlock(NvM_BlockIdType LddBlockId,
  void* LpNvM_DstPtr);

extern boolean TestNvM_ReadBlock(App_DataValidateType LddDataValidate,
  NvM_BlockIdType LddExpBlockId, void* NvM_DstPtr);

extern void TestSetNvM_WriteBlock(Std_ReturnType LddReturnType);
  
extern void SimulateNvM_WriteBlock(Std_ReturnType LddReturnType);

extern Std_ReturnType NvM_WriteBlock(NvM_BlockIdType LddBlockId,
  const void *LpNvM_SrcPtr);

extern boolean TestNvM_WriteBlock(App_DataValidateType LddDataValidate,
  NvM_BlockIdType LddExpBlockId, void *LpExpNvM_SrcPtr);
  
extern void NvM_SetBlockLockStatus(NvM_BlockIdType LddBlockId,
  boolean LblBlockLocked);

extern boolean TestNvM_SetBlockLockStatus(App_DataValidateType LddDataValidate,
  NvM_BlockIdType LddExpBlockId, boolean LblExpBlockLocked);
  
extern boolean App_DcmNvmDataValidation(uint8* LpExpData, uint8* LpActData,
  uint16 LusDataLength);
  
extern Std_ReturnType
 NvM_SetDataIndex( NvM_BlockIdType BlockId, uint8 DataIndex );

extern Std_ReturnType NvM_SetRamBlockStatus( NvM_BlockIdType BlockId,
 boolean BlockChanged);
 
extern void NvM_Init(void);

extern boolean TestNvM_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
  
extern void NvM_ReadAll(void);

extern boolean TestNvM_ReadAll(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
  
extern void NvM_WriteAll(void);

extern boolean TestNvM_WriteAll(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);

#endif /* NVM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
