/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Eep.c                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Ea Module                                             **
**                                                                            **
**  PURPOSE   : Provision of NvM_Cbk.c for testing applications               **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0    30-Aug-2012   Ravi Tiwari    Initial version                      **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#ifdef EA_MODULE_ACTIVE
#include "NvM_Cbk.h"
#include "Ea_Ram.h"
#endif

/*******************************************************************************
**                         Global Data                                        **
*******************************************************************************/
#ifdef EA_MODULE_ACTIVE
uint8 NvM_GucJobEndCount = 0;
uint8 NvM_GucJobErrCount = 0;
#endif

/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

#ifdef EA_MODULE_ACTIVE
/******************************************************************************/
/*                   NvM_JobEndNotification                                   */
/******************************************************************************/
/* NvM job end notification */
void NvM_JobEndNotification(void)
{
  #ifndef TYPICAL_CONFIG
  NvM_GucJobEndCount++;
  #endif
}
#endif

#ifdef EA_MODULE_ACTIVE
/*******************************************************************************
**                       TestNvM_JobEndNotification ()                        **
*******************************************************************************/
boolean TestNvM_JobEndNotification(App_DataValidateType DataValidate)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(DataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((NvM_GucJobEndCount == 0x01))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      NvM_GucJobEndCount = 0;
      break;
    }
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(NvM_GucJobEndCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
     } 
      
    default:
    {
      break;
    }
  } /* End switch(DataValidate) */
  return(LblStepResult);
} /* End TestNvM_JobEndNotification() */
#endif

#ifdef EA_MODULE_ACTIVE
/******************************************************************************/
/*                   NvM_JobErrorNotification                                 */
/******************************************************************************/
/* NvM job error notification */
void NvM_JobErrorNotification(void)
{
  #ifndef TYPICAL_CONFIG
  NvM_GucJobErrCount++;
  #endif
}
#endif

#ifdef EA_MODULE_ACTIVE
/*******************************************************************************
**                       TestNvM_JobErrorNotification ()                      **
*******************************************************************************/
boolean TestNvM_JobErrorNotification(App_DataValidateType DataValidate)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(DataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((NvM_GucJobErrCount == 0x01))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      NvM_GucJobErrCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(DataValidate) */
  return(LblStepResult);
} /* End TestNvM_JobErrorNotification() */
#endif

#ifdef EA_MODULE_ACTIVE
/******************************************************************************/
/*                   TestNvM_SetNvMData                                       */
/******************************************************************************/
/* NvM job error notification */
void TestNvM_SetNvMData(void)
{
  uint8 LucCount;
  for(LucCount = 0; LucCount < EA_TOTAL_NUM_BLOCKS_CONFIG; LucCount ++)
  {
    Ea_GaaNvData[LucCount].ulCurrentWriteCycles = 0x00000000;
  }
}
#endif
/******************************************************************************/
/*                   NvM_Test_API                                             */
/******************************************************************************/
/* Added to remove compilation warning(empty source file) in NvM_Cbk.c */
void NvM_Test_API(void)
{
  
}
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
