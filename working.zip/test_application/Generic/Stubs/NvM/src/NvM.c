/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: NvM.c                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR COMManager module                                     **
**                                                                            **
**  PURPOSE   : Declaration of Can functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0    30-Aug-2012   Ravi Tiwari    Initial version                      **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "NvM.h"
#ifdef COMM_MODULE_ACTIVE
#include "ComM.h"
#include "ComM_Ram.h"
#endif
#ifdef EA_MODULE_ACTIVE
#include "Ea_Ram.h"
#endif
#ifdef DLT_MODULE_ACTIVE
#include "Rte_Dlt_Type.h"
#include "Dlt_Cfg.h"
#include "Dlt_PCTypes.h"
#include "Dlt_Types.h"
#endif
#ifdef DEM_MODULE_ACTIVE
#include "Rte_Dem_Type.h"
#include "Dem_PCTypes.h"
#include "Dem_Cfg.h"
#include "Dem.h"
#include "Dem_Types.h"
#endif
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
#ifdef DLT_MODULE_ACTIVE
NvM_BlockIdType Dlt_GddBlockId;
Dlt_NvMData Dlt_GstDltNvMData;
Std_ReturnType NvM_GddReadReturnVal;
uint8 NvM_GucWriteBlockCount;
#endif
NvM_BlockIdType NvM_GddGeneralBlockId;
NvM_BlockIdType NvM_GddChnBlockId[NVM_BLOCKID_RANGE];
NvM_RequestResultType NvM_GaaRequestResultPtr[NVM_RESULT_TYPE_SIZE] =
 {0x00, 0x01, 0x02};
Std_ReturnType NvM_GddReturnVal;
#ifdef DCM_MODULE_ACTIVE
NvM_BlockIdType Dcm_GddGeneralBlockId;
Std_ReturnType Dcm_GddNvMGeneralReturn;
uint8 Dcm_GaaData[3];
uint8 Dcm_GeneralIndexCount;
boolean Dcm_GblBlockLocked;
#endif

#ifdef DEM_MODULE_ACTIVE
NvM_BlockIdType Dem_GddBlockId;
Dem_EventMemory Dem_GstDemNvMData;
uint8 Dem_GucDataIndex;
boolean Dem_GblBlockChangedStatus;
Std_ReturnType NvM_GddReadReturnVal;
boolean GblDem_ClearFinish;
#endif

#ifdef COMM_MODULE_ACTIVE
uint8 NvMGetErrorStatusCnt;
#endif
#ifdef BSWM_MODULE_ACTIVE
uint8 NvM_GucInitSeqCnt;
uint8 NvM_GucReadAllSeqCnt;
uint8 NvM_GucWriteAllSeqCnt;
uint8 NvM_GucInitCnt;
uint16 NvM_GusReadAllCnt;
uint16 NvM_GusWriteAllCnt;
#endif

#ifdef DEM_MODULE_ACTIVE
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
void NvM_GetErrorStatus_Return_Nk(void)
{		
	GblDem_ClearFinish = TRUE;
}
#endif
/*******************************************************************************
**                       NvM_GetErrorStatus()                                 **
*******************************************************************************/
Std_ReturnType NvM_GetErrorStatus(NvM_BlockIdType BlockId, 
NvM_RequestResultType *RequestResultPtr)
{
  #ifndef TYPICAL_CONFIG
  #if defined(DEM_MODULE_ACTIVE) || defined(COMM_MODULE_ACTIVE) || defined(DLT_MODULE_ACTIVE)
  
  #ifdef DEM_MODULE_ACTIVE
  switch(BlockId)
  {
   case DEM_PRI_BLOCK_ID:
          NvM_GddGeneralBlockId = BlockId;
          *RequestResultPtr =  0x01;
          break;
   case DEM_EVENT_STATUS_BLOCK_ID:
          NvM_GddGeneralBlockId = BlockId;
          *(RequestResultPtr) =  0x01;
          break;
    default:
           NvM_GddGeneralBlockId = BlockId;
          *(RequestResultPtr) =  0x01;
          break;
  }
  if(GblDem_ClearFinish == TRUE)
  {
  	GblDem_ClearFinish = DEM_FALSE;
	*RequestResultPtr =  0x00;
  }
  #endif
  
  #ifdef COMM_MODULE_ACTIVE
  NvM_GddGeneralBlockId = BlockId;
  NvMGetErrorStatusCnt++;
  switch(BlockId)
  {
   case 2:
          *RequestResultPtr = 0x00;
          break;
   case 3:
          *RequestResultPtr = 0x01;
          break;
   case 4:
          *RequestResultPtr = 0x02;
          break;
   default:
          break;
  }
  #endif
  
  #ifdef DLT_MODULE_ACTIVE
  Dlt_GddBlockId = BlockId;
  *RequestResultPtr = 0x00;
  #endif
  #else
  UNUSED(BlockId);
  UNUSED(RequestResultPtr);
  #endif
  #endif
  return(NvM_GddReturnVal);
}/* End NvM_GetErrorStatus() */
/*******************************************************************************
**                        TestNvM_GetErrorStatus()                            **
*******************************************************************************/
boolean TestNvM_GetErrorStatus(App_DataValidateType LucDataValidate,
NvM_BlockIdType ExpBlockId)
{
  boolean LblStepResult;
  #if defined(DEM_MODULE_ACTIVE) || defined(COMM_MODULE_ACTIVE) || defined(DLT_MODULE_ACTIVE)
  LblStepResult = STEP_FAILED;  
   
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      #ifdef DEM_MODULE_ACTIVE
      switch(ExpBlockId)
      {
       case 2:
              if(NvM_GddGeneralBlockId == ExpBlockId) 
              {
                LblStepResult = APP_TC_PASSED;
              }
              break;
       case 8:
              if(NvM_GddChnBlockId[0] == ExpBlockId)
              {
                LblStepResult = APP_TC_PASSED;
              }
              break;
       case 3:
              if(NvM_GddChnBlockId[1] == ExpBlockId)
              {
                LblStepResult = APP_TC_PASSED;
              }
              break;
       case 4:
              if(NvM_GddChnBlockId[2] == ExpBlockId)
              {
                LblStepResult = APP_TC_PASSED;
              }
              break;
       case 5:
              if(NvM_GddChnBlockId[3] == ExpBlockId)
              {
                LblStepResult = APP_TC_PASSED;
              }
              break;
       case 6:
              if(NvM_GddChnBlockId[4] == ExpBlockId)
              {
                LblStepResult = APP_TC_PASSED;
              }
              break;
       case 7:
              if(NvM_GddChnBlockId[5] == ExpBlockId)
              {
                LblStepResult = APP_TC_PASSED;
              }
              break;
       default:
              break;
      }
      #endif
      #ifdef COMM_MODULE_ACTIVE
      if((NvM_GddGeneralBlockId == ExpBlockId) &&
      (NvMGetErrorStatusCnt == 0x01))
      {
        LblStepResult = APP_TC_PASSED;
      }
      NvMGetErrorStatusCnt = 0;
	    #endif
      #ifdef DLT_MODULE_ACTIVE
      /* Validate invocation count, EventId and EventStatus */
      if(Dlt_GddBlockId == ExpBlockId)
      {
        LblStepResult = STEP_PASSED;
      }
      #endif
      break;
    }
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
	  #ifdef COMM_MODULE_ACTIVE
      if(NvMGetErrorStatusCnt == 0)
      {
        LblStepResult = STEP_PASSED;
      }
	  #endif
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  
  #else
  UNUSED(ExpBlockId);
  UNUSED(LucDataValidate);
  #endif
  return(LblStepResult);
} /* End TestNvM_GetErrorStatus() */

#ifdef DEM_MODULE_ACTIVE
/*******************************************************************************
**                         NvM_ReadBlock()                         **
*******************************************************************************/
Std_ReturnType NvM_ReadBlock(NvM_BlockIdType BlockId, void* NvM_DstPtr)
{
  #ifndef TYPICAL_CONFIG
  Dem_EventMemory* LpDemData;
  LpDemData = (Dem_EventMemory*)NvM_DstPtr;
  Dem_GddBlockId = BlockId;
  
  LpDemData->ddEventId = 0;
  LpDemData->ucOccCounter = 0;
  LpDemData->ucNumOfFF = 0;
 LpDemData->ddEventStatus = 0x50;
  LpDemData->aaFfData[0][0] = 0x00;
  LpDemData->aaFfData[0][1] = 0x00;
  
  LpDemData->aaEdData[0][0] = 0x00;
  LpDemData->aaEdData[0][1] = 0x00;
  #endif
  return(NvM_GddReadReturnVal);
} /* End TestNvM_ReadBlock() */
/*******************************************************************************
**                       TestNvM_ReadBlock()                                  **
*******************************************************************************/
boolean TestNvM_ReadBlock(App_DataValidateType LucDataValidate,
  NvM_BlockIdType LddBlockId,void* NvM_DstPtr)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;
	UNUSED(NvM_DstPtr);
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if(Dem_GddBlockId == LddBlockId)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestDem_GetEventExtendedDataRecord() */


Std_ReturnType NvM_SetDataIndex( NvM_BlockIdType BlockId, uint8 DataIndex)
{
Dem_GddBlockId  = BlockId;
Dem_GucDataIndex = DataIndex;
return(E_OK);
}

Std_ReturnType NvM_SetRamBlockStatus( NvM_BlockIdType BlockId,
 boolean BlockChanged)
{
Dem_GddBlockId = BlockId;
Dem_GblBlockChangedStatus = BlockChanged;
return(E_OK);
}

/*******************************************************************************
**                      NvM_WriteBlock()                                      **
*******************************************************************************/
Std_ReturnType NvM_WriteBlock(NvM_BlockIdType BlockId, const void* NvM_SrcPtr)
{
  #ifndef TYPICAL_CONFIG
  Dem_EventMemory* LpDemData;
  Dem_GddBlockId = BlockId;
  LpDemData = (Dem_EventMemory*)NvM_SrcPtr;
  
  Dem_GstDemNvMData.ddEventId = LpDemData->ddEventId;
  Dem_GstDemNvMData.ucOccCounter = LpDemData->ucOccCounter;
  Dem_GstDemNvMData.ucNumOfFF = LpDemData->ucNumOfFF;
  Dem_GstDemNvMData.ddEventStatus = LpDemData->ddEventStatus;
  Dem_GstDemNvMData.aaFfData[0][0] = LpDemData->aaFfData[0][0];
  Dem_GstDemNvMData.aaFfData[0][1] = LpDemData->aaFfData[0][1];
  Dem_GstDemNvMData.aaEdData[0][0] = LpDemData->aaEdData[0][0];
  Dem_GstDemNvMData.aaEdData[0][1] = LpDemData->aaEdData[0][1];
  #endif
  return(NvM_GddReadReturnVal);
} /* End NvM_ReadBlock() */
/*******************************************************************************
**                       TestNvM_WriteBlock()                                **
*******************************************************************************/
boolean TestNvM_WriteBlock(App_DataValidateType LucDataValidate,
  NvM_BlockIdType LddBlockId, void* NvM_SrcPtr)
{
  boolean LblStepResult;
	UNUSED(NvM_SrcPtr);
  
  LblStepResult = STEP_FAILED;
  LddBlockId = DEM_ZERO;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      
         LblStepResult = STEP_PASSED;

      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      Dem_GddBlockId = LddBlockId;
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestNvM_WriteBlock() */
#endif
/*******************************************************************************
**                         TestNvM_DefaultBehavior()                         **
*******************************************************************************/
void TestNvM_DefaultBehavior(void)
{
  #ifdef COMM_MODULE_ACTIVE
  #if((COMM_WAKEUP_INHIBITION_ENABLED == STD_ON) || \
      (COMM_MODE_LIMITATION_ENABLED == STD_ON))
  #if(COMM_NVM_BLOCK_DESCRIPTOR == STD_ON)
  uint8 LucIndex;
  #endif
  #endif
  NvM_GddReturnVal = 0;
  NvMGetErrorStatusCnt = 0;
  #if(COMM_NVM_BLOCK_DESCRIPTOR == STD_ON)
  ComM_GstData.ddComMEcuInhibition = 0;
  #endif
  #if((COMM_WAKEUP_INHIBITION_ENABLED == STD_ON) || \
      (COMM_MODE_LIMITATION_ENABLED == STD_ON))
  #if(COMM_NVM_BLOCK_DESCRIPTOR == STD_ON)
  for(LucIndex = 0; LucIndex < COMM_TOTAL_CHANNELS; LucIndex++)
  {
    if(ComM_GaaChannels[LucIndex].blNoWakeUpNvmStorage == COMM_TRUE)
    {
      /* Store required inhibhition : If TRUE*/
      ComM_GstData.aaComMChannelInhibitStatus[LucIndex] = 0;
    }
  }
  #endif
  #endif
  #if(COMM_MODE_LIMITATION_ENABLED == STD_ON)
  #if(COMM_NVM_BLOCK_DESCRIPTOR == STD_ON)
  ComM_GstData.usComMFullComInhibitCounter = 0;
  #endif
  #endif
  #endif /*#ifdef COMM_MODULE_ACTIVE*/
  #ifdef DLT_MODULE_ACTIVE
  Dlt_GddBlockId = 0;
  NvM_GddReadReturnVal = 0;
  #endif
}

/*******************************************************************************
**                         TestNvM_SetBehavior()                              **
*******************************************************************************/
void TestNvM_SetBehavior(Std_ReturnType LddReturnVal)
{
  NvM_GddReturnVal = LddReturnVal;
}

#ifdef DLT_MODULE_ACTIVE
/*******************************************************************************
**                      NvM_ReadBlock()                                       **
*******************************************************************************/
Std_ReturnType NvM_ReadBlock(NvM_BlockIdType BlockId, void* NvM_DstPtr)
{
  #ifndef TYPICAL_CONFIG
  Dlt_NvMData* LpDltData;
  LpDltData = (Dlt_NvMData*)NvM_DstPtr;
  Dlt_GddBlockId = BlockId;
  
  LpDltData->ddDefaultMaxLogLevel = DLT_LOG_INFO;
  LpDltData->ddVfbTraceLogLevel = DLT_LOG_ERROR;
  LpDltData->ulComBandwidth = 10;
  LpDltData->ulDiagChannelBandwidth = 10;
  LpDltData->blDefaultTraceStatus = 1;
  LpDltData->blUseExtendedHeader = 1;
  LpDltData->blUseEcuId = 1;
  LpDltData->blUseSessionId = 1;
  LpDltData->blUseTimeStamp = 1;
  LpDltData->blUseVerboseMode = 1;
  LpDltData->blFilterMessages = 1;

  #endif
  return(NvM_GddReadReturnVal);
} /* End TestNvM_ReadBlock() */
/*******************************************************************************
**                       TestNvM_ReadBlock()                                  **
*******************************************************************************/
boolean TestNvM_ReadBlock(App_DataValidateType LucDataValidate,
  NvM_BlockIdType LddBlockId, void* NvM_DstPtr)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;
  UNUSED(NvM_DstPtr);
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if(Dlt_GddBlockId == LddBlockId)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestDem_GetEventExtendedDataRecord() */

/*******************************************************************************
**                      NvM_WriteBlock()                                      **
*******************************************************************************/
Std_ReturnType NvM_WriteBlock(NvM_BlockIdType BlockId, const void* NvM_SrcPtr)
{
  #ifndef TYPICAL_CONFIG
  NvM_GucWriteBlockCount++;
  Dlt_NvMData* LpDltData;
  Dlt_GddBlockId = BlockId;
  LpDltData = (Dlt_NvMData*)NvM_SrcPtr;
  
  Dlt_GstDltNvMData.ddDefaultMaxLogLevel = LpDltData->ddDefaultMaxLogLevel;
  Dlt_GstDltNvMData.ddVfbTraceLogLevel = LpDltData->ddVfbTraceLogLevel;
  Dlt_GstDltNvMData.ulComBandwidth = LpDltData->ulComBandwidth;
  Dlt_GstDltNvMData.ulDiagChannelBandwidth = LpDltData->ulDiagChannelBandwidth;
  Dlt_GstDltNvMData.blDefaultTraceStatus = LpDltData->blDefaultTraceStatus;
  Dlt_GstDltNvMData.blUseExtendedHeader = LpDltData->blUseExtendedHeader;
  Dlt_GstDltNvMData.blUseEcuId = LpDltData->blUseEcuId;
  Dlt_GstDltNvMData.blUseSessionId = LpDltData->blUseSessionId;
  Dlt_GstDltNvMData.blUseTimeStamp = LpDltData->blUseTimeStamp;
  Dlt_GstDltNvMData.blUseVerboseMode = LpDltData->blUseVerboseMode;
  Dlt_GstDltNvMData.blFilterMessages = LpDltData->blFilterMessages;
  #endif
  return(NvM_GddReadReturnVal);
} /* End NvM_ReadBlock() */
/*******************************************************************************
**                       TestNvM_WriteBlock()                                **
*******************************************************************************/
boolean TestNvM_WriteBlock(App_DataValidateType LucDataValidate,
  NvM_BlockIdType LddBlockId, void* NvM_SrcPtr)
{
  boolean LblStepResult;
  Dlt_NvMData* LpDltData;
  LpDltData = (Dlt_NvMData*)NvM_SrcPtr;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, EventId and EventStatus */
      if(Dlt_GddBlockId == LddBlockId)
      {
        if(
          (Dlt_GstDltNvMData.ddDefaultMaxLogLevel == LpDltData->ddDefaultMaxLogLevel) &&
          (Dlt_GstDltNvMData.ddVfbTraceLogLevel == LpDltData->ddVfbTraceLogLevel) &&
          (Dlt_GstDltNvMData.ulComBandwidth == LpDltData->ulComBandwidth) &&
          (Dlt_GstDltNvMData.ulDiagChannelBandwidth == LpDltData->ulDiagChannelBandwidth) &&
          (Dlt_GstDltNvMData.blDefaultTraceStatus == LpDltData->blDefaultTraceStatus) &&
          (Dlt_GstDltNvMData.blUseExtendedHeader == LpDltData->blUseExtendedHeader) &&
          (Dlt_GstDltNvMData.blUseEcuId == LpDltData->blUseEcuId) &&
          (Dlt_GstDltNvMData.blUseSessionId == LpDltData->blUseSessionId) &&
          (Dlt_GstDltNvMData.blUseTimeStamp == LpDltData->blUseTimeStamp) &&
          (Dlt_GstDltNvMData.blUseVerboseMode == LpDltData->blUseVerboseMode) &&
          (Dlt_GstDltNvMData.blFilterMessages == LpDltData->blFilterMessages)
          )
        {
          LblStepResult = STEP_PASSED;
        }
      }
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(NvM_GucWriteBlockCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestNvM_WriteBlock() */

/*******************************************************************************
**                         TestSetNvM_ReadBlock()                             **
*******************************************************************************/
void TestSetNvM_ReadBlock(Std_ReturnType LddReturnVal)
{
  NvM_GddReadReturnVal = LddReturnVal;
}
/*******************************************************************************
**                         TestSetNvM_ReadBlock()                             **
*******************************************************************************/
void TestSetNvM_WriteBlock(Std_ReturnType LddReturnVal)
{
  NvM_GddReadReturnVal = LddReturnVal;
}
#endif

#ifdef DCM_MODULE_ACTIVE

/*******************************************************************************
**                        App_DcmNvmDataValidation()                     **
*******************************************************************************/
boolean App_DcmNvmDataValidation(uint8* LpExpData, uint8* LpActData,
  uint16 LusDataLength)
{
  boolean LblReturnValue;
  
  LblReturnValue = TRUE;
  
  while(LusDataLength > 0)
  {
    if(*LpExpData != *LpActData)
    {
      LblReturnValue = FALSE;
    }
    LpActData++;
    LpActData++;
    LusDataLength--;
  }
  return(LblReturnValue);
} /* End App_DcmNvmDataValidation */

/*******************************************************************************
**                         SetNvM_ReadBlockReturn()                           **
*******************************************************************************/
void SetNvM_ReadBlockReturn(Std_ReturnType LddReadReturn)
{
  Dcm_GddNvMGeneralReturn = LddReadReturn;
}

/*******************************************************************************
**                         SetNvM_ReadBlock()                                 **
*******************************************************************************/
void SetNvM_ReadBlock(uint8 *LpData, uint8 LucLength)
{
  uint8 LucIndex;
  LucIndex = 0;
  do
  {
    Dcm_GaaData[LucIndex] = (*LpData)++;
    LucIndex++;
  }
  while(LucIndex < LucLength);
}

/*******************************************************************************
**                              NvM_ReadBlock()                               **
*******************************************************************************/
Std_ReturnType NvM_ReadBlock(NvM_BlockIdType LddBlockId, void* LpNvM_DstPtr)
{
  LpNvM_DstPtr = &Dcm_GaaData[0];
  Dcm_GddGeneralBlockId = LddBlockId;
  Dcm_GeneralIndexCount++;
  
  if(LpNvM_DstPtr == NULL_PTR)
  {
    /* To avoid Compiler warning */
  }
   return(Dcm_GddNvMGeneralReturn);
}

/*******************************************************************************
**                            TestNvM_ReadBlock                               **
*******************************************************************************/
boolean TestNvM_ReadBlock(App_DataValidateType LddDataValidate, NvM_BlockIdType
  LddExpBlockId)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GeneralIndexCount == 0x01) && (Dcm_GddGeneralBlockId = 
        LddExpBlockId))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GeneralIndexCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GeneralIndexCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    
    case M_VALIDATE :
      break;
    
    case M_NOT_INVOKED :
      break;
    
    case S_VALIDATE_SEQ :
      break;
      
    case M_VALIDATE_SEQ :
      break;
    
  }
  return(LblRetValue);
}
  
/*******************************************************************************
**                           SimulateNvM_WriteBlock                           **
*******************************************************************************/  
void SimulateNvM_WriteBlock(Std_ReturnType LddReturnType)
{
  Dcm_GddNvMGeneralReturn = LddReturnType;
}  
  
/*******************************************************************************
**                           NvM_SetBlockLockStatus                           **
*******************************************************************************/
void NvM_SetBlockLockStatus(NvM_BlockIdType LddBlockId, boolean LblBlockLocked)
{
  Dcm_GddGeneralBlockId = LddBlockId;
  Dcm_GblBlockLocked = LblBlockLocked;
  Dcm_GeneralIndexCount++;
}  

/*******************************************************************************
**                           NvM_WriteBlock                                   **
*******************************************************************************/
Std_ReturnType NvM_WriteBlock(NvM_BlockIdType LddBlockId, void* LpNvM_SrcPtr)
{
  uint8 LucIndex;
  uint8* LpNvM_SrcPtr1;
  LpNvM_SrcPtr1 = (uint8*) LpNvM_SrcPtr;
  LucIndex = 0;
  do
  {
    Dcm_GaaData[LucIndex] = *LpNvM_SrcPtr1;
    LucIndex++;
    LpNvM_SrcPtr1++;
  }
  while(LucIndex < NVM_MAXVALUE);
  
  Dcm_GddGeneralBlockId = LddBlockId;
  Dcm_GeneralIndexCount++;
  return(Dcm_GddNvMGeneralReturn);
}  

/*******************************************************************************
**          TestNvM_SetBlockLockStatus                                        **
*******************************************************************************/
boolean TestNvM_SetBlockLockStatus(App_DataValidateType LddDataValidate,
  NvM_BlockIdType LddExpBlockId, boolean LblExpBlockLocked)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GeneralIndexCount == 0x01) && (Dcm_GddGeneralBlockId =
        LddExpBlockId) && (Dcm_GblBlockLocked == LblExpBlockLocked))
      {
         LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GeneralIndexCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GeneralIndexCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    
    case M_VALIDATE :
      break;
    
    case M_NOT_INVOKED :
      break;
    
    case S_VALIDATE_SEQ :
      break;
      
    case M_VALIDATE_SEQ :
      break;
    
  }  
  return(LblRetValue);
}

/*******************************************************************************
**          TestNvM_WriteBlock                                                **
*******************************************************************************/
boolean TestNvM_WriteBlock(App_DataValidateType LddDataValidate,
  NvM_BlockIdType LddExpBlockId, void *LpExpNvM_SrcPtr)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Opstatus */
      if((Dcm_GeneralIndexCount == 0x01) && (Dcm_GddGeneralBlockId =
        LddExpBlockId))
      {
        if(App_DcmNvmDataValidation(LpExpNvM_SrcPtr, &Dcm_GaaData[0], 
          LusLength))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GeneralIndexCount = 0;
       break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GeneralIndexCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    } /* End case S_NOT_INVOKED: */
    
    case M_VALIDATE :
      break;
    
    case M_NOT_INVOKED :
      break;
    
    case S_VALIDATE_SEQ :
      break;
      
    case M_VALIDATE_SEQ :
      break;
  }  
  return(LblRetValue);
}

#endif

#ifdef BSWM_MODULE_ACTIVE

/*******************************************************************************
**                          NvM_Init()                                        **
*******************************************************************************/

void NvM_Init(void)
{
	App_GucApiSeqCnt++;
	NvM_GucInitSeqCnt = App_GucApiSeqCnt;
	NvM_GucInitCnt++;
}/* End NvM_Init() */

/*******************************************************************************
**                           TestNvM_Init()                                   **
*******************************************************************************/
boolean TestNvM_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(NvM_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      NvM_GucInitCnt = 0;
      NvM_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(NvM_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      NvM_GucInitCnt = 0;
      NvM_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestNvM_Init() */

/*******************************************************************************
**                          NvM_ReadAll()                                     **
*******************************************************************************/

void NvM_ReadAll(void)
{
	App_GucApiSeqCnt++;
	NvM_GucReadAllSeqCnt = App_GucApiSeqCnt;
	NvM_GusReadAllCnt++;
}/* End NvM_ReadAll() */

/*******************************************************************************
**                           TestNvM_ReadAll()                                **
*******************************************************************************/
boolean TestNvM_ReadAll(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(NvM_GusReadAllCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      NvM_GusReadAllCnt = 0;
      NvM_GucReadAllSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(NvM_GucReadAllSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      NvM_GusReadAllCnt = 0;
      NvM_GucReadAllSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestNvM_ReadAll() */

/*******************************************************************************
**                          NvM_WriteAll()                                     **
*******************************************************************************/

void NvM_WriteAll(void)
{
	App_GucApiSeqCnt++;
	NvM_GucWriteAllSeqCnt = App_GucApiSeqCnt;
	NvM_GusWriteAllCnt++;
}/* End NvM_WriteAll() */

/*******************************************************************************
**                           TestNvM_ReadAll()                                **
*******************************************************************************/
boolean TestNvM_WriteAll(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(NvM_GusWriteAllCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      NvM_GusWriteAllCnt = 0;
      NvM_GucWriteAllSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(NvM_GucWriteAllSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      NvM_GusWriteAllCnt = 0;
      NvM_GucWriteAllSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestNvM_WriteAll() */

#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
