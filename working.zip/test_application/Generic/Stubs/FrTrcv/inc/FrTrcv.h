/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: FrTrcv.h                                                      **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FrTrcv Stub                                           **
**                                                                            **
**  PURPOSE   : Declaration of FrTrcv Stub functions                          **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/

#ifndef FRTRCV_H
#define FRTRCV_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Fr_GeneralTypes.h"
#include "TC_Generic.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define FRTRCV_AR_RELEASE_MAJOR_VERSION    0x04
#define FRTRCV_AR_RELEASE_MINOR_VERSION    0x00
#define FRTRCV_AR_RELEASE_REVISION_VERSION 0x03

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
/*FrTrcv_39_Transceiver Dummy files needs to be moved to FrTrcv_39_DriverA*/
extern Std_ReturnType FrTrcv_SetTransceiverMode(uint8 FrTrcv_TrcvIdx,
  FrTrcv_TrcvModeType FrTrcv_TrcvMode);

extern Std_ReturnType FrTrcv_GetTransceiverMode(uint8 FrTrcv_TrcvIdx,
  P2VAR(FrTrcv_TrcvModeType,AUTOAMATIC,FRIF_PRIVATE_DATA)FrTrcv_TrcvModePtr);

extern Std_ReturnType FrTrcv_GetTransceiverWUReason(
  uint8 FrTrcv_TrcvIdx, FrTrcv_TrcvWUReasonType* FrIf_TrcvWUReasonPtr);

extern Std_ReturnType FrTrcv_DisableTransceiverBranch(uint8 FrTrcv_TrcvIdx,
  uint8 FrTrcv_BranchIdx);

extern Std_ReturnType FrTrcv_EnableTransceiverBranch(uint8 FrTrcv_TrcvIdx,
 uint8 FrTrcv_BranchIdx);

extern Std_ReturnType FrTrcv_ClearTransceiverWakeup(uint8 FrTrcv_TrcvIdx);

extern Std_ReturnType FrTrcv_GetTransceiverError(
  uint8 FrTrcv_TrcvIdx, uint8 FrTrcv_BranchIdx,uint32* FrIf_BusErrorState);

extern void FrTrcv_CheckWakeupByTransceiver(uint8 FrTrcv_TrcvIdx);

extern boolean TestFrTrcv_CheckWakeupByTransceiver(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx);

extern void TestFrTrcv_SetTransceiverModeSetBeh(
  Std_ReturnType LddReturnVal);

extern boolean TestFrTrcv_SetTransceiverMode(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx,
  FrTrcv_TrcvModeType FrTrcv_TrcvMode);

extern boolean TestFrTrcv_EnableTransceiverBranch(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx,
  uint8 FrTrcv_BranchIdx);

extern boolean TestFrTrcv_DisableTransceiverBranch(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx,
  uint8 FrTrcv_BranchIdx);

extern void TestFrTrcv_GetTransceiverErrorSetBeh(
  Std_ReturnType LddReturnVal);

extern boolean TestFrTrcv_GetTransceiverError(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx,
  uint8 FrTrcv_BranchIdx,uint32* FrIf_BusErrorState);

extern void TestFrTrcv_EnableTransceiverBranchSetBeh(
  Std_ReturnType LddReturnVal);

extern void TestFrTrcv_DisableTransceiverBranchSetBeh(
  Std_ReturnType LddReturnVal);

extern void TestFrTrcv_GetTransceiverModeSetBeh(
  Std_ReturnType LddReturnVal);

extern void TestFrTrcv_GetTransceiverWUReasonSetBeh(
  Std_ReturnType LddReturnVal);

extern boolean TestFrTrcv_ClearTransceiverWakeup(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx);

extern void TestFrTrcv_ClearTransceiverWakeupSetBeh(
  Std_ReturnType LddReturnVal);

extern boolean TestFrTrcv_GetTransceiverWUReason(
  App_DataValidateType LddDataValidate,uint8 FrTrcv_TrcvIdx,
  FrTrcv_TrcvWUReasonType* FrIf_TrcvWUReasonPtr);

extern boolean TestFrTrcv_GetTransceiverMode(
  App_DataValidateType LddDataValidate,uint8 FrTrcv_TrcvIdx,
  FrTrcv_TrcvModeType* FrIf_TrcvModePtr);
#endif /* FRTRCV_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
