/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: FrTrcv.c                                                      **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FrTrcv Stub                                           **
**                                                                            **
**  PURPOSE   : This application file contains the FrTrcv Stub functions      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "FrTrcv.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
FrTrcv_TrcvModeType FrTrcv_GddTrcvMode;
uint8 FrTrcv_GucTransceivermodecount;
uint8 FrTrcv_GucTrcvIdx;
uint8 FrTrcv_GucBranchIdx;
uint32* FrTrcv_GulBusErrorState; 
uint8 FrTrcv_GucGetTransceiverError;
uint8 FrTrcv_GucEnableTransceiverBranch;
uint8 FrTrcv_GucDisableTransceiverBranch;
FrTrcv_TrcvWUReasonType* FrTrcv_GddTrcvWUReasonPtr;
uint8 FrTrcv_GucTrcvWUReasonCnt;
FrTrcv_TrcvModeType* FrTrcv_GddTrcvModePtr;
uint8 FrTrcv_GucGetTransceiverMode;
uint8 FrTrcv_GucSetTransceiverModeRetVal;
uint8 FrTrcv_GucGetTransceiverModeRetVal;
uint8 FrTrcv_GucGetTransceiverWUReasonRetVal;
uint8 FrTrcv_GucClearTransceiverWakeupRetVal;
uint8 FrTrcv_GucGetTransceiverErrorRetVal;
uint8 FrTrcv_GucEnableTransceiverBranchRetVal;
uint8 FrTrcv_GucDisableTransceiverBranchRetVal;
uint8 FrTrcv_GucTrcvCheckWakeupByTransceiver;

/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
/*******************************************************************************
**                     TestSetDet_ReportErrorRetVal()                         **
*******************************************************************************/
Std_ReturnType  FrTrcv_SetTransceiverMode(
  uint8 FrTrcv_TrcvIdx,FrTrcv_TrcvModeType FrTrcv_TrcvMode)
{
  FrTrcv_GucTrcvIdx = FrTrcv_TrcvIdx;
  FrTrcv_GddTrcvMode = FrTrcv_TrcvMode;
  FrTrcv_GucTransceivermodecount++;
  return(FrTrcv_GucSetTransceiverModeRetVal);
}
void TestFrTrcv_SetTransceiverModeSetBeh(
  Std_ReturnType LddReturnVal)
{
   FrTrcv_GucSetTransceiverModeRetVal = LddReturnVal;
}
/*******************************************************************************
**                         TestFr_39_DriverAStartCommunication()              **
*******************************************************************************/
boolean TestFrTrcv_SetTransceiverMode(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx,
  FrTrcv_TrcvModeType FrTrcv_TrcvMode)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((FrTrcv_GucTransceivermodecount == 0x01) &&
        (FrTrcv_GucTrcvIdx == FrTrcv_TrcvIdx) &&
        (FrTrcv_GddTrcvMode == FrTrcv_TrcvMode)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      FrTrcv_GucTransceivermodecount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrTrcv_GucTransceivermodecount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      FrTrcv_GucTransceivermodecount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
/*******************************************************************************
**                     FrTrcv_GetTransceiverMode()                            **
*******************************************************************************/
Std_ReturnType FrTrcv_GetTransceiverMode(
  uint8 FrTrcv_TrcvIdx, FrTrcv_TrcvModeType* FrIf_TrcvModePtr)
{
  FrTrcv_GucTrcvIdx = FrTrcv_TrcvIdx;
  FrTrcv_GddTrcvModePtr = FrIf_TrcvModePtr;
  FrTrcv_GucGetTransceiverMode++;
  return(FrTrcv_GucGetTransceiverModeRetVal);
}
void TestFrTrcv_GetTransceiverModeSetBeh(
  Std_ReturnType LddReturnVal)
{
   FrTrcv_GucGetTransceiverModeRetVal = LddReturnVal;
}
/*******************************************************************************
**               TestFrTrcv_39_TransceiverATrcvGetTransceiverWUReason()       **
*******************************************************************************/
boolean TestFrTrcv_GetTransceiverMode(
  App_DataValidateType LddDataValidate,uint8 FrTrcv_TrcvIdx, 
  FrTrcv_TrcvModeType* FrIf_TrcvModePtr) 
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((FrTrcv_GucGetTransceiverMode == 0x01) &&
        (FrTrcv_GucTrcvIdx == FrTrcv_TrcvIdx) &&
        (FrTrcv_GddTrcvModePtr == FrIf_TrcvModePtr)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      FrTrcv_GucGetTransceiverMode = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrTrcv_GucGetTransceiverMode == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      FrTrcv_GucGetTransceiverMode = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
/*******************************************************************************
**                     FrTrcv_GetTransceiverWUReason()                        **
*******************************************************************************/
Std_ReturnType FrTrcv_GetTransceiverWUReason(
  uint8 FrTrcv_TrcvIdx, FrTrcv_TrcvWUReasonType* FrIf_TrcvWUReasonPtr)
{
  FrTrcv_GucTrcvIdx = FrTrcv_TrcvIdx;
  FrTrcv_GddTrcvWUReasonPtr = FrIf_TrcvWUReasonPtr;
  FrTrcv_GucTrcvWUReasonCnt++;
  return(FrTrcv_GucGetTransceiverWUReasonRetVal);
}
void TestFrTrcv_GetTransceiverWUReasonSetBeh(
  Std_ReturnType LddReturnVal)
{
   FrTrcv_GucGetTransceiverWUReasonRetVal = LddReturnVal;
}
/*******************************************************************************
**               TestFrTrcv_GetTransceiverWUReason()                          **
*******************************************************************************/
boolean TestFrTrcv_GetTransceiverWUReason(
  App_DataValidateType LddDataValidate,uint8 FrTrcv_TrcvIdx, 
  FrTrcv_TrcvWUReasonType* FrIf_TrcvWUReasonPtr) 
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((FrTrcv_GucTrcvWUReasonCnt == 0x01) &&
        (FrTrcv_GucTrcvIdx == FrTrcv_TrcvIdx) &&
        (FrTrcv_GddTrcvWUReasonPtr == FrIf_TrcvWUReasonPtr)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      FrTrcv_GucTrcvWUReasonCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrTrcv_GucTrcvWUReasonCnt == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      FrTrcv_GucTrcvWUReasonCnt = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
/*******************************************************************************
**                     TrcvDisableTransceiverBranch()                         **
*******************************************************************************/
Std_ReturnType FrTrcv_DisableTransceiverBranch(
  uint8 FrTrcv_TrcvIdx, uint8 FrTrcv_BranchIdx)
{
  FrTrcv_GucBranchIdx = FrTrcv_BranchIdx;
  FrTrcv_GucTrcvIdx = FrTrcv_TrcvIdx;
  FrTrcv_GucDisableTransceiverBranch++;
  return(FrTrcv_GucDisableTransceiverBranchRetVal);
}
void TestFrTrcv_DisableTransceiverBranchSetBeh(
  Std_ReturnType LddReturnVal)
{
   FrTrcv_GucDisableTransceiverBranchRetVal = LddReturnVal;
}
/*******************************************************************************
**               TestFr_39_TransceiverATrcvDisableTransceiverBranch()         **
*******************************************************************************/
boolean TestFrTrcv_DisableTransceiverBranch(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx,
  uint8 FrTrcv_BranchIdx)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((FrTrcv_GucDisableTransceiverBranch == 0x01) &&
        (FrTrcv_GucTrcvIdx == FrTrcv_TrcvIdx) &&
        (FrTrcv_GucBranchIdx == FrTrcv_BranchIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      FrTrcv_GucDisableTransceiverBranch = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrTrcv_GucDisableTransceiverBranch == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      FrTrcv_GucDisableTransceiverBranch = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 


/*******************************************************************************
**                     TrcvEnableTransceiverBranch()                           **
*******************************************************************************/
Std_ReturnType FrTrcv_EnableTransceiverBranch(
  uint8 FrTrcv_TrcvIdx, uint8 FrTrcv_BranchIdx)
{
  FrTrcv_GucBranchIdx = FrTrcv_BranchIdx;
  FrTrcv_GucTrcvIdx = FrTrcv_TrcvIdx;
  FrTrcv_GucEnableTransceiverBranch++;
  return(FrTrcv_GucEnableTransceiverBranchRetVal);
}
void TestFrTrcv_EnableTransceiverBranchSetBeh(
  Std_ReturnType LddReturnVal)
{
   FrTrcv_GucEnableTransceiverBranchRetVal = LddReturnVal;
}
/*******************************************************************************
**               TestFr_39_TransceiverATrcvEnableTransceiverBranch()          **
*******************************************************************************/
boolean TestFrTrcv_EnableTransceiverBranch(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx,
  uint8 FrTrcv_BranchIdx)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((FrTrcv_GucEnableTransceiverBranch == 0x01) &&
        (FrTrcv_GucTrcvIdx == FrTrcv_TrcvIdx) &&
        (FrTrcv_GucBranchIdx == FrTrcv_BranchIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      FrTrcv_GucEnableTransceiverBranch = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrTrcv_GucEnableTransceiverBranch == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      FrTrcv_GucEnableTransceiverBranch = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
/*******************************************************************************
**                     TrcvClearTransceiverWakeup()                           **
*******************************************************************************/
Std_ReturnType FrTrcv_ClearTransceiverWakeup(
  uint8 FrTrcv_TrcvIdx)
{
  FrTrcv_GucTrcvIdx = FrTrcv_TrcvIdx;
  FrTrcv_GucTransceivermodecount++;
  return(FrTrcv_GucClearTransceiverWakeupRetVal);
}
void TestFrTrcv_ClearTransceiverWakeupSetBeh(
  Std_ReturnType LddReturnVal)
{
   FrTrcv_GucClearTransceiverWakeupRetVal = LddReturnVal;
}
/*******************************************************************************
**                         TestFr_39_DriverATrcvClearTransceiverWakeup()      **
*******************************************************************************/
boolean TestFrTrcv_ClearTransceiverWakeup(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((FrTrcv_GucTransceivermodecount == 0x01) &&
        (FrTrcv_GucTrcvIdx == FrTrcv_TrcvIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      FrTrcv_GucTransceivermodecount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrTrcv_GucTransceivermodecount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      FrTrcv_GucTransceivermodecount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
/*******************************************************************************
**                     FrTrcv_GetTransceiverError()                           **
*******************************************************************************/
Std_ReturnType FrTrcv_GetTransceiverError(
  uint8 FrTrcv_TrcvIdx, uint8 FrTrcv_BranchIdx,uint32* FrIf_BusErrorState)
{
  FrTrcv_GucTrcvIdx = FrTrcv_TrcvIdx;
  FrTrcv_GucBranchIdx = FrTrcv_BranchIdx;
  FrTrcv_GulBusErrorState = FrIf_BusErrorState;
  FrTrcv_GucGetTransceiverError++;
  return(FrTrcv_GucGetTransceiverErrorRetVal);
}
void TestFrTrcv_GetTransceiverErrorSetBeh(
  Std_ReturnType LddReturnVal)
{
   FrTrcv_GucGetTransceiverErrorRetVal = LddReturnVal;
}
/*******************************************************************************
**                   TestFrTrcv_GetTransceiverError()      **
*******************************************************************************/
boolean TestFrTrcv_GetTransceiverError(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx,
  uint8 FrTrcv_BranchIdx,uint32* FrIf_BusErrorState)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((FrTrcv_GucGetTransceiverError == 0x01) &&
        (FrTrcv_GucTrcvIdx == FrTrcv_TrcvIdx) &&
        (FrTrcv_GucBranchIdx == FrTrcv_BranchIdx) &&
        (FrTrcv_GulBusErrorState == FrIf_BusErrorState))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      FrTrcv_GucGetTransceiverError = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrTrcv_GucGetTransceiverError == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      FrTrcv_GucGetTransceiverError = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*******************************************************************************
**                     FrTrcv_CheckWakeupByTransceiver()                      **
*******************************************************************************/
void FrTrcv_CheckWakeupByTransceiver(uint8 FrTrcv_TrcvIdx)
{
  FrTrcv_GucTrcvIdx = FrTrcv_TrcvIdx;
  FrTrcv_GucTrcvCheckWakeupByTransceiver++;
}

/*******************************************************************************
**                   TestFrTrcv_CheckWakeupByTransceiver()                    **
*******************************************************************************/
boolean TestFrTrcv_CheckWakeupByTransceiver(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((FrTrcv_GucTrcvCheckWakeupByTransceiver == 0x01) &&
        (FrTrcv_GucTrcvIdx == FrTrcv_TrcvIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      FrTrcv_GucTrcvCheckWakeupByTransceiver = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrTrcv_GucTrcvCheckWakeupByTransceiver == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      FrTrcv_GucTrcvCheckWakeupByTransceiver = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
/*******************************************************************************
**                     CanTrcv_CheckWakeup()                                  **
*******************************************************************************/


/*******************************************************************************
**                     TestCanTrcv_CheckWakeup()                              **
*******************************************************************************/


/*******************************************************************************
**                       CanTrcv_GetBusWuReason()                             **
*******************************************************************************/

/*******************************************************************************
**                     TestSetCanTrcv_GetBusWuReason()                        **
*******************************************************************************/

/*******************************************************************************
**                   TestCanTrcv_GetBusWuReason()                             **
*******************************************************************************/


/*******************************************************************************
**                        TestCanTrcv_DefaultBehavior()                       **
*******************************************************************************/

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

