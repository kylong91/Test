/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: BswM.c                                                        **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BswM Stub                                             **
**                                                                            **
**  PURPOSE   : This application file contains the BswM Stub functions        **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "BswM.h"
#ifdef COMM_MODULE_ACTIVE
#include "BswM_ComM.h"
#endif
#ifdef ETHSM_MODULE_ACTIVE
#include "BswM_EthSM.h"
#endif
#ifdef CANSM_MODULE_ACTIVE
#include "BswM_CanSM.h"
#endif
#ifdef LINSM_MODULE_ACTIVE
#include "BswM_LinSM.h"
#endif
#ifdef LINIF_MODULE_ACTIVE
#include "BswM_LinTp.h"
#endif
#ifdef DCM_MODULE_ACTIVE
#include "BswM_Dcm.h"
#endif
#ifdef WDGM_MODULE_ACTIVE
#include "BswM_WdgM.h"
#endif
#ifdef SD_MODULE_ACTIVE
#include "BswM_SD.h"
#endif
#ifdef FRSM_MODULE_ACTIVE
#include "BswM_FrSM.h"
#endif
#ifdef ECUM_MODULE_ACTIVE
#include "BswM_EcuM.h"
#endif
#ifdef NVM_MODULE_ACTIVE
#include "BswM_NvM.h"
#endif
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/* Variables for BswM-CanSM Interfaces */
uint8 BswM_GucCurrentStateCheckCount;
NetworkHandleType BswM_GaaNetwork[BSWM_ARRAY_SIZE];
#ifdef CANSM_MODULE_ACTIVE
uint8 BswM_GucCurrentStateCount;
CanSM_BswMCurrentStateType BswM_GaaCurrentState[BSWM_ARRAY_SIZE];
#endif
#ifdef ETHSM_MODULE_ACTIVE
uint8 BswM_GucEthSmCurrentStateCount;
uint8 BswM_GucEthSmCurrentStateCheckCount;
NetworkHandleType BswM_GaaEthSmNetwork[BSWM_ARRAY_SIZE];
EthSM_BswMNetworkModeStateType BswM_GaaEthSmCurrentState[BSWM_ARRAY_SIZE];
#endif
#ifdef LINSM_MODULE_ACTIVE
uint8 BswM_GucLinCurrentStateCount;
uint8 BswM_GucLinCurrentScheduleCount;
NetworkHandleType BswM_GaaLinNetwork[BSWM_ARRAY_SIZE];
LinSM_ModeType BswM_GaaLinCurrentState[BSWM_ARRAY_SIZE];
LinIf_SchHandleType BswM_GaaLinCurrentSchedule[BSWM_ARRAY_SIZE];
#endif

uint8 BswM_GucRequestedModeCount;

#ifdef COMM_MODULE_ACTIVE
NetworkHandleType BswM_GddNetwork;
PNCHandleType BswM_GaaPNC[BSWM_ARRAY_SIZE];
ComM_PncModeType BswM_GaaRequestedPNCMode[BSWM_ARRAY_SIZE];
ComM_ModeType BswM_GddRequestedMode;
uint8 BswM_GucPncCount;
uint8 BswM_GucCheckPncCount;
#endif

/* Variables for BswM-LinTp Interfaces */
#ifdef LINIF_MODULE_ACTIVE
LinTp_Mode BswM_GddLinTpRequestedMode;
#endif

#ifdef DCM_MODULE_ACTIVE
NetworkHandleType BswM_GddNetworkId[15];
Dcm_CommunicationModeType BswM_GddCommunication[15];
uint8 BswM_GucControl[15];
uint8 BswM_GucCommunicationModeCount;
uint8 BswM_GucCommModeInCheckCount;
#endif

/* Variables for BswM-WdgM Interfaces */
#ifdef WDGM_MODULE_ACTIVE
uint8 BswM_GucPartitionResetCount;
uint8 BswM_GucPartitionResetCheckCount;
ApplicationType BswM_GaaApplication[BSWM_ARRAY_SIZE];
#endif

/* Variables for BswM-SD Interfaces */
#ifdef SD_MODULE_ACTIVE
uint8 BswM_GucSDCurrentStateCount;
uint8 BswM_GucSDCurrentStateCheckCount;
uint16 BswM_GaaSDService[BSWM_ARRAY_SIZE];
SD_StateType BswM_GaaSDCurrentState[BSWM_ARRAY_SIZE];
#endif

/* Variables for BswM-FrSM Interfaces */
#ifdef FRSM_MODULE_ACTIVE
uint8 BswM_GaaCurrStateNtwrk[BSWM_ARRAY_SIZE];
uint8 BswM_GaaCurrStateType[BSWM_ARRAY_SIZE];
uint8 BswM_GucCurrStateCount;
uint8 BswM_GucCurrStateCheckCount;
#endif

/* Variables for BswM-EcuM Interfaces */
#ifdef ECUM_MODULE_ACTIVE

EcuM_StateType BswM_GaaCurrentState[BSWM_ARRAY_SIZE];
EcuM_WakeupSourceType BswM_GaaWkpSource[BSWM_ARRAY_SIZE];
EcuM_WakeupStatusType BswM_GaaWkpSrcState[BSWM_ARRAY_SIZE];
uint8 BswM_GucConfigData;
uint8 BswM_GucEcuMWkpCount;
uint8 BswM_GucEcuMStateCount;
uint8 BswM_GucEcuMSeqCnt;
uint8 BswM_GaaEcuMSeqCnt[BSWM_ARRAY_SIZE];
uint8 BswM_GucEcuMCheckWkpCount;
uint8 BswM_GucEcuMCheckStateCount;
uint8 BswM_GucInitSeqCnt;
uint8 BswM_GucDeinitSeqCnt;
uint8 BswM_GucDeinitCount;
uint8 BswM_GucInitCount;
#endif

/* Variables for BswM-NvM Interface */
#ifdef NVM_MODULE_ACTIVE
uint8 BswM_GucServiceId;
NvM_RequestResultType BswM_GddCurrentJobMode;
uint8 BswM_GucMultiBlkCbkCount;
NvM_BlockIdType BswM_GddBlockId[BSWM_ARRAY_SIZE];
NvM_RequestResultType BswM_GddCurrentBlockMode[BSWM_ARRAY_SIZE];
uint8 BswM_GucSingleBlkCbkCount;
uint8 BswM_GucSingleBlkCbkCheckCount;
#endif
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
#ifdef ECUM_MODULE_ACTIVE
/*******************************************************************************
**                              BswM_Init()                                   **
*******************************************************************************/
void BswM_Init(const BswM_ConfigType * ConfigPtr)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  BswM_GucInitCount++;
  BswM_GucInitSeqCnt = App_GucApiSeqCnt;
  if (ConfigPtr != NULL_PTR)
  {
    BswM_GucConfigData = (ConfigPtr->dummy);
  }
  #endif
}

/*******************************************************************************
**                           TestBswM_Init()                                  **
*******************************************************************************/
boolean TestBswM_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, uint8 LucData)
{
  boolean LblStepResult;  
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((BswM_GucInitCount == 0x01) && (BswM_GucInitSeqCnt == 0x01) && 
        (BswM_GucConfigData == LucData))
      {
        LblStepResult = STEP_PASSED;
      }
      BswM_GucInitSeqCnt = 0;
      BswM_GucInitCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if((BswM_GucInitSeqCnt == LucSeqNo) && 
        (BswM_GucConfigData == LucData))
      {
        LblStepResult = STEP_PASSED;
      }
      BswM_GucInitSeqCnt = 0;
      BswM_GucInitCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(BswM_GucInitCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */    
    
  return(LblStepResult);
} /* End TestBswM_Init() */

/*******************************************************************************
**                              BswM_DeInit()                                 **
*******************************************************************************/
void BswM_Deinit(void)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  BswM_GucDeinitSeqCnt = App_GucApiSeqCnt;
  BswM_GucDeinitCount++;
  #endif
}

/*******************************************************************************
**                         TestBswM_Deinit()                                  **
*******************************************************************************/
boolean TestBswM_Deinit(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;  
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(BswM_GucDeinitCount == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      BswM_GucDeinitCount = 0;
      BswM_GucDeinitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(BswM_GucDeinitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      BswM_GucDeinitSeqCnt = 0;
      BswM_GucDeinitCount= 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */    
    
  return(LblStepResult);
} /* End TestBswM_Deinit() */

/*******************************************************************************
**                     BswM_EcuM_CurrentState()                               **
*******************************************************************************/
void BswM_EcuM_CurrentState(EcuM_StateType CurrentState)
{
  #ifndef TYPICAL_CONFIG
  BswM_GaaCurrentState[BswM_GucEcuMStateCount] = CurrentState;
  
  if(BswM_GucEcuMStateCount < BSWM_ARRAY_SIZE)
  {
    BswM_GucEcuMStateCount++;
  }
  else
  {
    BswM_GucEcuMStateCount = 0;
  }
  #endif
}

/*******************************************************************************
**                       TestBswM_EcuM_CurrentState()                         **
*******************************************************************************/
boolean TestBswM_EcuM_CurrentState(App_DataValidateType LucDataValidate, 
  EcuM_StateType LddCurrentState)
{
  boolean LblStepResult;
  uint8 LucIndex;
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((BswM_GucEcuMStateCount == 1) && 
        (BswM_GaaCurrentState[0] == LddCurrentState))
      {
        LblStepResult = STEP_PASSED;
      }
      BswM_GucEcuMStateCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < BswM_GucEcuMStateCount; LucIndex++)
      {
        /* Validate Current state */
        if(BswM_GaaCurrentState[LucIndex] == LddCurrentState)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = BswM_GucEcuMStateCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      BswM_GucEcuMCheckStateCount++;
      BswM_GucEcuMSeqCnt = 0;
      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(BswM_GucEcuMCheckStateCount == BswM_GucEcuMStateCount)
      {
        BswM_GucEcuMStateCount = 0;
        BswM_GucEcuMCheckStateCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(BswM_GucEcuMStateCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestBswM_EcuM_CurrentState() */

/*******************************************************************************
**                     BswM_EcuM_CurrentWakeup()                              **
*******************************************************************************/
void BswM_EcuM_CurrentWakeup(EcuM_WakeupSourceType source, 
  EcuM_WakeupStatusType state)
{
  #ifndef TYPICAL_CONFIG
  BswM_GaaWkpSource[BswM_GucEcuMWkpCount] = source;
  BswM_GaaWkpSrcState[BswM_GucEcuMWkpCount] = state;
  
  if(BswM_GucEcuMWkpCount < BSWM_ARRAY_SIZE)
  {
    BswM_GucEcuMWkpCount++;
  }
  #endif
}

/*******************************************************************************
**                       TestBswM_EcuM_CurrentWakeup()                        **
*******************************************************************************/
boolean TestBswM_EcuM_CurrentWakeup(App_DataValidateType LucDataValidate, 
  EcuM_WakeupSourceType Lddsource, EcuM_WakeupStatusType Lddstate)
{
  boolean LblStepResult;
  uint8 LucIndex;
  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((BswM_GucEcuMWkpCount == 1) && 
        (BswM_GaaWkpSource[0] == Lddsource) && 
        (BswM_GaaWkpSrcState[0] == Lddstate))
      {
        LblStepResult = STEP_PASSED;
      }
      BswM_GucEcuMWkpCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < BswM_GucEcuMWkpCount; LucIndex++)
      {
        /* Validate Current state */
        if((BswM_GaaWkpSource[LucIndex] == Lddsource) &&
          (BswM_GaaWkpSrcState[LucIndex] == Lddstate))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = BswM_GucEcuMWkpCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      BswM_GucEcuMCheckWkpCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(BswM_GucEcuMCheckWkpCount == BswM_GucEcuMWkpCount)
      {
        BswM_GucEcuMWkpCount = 0;
        BswM_GucEcuMCheckWkpCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(BswM_GucEcuMWkpCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestBswM_EcuM_CurrentWakeup() */
#endif
/*******************************************************************************
**                         TestBswM_DefaultBehavior()                         **
*******************************************************************************/
void TestBswM_DefaultBehavior(void)
{
  #ifdef ETHSM_MODULE_ACTIVE
  uint8 LucIndex;
  BswM_GucEthSmCurrentStateCount = 0;
  BswM_GucEthSmCurrentStateCheckCount = 0;
  for (LucIndex = 0 ; LucIndex < BSWM_ARRAY_SIZE; LucIndex++)
  {
    BswM_GaaEthSmNetwork[BswM_GucEthSmCurrentStateCount] = 0;
    BswM_GaaEthSmCurrentState[BswM_GucEthSmCurrentStateCount] = 0;
  }
  #endif
  #ifdef FRSM_MODULE_ACTIVE
  BswM_GucCurrStateCount = 0;
  BswM_GucCurrStateCheckCount = 0;
  #endif

  BswM_GucCurrentStateCheckCount = 0;
  #ifdef CANSM_MODULE_ACTIVE
  BswM_GucCurrentStateCount = 0;
  #endif

  #ifdef COMM_MODULE_ACTIVE
  BswM_GucRequestedModeCount = 0;
  BswM_GucPncCount = 0;
  #endif

  #ifdef LINSM_MODULE_ACTIVE
  BswM_GucLinCurrentStateCount = 0;
  BswM_GucLinCurrentScheduleCount = 0;
  #endif


  #ifdef LINIF_MODULE_ACTIVE
  BswM_GucRequestedModeCount = 0;
  #endif


  #ifdef DCM_MODULE_ACTIVE
  BswM_GucCommunicationModeCount = 0;
  BswM_GucCommModeInCheckCount = 0;
  #endif

  #ifdef WDGM_MODULE_ACTIVE
  BswM_GucPartitionResetCount = 0;
  BswM_GucPartitionResetCheckCount = 0;
  #endif
  
  #ifdef ECUM_MODULE_ACTIVE
  BswM_GucConfigData = 0;
  BswM_GucInitSeqCnt = 0;
  BswM_GucDeinitSeqCnt = 0;
  BswM_GucDeinitCount = 0;
  BswM_GucEcuMWkpCount = 0;
  BswM_GucEcuMStateCount = 0;
  BswM_GucEcuMSeqCnt = 0;
  BswM_GucEcuMCheckWkpCount = 0;
  BswM_GucEcuMCheckStateCount = 0;
  BswM_GucInitCount = 0;
  #endif
  
  #ifdef NVM_MODULE_ACTIVE
  BswM_GucSingleBlkCbkCount = 0;
  BswM_GucSingleBlkCbkCheckCount = 0;
  #endif
}

#ifdef CANSM_MODULE_ACTIVE
/*******************************************************************************
**                     BswM_CanSM_CurrentState()                              **
*******************************************************************************/
void BswM_CanSM_CurrentState(NetworkHandleType Network,
  const CanSM_BswMCurrentStateType CurrentState)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual Network and CurrentState into Global variables */
  BswM_GaaNetwork[BswM_GucCurrentStateCount] = Network;
  BswM_GaaCurrentState[BswM_GucCurrentStateCount] = CurrentState;

  /* Increment count variable to handle multiple invocations */
  if(BswM_GucCurrentStateCount < BSWM_ARRAY_SIZE)
  {
    BswM_GucCurrentStateCount++;
  }
  #endif /* TYPICAL_CONFIG */
}

/*******************************************************************************
**                       TestBswM_CanSM_CurrentState()                        **
*******************************************************************************/
boolean TestBswM_CanSM_CurrentState(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpNetwork,
  CanSM_BswMCurrentStateType LddExpCurrentState)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Network and CurrentState */
      if((BswM_GucCurrentStateCount == 0x01) &&
        (BswM_GaaNetwork[0] == LddExpNetwork) &&
        (BswM_GaaCurrentState[0] == LddExpCurrentState))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      BswM_GucCurrentStateCount = 0;
      BswM_GucCurrentStateCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < BswM_GucCurrentStateCount; LucIndex++)
      {
        /* Validate Network and CurrentState */
        if((BswM_GaaNetwork[LucIndex] == LddExpNetwork) &&
          (BswM_GaaCurrentState[LucIndex] == LddExpCurrentState))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = BswM_GucCurrentStateCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      BswM_GucCurrentStateCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(BswM_GucCurrentStateCheckCount == BswM_GucCurrentStateCount)
      {
        BswM_GucCurrentStateCount = 0;
        BswM_GucCurrentStateCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(BswM_GucCurrentStateCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestBswM_CanSM_CurrentState() */
#endif
#ifdef ETHSM_MODULE_ACTIVE
/*******************************************************************************
**                     BswM_EthSM_CurrentState()                              **
*******************************************************************************/
void BswM_EthSM_CurrentState( NetworkHandleType Network,
                                       EthSM_BswMNetworkModeStateType CurrentState)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual Network and CurrentState into Global variables */
  BswM_GaaEthSmNetwork[BswM_GucEthSmCurrentStateCount] = Network;
  BswM_GaaEthSmCurrentState[BswM_GucEthSmCurrentStateCount] = CurrentState;

  /* Increment count variable to handle multiple invocations */
  if(BswM_GucEthSmCurrentStateCount < BSWM_ARRAY_SIZE)
  {
    BswM_GucEthSmCurrentStateCount++;
  }
  #endif /* TYPICAL_CONFIG */
}

/*******************************************************************************
**                       TestBswM_EthSM_CurrentState()                        **
*******************************************************************************/
boolean TestBswM_EthSM_CurrentState(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpNetwork, EthSM_BswMNetworkModeStateType
  LddExpCurrentState)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Network and CurrentState */
      if((BswM_GucEthSmCurrentStateCount == 0x01) &&
        (BswM_GaaEthSmNetwork[0] == LddExpNetwork) &&
        (BswM_GaaEthSmCurrentState[0] == LddExpCurrentState))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      BswM_GucEthSmCurrentStateCount = 0;
      BswM_GucEthSmCurrentStateCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < BswM_GucEthSmCurrentStateCount; LucIndex++)
      {
        /* Validate Network and CurrentState */
        if((BswM_GaaEthSmNetwork[LucIndex] == LddExpNetwork) &&
          (BswM_GaaEthSmCurrentState[LucIndex] == LddExpCurrentState))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = BswM_GucEthSmCurrentStateCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      BswM_GucEthSmCurrentStateCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(BswM_GucEthSmCurrentStateCheckCount == BswM_GucEthSmCurrentStateCount)
      {
        BswM_GucEthSmCurrentStateCount = 0;
        BswM_GucEthSmCurrentStateCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(BswM_GucEthSmCurrentStateCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestBswM_EthSM_CurrentState() */

#endif

#ifdef COMM_MODULE_ACTIVE
/*******************************************************************************
**                     BswM_ComM_CurrentMode()                                **
*******************************************************************************/
void BswM_ComM_CurrentMode(NetworkHandleType Network,
  ComM_ModeType RequestedMode)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual Network and CurrentState into Global variables */
  BswM_GddNetwork = Network;
  BswM_GddRequestedMode = RequestedMode;
  BswM_GucRequestedModeCount++;
  #endif
}

/*******************************************************************************
**                       TestBswM_ComM_CurrentMode()                          **
*******************************************************************************/
boolean TestBswM_ComM_CurrentMode(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpNetwork,
  ComM_ModeType LddExpRequestedMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Network and CurrentState */
      if((BswM_GucRequestedModeCount == 0x01) &&
        (BswM_GddNetwork == LddExpNetwork) &&
        (BswM_GddRequestedMode == LddExpRequestedMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      BswM_GucRequestedModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(BswM_GucRequestedModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestBswM_ComM_CurrentMode() */

/*******************************************************************************
**                     BswM_ComM_CurrentPNCMode()                             **
*******************************************************************************/
void BswM_ComM_CurrentPNCMode(PNCHandleType PNC,
  ComM_PncModeType RequestedPNCMode)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual PNC and Current pnc State into Global variables */
  BswM_GaaPNC[BswM_GucPncCount] = PNC;
  BswM_GaaRequestedPNCMode[BswM_GucPncCount] = RequestedPNCMode;

  if(BswM_GucPncCount < BSWM_ARRAY_SIZE)
  {
    BswM_GucPncCount++;
  }
  else
  {
    BswM_GucPncCount = 0;
  }
  #endif
}

/*******************************************************************************
**                       TestBswM_ComM_CurrentPNCMode()                       **
*******************************************************************************/
boolean TestBswM_ComM_CurrentPNCMode(App_DataValidateType LucDataValidate,
  PNCHandleType LddExpPNC, ComM_PncModeType LddExpRequestedPNCMode)
{
  boolean LblStepResult;

  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Network and CurrentState */
      if((BswM_GucPncCount == 0x01) &&
        (BswM_GaaPNC[0] == LddExpPNC) &&
        (BswM_GaaRequestedPNCMode[0] == LddExpRequestedPNCMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      BswM_GucPncCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      for(LucIndex = 0; LucIndex < BswM_GucPncCount; LucIndex++)
      {
        /* Validate Current state */
        if((BswM_GaaPNC[LucIndex] == LddExpPNC) &&
          (BswM_GaaRequestedPNCMode[LucIndex] == LddExpRequestedPNCMode))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = BswM_GucPncCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      BswM_GucCheckPncCount++;
      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(BswM_GucCheckPncCount == BswM_GucPncCount)
      {
        BswM_GucPncCount = 0;
        BswM_GucCheckPncCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(BswM_GucPncCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestBswM_ComM_CurrentPNCMode() */
#endif

#ifdef LINSM_MODULE_ACTIVE
/*******************************************************************************
**                     BswM_LinSM_CurrentState()                              **
*******************************************************************************/
void BswM_LinSM_CurrentState( NetworkHandleType Network,
  LinSM_ModeType CurrentState)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual Network and CurrentState into Global variables */
  BswM_GaaLinNetwork[BswM_GucLinCurrentStateCount] = Network;
  BswM_GaaLinCurrentState[BswM_GucLinCurrentStateCount] = CurrentState;

  /* Increment count variable to handle multiple invocations */
  if(BswM_GucLinCurrentStateCount < BSWM_ARRAY_SIZE)
  {
    BswM_GucLinCurrentStateCount++;
  }
  #endif /* TYPICAL_CONFIG */
}

/*******************************************************************************
**                       TestBswM_LinSM_CurrentState()                        **
*******************************************************************************/
boolean TestBswM_LinSM_CurrentState(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpNetwork, LinSM_ModeType LddExpCurrentState)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Network and CurrentState */
      if((BswM_GucLinCurrentStateCount >= 0x01) &&
        (BswM_GaaLinNetwork[0] == LddExpNetwork) &&
        (BswM_GaaLinCurrentState[0] == LddExpCurrentState))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      BswM_GucLinCurrentStateCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(BswM_GucLinCurrentStateCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestBswM_CanSM_CurrentState() */

/*******************************************************************************
**                     BswM_LinSM_CurrentSchedule()                           **
*******************************************************************************/
void BswM_LinSM_CurrentSchedule( NetworkHandleType Network,
  LinIf_SchHandleType CurrentSchedule)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual Network and CurrentSchedule into Global variables */
  BswM_GaaLinNetwork[BswM_GucLinCurrentScheduleCount] = Network;
  BswM_GaaLinCurrentSchedule[BswM_GucLinCurrentScheduleCount] = CurrentSchedule;

  /* Increment count variable to handle multiple invocations */
  if(BswM_GucLinCurrentScheduleCount < BSWM_ARRAY_SIZE)
  {
    BswM_GucLinCurrentScheduleCount++;
  }
  #endif /* TYPICAL_CONFIG */
}

/*******************************************************************************
**                       TestBswM_LinSM_CurrentSchedule()                     **
*******************************************************************************/
boolean TestBswM_LinSM_CurrentSchedule(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpNetwork, LinIf_SchHandleType LddExpCurrentSchedule)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Network and CurrentSchedule */
      if((BswM_GucLinCurrentScheduleCount == 0x01) &&
        (BswM_GaaLinNetwork[0] == LddExpNetwork) &&
        (BswM_GaaLinCurrentSchedule[0] == LddExpCurrentSchedule))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      BswM_GucLinCurrentScheduleCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(BswM_GucLinCurrentScheduleCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestBswM_CanSM_CurrentSchedule() */
#endif

#ifdef LINIF_MODULE_ACTIVE
/*******************************************************************************
**                     BswM_LinTp_RequestMode()                               **
*******************************************************************************/
void BswM_LinTp_RequestMode(NetworkHandleType Network,
  LinTp_Mode LinTpRequestedMode)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual Network and LinTpRequestedMode into Global variables */
  BswM_GaaNetwork[BswM_GucRequestedModeCount] = Network;
  BswM_GddLinTpRequestedMode = LinTpRequestedMode;

  /* Increment count variable to handle multiple invocations */
  if(BswM_GucRequestedModeCount < BSWM_ARRAY_SIZE)
  {
    BswM_GucRequestedModeCount++;
  }
  #endif /* TYPICAL_CONFIG */
}

/*******************************************************************************
**                       TestBswM_LinTp_RequestMode()                         **
*******************************************************************************/
boolean TestBswM_LinTp_RequestMode(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpNetwork, LinTp_Mode LddExpRequestedScheduleMode)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Network and RequestedScheduleMode */
      if((BswM_GucRequestedModeCount == 0x01) &&
        (BswM_GaaNetwork[0] == LddExpNetwork) &&
        (BswM_GddLinTpRequestedMode == LddExpRequestedScheduleMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      BswM_GucRequestedModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(BswM_GucRequestedModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestBswM_LinTp_RequestMode() */
#endif

#ifdef DCM_MODULE_ACTIVE

/*******************************************************************************
**                     BswM_Dcm_CommunicationMode_CurrentState()              **
*******************************************************************************/
void BswM_Dcm_CommunicationMode_CurrentState(NetworkHandleType Network,
Dcm_CommunicationModeType RequestedMode, uint8 SubFunction)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual Network , RequestedMode and Control into Global variables */
  BswM_GddNetworkId[BswM_GucCommunicationModeCount] = Network;
  BswM_GddCommunication[BswM_GucCommunicationModeCount] = RequestedMode;
  BswM_GucControl[BswM_GucCommunicationModeCount] = SubFunction;
  BswM_GucCommunicationModeCount++;
  #endif
}

/*******************************************************************************
**                       TestBswM_Dcm_CommunicationMode_CurrentState()        **
*******************************************************************************/
boolean TestBswM_Dcm_CommunicationMode_CurrentState(
  App_DataValidateType LucDataValidate, NetworkHandleType LddExpNetworkId,
  Dcm_CommunicationModeType LddExpCommunicationType, uint8 LucSubFunction)
{
  uint8 LucIndex;
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Network and CurrentState */
      if((BswM_GucCommunicationModeCount == 0x01) &&
        (BswM_GddNetworkId[0] == LddExpNetworkId) &&
        (BswM_GddCommunication[0] == LddExpCommunicationType) &&
    (BswM_GucControl[0] == LucSubFunction))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      BswM_GucCommunicationModeCount = 0;
    BswM_GucCommModeInCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
    for(LucIndex = 0; LucIndex < BswM_GucCommunicationModeCount; LucIndex++)
      {
      if((BswM_GddNetworkId[LucIndex] == LddExpNetworkId) &&
        (BswM_GddCommunication[LucIndex] == LddExpCommunicationType) &&
       (BswM_GucControl[LucIndex] == LucSubFunction))
        {
          LblStepResult = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = BswM_GucCommunicationModeCount;
        }
    }

    /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      BswM_GucCommModeInCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(BswM_GucCommunicationModeCount == BswM_GucCommModeInCheckCount)
      {
        BswM_GucCommunicationModeCount = 0;
        BswM_GucCommModeInCheckCount = 0;
      }

      break;
  } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(BswM_GucCommunicationModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End BswM_Dcm_CommunicationMode_CurrentState() */
#endif

#ifdef WDGM_MODULE_ACTIVE
/*******************************************************************************
**                     BswM_CanSM_CurrentState()                              **
*******************************************************************************/
void BswM_WdgM_RequestPartitionReset(ApplicationType Application)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual Application into Global variables */
  BswM_GaaApplication[BswM_GucPartitionResetCount] = Application;

  /* Increment count variable to handle multiple invocations */
  if(BswM_GucPartitionResetCount < BSWM_ARRAY_SIZE)
  {
    BswM_GucPartitionResetCount++;
  }
  #endif
}

/*******************************************************************************
**                       TestBswM_CanSM_CurrentState()                        **
*******************************************************************************/
boolean TestBswM_WdgM_RequestPartitionReset(
  App_DataValidateType LucDataValidate, ApplicationType LddApplication)
{
  ApplicationType LddExpApplication;
  uint8 LucIndex;
  boolean LblStepResult;

  LddExpApplication = LddApplication;
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Application */
      if((BswM_GucPartitionResetCount == 0x01) &&
        (BswM_GaaApplication[0] == LddExpApplication))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      BswM_GucPartitionResetCount = 0;
      BswM_GucPartitionResetCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < BswM_GucPartitionResetCount; LucIndex++)
      {
        /* Validate Application */
        if((BswM_GaaApplication[LucIndex] == LddExpApplication))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = BswM_GucPartitionResetCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      BswM_GucCurrentStateCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(BswM_GucCurrentStateCheckCount == BswM_GucPartitionResetCount)
      {
        BswM_GucPartitionResetCount = 0;
        BswM_GucPartitionResetCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestBswM_CanSM_CurrentState() */
#endif

#ifdef SD_MODULE_ACTIVE
/*******************************************************************************
**                     BswM_SD_CurrentState()                              **
*******************************************************************************/
void BswM_SD_CurrentState(uint16 ServiceInstanceID, SD_StateType State)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual Network and CurrentState into Global variables */
  BswM_GaaSDService[BswM_GucSDCurrentStateCount] = ServiceInstanceID;
  BswM_GaaSDCurrentState[BswM_GucSDCurrentStateCount] = State;

  /* Increment count variable to handle multiple invocations */
  if(BswM_GucSDCurrentStateCount < BSWM_ARRAY_SIZE)
  {
    BswM_GucSDCurrentStateCount++;
  }
  #endif /* TYPICAL_CONFIG */
}

/*******************************************************************************
**                       TestBswM_SD_CurrentState()                        **
*******************************************************************************/
boolean TestBswM_SD_CurrentState(App_DataValidateType LucDataValidate,
  uint16 LusServiceInstanceID,
  SD_StateType LddExpCurrentState)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Network and CurrentState */
      if((BswM_GucSDCurrentStateCount == 0x01) &&
        (BswM_GaaSDService[0] == LusServiceInstanceID) &&
        (BswM_GaaSDCurrentState[0] == LddExpCurrentState))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      BswM_GucSDCurrentStateCount = 0;
      BswM_GucSDCurrentStateCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < BswM_GucSDCurrentStateCount; LucIndex++)
      {
        /* Validate Service and CurrentState */
        if((BswM_GaaSDService[LucIndex] == LusServiceInstanceID) &&
          (BswM_GaaSDCurrentState[LucIndex] == LddExpCurrentState))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = BswM_GucSDCurrentStateCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      BswM_GucSDCurrentStateCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(BswM_GucSDCurrentStateCheckCount == BswM_GucSDCurrentStateCount)
      {
        BswM_GucSDCurrentStateCount = 0;
        BswM_GucSDCurrentStateCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(BswM_GucSDCurrentStateCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestBswM_SD_CurrentState() */
#endif

#ifdef FRSM_MODULE_ACTIVE
/*******************************************************************************
**                       BswM_FrSM_CurrentState()                          **
*******************************************************************************/
void BswM_FrSM_CurrentState(NetworkHandleType Network, FrSM_BswM_StateType CurrentState)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual CtrlId into Global variable */
  BswM_GaaCurrStateNtwrk[BswM_GucCurrStateCount] = Network;
  BswM_GaaCurrStateType[BswM_GucCurrStateCount] = CurrentState;
  if(BswM_GucCurrStateCount != BSWM_ARRAY_SIZE)
  {
    BswM_GucCurrStateCount++;
  }
  #endif
} /* End BswM_FrSM_CurrentState() */

/*******************************************************************************
**                       TestBswM_FrSM_CurrentState()                          **
*******************************************************************************/
boolean TestBswM_FrSM_CurrentState(App_DataValidateType LucDataValidate,
  NetworkHandleType ExpNetwork, FrSM_BswM_StateType ExpCurrentState)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((BswM_GucCurrStateCount == 0x01) &&
        (ExpNetwork == BswM_GaaCurrStateNtwrk[0]) &&
        (ExpCurrentState == BswM_GaaCurrStateType[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      BswM_GucCurrStateCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(BswM_GucCurrStateCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < BswM_GucCurrStateCount; LucIndex++)
      {
        /* Validate the Controller Id */
        if((ExpNetwork ==
          BswM_GaaCurrStateNtwrk[BswM_GucCurrStateCheckCount]) &&
        (ExpCurrentState == BswM_GaaCurrStateType[BswM_GucCurrStateCheckCount]))
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = BswM_GucCurrStateCount;
        } /* End if(ExpNetwork == BswM_GaaCurrStateNtwrk[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < BswM_GucCurrStateCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      BswM_GucCurrStateCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(BswM_GucCurrStateCheckCount == BswM_GucCurrStateCount)
      {
        BswM_GucCurrStateCount = 0;
        BswM_GucCurrStateCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    /*
     * Case to handle API invocation with multiple occurance (with sequnce)
     * and to validate parameters of the API with what it has been invoked
     */
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((BswM_GucCurrStateCheckCount <= BswM_GucCurrStateCount) &&
        (ExpNetwork ==
         BswM_GaaCurrStateNtwrk[BswM_GucCurrStateCheckCount]) &&
        (ExpCurrentState == BswM_GaaCurrStateType[BswM_GucCurrStateCheckCount]))
      {
        LblRetValue = STEP_PASSED;
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      BswM_GucCurrStateCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(BswM_GucCurrStateCheckCount == BswM_GucCurrStateCount)
      {
        BswM_GucCurrStateCount = 0;
        BswM_GucCurrStateCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < BswM_GucCurrStateCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if((ExpNetwork == BswM_GaaCurrStateNtwrk[LucIndex]) &&
        (ExpCurrentState == BswM_GaaCurrStateType[LucIndex]))
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestBswM_FrSM_CurrentState() */
#endif
#ifdef NVM_MODULE_ACTIVE
/*******************************************************************************
**                            BswM_NvM_CurrentJobMode()                       **
*******************************************************************************/
void BswM_NvM_CurrentJobMode
  (uint8 ServiceId, NvM_RequestResultType CurrentJobMode)
{
  /* Load actual ServiceId and JobResult into Global variables */
  BswM_GucServiceId = ServiceId;
  BswM_GddCurrentJobMode = CurrentJobMode;
  BswM_GucMultiBlkCbkCount++;
}

/*******************************************************************************
**                        Test_BswM_NvM_CurrentJobMode()                      **
*******************************************************************************/
boolean Test_BswM_NvM_CurrentJobMode(App_DataValidateType LucDataValidate, 
  uint8 LucServiceId, NvM_RequestResultType LddCurrentJobMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle callback invocation with single occurance and to validate
     * parameters of the callback with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ControllerId and PduModeRequest */
      if((BswM_GucMultiBlkCbkCount == 0x01) &&
        (BswM_GucServiceId == LucServiceId) &&
        (BswM_GddCurrentJobMode == LddCurrentJobMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      BswM_GucMultiBlkCbkCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(BswM_GucMultiBlkCbkCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
}

/*******************************************************************************
**                            BswM_NvM_CurrentBlockMode()                     **
*******************************************************************************/
void BswM_NvM_CurrentBlockMode
  (NvM_BlockIdType Block, NvM_RequestResultType CurrentBlockMode)
{
  BswM_GddBlockId[BswM_GucSingleBlkCbkCount] = Block;
  BswM_GddCurrentBlockMode[BswM_GucSingleBlkCbkCount] = CurrentBlockMode;

  /* Increment count variable to handle multiple invocations */
  if(BswM_GucSingleBlkCbkCount < BSWM_ARRAY_SIZE)
  {
    BswM_GucSingleBlkCbkCount++;
  }
}

/*******************************************************************************
**                            Test_BswM_NvM_CurrentBlockMode()                **
*******************************************************************************/
boolean Test_BswM_NvM_CurrentBlockMode(App_DataValidateType LucDataValidate,
  NvM_BlockIdType LddBlock, NvM_RequestResultType LddCurrentBlockMode)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle callback invocation with single occurance and to validate
     * parameters of the callback with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ControllerId and PduModeRequest */
      if((BswM_GucSingleBlkCbkCount == 0x01) &&
        (BswM_GddBlockId[0] == LddBlock) &&
        (BswM_GddCurrentBlockMode[0] == LddCurrentBlockMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      BswM_GucSingleBlkCbkCount = 0;
      BswM_GucSingleBlkCbkCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < BswM_GucSingleBlkCbkCount; LucIndex++)
      {
        /* Validate ControllerId and PduModeRequest */
        if((BswM_GddBlockId[LucIndex] == LddBlock) &&
          (BswM_GddCurrentBlockMode[LucIndex] == LddCurrentBlockMode))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = BswM_GucSingleBlkCbkCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      BswM_GucSingleBlkCbkCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(BswM_GucSingleBlkCbkCheckCount == BswM_GucSingleBlkCbkCount)
      {
        BswM_GucSingleBlkCbkCount = 0;
        BswM_GucSingleBlkCbkCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(BswM_GucSingleBlkCbkCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
}
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

