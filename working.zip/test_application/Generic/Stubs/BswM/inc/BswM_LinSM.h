/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: BswM_LinSM.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BswM Stub                                             **
**                                                                            **
**  PURPOSE   : Declaration of BswM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

#ifndef BSWM_LINSM_H
#define BSWM_LINSM_H


/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "LinIf.h"
#include "LinSM.h"
#include "ComStack_Types.h"
#include "TC_Generic.h"
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern boolean TestBswM_LinSM_CurrentState(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpNetwork, LinSM_ModeType LddExpCurrentState);
  
extern void BswM_LinSM_CurrentState(NetworkHandleType Network, 
  LinSM_ModeType CurrentState);
  
extern void BswM_LinSM_CurrentSchedule(NetworkHandleType Network, 
  LinIf_SchHandleType CurrentSchedule);
  
extern boolean TestBswM_LinSM_CurrentSchedule(App_DataValidateType 
  LucDataValidate,
  NetworkHandleType LddExpNetwork, LinIf_SchHandleType LddExpCurrentSchedule);

#endif /* BSWM_CANSM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
