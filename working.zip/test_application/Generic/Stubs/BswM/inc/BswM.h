/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: BswM.h                                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BswM Stub                                             **
**                                                                            **
**  PURPOSE   : Declaration of BswM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

#ifndef BSWM_H
#define BSWM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"
#include "Std_Types.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define BSWM_AR_RELEASE_MAJOR_VERSION    4
#define BSWM_AR_RELEASE_MINOR_VERSION    0
#define BSWM_AR_RELEASE_REVISION_VERSION 3

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define BSWM_ARRAY_SIZE                  50

#define BswMConfig0 &BswM_GaaConfig[0]
#define BswMConfig1 &BswM_GaaConfig[1]
/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
typedef struct STag_BswM_ConfigType
{
  uint8 dummy;
}BswM_ConfigType;

extern const BswM_ConfigType BswM_GaaConfig[];
extern uint8 BswM_GucRequestedModeCount;
extern uint8 BswM_GucConfigData;
extern boolean BswM_GblDeinit;

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void BswM_Init(const BswM_ConfigType *ConfigPtr);
extern void BswM_Deinit(void);

extern boolean TestBswM_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, uint8 LucData);
extern boolean TestBswM_Deinit(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);

extern void TestBswM_DefaultBehavior(void);

#endif /* BSWM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
