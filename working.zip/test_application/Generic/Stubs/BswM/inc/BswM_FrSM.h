/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: BswM_FrSM.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Flexray State Manager                                 **
**                                                                            **
**  PURPOSE   : Declaration of BswM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef BSWM_FRSM_H
#define BSWM_FRSM_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "FrSM.h"
#include "ComStack_Types.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void BswM_FrSM_CurrentState(NetworkHandleType Network,
  FrSM_BswM_StateType CurrentState);
  
extern boolean TestBswM_FrSM_CurrentState(App_DataValidateType LucDataValidate,
  NetworkHandleType ExpNetwork, FrSM_BswM_StateType ExpCurrentState);

#endif /* end of BSWM_FRSM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

