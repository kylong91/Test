/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Cdd.c                                                         **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Cdd stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Cdd Stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#ifdef CANIF_MODULE_ACTIVE
#include "Cdd_CanIf.h"
#else

#ifndef FRSM_MODULE_ACTIVE
#include "Cdd.h"
#else
#include "Cdd_Cbk.h"
#endif

#ifdef LINIF_MODULE_ACTIVE
#include "Cdd_LinIf.h"
#endif/* #ifdef LINIF_MODULE_ACTIVE */

#ifdef RAMTST_MODULE_ACTIVE
#include "Cdd_RamTst.h"
#endif

#endif/* #ifdef CANIF_MODULE_ACTIVE */
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#ifdef FRIF_MODULE_ACTIVE
uint8 Cdd_GucTxPduId;
uint8 GucFrIfTriggerTransmit;
uint8 Cdd_GucTxConfirmCount;
PduIdType GucRxPduId;
uint8 GucRxConfirmationcount;
#endif

#ifdef FRSM_MODULE_ACTIVE
uint8 Cdd_GucSyncLossCount;
NetworkHandleType Cdd_GddSyncLossNw[CDDCBK_ARRAY_SIZE];
boolean Cdd_GblSyncLossErrorStatus[CDDCBK_ARRAY_SIZE];
#endif

#ifdef CANIF_MODULE_ACTIVE
uint8 Cdd_GucTxConfirmCount;
uint8 Cdd_GucTrcvModeIndCnt;
uint8 Cdd_GucConfirmPnCount;
uint8 Cdd_GucClrTrcvWufFlagIndCount;
uint8 Cdd_GucChkTrcvWakeFlagIndCount;
uint8 Cdd_GucTxConfirmCount1;
uint8 Cdd_GucTxConfirmCount2;
uint8 Cdd_GucTxConfirmCount3;
uint8 Cdd_GucTxConfirmCount4;
uint8 Cdd_GucTxConfirmCount5;
uint8 Cdd_GucTxConfirmCount6;
uint8 Cdd_GucTxConfirmCheckCount;
uint8 Cdd_GucTxConfirmCheckCount1;
uint8 Cdd_GucTxConfirmCheckCount2;
uint8 Cdd_GucTxConfirmCheckCount3;
uint8 Cdd_GucTxConfirmCheckCount4;
uint8 Cdd_GucTxConfirmCheckCount5;
uint8 Cdd_GucTxConfirmCheckCount6;
PduIdType Cdd_GucTxPduId;
PduIdType Cdd_GucTxPduId1;
PduIdType Cdd_GucTxPduId2;
PduIdType Cdd_GucTxPduId3;
PduIdType Cdd_GucTxPduId4;
PduIdType Cdd_GucTxPduId5;
PduIdType Cdd_GucTxPduId6;

uint8 Cdd_GucRxIndiCount;
uint8 Cdd_GucRxIndSduLength;
uint8 Cdd_GaaRxIndSduData[CDD_DATA_LENGTH];
PduIdType Cdd_GucRxPduId;
PduInfoType *GstPduInfoPtr;

uint8 Cdd_GucCntrlBusOffCount;
uint8 Cdd_GucCntrlBusOffCheckCount;
uint8 Cdd_GucCnrtlBusControllerId;

uint8 Cdd_GucSetWakEventCount;
uint8 Cdd_GucSetWakEventCheckCount;
EcuM_WakeupSourceType Cdd_Gddsources;

uint8 Cdd_GucValidWakupEvCount;
uint8 Cdd_GucValidWakupEvCheckCount;

uint8 Cdd_GucCntrlModeIndiCount;
uint8 Cdd_GucModeIndiControllerId;
uint8 Cdd_GucCntrlModeIndiCheckCount;
CanIf_ControllerModeType Cdd_GddControllerMode;

uint8 Cdd_GucTrcvModeIndiCount;
uint8 Cdd_GucTrcvModeIndiCheckCount;
uint8 Cdd_GucTransceiverId;
CanTrcv_TrcvModeType Cdd_GddTransceiverMode;
uint8 Cdd_GucTrcvId;
#endif

#ifdef LINIF_MODULE_ACTIVE
/* Variables used for LinIf module  */
PduIdType Cdd_GucLinIfTxConfPduId[CDD_ARRAY_SIZE];
uint8 Cdd_GucLinIfTxConfCount;
uint8 Cdd_GucLinIfTxConfCheckCount;

PduIdType Cdd_GaaLinIfRxIndPduId[CDD_ARRAY_SIZE];
uint32 Cdd_GaaLinIfRxIndSduLength[CDD_ARRAY_SIZE];
uint8 Cdd_GaaLinIfRxIndSduData[CDD_ARRAY_SIZE][CDD_DATA_LENGTH];
uint8 Cdd_GucLinIfRxIndCount;
uint8 Cdd_GucLinIfRxIndCheckCount;

PduIdType Cdd_GaaLinIfTrigTxPduId[CDD_ARRAY_SIZE];
uint8 Cdd_GucLinIfTrigTxCount;
uint8 Cdd_GucPduRLinIfTrigTxCheckCount;
PduIdType Cdd_GaaLinIfTrigSetTxPduId[CDD_ARRAY_SIZE];
uint8 Cdd_GaaLinIfTrigSetTxSduLength[CDD_ARRAY_SIZE];
uint8 Cdd_GaaLinIfTrigSetTxSduData[CDD_ARRAY_SIZE][CDD_DATA_LENGTH];

NetworkHandleType Cdd_GddSchReqConfNw[CDD_ARRAY_SIZE];
NetworkHandleType Cdd_GddWakeUpConfNw[CDD_ARRAY_SIZE];
NetworkHandleType Cdd_GddGotoSleepConfNw[CDD_ARRAY_SIZE];
LinIf_SchHandleType Cdd_GddSchReqConfSchedule[CDD_ARRAY_SIZE];
boolean Cdd_GblWakeUpConfSuccs[CDD_ARRAY_SIZE];
boolean Cdd_GblGotoSleepConfSuccs[CDD_ARRAY_SIZE];
uint8 Cdd_GucSchReqConfCount;
uint8 Cdd_GucWakeUpConfCount;
uint8 Cdd_GucGotoSleepConfCount;
uint8 Cdd_GucSchReqConfCheckCount;
uint8 Cdd_GucWakeUpConfCheckCount;
uint8 Cdd_GucGotoSleepConfCheckCount;
/* Variables used for LinIf module  */
#endif
#ifdef RAMTST_MODULE_ACTIVE
uint8 Cdd_GucRamTstErrorNotif;
uint8 Cdd_GucRamTstCompleteNotif;
#endif
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
#ifdef RAMTST_MODULE_ACTIVE
/*******************************************************************************
**                     RamTst_ErrorNotification()                              **
*******************************************************************************/
void RamTst_ErrorNotification(void)
{
  Cdd_GucRamTstErrorNotif++;
} /* End of RamTst_ErrorNotification() */

boolean TestRamTst_ErrorNotification(App_DataValidateType LucDataValidate)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Cdd_GucRamTstErrorNotif == 0x01)
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucRamTstErrorNotif = 0;      
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucRamTstErrorNotif == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}

/*******************************************************************************
**                     RamTst_TestCompletedNotification()                     **
*******************************************************************************/
void RamTst_TestCompletedNotification(void)
{
  Cdd_GucRamTstCompleteNotif++;
} /* End of RamTst_TestCompletedNotification() */

boolean TestRamTst_TestCompletedNotification(App_DataValidateType LucDataValidate)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Cdd_GucRamTstCompleteNotif == 0x01)
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucRamTstCompleteNotif = 0;      
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucRamTstCompleteNotif == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}

#endif
#ifdef FRIF_MODULE_ACTIVE
/*******************************************************************************
**                     Cdd_FrIfTxConfirmation()                              **
*******************************************************************************/
void Cdd_FrIfTxConfirmation(PduIdType TxPduId)
{
  /* Load actual TxPduId into Global variables */
  Cdd_GucTxPduId = TxPduId;
  Cdd_GucTxConfirmCount++;
} /* End of Cdd_FrIfTxConfirmation() */

boolean TestCdd_FrIfTxConfirmation(App_DataValidateType LucDataValidate,
PduIdType TxPduId)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Cdd_GucTxConfirmCount == 0x01) && 
        (Cdd_GucTxPduId == TxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucTxConfirmCount = 0;      
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucTxConfirmCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}
/*******************************************************************************
**                       Cdd_FrIfRxIndication()                               **
*******************************************************************************/
void Cdd_FrIfRxIndication(PduIdType RxPduId, PduInfoType* PduInfoPtr)
{
  UNUSED(PduInfoPtr);
  GucRxPduId = RxPduId;
  GucRxConfirmationcount++;  
} /* End Cdd_FrIfRxIndication() */
/*******************************************************************************
**                       TestCdd_FrIfRxIndication()                           **
*******************************************************************************/
boolean TestCdd_FrIfRxIndication(App_DataValidateType LucDataValidate,
PduIdType RxPduId)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((GucRxConfirmationcount == 0x01) && 
        (GucRxPduId == RxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      GucRxConfirmationcount = 0;      
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(GucRxConfirmationcount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}
/*******************************************************************************
**                     Cdd_FrIfTriggerTransmit()                              **
*******************************************************************************/
Std_ReturnType Cdd_FrIfTriggerTransmit(PduIdType TxPduId,
              PduInfoType* PduInfoPtr)
  {
    PduInfoType LddPduInfoPtr;
    LddPduInfoPtr.SduLength = PduInfoPtr->SduLength;
    Cdd_GucTxPduId = TxPduId;
    GucFrIfTriggerTransmit++;
    return(E_OK);
  }

boolean TestCdd_FrIfTriggerTransmit(App_DataValidateType LucDataValidate,
PduIdType TxPduId)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((GucFrIfTriggerTransmit == 0x01) && 
        (Cdd_GucTxPduId == TxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      GucFrIfTriggerTransmit = 0;      
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(GucFrIfTriggerTransmit == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}
#endif

/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
#ifdef FRSM_MODULE_ACTIVE
/*******************************************************************************
**                       Cdd_SyncLoss()                                        **
*******************************************************************************/
void Cdd_SyncLoss(NetworkHandleType NetworkHandle, boolean SyncLossErrorStatus)
{
  #ifndef TYPICAL_CONFIG
  Cdd_GddSyncLossNw[Cdd_GucSyncLossCount] = NetworkHandle;
  Cdd_GblSyncLossErrorStatus[Cdd_GucSyncLossCount] = SyncLossErrorStatus;
  /* Increment count variable to handle multiple invocations */
  if(Cdd_GucSyncLossCount != CDDCBK_ARRAY_SIZE)
  {    
    Cdd_GucSyncLossCount++;
  }
  #endif
} /* End Cdd_SynLoss() */
/*******************************************************************************
**                       TestCdd_SynLoss()                    **
*******************************************************************************/
boolean TestCdd_SyncLoss(App_DataValidateType 
  LucDataValidate, NetworkHandleType ExpNetworkHandle, boolean ExpSyncLossErrorStatus)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Cdd_GucSyncLossCount == 0x01) && 
        (ExpNetworkHandle == Cdd_GddSyncLossNw[0]) && 
        (ExpSyncLossErrorStatus == Cdd_GblSyncLossErrorStatus[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucSyncLossCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucSyncLossCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCdd_SynLoss() */
#endif
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
#ifdef CANIF_MODULE_ACTIVE

/*******************************************************************************
**                     TestCdd_TransceiverModeIndication()                    **
*******************************************************************************/
boolean TestCdd_TransceiverModeIndication(App_DataValidateType LddDataValidate,
uint8 TransceiverId, CanTrcv_TrcvModeType TransceiverMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  TransceiverMode = TransceiverMode;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TxPduId */
      if((Cdd_GucTrcvModeIndCnt == 0x01) && (Cdd_GucTrcvId == TransceiverId))

      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucTrcvModeIndCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucTrcvModeIndCnt == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCdd_ClearTrcvWufFlagIndication() */

/*******************************************************************************
**                     Cdd_CheckTrcvWakeFlagIndication()                      **
*******************************************************************************/
void Cdd_CheckTrcvWakeFlagIndication (uint8 TransceiverId)
{
  /* Load actual TxPduId into Global variables */
  Cdd_GucTrcvId = TransceiverId;
  Cdd_GucChkTrcvWakeFlagIndCount++;
} /* End of Cdd_CheckTrcvWakeFlagIndication() */

/*******************************************************************************
**                     TestCdd_CheckTrcvWakeFlagIndication()                  **
*******************************************************************************/
boolean TestCdd_CheckTrcvWakeFlagIndication(App_DataValidateType LddDataValidate,
uint8 TransceiverId)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TxPduId */
      if((Cdd_GucChkTrcvWakeFlagIndCount == 0x01) && (Cdd_GucTrcvId == TransceiverId))

      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucChkTrcvWakeFlagIndCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucChkTrcvWakeFlagIndCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCdd_ClearTrcvWufFlagIndication() */

/*******************************************************************************
**                     Cdd_ClearTrcvWufFlagIndication()                       **
*******************************************************************************/
void Cdd_ClearTrcvWufFlagIndication(uint8 TransceiverId)
{
  /* Load actual TxPduId into Global variables */
  Cdd_GucTrcvId = TransceiverId;
  Cdd_GucClrTrcvWufFlagIndCount++;
} /* End of Cdd_ClearTrcvWufFlagIndication() */

/*******************************************************************************
**                     Cdd_ClearTrcvWufFlagIndication()                        **
*******************************************************************************/
boolean TestCdd_ClearTrcvWufFlagIndication(App_DataValidateType LddDataValidate,
uint8 TransceiverId)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TxPduId */
      if((Cdd_GucClrTrcvWufFlagIndCount == 0x01) && (Cdd_GucTrcvId == TransceiverId))

      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucClrTrcvWufFlagIndCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucClrTrcvWufFlagIndCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCdd_ClearTrcvWufFlagIndication() */

/*******************************************************************************
**                     Cdd_ConfirmPnAvailability()                            **
*******************************************************************************/
void Cdd_ConfirmPnAvailability(uint8 TransceiverId)
{
  /* Load actual TxPduId into Global variables */
  Cdd_GucTrcvId = TransceiverId;
  Cdd_GucConfirmPnCount++;
} /* End of Cdd_CanIfTxConfirmation() */

/*******************************************************************************
**                     TestCdd_ConfirmPnAvailability()                        **
*******************************************************************************/
boolean TestCdd_ConfirmPnAvailability(App_DataValidateType LddDataValidate,
uint8 TransceiverId)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TxPduId */
      if((Cdd_GucConfirmPnCount == 0x01) && (Cdd_GucTrcvId == TransceiverId))

      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucConfirmPnCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucConfirmPnCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCdd_ConfirmPnAvailability() */

/*******************************************************************************
**                     Cdd_CanIfTxConfirmation()                              **
*******************************************************************************/
void Cdd_TxConfirmation(PduIdType TxPduId)
{
  /* Load actual TxPduId into Global variables */
  Cdd_GucTxPduId = TxPduId;
  Cdd_GucTxConfirmCount++;
} /* End of Cdd_CanIfTxConfirmation() */
/*******************************************************************************
**                     Cdd_CanIfTxConfirmation()                              **
*******************************************************************************/
void Cdd_CanIfTxConfirmation(PduIdType TxPduId)
{
  /* Load actual TxPduId into Global variables */
  Cdd_GucTxPduId = TxPduId;
  Cdd_GucTxConfirmCount++;
} /* End of Cdd_CanIfTxConfirmation() */

/*******************************************************************************
**                     TestCdd_CanIfTxConfirmation()                          **
*******************************************************************************/
boolean TestCdd_CanIfTxConfirmation(App_DataValidateType LddDataValidate,
PduIdType ExpTxPduId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TxPduId */
      if((Cdd_GucTxConfirmCount == 0x01) && (Cdd_GucTxPduId == ExpTxPduId))

      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucTxConfirmCount = 0;
      Cdd_GucTxConfirmCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Cdd_GucTxConfirmCount; LucIndex++)
      {
        /* Validate TxPduId */
        if(Cdd_GucTxPduId == ExpTxPduId)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Cdd_GucTxConfirmCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Cdd_GucTxConfirmCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Cdd_GucTxConfirmCheckCount == Cdd_GucTxConfirmCount)
      {
        Cdd_GucTxConfirmCount = 0;
        Cdd_GucTxConfirmCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucTxConfirmCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCdd_CanIfTxConfirmation() */
/*******************************************************************************
**                     Cdd_CanIfTxConfirmation1()                             **
*******************************************************************************/
void Cdd_CanIfTxConfirmation1(PduIdType TxPduId)
{
  /* Load actual TxPduId1 into Global variables */
  Cdd_GucTxPduId1 = TxPduId;
  Cdd_GucTxConfirmCount1++;
} /* End of Cdd_CanIfTxConfirmation1() */
/*******************************************************************************
**                     TestCdd_CanIfTxConfirmation1()                         **
*******************************************************************************/
boolean TestCdd_CanIfTxConfirmation1(App_DataValidateType LddDataValidate,
PduIdType ExpTxPduId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TxPduId */
      if((Cdd_GucTxConfirmCount1 == 0x01) && (Cdd_GucTxPduId1 == ExpTxPduId))

      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucTxConfirmCount1 = 0;
      Cdd_GucTxConfirmCheckCount1 = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Cdd_GucTxConfirmCount1; LucIndex++)
      {
        /* Validate TxPduId */
        if(Cdd_GucTxPduId1 == ExpTxPduId)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Cdd_GucTxConfirmCount1;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Cdd_GucTxConfirmCheckCount1++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Cdd_GucTxConfirmCheckCount1 == Cdd_GucTxConfirmCount1)
      {
        Cdd_GucTxConfirmCount1 = 0;
        Cdd_GucTxConfirmCheckCount1 = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucTxConfirmCount1 == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCdd_CanIfTxConfirmation1() */

/*******************************************************************************
**                     Cdd_CanIfTxConfirmation2()                             **
*******************************************************************************/
void Cdd_CanIfTxConfirmation2(PduIdType TxPduId)
{
  /* Load actual TxPduId2 into Global variables */
  Cdd_GucTxPduId2 = TxPduId;
  Cdd_GucTxConfirmCount2++;
} /* End of Cdd_CanIfTxConfirmation2() */

/*******************************************************************************
**                     TestCdd_CanIfTxConfirmation2()                         **
*******************************************************************************/
boolean TestCdd_CanIfTxConfirmation2(App_DataValidateType LddDataValidate,
PduIdType ExpTxPduId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TxPduId */
      if((Cdd_GucTxConfirmCount2 == 0x01) && (Cdd_GucTxPduId2 == ExpTxPduId))

      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucTxConfirmCount2 = 0;
      Cdd_GucTxConfirmCheckCount2 = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Cdd_GucTxConfirmCount2; LucIndex++)
      {
        /* Validate TxPduId */
        if(Cdd_GucTxPduId2 == ExpTxPduId)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Cdd_GucTxConfirmCount2;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Cdd_GucTxConfirmCheckCount2++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Cdd_GucTxConfirmCheckCount2 == Cdd_GucTxConfirmCount2)
      {
        Cdd_GucTxConfirmCount2 = 0;
        Cdd_GucTxConfirmCheckCount2 = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucTxConfirmCount2 == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCdd_CanIfTxConfirmation2() */
/*******************************************************************************
**                     Cdd_CanIfTxConfirmation3()                             **
*******************************************************************************/
void Cdd_CanIfTxConfirmation3(PduIdType TxPduId)
{
  /* Load actual TxPduId3 into Global variables */
  Cdd_GucTxPduId3 = TxPduId;
  Cdd_GucTxConfirmCount3++;
} /* End of Cdd_CanIfTxConfirmation3() */

/*******************************************************************************
**                     TestCdd_CanIfTxConfirmation3()                         **
*******************************************************************************/
boolean TestCdd_CanIfTxConfirmation3(App_DataValidateType LddDataValidate,
PduIdType ExpTxPduId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TxPduId */
      if((Cdd_GucTxConfirmCount3 == 0x01) && (Cdd_GucTxPduId3 == ExpTxPduId))

      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucTxConfirmCount3 = 0;
      Cdd_GucTxConfirmCheckCount3 = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Cdd_GucTxConfirmCount3; LucIndex++)
      {
        /* Validate TxPduId */
        if(Cdd_GucTxPduId3 == ExpTxPduId)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Cdd_GucTxConfirmCount3;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Cdd_GucTxConfirmCheckCount3++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Cdd_GucTxConfirmCheckCount3 == Cdd_GucTxConfirmCount3)
      {
        Cdd_GucTxConfirmCount3 = 0;
        Cdd_GucTxConfirmCheckCount3 = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucTxConfirmCount3 == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCdd_CanIfTxConfirmation3() */

/*******************************************************************************
**                     Cdd_CanIfTxConfirmation4()                             **
*******************************************************************************/
void Cdd_CanIfTxConfirmation4(PduIdType TxPduId)
{
  /* Load actual TxPduId4 into Global variables */
  Cdd_GucTxPduId4 = TxPduId;
  Cdd_GucTxConfirmCount4++;
} /* End of Cdd_CanIfTxConfirmation4() */

/*******************************************************************************
**                     TestCdd_CanIfTxConfirmation4()                          **
*******************************************************************************/
boolean TestCdd_CanIfTxConfirmation4(App_DataValidateType LddDataValidate,
PduIdType ExpTxPduId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TxPduId */
      if((Cdd_GucTxConfirmCount4 == 0x01) && (Cdd_GucTxPduId4 == ExpTxPduId))

      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucTxConfirmCount4 = 0;
      Cdd_GucTxConfirmCheckCount4 = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Cdd_GucTxConfirmCount4; LucIndex++)
      {
        /* Validate TxPduId */
        if(Cdd_GucTxPduId4 == ExpTxPduId)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Cdd_GucTxConfirmCount4;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Cdd_GucTxConfirmCheckCount4++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Cdd_GucTxConfirmCheckCount4 == Cdd_GucTxConfirmCount4)
      {
        Cdd_GucTxConfirmCount4 = 0;
        Cdd_GucTxConfirmCheckCount4 = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucTxConfirmCount4 == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCdd_CanIfTxConfirmation4() */

/*******************************************************************************
**                     Cdd_CanIfTxConfirmation5()                             **
*******************************************************************************/
void Cdd_CanIfTxConfirmation5(PduIdType TxPduId)
{
  /* Load actual TxPduId5 into Global variables */
  Cdd_GucTxPduId5 = TxPduId;
  Cdd_GucTxConfirmCount5++;
} /* End of Cdd_CanIfTxConfirmation5() */

/*******************************************************************************
**                     TestCdd_CanIfTxConfirmation5()                         **
*******************************************************************************/
boolean TestCdd_CanIfTxConfirmation5(App_DataValidateType LddDataValidate,
PduIdType ExpTxPduId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TxPduId */
      if((Cdd_GucTxConfirmCount5 == 0x01) && (Cdd_GucTxPduId5 == ExpTxPduId))

      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucTxConfirmCount5 = 0;
      Cdd_GucTxConfirmCheckCount5 = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Cdd_GucTxConfirmCount5; LucIndex++)
      {
        /* Validate TxPduId */
        if(Cdd_GucTxPduId5 == ExpTxPduId)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Cdd_GucTxConfirmCount5;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Cdd_GucTxConfirmCheckCount5++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Cdd_GucTxConfirmCheckCount5 == Cdd_GucTxConfirmCount5)
      {
        Cdd_GucTxConfirmCount5 = 0;
        Cdd_GucTxConfirmCheckCount5 = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucTxConfirmCount5 == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCdd_CanIfTxConfirmation5() */

/*******************************************************************************
**                     Cdd_CanIfTxConfirmation6()                             **
*******************************************************************************/
void Cdd_CanIfTxConfirmation6(PduIdType TxPduId)
{
  /* Load actual TxPduId6 into Global variables */
  Cdd_GucTxPduId6 = TxPduId;
  Cdd_GucTxConfirmCount6++;
} /* End of Cdd_CanIfTxConfirmation6() */

/*******************************************************************************
**                     TestCdd_CanIfTxConfirmation6()                          **
*******************************************************************************/
boolean TestCdd_CanIfTxConfirmation6(App_DataValidateType LddDataValidate,
PduIdType ExpTxPduId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TxPduId */
      if((Cdd_GucTxConfirmCount6 == 0x01) && (Cdd_GucTxPduId6 == ExpTxPduId))

      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucTxConfirmCount6 = 0;
      Cdd_GucTxConfirmCheckCount6 = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Cdd_GucTxConfirmCount6; LucIndex++)
      {
        /* Validate TxPduId */
        if(Cdd_GucTxPduId6 == ExpTxPduId)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Cdd_GucTxConfirmCount6;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Cdd_GucTxConfirmCheckCount6++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Cdd_GucTxConfirmCheckCount6 == Cdd_GucTxConfirmCount6)
      {
        Cdd_GucTxConfirmCount6 = 0;
        Cdd_GucTxConfirmCheckCount6 = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucTxConfirmCount6 == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCdd_CanIfTxConfirmation6() */

/*******************************************************************************
**                       Cdd_CanIfRxIndication()                              **
*******************************************************************************/
void Cdd_CanIfRxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr)
{
  uint8 LucDataIndex;
  uint8* LpSduDataPtr;

  /* Load actual TxPduId, Sdulength and SduDataPt into Global variables */
  Cdd_GucRxPduId = RxPduId;
  Cdd_GucRxIndiCount++;

  Cdd_GucRxIndSduLength = PduInfoPtr->SduLength;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;

  for(LucDataIndex = 0x00; LucDataIndex < Cdd_GucRxIndSduLength; LucDataIndex++)
  {
    Cdd_GaaRxIndSduData[LucDataIndex] = *LpSduDataPtr;
    LpSduDataPtr++;
  }
}  /* End of Cdd_CanIfRxIndication() */

/*******************************************************************************
**                   TestCdd_CanIfRxIndication()                              **
*******************************************************************************/
boolean TestCdd_CanIfRxIndication(App_DataValidateType LddDataValidate,
PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType LstActPduInfo;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Cdd_GucRxIndiCount == 0x01) && (Cdd_GucRxPduId == ExpRxPduId))
      {
        LstActPduInfo.SduLength = Cdd_GucRxIndSduLength;
        LstActPduInfo.SduDataPtr = &Cdd_GaaRxIndSduData[0];

        /* Validate SduLength and Data */
        if(Cdd_TestValidateData((PduInfoType *)ExpPduInfoPtr,
          &LstActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucRxIndiCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucRxIndiCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
       default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End of TestCdd_CanIfRxIndication() */

/*******************************************************************************
**                     Cdd_CanIfControllerBusOff()                            **
*******************************************************************************/
void Cdd_CanIfControllerBusOff(uint8 ControllerId)
{
 /* Load actual ControllerId into Global variables */
  Cdd_GucCnrtlBusControllerId = ControllerId;
  Cdd_GucCntrlBusOffCount++;
}
/* End of Cdd_CanIfControllerBusOff() */

/*******************************************************************************
**                     TestCdd_CanIfControllerBusOff()                        **
*******************************************************************************/
boolean TestCdd_CanIfControllerBusOff(App_DataValidateType LddDataValidate,
uint8 ExpControllerId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ControllerId */
      if((Cdd_GucCntrlBusOffCount == 0x01) &&
        (Cdd_GucCnrtlBusControllerId == ExpControllerId))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucCntrlBusOffCount = 0;
      Cdd_GucCntrlBusOffCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Cdd_GucCntrlBusOffCount; LucIndex++)
      {
        /* Validate ControllerId */
        if(Cdd_GucCnrtlBusControllerId == ExpControllerId)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Cdd_GucCntrlBusOffCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Cdd_GucCntrlBusOffCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Cdd_GucCntrlBusOffCheckCount == Cdd_GucCntrlBusOffCount)
      {
        Cdd_GucCntrlBusOffCount = 0;
        Cdd_GucCntrlBusOffCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucCntrlBusOffCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCdd_CanIfControllerBusOff() */

/*******************************************************************************
**                     Cdd_CanIfSetWakeupEvent()                              **
*******************************************************************************/
void Cdd_CanIfSetWakeupEvent(EcuM_WakeupSourceType sources)
{
  /* Load actual sources into Global variables */
  Cdd_Gddsources = sources;
  Cdd_GucSetWakEventCount++;
} /* End of Cdd_CanIfSetWakeupEvent() */

/*******************************************************************************
**                     TestCdd_CanIfSetWakeupEvent()                          **
*******************************************************************************/
boolean TestCdd_CanIfSetWakeupEvent(App_DataValidateType LddDataValidate,
EcuM_WakeupSourceType Expsources)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, sources  */
      if((Cdd_GucSetWakEventCount == 0x01) && (Cdd_Gddsources == Expsources))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucSetWakEventCount = 0;
      Cdd_GucSetWakEventCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Cdd_GucSetWakEventCount; LucIndex++)
      {
        /* Validate  */
        if(Cdd_Gddsources == Expsources)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Cdd_GucSetWakEventCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Cdd_GucSetWakEventCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Cdd_GucSetWakEventCheckCount == Cdd_GucSetWakEventCount)
      {
        Cdd_GucSetWakEventCount = 0;
        Cdd_GucSetWakEventCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucSetWakEventCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCdd_CanIfSetWakeupEvent() */

/*******************************************************************************
**                       Cdd_CanIfValidateWakeupEvent()                       **
*******************************************************************************/
void Cdd_CanIfValidateWakeupEvent(EcuM_WakeupSourceType sources)
{
  /* Load actual sources into Global variables */
  Cdd_Gddsources = sources;
  Cdd_GucValidWakupEvCount++;
} /* End of Cdd_CanIfValidateWakeupEvent() */

/*******************************************************************************
**                   TestCdd_CanIfValidateWakeupEvent()                       **
*******************************************************************************/
boolean TestCdd_CanIfValidateWakeupEvent(App_DataValidateType LddDataValidate,
  EcuM_WakeupSourceType Expsources)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, sources */
      if((Cdd_GucValidWakupEvCount == 0x01) && (Cdd_Gddsources == Expsources))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucValidWakupEvCount = 0;
      Cdd_GucValidWakupEvCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Cdd_GucValidWakupEvCount; LucIndex++)
      {
        /* Validate sources */
        if((Cdd_Gddsources == Expsources))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Cdd_GucValidWakupEvCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Cdd_GucValidWakupEvCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Cdd_GucValidWakupEvCheckCount ==
        Cdd_GucValidWakupEvCount)
      {
        Cdd_GucValidWakupEvCount = 0;
        Cdd_GucValidWakupEvCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucValidWakupEvCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCdd_CanIfValidateWakeupEvent() */

/*******************************************************************************
**                       Cdd_CanIfControllerModeIndication()                  **
*******************************************************************************/
void Cdd_CanIfControllerModeIndication(uint8 ControllerId,
  CanIf_ControllerModeType ControllerMode)
{
  /* Load actual ControllerId and ControllerMode into Global variables */
  Cdd_GucModeIndiControllerId = ControllerId;
  Cdd_GddControllerMode = ControllerMode;
  Cdd_GucCntrlModeIndiCount++;
}  /* End of Cdd_CanIfControllerModeIndication() */

/*******************************************************************************
**                   TestCdd_CanIfControllerModeIndication()                  **
*******************************************************************************/
boolean TestCdd_CanIfControllerModeIndication(App_DataValidateType LddDataValidate,
  uint8 ExpControllerId, CanIf_ControllerModeType ExpControllerMode)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ControllerId and ControllerMode */
      if((Cdd_GucCntrlModeIndiCount == 0x01) &&
        (Cdd_GucModeIndiControllerId == ExpControllerId) &&
        (Cdd_GddControllerMode == ExpControllerMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucCntrlModeIndiCount = 0;
      Cdd_GucCntrlModeIndiCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Cdd_GucCntrlModeIndiCount; LucIndex++)
      {
        /* Validate ControllerId and ControllerMode */
        if((Cdd_GucModeIndiControllerId == ExpControllerId) &&
          (Cdd_GddControllerMode == ExpControllerMode))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Cdd_GucCntrlModeIndiCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Cdd_GucCntrlModeIndiCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Cdd_GucCntrlModeIndiCheckCount == Cdd_GucCntrlModeIndiCount)
      {
        Cdd_GucCntrlModeIndiCount = 0;
        Cdd_GucCntrlModeIndiCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucCntrlModeIndiCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCdd_CanIfControllerModeIndication() */

/*******************************************************************************
**                    Cdd_CanIfTransceiverModeIndication()                           **
*******************************************************************************/
void Cdd_CanIfTransceiverModeIndication(uint8 TransceiverId,
CanTrcv_TrcvModeType TransceiverMode)
{
  /* Load actual TransceiverId and TransceiverMode into Global variables */
  Cdd_GucTransceiverId = TransceiverId;
  Cdd_GddTransceiverMode = TransceiverMode;
  Cdd_GucTrcvModeIndiCount++;
} /* End Cdd_CanIfTransceiverModeIndication()  */

/*******************************************************************************
**                   TestCdd_CanIfTransceiverModeIndication()                        **
*******************************************************************************/
boolean TestCdd_CanIfTransceiverModeIndication(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiverId, CanTrcv_TrcvModeType ExpTransceiverMode)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TransceiverId and TransceiverMode */
      if((Cdd_GucTrcvModeIndiCount == 0x01) &&
        (Cdd_GucTransceiverId == ExpTransceiverId) &&
        (Cdd_GddTransceiverMode == ExpTransceiverMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucTrcvModeIndiCount = 0;
      Cdd_GucTrcvModeIndiCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Cdd_GucTrcvModeIndiCount; LucIndex++)
      {
        /* Validate TransceiverId and TransceiverMode */
        if((Cdd_GucTransceiverId == ExpTransceiverId) &&
          (Cdd_GddTransceiverMode == ExpTransceiverMode))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Cdd_GucTrcvModeIndiCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Cdd_GucTrcvModeIndiCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Cdd_GucTrcvModeIndiCheckCount == Cdd_GucTrcvModeIndiCount)
      {
        Cdd_GucTrcvModeIndiCount = 0;
        Cdd_GucTrcvModeIndiCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucTrcvModeIndiCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCdd_CanIfTransceiverModeIndication() */
#endif
/*******************************************************************************
**                       Cdd_Test_ValidateData()                              **
*******************************************************************************/
boolean Cdd_TestValidateData(PduInfoType* LddExpPduInfo,
  PduInfoType* LddActPduInfo)
{
  uint8 *LpActualSduDataPtr;
  uint8 *LpExpSduDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  LddSduCount = LddExpPduInfo->SduLength;
  LpExpSduDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualSduDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  if((LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }

  while((LddSduCount > 0) && (LblReturnValue != FALSE))
 {
    if(*LpActualSduDataPtr != *LpExpSduDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualSduDataPtr++;
    LpExpSduDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* Cdd_TestValidateData() */
#ifdef LINIF_MODULE_ACTIVE 
/*******************************************************************************
**                         Cdd_LinIfTxConfirmation()                         **
*******************************************************************************/
void Cdd_LinIfTxConfirmation(PduIdType TxPduId)
{
  #ifndef TYPICAL_CONFIG
  Cdd_GucLinIfTxConfPduId[Cdd_GucLinIfTxConfCount] = TxPduId;
  Cdd_GucLinIfTxConfCount++;
  #endif
} /* End Cdd_LinIfTxConfirmation() */

/*******************************************************************************
**                       TestCdd_LinIfTxConfirmation()                       **
*******************************************************************************/
boolean TestCdd_LinIfTxConfirmation(App_DataValidateType LddDataValidate,
PduIdType ExpTxPduId)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    case S_VALIDATE:
    {
      if((Cdd_GucLinIfTxConfCount == 0x01) &&
        (ExpTxPduId == Cdd_GucLinIfTxConfPduId[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      Cdd_GucLinIfTxConfCount = 0;
      break;
    } /* End case S_VALIDATE: */
    case S_NOT_INVOKED:
    {
      if(Cdd_GucLinIfTxConfCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Cdd_GucLinIfTxConfCount; LucIndex++)
      {
        if(ExpTxPduId == Cdd_GucLinIfTxConfPduId[LucIndex])
        {
          LblRetValue = STEP_PASSED;
          LucIndex = Cdd_GucLinIfTxConfCount;
        } /* End if(ExpTxPduId == Cdd_GucLinIfTxConfPduId[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < Cdd_GucLinIfTxConfCount; ...) */
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Cdd_GucLinIfTxConfCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Cdd_GucLinIfTxConfCount == Cdd_GucLinIfTxConfCheckCount)
      {
        Cdd_GucLinIfTxConfCount = 0;
        Cdd_GucLinIfTxConfCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < Cdd_GucLinIfTxConfCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpTxPduId == Cdd_GucLinIfTxConfPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCdd_LinIfTxConfirmation() */
/*******************************************************************************
**                         Cdd_LinIfRxIndication()                           **
*******************************************************************************/
void Cdd_LinIfRxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8* LpSduDataPtr;
  uint32 LucDataLength;

  Cdd_GaaLinIfRxIndPduId[Cdd_GucLinIfRxIndCount] = RxPduId;
  Cdd_GaaLinIfRxIndSduLength[Cdd_GucLinIfRxIndCount] = PduInfoPtr->SduLength;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > CDD_DATA_LENGTH)
  {
    LucDataLength = CDD_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->SduLength;
  }
  /* Copy the actual data from actual SduDataPtr into global array */
  for(LucDataIndex = 0x00; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    Cdd_GaaLinIfRxIndSduData[Cdd_GucLinIfRxIndCount][LucDataIndex] =
      *LpSduDataPtr;
    LpSduDataPtr++;
  }
  Cdd_GucLinIfRxIndCount++;
  #endif
} /* End Cdd_LinIfTransmit()*/

/*******************************************************************************
**                       TestCdd_LinIfRxIndication()                         **
*******************************************************************************/
boolean TestCdd_LinIfRxIndication(App_DataValidateType LddDataValidate,
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Cdd_GucLinIfRxIndCount == 0x01) &&
        (ExpRxPduId == Cdd_GaaLinIfRxIndPduId[0]))
      {
        ActPduInfo.SduLength = Cdd_GaaLinIfRxIndSduLength[0];
        ActPduInfo.SduDataPtr = &Cdd_GaaLinIfRxIndSduData[0][0];

        /* Validate SduLength and Data */
        if(Cdd_TestValidateData(ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucLinIfRxIndCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucLinIfRxIndCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Cdd_GucLinIfRxIndCount; LucIndex++)
      {
        if(ExpRxPduId == Cdd_GaaLinIfRxIndPduId[LucIndex])
        {
          ActPduInfo.SduLength = Cdd_GaaLinIfRxIndSduLength[LucIndex];
          ActPduInfo.SduDataPtr = &Cdd_GaaLinIfRxIndSduData[LucIndex][0];

          if(Cdd_TestValidateData((PduInfoType *)ExpPduInfoPtr, &ActPduInfo))
          {
            LblRetValue = STEP_PASSED;
          }
          LucIndex = Cdd_GucLinIfRxIndCount;
        } /* End if(ExpRxPduId == Cdd_GaaLinIfRxIndPduId[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < Cdd_GucLinIfRxIndCount; ...) */
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Cdd_GucLinIfRxIndCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Cdd_GucLinIfRxIndCount == Cdd_GucLinIfRxIndCheckCount)
      {
        Cdd_GucLinIfRxIndCount = 0;
        Cdd_GucLinIfRxIndCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < Cdd_GucLinIfRxIndCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpRxPduId == Cdd_GaaLinIfRxIndPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCdd_LinIfRxIndication() */
/*******************************************************************************
**                         Cdd_LinIfTriggerTransmit()                         **
*******************************************************************************/
Std_ReturnType Cdd_LinIfTriggerTransmit(PduIdType TxPduId,
  PduInfoType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 *LpSduDataPtr;
  uint8 LucCount;
  uint8 LucSduLength = 0x00;

  boolean LblValue = FALSE;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  Cdd_GaaLinIfTrigTxPduId[Cdd_GucLinIfTrigTxCount] = TxPduId;
  for(LucCount = 0x00;(LucCount < CDD_ARRAY_SIZE) && (LblValue == FALSE);
    LucCount++)
  {
    if(TxPduId == Cdd_GaaLinIfTrigSetTxPduId[LucCount])
    {
      PduInfoPtr->SduLength = Cdd_GaaLinIfTrigSetTxSduLength[LucCount];
      while(LucSduLength < PduInfoPtr->SduLength)
      {
        *LpSduDataPtr =
          Cdd_GaaLinIfTrigSetTxSduData[LucCount][LucSduLength];
        LpSduDataPtr++;
        LucSduLength++;
      }      
      LblValue = TRUE;
    }
    if((LblValue != TRUE) && (LucCount == (CDD_ARRAY_SIZE - 1)))
    {
      PduInfoPtr->SduLength = Cdd_GaaLinIfTrigSetTxSduLength[LucCount];
      while(LucSduLength < PduInfoPtr->SduLength)
      {
        *LpSduDataPtr =
          Cdd_GaaLinIfTrigSetTxSduData[LucCount][LucSduLength];
        LpSduDataPtr++;
        LucSduLength++;
      }      
    }
  }
  Cdd_GucLinIfTrigTxCount++;
  #endif
  return(E_OK);
} /* End Cdd_LinIfTriggerTransmit() */

/*******************************************************************************
**                       TestCdd_LinIfTriggerTransmit()                      **
*******************************************************************************/
boolean TestCdd_LinIfTriggerTransmit(App_DataValidateType LddDataValidate,
PduIdType ExpTxPduId)
{
  uint8 LucIndex;
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
    */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Cdd_GucLinIfTrigTxCount == 0x01) &&
        (ExpTxPduId == Cdd_GaaLinIfTrigTxPduId[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucLinIfTrigTxCount = 0x00;
      Cdd_GucPduRLinIfTrigTxCheckCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucLinIfTrigTxCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < Cdd_GucLinIfTrigTxCount; LucIndex++)
      {
        /* Validate the PduId */
        if((ExpTxPduId == Cdd_GaaLinIfTrigTxPduId[LucIndex]))
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = Cdd_GucLinIfTrigTxCount;
        } /* End if(ExpPduId == Cdd_GucComActPduId[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < Cdd_GucLinIfTrigTxCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Cdd_GucPduRLinIfTrigTxCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Cdd_GucPduRLinIfTrigTxCheckCount == Cdd_GucLinIfTrigTxCount)
      {
        Cdd_GucLinIfTrigTxCount = 0;
        Cdd_GucPduRLinIfTrigTxCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with sequnce)
     * and to validate parameters of the API with what it has been invoked
     */

    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;

      /* Loop through the global array and check for the expected ID */
      for(LucIndex = 0; (LucIndex < Cdd_GucLinIfTrigTxCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpTxPduId == Cdd_GaaLinIfTrigTxPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    } /* End case M_NOT_INVOKED: */

    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}  /* End TestCdd_LinIfTriggerTransmit() */
/*******************************************************************************
**                       Cdd_ScheduleRequestConfirmation()                    **
*******************************************************************************/
void Cdd_ScheduleRequestConfirmation(NetworkHandleType network, 
  LinIf_SchHandleType schedule)
{
  #ifndef TYPICAL_CONFIG
  Cdd_GddSchReqConfNw[Cdd_GucSchReqConfCount] = network;
  Cdd_GddSchReqConfSchedule[Cdd_GucSchReqConfCount] = schedule;
  /* Increment count variable to handle multiple invocations */
  if(Cdd_GucSchReqConfCount != CDD_ARRAY_SIZE)
  {    
    Cdd_GucSchReqConfCount++;
  }
  #endif
} /* End Cdd_ScheduleRequestConfirmation() */

/*******************************************************************************
**                       TestCdd_ScheduleRequestConfirmation()                **
*******************************************************************************/
boolean TestCdd_ScheduleRequestConfirmation(App_DataValidateType 
  LucDataValidate, NetworkHandleType Expnetwork, LinIf_SchHandleType 
  Expschedule)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Cdd_GucSchReqConfCount == 0x01) && 
        (Expnetwork == Cdd_GddSchReqConfNw[0]) && 
        (Expschedule == Cdd_GddSchReqConfSchedule[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucSchReqConfCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucSchReqConfCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((Cdd_GucSchReqConfCheckCount <= Cdd_GucSchReqConfCount) &&
        (Expnetwork == Cdd_GddSchReqConfNw[Cdd_GucSchReqConfCheckCount]) && 
        (Expschedule == 
        Cdd_GddSchReqConfSchedule[Cdd_GucSchReqConfCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Cdd_GucSchReqConfCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Cdd_GucSchReqConfCheckCount == Cdd_GucSchReqConfCount)
      {
        Cdd_GucSchReqConfCount = 0;
        Cdd_GucSchReqConfCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < Cdd_GucSchReqConfCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(Expnetwork == Cdd_GddSchReqConfNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCdd_ScheduleRequestConfirmation() */
/*******************************************************************************
**                       Cdd_WakeupConfirmation()                        **
*******************************************************************************/
void Cdd_WakeupConfirmation(NetworkHandleType network, boolean success)
{
  #ifndef TYPICAL_CONFIG
  Cdd_GddWakeUpConfNw[Cdd_GucWakeUpConfCount] = network;
  Cdd_GblWakeUpConfSuccs[Cdd_GucWakeUpConfCount] = success;
  /* Increment count variable to handle multiple invocations */
  if(Cdd_GucWakeUpConfCount != CDD_ARRAY_SIZE)
  {    
    Cdd_GucWakeUpConfCount++;
  }
  #endif
} /* End Cdd_WakeupConfirmation() */

/*******************************************************************************
**                       TestCdd_WakeupConfirmation()                         **
*******************************************************************************/
boolean TestCdd_WakeupConfirmation(App_DataValidateType 
  LucDataValidate, NetworkHandleType Expnetwork, boolean Expsuccess)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Cdd_GucWakeUpConfCount == 0x01) && 
        (Expnetwork == Cdd_GddWakeUpConfNw[0]) && 
        (Expsuccess == Cdd_GblWakeUpConfSuccs[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucWakeUpConfCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucWakeUpConfCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((Cdd_GucWakeUpConfCheckCount <= Cdd_GucWakeUpConfCount) &&
        (Expnetwork == Cdd_GddWakeUpConfNw[Cdd_GucWakeUpConfCheckCount]) && 
        (Expsuccess == 
        Cdd_GblWakeUpConfSuccs[Cdd_GucWakeUpConfCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Cdd_GucWakeUpConfCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Cdd_GucWakeUpConfCheckCount == Cdd_GucWakeUpConfCount)
      {
        Cdd_GucWakeUpConfCount = 0;
        Cdd_GucWakeUpConfCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < Cdd_GucWakeUpConfCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(Expnetwork == Cdd_GddWakeUpConfNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCdd_WakeupConfirmation() */
/*******************************************************************************
**                       Cdd_GotoSleepConfirmation()                        **
*******************************************************************************/
void Cdd_GotoSleepConfirmation(NetworkHandleType network, boolean success)
{
  #ifndef TYPICAL_CONFIG
  Cdd_GddGotoSleepConfNw[Cdd_GucGotoSleepConfCount] = network;
  Cdd_GblGotoSleepConfSuccs[Cdd_GucGotoSleepConfCount] = success;
  /* Increment count variable to handle multiple invocations */
  if(Cdd_GucGotoSleepConfCount != CDD_ARRAY_SIZE)
  {    
    Cdd_GucGotoSleepConfCount++;
  }
  #endif
} /* End Cdd_GotoSleepConfirmation() */

/*******************************************************************************
**                       TestCdd_GotoSleepConfirmation()                    **
*******************************************************************************/
boolean TestCdd_GotoSleepConfirmation(App_DataValidateType 
  LucDataValidate, NetworkHandleType Expnetwork, boolean Expsuccess)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Cdd_GucGotoSleepConfCount == 0x01) && 
        (Expnetwork == Cdd_GddGotoSleepConfNw[0]) && 
        (Expsuccess == Cdd_GblGotoSleepConfSuccs[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      Cdd_GucGotoSleepConfCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Cdd_GucGotoSleepConfCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((Cdd_GucGotoSleepConfCheckCount <= Cdd_GucGotoSleepConfCount) &&
        (Expnetwork == Cdd_GddGotoSleepConfNw[Cdd_GucGotoSleepConfCheckCount]) && 
        (Expsuccess == 
        Cdd_GblGotoSleepConfSuccs[Cdd_GucGotoSleepConfCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Cdd_GucGotoSleepConfCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Cdd_GucGotoSleepConfCheckCount == Cdd_GucGotoSleepConfCount)
      {
        Cdd_GucGotoSleepConfCount = 0;
        Cdd_GucGotoSleepConfCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < Cdd_GucGotoSleepConfCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(Expnetwork == Cdd_GddGotoSleepConfNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCdd_GotoSleepConfirmation() */
#endif
/*******************************************************************************
**                     TestCdd_DefaultBehavior()                              **
*******************************************************************************/
void TestCdd_DefaultBehavior(void)
{
  #ifdef FRSM_MODULE_ACTIVE
  Cdd_GucSyncLossCount = 0;
  #endif 
  
  #ifdef LINIF_MODULE_ACTIVE
  uint8 LucDataIndex;
  uint8 LucDataCount;
  #endif
  
  #ifdef RAMTST_MODULE_ACTIVE
  Cdd_GucRamTstErrorNotif = 0;
  Cdd_GucRamTstCompleteNotif = 0;
  #endif
  #ifdef CANIF_MODULE_ACTIVE
  Cdd_GucTxConfirmCount = 0;
  Cdd_GucTrcvModeIndCnt = 0;
  Cdd_GucClrTrcvWufFlagIndCount = 0;
  Cdd_GucChkTrcvWakeFlagIndCount = 0;
  Cdd_GucConfirmPnCount = 0;
  Cdd_GucTxConfirmCount1 = 0;
  Cdd_GucTxConfirmCount2 = 0;
  Cdd_GucTxConfirmCount3 = 0;
  Cdd_GucTxConfirmCount4 = 0;
  Cdd_GucTxConfirmCount5 = 0;
  Cdd_GucTxConfirmCount6 = 0;
  Cdd_GucTxConfirmCheckCount = 0;
  Cdd_GucTxConfirmCheckCount1 = 0;
  Cdd_GucTxConfirmCheckCount2 = 0;
  Cdd_GucTxConfirmCheckCount3 = 0;
  Cdd_GucTxConfirmCheckCount4 = 0;
  Cdd_GucTxConfirmCheckCount5 = 0;
  Cdd_GucTxConfirmCheckCount6 = 0;
  Cdd_GucRxIndiCount = 0;
  Cdd_GucCntrlBusOffCount = 0;
  Cdd_GucCntrlBusOffCheckCount = 0;
  Cdd_GucSetWakEventCount = 0;
  Cdd_GucSetWakEventCheckCount = 0;
  Cdd_GucValidWakupEvCount = 0;
  Cdd_GucValidWakupEvCheckCount = 0;
  Cdd_GucCntrlModeIndiCount = 0;
  Cdd_GucCntrlModeIndiCheckCount = 0;
  Cdd_GucTrcvModeIndiCount = 0;
  Cdd_GucTrcvModeIndiCheckCount = 0;
  #endif
  #ifdef LINIF_MODULE_ACTIVE 
  Cdd_GucLinIfTxConfCount = 0x00;
  Cdd_GucLinIfTxConfCheckCount = 0x00;
  Cdd_GucLinIfRxIndCount = 0x00;
  Cdd_GucLinIfRxIndCheckCount = 0x00;
  Cdd_GucLinIfTrigTxCount = 0x00;
  Cdd_GucPduRLinIfTrigTxCheckCount = 0x00;
  Cdd_GucSchReqConfCount = 0;
  Cdd_GucGotoSleepConfCount = 0;
  Cdd_GucWakeUpConfCount = 0;
  Cdd_GucSchReqConfCheckCount = 0;
  Cdd_GucGotoSleepConfCheckCount = 0;
  Cdd_GucWakeUpConfCheckCount = 0;
  for(LucDataIndex = 0x00; LucDataIndex < CDD_ARRAY_SIZE ; LucDataIndex++)
  {
    Cdd_GaaLinIfTrigSetTxPduId[LucDataIndex] = 0xFF;
    Cdd_GaaLinIfTrigSetTxSduLength[LucDataIndex] = 0x08;
    for(LucDataCount = 0x00; LucDataCount < CDD_DATA_LENGTH ; LucDataCount++)
    {
      Cdd_GaaLinIfTrigSetTxSduData[LucDataIndex][LucDataCount] = LucDataCount;
    }    
  }
  #endif
} /* End TestCdd_DefaultBehavior() */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

