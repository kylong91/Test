/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Cdd_CanIf.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Cdd_CanIf stub                                        **
**                                                                            **
**  PURPOSE   : Declaration of Cdd_CanIf stub functions                       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef CDD_H
#define CDD_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"             /* Com Stack header */
#include "TC_Generic.h"
#include "Can_GeneralTypes.h"
#include "EcuM.h"
#include "CanIf.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define CDD_AR_RELEASE_MAJOR_VERSION    0x04
#define CDD_AR_RELEASE_MINOR_VERSION    0x00
#define CDD_AR_RELEASE_REVISION_VERSION 0x02
#define CDD_ARRAY_SIZE                  0x08
#define CDD_DATA_LENGTH                 0x08

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern void Cdd_CanIfTxConfirmation(PduIdType TxPduId);

extern void Cdd_TrcvModeIndication (uint8 TransceiverId, CanTrcv_TrcvModeType
                                                               TransceiverMode);

extern boolean TestCdd_CanIfValidateWakeupEvent(App_DataValidateType LddDataValidate,
  EcuM_WakeupSourceType Expsources);

extern boolean TestCdd_ClearTrcvWufFlagIndication(App_DataValidateType LddDataValidate,
uint8 TransceiverId);

extern void Cdd_ClearTrcvWufFlagIndication(uint8 TransceiverId);

extern void Cdd_CanIfTxConfirmation1(PduIdType TxPduId);

extern void Cdd_CanIfTxConfirmation2(PduIdType TxPduId);

extern void Cdd_CanIfTxConfirmation3(PduIdType TxPduId);

extern void Cdd_CanIfTxConfirmation4(PduIdType TxPduId);

extern void Cdd_CanIfTxConfirmation5(PduIdType TxPduId);

extern void Cdd_CanIfTxConfirmation6(PduIdType TxPduId);

extern void Cdd_CanIfRxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr);

extern void Cdd_CanIfControllerBusOff(uint8 ControllerId);

extern void Cdd_CanIfSetWakeupEvent(EcuM_WakeupSourceType sources);

extern void Cdd_CanIfValidateWakeupEvent(EcuM_WakeupSourceType sources);

extern void Cdd_CanIfControllerModeIndication(uint8 ControllerId,
  CanIf_ControllerModeType ControllerMode);

extern void Cdd_CanIfTrcvModeIndication(uint8 TransceiverId,
  CanTrcv_TrcvModeType TransceiverMode);
  
extern void Cdd_CanIfTransceiverModeIndication(uint8 TransceiverId,
CanTrcv_TrcvModeType TransceiverMode);

extern boolean TestCdd_CanIfTransceiverModeIndication(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiverId, CanTrcv_TrcvModeType ExpTransceiverMode);

extern boolean TestCdd_CanIfTxConfirmation(App_DataValidateType LddDataValidate,
  PduIdType ExpTxPduId);

extern boolean TestCdd_CanIfTxConfirmation1(App_DataValidateType
  LddDataValidate, PduIdType ExpTxPduId);

extern boolean TestCdd_CanIfTxConfirmation2(App_DataValidateType
  LddDataValidate, PduIdType ExpTxPduId);

extern boolean TestCdd_CanIfTxConfirmation3(App_DataValidateType
  LddDataValidate, PduIdType ExpTxPduId);

extern boolean TestCdd_CanIfTxConfirmation4(App_DataValidateType
  LddDataValidate, PduIdType ExpTxPduId);

extern boolean TestCdd_CanIfTxConfirmation5(App_DataValidateType
  LddDataValidate, PduIdType ExpTxPduId);

extern boolean TestCdd_CanIfTxConfirmation6(App_DataValidateType
  LddDataValidate, PduIdType ExpTxPduId);

extern boolean TestCdd_CanIfRxIndication(App_DataValidateType LddDataValidate,
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr);

extern boolean TestCdd_CanIfControllerBusOff(
  App_DataValidateType LddDataValidate, uint8 ExpControllerId);

extern boolean TestCdd_CanIfSetWakeupEvent(App_DataValidateType LddDataValidate,
  EcuM_WakeupSourceType Expsources);

extern boolean TestCdd_CanIfControllerModeIndication
  (App_DataValidateType LddDataValidate, uint8 ExpControllerId,
  CanIf_ControllerModeType ExpControllerMode);

extern boolean TestCdd_CanIfTrcvModeIndication(
  App_DataValidateType LddDataValidate, uint8 ExpTransceiverId,
  CanTrcv_TrcvModeType ExpTransceiverMode);

 
extern void Cdd_WakeupConfirmation(NetworkHandleType network, boolean success);

extern void Cdd_GotoSleepConfirmation(NetworkHandleType network, 
  boolean success);
  
extern boolean TestCdd_WakeupConfirmation(App_DataValidateType 
  LucDataValidate, NetworkHandleType Expnetwork, boolean Expsuccess);
  
extern boolean TestCdd_GotoSleepConfirmation(App_DataValidateType 
  LucDataValidate, NetworkHandleType Expnetwork, boolean Expsuccess);

extern boolean Cdd_TestValidateData(PduInfoType* LddExpPduInfo,
  PduInfoType* LddActPduInfo);  
extern void TestCdd_DefaultBehavior(void);

extern boolean TestCdd_ConfirmPnAvailability(App_DataValidateType LddDataValidate,
uint8 TransceiverId);

extern boolean TestCdd_CheckTrcvWakeFlagIndication(App_DataValidateType LddDataValidate,
uint8 TransceiverId);

extern boolean TestCdd_TransceiverModeIndication(App_DataValidateType LddDataValidate,
uint8 TransceiverId, CanTrcv_TrcvModeType TransceiverMode);

extern void Cdd_CheckTrcvWakeFlagIndication (uint8 TransceiverId);

extern void Cdd_ConfirmPnAvailability(uint8 TransceiverId);

extern void Cdd_TxConfirmation(PduIdType TxPduId);
#endif /* CDD_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
