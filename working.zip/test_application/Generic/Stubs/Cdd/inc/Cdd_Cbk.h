/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Cdd_Cbk.h                                                     **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Cdd_Cbk stub                                          **
**                                                                            **
**  PURPOSE   : Declaration of Cdd_Cbk stub functions                         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef CDD_CBK_H
#define CDD_CBK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"             /* Com Stack header */
#include "TC_Generic.h"

#include "LinIf.h"
/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define CDD_AR_RELEASE_MAJOR_VERSION    4
#define CDD_AR_RELEASE_MINOR_VERSION    0
#define CDD_AR_RELEASE_REVISION_VERSION 3

#define CDDCBK_ARRAY_SIZE                  0x08
#define CDD_DATA_LENGTH                    0x08
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void Cdd_SyncLoss(NetworkHandleType NetworkHandle, boolean SyncLossErrorStatus);

extern void TestCdd_DefaultBehavior(void);

extern void Cdd_LinIfRxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr);

extern void Cdd_LinIfTxConfirmation(PduIdType TxPduId);

extern Std_ReturnType Cdd_LinIfTriggerTransmit(PduIdType TxPduId,
  PduInfoType *PduInfoPtr);
  
extern void Cdd_ScheduleRequestConfirmation(NetworkHandleType network, 
  LinIf_SchHandleType schedule);
  
extern void Cdd_WakeupConfirmation(NetworkHandleType network, boolean success);

extern void Cdd_GotoSleepConfirmation(NetworkHandleType network, 
  boolean success);

extern boolean TestCdd_LinIfRxIndication(App_DataValidateType LddDataValidate,
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr);
  
extern  boolean TestCdd_LinIfTxConfirmation(App_DataValidateType LddDataValidate,
PduIdType ExpTxPduId);

extern boolean TestCdd_LinIfTriggerTransmit(App_DataValidateType LddDataValidate,
PduIdType ExpTxPduId);

extern boolean TestCdd_ScheduleRequestConfirmation(App_DataValidateType 
  LucDataValidate, NetworkHandleType Expnetwork, LinIf_SchHandleType 
  Expschedule);
  
extern boolean TestCdd_WakeupConfirmation(App_DataValidateType 
  LucDataValidate, NetworkHandleType Expnetwork, boolean Expsuccess);
  
extern boolean TestCdd_GotoSleepConfirmation(App_DataValidateType 
  LucDataValidate, NetworkHandleType Expnetwork, boolean Expsuccess);

extern boolean Cdd_TestValidateData(PduInfoType* LddExpPduInfo,
  PduInfoType* LddActPduInfo); 

#endif /* CDD_CBK_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
