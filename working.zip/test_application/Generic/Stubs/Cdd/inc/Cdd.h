/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Cdd.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Cdd stub                                              **
**                                                                            **
**  PURPOSE   : Declaration of Cdd stub functions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef CDD_H
#define CDD_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"             /* Com Stack header */
#include "TC_Generic.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define CDD_AR_RELEASE_MAJOR_VERSION    4
#define CDD_AR_RELEASE_MINOR_VERSION    0
#define CDD_AR_RELEASE_REVISION_VERSION 3

#define CDD_ARRAY_SIZE                  0x08
#define CDD_DATA_LENGTH                 0x08

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern void TestCdd_DefaultBehavior(void);

extern void Cdd_SyncLoss(NetworkHandleType NetworkHandle,
  boolean SyncLossErrorStatus);

extern boolean TestCdd_SyncLoss(App_DataValidateType LucDataValidate,
  NetworkHandleType ExpNetworkHandle, boolean ExpSyncLossErrorStatus);


extern void Cdd_FrIfTxConfirmation(PduIdType TxPduId);

extern boolean TestCdd_FrIfTxConfirmation(App_DataValidateType LucDataValidate,
PduIdType TxPduId);

extern Std_ReturnType Cdd_FrIfTriggerTransmit(PduIdType TxPduId,
          PduInfoType* PduInfoPtr);
  
extern boolean TestCdd_FrIfTriggerTransmit(App_DataValidateType LucDataValidate,
PduIdType TxPduId);

extern void Cdd_FrIfRxIndication(PduIdType RxPduId, PduInfoType* PduInfoPtr);

extern boolean TestCdd_FrIfRxIndication(App_DataValidateType LucDataValidate,
PduIdType RxPduId);

extern boolean Cdd_TestValidateData(PduInfoType* LddExpPduInfo,
  PduInfoType* LddActPduInfo);

#endif /* CDD_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
