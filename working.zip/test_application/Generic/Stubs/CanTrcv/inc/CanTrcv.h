/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: CanTrcv.h                                                     **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CAN Transceiver module                                **
**                                                                            **
**  PURPOSE   : Declaration of CanTrcv functions                              **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     13-Jun-2011   BJV    Initial version                             **
**                                                                            **
** 4.0.1     20-Sep-2011   BPT    Updated for CanIf                           **
** 4.0.2     20-Dec-2011   RPS    General Inclusions are updated              **
*******************************************************************************/

#ifndef CANTRCV_H
#define CANTRCV_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"             /* Com Stack header */
#include "Can_GeneralTypes.h"
#include "TC_Generic.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define CANTRCV_AR_RELEASE_MAJOR_VERSION    0x04
#define CANTRCV_AR_RELEASE_MINOR_VERSION    0x00
#define CANTRCV_AR_RELEASE_REVISION_VERSION 0x02

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Std_ReturnType CanTrcv_CheckWakeup(uint8 Transceiver);
extern boolean TestCanTrcv_CheckWakeFlag(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver);

extern Std_ReturnType CanTrcv_ClearTrcvWufFlag(uint8 Transceiver);

extern boolean TestCanTrcv_ClearTrcvWufFlag(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver);

extern Std_ReturnType CanTrcv_GetBusWuReason(uint8 Transceiver,
  CanTrcv_TrcvWakeupReasonType *reason);

extern Std_ReturnType CanTrcv_GetOpMode(uint8 Transceiver,
  CanTrcv_TrcvModeType *OpMode);

extern Std_ReturnType CanTrcv_SetOpMode(uint8 Transceiver,
  CanTrcv_TrcvModeType OpMode);

extern Std_ReturnType CanTrcv_SetWakeupMode(uint8 Transceiver,
  CanTrcv_TrcvWakeupModeType TrcvWakeupMode);

extern void TestSetCanTrcv_GetBusWuReason(
  CanTrcv_TrcvWakeupReasonType LenWakeupReason);

extern boolean TestCanTrcv_CheckWakeup(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver);

extern boolean TestCanTrcv_GetBusWuReason(App_DataValidateType LddDataValidate,
  uint8 LddExpTransceiver);

extern boolean TestCanTrcv_GetOpMode(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver);

extern boolean TestCanTrcv_SetOpMode(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver, CanTrcv_TrcvModeType ExpOpMode);

extern boolean TestCanTrcv_SetWakeupMode(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver, CanTrcv_TrcvWakeupModeType ExpTrcvWakeupMode);

extern void TestCanTrcv_DefaultBehavior(void);

extern void TestSetCanTrcv_GetOpModeRetVal(Std_ReturnType LddRetVal,
  CanTrcv_TrcvModeType LddOpMode);

extern void TestSetCanTrcv_GetTrcvModeVal(CanTrcv_TrcvModeType LddOpMode);

extern void TestSetCanTrcv_CheckWakeupRetVal
  (Std_ReturnType LddCanTrcvReturnVal);
  
extern Std_ReturnType CanTrcv_CheckWakeFlag(uint8 Transceiver);

#endif /* CANTRCV_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
