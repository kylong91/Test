/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: CanTrcv.c                                                     **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CanTrcv Stub                                          **
**                                                                            **
**  PURPOSE   : This application file contains the CanTrcv  Stub functions    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision    Date         By    Description                                 **
********************************************************************************
** 4.0.0     13-Jun-2011   BJV    Initial version                             **
**                                                                            **
** 4.0.1     20-Sep-2011   BPT    Updated for CanIf                           **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "CanTrcv.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 CanTrcv_GucChkWakeCount;
uint8 CanTrcv_GucWakeFlagCount;

uint8 CanTrcv_GucClrTrcvWufFlagIndCount;
uint8 CanTrcv_GucClrTrcvWufFlagCount;
uint8 CanTrcv_GucChkWakeCheckCount;
uint8 CanTrcv_GucTransceiver;
Std_ReturnType CanTrcv_GddCheckWakeupRetVal;

uint8 CanTrcv_GucGetBusWRCount;
uint8 CanTrcv_GucGetBusWRCheckCount;
CanTrcv_TrcvWakeupReasonType CanTrcv_GenReason;

uint8 CanTrcv_GucGetOpMoCount;
uint8 CanTrcv_GucGetOpMoCheckCount;
CanTrcv_TrcvModeType CanTrcv_GddGetOpMode;
Std_ReturnType CanTrcv_GddGetOpModeRetVal;

uint8 CanTrcv_GucSetOpMoCount;
uint8 CanTrcv_GucSetOpMoCheckCount;
CanTrcv_TrcvModeType CanTrcv_GddSetOpMode;

uint8 CanTrcv_GucSetWakupCount;
uint8 CanTrcv_GucSetWakupCheckCount;
CanTrcv_TrcvWakeupModeType CanTrcv_GucTrcvWakeupMode;

/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/******************************************************************************
**                     CanTrcv_CheckWakeFlag()                                **
*******************************************************************************/

Std_ReturnType CanTrcv_CheckWakeFlag(uint8 Transceiver)
{
  /* Load actual Transceiver into Global variables */
  Std_ReturnType LenStdRetVal;
  LenStdRetVal = E_OK;
  CanTrcv_GucTransceiver = Transceiver;
  CanTrcv_GucWakeFlagCount++;
  return(LenStdRetVal);
} /* End CanTrcv_CheckWakeFlag() */

/*******************************************************************************
**                     TestCanTrcv_CheckWakeFlag()                     **
*******************************************************************************/
boolean TestCanTrcv_CheckWakeFlag(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count,Transceiver  */
      if((CanTrcv_GucWakeFlagCount == 0x01) &&
      (CanTrcv_GucTransceiver == ExpTransceiver))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucWakeFlagCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucWakeFlagCount; LucIndex++)
      {
        /* Validate Transceiver */
        if(CanTrcv_GucTransceiver == ExpTransceiver)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucWakeFlagCount;
        }
      }
      /*
      * Reset all the count variables once after verifying the API invocation
      * for maximum number of API invocations
      */
   
      CanTrcv_GucWakeFlagCount = 0;
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucWakeFlagCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestCanTrcv_CheckWakeFlag() */



/*******************************************************************************
**                     CanTrcv_ClearTrcvWufFlag()                     **
*******************************************************************************/
Std_ReturnType CanTrcv_ClearTrcvWufFlag(uint8 Transceiver)
{
  /* Load actual Transceiver into Global variables */
  Std_ReturnType LenStdRetVal;
  LenStdRetVal = E_OK;
  CanTrcv_GucTransceiver = Transceiver;
  CanTrcv_GucClrTrcvWufFlagCount++;
  return(LenStdRetVal);
} /* End CanTrcv_ClearTrcvWufFlag() */


/*******************************************************************************
**                     TestCanTrcv_ClearTrcvWufFlag()                     **
*******************************************************************************/
boolean TestCanTrcv_ClearTrcvWufFlag(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count,Transceiver  */
      if((CanTrcv_GucClrTrcvWufFlagCount == 0x01) &&
      (CanTrcv_GucTransceiver == ExpTransceiver))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucClrTrcvWufFlagCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucClrTrcvWufFlagCount; LucIndex++)
      {
        /* Validate Transceiver */
        if(CanTrcv_GucTransceiver == ExpTransceiver)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucClrTrcvWufFlagCount;
        }
      }
      /*
      * Reset all the count variables once after verifying the API invocation
      * for maximum number of API invocations
      */
   
      CanTrcv_GucClrTrcvWufFlagCount = 0;
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucClrTrcvWufFlagCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestCanTrcv_ClearTrcvWufFlag() */




/*******************************************************************************
**                     CanTrcv_CheckWakeup()                                  **
*******************************************************************************/
Std_ReturnType CanTrcv_CheckWakeup(uint8 Transceiver)
{
  /* Load actual Transceiver into Global variables */
  CanTrcv_GucTransceiver = Transceiver;
  CanTrcv_GucChkWakeCount++;

  return(CanTrcv_GddCheckWakeupRetVal);
} /* End CanTrcv_CheckWakeup() */

/*******************************************************************************
**                     TestCanTrcv_CheckWakeup()                              **
*******************************************************************************/
boolean TestCanTrcv_CheckWakeup(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count,Transceiver  */
      if((CanTrcv_GucChkWakeCount == 0x01) &&
      (CanTrcv_GucTransceiver == ExpTransceiver))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucChkWakeCount = 0;
      CanTrcv_GucChkWakeCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucChkWakeCount; LucIndex++)
      {
        /* Validate Transceiver */
        if(CanTrcv_GucTransceiver == ExpTransceiver)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucChkWakeCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTrcv_GucChkWakeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTrcv_GucChkWakeCheckCount == CanTrcv_GucChkWakeCount)
      {
        CanTrcv_GucChkWakeCount = 0;
        CanTrcv_GucChkWakeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucChkWakeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCanTrcv_CheckWakeup() */

/*******************************************************************************
**                       CanTrcv_GetBusWuReason()                             **
*******************************************************************************/
Std_ReturnType CanTrcv_GetBusWuReason(uint8 Transceiver,
  CanTrcv_TrcvWakeupReasonType *reason)
{
  /* Load actual Transceiver and reason into Global variables */
  CanTrcv_GucTransceiver = Transceiver;
  *reason = CanTrcv_GenReason;
  CanTrcv_GucGetBusWRCount++;

  return(E_OK);
} /* End CanTrcv_GetBusWuReason() */

/*******************************************************************************
**                     TestSetCanTrcv_GetBusWuReason()                        **
*******************************************************************************/
void TestSetCanTrcv_GetBusWuReason(CanTrcv_TrcvWakeupReasonType LenWakeupReason)
{
  CanTrcv_GenReason = LenWakeupReason;
}

/*******************************************************************************
**                   TestCanTrcv_GetBusWuReason()                             **
*******************************************************************************/
boolean TestCanTrcv_GetBusWuReason(App_DataValidateType LddDataValidate,
  uint8 LddExpTransceiver)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Transceiver and reason */
      if((CanTrcv_GucGetBusWRCount == 0x01) &&
        (CanTrcv_GucTransceiver == LddExpTransceiver))
     {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucGetBusWRCount = 0;
      CanTrcv_GucGetBusWRCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucGetBusWRCount; LucIndex++)
      {
        /* Validate Transceiver and reason */
        if((CanTrcv_GucTransceiver == LddExpTransceiver))

        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucGetBusWRCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTrcv_GucGetBusWRCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTrcv_GucGetBusWRCheckCount == CanTrcv_GucGetBusWRCount)
      {
        CanTrcv_GucGetBusWRCount = 0;
        CanTrcv_GucGetBusWRCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucGetBusWRCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCanTrcv_GetBusWuReason() */

/*******************************************************************************
**                   CanTrcv_GetOpMode()                                      **
*******************************************************************************/
Std_ReturnType CanTrcv_GetOpMode(uint8 Transceiver,
  CanTrcv_TrcvModeType *OpMode)
{
  /* Load actual Transceiver and OpMode into Global variables */
  CanTrcv_GucTransceiver = Transceiver;
  *OpMode = CanTrcv_GddGetOpMode;
  CanTrcv_GucGetOpMoCount++;

  return(CanTrcv_GddGetOpModeRetVal);
} /* End CanTrcv_GetOpMode() */

/*******************************************************************************
**                   TestCanTrcv_GetOpMode()                                  **
*******************************************************************************/
boolean TestCanTrcv_GetOpMode(App_DataValidateType LddDataValidate,
  uint8 LddExpTransceiver)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Transceiver and OpMode */
      if((CanTrcv_GucGetOpMoCount == 0x01) &&
        (CanTrcv_GucTransceiver == LddExpTransceiver))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucGetOpMoCount = 0;
      CanTrcv_GucGetOpMoCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucGetOpMoCount; LucIndex++)
      {
        /* Validate ControllerId and ControllerMode */
        if(CanTrcv_GucTransceiver == LddExpTransceiver)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucGetOpMoCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTrcv_GucGetOpMoCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTrcv_GucGetOpMoCheckCount == CanTrcv_GucGetOpMoCount)
      {
        CanTrcv_GucGetOpMoCount = 0;
        CanTrcv_GucGetOpMoCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucGetOpMoCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCanTrcv_GetOpMode() */

/*******************************************************************************
**                   CanTrcv_SetOpMode()                                      **
*******************************************************************************/
Std_ReturnType CanTrcv_SetOpMode(uint8 Transceiver, CanTrcv_TrcvModeType OpMode)
{
  /* Load actual Transceiver and OpMode into Global variables */
  CanTrcv_GucTransceiver = Transceiver;
  CanTrcv_GddSetOpMode = OpMode;
  CanTrcv_GucSetOpMoCount++;

  return(E_OK);
} /* End CanTrcv_SetOpMode() */

/*******************************************************************************
**                   TestCanTrcv_SetOpMode()                                  **
*******************************************************************************/
boolean TestCanTrcv_SetOpMode(App_DataValidateType LddDataValidate,
uint8 ExpTransceiver, CanTrcv_TrcvModeType ExpOpMode)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Transceiver and OpMode */
      if((CanTrcv_GucSetOpMoCount == 0x01) &&
        (CanTrcv_GucTransceiver == ExpTransceiver) &&
        ( CanTrcv_GddSetOpMode == ExpOpMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucSetOpMoCount = 0;
      CanTrcv_GucSetOpMoCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucSetOpMoCount; LucIndex++)
      {
        /* Validate Transceiver and OpMode */
        if((CanTrcv_GucTransceiver == ExpTransceiver) &&
          (CanTrcv_GddSetOpMode == ExpOpMode))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucSetOpMoCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTrcv_GucSetOpMoCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTrcv_GucSetOpMoCheckCount == CanTrcv_GucSetOpMoCount)
      {
        CanTrcv_GucSetOpMoCount = 0;
        CanTrcv_GucSetOpMoCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucSetOpMoCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCanTrcv_SetOpMode() */

/*******************************************************************************
**                   CanTrcv_SetWakeupMode()                                  **
*******************************************************************************/
Std_ReturnType CanTrcv_SetWakeupMode(uint8 Transceiver,
CanTrcv_TrcvWakeupModeType TrcvWakeupMode)
{
  /* Load actual Transceiver and TrcvWakeupMode into Global variables */
  CanTrcv_GucTransceiver = Transceiver;
  CanTrcv_GucTrcvWakeupMode = TrcvWakeupMode;
  CanTrcv_GucSetWakupCount++;
  Transceiver = Transceiver;

  return(E_OK);
} /* End CanTrcv_SetWakeupMode() */

/*******************************************************************************
**                   TestCanTrcv_SetWakeupMode()                              **
*******************************************************************************/
boolean TestCanTrcv_SetWakeupMode(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver, CanTrcv_TrcvWakeupModeType ExpTrcvWakeupMode)
{
 boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Transceiver and TrcvWakeupMode */
      if((CanTrcv_GucSetWakupCount == 0x01) &&
         (CanTrcv_GucTransceiver == ExpTransceiver) &&
         (CanTrcv_GucTrcvWakeupMode == ExpTrcvWakeupMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucSetWakupCount = 0;
      CanTrcv_GucSetWakupCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucSetWakupCount; LucIndex++)
      {
        /* Validate Transceiver and TrcvWakeupMode  */
        if((CanTrcv_GucTransceiver == ExpTransceiver) &&
          (CanTrcv_GucTrcvWakeupMode == ExpTrcvWakeupMode))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucSetWakupCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTrcv_GucSetWakupCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTrcv_GucSetWakupCheckCount == CanTrcv_GucSetWakupCount)
      {
        CanTrcv_GucSetWakupCount = 0;
        CanTrcv_GucSetWakupCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucSetWakupCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCanTrcv_SetWakeupMode() */

/*******************************************************************************
**                     TestSetCanTrcv_GetOpModeRetVal()                       **
*******************************************************************************/
void TestSetCanTrcv_GetOpModeRetVal(Std_ReturnType LddRetVal,
  CanTrcv_TrcvModeType LddOpMode)
{
  CanTrcv_GddGetOpModeRetVal = LddRetVal;
  CanTrcv_GddGetOpMode = LddOpMode;
} /* End of TestSetCanTrcv_GetOpModeRetVal() */

/*******************************************************************************
**                     TestSetCanTrcv_GetTrcvModeVal()                        **
*******************************************************************************/
void TestSetCanTrcv_GetTrcvModeVal(CanTrcv_TrcvModeType LddOpMode)
{
  CanTrcv_GddGetOpMode = LddOpMode;
} /* End of TestSetCanTrcv_GetTrcvModeVal() */

/*******************************************************************************
**                  TestSetCanTrcv_CheckWakeupRetVal()                        **
*******************************************************************************/
void TestSetCanTrcv_CheckWakeupRetVal(Std_ReturnType LddCanTrcvReturnVal)
{
  CanTrcv_GddCheckWakeupRetVal = LddCanTrcvReturnVal;
}
/* End TestSetCanTrcv_CheckWakeupRetVal() */


/*******************************************************************************
**                        TestCanTrcv_DefaultBehavior()                       **
*******************************************************************************/
void TestCanTrcv_DefaultBehavior(void)
{
  CanTrcv_GucChkWakeCount = 0;
  CanTrcv_GucClrTrcvWufFlagIndCount = 0;
  CanTrcv_GucClrTrcvWufFlagCount = 0;
  CanTrcv_GucChkWakeCheckCount = 0;
  CanTrcv_GucTransceiver = 0;
  CanTrcv_GucGetBusWRCount = 0;
  CanTrcv_GucGetBusWRCheckCount = 0;
  CanTrcv_GucGetOpMoCount = 0;
  CanTrcv_GucGetOpMoCheckCount = 0;
  CanTrcv_GucSetOpMoCount = 0;
  CanTrcv_GucSetOpMoCheckCount = 0;
  CanTrcv_GucSetWakupCount = 0;
  CanTrcv_GucSetWakupCheckCount = 0;
  CanTrcv_GddGetOpMode = CANTRCV_TRCVMODE_NORMAL;
  CanTrcv_GenReason = CANTRCV_WU_POWER_ON;
  CanTrcv_GddGetOpModeRetVal = E_OK;
  CanTrcv_GddCheckWakeupRetVal = E_OK;
}

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

