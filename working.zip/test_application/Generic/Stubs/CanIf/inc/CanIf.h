/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**                                                                            **
**  SRC-MODULE: CanIf.h                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CanIf Stub                                            **
**                                                                            **
**  PURPOSE   : Declaration of CanIf Stub functions                           **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

#ifndef CANIF_H
#define CANIF_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "CanIf_Types.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define CANIF_AR_RELEASE_MAJOR_VERSION    4
#define CANIF_AR_RELEASE_MINOR_VERSION    0
#define CANIF_AR_RELEASE_REVISION_VERSION 3

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define CANIF_DATA_LENGTH                 0x08
#define CANIF_ARRAY_SIZE                  250

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
typedef uint8 CanIf_ConfigType; 

#define CanIfConf_CanIfTxPduCfg_CanIfTxPduCfg2 0x00
#define CanIfConf_CanIfTxPduCfg_CanIfTxPduCfg3 0x01
#define CanIfConf_CanIfTxPduCfg_CanIfTxPduCfg4 0x02

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern uint8 GucCanSM_Value;               

extern boolean TestCanIf_ChangeBaudrate(App_DataValidateType LucDataValidate,
                            uint8 LucExpControllerId, const uint16 LddBaudrate);
extern boolean TestCanIf_CheckTrcvWufFlag(App_DataValidateType LucDataValidate,
                                                     uint8 LucExpTransceiverId);
extern boolean TestCanIf_ClearTrcvWufFlag(App_DataValidateType LucDataValidate,
                                                     uint8 LucExpTransceiverId);                                                     
extern Std_ReturnType CanIf_SetControllerMode(uint8 ControllerId,
  CanIf_ControllerModeType ControllerMode);

extern Std_ReturnType CanIf_SetTrcvMode(uint8 TransceiverId,
  CanTrcv_TrcvModeType TransceiverMode);

extern Std_ReturnType CanIf_SetPduMode(uint8 ControllerId,
  CanIf_PduSetModeType PduModeRequest);

extern CanIf_NotifStatusType CanIf_GetTxConfirmationState(uint8 ControllerId);

extern boolean TestCanIf_SetControllerMode(App_DataValidateType LucDataValidate,
  uint8 LucExpControllerId, CanIf_ControllerModeType LddExpControllerMode);

extern boolean TestCanIf_SetTrcvMode(App_DataValidateType LucDataValidate,
  uint8 LucExpTransceiverId, CanTrcv_TrcvModeType LddExpTransceiverMode);

extern boolean TestCanIf_SetPduMode(App_DataValidateType LucDataValidate,
  uint8 LucExpControllerId, CanIf_PduSetModeType LddExpPduModeRequest);

extern boolean TestCanIf_GetTxConfirmationState(
  App_DataValidateType LucDataValidate, uint8 LucExpControllerId);

extern void TestSetCanIf_GetTxConfirStateRetVal(
  CanIf_NotifStatusType LenGetTxConfirmStateReturn);

extern void CanIf_TrcvModeIndication(uint8 Transceiver, CanTrcv_TrcvModeType OpMode);

extern void TestSetCanIf_TxPduIdForRet(PduIdType LddPduIdForRet);

extern Std_ReturnType CanIf_Transmit(PduIdType CanTxPduId,
  const PduInfoType *PduInfoPtr);

extern void TestCanIf_TransmitSetRetVal(Std_ReturnType LddRetVal);

extern boolean TestCanIf_Transmit(App_DataValidateType LucDataValidate,
  PduIdType ExpCanTxPduId, const PduInfoType *ExpPduInfoPtr);

extern boolean CanIfTest_ValidateData(PduInfoType* LddExpPduInfo,
  PduInfoType* LddActPduInfo);

extern boolean TestCanIf_TrcvModeIndication(App_DataValidateType LucDataValidate,
  uint8 LucExpTransceiver, CanTrcv_TrcvModeType LddExpOpMode);

extern void TestCanIf_DefaultBehavior(void);

extern void CanIf_Init(const CanIf_ConfigType* ConfigPtr);

extern boolean TestCanIf_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
  
extern Std_ReturnType CanIf_CheckTrcvWakeFlag( uint8 Transceiver); 

extern Std_ReturnType CanIf_ClearTrcvWufFlag( uint8 Transceiver); 

extern Std_ReturnType CanIf_ChangeBaudrate 
                                   ( uint8 ControllerId, const uint16 Baudrate);
                                   
extern Std_ReturnType CanIf_CheckBaudrate 
                                   ( uint8 ControllerId, const uint16 Baudrate);
                 
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

