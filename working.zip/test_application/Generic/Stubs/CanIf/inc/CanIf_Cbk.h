/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: CanIf_Cbk.h                                                   **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CanIf_Cbk Stub                                        **
**                                                                            **
**  PURPOSE   : Declaration of CanIf_Cbk functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
*******************************************************************************/

/*******************************************************************************
**                       CanIf Generation Tool Version                        **
*******************************************************************************/

/*******************************************************************************
**                         Input File                                         **
*******************************************************************************/
#ifndef CANIF_CBK_H
#define CANIF_CBK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/

/* AUTOSAR Specification Version Information */
#define CANIF_CBK_AR_RELEASE_MAJOR_VERSION  4
#define CANIF_CBK_AR_RELEASE_MINOR_VERSION  0
#define CANIF_CBK_AR_RELEASE_PATCH_VERSION  3

/*******************************************************************************
**                      Global Function Prototypes                            **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void CanIf_ControllerBusOff (uint8 Controller);

extern void CanIf_ControllerModeIndication (uint8 Controller, 
  CanIf_ControllerModeType ControllerMode);

extern void CanIf_RxIndication (Can_HwHandleType Hrh, Can_IdType CanId, 
  uint8 CanDlc, const uint8* CanSduPtr);

extern void CanIf_TxConfirmation(PduIdType CanTxPduId);

extern boolean TestCanIf_ControllerBusOff(App_DataValidateType LucDataValidate,
  uint8 LucExpController);

extern boolean TestCanIf_ControllerModeIndication 
  (App_DataValidateType LucDataValidate, uint8 LucExpController, 
  CanIf_ControllerModeType LddExpControllerMode);

extern boolean TestCanIf_RxIndication(App_DataValidateType LucDataValidate,
  Can_HwHandleType LddExpHrh, Can_IdType LddExpCanId, uint8 LddExpCanDlc, 
  const uint8 *ExpCanSduPtr);

extern boolean TestCanIf_TxConfirmation(
  App_DataValidateType LucDataValidate, PduIdType LddExpCanTxPduId);

extern boolean CanIfTest_CanRxValidateData(const uint8* LddExpCanSdu, 
  const uint8* LddActCanSdu, uint8 LucLength);

#endif /* CANIF_CBK_H */

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
