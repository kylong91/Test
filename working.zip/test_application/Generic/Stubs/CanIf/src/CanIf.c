/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**                                                                            **
**  SRC-MODULE: CanIf.c                                                       **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CanIf Stub                                            **
**                                                                            **
**  PURPOSE   : This application file contains the CanIf Stub functions       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "CanIf.h"
#include "CanIf_Cbk.h"
#ifdef CANSM_MODULE_ACTIVE
#include "CanSM_Cbk.h"
#endif
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#ifdef CANSM_MODULE_ACTIVE
uint8 GucCanSM_Value;
#endif    
uint8 CanIf_GucSetCtrlModeCount;
uint8 CanIf_GucSetCtrlModeCheckCount;
uint8 CanIf_GaaCtrlModeCtrlId[CANIF_ARRAY_SIZE];

uint8 CanIf_GucCheckBaudRateCheckCount;
uint8 CanIf_GucCheckBaudRateCount;
uint8 CanIf_GucSetTrcvModeCount;
uint8 CanIf_GucSetTrcvModeCheckCount;
uint8 CanIf_GucChangeBaudRateCount;
uint8 CanIf_GucChangeBaudRateCheckCount;
uint8 CanIf_GaaTrcvModeTrcvId[CANIF_ARRAY_SIZE];
CanTrcv_TrcvModeType CanIf_GaaTrcvMode[CANIF_ARRAY_SIZE];

uint8 CanIf_GaaCheckControllerID[CANIF_ARRAY_SIZE];
uint16 CanIf_GaaCheckBaudRate[CANIF_ARRAY_SIZE];
uint8 CanIf_GaaChangeControllerID[CANIF_ARRAY_SIZE];
uint16 CanIf_GaaChangeBaudRate[CANIF_ARRAY_SIZE];
uint8 CanIf_GucSetPduModeCount;
uint8 CanIf_GucSetPduModeCheckCount;
uint8 CanIf_GaaPduModeCtrlId[CANIF_ARRAY_SIZE];
CanIf_PduSetModeType CanIf_GaaPduMode[CANIF_ARRAY_SIZE];

uint8 CanIf_GucGetTxConfirmCount;
uint8 CanIf_GucGetTxConfirmCheckCount;
uint8 CanIf_GaaGetTxConfirmCtrlId[CANIF_ARRAY_SIZE];

CanIf_NotifStatusType CanIf_GenGetTxConfirmStateReturn =
  CANIF_TX_RX_NOTIFICATION;
  
PduIdType CanIf_GaaCanTxPduId[CANIF_ARRAY_SIZE];
PduIdType CanIf_GddPduIdForRet;
PduLengthType CanIf_GaaSduLength[CANIF_ARRAY_SIZE];
uint8 CanIf_GucTransmitCount;
uint8 CanIf_GucTransmitCheckCount;
uint8 CanIf_GaaTransmitData[CANIF_ARRAY_SIZE][CANIF_DATA_LENGTH];
Std_ReturnType CanIf_GddTransmitReturn;
Std_ReturnType CanIf_GddCancelTransmitReturn;

uint8 CanIf_GucCtrlBusOffCount;
uint8 CanIf_GucCtrlBusOffCheckCount;
uint8 CanIf_GaaCtrlBusOffCtrl[CANIF_ARRAY_SIZE];

uint8 CanIf_GucCtrlModeIndCount;
uint8 CanIf_GucCtrlModeIndCheckCount;
uint8 CanIf_GaaCtrlModeIndCtrl[CANIF_ARRAY_SIZE];
CanIf_ControllerModeType CanIf_GaaCtrlMode[CANIF_ARRAY_SIZE];

PduIdType Can_GaaTxConfCanTxPduId[CANIF_ARRAY_SIZE];
uint8 Can_GucTxConfCanTxPduIdCount;
uint8 Can_GucTxConfCanTxPduIdCheckCount;

Can_HwHandleType CanIf_GddHrh[CANIF_ARRAY_SIZE];
Can_IdType CanIf_GddCanId[CANIF_ARRAY_SIZE];
uint8 CanIf_GddCanDlc[CANIF_ARRAY_SIZE];
uint8 CanIf_GaaRxIndSduPtr[CANIF_ARRAY_SIZE][CANIF_DATA_LENGTH];
uint8 CanIf_GucRxIndCount;
uint8 CanIf_GucRxIndCheckCount;
uint8 CanIf_GucTrcvModeIndCount;
uint8 CanIf_GucClearTrcvWufFlagIndCount;
uint8 CanIf_GucTrcvModeIndCheckCount;
uint8 CanIf_GaaTrcvModeTransceiverId[CANIF_ARRAY_SIZE];
uint8 CanIf_GaaClearTrcvWufFlagTransceiverId[CANIF_ARRAY_SIZE];
CanTrcv_TrcvModeType CanIf_GaaTrcvOpMode[CANIF_ARRAY_SIZE];
uint8 CanIf_GaaCheckTrcvWufFlagTransceiverId[CANIF_ARRAY_SIZE];
uint8 CanIf_GucCheckTrcvWufFlagIndCount;

#ifdef BSWM_MODULE_ACTIVE
uint8 CanIf_GucInitSeqCnt;
uint8 CanIf_GucInitCnt;
#endif
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
**                       CanIf_SetControllerMode()                            **
*******************************************************************************/
Std_ReturnType CanIf_SetControllerMode(uint8 ControllerId,
CanIf_ControllerModeType ControllerMode)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual ControllerId and ControllerMode into Global variables */
  CanIf_GaaCtrlModeCtrlId[CanIf_GucSetCtrlModeCount] = ControllerId;
  CanIf_GaaCtrlMode[CanIf_GucSetCtrlModeCount] = ControllerMode;

  /* Increment count variable to handle multiple invocations */
  if(CanIf_GucSetCtrlModeCount < CANIF_ARRAY_SIZE)
  {
    CanIf_GucSetCtrlModeCount++;
  }
  #ifdef CANSM_MODULE_ACTIVE
  if(GucCanSM_Value == 0x01)
  {
    CanSM_ControllerModeIndication(ControllerId, ControllerMode);
  }
  #endif
	#endif /* TYPICAL_CONFIG */
  return(E_OK);
} /* End CanIf_SetControllerMode() */

/*******************************************************************************
**                       TestCanIf_SetControllerMode()                        **
*******************************************************************************/
boolean TestCanIf_SetControllerMode(App_DataValidateType LucDataValidate,
  uint8 LucExpControllerId, CanIf_ControllerModeType LddExpControllerMode)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ControllerId and ControllerMode */
      if((CanIf_GucSetCtrlModeCount == 0x01) &&
        (CanIf_GaaCtrlModeCtrlId[0] == LucExpControllerId) &&
        (CanIf_GaaCtrlMode[0] == LddExpControllerMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanIf_GucSetCtrlModeCount = 0;
      CanIf_GucSetCtrlModeCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanIf_GucSetCtrlModeCount; LucIndex++)
      {
        /* Validate ControllerId and ControllerMode */
        if((CanIf_GaaCtrlModeCtrlId[LucIndex] == LucExpControllerId) &&
          (CanIf_GaaCtrlMode[LucIndex] == LddExpControllerMode))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanIf_GucSetCtrlModeCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanIf_GucSetCtrlModeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanIf_GucSetCtrlModeCheckCount == CanIf_GucSetCtrlModeCount)
      {
        CanIf_GucSetCtrlModeCount = 0;
        CanIf_GucSetCtrlModeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanIf_GucSetCtrlModeCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestCanIf_SetControllerMode() */

/*******************************************************************************
**                       CanIf_SetTrcvMode()                           **
*******************************************************************************/
Std_ReturnType CanIf_SetTrcvMode(uint8 TransceiverId,
CanTrcv_TrcvModeType TransceiverMode)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual TransceiverId and TransceiverMode into Global variables */
  CanIf_GaaTrcvModeTrcvId[CanIf_GucSetTrcvModeCount] = TransceiverId;
  CanIf_GaaTrcvMode[CanIf_GucSetTrcvModeCount] = TransceiverMode;

  /* Increment count variable to handle multiple invocations */
  if(CanIf_GucSetTrcvModeCount < CANIF_ARRAY_SIZE)
  {
    CanIf_GucSetTrcvModeCount++;
  }
  #ifdef CANSM_MODULE_ACTIVE
  #if (STD_ON == CANSM_CANTRCV_SUPPORT)
  if(GucCanSM_Value == 0x01)
  {
    CanSM_TransceiverModeIndication(TransceiverId, TransceiverMode);
  }
  #endif
  #endif
	#endif /* TYPICAL_CONFIG */
  return(E_OK);
} /* End CanIf_SetTrcvMode() */

/*******************************************************************************
**                       TestCanIf_SetTrcvMode()                        **
*******************************************************************************/
boolean TestCanIf_SetTrcvMode(App_DataValidateType LucDataValidate,
  uint8 LucExpTransceiverId, CanTrcv_TrcvModeType LddExpTransceiverMode)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TransceiverId and TransceiverMode */
      if((CanIf_GucSetTrcvModeCount == 0x01) &&
        (CanIf_GaaTrcvModeTrcvId[0] == LucExpTransceiverId) &&
        (CanIf_GaaTrcvMode[0] == LddExpTransceiverMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanIf_GucSetTrcvModeCount = 0;
      CanIf_GucSetTrcvModeCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanIf_GucSetTrcvModeCount; LucIndex++)
      {
        /* Validate TransceiverId and TransceiverMode */
        if((CanIf_GaaTrcvModeTrcvId[LucIndex] == LucExpTransceiverId) &&
          (CanIf_GaaTrcvMode[LucIndex] == LddExpTransceiverMode))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanIf_GucSetTrcvModeCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanIf_GucSetTrcvModeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanIf_GucSetTrcvModeCheckCount == CanIf_GucSetTrcvModeCount)
      {
        CanIf_GucSetTrcvModeCount = 0;
        CanIf_GucSetTrcvModeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanIf_GucSetTrcvModeCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestCanIf_SetTrcvMode() */

/*******************************************************************************
**                       CanIf_SetPduMode()                                   **
*******************************************************************************/
Std_ReturnType CanIf_SetPduMode(uint8 ControllerId,
CanIf_PduSetModeType PduModeRequest)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual ControllerId and PduModeRequest into Global variables */
  CanIf_GaaPduModeCtrlId[CanIf_GucSetPduModeCount] = ControllerId;
  CanIf_GaaPduMode[CanIf_GucSetPduModeCount] = PduModeRequest;

  /* Increment count variable to handle multiple invocations */
  if(CanIf_GucSetPduModeCount < CANIF_ARRAY_SIZE)
  {
    CanIf_GucSetPduModeCount++;
  }
	#endif /* TYPICAL_CONFIG */
  return(E_OK);
} /* End CanIf_SetPduMode() */

/*******************************************************************************
**                       TestCanIf_SetPduMode()                               **
*******************************************************************************/
boolean TestCanIf_SetPduMode(App_DataValidateType LucDataValidate,
  uint8 LucExpControllerId, CanIf_PduSetModeType LddExpPduModeRequest)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ControllerId and PduModeRequest */
      if((CanIf_GucSetPduModeCount == 0x01) &&
        (CanIf_GaaPduModeCtrlId[0] == LucExpControllerId) &&
        (CanIf_GaaPduMode[0] == LddExpPduModeRequest))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanIf_GucSetPduModeCount = 0;
      CanIf_GucSetPduModeCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanIf_GucSetPduModeCount; LucIndex++)
      {
        /* Validate ControllerId and PduModeRequest */
        if((CanIf_GaaPduModeCtrlId[LucIndex] == LucExpControllerId) &&
          (CanIf_GaaPduMode[LucIndex] == LddExpPduModeRequest))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanIf_GucSetPduModeCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanIf_GucSetPduModeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanIf_GucSetPduModeCheckCount == CanIf_GucSetPduModeCount)
      {
        CanIf_GucSetPduModeCount = 0;
        CanIf_GucSetPduModeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanIf_GucSetPduModeCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestCanIf_SetPduMode() */

/*******************************************************************************
**                       CanIf_GetTxConfirmationState()                       **
*******************************************************************************/
CanIf_NotifStatusType CanIf_GetTxConfirmationState(uint8 ControllerId)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual ControllerId into Global variables */
  CanIf_GaaGetTxConfirmCtrlId[CanIf_GucGetTxConfirmCount] = ControllerId;

  /* Increment count variable to handle multiple invocations */
  if(CanIf_GucGetTxConfirmCount < CANIF_ARRAY_SIZE)
  {
    CanIf_GucGetTxConfirmCount++;
  }
  #endif /* TYPICAL_CONFIG */
  return(CanIf_GenGetTxConfirmStateReturn);
} /* End CanIf_GetTxConfirmationState() */

/*******************************************************************************
**                       TestCanIf_GetTxConfirmationState()                   **
*******************************************************************************/
boolean TestCanIf_GetTxConfirmationState(
  App_DataValidateType LucDataValidate, uint8 LucExpControllerId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation countand ControllerId */
      if((CanIf_GucGetTxConfirmCount == 0x01) &&
        (CanIf_GaaGetTxConfirmCtrlId[0] == LucExpControllerId))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanIf_GucGetTxConfirmCount = 0;
      CanIf_GucGetTxConfirmCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanIf_GucGetTxConfirmCount; LucIndex++)
      {
        /* Validate ControllerId */
        if(CanIf_GaaGetTxConfirmCtrlId[LucIndex] == LucExpControllerId)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanIf_GucGetTxConfirmCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanIf_GucGetTxConfirmCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanIf_GucGetTxConfirmCheckCount == CanIf_GucGetTxConfirmCount)
      {
        CanIf_GucGetTxConfirmCount = 0;
        CanIf_GucGetTxConfirmCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanIf_GucGetTxConfirmCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestCanIf_GetTxConfirmationState() */

/*******************************************************************************
**              TestCanIf_CanSM_CurrentStateBehavior()                         **
*******************************************************************************/
void TestSetCanIf_GetTxConfirStateRetVal(
  CanIf_NotifStatusType LenGetTxConfirmStateReturn)
{
  CanIf_GenGetTxConfirmStateReturn = LenGetTxConfirmStateReturn;
}

/*******************************************************************************
**                     TestSetCanIf_TxPduIdForRet()                           **
*******************************************************************************/
void TestSetCanIf_TxPduIdForRet(PduIdType LddPduIdForRet)
{
  CanIf_GddPduIdForRet = LddPduIdForRet;
} /* End TestSetCanIf_TxPduIdForRet() */

/*******************************************************************************
**                              CanIf_Transmit()                              **
*******************************************************************************/
Std_ReturnType CanIf_Transmit(PduIdType CanTxPduId,
const PduInfoType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  PduLengthType LddDataLength;
  uint8* LpSduDataPtr;
  
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  CanIf_GaaCanTxPduId[CanIf_GucTransmitCount] = CanTxPduId;
  CanIf_GaaSduLength[CanIf_GucTransmitCount] = PduInfoPtr->SduLength;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > CANIF_DATA_LENGTH)
  {
    LddDataLength = CANIF_DATA_LENGTH;    
  }
  else
  {
    LddDataLength = PduInfoPtr->SduLength;
  }
  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0; LucDataIndex < LddDataLength; LucDataIndex++)
  {
    CanIf_GaaTransmitData[CanIf_GucTransmitCount][LucDataIndex] = 
      *LpSduDataPtr;
    LpSduDataPtr++;
  }
  /* Increment count variable to handle multiple invocations */
  if(CanIf_GucTransmitCount != CANIF_ARRAY_SIZE)
  {    
    CanIf_GucTransmitCount++;
  }
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((CanIf_GddPduIdForRet == CanTxPduId) ||
    (CanIf_GddTransmitReturn == E_NOT_OK))
  {
    CanIf_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif
  #endif /* TYPICAL_CONFIG */
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(CanIf_GddTransmitReturn);
  #endif
} /* End CanIf_Transmit() */

/*******************************************************************************
**                            TestCanIf_Transmit()                            **
*******************************************************************************/
boolean TestCanIf_Transmit(App_DataValidateType LucDataValidate,
PduIdType ExpCanTxPduId, const PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((CanIf_GucTransmitCount == 0x01) && 
        (ExpCanTxPduId == CanIf_GaaCanTxPduId[0]))
      {
        ActPduInfo.SduLength = CanIf_GaaSduLength[0];
        ActPduInfo.SduDataPtr = &CanIf_GaaTransmitData[0][0];

        /* Validate SduLength and Data */
        if(CanIfTest_ValidateData((PduInfoType *)ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      CanIf_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanIf_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((CanIf_GucTransmitCheckCount <= CanIf_GucTransmitCount) &&
        (ExpCanTxPduId == CanIf_GaaCanTxPduId[CanIf_GucTransmitCheckCount]))
      {
        ActPduInfo.SduLength =
          CanIf_GaaSduLength[CanIf_GucTransmitCheckCount];
        ActPduInfo.SduDataPtr =
          &CanIf_GaaTransmitData[CanIf_GucTransmitCheckCount][0];

        /* Validate the SduLength and Data */
        if(CanIfTest_ValidateData((PduInfoType *)ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanIf_GucTransmitCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanIf_GucTransmitCheckCount == CanIf_GucTransmitCount)
      {
        CanIf_GucTransmitCount = 0;
        CanIf_GucTransmitCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < CanIf_GucTransmitCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpCanTxPduId == CanIf_GaaCanTxPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCanIf_Transmit() */

/*******************************************************************************
**                          TestCanIf_TransmitSetRetVal()                     **
*******************************************************************************/
void TestCanIf_TransmitSetRetVal(Std_ReturnType LddRetVal)
{
  CanIf_GddTransmitReturn = LddRetVal;
}/* End TestCanIf_TransmitSetRetVal() */

/*******************************************************************************
**                       CanIfTest_ValidateData()                             **
*******************************************************************************/
boolean CanIfTest_ValidateData(PduInfoType* LddExpPduInfo, 
PduInfoType* LddActPduInfo)
{
  uint8 *LpActualDataPtr;
  uint8 *LpExpDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  /* Load the ExpPduInfo to local variables */
  LddSduCount = LddExpPduInfo->SduLength;
  LpExpDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  /* Check the sdu length */
  if((LddExpPduInfo->SduLength <= CANIF_DATA_LENGTH) &&
    (LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }
   /* Check the sdu data */
  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    if(*LpActualDataPtr != *LpExpDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualDataPtr++;
    LpExpDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* End CanIfTest_ValidateData() */

/*******************************************************************************
**                       CanIf_ControllerBusOff()                             **
*******************************************************************************/
void CanIf_ControllerBusOff(uint8 Controller)
{
   #ifndef TYPICAL_CONFIG
  /* Load actual Controller into Global variables */
  CanIf_GaaCtrlBusOffCtrl[CanIf_GucCtrlBusOffCount] = Controller;

  /* Increment count variable to handle multiple invocations */
  if(CanIf_GucCtrlBusOffCount < CANIF_ARRAY_SIZE)
  {
    CanIf_GucCtrlBusOffCount++;
  }
  #endif /* TYPICAL_CONFIG */
} /* End CanIf_ControllerBusOff() */

/*******************************************************************************
**                       TestCanIf_ControllerBusOff()                         **
*******************************************************************************/
boolean TestCanIf_ControllerBusOff(App_DataValidateType LucDataValidate,
  uint8 LucExpController)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ControllerId and ControllerMode */
      if((CanIf_GucCtrlBusOffCount == 0x01) &&
        (CanIf_GaaCtrlBusOffCtrl[0] == LucExpController))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanIf_GucCtrlBusOffCount = 0;
      CanIf_GucCtrlBusOffCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanIf_GucCtrlBusOffCount; LucIndex++)
      {
        /* Validate ControllerId and ControllerMode */
        if(CanIf_GaaCtrlBusOffCtrl[LucIndex] == LucExpController)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanIf_GucCtrlBusOffCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanIf_GucCtrlBusOffCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanIf_GucCtrlBusOffCheckCount == CanIf_GucCtrlBusOffCount)
      {
        CanIf_GucCtrlBusOffCount = 0;
        CanIf_GucCtrlBusOffCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanIf_GucCtrlBusOffCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestCanIf_ControllerBusOff() */

/*******************************************************************************
**                       CanIf_ControllerModeIndication()                     **
*******************************************************************************/
void CanIf_ControllerModeIndication(uint8 Controller,
CanIf_ControllerModeType ControllerMode)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual Controller and ControllerMode into Global variables */
  CanIf_GaaCtrlModeIndCtrl[CanIf_GucCtrlModeIndCount] = Controller;
  CanIf_GaaCtrlMode[CanIf_GucCtrlModeIndCount] = ControllerMode;

  /* Increment count variable to handle multiple invocations */
  if(CanIf_GucCtrlModeIndCount < CANIF_ARRAY_SIZE)
  {
    CanIf_GucCtrlModeIndCount++;
  }
  #endif /* TYPICAL_CONFIG */
} /* End CanIf_ControllerModeIndication() */

/*******************************************************************************
**                       TestCanIf_ControllerModeIndication()                 **
*******************************************************************************/
boolean TestCanIf_ControllerModeIndication(App_DataValidateType LucDataValidate,
  uint8 LucExpController, CanIf_ControllerModeType LddExpControllerMode)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and ControllerMode */
      if((CanIf_GucCtrlModeIndCount == 0x01) &&
        (CanIf_GaaCtrlModeIndCtrl[0] == LucExpController) &&
        (CanIf_GaaCtrlMode[0] == LddExpControllerMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanIf_GucCtrlModeIndCount = 0;
      CanIf_GucCtrlModeIndCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanIf_GucCtrlModeIndCount; LucIndex++)
      {
        /* Validate Controller and ControllerMode */
        if((CanIf_GaaCtrlModeIndCtrl[LucIndex] == LucExpController) &&
          (CanIf_GaaCtrlMode[LucIndex] == LddExpControllerMode))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanIf_GucCtrlModeIndCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanIf_GucCtrlModeIndCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanIf_GucCtrlModeIndCheckCount == CanIf_GucCtrlModeIndCount)
      {
        CanIf_GucCtrlModeIndCount = 0;
        CanIf_GucCtrlModeIndCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanIf_GucCtrlModeIndCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestCanIf_ControllerModeIndication() */

/*******************************************************************************
**                          CanIf_RxIndication()                              **
*******************************************************************************/
void CanIf_RxIndication(Can_HwHandleType Hrh, Can_IdType CanId, uint8 CanDlc, 
  const uint8* CanSduPtr)
 {
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8 *LpSduPtr;
  
  /* Load actual Hrh, CanId and CanDlc into Global variables */
  CanIf_GddHrh[CanIf_GucRxIndCount] = Hrh;
  CanIf_GddCanId[CanIf_GucRxIndCount] = CanId;
  CanIf_GddCanDlc[CanIf_GucRxIndCount] = CanDlc;
  LpSduPtr = (uint8 *)CanSduPtr;

  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0x00; LucDataIndex < CanIf_GddCanDlc[CanIf_GucRxIndCount]; LucDataIndex++)
  {
    CanIf_GaaRxIndSduPtr[CanIf_GucRxIndCount][LucDataIndex] = *LpSduPtr;
    LpSduPtr++;
  }
    if(CanIf_GucRxIndCount != CANIF_ARRAY_SIZE)
  {    
    CanIf_GucRxIndCount++;
  }
  #endif /* TYPICAL_CONFIG */
} /* End CanIf_RxIndication()*/
/*******************************************************************************
**                       TestCanIf_RxIndication()                             **
*******************************************************************************/
boolean TestCanIf_RxIndication(App_DataValidateType LucDataValidate, 
  Can_HwHandleType ExpHrh, Can_IdType ExpCanId, uint8 ExpCanDlc, 
  const uint8* ExpCanSduPtr)
{
  boolean LblStepResult;
  uint8 *ActCanSdu;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((CanIf_GucRxIndCount == 0x01) && (ExpHrh == CanIf_GddHrh[0]) 
         && (ExpCanId == CanIf_GddCanId[0]) && 
         (ExpCanDlc == CanIf_GddCanDlc[0]))
      {
        ActCanSdu = &CanIf_GaaRxIndSduPtr[0][0];
        
        /* Validate SduLength and Data */
        if(CanIfTest_CanRxValidateData((uint8 *)ExpCanSduPtr, ActCanSdu, ExpCanDlc))
        {
          LblStepResult = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      CanIf_GucRxIndCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanIf_GucRxIndCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanIf_GucRxIndCount; LucIndex++)
      {
        if((ExpHrh == CanIf_GddHrh[LucIndex]) && (ExpCanId ==
           CanIf_GddCanId[LucIndex]) && (ExpCanDlc == CanIf_GddCanDlc[LucIndex]))
        {
          ActCanSdu = &CanIf_GaaRxIndSduPtr[LucIndex][0];

          if(CanIfTest_CanRxValidateData((uint8 *)ExpCanSduPtr, ActCanSdu, ExpCanDlc))
          {
            LblStepResult = STEP_PASSED;
          }
          LucIndex = CanIf_GucRxIndCount;
        } /* End if(ExpHrh == CanIf_GaaRxIndSduPtr[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < CanIf_GucRxIndCount; ...) */
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanIf_GucRxIndCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanIf_GucRxIndCount == CanIf_GucRxIndCheckCount)
      {
        CanIf_GucRxIndCount = 0;
        CanIf_GucRxIndCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    case M_NOT_INVOKED:
    {
      LblStepResult = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < CanIf_GucRxIndCount) &&
        (LblStepResult == STEP_PASSED); LucIndex++)
      {
        if((ExpHrh == CanIf_GddHrh[LucIndex]) && (ExpCanId ==  
           CanIf_GddCanId[LucIndex]) && (ExpCanDlc == CanIf_GddCanDlc[LucIndex]))
        {
          LblStepResult = STEP_FAILED;
        }
      }
      break;
    } /* End case M_NOT_INVOKED: */
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End TestCanIf_RxIndication() */

/*******************************************************************************
**                         CanIf_TxConfirmation()                             **
*******************************************************************************/
void CanIf_TxConfirmation(PduIdType CanTxPduId)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual PduId into Global variables */
  Can_GaaTxConfCanTxPduId[Can_GucTxConfCanTxPduIdCount] = CanTxPduId;
  /* Increment count variable to handle multiple invocations */
  if(Can_GucTxConfCanTxPduIdCount != CANIF_ARRAY_SIZE)
  {    
    Can_GucTxConfCanTxPduIdCount++;
  }
  #endif /* TYPICAL_CONFIG */
} /* End CanIf_TxConfirmation() */
/*******************************************************************************
**                       TestCanIf_TxConfirmation()                           **
*******************************************************************************/
boolean TestCanIf_TxConfirmation(App_DataValidateType LucDataValidate,
  PduIdType ExpCanTxPduId)
{
  boolean LblStepResult;
  uint8 LucIndex;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count and Id */
      if((Can_GucTxConfCanTxPduIdCount == 0x01) &&  
        (ExpCanTxPduId == Can_GaaTxConfCanTxPduId[0]))
      {
        LblStepResult = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Can_GucTxConfCanTxPduIdCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Can_GucTxConfCanTxPduIdCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Can_GucTxConfCanTxPduIdCount; LucIndex++)
      {
        if(ExpCanTxPduId == Can_GaaTxConfCanTxPduId[LucIndex])
        {
          LblStepResult = STEP_PASSED;          
          LucIndex = Can_GucTxConfCanTxPduIdCount;
        } /* End if(ExpCanTxPduId == Can_GaaTxConfCanTxPduId[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < Can_GucTxConfCanTxPduIdCount;...) */
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Can_GucTxConfCanTxPduIdCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Can_GucTxConfCanTxPduIdCount == Can_GucTxConfCanTxPduIdCheckCount)
      {
        Can_GucTxConfCanTxPduIdCount = 0;
        Can_GucTxConfCanTxPduIdCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    case M_NOT_INVOKED:
    {
      LblStepResult = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < Can_GucTxConfCanTxPduIdCount) &&
        (LblStepResult == STEP_PASSED); LucIndex++)
      {
        if(ExpCanTxPduId == Can_GaaTxConfCanTxPduId[LucIndex])
        {
          LblStepResult = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End TestCanIf_TxConfirmation() */

/*******************************************************************************
**                         CanIf_TrcvModeIndication()                         **
*******************************************************************************/
void CanIf_TrcvModeIndication(uint8 Transceiver, CanTrcv_TrcvModeType OpMode)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual Transceiver and OpMode into Global variables */
  CanIf_GaaTrcvModeTransceiverId[CanIf_GucTrcvModeIndCount] = Transceiver;
  CanIf_GaaTrcvOpMode[CanIf_GucTrcvModeIndCount] = OpMode;
  CanIf_GucTrcvModeIndCount++;
  #endif /* TYPICAL_CONFIG */
} /* End CanIf_TrcvModeIndication() */

/*******************************************************************************
**                       TestCanIf_TrcvModeIndication()                       **
*******************************************************************************/
boolean TestCanIf_TrcvModeIndication(App_DataValidateType LucDataValidate,
  uint8 LucExpTransceiver, CanTrcv_TrcvModeType LddExpOpMode)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and ControllerMode */
      if((CanIf_GucTrcvModeIndCount == 0x01) &&
        (CanIf_GaaTrcvModeTransceiverId[0] == LucExpTransceiver) &&
        (CanIf_GaaTrcvOpMode[0] == LddExpOpMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanIf_GucTrcvModeIndCount = 0;
      CanIf_GucTrcvModeIndCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanIf_GucTrcvModeIndCount; LucIndex++)
      {
        /* Validate Controller and ControllerMode */
        if((CanIf_GaaTrcvModeTransceiverId[LucIndex] == LucExpTransceiver) &&
          (CanIf_GaaTrcvOpMode[LucIndex] == LddExpOpMode))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanIf_GucTrcvModeIndCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanIf_GucTrcvModeIndCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanIf_GucTrcvModeIndCheckCount == CanIf_GucTrcvModeIndCount)
      {
        CanIf_GucTrcvModeIndCount = 0;
        CanIf_GucTrcvModeIndCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanIf_GucTrcvModeIndCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestCanIf_TrcvModeIndication() */

/*******************************************************************************
**                       CanIfTest_CanRxValidateData()                        **
*******************************************************************************/
boolean CanIfTest_CanRxValidateData(const uint8* LpExpCanSdu, 
  const uint8* LpActCanSdu, uint8 LucLength)
{
  uint8 LucCount;
  boolean LblReturnValue;
  
  LblReturnValue = TRUE;
  LucCount = 0;

  while((LblReturnValue != FALSE) && (LucCount < LucLength))
  {
    if(*LpActCanSdu != *LpExpCanSdu)
    {
      LblReturnValue = FALSE;
    }
    LpActCanSdu++;
    LpExpCanSdu++;
    LucCount++;
  }
  return(LblReturnValue);
} /* End CanIfTest_CanRxValidateData()  */

/*******************************************************************************
**                       CanIf_CheckTrcvWakeFlag()                            **
*******************************************************************************/

Std_ReturnType CanIf_CheckTrcvWakeFlag( uint8 Transceiver)
{
  Std_ReturnType LddRetunVal;
  CanIf_GaaCheckTrcvWufFlagTransceiverId[CanIf_GucCheckTrcvWufFlagIndCount] = 
                                                                    Transceiver;
  if(CanIf_GucCheckTrcvWufFlagIndCount < CANIF_ARRAY_SIZE)
  {
    CanIf_GucCheckTrcvWufFlagIndCount++;
  }
LddRetunVal = E_OK;
return(LddRetunVal);
}
/*******************************************************************************
**                       TestCanIf_CheckTrcvWufFlag                           **
*******************************************************************************/
boolean TestCanIf_CheckTrcvWufFlag(App_DataValidateType LucDataValidate,
                                                      uint8 LucExpTransceiverId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TransceiverId and TransceiverMode */
      if((CanIf_GucCheckTrcvWufFlagIndCount == 0x01) &&
        (CanIf_GaaClearTrcvWufFlagTransceiverId[0] == LucExpTransceiverId))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanIf_GucCheckTrcvWufFlagIndCount = 0;
      CanIf_GucSetTrcvModeCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanIf_GucCheckTrcvWufFlagIndCount; LucIndex++)
      {
        /* Validate TransceiverId and TransceiverMode */
        if((CanIf_GaaTrcvModeTrcvId[LucIndex] == LucExpTransceiverId))
          
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanIf_GucCheckTrcvWufFlagIndCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanIf_GucSetTrcvModeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanIf_GucSetTrcvModeCheckCount == CanIf_GucCheckTrcvWufFlagIndCount)
      {
        CanIf_GucCheckTrcvWufFlagIndCount = 0;
        CanIf_GucSetTrcvModeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanIf_GucCheckTrcvWufFlagIndCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestCanIf_SetTrcvMode() */


/*******************************************************************************
**                       CanIf_ClearTrcvWufFlag()                             **
*******************************************************************************/
Std_ReturnType CanIf_ClearTrcvWufFlag( uint8 Transceiver)
{
  Std_ReturnType LddRetunVal;
  CanIf_GaaClearTrcvWufFlagTransceiverId[CanIf_GucClearTrcvWufFlagIndCount] = 
                                                                    Transceiver;
  if(CanIf_GucClearTrcvWufFlagIndCount < CANIF_ARRAY_SIZE)
  {
    CanIf_GucClearTrcvWufFlagIndCount++;
  }
LddRetunVal = E_OK;
return(LddRetunVal);
}

/*******************************************************************************
**                       TestCanIf_ClearTrcvWufFlag                           **
*******************************************************************************/
boolean TestCanIf_ClearTrcvWufFlag(App_DataValidateType LucDataValidate,
                                                      uint8 LucExpTransceiverId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TransceiverId and TransceiverMode */
      if((CanIf_GucClearTrcvWufFlagIndCount == 0x01) &&
        (CanIf_GaaClearTrcvWufFlagTransceiverId[0] == LucExpTransceiverId))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanIf_GucClearTrcvWufFlagIndCount = 0;
      CanIf_GucSetTrcvModeCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanIf_GucClearTrcvWufFlagIndCount; LucIndex++)
      {
        /* Validate TransceiverId and TransceiverMode */
        if((CanIf_GaaTrcvModeTrcvId[LucIndex] == LucExpTransceiverId))
          
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanIf_GucClearTrcvWufFlagIndCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanIf_GucSetTrcvModeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanIf_GucSetTrcvModeCheckCount == CanIf_GucClearTrcvWufFlagIndCount)
      {
        CanIf_GucClearTrcvWufFlagIndCount = 0;
        CanIf_GucSetTrcvModeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanIf_GucClearTrcvWufFlagIndCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestCanIf_SetTrcvMode() */


/*******************************************************************************
**                        CanIf_ChangeBaudrate()                              **
*******************************************************************************/
Std_ReturnType CanIf_ChangeBaudrate( uint8 ControllerId, const uint16 Baudrate)
{
 
 /* Load actual TransceiverId and TransceiverMode into Global variables */
  CanIf_GaaChangeControllerID[CanIf_GucChangeBaudRateCount] = ControllerId;
  CanIf_GaaChangeBaudRate[CanIf_GucChangeBaudRateCount] = Baudrate;
 /* Increment count variable to handle multiple invocations */
  if(CanIf_GaaChangeBaudRate[CanIf_GucChangeBaudRateCount] > 1000)
  {
     return(E_NOT_OK);
  }
  if(CanIf_GucChangeBaudRateCount < CANIF_ARRAY_SIZE)
  {
    CanIf_GucChangeBaudRateCount++;
  }
  return(E_OK);
}

/*******************************************************************************
**                       TestCanIf_ChangeBaudrate()                           **
*******************************************************************************/
boolean TestCanIf_ChangeBaudrate(App_DataValidateType LucDataValidate,
  uint8 LucExpControllerId, const uint16 LddBaudrate)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TransceiverId and TransceiverMode */
      if((CanIf_GucChangeBaudRateCount == 0x01) &&
        (CanIf_GaaChangeControllerID[0] == LucExpControllerId) &&
        (CanIf_GaaChangeBaudRate[0] == LddBaudrate))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanIf_GucChangeBaudRateCount = 0;
      CanIf_GucChangeBaudRateCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanIf_GucChangeBaudRateCount; LucIndex++)
      {
        /* Validate TransceiverId and TransceiverMode */
        if((CanIf_GaaChangeControllerID[LucIndex] == LucExpControllerId) &&
          (CanIf_GaaChangeBaudRate[LucIndex] == LddBaudrate))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanIf_GucChangeBaudRateCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanIf_GucChangeBaudRateCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanIf_GucChangeBaudRateCheckCount == CanIf_GucChangeBaudRateCount)
      {
        CanIf_GucChangeBaudRateCount = 0;
        CanIf_GucChangeBaudRateCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanIf_GucChangeBaudRateCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestCanIf_SetTrcvMode() */


/*******************************************************************************
**                        CanIf_CheckBaudrate()                               **
*******************************************************************************/
Std_ReturnType CanIf_CheckBaudrate( uint8 ControllerId, const uint16 Baudrate)
{
 
 /* Load actual TransceiverId and TransceiverMode into Global variables */
  CanIf_GaaCheckControllerID[CanIf_GucCheckBaudRateCount] = ControllerId;
  CanIf_GaaCheckBaudRate[CanIf_GucCheckBaudRateCount] = Baudrate;
 /* Increment count variable to handle multiple invocations */
  if(CanIf_GaaCheckBaudRate[CanIf_GucCheckBaudRateCount] > 1000)
  {
     return(E_NOT_OK);
  }
  if(CanIf_GucCheckBaudRateCount < CANIF_ARRAY_SIZE)
  {
    CanIf_GucCheckBaudRateCount++;
  }
  return(E_OK);
}
/*******************************************************************************
**                       TestCanIf_ChangeBaudrate()                           **
*******************************************************************************/
boolean TestCanIf_CheckBaudrate(App_DataValidateType LucDataValidate,
  uint8 LucExpControllerId, const uint16 LddBaudrate)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TransceiverId and TransceiverMode */
      if((CanIf_GucCheckBaudRateCount == 0x01) &&
        (CanIf_GaaCheckControllerID[0] == LucExpControllerId) &&
        (CanIf_GaaCheckBaudRate[0] == LddBaudrate))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanIf_GucCheckBaudRateCount = 0;
      CanIf_GucCheckBaudRateCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanIf_GucCheckBaudRateCount; LucIndex++)
      {
        /* Validate TransceiverId and TransceiverMode */
        if((CanIf_GaaCheckControllerID[LucIndex] == LucExpControllerId) &&
          (CanIf_GaaCheckBaudRate[LucIndex] == LddBaudrate))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanIf_GucCheckBaudRateCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanIf_GucCheckBaudRateCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanIf_GucCheckBaudRateCheckCount == CanIf_GucCheckBaudRateCount)
      {
        CanIf_GucCheckBaudRateCount = 0;
        CanIf_GucCheckBaudRateCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanIf_GucCheckBaudRateCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestCanIf_SetTrcvMode() */

/*******************************************************************************
**                        TestCanIf_DefaultBehavior()                         **
*******************************************************************************/
void TestCanIf_DefaultBehavior(void)
{ 
  CanIf_GucSetCtrlModeCount = 0;
  CanIf_GucSetCtrlModeCheckCount = 0;
  CanIf_GucSetTrcvModeCount = 0;
  CanIf_GucSetTrcvModeCheckCount = 0;
  CanIf_GucSetPduModeCount = 0;
  CanIf_GucSetPduModeCheckCount = 0;
  CanIf_GucGetTxConfirmCount = 0;
  CanIf_GucGetTxConfirmCheckCount = 0;
  CanIf_GddTransmitReturn = E_OK;
  CanIf_GucTransmitCount = 0;
  CanIf_GucTransmitCheckCount = 0;
  CanIf_GddPduIdForRet = (PduIdType)0xFF;
  CanIf_GenGetTxConfirmStateReturn = CANIF_TX_RX_NOTIFICATION;
  CanIf_GucCtrlBusOffCount = 0;
  CanIf_GucCtrlBusOffCheckCount = 0;
  CanIf_GucCtrlModeIndCount = 0;
  CanIf_GucCtrlModeIndCheckCount = 0;
  Can_GucTxConfCanTxPduIdCount = 0;
  Can_GucTxConfCanTxPduIdCheckCount = 0;
  CanIf_GucRxIndCount = 0;
  CanIf_GucRxIndCheckCount = 0;
  CanIf_GucTrcvModeIndCount = 0;
  CanIf_GucTrcvModeIndCheckCount = 0;
  CanIf_GucClearTrcvWufFlagIndCount = 0;
  CanIf_GucCheckTrcvWufFlagIndCount = 0;
  CanIf_GucChangeBaudRateCheckCount = 0;
  CanIf_GucChangeBaudRateCount = 0;
  CanIf_GucCheckBaudRateCheckCount = 0;
  CanIf_GucCheckBaudRateCount = 0;
} 

#ifdef BSWM_MODULE_ACTIVE

/*******************************************************************************
**                          CanIf_Init()                                      **
*******************************************************************************/

void CanIf_Init(const CanIf_ConfigType* ConfigPtr)
{
  UNUSED(ConfigPtr);
	App_GucApiSeqCnt++;
	CanIf_GucInitSeqCnt = App_GucApiSeqCnt;
	CanIf_GucInitCnt++;
}/* End CanIf_Init() */

/*******************************************************************************
**                           TestCanIf_Init()                                 **
*******************************************************************************/
boolean TestCanIf_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(CanIf_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      CanIf_GucInitCnt = 0;
      CanIf_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(CanIf_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      CanIf_GucInitCnt = 0;
      CanIf_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanIf_Init() */

#endif
/*******************************************************************************  
**                       CanIfCancelTransmit()                               **
*******************************************************************************/
Std_ReturnType CanIfCancelTransmit(PduIdType id)
{
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  CanIf_GaaCanTxPduId[CanIf_GucTransmitCount] = id;
  /* Increment count variable to handle multiple invocations */
  if(CanIf_GucTransmitCount != CANIF_ARRAY_SIZE)
  {    
    CanIf_GucTransmitCount++;
  }
  
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((CanIf_GddPduIdForRet == id) ||
    (CanIf_GddCancelTransmitReturn == E_NOT_OK))
  {
    CanIf_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(CanIf_GddCancelTransmitReturn);
  #endif
}
/*******************************************************************************
**                            TestCanIfCancelTransmit()                       **
*******************************************************************************/
boolean TestCanIfCancelTransmit(App_DataValidateType LucDataValidate,
  PduIdType ExpCanIfTxSduId)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((CanIf_GucTransmitCount == 0x01) && 
        (ExpCanIfTxSduId == CanIf_GaaCanTxPduId[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      CanIf_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanIf_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCanIfCancelTransmit() */

/*******************************************************************************
**                          TestCanIf_CancelTransmitSetRetVal()                **
*******************************************************************************/
void TestCanIf_CancelTransmitSetRetVal(Std_ReturnType LddRetVal)
{
  CanIf_GddCancelTransmitReturn = LddRetVal;
}/* End TestCanIf_CancelTransmitSetRetVal() */


/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
