/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE:  App_Dbg.c                                                    **
**                                                                            **
**  TARGET    :  All                                                          **
**                                                                            **
**  PRODUCT   : AUTOSAR DBG Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the DBG Stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/
/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
/*******************************************************************************
**                     Include Section                                        **
*******************************************************************************/
#include "App_Dbg.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
const uint8 DbgApp_GucTestDebugVar_0 = 0x02;
const uint16 DbgApp_GusTestDebugVar_1 = 0x1654;
const uint32 DbgApp_GulTestDebugVar_2 = 0x25896417;
const uint8 DbgApp_GaaTestDebugVar_2[10] = 
{0xAA, 0xAB, 0xAC, 0xAD, 0xAE, 0xAF, 0xBA, 0xBB, 0xBC, 0xBD};
const uint8 DbgApp_GaaTestDebugVar_3[2] = {0x01, 0x02};
const uint16 DbgApp_GaaTestDebugVar_4[2] = {0x1456, 0x8796};
const uint8 DbgApp_GucTestDebugVar_5 = 0x03;
const uint8 DbgApp_GucTestDebugVar_6 = 0x04;
const uint8 DbgApp_GucTestDebugVar_7 = 0x05;
const uint8 DbgApp_GucTestDebugVar_8 = 0x06;
const uint8 DbgApp_GucTestDebugVar_9 = 0x07;
const uint8 RunnableEntity_0_ServiceSwComponentType_0 = 0xFF;

uint8 Rte_GucRPortPrototype_0_ArgumentDataPrototype_0_ServiceSwComponentType_0 = 0xAB;
uint8 Rte_GucRPortPrototype_1_VariableDataPrototype_0_ServiceSwComponentType_0 = 0xFF;
AppDebugStructType 
Rte_GstRPortPrototype_1_VariableDataPrototype_1_ServiceSwComponentType_0 = 
{0x00ABCDEF, 0x1122, 0xFF};

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
