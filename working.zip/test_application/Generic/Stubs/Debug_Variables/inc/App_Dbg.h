/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: App_Dbg.h                                                     **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR DBG Stub                                              **
**                                                                            **
**  PURPOSE   : Declaration of DBG Stub functions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef APP_DBG_H
#define APP_DBG_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Std_Types.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/

/*******************************************************************************
**                      Type Definitions                                      **
*******************************************************************************/
typedef struct
{
 uint32 ulData;
 uint16 usData;
 uint8 ucData;
}AppDebugStructType;

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
extern const uint8 DbgApp_GucTestDebugVar_0;
extern const uint16 DbgApp_GusTestDebugVar_1;
extern const uint32 DbgApp_GulTestDebugVar_2;
extern const uint8 DbgApp_GaaTestDebugVar_2[10];
extern const uint8 DbgApp_GaaTestDebugVar_3[2];
extern const uint16 DbgApp_GaaTestDebugVar_4[2];
extern const uint8 DbgApp_GucTestDebugVar_5;
extern const uint8 DbgApp_GucTestDebugVar_6;
extern const uint8 DbgApp_GucTestDebugVar_7;
extern const uint8 DbgApp_GucTestDebugVar_8;
extern const uint8 DbgApp_GucTestDebugVar_9;
extern const uint8 RunnableEntity_0_ServiceSwComponentType_0;
extern uint8 Rte_GucRPortPrototype_0_ArgumentDataPrototype_0_ServiceSwComponentType_0;
extern uint8 Rte_GucRPortPrototype_1_VariableDataPrototype_0_ServiceSwComponentType_0;
extern AppDebugStructType Rte_GstRPortPrototype_1_VariableDataPrototype_1_ServiceSwComponentType_0;

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/


#endif /* End of APP_DBG_H */
/*******************************************************************************
**                       End of File                                          **
*******************************************************************************/
