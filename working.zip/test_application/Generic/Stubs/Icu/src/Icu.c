/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Icu.c                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Icu Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Icu Stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     13-Dec-2012   Shanthi    Creation of Icu.c module                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Icu.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Icu_GucEnableCount;
uint8 Icu_GucDisableCount;
uint8 Icu_GucEnCheckCount; 
uint8 Icu_GucDisCheckCount;
Icu_ChannelType GddIcuEnChannelId[ICU_ARRAY_SIZE];
Icu_ChannelType GddIcuDisChannelId[ICU_ARRAY_SIZE];
#ifdef ECUM_MODULE_ACTIVE
uint8 Icu_GucConfigData;
uint8 Icu_GucInitSeqCnt;
uint8 Icu_GucInitCount;
#endif
/*******************************************************************************
**                       Icu_EnableNotification()                             **
*******************************************************************************/
void Icu_EnableNotification(Icu_ChannelType Channel)
{
  GddIcuEnChannelId[Icu_GucEnableCount] = Channel;
  /* Increment count variable to handle multiple invocations */
  Icu_GucEnableCount++;
} /* End Icu_EnableNotification */

/*******************************************************************************
**                        TestIcu_EnableNotification()                        **
*******************************************************************************/
boolean TestIcu_EnableNotification(App_DataValidateType LucDataValidate,
  Icu_ChannelType ExpChannelId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation ExpChannelId */
      if((Icu_GucEnableCount == 0x01) && (GddIcuEnChannelId[0] == ExpChannelId))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Icu_GucEnableCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Icu_GucEnableCount; LucIndex++)
      {
        /* Validate Network and Current State */
        if(GddIcuEnChannelId[LucIndex] == ExpChannelId)
        {
          LblStepResult = STEP_PASSED;          
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Icu_GucEnableCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Icu_GucEnCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Icu_GucEnCheckCount == Icu_GucEnableCount)
      {
        Icu_GucEnableCount = 0;
        Icu_GucEnCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Icu_GucEnableCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End */

/*******************************************************************************
**                       Icu_DisableNotification()                            **
*******************************************************************************/
void Icu_DisableNotification(Icu_ChannelType Channel)
{
  GddIcuDisChannelId[Icu_GucDisableCount] = Channel;
  /* Increment count variable to handle multiple invocations */
  Icu_GucDisableCount++;
} /* End Icu_EnableNotification */

/*******************************************************************************
**                        TestIcu_EnableNotification()                        **
*******************************************************************************/
boolean TestIcu_DisableNotification(App_DataValidateType LucDataValidate,
  Icu_ChannelType ExpChannelId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation ExpChannelId */
      if((Icu_GucDisableCount == 0x01) && (GddIcuDisChannelId[0] == ExpChannelId))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Icu_GucDisableCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Icu_GucDisableCount; LucIndex++)
      {
        /* Validate Network and Current State */
        if(GddIcuDisChannelId[LucIndex] == ExpChannelId)
        {
          LblStepResult = STEP_PASSED;          
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Icu_GucDisableCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Icu_GucDisCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Icu_GucDisCheckCount == Icu_GucDisableCount)
      {
        Icu_GucDisableCount = 0;
        Icu_GucDisCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Icu_GucDisableCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End */
#ifdef ECUM_MODULE_ACTIVE

/*******************************************************************************
**                         Icu_Init()                                         **
*******************************************************************************/
void Icu_Init(const Icu_ConfigType *ConfigPtr)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Icu_GucInitSeqCnt = App_GucApiSeqCnt;
  Icu_GucInitCount++;
  if (ConfigPtr != NULL_PTR)
  {
    Icu_GucConfigData = (ConfigPtr->dummy);
  }
  #endif
}
/*******************************************************************************
**                        TestIcu_Init()                                      **
*******************************************************************************/
boolean TestIcu_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, uint8 LucData)
{
  boolean LblStepResult;  
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Icu_GucInitCount == 0x01) && 
        (Icu_GucConfigData == LucData))
      {
        LblStepResult = STEP_PASSED;
      }
      Icu_GucInitCount = 0;
      Icu_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if((Icu_GucInitSeqCnt == LucSeqNo) && 
        (Icu_GucConfigData == LucData))
      {
        LblStepResult = STEP_PASSED;
      }
      Icu_GucInitSeqCnt = 0;
      Icu_GucInitCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */    
    
  return(LblStepResult);
} /* End TestIcu_Init() */
#endif
/*******************************************************************************
**              TestDet_DefaultBehavior()                                     **
*******************************************************************************/
void TestIcu_DefaultBehavior(void)
{
  Icu_GucEnableCount = 0;
  Icu_GucDisableCount = 0;
  Icu_GucEnCheckCount = 0;
  Icu_GucDisCheckCount =0;
  #ifdef ECUM_MODULE_ACTIVE
  Icu_GucConfigData = 0;
  Icu_GucInitSeqCnt = 0;
  Icu_GucInitCount = 0;
  #endif
}
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
