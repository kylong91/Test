/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Icu.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Icu Stub                                              **
**                                                                            **
**  PURPOSE   : Declaration of Icu Stub functions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By          Description                            **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/

#ifndef ICU_H
#define ICU_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define ICU_AR_RELEASE_MAJOR_VERSION        0x04
#define ICU_AR_RELEASE_MINOR_VERSION        0x00
#define ICU_AR_RELEASE_REVISION_VERSION     0x03

/* Software Version Information */
#define ICU_SW_MAJOR_VERSION         1
#define ICU_SW_MINOR_VERSION         0

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define ICU_ARRAY_SIZE            255
typedef uint8 Icu_ChannelType;
#define IcuConfigSet0 &Icu_GaaConfig[0]
#define IcuConfigSet1 &Icu_GaaConfig[1]
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/* Dummy Structure for Icu_ConfigType */
typedef struct STag_Icu_ConfigType
{
  uint8 dummy;
}Icu_ConfigType;
extern const Icu_ConfigType Icu_GaaConfig[2];
extern uint8 Icu_GucConfigData;
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void Icu_Init(const Icu_ConfigType *ConfigPtr);
extern boolean TestIcu_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, uint8 LucData);
extern void Icu_EnableNotification(Icu_ChannelType Channel);

extern void Icu_DisableNotification(Icu_ChannelType Channel);

extern void TestIcu_DefaultBehavior(void);

extern boolean TestIcu_EnableNotification(App_DataValidateType LucDataValidate,
  Icu_ChannelType ExpChannelId);
  
extern boolean TestIcu_DisableNotification(App_DataValidateType LucDataValidate,
  Icu_ChannelType ExpChannelId);
#endif /* End ICU_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

