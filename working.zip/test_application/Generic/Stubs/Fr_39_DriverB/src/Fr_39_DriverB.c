/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Fr_DriverB.c                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Fr_DriverB Stub                                       **
**                                                                            **
**  PURPOSE   : This application file contains the Fr_DriverB Stub functions  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Fr_39_DriverB.h"
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
  uint8 Fr_GucDrvbBCtrlIdx =0;
  uint8 Fr_GucDrvBStartCommunication =0;
  uint8 Fr_GucDrvBHaltCommunication =0;
  uint8 Fr_GucDrvBAbortCommunication =0;
  uint8 Fr_GucDrvBAllowColdstart =0;
  uint8 Fr_GucDrvBAllSlots =0;
  uint8 Fr_GucDrvBControllerInit =0;
  uint8 Fr_GucDrvBAbsTimerIdx =0;
  uint8 Fr_GucDrvBcycle =0;
  uint16 Fr_GusDrvBOffset =0;
  uint8 Fr_GucDrvBAbsoluteTimer =0;
  uint8 Fr_GucDrvBEnableAbsoluteTimerIRQ =0;
  uint8 Fr_GucDrvBGetAbsoluteTimerIRQStatus=0;
  uint8 Fr_GucDrvBDisableAbsoluteTimerIRQ =0 ;
  boolean* Fr_GpDrvBBIRQStatusPtr =0;
  Fr_ChannelType Fr_GddDrvBChnlIdx =0;
  uint8 Fr_GucDrvBSetWakeupChannel =0;
  uint8 Fr_GucDrvBSendWUP =0;
  uint8 Fr_GucDvrBTransceivermodecount =0;
  uint8 Fr_GucDrvBGetChannelStatus =0;
  uint16* Fr_GpDrvBChannelAStatusPtr =0;
  uint16* Fr_GpDrvBChannelBStatusPtr =0;
  sint16* FrIf_GpDrvBRateCorrectionPtr =0;
  sint32* FrIf_GpDrvBOffsetCorrectionPtr =0;
  uint8 GucDrvBGetClockCorrection =0;
  uint8 Fr_GucDrvBListSize =0;
  uint16* Fr_GpDrvBChannelAEvenListPtr =0;
  uint16* Fr_GpDrvBChannelBEvenListPtr =0;
  uint16* Fr_GpDrvBChannelAOddListPtr =0;
  uint16* Fr_GpDrvBChannelBOddListPtr =0;
  uint8 Fr_GucDrvBGetSyncFrameList =0;
  uint8* Fr_GpDrvBNumOfStartupFramesPtr =0;
  uint8 Fr_GucDrvBGetNumOfStartupFrames =0;
  uint16 Fr_GusDrvBLPduIdx =0; 
  uint8* Fr_GpDrvBWakeupRxStatusPtr =0;
  uint8 Fr_GucDrvBGetWakeupRxStatus =0;
  uint16 Fr_GusDrvBFrameId =0;
  uint8 Fr_GucDrvBCycleRepetition =0; 
  uint8 Fr_GucDrvBCycleOffset =0;
  uint8 Fr_GucDrvBPayloadLength =0;
  uint16 Fr_GusDrvBHeaderCRC =0;
  uint8 Fr_GucDrvBReconfigLPdu =0;
  uint8* Fr_GpDrvBNmVectorPtr =0;
  uint8 Fr_GucDrvBGetNmVector =0;
  uint8 Fr_GucDrvBConfigParamIdx =0;
  uint8 Fr_GucDrvBReadCCConfig =0;
  Fr_POCStatusType* Fr_GpDrvBPOCStatusPtr =0; 
  uint8 Fr_GucDrvBGetPOCStatus =0;
  uint8* Fr_GpDrvBCyclePtr =0;
  uint16* Fr_GpDrvBMacroTickPtr =0;
  uint8 Fr_GucDrvBGetGlobalTime =0;
  uint8 Fr_GucDrvBAckAbsoluteTimerIRQ =0;
  uint8 Fr_GucDrvBCancelAbsoluteTimer =0;
  uint8* Fr_GpDrvBLSduPtr;
  uint32* Fr_GpDrvBConfigParamValuePtr;
  uint8 Fr_GucDrvBPrepareLPdu = 0;
  uint8 Fr_GucDrvBCheckTxLPduStatus = 0;
  uint8 Fr_GucDrvBReceiveRxLPdu = 0;
  uint8 Fr_GpDrvBLSduLength = 0;
  uint8 Fr_GucDrvBTransmitTxLPdu = 0;
  uint8 Fr_GucDrvBDisableLPdu = 0;
  uint8 Fr_GucDrvBCancelTxLPdu = 0;
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
**                         TestFr_39_DriverBControllerInit()                  **
*******************************************************************************/
boolean TestFr_39_DriverBControllerInit(App_DataValidateType LddDataValidate,
                                                               uint8 Fr_CtrlIdx)
{
    boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBControllerInit == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBControllerInit = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBControllerInit == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvBControllerInit = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

Std_ReturnType Fr_39_DriverB_ControllerInit(uint8 Fr_CtrlIdx)
{
Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
Fr_GucDrvBControllerInit++;
return 1;
 }

Std_ReturnType Fr_39_DriverB_AckAbsoluteTimerIRQ(uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx)
{
     Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvBAbsTimerIdx = Fr_AbsTimerIdx;
    Fr_GucDrvBAckAbsoluteTimerIRQ++;
 return 1;
 }
 
/*******************************************************************************
**                         TestFr_39_DriverBAckAbsoluteTimerIRQ()             **
*******************************************************************************/
boolean TestFr_39_DriverBAckAbsoluteTimerIRQ(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBAckAbsoluteTimerIRQ == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucDrvBAbsTimerIdx == Fr_AbsTimerIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBAckAbsoluteTimerIRQ = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBAckAbsoluteTimerIRQ == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvBAckAbsoluteTimerIRQ = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

Std_ReturnType Fr_39_DriverB_CancelAbsoluteTimer(uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx)
{
    Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvBAbsTimerIdx = Fr_AbsTimerIdx;
    Fr_GucDrvBCancelAbsoluteTimer++;
 return 1;
}
/*******************************************************************************
**                         TestFr_39_DriverBCancelAbsoluteTimer()             **
*******************************************************************************/
boolean TestFr_39_DriverBCancelAbsoluteTimer(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBCancelAbsoluteTimer == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucDrvBAbsTimerIdx == Fr_AbsTimerIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBCancelAbsoluteTimer = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBCancelAbsoluteTimer == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvBCancelAbsoluteTimer = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
Std_ReturnType Fr_39_DriverB_AbortCommunication (uint8 Fr_CtrlIdx)
{
   Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
  Fr_GucDrvBAbortCommunication++;
 return 1;
}
/*******************************************************************************
**                         TestFr_39_DriverBAbortCommunication()              **
*******************************************************************************/
boolean TestFr_39_DriverBAbortCommunication(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBAbortCommunication == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBAbortCommunication = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBAbortCommunication == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvBAbortCommunication = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

Std_ReturnType Fr_39_DriverB_AllowColdstart(uint8 Fr_CtrlIdx)
{ 
  Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
  Fr_GucDrvBAllowColdstart++;
return 1;
}

/*******************************************************************************
**                         TestFr_39_DriverBAllowColdstart()                  **
*******************************************************************************/
boolean TestFr_39_DriverBAllowColdstart(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBAllowColdstart == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBAllowColdstart = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBAllowColdstart == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvBAllowColdstart = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
Std_ReturnType Fr_39_DriverB_DisableAbsoluteTimerIRQ(uint8 Fr_CtrlIdx,uint8 Fr_AbsTimerIdx)
{ 
Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvBAbsTimerIdx = Fr_AbsTimerIdx;
    Fr_GucDrvBDisableAbsoluteTimerIRQ++;
return 1;
}

/*******************************************************************************
**                         TestFr_39_DriverBDisableAbsoluteTimerIRQ()  **
*******************************************************************************/
boolean TestFr_39_DriverBDisableAbsoluteTimerIRQ(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBDisableAbsoluteTimerIRQ == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucDrvBAbsTimerIdx == Fr_AbsTimerIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBDisableAbsoluteTimerIRQ = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBDisableAbsoluteTimerIRQ == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvBDisableAbsoluteTimerIRQ = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

Std_ReturnType Fr_39_DriverB_EnableAbsoluteTimerIRQ(uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx)
{
    Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvBAbsTimerIdx = Fr_AbsTimerIdx;
    Fr_GucDrvBEnableAbsoluteTimerIRQ++;
 return 1;}
/*******************************************************************************
**                         TestFr_39_DriverBEnableAbsoluteTimerIRQ()          **
*******************************************************************************/
boolean TestFr_39_DriverBEnableAbsoluteTimerIRQ(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBEnableAbsoluteTimerIRQ == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucDrvBAbsTimerIdx == Fr_AbsTimerIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBEnableAbsoluteTimerIRQ = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBEnableAbsoluteTimerIRQ == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvBEnableAbsoluteTimerIRQ = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

Std_ReturnType Fr_39_DriverB_GetAbsoluteTimerIRQStatus(uint8 Fr_CtrlIdx,uint8 Fr_AbsTimerIdx, boolean* FrIf_IRQStatusPtr)
{ 
    Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvBAbsTimerIdx = Fr_AbsTimerIdx;
    Fr_GpDrvBBIRQStatusPtr = FrIf_IRQStatusPtr;
    Fr_GucDrvBGetAbsoluteTimerIRQStatus++;
return 1;
}
/*******************************************************************************
**                         TestFr_39_DriverBGetAbsoluteTimerIRQStatus()       **
*******************************************************************************/
boolean TestFr_39_DriverBGetAbsoluteTimerIRQStatus(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx, 
  boolean* FrIf_IRQStatusPtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBGetAbsoluteTimerIRQStatus == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucDrvBAbsTimerIdx == Fr_AbsTimerIdx) &&
        (Fr_GpDrvBBIRQStatusPtr == FrIf_IRQStatusPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBGetAbsoluteTimerIRQStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBGetAbsoluteTimerIRQStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvBGetAbsoluteTimerIRQStatus = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
/*******************************************************************************
**                         TestFr_39_DriverBGetGlobalTime()                   **
*******************************************************************************/
boolean TestFr_39_DriverBGetGlobalTime(App_DataValidateType LddDataValidate,
uint8 Fr_CtrlIdx,uint8* FrIf_CyclePtr, uint16* FrIf_MacroTickPtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBGetGlobalTime == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpDrvBCyclePtr == FrIf_CyclePtr) &&
        (Fr_GpDrvBMacroTickPtr == FrIf_MacroTickPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBGetGlobalTime = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBGetGlobalTime == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
Std_ReturnType Fr_39_DriverB_GetGlobalTime(uint8 Fr_CtrlIdx,uint8* FrIf_CyclePtr, uint16* FrIf_MacroTickPtr)
{
    Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
    Fr_GpDrvBCyclePtr = FrIf_CyclePtr;
    Fr_GpDrvBMacroTickPtr = FrIf_MacroTickPtr;
    Fr_GucDrvBGetGlobalTime++;
 return 1;
 }
/*******************************************************************************
**                         TestFr_39_DriverBGetPOCStatus()                    **
*******************************************************************************/
boolean TestFr_39_DriverBGetPOCStatus(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, Fr_POCStatusType* FrIf_POCStatusPtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBGetPOCStatus == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpDrvBPOCStatusPtr == FrIf_POCStatusPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBGetPOCStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBGetPOCStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
Std_ReturnType Fr_39_DriverB_GetPOCStatus(uint8 Fr_CtrlIdx,Fr_POCStatusType* FrIf_POCStatusPtr)
{
    Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
    Fr_GpDrvBPOCStatusPtr = FrIf_POCStatusPtr;
    Fr_GucDrvBGetPOCStatus++;
 return 1;
}
/*******************************************************************************
**                         TestFr_39_DriverBHaltCommunication()              **
*******************************************************************************/
boolean TestFr_39_DriverBHaltCommunication(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBHaltCommunication == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBHaltCommunication = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBHaltCommunication == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvBHaltCommunication = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
Std_ReturnType Fr_39_DriverB_HaltCommunication (uint8 Fr_CtrlIdx)
{ 
    Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvBHaltCommunication++;
return 1;
}
/*******************************************************************************
**                         TestFr_39_DriverBSendWUP()                         **
*******************************************************************************/
boolean TestFr_39_DriverBSendWUP(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBSendWUP == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBSendWUP = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBSendWUP == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvBSendWUP = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}  
Std_ReturnType Fr_39_DriverB_SendWUP(uint8 Fr_CtrlIdx)
{ 
 Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
Fr_GucDrvBSendWUP++;
return 1;
}
/*******************************************************************************
**                         TestFr_39_DriverBSetAbsoluteTimer()                **
*******************************************************************************/
boolean TestFr_39_DriverBSetAbsoluteTimer(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx, uint8 Fr_Cycle, uint16 Fr_Offset)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBAbsoluteTimer == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucDrvBAbsTimerIdx == Fr_AbsTimerIdx) &&
        (Fr_GucDrvBcycle == Fr_Cycle) &&
        (Fr_GusDrvBOffset == Fr_Offset))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBAbsoluteTimer = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBAbsoluteTimer == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvBAbsoluteTimer = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
Std_ReturnType Fr_39_DriverB_SetAbsoluteTimer(uint8 Fr_CtrlIdx,
  uint8 Fr_AbsTimerIdx, uint8 Fr_Cycle, uint16 Fr_Offset)
{ 
    Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvBAbsTimerIdx = Fr_AbsTimerIdx;
    Fr_GucDrvBcycle = Fr_Cycle;
    Fr_GusDrvBOffset = Fr_Offset;
    Fr_GucDrvBAbsoluteTimer++;
return 1;
}
/*******************************************************************************
**                         TestFr_39_DriverBSetWakeupChannel()                **
*******************************************************************************/
boolean TestFr_39_DriverBSetWakeupChannel(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx,
  Fr_ChannelType Fr_ChnlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if(( Fr_GucDrvBSetWakeupChannel == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GddDrvBChnlIdx == Fr_ChnlIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBSetWakeupChannel = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBSetWakeupChannel == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}  
Std_ReturnType Fr_39_DriverB_SetWakeupChannel(uint8 Fr_CtrlIdx, Fr_ChannelType Fr_ChnlIdx)
{
    Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
    Fr_GddDrvBChnlIdx = Fr_ChnlIdx;
    Fr_GucDrvBSetWakeupChannel++;
 return 1;
 }
/*******************************************************************************
**                         TestFr_39_DriverBStartCommunication()              **
*******************************************************************************/
boolean TestFr_39_DriverBStartCommunication(App_DataValidateType LddDataValidate
  , uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBStartCommunication == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBStartCommunication = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBStartCommunication == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvBStartCommunication = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
Std_ReturnType Fr_39_DriverB_StartCommunication(uint8 Fr_CtrlIdx)
{ 
    Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvBStartCommunication++;
return 1;
}
/*******************************************************************************
**                         TestFr_39_DriverBAllSlots()                  **
*******************************************************************************/
boolean TestFr_39_DriverBAllSlots(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBAllSlots == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBAllSlots = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBAllSlots == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvBAllSlots = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
Std_ReturnType Fr_39_DriverB_AllSlots(uint8 Fr_CtrlIdx)
{
  Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
  Fr_GucDrvBAllSlots++;
 return 1;
 }
/*******************************************************************************
**                         TestFr_39_DriverBGetChannelStatus()              **
*******************************************************************************/
boolean TestFr_39_DriverBGetChannelStatus(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx,
  uint16* FrIf_ChannelAStatusPtr, uint16* FrIf_ChannelBStatusPtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBGetChannelStatus == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpDrvBChannelAStatusPtr == FrIf_ChannelAStatusPtr) &&
        (Fr_GpDrvBChannelBStatusPtr == FrIf_ChannelBStatusPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBGetChannelStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBGetChannelStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}   
Std_ReturnType Fr_39_DriverB_GetChannelStatus(uint8 Fr_CtrlIdx,uint16* FrIf_ChannelAStatusPtr, 
                uint16* FrIf_ChannelBStatusPtr)
{
  Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
  Fr_GpDrvBChannelAStatusPtr = FrIf_ChannelAStatusPtr;
  Fr_GpDrvBChannelBStatusPtr = FrIf_ChannelBStatusPtr;
  Fr_GucDrvBGetChannelStatus ++;
 return 1;
 }

/*******************************************************************************
**                         TestFr_39_DriverBGetClockCorrection()              **
*******************************************************************************/ 
boolean TestFr_39_DriverBGetClockCorrection(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx,
  sint16* FrIf_RateCorrectionPtr, sint32* FrIf_OffsetCorrectionPtr)
{
    boolean LblStepResult;

    LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((GucDrvBGetClockCorrection == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (FrIf_GpDrvBRateCorrectionPtr == FrIf_RateCorrectionPtr) &&
        (FrIf_GpDrvBOffsetCorrectionPtr == FrIf_OffsetCorrectionPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      GucDrvBGetClockCorrection = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(GucDrvBGetClockCorrection == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}   
Std_ReturnType Fr_39_DriverB_GetClockCorrection(uint8 Fr_CtrlIdx, sint16* FrIf_RateCorrectionPtr, sint32* FrIf_OffsetCorrectionPtr)
{
   Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
    FrIf_GpDrvBRateCorrectionPtr = FrIf_RateCorrectionPtr;
    FrIf_GpDrvBOffsetCorrectionPtr = FrIf_OffsetCorrectionPtr;
    GucDrvBGetClockCorrection++;
return 1;
}	

/*******************************************************************************
**               TestFr_39_DriverBGetNmVector()                               **
*******************************************************************************/
boolean TestFr_39_DriverBGetNmVector(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint8* Fr_NmVectorPtr)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBGetNmVector == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpDrvBNmVectorPtr == Fr_NmVectorPtr)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBGetNmVector = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBGetNmVector == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvBGetNmVector = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
Std_ReturnType Fr_39_DriverB_GetNmVector(uint8 Fr_CtrlIdx, uint8* Fr_NmVectorPtr)
{ 
  Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
  Fr_GpDrvBNmVectorPtr = Fr_NmVectorPtr;
  Fr_GucDrvBGetNmVector++;
return 1;
}
/*******************************************************************************
**                         TestFr_39_DriverBGetNumOfStartupFrames()           **
*******************************************************************************/ 
boolean TestFr_39_DriverBGetNumOfStartupFrames(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, uint8* FrIf_NumOfStartupFramesPtr)
{
    boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBGetNumOfStartupFrames == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpDrvBNumOfStartupFramesPtr == FrIf_NumOfStartupFramesPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBGetNumOfStartupFrames = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBGetNumOfStartupFrames == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}   
Std_ReturnType Fr_39_DriverB_GetNumOfStartupFrames(uint8 Fr_CtrlIdx,
  uint8* FrIf_NumOfStartupFramesPtr)
  { 
    Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
  Fr_GpDrvBNumOfStartupFramesPtr = FrIf_NumOfStartupFramesPtr;
  Fr_GucDrvBGetNumOfStartupFrames++;
  return 1;
  }
/*******************************************************************************
**                         TestFr_39_DriverBGetSyncFrameList()                **
*******************************************************************************/ 
boolean TestFr_39_DriverBGetSyncFrameList(App_DataValidateType LddDataValidate, 
  uint8 Fr_CtrlIdx,uint8 Fr_ListSize,
  uint16* FrIf_ChannelAEvenListPtr, uint16* FrIf_ChannelBEvenListPtr,
  uint16* FrIf_ChannelAOddListPtr, uint16* FrIf_ChannelBOddListPtr)
{
    boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBGetSyncFrameList == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpDrvBChannelAEvenListPtr == FrIf_ChannelAEvenListPtr) &&
        (Fr_GpDrvBChannelBEvenListPtr == FrIf_ChannelBEvenListPtr) &&
        (Fr_GucDrvBListSize == Fr_ListSize) &&
        (Fr_GpDrvBChannelAOddListPtr == FrIf_ChannelAOddListPtr) &&
        (Fr_GpDrvBChannelBOddListPtr == FrIf_ChannelBOddListPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBGetSyncFrameList = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBGetSyncFrameList == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}   
Std_ReturnType Fr_39_DriverB_GetSyncFrameList(uint8 Fr_CtrlIdx,uint8 Fr_ListSize,
  uint16* FrIf_ChannelAEvenListPtr, uint16* FrIf_ChannelBEvenListPtr,
  uint16* FrIf_ChannelAOddListPtr, uint16* FrIf_ChannelBOddListPtr)
  { 
    Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvBListSize = Fr_ListSize;
    Fr_GpDrvBChannelAEvenListPtr = FrIf_ChannelAEvenListPtr;
    Fr_GpDrvBChannelBEvenListPtr = FrIf_ChannelBEvenListPtr;
    Fr_GpDrvBChannelAOddListPtr = FrIf_ChannelAOddListPtr;
    Fr_GpDrvBChannelBOddListPtr = FrIf_ChannelBOddListPtr;
    Fr_GucDrvBGetSyncFrameList++;
  return 1;
  }
/*******************************************************************************
**                         TestFr_39_DriverBGetWakeupRxStatus()               **
*******************************************************************************/ 
boolean TestFr_39_DriverBGetWakeupRxStatus(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, 
  uint8* FrIf_WakeupRxStatusPtr)
{
  boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBGetWakeupRxStatus == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpDrvBWakeupRxStatusPtr == FrIf_WakeupRxStatusPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBGetWakeupRxStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBGetWakeupRxStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
Std_ReturnType Fr_39_DriverB_GetWakeupRxStatus(uint8 Fr_CtrlIdx,
  uint8* FrIf_WakeupRxStatusPtr)
  { 
    Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
  Fr_GpDrvBWakeupRxStatusPtr = FrIf_WakeupRxStatusPtr;
  Fr_GucDrvBGetWakeupRxStatus++;
  return 1;
  }
/*******************************************************************************
**               TestFr_39_DriverBReadCCConfig()                              **
*******************************************************************************/
  
boolean TestFr_39_DriverBReadCCConfig (App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint8 FrIf_CCLLParamIndex,
  uint32* FrIf_CCLLParamValue) 
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBReadCCConfig == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucDrvBConfigParamIdx == FrIf_CCLLParamIndex) &&
        (Fr_GpDrvBConfigParamValuePtr == FrIf_CCLLParamValue)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBReadCCConfig = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBReadCCConfig == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvBReadCCConfig = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
Std_ReturnType Fr_39_DriverB_ReadCCConfig(uint8 Fr_CtrlIdx,
  uint8 FrIf_CCLLParamIndex, uint32* FrIf_CCLLParamValue)
  { 
    Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
  Fr_GucDrvBConfigParamIdx = FrIf_CCLLParamIndex;
  Fr_GpDrvBConfigParamValuePtr = FrIf_CCLLParamValue;
  Fr_GucDrvBReadCCConfig++;
  return 1;
  }
/*******************************************************************************
**               TestFr_39_ReconfigLPdu()                                     **
*******************************************************************************/
boolean TestFr_39_DriverBReconfigLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx, uint16 Fr_FrameId,
  Fr_ChannelType Fr_ChnlIdx, uint8 Fr_CycleRepetition, uint8 Fr_CycleOffset,
  uint8 Fr_PayloadLength, uint16 Fr_HeaderCRC)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBReconfigLPdu == 0x01) &&
        (Fr_GusDrvBLPduIdx == Fr_LPduIdx) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) && 
        (Fr_GusDrvBFrameId == Fr_FrameId) &&
        (Fr_GddDrvBChnlIdx == Fr_ChnlIdx) && 
        (Fr_GucDrvBCycleRepetition == Fr_CycleRepetition) &&
        (Fr_GucDrvBCycleOffset == Fr_CycleOffset) &&
        (Fr_GucDrvBPayloadLength == Fr_PayloadLength) &&
        (Fr_GusDrvBHeaderCRC == Fr_HeaderCRC))
        {
        LblStepResult = STEP_PASSED;
        }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDvrBTransceivermodecount = 0;
      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBReconfigLPdu = 0;
      break;
    }/* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBReconfigLPdu == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
Std_ReturnType Fr_39_DriverB_ReconfigLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx,uint16 Fr_FrameId, 
Fr_ChannelType Fr_ChnlIdx, uint8 Fr_CycleRepetition, uint8 Fr_CycleOffset, uint8 Fr_PayloadLength,  uint16 Fr_HeaderCRC )
{ 
 Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
  Fr_GusDrvBLPduIdx = Fr_LPduIdx;
  Fr_GusDrvBFrameId = Fr_FrameId;
  Fr_GddDrvBChnlIdx = Fr_ChnlIdx;
  Fr_GucDrvBCycleRepetition = Fr_CycleRepetition;
  Fr_GucDrvBCycleOffset = Fr_CycleOffset;
  Fr_GucDrvBPayloadLength = Fr_PayloadLength;
  Fr_GusDrvBHeaderCRC = Fr_HeaderCRC;
  Fr_GucDrvBReconfigLPdu++;
return 1;
}

/*******************************************************************************
**               Fr_39_DriverB_CancelTxLPdu()                                  **
*******************************************************************************/
Std_ReturnType Fr_39_DriverB_CancelTxLPdu(uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx)
{
  Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
  Fr_GusDrvBLPduIdx = Fr_LPduIdx;
  Fr_GucDrvBCancelTxLPdu++;
  return E_OK;
}

/*******************************************************************************
**                         TestFr_39_DriverBCancelTxLPdu()                    **
*******************************************************************************/

boolean TestFr_39_DriverBCancelTxLPdu(App_DataValidateType LddDataValidate,
uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBCancelTxLPdu == 0x01) && 
         (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GusDrvBLPduIdx == Fr_LPduIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBCancelTxLPdu = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBCancelTxLPdu == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*******************************************************************************
**               Fr_39_DriverB_DisableLPdu()                                  **
*******************************************************************************/
Std_ReturnType Fr_39_DriverB_DisableLPdu(uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx)
{
  Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
  Fr_GusDrvBLPduIdx = Fr_LPduIdx;
  Fr_GucDrvBDisableLPdu++;
  return E_OK;
}

/*******************************************************************************
**                         TestFr_39_DriverBDisableLPdu()                  **
*******************************************************************************/

boolean TestFr_39_DriverBDisableLPdu(App_DataValidateType LddDataValidate,
uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBDisableLPdu == 0x01) && 
         (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GusDrvBLPduIdx == Fr_LPduIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBDisableLPdu = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBDisableLPdu == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*******************************************************************************
**               Fr_39_DriverB_TransmitTxLPdu()                                **
*******************************************************************************/
Std_ReturnType Fr_39_DriverB_TransmitTxLPdu(uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx,
P2CONST(uint8, AUTOMATIC, FRIF_APPL_DATA)Fr_LSduPtr, uint8 Fr_LSduLength)
{
  Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
  Fr_GusDrvBLPduIdx = Fr_LPduIdx;
  Fr_GpDrvBLSduPtr = (uint8*)Fr_LSduPtr;
  Fr_GpDrvBLSduLength = Fr_LSduLength;
  Fr_GucDrvBTransmitTxLPdu++;
  return E_OK;
}

/*******************************************************************************
**                         TestFr_39_DriverBTransmitTxLPdu()                  **
*******************************************************************************/

boolean TestFr_39_DriverBTransmitTxLPdu(App_DataValidateType LddDataValidate,
uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx,
P2CONST(uint8, AUTOMATIC, FRIF_APPL_DATA)Fr_LSduPtr, uint8 Fr_LSduLength)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBTransmitTxLPdu == 0x01) && 
         (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GusDrvBLPduIdx == Fr_LPduIdx) && 
        (Fr_GpDrvBLSduPtr == (uint8*)Fr_LSduPtr) && 
         (Fr_GpDrvBLSduLength == Fr_LSduLength))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBTransmitTxLPdu = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBTransmitTxLPdu == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*******************************************************************************
**               Fr_39_DriverB_ReceiveRxLPdu()                                **
*******************************************************************************/
Std_ReturnType Fr_39_DriverB_ReceiveRxLPdu(uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx, 
  P2VAR(uint8,AUTOMATIC,FRIF_APPL_DATA)Fr_LSduPtr, 
  P2VAR(Fr_RxLPduStatusType,AUTOMATIC,FRIF_APPL_DATA)Fr_LPduStatusPtr, 
  P2VAR(uint8,AUTOMATIC,FRIF_APPL_DATA)Fr_LSduLengthPtr)
{ 
  Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
  Fr_GusDrvBLPduIdx = Fr_LPduIdx;
  *Fr_LSduPtr = 0;
  *Fr_LPduStatusPtr =0;
  *Fr_LSduLengthPtr =0;
  Fr_GucDrvBReceiveRxLPdu++;
  return E_OK;
}

/*******************************************************************************
**                         TestFr_39_DriverBReceiveRxLPdu()                   **
*******************************************************************************/

boolean TestFr_39_DriverBReceiveRxLPdu(App_DataValidateType LddDataValidate,
uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBReceiveRxLPdu == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GusDrvBLPduIdx == Fr_LPduIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBReceiveRxLPdu = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBReceiveRxLPdu == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*******************************************************************************
**               Fr_39_DriverB_CheckTxLPduStatus()                            **
*******************************************************************************/
Std_ReturnType Fr_39_DriverB_CheckTxLPduStatus(uint8 Fr_CtrlIdx,
uint16 Fr_LPduIdx, P2VAR(Fr_TxLPduStatusType,
AUTOMATIC,FRIF_APPL_DATA)Fr_TxLPduStatusPtr)
{
    Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
    Fr_GusDrvBLPduIdx = Fr_LPduIdx;
    *Fr_TxLPduStatusPtr = FR_TRANSMITTED;    
    Fr_GucDrvBCheckTxLPduStatus++;
    return E_OK;
}

/*******************************************************************************
**                         TestFr_39_DriverBCheckTxLPduStatus()               **
*******************************************************************************/

boolean TestFr_39_DriverBCheckTxLPduStatus(App_DataValidateType LddDataValidate, 
uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBCheckTxLPduStatus == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GusDrvBLPduIdx == Fr_LPduIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBCheckTxLPduStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBCheckTxLPduStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*******************************************************************************
**               Fr_39_DriverB_PrepareLPdu()                                  **
*******************************************************************************/
Std_ReturnType Fr_39_DriverB_PrepareLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx)
{ 
  Fr_GucDrvbBCtrlIdx = Fr_CtrlIdx;
  Fr_GusDrvBLPduIdx = Fr_LPduIdx;
  Fr_GucDrvBPrepareLPdu++;
  return E_OK;
}

/*******************************************************************************
**                         TestFr_39_DriverBPrepareLPdu()                     **
*******************************************************************************/

boolean TestFr_39_DriverBPrepareLPdu(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx,
  uint16 Fr_LPduIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvBPrepareLPdu == 0x01) &&
        (Fr_GucDrvbBCtrlIdx == Fr_CtrlIdx) &&
        (Fr_GusDrvBLPduIdx == Fr_LPduIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvBPrepareLPdu = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvBPrepareLPdu == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
