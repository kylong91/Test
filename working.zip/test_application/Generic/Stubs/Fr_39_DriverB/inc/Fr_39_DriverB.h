/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Fr_DriverB.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Fr_DriverB Stub                                       **
**                                                                            **
**  PURPOSE   : Declaration of Fr_DriverB Stub functions                      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/

#ifndef FR_DRIVERB_H
#define FR_DRIVERB_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
/*
 * This header file includes all the standard data types, platform dependent
 * header file and common return types
 */
#include "Std_Types.h"
#include "Fr_GeneralTypes.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define FR_AR_RELEASE_MAJOR_VERSION      0x04
#define FR_AR_RELEASE_MINOR_VERSION      0x00
#define FR_AR_RELEASE_REVISION_VERSION   0x03

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/*
 * Defining the structure to store the parameters of Det Report Error function
 */


/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
  
  /*******************************************************************************
**               Function Prototypes  for FR Driver A                         **
*******************************************************************************/
extern Std_ReturnType Fr_39_DriverB_ControllerInit(uint8 Fr_CtrlIdx);
extern uint16 Fr_39_DriverB_GetMacroticksPerCycle(uint8 Fr_CtrlIdx);
extern Std_ReturnType Fr_39_DriverB_SetAbsoluteTimer(uint8 Fr_CtrlIdx,
  uint8 FrIf_AbsTimerIdx, uint8 FrIf_Cycle, uint16 FrIf_Offset);
extern Std_ReturnType Fr_39_DriverB_EnableAbsoluteTimerIRQ(uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx);
extern Std_ReturnType Fr_39_DriverB_AckAbsoluteTimerIRQ(uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx);
extern Std_ReturnType Fr_39_DriverB_StartCommunication(uint8 Fr_CtrlIdx);
extern Std_ReturnType Fr_39_DriverB_HaltCommunication (uint8 Fr_CtrlIdx);
extern Std_ReturnType Fr_39_DriverB_AbortCommunication (uint8 Fr_CtrlIdx);
extern Std_ReturnType Fr_39_DriverB_SetWakeupChannel(uint8 Fr_CtrlIdx, Fr_ChannelType Fr_ChnlIdx);
extern Std_ReturnType Fr_39_DriverB_SendWUP(uint8 Fr_CtrlIdx);
extern Std_ReturnType Fr_39_DriverB_GetPOCStatus(uint8 Fr_CtrlIdx,Fr_POCStatusType* FrIf_POCStatusPtr);
extern Std_ReturnType Fr_39_DriverB_GetGlobalTime(uint8 Fr_CtrlIdx,uint8* FrIf_CyclePtr, uint16* FrIf_MacroTickPtr);
extern Std_ReturnType Fr_39_DriverB_AllowColdstart(uint8 Fr_CtrlIdx);
extern Std_ReturnType Fr_39_DriverB_CancelAbsoluteTimer(uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx);
extern Std_ReturnType Fr_39_DriverB_CancelAbsoluteTimerIRQ(uint8 Fr_CtrlIdx,uint8 Fr_AbsTimerIdx);
extern Std_ReturnType Fr_39_DriverB_DisableAbsoluteTimerIRQ(uint8 Fr_CtrlIdx,uint8 Fr_AbsTimerIdx);
extern Std_ReturnType Fr_39_DriverB_GetAbsoluteTimerIRQStatus(uint8 Fr_CtrlIdx,uint8 Fr_AbsTimerIdx, boolean* FrIf_IRQStatusPtr);
extern Std_ReturnType Fr_39_DriverB_AllSlots(uint8 Fr_CtrlIdx);   
extern Std_ReturnType Fr_39_DriverB_GetChannelStatus(uint8 Fr_CtrlIdx,uint16* FrIf_ChannelAStatusPtr, uint16* FrIf_ChannelBStatusPtr);
extern Std_ReturnType Fr_39_DriverB_GetClockCorrection(uint8 Fr_CtrlIdx, sint16* FrIf_RateCorrectionPtr, sint32* FrIf_OffsetCorrectionPtr);
extern Std_ReturnType Fr_39_DriverB_GetSyncFrameList(uint8 Fr_CtrlIdx,uint8 Fr_ListSize,
  uint16* FrIf_ChannelAEvenListPtr, uint16* FrIf_ChannelBEvenListPtr,
  uint16* FrIf_ChannelAOddListPtr, uint16* FrIf_ChannelBOddListPtr);
extern Std_ReturnType Fr_39_DriverB_GetNumOfStartupFrames(uint8 Fr_CtrlIdx,
  uint8* FrIf_NumOfStartupFramesPtr);
extern Std_ReturnType Fr_39_DriverB_GetWakeupRxStatus(uint8 Fr_CtrlIdx,
  uint8* FrIf_WakeupRxStatusPtr);
extern Std_ReturnType Fr_39_DriverB_CancelTxLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx);
extern Std_ReturnType Fr_39_DriverB_DisableLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx);
extern Std_ReturnType Fr_39_DriverB_ReconfigLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx,uint16 Fr_FrameId, Fr_ChannelType Fr_ChnlIdx, uint8 Fr_CycleRepetition, uint8 Fr_CycleOffset, uint8 Fr_PayloadLength,  uint16 Fr_HeaderCRC );
extern Std_ReturnType Fr_39_DriverB_GetNmVector(uint8 Fr_CtrlIdx, uint8* Fr_NmVectorPtr);
extern Std_ReturnType Fr_39_DriverB_TransmitTxLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx, P2CONST(uint8,AUTOMATIC,FRIF_APPL_DATA)Fr_LSduPtr,uint8 Fr_LSduLength);
extern Std_ReturnType Fr_39_DriverB_ReceiveRxLPdu(uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx, 
  P2VAR(uint8,AUTOMATIC,FRIF_APPL_DATA)Fr_LSduPtr, 
  P2VAR(Fr_RxLPduStatusType,AUTOMATIC,FRIF_APPL_DATA)Fr_LPduStatusPtr, 
  P2VAR(uint8,AUTOMATIC,FRIF_APPL_DATA)Fr_LSduLengthPtr);
extern Std_ReturnType Fr_39_DriverB_CheckTxLPduStatus(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx, P2VAR(Fr_TxLPduStatusType,AUTOMATIC,FRIF_APPL_DATA)Fr_TxLPduStatusPtr);
extern Std_ReturnType Fr_39_DriverB_PrepareLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx);
extern Std_ReturnType Fr_39_DriverB_ReadCCConfig(uint8 Fr_CtrlIdx,
  uint8 FrIf_CCLLParamIndex, uint32* FrIf_CCLLParamValue);
  
  
  
/*FrTrcv_39_Transceiver Dummy files needs to be moved to FrTrcv_39_TrcvA*/


extern boolean TestFr_39_DriverBControllerInit(
  App_DataValidateType LddDataValidate,uint8 Fr_CtrlIdx);

extern boolean TestFr_39_DriverBAckAbsoluteTimerIRQ(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx);
  
extern boolean TestFr_39_DriverBAllowColdstart(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx);
  
extern boolean TestFr_39_DriverBAbortCommunication(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx);
  
extern boolean TestFr_39_DriverBCancelAbsoluteTimer(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx);

extern boolean TestFr_39_DriverBDisableAbsoluteTimerIRQ(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx);
  
extern boolean TestFr_39_DriverBEnableAbsoluteTimerIRQ(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx);
  
extern boolean TestFr_39_DriverBGetAbsoluteTimerIRQStatus(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx, 
  boolean* FrIf_IRQStatusPtr);
  
extern boolean TestFr_39_DriverBGetGlobalTime(App_DataValidateType LddDataValidate,
uint8 Fr_CtrlIdx,uint8* FrIf_CyclePtr, uint16* FrIf_MacroTickPtr);

extern boolean TestFr_39_DriverBGetPOCStatus(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, Fr_POCStatusType* FrIf_POCStatusPtr);
  
extern boolean TestFr_39_DriverBHaltCommunication(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx);
  
extern boolean TestFr_39_DriverBSendWUP(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx);

extern Std_ReturnType TestFr_39_DriverBSetAbsoluteTimer(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 FrIf_AbsTimerIdx,
  uint8 FrIf_Cycle, uint16 FrIf_Offset);
  
extern boolean TestFr_39_DriverBSetWakeupChannel(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx,
  Fr_ChannelType Fr_ChnlIdx);
  
extern boolean TestFr_39_DriverBStartCommunication(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx);
  
extern boolean TestFr_39_DriverBAllSlots(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx);

extern boolean TestFr_39_DriverBGetChannelStatus(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx,
  uint16* FrIf_ChannelAStatusPtr, uint16* FrIf_ChannelBStatusPtr);
  
extern boolean TestFr_39_DriverBGetClockCorrection(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx,
  sint16* FrIf_RateCorrectionPtr, sint32* FrIf_OffsetCorrectionPtr);
  
extern boolean TestFr_39_DriverBGetNmVector(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint8* Fr_NmVectorPtr);

extern boolean TestFr_39_DriverBGetNumOfStartupFrames(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, uint8* FrIf_NumOfStartupFramesPtr);
  
extern boolean TestFr_39_DriverBGetSyncFrameList(
  App_DataValidateType LddDataValidate,uint8 Fr_CtrlIdx,uint8 Fr_ListSize,
  uint16* FrIf_ChannelAEvenListPtr, uint16* FrIf_ChannelBEvenListPtr,
  uint16* FrIf_ChannelAOddListPtr, uint16* FrIf_ChannelBOddListPtr);
  
extern boolean TestFr_39_DriverBGetWakeupRxStatus(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, uint8* FrIf_WakeupRxStatusPtr);
  
extern boolean TestFr_39_DriverBReadCCConfig(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint8 FrIf_CCLLParamIndex,
  uint32* FrIf_CCLLParamValue);

extern boolean TestFr_39_DriverBReconfigLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx, uint16 Fr_FrameId,
  Fr_ChannelType Fr_ChnlIdx, uint8 Fr_CycleRepetition, uint8 Fr_CycleOffset,
  uint8 Fr_PayloadLength, uint16 Fr_HeaderCRC);
  
extern boolean TestFr_39_DriverBCancelTxLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx);
  
#endif /* End FR_DRIVERB_H */  
/*******************************************************************************
**                      End of Function Prototypes                            **
*******************************************************************************/
