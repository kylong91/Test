/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: SoAd.h                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR SoAd Stub                                            **
**                                                                            **
**  PURPOSE   : Declaration of SoAd Stub functions                           **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     03-Nov-2010   PPA    Initial version                             **
**                                                                            **
** 4.0.1     20-Sep-2011   BPT    Updated for Can                             **
** 4.0.2     20-Dec-2011   RPS    Updated for Can           				  **
** 4.0.3     04-Apr-2012   RPS    Updated for CanTrcv                         **
*******************************************************************************/

#ifndef SOAD_H
#define SOAD_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "SoAd_Types.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define SOAD_AR_RELEASE_MAJOR_VERSION    0x04
#define SOAD_AR_RELEASE_MINOR_VERSION    0x00
#define SOAD_AR_RELEASE_REVISION_VERSION 0x03

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define SOAD_DATA_LENGTH                 255 /* 0x08 */
#define SOAD_ARRAY_SIZE                  250

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
/*
extern Std_ReturnType SoAd_SetControllerMode(uint8 ControllerId,
  SoAd_ControllerModeType ControllerMode);

extern Std_ReturnType SoAd_SetTrcvMode(uint8 TransceiverId,
  SoAdTrcv_TrcvModeType TransceiverMode);

extern Std_ReturnType SoAd_SetPduMode(uint8 ControllerId,
  SoAd_PduSetModeType PduModeRequest);

extern SoAd_NotifStatusType SoAd_GetTxConfirmationState(uint8 ControllerId);

extern boolean TestSoAd_SetControllerMode(App_DataValidateType LucDataValidate,
  uint8 LucExpControllerId, SoAd_ControllerModeType LddExpControllerMode);

extern boolean TestSoAd_SetTrcvMode(App_DataValidateType LucDataValidate,
  uint8 LucExpTransceiverId, SoAdTrcv_TrcvModeType LddExpTransceiverMode);

extern boolean TestSoAd_SetPduMode(App_DataValidateType LucDataValidate,
  uint8 LucExpControllerId, SoAd_PduSetModeType LddExpPduModeRequest);

extern boolean TestSoAd_GetTxConfirmationState(
  App_DataValidateType LucDataValidate, uint8 LucExpControllerId);

extern void TestSetSoAd_GetTxConfirStateRetVal(
  SoAd_NotifStatusType LenGetTxConfirmStateReturn);

extern void SoAd_TrcvModeIndication(uint8 Transceiver, SoAdTrcv_TrcvModeType OpMode);

extern void TestSetSoAd_TxPduIdForRet(PduIdType LddPduIdForRet);
*/
extern Std_ReturnType SoAdIf_Transmit(PduIdType SoAdTxPduId,
  const PduInfoType *PduInfoPtr);

extern void TestSoAd_TransmitSetRetVal(Std_ReturnType LddRetVal);

extern boolean TestSoAdIf_Transmit(App_DataValidateType LucDataValidate,
  PduIdType ExpSoAdTxPduId, const PduInfoType *ExpPduInfoPtr);

extern boolean SoAdTest_ValidateData(PduInfoType* LddExpPduInfo,
  PduInfoType* LddActPduInfo);
/*
extern boolean TestSoAd_TrcvModeIndication(App_DataValidateType LucDataValidate,
  uint8 LucExpTransceiver, SoAdTrcv_TrcvModeType LddExpOpMode);
*/
extern void TestSoAd_DefaultBehavior(void);

extern Std_ReturnType SoAd_EnableRouting( SoAd_RoutingGroupIdType id );
extern Std_ReturnType SoAd_DisableRouting( SoAd_RoutingGroupIdType id );
extern boolean TestSoAd_SD_EnableDisableRouting(App_DataValidateType
  LucDataValidate, SoAd_RoutingGroupIdType LddRoutGrpId, boolean LblEnable);
extern boolean TestSoAd_SD_EnableRouting(App_DataValidateType LucDataValidate,
  SoAd_RoutingGroupIdType LddRoutGrpId);
extern boolean TestSoAd_SD_DisableRouting(App_DataValidateType LucDataValidate,
  SoAd_RoutingGroupIdType LddRoutGrpId);
  
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

