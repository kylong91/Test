/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: SoAd_Types.h                                                 **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR SoAd Stub                                            **
**                                                                            **
**  PURPOSE   : Declaration of SoAd Stub functions                           **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     28-Nov-2011   SLM    Initial version                             **
** 4.0.1     23-Dec-2011   RPS    Updated for Can                             **
*******************************************************************************/

#ifndef SOAD_TYPES_H
#define SOAD_TYPES_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"             /* Com Stack header */
/* #include "SoAd_GeneralTypes.h" */
/* #include "SoAd_GenericTypes.h" */
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
typedef enum
{
  SOAD_CS_UNINIT = 0,
  SOAD_CS_STOPPED,
  SOAD_CS_STARTED,
  SOAD_CS_SLEEP
}SoAd_ControllerModeType;

typedef enum
{
  SOAD_SET_OFFLINE = 0,
  SOAD_SET_RX_OFFLINE,
  SOAD_SET_RX_ONLINE,
  SOAD_SET_TX_OFFLINE,
  SOAD_SET_TX_ONLINE,
  SOAD_SET_ONLINE,
  SOAD_SET_TX_OFFLINE_ACTIVE
}SoAd_PduSetModeType;

typedef enum
{
  SOAD_NO_NOTIFICATION = 0,
  SOAD_TX_RX_NOTIFICATION
}SoAd_NotifStatusType;

typedef uint16  SoAd_SoConIdType;   /* Tentative uint8, uint16 */
typedef uint8 SoAd_RoutingGroupIdType;  /* uint8, uint16 */
typedef uint32	TcpIp_SockAddrType;
typedef uint16	TcpIp_SocketIdType;
typedef uint16	TcpIp_EventType;
typedef uint32	TcpIp_LocalAddrIdType;
typedef uint32	TcpIp_IpAddrStateType;
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

