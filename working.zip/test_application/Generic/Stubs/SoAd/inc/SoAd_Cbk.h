/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: SoAd_Cbk.h                                                    **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR SoAd Module                                           **
**                                                                            **
**  PURPOSE   : Provision to include Callback Header Files                    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     29-Jun-2011   PKN    Initial version                             **
**                                                                            **
** 4.0.1     20-Sep-2011   BPT    Updated for Can                             **
** 4.0.2     20-Dec-2011   RPS    Updated for Can     				          **
** 4.0.3     23-Dec-2011   RPS    Updated for Can      				          **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
*******************************************************************************/

/*******************************************************************************
**                       SoAd Generation Tool Version                         **
*******************************************************************************/

/*******************************************************************************
**                         Input File                                         **
*******************************************************************************/
#ifndef SOAD_CBK_H
#define SOAD_CBK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "SoAd_Types.h"

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/

/* AUTOSAR Specification Version Information */
#define SOAD_CBK_AR_RELEASE_MAJOR_VERSION  4
#define SOAD_CBK_AR_RELEASE_MINOR_VERSION  0
#define SOAD_CBK_AR_RELEASE_PATCH_VERSION  2

/*******************************************************************************
**                      Global Function Prototypes                            **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
/*
extern void SoAd_ControllerBusOff (uint8 Controller);

extern void SoAd_ControllerModeIndication (uint8 Controller, 
  SoAd_ControllerModeType ControllerMode);

extern void SoAd_RxIndication (SoAd_HwHandleType Hrh, SoAd_IdType SoAdId, 
  uint8 SoAdDlc, const uint8* SoAdSduPtr);

extern void SoAd_TxConfirmation(PduIdType SoAdTxPduId);

extern boolean TestSoAd_ControllerBusOff(App_DataValidateType LucDataValidate,
  uint8 LucExpController);

extern boolean TestSoAd_ControllerModeIndication 
  (App_DataValidateType LucDataValidate, uint8 LucExpController, 
  SoAd_ControllerModeType LddExpControllerMode);

extern boolean TestSoAd_RxIndication(App_DataValidateType LucDataValidate,
  SoAd_HwHandleType LddExpHrh, SoAd_IdType LddExpSoAdId, uint8 LddExpSoAdDlc, 
  const uint8 *ExpSoAdSduPtr);

extern boolean TestSoAd_TxConfirmation(
  App_DataValidateType LucDataValidate, PduIdType LddExpSoAdTxPduId);

boolean SoAdTest_SoAdRxValidateData(const uint8* LddExpSoAdSdu, 
  const uint8* LddActSoAdSdu, uint8 LucLength);
*/

extern void TestSoAd_DefaultBehavior(void);

#endif /* SOAD_CBK_H */

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
