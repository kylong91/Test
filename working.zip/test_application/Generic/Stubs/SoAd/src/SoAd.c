/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: SoAd.c                                                       **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR SoAd Stub                                            **
**                                                                            **
**  PURPOSE   : This application file contains the SoAd Stub functions       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     03-Nov-2010   PPA    Initial version                             **
**                                                                            **
** 4.0.1     26-Sep-2011   BPT    Updated for CanNm, CanSM, Can, CanTp        **
** 4.0.2     10-Jan-2012   RPS    Updated for PduR                            **
** 4.0.3     04-Apr-2012   RPS    Updated for CanTrcv                         **
*******************************************************************************/
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "SoAd.h"
#include "SoAd_Cbk.h"
#include "Sd_Debug.h" /* Tentative To be removed */
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 SoAd_GucSetCtrlModeCount;
uint8 SoAd_GucSetCtrlModeCheckCount;
uint8 SoAd_GaaCtrlModeCtrlId[SOAD_ARRAY_SIZE];
SoAd_ControllerModeType SoAd_GaaCtrlMode[SOAD_ARRAY_SIZE];

uint8 SoAd_GucSetTrcvModeCount;
uint8 SoAd_GucSetTrcvModeCheckCount;
uint8 SoAd_GaaTrcvModeTrcvId[SOAD_ARRAY_SIZE];

uint8 SoAd_GucSetPduModeCount;
uint8 SoAd_GucSetPduModeCheckCount;
uint8 SoAd_GaaPduModeCtrlId[SOAD_ARRAY_SIZE];
SoAd_PduSetModeType SoAd_GaaPduMode[SOAD_ARRAY_SIZE];

uint8 SoAd_GucGetTxConfirmCount;
uint8 SoAd_GucGetTxConfirmCheckCount;
uint8 SoAd_GaaGetTxConfirmCtrlId[SOAD_ARRAY_SIZE];

SoAd_NotifStatusType SoAd_GenGetTxConfirmStateReturn =
  SOAD_TX_RX_NOTIFICATION;
  
PduIdType SoAd_GaaSoAdTxPduId[SOAD_ARRAY_SIZE];
PduIdType SoAd_GddPduIdForRet;
uint8 SoAd_GaaSduLength[SOAD_ARRAY_SIZE];
uint8 SoAd_GucTransmitCount;
uint8 SoAd_GucTransmitCheckCount;
uint8 SoAd_GaaTransmitData[SOAD_ARRAY_SIZE][SOAD_DATA_LENGTH];
Std_ReturnType SoAd_GddTransmitReturn;

uint8 SoAd_GucCtrlBusOffCount;
uint8 SoAd_GucCtrlBusOffCheckCount;
uint8 SoAd_GaaCtrlBusOffCtrl[SOAD_ARRAY_SIZE];

uint8 SoAd_GucCtrlModeIndCount;
uint8 SoAd_GucCtrlModeIndCheckCount;
uint8 SoAd_GaaCtrlModeIndCtrl[SOAD_ARRAY_SIZE];
SoAd_ControllerModeType SoAd_GaaCtrlMode[SOAD_ARRAY_SIZE];

PduIdType SoAd_GaaTxConfSoAdTxPduId[SOAD_ARRAY_SIZE];
uint8 SoAd_GucTxConfSoAdTxPduIdCount;
uint8 SoAd_GucTxConfSoAdTxPduIdCheckCount;

uint8 SoAd_GddSoAdDlc[SOAD_ARRAY_SIZE];
uint8 SoAd_GaaRxIndSduPtr[SOAD_ARRAY_SIZE][SOAD_DATA_LENGTH];
uint8 SoAd_GucRxIndCount;
uint8 SoAd_GucRxIndCheckCount;

uint8 SoAd_GucTrcvModeIndCount;
uint8 SoAd_GucTrcvModeIndCheckCount;
uint8 SoAd_GaaTrcvModeTransceiverId[SOAD_ARRAY_SIZE];



uint8 SoAd_GucRoutGrpCount;
uint8 SoAd_GucRoutGrpCheckCount;
SoAd_RoutingGroupIdType SoAd_GaaRoutGrpId[SOAD_ARRAY_SIZE];
boolean SoAd_GddRoutGrpState[SOAD_ARRAY_SIZE] = {FALSE,};

uint8 SoAd_GucEnRoutGrpCount;
uint8 SoAd_GucEnRoutGrpCheckCount;
SoAd_RoutingGroupIdType SoAd_GaaEnRoutGrpId[SOAD_ARRAY_SIZE];

uint8 SoAd_GucDisRoutGrpCount;
uint8 SoAd_GucDisRoutGrpCheckCount;
SoAd_RoutingGroupIdType SoAd_GaaDisRoutGrpId[SOAD_ARRAY_SIZE];

/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
**                       SoAdTest_ValidateData()                             **
*******************************************************************************/
boolean SoAdTest_ValidateData(PduInfoType* LddExpPduInfo, 
PduInfoType* LddActPduInfo)
{
  uint8 *LpActualDataPtr;
  uint8 *LpExpDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  /* Load the ExpPduInfo to local variables */
  LddSduCount = LddExpPduInfo->SduLength;
  LpExpDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  /* Check the sdu length */
  if((LddExpPduInfo->SduLength <= SOAD_DATA_LENGTH) &&
    (LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }
   /* Check the sdu data */
  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    if(*LpActualDataPtr != *LpExpDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualDataPtr++;
    LpExpDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* End SoAdTest_ValidateData() */



/*******************************************************************************
**                              SoAdIf_Transmit()                              **
*******************************************************************************/
Std_ReturnType SoAdIf_Transmit(PduIdType SoAdTxPduId,
const PduInfoType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8* LpSduDataPtr;
  
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  SoAd_GaaSoAdTxPduId[SoAd_GucTransmitCount] = SoAdTxPduId;
  SoAd_GaaSduLength[SoAd_GucTransmitCount] = PduInfoPtr->SduLength;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > SOAD_DATA_LENGTH)
  {
    LucDataLength = SOAD_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->SduLength;
  }
  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    SoAd_GaaTransmitData[SoAd_GucTransmitCount][LucDataIndex] = 
      *LpSduDataPtr;
    LpSduDataPtr++;
  }
  /* Increment count variable to handle multiple invocations */
  if(SoAd_GucTransmitCount != SOAD_ARRAY_SIZE)
  {    
    SoAd_GucTransmitCount++;
  }
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((SoAd_GddPduIdForRet == SoAdTxPduId) ||
    (SoAd_GddTransmitReturn == E_NOT_OK))
  {
    SoAd_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif
  #endif /* TYPICAL_CONFIG */
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(SoAd_GddTransmitReturn);
  #endif
} /* End SoAdIf_Transmit() */

/*******************************************************************************
**                            TestSoAdIf_Transmit()                            **
*******************************************************************************/
boolean TestSoAdIf_Transmit(App_DataValidateType LucDataValidate,
PduIdType ExpSoAdTxPduId, const PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((SoAd_GucTransmitCount == 0x01) && 
        (ExpSoAdTxPduId == SoAd_GaaSoAdTxPduId[0]))
      {
        ActPduInfo.SduLength = SoAd_GaaSduLength[0];
        ActPduInfo.SduDataPtr = &SoAd_GaaTransmitData[0][0];

        /* Validate SduLength and Data */
        if(SoAdTest_ValidateData((PduInfoType *)ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      SoAd_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(SoAd_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((SoAd_GucTransmitCheckCount <= SoAd_GucTransmitCount) &&
        (ExpSoAdTxPduId == SoAd_GaaSoAdTxPduId[SoAd_GucTransmitCheckCount]))
      {
        ActPduInfo.SduLength =
          SoAd_GaaSduLength[SoAd_GucTransmitCheckCount];
        ActPduInfo.SduDataPtr =
          &SoAd_GaaTransmitData[SoAd_GucTransmitCheckCount][0];

        /* Validate the SduLength and Data */
        if(SoAdTest_ValidateData((PduInfoType *)ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      SoAd_GucTransmitCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(SoAd_GucTransmitCheckCount == SoAd_GucTransmitCount)
      {
        SoAd_GucTransmitCount = 0;
        SoAd_GucTransmitCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < SoAd_GucTransmitCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpSoAdTxPduId == SoAd_GaaSoAdTxPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestSoAdif_Transmit() */

/*******************************************************************************
**                          TestSoAd_TransmitSetRetVal()                     **
*******************************************************************************/
void TestSoAd_TransmitSetRetVal(Std_ReturnType LddRetVal)
{
  SoAd_GddTransmitReturn = LddRetVal;
}/* End TestSoAd_TransmitSetRetVal() */

/*******************************************************************************
**                        TestSoAd_DefaultBehavior()                         **
*******************************************************************************/
void TestSoAd_DefaultBehavior(void)
{ 
  SoAd_GucSetCtrlModeCount = 0;
  SoAd_GucSetCtrlModeCheckCount = 0;
  SoAd_GucSetTrcvModeCount = 0;
  SoAd_GucSetTrcvModeCheckCount = 0;
  SoAd_GucSetPduModeCount = 0;
  SoAd_GucSetPduModeCheckCount = 0;
  SoAd_GucGetTxConfirmCount = 0;
  SoAd_GucGetTxConfirmCheckCount = 0;
  SoAd_GddTransmitReturn = E_OK;
  SoAd_GucTransmitCount = 0;
  SoAd_GucTransmitCheckCount = 0;
  SoAd_GddPduIdForRet = (PduIdType)0xFF;
  SoAd_GenGetTxConfirmStateReturn = SOAD_TX_RX_NOTIFICATION;
  SoAd_GucCtrlBusOffCount = 0;
  SoAd_GucCtrlBusOffCheckCount = 0;
  SoAd_GucCtrlModeIndCount = 0;
  SoAd_GucCtrlModeIndCheckCount = 0;
  SoAd_GucTxConfSoAdTxPduIdCount = 0;
  SoAd_GucTxConfSoAdTxPduIdCheckCount = 0;
  SoAd_GucRxIndCount = 0;
  SoAd_GucRxIndCheckCount = 0;
  SoAd_GucTrcvModeIndCount = 0;
  SoAd_GucTrcvModeIndCheckCount = 0;
  SoAd_GucRoutGrpCount = 0;
  SoAd_GucRoutGrpCheckCount = 0;
  SoAd_GucEnRoutGrpCount = 0;
  SoAd_GucEnRoutGrpCheckCount = 0;
  SoAd_GucDisRoutGrpCount = 0;
  SoAd_GucDisRoutGrpCheckCount = 0;
}

/*******************************************************************************
**                      SoAd_EnableRouting                                    **
*******************************************************************************/
Std_ReturnType SoAd_EnableRouting( SoAd_RoutingGroupIdType LddId )
{
  #ifndef TYPICAL_CONFIG
  TRACE("Enable Routing %d\n", LddId);  /* Tentative */
  
  /***************************************************************************/
  /* Routing Group status */
  SoAd_GaaRoutGrpId[SoAd_GucRoutGrpCount] = LddId;
  SoAd_GddRoutGrpState[SoAd_GucRoutGrpCount] = TRUE;  /* Enable => TRUE */
  
  /* Increment count variable to handle multiple invocations */
  if (SoAd_GucRoutGrpCount < SOAD_ARRAY_SIZE)
  {
    SoAd_GucRoutGrpCount++;
  }
  
  /***************************************************************************/
  /* Enable Routing Group only */
  SoAd_GaaEnRoutGrpId[SoAd_GucEnRoutGrpCount] = LddId;
  
  /* Increment count variable to handle multiple invocations */
  if (SoAd_GucEnRoutGrpCount < SOAD_ARRAY_SIZE)
  {
    SoAd_GucEnRoutGrpCount++;
  }
  
  #endif /* TYPICAL_CONFIG */
  return E_OK;
}

/*******************************************************************************
**                      SoAd_DisableRouting                                   **
*******************************************************************************/
Std_ReturnType SoAd_DisableRouting( SoAd_RoutingGroupIdType LddId )
{
  #ifndef TYPICAL_CONFIG
  TRACE("Diable Routing %d\n", LddId);  /* Tentative */
  
  /***************************************************************************/
  /* Routing Group status */
  SoAd_GaaRoutGrpId[SoAd_GucRoutGrpCount] = LddId;
  SoAd_GddRoutGrpState[SoAd_GucRoutGrpCount] = FALSE;  /* Disable => FALSE */
  
  /* Increment count variable to handle multiple invocations */
  if (SoAd_GucRoutGrpCount < SOAD_ARRAY_SIZE)
  {
    SoAd_GucRoutGrpCount++;
  }
  
  /***************************************************************************/
  /* Disable Routing Group only */
  SoAd_GaaDisRoutGrpId[SoAd_GucDisRoutGrpCount] = LddId;
  
  /* Increment count variable to handle multiple invocations */
  if (SoAd_GucDisRoutGrpCount < SOAD_ARRAY_SIZE)
  {
    SoAd_GucDisRoutGrpCount++;
  }
  #endif /* TYPICAL_CONFIG */
  return E_OK;
}
/*******************************************************************************
**                  TestSoAd_SD_EnableDisableRouting()                        **
*******************************************************************************/
boolean TestSoAd_SD_EnableDisableRouting(App_DataValidateType LucDataValidate,
  SoAd_RoutingGroupIdType LddRoutGrpId, boolean LblEnable)
{
  boolean LblStepResult;
  uint8 LucIndex;
  
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Network and CurrentState */
      if((SoAd_GucRoutGrpCount == 0x01) &&
        (SoAd_GaaRoutGrpId[0] == LddRoutGrpId) &&
        (SoAd_GddRoutGrpState[0] == LblEnable))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      SoAd_GucRoutGrpCount = 0;
      SoAd_GucRoutGrpCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < SoAd_GucRoutGrpCount; LucIndex++)
      {
        /* Validate Service and CurrentState */
        if((SoAd_GaaRoutGrpId[LucIndex] == LddRoutGrpId) &&
          (SoAd_GddRoutGrpState[LucIndex] == LblEnable))
        {
          LblStepResult = STEP_PASSED;          
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = SoAd_GucRoutGrpCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      SoAd_GucRoutGrpCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(SoAd_GucRoutGrpCheckCount == SoAd_GucRoutGrpCount)
      {
        SoAd_GucRoutGrpCount = 0;
        SoAd_GucRoutGrpCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(SoAd_GucRoutGrpCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestSoAd_SD_EnableDisableRouting */

boolean TestSoAd_SD_EnableRouting(App_DataValidateType LucDataValidate,
  SoAd_RoutingGroupIdType LddRoutGrpId)
{
  return TestSoAd_SD_EnableDisableRouting(LucDataValidate, LddRoutGrpId, TRUE);
}

boolean TestSoAd_SD_DisableRouting(App_DataValidateType LucDataValidate,
  SoAd_RoutingGroupIdType LddRoutGrpId)
{
  return TestSoAd_SD_EnableDisableRouting(LucDataValidate, LddRoutGrpId, FALSE);
}

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
