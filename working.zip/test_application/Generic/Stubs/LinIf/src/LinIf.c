/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: LinIf.c                                                       **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PDU Router                                            **
**                                                                            **
**  PURPOSE   : This application file contains the LinIf functions            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0    30-Aug-2012   Ravi Tiwari    Initial version                      **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "LinIf.h"

/*******************************************************************************
**                    LinIf Global Data Types                                 **
*******************************************************************************/
#ifdef LINSM_MODULE_ACTIVE
Std_ReturnType LinIf_GddGotoSleepReturn;
Std_ReturnType LinIf_GddWakeUpReturn;
Std_ReturnType LinIf_GddScheduleRequestReturn;
Std_ReturnType LinIf_GddSetTrcvModeReturn;
NetworkHandleType LinIf_GddChannelHandle;
LinIf_SchHandleType LinIf_GddScheduleHandle;
uint8 LinIf_GucGotoSleepCount;
uint8 LinIf_GucWakeUpCount;
uint8 LinIf_GucScheduleRequestCount;
uint8 LinIf_GucSetTrcvModeCount;
LinTrcv_TrcvModeType LinIf_GddTrcvMode;
#endif
#ifdef PDUR_MODULE_ACTIVE
Std_ReturnType LinIf_GddCancelTransmitReturn;
Std_ReturnType LinTp_GddTransmitReturn;
Std_ReturnType LinTp_GddChangeParameterReturn;
Std_ReturnType LinTp_GddCancelReceiveReturn;
Std_ReturnType LinTp_GddCancelTransmitReturn;
PduIdType LinTp_GaaLinTpParameter[LINTP_ARRAY_SIZE];
PduIdType LinTp_GaaLinTpValue[LINTP_ARRAY_SIZE];
PduIdType LinTp_GaaLinTpRxSduId[LINTP_ARRAY_SIZE];

Std_ReturnType LinIf_GddTransmitReturn;
PduIdType LinIf_GaaLinTxPduId[LINIF_ARRAY_SIZE];
PduIdType LinIf_GddPduIdForRet;
uint8 LinIf_GaaSduLength[LINIF_ARRAY_SIZE];
uint8 LinIf_GaaTransmitData[LINIF_ARRAY_SIZE][LINIF_DATA_LENGTH];
uint8 LinIf_GucTransmitCount;
uint8 LinIf_GucTransmitCheckCount;
#endif

#ifdef BSWM_MODULE_ACTIVE
uint8 LinIf_GucInitSeqCnt;
uint8 LinIf_GucInitCnt;
uint8 LinTp_GucInitCnt;

uint8 LinTp_GucInitSeqCnt;
#endif

#ifdef PDUR_MODULE_ACTIVE
/*******************************************************************************
**                     LinTp Global Data  Types                               **
*******************************************************************************/

PduIdType LinTp_GaaLinTpTxSduId[LINTP_ARRAY_SIZE];
uint8 LinTp_GaaSduLength[LINTP_ARRAY_SIZE];
uint8 LinTp_GaaTransmitData[LINTP_ARRAY_SIZE][LINTP_DATA_LENGTH];
Std_ReturnType LinTp_GddTransmitReturn;
uint8 LinTp_GucTransmitCount;
uint8 LinTp_GucTransmitCheckCount;
PduIdType LinTp_GddPduIdForRet;
/*******************************************************************************
**                     TestSetLinIf_TxPduIdForRet()                           **
*******************************************************************************/
void TestSetLinIf_TxPduIdForRet(PduIdType LddPduIdForRet)
{
  LinIf_GddPduIdForRet = LddPduIdForRet;
} /* End TestSetLinIf_TxPduIdForRet() */

/*******************************************************************************
**                              LinIf_Transmit()                              **
*******************************************************************************/
Std_ReturnType LinIf_Transmit(PduIdType LinTxPduId,
const PduInfoType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8* LpSduDataPtr;
  
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  LinIf_GaaLinTxPduId[LinIf_GucTransmitCount] = LinTxPduId;
  LinIf_GaaSduLength[LinIf_GucTransmitCount] = PduInfoPtr->SduLength;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > LINIF_DATA_LENGTH)
  {
    LucDataLength = LINIF_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->SduLength;
  }
  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    LinIf_GaaTransmitData[LinIf_GucTransmitCount][LucDataIndex] = 
      *LpSduDataPtr;
    LpSduDataPtr++;
  }
  /* Increment count variable to handle multiple invocations */
  if(LinIf_GucTransmitCount != LINIF_ARRAY_SIZE)
  {    
    LinIf_GucTransmitCount++;
  }
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((LinIf_GddPduIdForRet == LinTxPduId) ||
    (LinIf_GddTransmitReturn == E_NOT_OK))
  {
    LinIf_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif
  #endif
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(LinIf_GddTransmitReturn);
  #endif
} /* End LinIf_Transmit() */

/*******************************************************************************
**                            TestLinIf_Transmit()                            **
*******************************************************************************/
boolean TestLinIf_Transmit(App_DataValidateType LucDataValidate,
PduIdType ExpLinTxPduId, const PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinIf_GucTransmitCount == 0x01) && 
        (ExpLinTxPduId == LinIf_GaaLinTxPduId[0]))
      {
        ActPduInfo.SduLength = LinIf_GaaSduLength[0];
        ActPduInfo.SduDataPtr = &LinIf_GaaTransmitData[0][0];

        /* Validate SduLength and Data */
        if(LinIfTest_ValidateData((PduInfoType *)ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      LinIf_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinIf_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinIf_GucTransmitCheckCount <= LinIf_GucTransmitCount) &&
        (ExpLinTxPduId == LinIf_GaaLinTxPduId[LinIf_GucTransmitCheckCount]))
      {
        ActPduInfo.SduLength =
          LinIf_GaaSduLength[LinIf_GucTransmitCheckCount];
        ActPduInfo.SduDataPtr =
          &LinIf_GaaTransmitData[LinIf_GucTransmitCheckCount][0];

        /* Validate the SduLength and Data */
        if(LinIfTest_ValidateData((PduInfoType *)ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinIf_GucTransmitCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinIf_GucTransmitCheckCount == LinIf_GucTransmitCount)
      {
        LinIf_GucTransmitCount = 0;
        LinIf_GucTransmitCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinIf_GucTransmitCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinTxPduId == LinIf_GaaLinTxPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinIf_Transmit() */

/*******************************************************************************
**                          TestLinIf_TransmitSetRetVal()                     **
*******************************************************************************/
void TestLinIf_TransmitSetRetVal(Std_ReturnType LddRetVal)
{
  LinIf_GddTransmitReturn = LddRetVal;
}/* End TestLinIf_TransmitSetRetVal() */

/*******************************************************************************
**                       LinIfTest_ValidateData()                             **
*******************************************************************************/
boolean LinIfTest_ValidateData(PduInfoType* LddExpPduInfo, 
PduInfoType* LddActPduInfo)
{
  uint8 *LpActualDataPtr;
  uint8 *LpExpDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  LddSduCount = LddExpPduInfo->SduLength;
  LpExpDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  if((LddExpPduInfo->SduLength <= LINIF_DATA_LENGTH) &&
    (LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }
  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    if(*LpActualDataPtr != *LpExpDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualDataPtr++;
    LpExpDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* End LinIfTest_ValidateData() */

/*******************************************************************************
**                       TestLinTp_DefaultBehavior()                          **
*******************************************************************************/
void TestLinTp_DefaultBehavior(void)
{
  LinTp_GddTransmitReturn = E_OK;
  LinTp_GucTransmitCount = 0;
  LinTp_GucTransmitCheckCount = 0;
  LinTp_GddPduIdForRet = (PduIdType)0xFFFF;
} /* End TestLinTp_DefaultBehavior() */

/*******************************************************************************
**                     TestSetLinTp_TxPduIdForRet()                           **
*******************************************************************************/
void TestSetLinTp_TxPduIdForRet(PduIdType LddPduIdForRet)
{
  LinTp_GddPduIdForRet = LddPduIdForRet;
} /* End TestSetLinTp_TxPduIdForRet() */

/*******************************************************************************
**                              LinTp_Transmit()                              **
*******************************************************************************/
Std_ReturnType LinTp_Transmit(PduIdType LinTpTxSduId,
const PduInfoType *LinTpTxInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8* LpSduDataPtr;

  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  LinTp_GaaLinTpTxSduId[LinTp_GucTransmitCount] = LinTpTxSduId;
  LinTp_GaaSduLength[LinTp_GucTransmitCount] = LinTpTxInfoPtr->SduLength;
  LpSduDataPtr = LinTpTxInfoPtr->SduDataPtr;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(LinTpTxInfoPtr->SduLength > LINTP_DATA_LENGTH)
  {
    LucDataLength = LINTP_DATA_LENGTH;
  }
  else
  {
    LucDataLength = LinTpTxInfoPtr->SduLength;
  }
  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    LinTp_GaaTransmitData[LinTp_GucTransmitCount][LucDataIndex] =
      *LpSduDataPtr;
    LpSduDataPtr++;
  }
  /* Increment count variable to handle multiple invocations */
  if(LinTp_GucTransmitCount != LINTP_ARRAY_SIZE)
  {
    LinTp_GucTransmitCount++;
  }
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((LinTp_GddPduIdForRet == LinTpTxSduId) ||
    (LinTp_GddTransmitReturn == E_NOT_OK))
  {
    LinTp_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif
  #endif
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(LinTp_GddTransmitReturn);
  #endif
} /* End LinTp_Transmit() */

/*******************************************************************************
**                            TestLinTp_Transmit()                            **
*******************************************************************************/
boolean TestLinTp_Transmit(App_DataValidateType LucDataValidate,
PduIdType ExpLinTpTxSduId, const PduInfoType *ExpLinTpTxInfoPtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTp_GucTransmitCount == 0x01) &&
        (ExpLinTpTxSduId == LinTp_GaaLinTpTxSduId[0]))
      {
          LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTp_GucTransmitCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTp_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }

    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTp_GucTransmitCheckCount <= LinTp_GucTransmitCount) &&
        (ExpLinTpTxSduId == LinTp_GaaLinTpTxSduId[LinTp_GucTransmitCheckCount]))
      {
        ActPduInfo.SduLength =
          LinTp_GaaSduLength[LinTp_GucTransmitCheckCount];
        ActPduInfo.SduDataPtr =
          &LinTp_GaaTransmitData[LinTp_GucTransmitCheckCount][0];

        /* Validate the SduLength and Data */
        if(LinTpTest_ValidateData((PduInfoType *)ExpLinTpTxInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTp_GucTransmitCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTp_GucTransmitCheckCount == LinTp_GucTransmitCount)
      {
        LinTp_GucTransmitCount = 0;
        LinTp_GucTransmitCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */

    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTp_GucTransmitCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinTpTxSduId == LinTp_GaaLinTpTxSduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTp_Transmit() */

/*******************************************************************************
**                          TestLinTp_TransmitSetRetVal()                     **
*******************************************************************************/
void TestLinTp_TransmitSetRetVal(Std_ReturnType LddRetVal)
{
  LinTp_GddTransmitReturn = LddRetVal;
}/* End TestLinTp_TransmitSetRetVal() */

/*******************************************************************************
**                       LinTpTest_ValidateData()                             **
*******************************************************************************/
boolean LinTpTest_ValidateData(PduInfoType* LddExpPduInfo,
PduInfoType* LddActPduInfo)
{
  uint8 *LpActualDataPtr;
  uint8 *LpExpDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  LddSduCount = LddExpPduInfo->SduLength;
  LpExpDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  if((LddExpPduInfo->SduLength <= LINTP_DATA_LENGTH) &&
    (LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }
  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    if(*LpActualDataPtr != *LpExpDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualDataPtr++;
    LpExpDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* End LinTpTest_ValidateData() */

#endif

#ifdef LINSM_MODULE_ACTIVE
/*******************************************************************************
**                            LinIf_GotoSleep()                               **
*******************************************************************************/
Std_ReturnType LinIf_GotoSleep(NetworkHandleType Channel)
{
  #ifndef TYPICAL_CONFIG
  LinIf_GddChannelHandle = Channel;
  LinIf_GucGotoSleepCount++;
  #endif
  return(LinIf_GddGotoSleepReturn);
}

/*******************************************************************************
**                          TestLinIf_GotoSleepSetRetVal()                     **
*******************************************************************************/
void TestLinIf_GotoSleepSetRetVal(Std_ReturnType LddRetVal)
{
  LinIf_GddGotoSleepReturn = LddRetVal;
}

/*******************************************************************************
**                        TestLinIf_GotoSleep()                               **
*******************************************************************************/
boolean TestLinIf_GotoSleep(App_DataValidateType LucDataValidate,
  NetworkHandleType ExpChannel)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    case S_VALIDATE:
    {
      /* Validate the channel handle and states */
      if((LinIf_GucGotoSleepCount == 0x01)
        && (LinIf_GddChannelHandle == ExpChannel))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API Invocation Count to Zero */
      LinIf_GucGotoSleepCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinIf_GucGotoSleepCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinIf_GotoSleep() */

/*******************************************************************************
**                            LinIf_WakeUp()                                  **
*******************************************************************************/
Std_ReturnType LinIf_Wakeup(NetworkHandleType Channel)
{
  #ifndef TYPICAL_CONFIG
  LinIf_GddChannelHandle = Channel;
  LinIf_GucWakeUpCount++;
  #endif
  return(LinIf_GddWakeUpReturn);
}

/*******************************************************************************
**                          TestLinIf_WakeUpSetRetVal()                     **
*******************************************************************************/
void TestLinIf_WakeUpSetRetVal(Std_ReturnType LddRetVal)
{
  LinIf_GddWakeUpReturn = LddRetVal;
}

/*******************************************************************************
**                        TestLinIf_WakeUp()                                  **
*******************************************************************************/
boolean TestLinIf_WakeUp(App_DataValidateType LucDataValidate,
  NetworkHandleType ExpChannel)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    case S_VALIDATE:
    {
      /* Validate the channel handle and states */
      if((LinIf_GucWakeUpCount == 0x01)
        && (LinIf_GddChannelHandle == ExpChannel))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API Invocation Count to Zero */
      LinIf_GucWakeUpCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinIf_GucWakeUpCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinIf_WakeUp() */

/*******************************************************************************
**                            LinIf_ScheduleRequest()                         **
*******************************************************************************/
Std_ReturnType LinIf_ScheduleRequest(NetworkHandleType Channel, 
  LinIf_SchHandleType Schedule)
{
  #ifndef TYPICAL_CONFIG
  LinIf_GddChannelHandle = Channel;
  LinIf_GddScheduleHandle = Schedule;
  LinIf_GucScheduleRequestCount++;
  #endif
  return(LinIf_GddScheduleRequestReturn);
}

/*******************************************************************************
**                     TestLinIf_ScheduleRequestSetRetVal()                   **
*******************************************************************************/
void TestLinIf_ScheduleRequestSetRetVal(Std_ReturnType LddRetVal)
{
  LinIf_GddScheduleRequestReturn = LddRetVal;
}

/*******************************************************************************
**                        TestLinIf_ScheduleRequest()                         **
*******************************************************************************/
boolean TestLinIf_ScheduleRequest(App_DataValidateType LucDataValidate,
  NetworkHandleType ExpChannel, LinIf_SchHandleType ExpSchedule)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    case S_VALIDATE:
    {
      /* Validate the channel handle and states */
      if((LinIf_GucScheduleRequestCount == 0x01)&& 
      (LinIf_GddChannelHandle == ExpChannel) && 
      (LinIf_GddScheduleHandle == ExpSchedule))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API Invocation Count to Zero */
      LinIf_GucScheduleRequestCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinIf_GucScheduleRequestCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinIf_ScheduleRequest() */

/*******************************************************************************
**                            LinIf_SetTrcvMode()                             **
*******************************************************************************/
Std_ReturnType LinIf_SetTrcvMode(NetworkHandleType Channel, 
  LinTrcv_TrcvModeType TransceiverMode)
{
  #ifndef TYPICAL_CONFIG
  LinIf_GddChannelHandle = Channel;
  LinIf_GddTrcvMode = TransceiverMode;
  LinIf_GucSetTrcvModeCount++;
  #endif
  return(LinIf_GddSetTrcvModeReturn);
}

/*******************************************************************************
**                        TestLinIf_SetTrcvMode()                             **
*******************************************************************************/
boolean TestLinIf_SetTrcvMode(App_DataValidateType LucDataValidate,
  NetworkHandleType ExpChannel, LinTrcv_TrcvModeType ExpTransceiverMode)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    case S_VALIDATE:
    {
      /* Validate the channel handle and states */
      if((LinIf_GucSetTrcvModeCount >= 0x01)&& 
      (LinIf_GddChannelHandle == ExpChannel) && 
      (LinIf_GddTrcvMode == ExpTransceiverMode))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API Invocation Count to Zero */
      LinIf_GucSetTrcvModeCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinIf_GucSetTrcvModeCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinIf_SetTrcvMode() */
#endif

/*******************************************************************************
**                       TestLinIf_DefaultBehavior()                          **
*******************************************************************************/
void TestLinIf_DefaultBehavior(void)
{
  #ifdef LINSM_MODULE_ACTIVE
  LinIf_GddGotoSleepReturn = E_OK;
  LinIf_GddWakeUpReturn = E_OK;
  LinIf_GddScheduleRequestReturn = E_OK;
  LinIf_GucGotoSleepCount = 0;
  LinIf_GucWakeUpCount = 0;
  LinIf_GucScheduleRequestCount = 0;
  LinIf_GucSetTrcvModeCount = 0;
  #endif
  
  #ifdef PDUR_MODULE_ACTIVE
  LinIf_GddTransmitReturn = E_OK;
  LinIf_GucTransmitCount = 0;
  LinIf_GucTransmitCheckCount = 0;
  LinIf_GddPduIdForRet = (PduIdType)0xFFFF;
  #endif
} /* End TestLinIf_DefaultBehavior() */
#ifdef BSWM_MODULE_ACTIVE

/*******************************************************************************
**                          LinIf_Init()                                      **
*******************************************************************************/

void LinIf_Init(const LinIf_ConfigType* ConfigPtr)
{
  UNUSED(ConfigPtr);
	App_GucApiSeqCnt++;
	LinIf_GucInitSeqCnt = App_GucApiSeqCnt;
	LinIf_GucInitCnt++;
}/* End LinIf_Init() */

/*******************************************************************************
**                           TestLinIf_Init()                                 **
*******************************************************************************/
boolean TestLinIf_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(LinIf_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      LinIf_GucInitCnt = 0;
      LinIf_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(LinIf_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      LinIf_GucInitCnt = 0;
      LinIf_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLinIf_Init() */

/*******************************************************************************
**                          LinTp_Init()                                      **
*******************************************************************************/

void LinTp_Init(const LinTp_ConfigType* ConfigPtr)
{
  UNUSED(ConfigPtr);
	App_GucApiSeqCnt++;
	LinTp_GucInitSeqCnt = App_GucApiSeqCnt;
	LinTp_GucInitCnt++;
}/* End LinTp_Init() */

/*******************************************************************************
**                           TestLinTp_Init()                                 **
*******************************************************************************/
boolean TestLinTp_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(LinTp_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      LinTp_GucInitCnt = 0;
      LinTp_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(LinTp_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      LinTp_GucInitCnt = 0;
      LinTp_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLinTp_Init() */

#endif
#ifdef PDUR_MODULE_ACTIVE
/*******************************************************************************
**                       LinIf_CancelTransmit()                               **
*******************************************************************************/
Std_ReturnType LinIf_CancelTransmit(PduIdType id)
{
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  LinIf_GaaLinTxPduId[LinIf_GucTransmitCount] = id;
  /* Increment count variable to handle multiple invocations */
  if(LinIf_GucTransmitCount != LINIF_ARRAY_SIZE)
  {    
    LinIf_GucTransmitCount++;
  }
  
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((LinIf_GddPduIdForRet == id) ||
    (LinIf_GddCancelTransmitReturn == E_NOT_OK))
  {
    LinIf_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(LinIf_GddCancelTransmitReturn);
  #endif
}
/*******************************************************************************
**                            TestLinIf_CancelTransmit()                       **
*******************************************************************************/
boolean TestLinIf_CancelTransmit(App_DataValidateType LucDataValidate,
  PduIdType ExpLinIfTxSduId)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinIf_GucTransmitCount == 0x01) && 
        (ExpLinIfTxSduId == LinIf_GaaLinTxPduId[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      LinIf_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinIf_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinIf_CancelTransmit() */

/*******************************************************************************
**                          TestLinIf_CancelTransmitSetRetVal()                **
*******************************************************************************/
void TestLinIf_CancelTransmitSetRetVal(Std_ReturnType LddRetVal)
{
  LinIf_GddCancelTransmitReturn = LddRetVal;
}/* End TestLinIf_CancelTransmitSetRetVal() */

/*******************************************************************************
**                       LinTp_CancelTransmit()                               **
*******************************************************************************/
Std_ReturnType LinTp_CancelTransmit(PduIdType id)
{
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  LinTp_GaaLinTpTxSduId[LinTp_GucTransmitCount] = id;
  /* Increment count variable to handle multiple invocations */
  if(LinTp_GucTransmitCount != LINTP_ARRAY_SIZE)
  {    
    LinTp_GucTransmitCount++;
  }
  
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((LinTp_GddPduIdForRet == id) ||
    (LinTp_GddCancelTransmitReturn == E_NOT_OK))
  {
    LinTp_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(LinTp_GddCancelTransmitReturn);
  #endif
}
/*******************************************************************************
**                            TestLinTp_CancelTransmit()                       **
*******************************************************************************/
boolean TestLinTp_CancelTransmit(App_DataValidateType LucDataValidate,
  PduIdType ExpLinTpTxSduId)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTp_GucTransmitCount == 0x01) && 
        (ExpLinTpTxSduId == LinTp_GaaLinTpTxSduId[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTp_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTp_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTp_Transmit() */

/*******************************************************************************
**                          TestLinTp_CancelTransmitSetRetVal()                **
*******************************************************************************/
void TestLinTp_CancelTransmitSetRetVal(Std_ReturnType LddRetVal)
{
  LinTp_GddCancelTransmitReturn = LddRetVal;
}/* End TestLinTp_TransmitSetRetVal() */

/*******************************************************************************
**                       LinTp_CancelReceive()                                 **
*******************************************************************************/
Std_ReturnType LinTp_CancelReceive(PduIdType id)
{
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  LinTp_GaaLinTpRxSduId[LinTp_GucTransmitCount] = id;
  /* Increment count variable to handle multiple invocations */
  if(LinTp_GucTransmitCount != LINTP_ARRAY_SIZE)
  {    
    LinTp_GucTransmitCount++;
  }
  
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((LinTp_GddPduIdForRet == id) ||
    (LinTp_GddCancelReceiveReturn == E_NOT_OK))
  {
    LinTp_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(LinTp_GddCancelReceiveReturn);
  #endif
}
/*******************************************************************************
**                            TestLinTp_CancelReceive()                        **
*******************************************************************************/
boolean TestLinTp_CancelReceive(App_DataValidateType LucDataValidate,
  PduIdType ExpLinTpRxSduId)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTp_GucTransmitCount == 0x01) && 
        (ExpLinTpRxSduId == LinTp_GaaLinTpRxSduId[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTp_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTp_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTp_CancelReceive() */

/*******************************************************************************
**                          TestLinTp_CancelReceiveSetRetVal()                **
*******************************************************************************/
void TestLinTp_CancelReceiveSetRetVal(Std_ReturnType LddRetVal)
{
  LinTp_GddCancelReceiveReturn = LddRetVal;
}/* End TestLinTp_CancelReceiveSetRetVal() */
/*******************************************************************************
**                       LinTp_ChangeParameter()                               **
*******************************************************************************/
Std_ReturnType LinTp_ChangeParameter(PduIdType id,
    TPParameterType parameter, uint16 value)
{  
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  LinTp_GaaLinTpTxSduId[LinTp_GucTransmitCount] = id;
  LinTp_GaaLinTpParameter[LinTp_GucTransmitCount] = parameter;
  LinTp_GaaLinTpValue[LinTp_GucTransmitCount] = value;
  /* Increment count variable to handle multiple invocations */
  if(LinTp_GucTransmitCount != LINTP_ARRAY_SIZE)
  {    
    LinTp_GucTransmitCount++;
  }
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((LinTp_GddPduIdForRet == id) ||
    (LinTp_GddChangeParameterReturn == E_NOT_OK))
  {
    LinTp_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(LinTp_GddChangeParameterReturn);
  #endif
}

/*******************************************************************************
**                            TestLinTp_ChangeParameter()                      **
*******************************************************************************/
boolean TestLinTp_ChangeParameter(App_DataValidateType LucDataValidate,
  PduIdType ExpLinTpTxSduId, TPParameterType ExpParameter, uint16 Expvalue)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTp_GucTransmitCount == 0x01) && 
        (ExpLinTpTxSduId == LinTp_GaaLinTpTxSduId[0]) && 
        (ExpParameter == LinTp_GaaLinTpParameter[0]) && 
        (ExpParameter == LinTp_GaaLinTpValue[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTp_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTp_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTp_Transmit() */

/*******************************************************************************
**                          TestLinTp_ChangeParameterSetRetVal()                           **
*******************************************************************************/
void TestLinTp_ChangeParameterSetRetVal(Std_ReturnType LddRetVal)
{
  LinTp_GddChangeParameterReturn = LddRetVal;
}/* End TestLinTp_TransmitSetRetVal() */
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
