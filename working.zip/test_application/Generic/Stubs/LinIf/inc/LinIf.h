/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: LinIf.h                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Lin Interface Stub                                    **
**                                                                            **
**  PURPOSE   : C header for LinIf.c                                          **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By          Description                            **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Creation of LinIf.h module             **
*******************************************************************************/

#ifndef LINIF_H
#define LINIF_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"   /* ComStack types header file */
#include "TC_Generic.h"
#include "Lin_GeneralTypes.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define LINIF_AR_RELEASE_MAJOR_VERSION         0x04
#define LINIF_AR_RELEASE_MINOR_VERSION         0x00
#define LINIF_AR_RELEASE_REVISION_VERSION      0x03

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define LINIF_DATA_LENGTH                      0x08
#define LINIF_ARRAY_SIZE                       0x04
#define LINTP_ARRAY_SIZE                       0x04
#define LINTP_DATA_LENGTH                      0x08
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
typedef uint8 LinIf_ConfigType;
typedef uint8 LinTp_ConfigType;

/* LinIf Schedule Handle type */
typedef uint8 LinIf_SchHandleType;

typedef enum
{
  LINTP_APPLICATIVE_SCHEDULE = 0,
  LINTP_DIAG_REQUEST,
  LINTP_DIAG_RESPONSE
}LinTp_Mode;

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern void TestLinIf_DefaultBehavior(void);

extern void TestSetLinIf_TxPduIdForRet(PduIdType LddPduIdForRet);
extern void TestLinIf_TransmitSetRetVal(Std_ReturnType LddRetVal);

extern Std_ReturnType LinIf_Transmit(PduIdType LinTxPduId,
  const PduInfoType *PduInfoPtr);
extern boolean TestLinIf_Transmit(App_DataValidateType LucDataValidate,
  PduIdType ExpLinTxPduId, const PduInfoType *ExpPduInfoPtr);

extern Std_ReturnType LinIf_CancelTransmit(PduIdType id);

extern boolean LinIfTest_ValidateData(PduInfoType* LddExpPduInfo,
  PduInfoType* LddActPduInfo);

extern Std_ReturnType LinIf_Wakeup(NetworkHandleType Channel);
/* Extern for TestLinIf_WakeUp */
extern boolean TestLinIf_WakeUp(App_DataValidateType LucDataValidate,
  NetworkHandleType ExpChannel);
  
/* Extern for LinIf_GotoSleep */
extern Std_ReturnType LinIf_GotoSleep(NetworkHandleType Channel);

/* Extern for TestLinIf_GotoSleepSetRetVal */
extern void TestLinIf_GotoSleepSetRetVal(Std_ReturnType LddRetVal);

/* Extern for TestLinIf_GotoSleep */
extern boolean TestLinIf_GotoSleep(App_DataValidateType LucDataValidate,
  NetworkHandleType ExpChannel);

/* Extern for TestLinIf_WakeUpSetRetVal */
extern void TestLinIf_WakeUpSetRetVal(Std_ReturnType LddRetVal);

  
  /* Extern for LinIf_ScheduleRequest */
extern Std_ReturnType LinIf_ScheduleRequest(NetworkHandleType Channel, 
  LinIf_SchHandleType Schedule);
  
  /* Extern for TestLinIf_ScheduleRequestSetRetVal */
extern void TestLinIf_ScheduleRequestSetRetVal(Std_ReturnType LddRetVal);
  
  /* Extern for TestLinIf_ScheduleRequest */
extern boolean TestLinIf_ScheduleRequest(App_DataValidateType LucDataValidate,
  NetworkHandleType ExpChannel, LinIf_SchHandleType ExpSchedule);
  
  /* Extern for LinIf_SetTrcvMode */
extern Std_ReturnType LinIf_SetTrcvMode(NetworkHandleType Channel, 
  LinTrcv_TrcvModeType TransceiverMode); 
  
  /* Extern for TestLinIf_SetTrcvMode */
extern boolean TestLinIf_SetTrcvMode(App_DataValidateType LucDataValidate,
  NetworkHandleType ExpChannel, LinTrcv_TrcvModeType ExpTransceiverMode);
  
extern void TestLinTp_DefaultBehavior(void);

extern void TestSetLinTp_TxPduIdForRet(PduIdType LddPduIdForRet);

extern Std_ReturnType LinTp_Transmit(PduIdType LinTpTxSduId,
const PduInfoType *LinTpTxInfoPtr);

extern void TestLinTp_TransmitSetRetVal(Std_ReturnType LddRetVal);

extern boolean TestLinTp_Transmit(App_DataValidateType LucDataValidate,
PduIdType ExpLinTpTxSduId, const PduInfoType *ExpLinTpTxInfoPtr);

extern boolean LinTpTest_ValidateData(PduInfoType* LddExpPduInfo, 
PduInfoType* LddActPduInfo);

extern void LinIf_Init(const LinIf_ConfigType* ConfigPtr);

extern boolean TestLinIf_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
  
extern void LinTp_Init(const LinTp_ConfigType* ConfigPtr);

extern boolean TestLinTp_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
  
extern Std_ReturnType LinTp_ChangeParameter(PduIdType id,
    TPParameterType parameter, uint16 value);
    
extern Std_ReturnType LinTp_CancelTransmit(PduIdType id);
extern boolean TestLinTp_ChangeParameter(App_DataValidateType LucDataValidate,
  PduIdType ExpLinTpTxSduId, TPParameterType ExpParameter, uint16 Expvalue);
extern void TestLinTp_CancelTransmitSetRetVal(Std_ReturnType LddRetVal);
extern Std_ReturnType LinTp_CancelReceive(PduIdType id);
extern boolean TestLinTp_CancelReceive(App_DataValidateType LucDataValidate,
  PduIdType ExpLinTpRxSduId);
extern void TestLinTp_CancelReceiveSetRetVal(Std_ReturnType LddRetVal);
#endif /* LINIF_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
