/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: CanTp.c                                                       **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CanTp Stub                                            **
**                                                                            **
**  PURPOSE   : This application file contains the CanTp Stub functions       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "CanTp.h"
#include "CanTp_Cbk.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
PduIdType CanTp_GaaCanTpTxSduId[CANTP_ARRAY_SIZE];
PduIdType CanTp_GaaCanTpRxSduId[CANTP_ARRAY_SIZE];
PduIdType CanTp_GaaCanTpParameter[CANTP_ARRAY_SIZE];
uint16 CanTp_GaaCanTpValue[CANTP_ARRAY_SIZE];
uint8 CanTp_GaaSduLength[CANTP_ARRAY_SIZE];
uint8 CanTp_GaaTransmitData[CANTP_ARRAY_SIZE][CANTP_DATA_LENGTH];
Std_ReturnType CanTp_GddTransmitReturn;
Std_ReturnType CanTp_GddChangeParameterReturn;
Std_ReturnType CanTp_GddCancelTransmitReturn;
Std_ReturnType CanTp_GddCancelReceiveReturn;
uint8 CanTp_GucTransmitCount;
uint8 CanTp_GucTransmitCheckCount;
PduIdType CanTp_GddPduIdForRet;

#ifdef BSWM_MODULE_ACTIVE
uint8 CanTp_GucInitSeqCnt;
uint8 CanTp_GucInitCnt;
#endif

/* Variables used for CanIf module */
uint8 CanTp_GucTxConfirmCount;
uint8 CanTp_GucTxConfirmCheckCount;
PduIdType CanTp_GucTxPduId;
uint8 CanTp_GucRxIndiCount;
PduIdType CanTp_GucRxPduId;
uint8 CanTp_GaaRxIndSduData[CANTP_DATA_LENGTH];
uint8 CanTp_GucRxIndSduLength;

/*******************************************************************************
**                     TestSetCanTp_TxPduIdForRet()                           **
*******************************************************************************/
void TestSetCanTp_TxPduIdForRet(PduIdType LddPduIdForRet)
{
  CanTp_GddPduIdForRet = LddPduIdForRet;
} /* End TestSetCanTp_TxPduIdForRet() */

/*******************************************************************************
**                              CanTp_Transmit()                              **
*******************************************************************************/
Std_ReturnType CanTp_Transmit(PduIdType CanTpTxSduId,
const PduInfoType *CanTpTxInfoPtr)
{
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8* LpSduDataPtr;

  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  CanTp_GaaCanTpTxSduId[CanTp_GucTransmitCount] = CanTpTxSduId;
  CanTp_GaaSduLength[CanTp_GucTransmitCount] = CanTpTxInfoPtr->SduLength;
  LpSduDataPtr = CanTpTxInfoPtr->SduDataPtr;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(CanTpTxInfoPtr->SduLength > CANTP_DATA_LENGTH)
  {
    LucDataLength = CANTP_DATA_LENGTH;
  }
  else
  {
    LucDataLength = CanTpTxInfoPtr->SduLength;
  }
  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    CanTp_GaaTransmitData[CanTp_GucTransmitCount][LucDataIndex] =
      *LpSduDataPtr;
    LpSduDataPtr++;
  }
  /* Increment count variable to handle multiple invocations */
  if(CanTp_GucTransmitCount != CANTP_ARRAY_SIZE)
  {
    CanTp_GucTransmitCount++;
  }
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((CanTp_GddPduIdForRet == CanTpTxSduId) ||
    (CanTp_GddTransmitReturn == E_NOT_OK))
  {
    CanTp_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #else
  return(CanTp_GddTransmitReturn);
  #endif
} /* End CanTp_Transmit() */

/*******************************************************************************
**                            TestCanTp_Transmit()                            **
*******************************************************************************/
boolean TestCanTp_Transmit(App_DataValidateType LucDataValidate,
PduIdType ExpCanTpTxSduId, const PduInfoType *ExpCanTpTxInfoPtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((CanTp_GucTransmitCount == 0x01) &&
        (ExpCanTpTxSduId == CanTp_GaaCanTpTxSduId[0]))
      {
        ActPduInfo.SduLength = CanTp_GaaSduLength[0];
        ActPduInfo.SduDataPtr = &CanTp_GaaTransmitData[0][0];

        /* Validate SduLength and Data */
        if(CanTpTest_ValidateData((PduInfoType *)ExpCanTpTxInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      CanTp_GucTransmitCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTp_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }

    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((CanTp_GucTransmitCheckCount <= CanTp_GucTransmitCount) &&
        (ExpCanTpTxSduId == CanTp_GaaCanTpTxSduId[CanTp_GucTransmitCheckCount]))
      {
        ActPduInfo.SduLength =
          CanTp_GaaSduLength[CanTp_GucTransmitCheckCount];
        ActPduInfo.SduDataPtr =
          &CanTp_GaaTransmitData[CanTp_GucTransmitCheckCount][0];

        /* Validate the SduLength and Data */
        if(CanTpTest_ValidateData((PduInfoType *)ExpCanTpTxInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTp_GucTransmitCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTp_GucTransmitCheckCount == CanTp_GucTransmitCount)
      {
        CanTp_GucTransmitCount = 0;
        CanTp_GucTransmitCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */

    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < CanTp_GucTransmitCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpCanTpTxSduId == CanTp_GaaCanTpTxSduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCanTp_Transmit() */

/*******************************************************************************
**                          TestCanTp_TransmitSetRetVal()                     **
*******************************************************************************/
void TestCanTp_TransmitSetRetVal(Std_ReturnType LddRetVal)
{
  CanTp_GddTransmitReturn = LddRetVal;
}/* End TestCanTp_TransmitSetRetVal() */

/*******************************************************************************
**                     CanTp_TxConfirmation()                                 **
*******************************************************************************/
void CanTp_TxConfirmation(PduIdType TxPduId)
{
  /* Load actual TxPduId into Global variables */
  CanTp_GucTxPduId = TxPduId;
  CanTp_GucTxConfirmCount++;
}
/* End of CanTp_TxConfirmation() */

/*******************************************************************************
**                     TestCanTp_TxConfirmation()                             **
*******************************************************************************/
boolean TestCanTp_TxConfirmation(App_DataValidateType LddDataValidate,
PduIdType ExpTxPduId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TxPduId */
      if((CanTp_GucTxConfirmCount == 0x01) &&
        (CanTp_GucTxPduId == ExpTxPduId))

      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTp_GucTxConfirmCount = 0;
      CanTp_GucTxConfirmCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTp_GucTxConfirmCount; LucIndex++)
      {
        /* Validate TxPduId */
        if(CanTp_GucTxPduId == ExpTxPduId)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTp_GucTxConfirmCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTp_GucTxConfirmCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTp_GucTxConfirmCheckCount == CanTp_GucTxConfirmCount)
      {
        CanTp_GucTxConfirmCount = 0;
        CanTp_GucTxConfirmCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTp_GucTxConfirmCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCanTp_TxConfirmation() */

/*******************************************************************************
**                       CanTp_RxIndication()                                 **
*******************************************************************************/
void CanTp_RxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr)
{
  uint8 LucDataIndex;
  uint8* LpSduDataPtr;

  /* Load actual TxPduId  Sdulength and SduDataPt into Global variables */
  CanTp_GucRxIndiCount++;
  CanTp_GucRxPduId = RxPduId;

  CanTp_GucRxIndSduLength = PduInfoPtr->SduLength;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;

  for(LucDataIndex = 0x00; LucDataIndex < CanTp_GucRxIndSduLength;
    LucDataIndex++)
  {
    CanTp_GaaRxIndSduData[LucDataIndex] = *LpSduDataPtr;
    LpSduDataPtr++;
  }
}
/* End of CanTp_RxIndication() */

/*******************************************************************************
**                   TestCanTp_RxIndication()                                 **
*******************************************************************************/
boolean TestCanTp_RxIndication(App_DataValidateType LddDataValidate,
PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType LstActPduInfo;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((CanTp_GucRxIndiCount == 0x01) && (CanTp_GucRxPduId == ExpRxPduId))
      {
        LstActPduInfo.SduLength = CanTp_GucRxIndSduLength;
        LstActPduInfo.SduDataPtr = &CanTp_GaaRxIndSduData[0];

        /* Validate SduLength and Data */
        if(CanTpTest_ValidateData((PduInfoType *)ExpPduInfoPtr,
          &LstActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      CanTp_GucRxIndiCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTp_GucRxIndiCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
       default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End of TestCanTp_RxIndication() */

/*******************************************************************************
**                       CanTpTest_ValidateData()                             **
*******************************************************************************/
boolean CanTpTest_ValidateData(PduInfoType* LddExpPduInfo,
PduInfoType* LddActPduInfo)
{
  uint8 *LpActualDataPtr;
  uint8 *LpExpDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  LddSduCount = LddExpPduInfo->SduLength;
  LpExpDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  if((LddExpPduInfo->SduLength <= CANTP_DATA_LENGTH) &&
    (LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }
  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    if(*LpActualDataPtr != *LpExpDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualDataPtr++;
    LpExpDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* End CanTpTest_ValidateData() */

/*******************************************************************************
**                       TestCanTp_DefaultBehavior()                          **
*******************************************************************************/
void TestCanTp_DefaultBehavior(void)
{
  CanTp_GddTransmitReturn = E_OK;
  CanTp_GucTransmitCount = 0;
  CanTp_GucTransmitCheckCount = 0;
  CanTp_GddPduIdForRet = (PduIdType)0xFFFF;
  CanTp_GucTxConfirmCount = 0;
  CanTp_GucTxConfirmCheckCount = 0;
  CanTp_GucRxIndiCount = 0;
} /* End TestCanTp_DefaultBehavior() */

#ifdef BSWM_MODULE_ACTIVE
/*******************************************************************************
**                          CanTp_Init()                                      **
*******************************************************************************/

void CanTp_Init(const CanTp_ConfigType* CfgPtr)
{
  UNUSED(CfgPtr);
	App_GucApiSeqCnt++;
	CanTp_GucInitSeqCnt = App_GucApiSeqCnt;
	CanTp_GucInitCnt++;
}/* End CanTp_Init() */

/*******************************************************************************
**                           TestCanTp_Init()                                   **
*******************************************************************************/
boolean TestCanTp_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(CanTp_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      CanTp_GucInitCnt = 0;
      CanTp_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(CanTp_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      CanTp_GucInitCnt = 0;
      CanTp_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCanTp_Init() */
#endif

/*******************************************************************************
**                       CanTp_CancelTransmit()                               **
*******************************************************************************/
Std_ReturnType CanTp_CancelTransmit(PduIdType id)
{
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  CanTp_GaaCanTpTxSduId[CanTp_GucTransmitCount] = id;
  /* Increment count variable to handle multiple invocations */
  if(CanTp_GucTransmitCount != CANTP_ARRAY_SIZE)
  {    
    CanTp_GucTransmitCount++;
  }
  
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((CanTp_GddPduIdForRet == id) ||
    (CanTp_GddCancelTransmitReturn == E_NOT_OK))
  {
    CanTp_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(CanTp_GddCancelTransmitReturn);
  #endif
}
/*******************************************************************************
**                            TestCanTp_CancelTransmit()                       **
*******************************************************************************/
boolean TestCanTp_CancelTransmit(App_DataValidateType LucDataValidate,
  PduIdType ExpCanTpTxSduId)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((CanTp_GucTransmitCount == 0x01) && 
        (ExpCanTpTxSduId == CanTp_GaaCanTpTxSduId[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      CanTp_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTp_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCanTp_Transmit() */

/*******************************************************************************
**                          TestCanTp_CancelTransmitSetRetVal()                **
*******************************************************************************/
void TestCanTp_CancelTransmitSetRetVal(Std_ReturnType LddRetVal)
{
  CanTp_GddCancelTransmitReturn = LddRetVal;
}/* End TestCanTp_TransmitSetRetVal() */

/*******************************************************************************
**                       CanTp_CancelReceive()                                 **
*******************************************************************************/
Std_ReturnType CanTp_CancelReceive(PduIdType id)
{
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  CanTp_GaaCanTpRxSduId[CanTp_GucTransmitCount] = id;
  /* Increment count variable to handle multiple invocations */
  if(CanTp_GucTransmitCount != CANTP_ARRAY_SIZE)
  {    
    CanTp_GucTransmitCount++;
  }
  
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((CanTp_GddPduIdForRet == id) ||
    (CanTp_GddCancelReceiveReturn == E_NOT_OK))
  {
    CanTp_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(CanTp_GddCancelReceiveReturn);
  #endif
}
/*******************************************************************************
**                            TestCanTp_CancelReceive()                        **
*******************************************************************************/
boolean TestCanTp_CancelReceive(App_DataValidateType LucDataValidate,
  PduIdType ExpCanTpRxSduId)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((CanTp_GucTransmitCount == 0x01) && 
        (ExpCanTpRxSduId == CanTp_GaaCanTpRxSduId[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      CanTp_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTp_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCanTp_CancelReceive() */

/*******************************************************************************
**                          TestCanTp_CancelReceiveSetRetVal()                **
*******************************************************************************/
void TestCanTp_CancelReceiveSetRetVal(Std_ReturnType LddRetVal)
{
  CanTp_GddCancelReceiveReturn = LddRetVal;
}/* End TestCanTp_CancelReceiveSetRetVal() */
/*******************************************************************************
**                       CanTp_ChangeParameter()                               **
*******************************************************************************/
Std_ReturnType CanTp_ChangeParameter(PduIdType id,
    TPParameterType parameter, uint16 value)
{  
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  CanTp_GaaCanTpTxSduId[CanTp_GucTransmitCount] = id;
  CanTp_GaaCanTpParameter[CanTp_GucTransmitCount] = parameter;
  CanTp_GaaCanTpValue[CanTp_GucTransmitCount] = value;
  /* Increment count variable to handle multiple invocations */
  if(CanTp_GucTransmitCount != CANTP_ARRAY_SIZE)
  {    
    CanTp_GucTransmitCount++;
  }
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((CanTp_GddPduIdForRet == id) ||
    (CanTp_GddChangeParameterReturn == E_NOT_OK))
  {
    CanTp_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(CanTp_GddChangeParameterReturn);
  #endif
}

/*******************************************************************************
**                            TestCanTp_ChangeParameter()                      **
*******************************************************************************/
boolean TestCanTp_ChangeParameter(App_DataValidateType LucDataValidate,
  PduIdType ExpCanTpTxSduId, TPParameterType ExpParameter, uint16 Expvalue)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;
  Expvalue = Expvalue;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((CanTp_GucTransmitCount == 0x01) && 
        (ExpCanTpTxSduId == CanTp_GaaCanTpTxSduId[0]) && 
        (ExpParameter == CanTp_GaaCanTpParameter[0]) && 
        (ExpParameter == CanTp_GaaCanTpValue[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      CanTp_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTp_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCanTp_Transmit() */

/*******************************************************************************
**                          TestCanTp_ChangeParameterSetRetVal()                           **
*******************************************************************************/
void TestCanTp_ChangeParameterSetRetVal(Std_ReturnType LddRetVal)
{
  CanTp_GddChangeParameterReturn = LddRetVal;
}/* End TestCanTp_TransmitSetRetVal() */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
