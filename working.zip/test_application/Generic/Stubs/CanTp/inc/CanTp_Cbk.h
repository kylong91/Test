/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: CanTp_Cbk.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CanTp_Cbk Stub                                        **
**                                                                            **
**  PURPOSE   : Declaration of CanTp_Cbk functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef CANTP_CBK_H
#define CANTP_CBK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void CanTp_TxConfirmation(PduIdType TxPduId);

extern void CanTp_RxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr);

extern boolean TestCanTp_TxConfirmation(App_DataValidateType LddDataValidate,
  PduIdType ExpTxPduId);

extern boolean TestCanTp_RxIndication(App_DataValidateType LddDataValidate,
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr);

#endif /* CANTP_CBK_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
