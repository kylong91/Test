/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: CanTp.h                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CanTp Stub                                            **
**                                                                            **
**  PURPOSE   : Declaration of CanTp Stub functions                           **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

#ifndef CANTP_H
#define CANTP_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"   /* ComStack types header file */
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define CANTP_AR_RELEASE_MAJOR_VERSION        0x04
#define CANTP_AR_RELEASE_MINOR_VERSION        0x00
#define CANTP_AR_RELEASE_REVISION_VERSION     0x02

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define CANTP_DATA_LENGTH                     0x40
#define CANTP_ARRAY_SIZE                      0x04

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
typedef uint8 CanTp_ConfigType;


/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void TestCanTp_DefaultBehavior(void);

extern void TestSetCanTp_TxPduIdForRet(PduIdType LddPduIdForRet);

extern Std_ReturnType CanTp_Transmit(PduIdType CanTpTxSduId,
  const PduInfoType *CanTpTxInfoPtr);

extern void TestCanTp_TransmitSetRetVal(Std_ReturnType LddRetVal);

extern Std_ReturnType CanTp_CancelTransmit(PduIdType id);
extern boolean TestCanTp_Transmit(App_DataValidateType LucDataValidate,
  PduIdType ExpCanTpTxSduId, const PduInfoType *ExpCanTpTxInfoPtr);

extern boolean CanTpTest_ValidateData(PduInfoType* LddExpPduInfo,
  PduInfoType* LddActPduInfo);

extern Std_ReturnType CanTp_CancelReceive(PduIdType CanTpRxSduId);
extern Std_ReturnType CanTp_ChangeParameter(PduIdType id,
    TPParameterType parameter, uint16 value);
    
extern boolean TestCanTp_ChangeParameter(App_DataValidateType LucDataValidate,
  PduIdType ExpCanTpTxSduId, TPParameterType ExpParameter, uint16 Expvalue);
extern void TestCanTp_CancelTransmitSetRetVal(Std_ReturnType LddRetVal);
extern boolean TestCanTp_CancelReceive(App_DataValidateType LucDataValidate,
  PduIdType ExpCanTpRxSduId);
extern void TestCanTp_CancelReceiveSetRetVal(Std_ReturnType LddRetVal);
extern void CanTp_Init(const CanTp_ConfigType* CfgPtr);

extern boolean TestCanTp_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
#endif /* CANTP_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
