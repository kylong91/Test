/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Fr_DriverB.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Fr_DriverB Stub                                       **
**                                                                            **
**  PURPOSE   : Declaration of Fr_DriverB Stub functions                      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/

#ifndef FR_TRCVA_H
#define FR_TRCVA_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
/*
 * This header file includes all the standard data types, platform dependent
 * header file and common return types
 */
#include "Std_Types.h"
#include "Fr_GeneralTypes.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define FRTRCV_AR_RELEASE_MAJOR_VERSION      0x04
#define FRTRCV_AR_RELEASE_MINOR_VERSION      0x00
#define FRTRCV_AR_RELEASE_REVISION_VERSION   0x03

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/


/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern Std_ReturnType FrTrcv_39_DriverA_SetTransceiverMode(uint8 FrTrcv_TrcvIdx,FrTrcv_TrcvModeType FrTrcv_TrcvMode);
extern Std_ReturnType FrTrcv_39_DriverA_GetTransceiverMode(uint8 FrTrcv_TrcvIdx, P2VAR(FrTrcv_TrcvModeType,AUTOAMATIC,FRIF_PRIVATE_DATA)FrTrcv_TrcvModePtr);
extern Std_ReturnType FrTrcv_39_DriverA_GetTransceiverWUReason(uint8 FrTrcv_TrcvIdx, P2VAR(FrTrcv_TrcvWUReasonType,AUTOAMATIC,FRIF_PRIVATE_DATA)FrTrcv_TrcvWUReasonPtr);
extern Std_ReturnType FrTrcv_39_DriverA_DisableTransceiverBranch(uint8 FrTrcv_TrcvIdx, uint8 FrTrcv_BranchIdx);
extern Std_ReturnType FrTrcv_39_DriverA_EnableTransceiverBranch(uint8 FrTrcv_TrcvIdx, uint8 FrTrcv_BranchIdx);
extern Std_ReturnType FrTrcv_39_DriverA_ClearTransceiverWakeup(uint8 FrTrcv_TrcvIdx);
extern Std_ReturnType FrTrcv_39_DriverA_GetTransceiverError(uint8 FrTrcv_TrcvIdx, uint8 FrTrcv_BranchIdx,P2VAR(uint32,AUTOAMATIC,FRIF_APPL_DATA)FrTrcv_BusErrorState);
extern void FrTrcv_39_DriverA_CheckWakeupByTransceiver(uint8 FrTrcv_TrcvIdx);




extern boolean TestFrTrcv_TransceiverACheckWakeupByTransceiver(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx, Fr_ChannelType
  FrIf_ChnlIdx);
  
extern boolean TestFrTrcv_TransceiverAClearTransceiverWakeup(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx, Fr_ChannelType 
  FrIf_ChnlIdx);
  
extern boolean TestFrTrcv_TransceiverAGetTransceiverMode(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx, Fr_ChannelType 
  FrIf_ChnlIdx, FrTrcv_TrcvModeType* FrIf_TrcvModePtr);
  
extern Std_ReturnType TestFrTrcv_TransceiverASetTransceiverMode(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx, Fr_ChannelType 
  FrIf_ChnlIdx, FrTrcv_TrcvModeType FrTrcv_TrcvMode);
  
extern Std_ReturnType TestFrTrcv_TransceiverADisableTransceiverBranch(
  App_DataValidateType LddDataValidate,uint8 FrTrcv_TrcvIdx, Fr_ChannelType 
  FrIf_ChnlIdx, uint8 FrTrcv_BranchIdx);
  
extern Std_ReturnType TestFrTrcv_TransceiverAEnableTransceiverBranch(
  App_DataValidateType LddDataValidate,uint8 FrTrcv_TrcvIdx, Fr_ChannelType 
  FrIf_ChnlIdx, uint8 FrTrcv_BranchIdx);
  
extern Std_ReturnType TestFrTrcv_TransceiverAGetTransceiverError(
  App_DataValidateType LddDataValidate, uint8 FrTrcv_TrcvIdx, Fr_ChannelType 
  FrIf_ChnlIdx, uint8 FrTrcv_BranchIdx, uint32* FrIf_BusErrorState);

#endif /* End FR_TRCVB_H */  
/*******************************************************************************
**                      End of Function Prototypes                            **
*******************************************************************************/
