/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: FrTrcv_39_DriverA.c                                           **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Fr_DriverA Stub                                       **
**                                                                            **
**  PURPOSE   : This application file contains the Fr_DriverA Stub functions  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Fr.h"
#include "FrTrcv_39_DriverA.h"
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
  uint8 Fr_GucTrcvACtrlIdx;
  uint8 Fr_GucTrcvACheckWakeupByTransceiver;
  uint8 Fr_GucTrcvAGetTransceiverError;
  uint8 Fr_GucTrcvABranchIdx;
  uint8 Fr_GucTrcvAClearTransceiverWakeup;
  uint8 Fr_GucTrcvAEnableTransceiverBranch;
  uint8 Fr_GucTrcvADisableTransceiverBranch;
  uint8 Fr_GucTrcvAGetTransceiverWUReason;
  uint8 Fr_GucTrcvAGetTransceiverMode;
  FrTrcv_TrcvModeType FrTrcv_TrcvMode;
  uint8 Fr_GucTrcvASetTransceiverMode;
  FrTrcv_TrcvModeType Fr_GucTrcvAMode;
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
**                     FrTrcv_39_DriverA_SetTransceiverMode()                 **
*******************************************************************************/
Std_ReturnType FrTrcv_39_DriverA_SetTransceiverMode(uint8 FrTrcv_TrcvIdx,
FrTrcv_TrcvModeType FrTrcv_TrcvMode)
{ 
  Fr_GucTrcvACtrlIdx = FrTrcv_TrcvIdx;
  Fr_GucTrcvAMode = FrTrcv_TrcvMode;
  Fr_GucTrcvASetTransceiverMode++;
  return E_OK;
}

/*******************************************************************************
**                  TestFrTrcv_39_DriverASetTransceiverMode()                 **
*******************************************************************************/
boolean TestFrTrcv_39_DriverASetTransceiverMode(App_DataValidateType 
LddDataValidate, uint8 FrTrcv_TrcvIdx, FrTrcv_TrcvModeType FrTrcv_TrcvMode)
{

  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
   /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      
      /* Validate invocation count and Mode  */
      if((Fr_GucTrcvASetTransceiverMode == 0x01) && 
          (Fr_GucTrcvACtrlIdx == FrTrcv_TrcvIdx) && 
           (Fr_GucTrcvAMode == FrTrcv_TrcvMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucTrcvASetTransceiverMode = 0;
      break;
    } /* End case S_VALIDATE: */
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestFrTrcv_39_DriverA_GetTransceiverWUReason() */

/*******************************************************************************
**                     FrTrcv_39_DriverA_GetTransceiverMode()                 **
*******************************************************************************/
Std_ReturnType FrTrcv_39_DriverA_GetTransceiverMode(uint8 FrTrcv_TrcvIdx,
P2VAR(FrTrcv_TrcvModeType, AUTOAMATIC, FRIF_PRIVATE_DATA)FrTrcv_TrcvModePtr)
{ 
  Fr_GucTrcvACtrlIdx = FrTrcv_TrcvIdx;
  *FrTrcv_TrcvModePtr  =0;
  Fr_GucTrcvAGetTransceiverMode++;
  return E_OK;
}

/*******************************************************************************
**                  TestFrTrcv_39_DriverAGetTransceiverMode()                 **
*******************************************************************************/
boolean TestFrTrcv_39_DriverAGetTransceiverMode(App_DataValidateType 
LddDataValidate, uint8 FrTrcv_TrcvIdx)
{

  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
   /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      
      /* Validate invocation count and Mode  */
      if((Fr_GucTrcvAGetTransceiverMode == 0x01) && 
          (Fr_GucTrcvACtrlIdx == FrTrcv_TrcvIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucTrcvAGetTransceiverMode = 0;
      break;
    } /* End case S_VALIDATE: */
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestFrTrcv_39_DriverAGetTransceiverMode() */

/*******************************************************************************
**                     FrTrcv_39_DriverA_GetTransceiverWUReason()             **
*******************************************************************************/
Std_ReturnType FrTrcv_39_DriverA_GetTransceiverWUReason(uint8 FrTrcv_TrcvIdx,
P2VAR(FrTrcv_TrcvWUReasonType, AUTOAMATIC, FRIF_PRIVATE_DATA)
FrTrcv_TrcvWUReasonPtr)
{ 
  Fr_GucTrcvACtrlIdx = FrTrcv_TrcvIdx;
  *FrTrcv_TrcvWUReasonPtr  = 0;
  Fr_GucTrcvAGetTransceiverWUReason++;
  return E_OK;
}

/*******************************************************************************
**                  TestFrTrcv_39_DriverA_GetTransceiverWUReason()            **
*******************************************************************************/
boolean TestFrTrcv_39_DriverA_GetTransceiverWUReason(App_DataValidateType 
LddDataValidate, uint8 FrTrcv_TrcvIdx)
{

  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
   /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      
      /* Validate invocation count and Mode  */
      if((Fr_GucTrcvAGetTransceiverWUReason == 0x01) && 
          (Fr_GucTrcvACtrlIdx == FrTrcv_TrcvIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucTrcvAGetTransceiverWUReason = 0;
      break;
    } /* End case S_VALIDATE: */
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestFrTrcv_39_DriverA_GetTransceiverWUReason() */

/*******************************************************************************
**                     FrTrcv_39_DriverA_DisableTransceiverBranch()           **
*******************************************************************************/
Std_ReturnType FrTrcv_39_DriverA_DisableTransceiverBranch(uint8 FrTrcv_TrcvIdx,
uint8 FrTrcv_BranchIdx)
{
  Fr_GucTrcvACtrlIdx = FrTrcv_TrcvIdx;
  Fr_GucTrcvABranchIdx = FrTrcv_BranchIdx;
  Fr_GucTrcvADisableTransceiverBranch++;
  return E_OK;
}

/*******************************************************************************
**                  TestFrTrcv_39_DisableTransceiverBranch()                  **
*******************************************************************************/
boolean TestFrTrcv_39_DisableTransceiverBranch(App_DataValidateType 
LddDataValidate, uint8 FrTrcv_TrcvIdx, uint8 FrTrcv_BranchIdx)
{

  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
   /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      
      /* Validate invocation count and Mode  */
      if((Fr_GucTrcvADisableTransceiverBranch == 0x01) && 
          (Fr_GucTrcvACtrlIdx == FrTrcv_TrcvIdx) &&
          (Fr_GucTrcvABranchIdx = FrTrcv_BranchIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucTrcvADisableTransceiverBranch = 0;
      break;
    } /* End case S_VALIDATE: */
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestFrTrcv_39_DisableTransceiverBranch() */

/*******************************************************************************
**                     FrTrcv_39_DriverA_EnableTransceiverBranch()            **
*******************************************************************************/
Std_ReturnType FrTrcv_39_DriverA_EnableTransceiverBranch(uint8 FrTrcv_TrcvIdx, 
uint8 FrTrcv_BranchIdx)
{
  Fr_GucTrcvACtrlIdx = FrTrcv_TrcvIdx;
  Fr_GucTrcvABranchIdx = FrTrcv_BranchIdx;
  Fr_GucTrcvAEnableTransceiverBranch++;
  return E_OK;
}

/*******************************************************************************
**                  TestFrTrcv_39_EnableTransceiverBranch()                   **
*******************************************************************************/
boolean TestFrTrcv_39_EnableTransceiverBranch(App_DataValidateType 
LddDataValidate, uint8 FrTrcv_TrcvIdx, uint8 FrTrcv_BranchIdx)
{

  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
   /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      
      /* Validate invocation count and Mode  */
      if((Fr_GucTrcvAEnableTransceiverBranch == 0x01) && 
          (Fr_GucTrcvACtrlIdx == FrTrcv_TrcvIdx) &&
          (Fr_GucTrcvABranchIdx = FrTrcv_BranchIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucTrcvAEnableTransceiverBranch = 0;
      break;
    } /* End case S_VALIDATE: */
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestFrTrcv_39_EnableTransceiverBranch() */

/*******************************************************************************
**                     FrTrcv_39_DriverA_ClearTransceiverWakeup()             **
*******************************************************************************/
Std_ReturnType FrTrcv_39_DriverA_ClearTransceiverWakeup(uint8 FrTrcv_TrcvIdx)
{ 
  Fr_GucTrcvACtrlIdx = FrTrcv_TrcvIdx;
  Fr_GucTrcvAClearTransceiverWakeup++;
  return E_OK;
}

/*******************************************************************************
**                  TestFrTrcv_39_DriverA_ClearTransceiverWakeup()            **
*******************************************************************************/
boolean TestFrTrcv_39_DriverA_ClearTransceiverWakeup(App_DataValidateType 
LddDataValidate, uint8 FrTrcv_TrcvIdx)
{

  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
   /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      
      /* Validate invocation count and Mode  */
      if((Fr_GucTrcvAClearTransceiverWakeup == 0x01) && 
          (Fr_GucTrcvACtrlIdx == FrTrcv_TrcvIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucTrcvAClearTransceiverWakeup = 0;
      break;
    } /* End case S_VALIDATE: */
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestFrTrcv_39_DriverA_ClearTransceiverWakeup() */

/*******************************************************************************
**                     FrTrcv_39_DriverA_GetTransceiverError()                **
*******************************************************************************/
Std_ReturnType FrTrcv_39_DriverA_GetTransceiverError(uint8 FrTrcv_TrcvIdx,
uint8 FrTrcv_BranchIdx,
P2VAR(uint32,AUTOAMATIC,FRIF_APPL_DATA)FrTrcv_BusErrorState)
{
  Fr_GucTrcvACtrlIdx = FrTrcv_TrcvIdx;
  Fr_GucTrcvABranchIdx = FrTrcv_BranchIdx;
  *FrTrcv_BusErrorState  =0;
  Fr_GucTrcvAGetTransceiverError++;
  return E_OK;
}

/*******************************************************************************
**                  TestFrTrcv_39_DriverAGetTransceiverError()                **
*******************************************************************************/
boolean TestFrTrcv_39_DriverAGetTransceiverError(App_DataValidateType 
LddDataValidate, uint8 FrTrcv_TrcvIdx, uint8 FrTrcv_BranchIdx)
{

  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
   /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      
      /* Validate invocation count and Mode  */
      if((Fr_GucTrcvAGetTransceiverError == 0x01) && 
          (Fr_GucTrcvACtrlIdx == FrTrcv_TrcvIdx) &&
          (Fr_GucTrcvABranchIdx = FrTrcv_BranchIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucTrcvAGetTransceiverError = 0;
      break;
    } /* End case S_VALIDATE: */
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestFrTrcv_39_DriverAGetTransceiverError() */

/*******************************************************************************
**                     FrTrcv_39_DriverA_CheckWakeupByTransceiver()           **
*******************************************************************************/
void FrTrcv_39_DriverA_CheckWakeupByTransceiver(uint8 FrTrcv_TrcvIdx)
{
  Fr_GucTrcvACtrlIdx = FrTrcv_TrcvIdx;
  Fr_GucTrcvACheckWakeupByTransceiver++;
}

/*******************************************************************************
**                  TestFrTrcv_39_DriverA_TrcvCheckWakeupByTransceiver()      **
*******************************************************************************/
boolean TestFrTrcv_39_DriverA_TrcvCheckWakeupByTransceiver(App_DataValidateType 
LddDataValidate, uint8 FrTrcv_TrcvIdx)
{

  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
   /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      
      /* Validate invocation count and Mode  */
      if((Fr_GucTrcvACheckWakeupByTransceiver == 0x01) && 
          (Fr_GucTrcvACtrlIdx == FrTrcv_TrcvIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucTrcvACheckWakeupByTransceiver = 0;
      break;
    } /* End case S_VALIDATE: */
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }

  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestFrTrcv_39_DriverA_TrcvCheckWakeupByTransceiver() */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/


