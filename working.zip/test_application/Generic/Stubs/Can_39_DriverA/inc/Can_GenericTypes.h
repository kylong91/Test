/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Can_GenericTypes.h                                            **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CAN Driver module                                     **
**                                                                            **
**  PURPOSE   : Declaration of Can functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     10/06/2011    BJV    Creation of Can_GenericTypes.h module       **
*******************************************************************************/
#ifndef CAN_GENERICTYPES_H
#define CAN_GENERICTYPES_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
typedef uint32 Can_IdType;
typedef uint32 Can_HwHandleType;

/* This is used to provide CAN-ID, DLC and SDU from CanIf to CAN Driver */
typedef struct Can_PduType
{
  /* CAN-ID */
  Can_IdType id;
  /* DLC */
  uint8 length;
  /* Pointer to L-SDU */
  uint8 *sdu;
  /* swPduHandle */
  PduIdType swPduHandle ;
} Can_PduType;

/* State transitions that are used by the function Can_SetControllerMode */
typedef enum
{
  CAN_T_START = 0,
  CAN_T_STOP,
  CAN_T_SLEEP,
  CAN_T_WAKEUP
}Can_StateTransitionType;

/* Return values of CAN Driver API */
typedef enum
{
  CAN_OK = 0,
  CAN_NOT_OK,
  CAN_BUSY
}Can_ReturnType;

#endif /* CAN_GENERICTYPES_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
