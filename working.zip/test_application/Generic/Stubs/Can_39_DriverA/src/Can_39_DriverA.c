/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Can_39_DriverA.c                                              **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Can_39_DriverA Stub                                   **
**                                                                            **
**  PURPOSE   : This application file contains the Can_39_DriverA stub        **
**              functions                                                     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     22-Jun-2011   BJV    Initial version                             **
**                                                                            **
** 4.0.1     20-Sep-2011   BPT    Updated for CanIf                           **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include"Can_39_DriverA.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Can_GucCheckController;
uint16 Can_GddBaudRateA;
uint8 Can_GucCheckBaudRateCountA;

uint8 Can_GucDrvASetCtrlModeCount;
uint8 Can_GucDrvASetController;
Can_StateTransitionType Can_GddDrvATransition;

uint8 Can_GucDrvACheckWakeupCount;
uint8 Can_GucDrvAWakupController;
uint8 Can_GucDrvACheckWakeupCheckCount;

uint8 Can_GucDrvAWriteCount;
Can_HwHandleType Can_GddDrvAHth;
PduIdType Can_GddDrvAWriteswPduhandle;
Can_IdType Can_GucDrvAWriteCanId;
uint8 Can_GucDrvAWriteLength;
uint8 Can_GaaDrvAWriteSdu[CAN_DRVA_DATA_LENGTH];

Can_ReturnType Can_GddDrvASetCtrlRetVal;
Can_ReturnType Can_GddDrvACheckWakeupRetVal;
Can_ReturnType Can_GddDrvAWriteRetVal;

/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
**                     Can_39_DriverA_SetControllerMode()                     **
*******************************************************************************/
Can_ReturnType Can_39_DriverA_SetControllerMode(uint8 Controller,
  Can_StateTransitionType Transition)
{
  /* Load actual Controller and Transition into Global variables */
  Can_GucDrvASetController = Controller;
  Can_GddDrvATransition = Transition;
  Can_GucDrvASetCtrlModeCount++;

  return(Can_GddDrvASetCtrlRetVal);
} /* End Can_39_DriverA_SetControllerMode() */

/*******************************************************************************
**                     TestCan_39_DriverA_SetControllerMode()                 **
*******************************************************************************/
boolean TestCan_39_DriverA_SetControllerMode(
  App_DataValidateType LddDataValidate, uint8 LucExpController,
  Can_StateTransitionType LddExpTransition)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Can_GucDrvASetCtrlModeCount == 0x01) &&
        (Can_GucDrvASetController == LucExpController) &&
        (Can_GddDrvATransition == LddExpTransition))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Can_GucDrvASetCtrlModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Can_GucDrvASetCtrlModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Can_GucDrvASetCtrlModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCan_39_DriverA_SetControllerMode() */

/*******************************************************************************
**                           Can_39_DriverA_CheckWakeup()                     **
*******************************************************************************/
Can_ReturnType Can_39_DriverA_CheckWakeup(uint8 Controller)
{
  /* Load actual Controller into Global variables */
  Can_GucDrvACheckWakeupCount++;
  Can_GucDrvAWakupController = Controller;

  return(Can_GddDrvACheckWakeupRetVal);
}  /* End Can_39_DriverA_CheckWakeup() */

/*******************************************************************************
**                        TestCan_39_DriverA_CheckWakeup()                    **
*******************************************************************************/
boolean TestCan_39_DriverA_CheckWakeup(App_DataValidateType LddDataValidate,
  uint8 LucExpController)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller  */
      if((Can_GucDrvACheckWakeupCount == 0x01) &&
        (Can_GucDrvAWakupController == LucExpController))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Can_GucDrvACheckWakeupCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Can_GucDrvACheckWakeupCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Can_GucDrvACheckWakeupCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCan_39_DriverA_CheckWakeup() */



/*******************************************************************************
**                           Can_39_DriverA_CheckBaudrate()                   **
*******************************************************************************/
Std_ReturnType Can_39_DriverA_CheckBaudrate (uint8 ControllerId,
                                            CONST(uint16, CANIF_CONST) Baudrate)
{
  Can_GucCheckController = ControllerId;
  Can_GddBaudRateA = Baudrate;
  Can_GucCheckBaudRateCountA++;

  return(E_OK);
}  /* End Can_39_DriverA_CheckWakeup() */

/*******************************************************************************
**                        TestCan_39_DriverA_CheckBaudrate()                  **
*******************************************************************************/
boolean TestCan_39_DriverA_CheckBaudrate (App_DataValidateType LddDataValidate, uint8 ControllerId,
                                            CONST(uint16, CANIF_CONST) Baudrate)
{

  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  UNUSED(Baudrate);

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller  */
      if((Can_GucCheckBaudRateCountA == 0x01) &&
        (ControllerId == Can_GucCheckController))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Can_GucCheckBaudRateCountA = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Can_GucCheckBaudRateCountA == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Can_GucCheckBaudRateCountA = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCan_39_DriverA_CheckBaudRate() */





/*******************************************************************************
**                           Can_39_DriverA_ChangeBaudrate()                   **
*******************************************************************************/
Std_ReturnType Can_39_DriverA_ChangeBaudrate (uint8 ControllerId,
                                            CONST(uint16, CANIF_CONST) Baudrate)
{
  Can_GucCheckController = ControllerId;
  Can_GddBaudRateA = Baudrate;
  Can_GucCheckBaudRateCountA++;
  UNUSED(Baudrate);

  return(E_OK);
}  /* End Can_39_DriverA_CheckWakeup() */

/*******************************************************************************
**                        TestCan_39_DriverA_ChangeBaudrate()                  **
*******************************************************************************/
boolean TestCan_39_DriverA_ChangeBaudrate (App_DataValidateType LddDataValidate, uint8 ControllerId,
                                            CONST(uint16, CANIF_CONST) Baudrate)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  UNUSED(Baudrate);

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller  */
      if((Can_GucCheckBaudRateCountA == 0x01) &&
        (ControllerId == Can_GucCheckController))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Can_GucCheckBaudRateCountA = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Can_GucCheckBaudRateCountA == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Can_GucCheckBaudRateCountA = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCan_39_DriverA_ChangeBaudRate() */



/*******************************************************************************
**                           Can_39_DriverA_Write()                           **
*******************************************************************************/
Can_ReturnType Can_39_DriverA_Write(Can_HwHandleType LddHth,
  const Can_PduType *LstPduInfo)
{
  uint8 LucDataIndex;
  uint8 *LpWriteSdu;

  /* Load actual Hth and SduDataPtr into Global variables */
  Can_GddDrvAHth = LddHth;
  Can_GddDrvAWriteswPduhandle = LstPduInfo->swPduHandle;
  LpWriteSdu = LstPduInfo->sdu;
  Can_GucDrvAWriteCanId = LstPduInfo->id;
  if(LstPduInfo->length > CAN_DRVA_DATA_LENGTH)
  {
    Can_GucDrvAWriteLength = CAN_DRVA_DATA_LENGTH;
  }
  else
  {
    Can_GucDrvAWriteLength = LstPduInfo->length;
  }

  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0; LucDataIndex < Can_GucDrvAWriteLength; LucDataIndex++)
  {
    Can_GaaDrvAWriteSdu[LucDataIndex] = *LpWriteSdu;
    LpWriteSdu++;
  }
  Can_GucDrvAWriteCount++;
  return(Can_GddDrvAWriteRetVal);
} /* End Can_39_DriverA_Write() */

/*******************************************************************************
**                           TestCan_39_DriverA_Write()                       **
*******************************************************************************/
boolean TestCan_39_DriverA_Write(App_DataValidateType LddDataValidate,
  Can_HwHandleType ExpHth, const Can_PduType *ExpPduInfo)
{
  boolean LblRetValue;
  uint8 *LpSduPtr;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and HTH */
      if((Can_GucDrvAWriteCount == 0x01) && (Can_GddDrvAHth == ExpHth) &&
        (ExpPduInfo->length == Can_GucDrvAWriteLength) &&
        (ExpPduInfo->id == Can_GucDrvAWriteCanId) &&
        (ExpPduInfo->swPduHandle == Can_GddDrvAWriteswPduhandle))
      {
        LpSduPtr = ExpPduInfo->sdu;
        /* Validate SduLength and Data */
        if(Can_39_DriverA_Test_ValidateData(LpSduPtr, &Can_GaaDrvAWriteSdu[0]))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      Can_GucDrvAWriteCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Can_GucDrvAWriteCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      Can_GucDrvAWriteCount = 0;
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCan_39_DriverA_Write() */

/*******************************************************************************
**                       Can_39_DriverA_Test_ValidateData()                   **
*******************************************************************************/
boolean Can_39_DriverA_Test_ValidateData(uint8* LpExpSdu, uint8* LpActSdu)
{
  uint8 LddSduCount;
  uint8 *LpExpSduData;
  uint8 *LpActSduData;
  boolean LblReturnValue;

  LpExpSduData = LpExpSdu;
  LpActSduData = LpActSdu;
  LblReturnValue = TRUE;
  LddSduCount = Can_GucDrvAWriteLength;

  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    LddSduCount--;
    if(*LpActSduData != *LpExpSduData)
    {
      LblReturnValue = FALSE;
    }
    LpActSduData++;
    LpExpSduData++;

  }
  return(LblReturnValue);
} /* End Can_39_DriverA_Test_ValidateData()  */

/*******************************************************************************
**                    TestCan_39_DriverA_SetCtrlRetVal()                      **
*******************************************************************************/
void TestCan_39_DriverA_SetCtrlRetVal(Can_ReturnType LddCanReturnVal)
{
  Can_GddDrvASetCtrlRetVal = LddCanReturnVal;
}
/* End TestCan_39_DriverA_SetCtrlRetVal() */

/*******************************************************************************
**                  TestCan_39_DriverA_SetCheckWakeupRetVal()                 **
*******************************************************************************/
void TestCan_39_DriverA_SetCheckWakeupRetVal(Can_ReturnType LddCanReturnVal)
{
  Can_GddDrvACheckWakeupRetVal = LddCanReturnVal;
}
/* End TestCan_39_DriverA_SetCheckWakeupRetVal() */

/*******************************************************************************
**                    TestCan_39_DriverA_SetWriteRetVal()                     **
*******************************************************************************/
void TestCan_39_DriverA_SetWriteRetVal(Can_ReturnType LddCanReturnVal)
{
  Can_GddDrvAWriteRetVal = LddCanReturnVal;
}
/* End TestCan_39_DriverA_SetWriteRetVal() */

/*******************************************************************************
**                     TestCan_39_DriverA_DefaultBehavior()                   **
*******************************************************************************/
void TestCan_39_DriverA_DefaultBehavior(void)
{
 Can_GddDrvASetCtrlRetVal = CAN_OK;
 Can_GddDrvACheckWakeupRetVal = CAN_OK;
 Can_GddDrvAWriteRetVal = CAN_OK;
 Can_GddDrvATransition = CAN_T_STOP;
 Can_GucDrvASetCtrlModeCount = 0;
 Can_GucDrvASetController = 0;
 Can_GucDrvACheckWakeupCount = 0;
 Can_GucDrvAWakupController = 0;
 Can_GucDrvACheckWakeupCheckCount = 0;
 Can_GucDrvAWriteCount = 0;
 Can_GddDrvAWriteswPduhandle = 0;
 Can_GucDrvAWriteCanId = 0;
 Can_GucDrvAWriteLength = 0;
 Can_GddDrvAHth = 0;
 Can_GucCheckController = 0;
 Can_GddBaudRateA = 0; 
 Can_GucCheckBaudRateCountA = 0;
} 
 /* End TestCan_39_DriverA_DefaultBehavior() */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

