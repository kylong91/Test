/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Fee.c                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Fee Module                                            **
**                                                                            **
**  PURPOSE   : Provision of Fee.c for testing applications                   **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     25-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Fee.h"
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Fee_GucCancelCount;
uint8 Fee_GucEraseImmediateBlkCount;
uint16 Fee_GusBlockNumber;
Std_ReturnType Fee_GddEarImmdiBlkRetVal;
uint8 Fee_GucGetJobResultCount;
uint8 Fee_GucGetStatusCount;
uint8 Fee_TestBlockLength = 10;
uint8 Fee_GaaDataBuffer[10];
uint8 Fee_GucInvalidateBlockCount;
Std_ReturnType Fee_GddInvBlockRetVal;
uint8 Fee_GucReadCount;
Std_ReturnType Fee_GddReadRetVal;
uint16 Fee_GusBlockOffset;
uint8 Fee_GucDataBufferPtr;
uint16 Fee_GusLength;
uint8 Fee_GucSetModeCount;
MemIf_ModeType Fee_GddMode;
MemIf_JobResultType Fee_GddJobResult;
MemIf_StatusType Fee_GddStatus;
uint8 Fee_GucWriteCount;
Std_ReturnType Fee_GddWriteRetVal;

/*******************************************************************************
**                         Fee_Cancel                                         **
******************************************************************************/
void Fee_Cancel(void)
{
  Fee_GucCancelCount++;
}
/*******************************************************************************
**                         TestFee_Cancel()                                   **
*******************************************************************************/
boolean TestFee_Cancel(App_DataValidateType LucDataValidate)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if(Fee_GucCancelCount == 0x01)
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Fee_GucCancelCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fee_GucCancelCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestFee_Cancel() */
/******************************************************************************/
/*                       FrNm_NetworkRequest()                               */
/******************************************************************************/
Std_ReturnType Fee_EraseImmediateBlock(uint16 BlockNumber)
{
  Fee_GusBlockNumber = BlockNumber;
  Fee_GucEraseImmediateBlkCount++;
  return(Fee_GddEarImmdiBlkRetVal);
}
/*******************************************************************************
**                       TestFee_EraseImmediateBlock()                          **
*******************************************************************************/
boolean TestFee_EraseImmediateBlock(App_DataValidateType LucDataValidate,
  uint16 LddExpBlockNumber)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Fee_GucEraseImmediateBlkCount == 0x01)&&
        (LddExpBlockNumber == Fee_GusBlockNumber))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Fee_GucEraseImmediateBlkCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fee_GucEraseImmediateBlkCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFee_EraseImmediateBlock() */
/*******************************************************************************
**                     TestFee_EraseImmediateBlockSetRetVal()                  **
*******************************************************************************/
void TestFee_EraseImmediateBlockSetRetVal(Std_ReturnType ReturnValue)
{
  Fee_GddEarImmdiBlkRetVal = ReturnValue;
} /* End TestFee_EraseImmediateBlockSetRetVal() */
/******************************************************************************/
/*                          Fee_GetJobResult()                                 */
/******************************************************************************/
MemIf_JobResultType Fee_GetJobResult(void)
{
  Fee_GucGetJobResultCount++;
  return(Fee_GddJobResult);
} /* End Fee_GetJobResult() */
/*******************************************************************************
**                           TestFee_GetJobResult()                            **
*******************************************************************************/
boolean TestFee_GetJobResult(App_DataValidateType LucDataValidate)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Fee_GucGetJobResultCount == 0x01)
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Fee_GucGetJobResultCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fee_GucGetJobResultCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFee_GetJobResult() */
/******************************************************************************/
/*                           Fee_GetStatus()                                   */
/******************************************************************************/
MemIf_StatusType Fee_GetStatus(void)
{
  Fee_GucGetStatusCount++;
  return(Fee_GddStatus);
} /* End Fee_GetStatus() */
/*******************************************************************************
**                       TestFee_GetStatus()                                   **
*******************************************************************************/
boolean TestFee_GetStatus(App_DataValidateType LucDataValidate)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if(Fee_GucGetStatusCount == 0x01)
       {
         LblStepResult = STEP_PASSED;
       }
      /* Reset API invocation Count after validating the API invocation */
      Fee_GucGetStatusCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fee_GucGetStatusCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFee_GetStatus() */
/******************************************************************************/
/*                           Fee_InvalidateBlock()                             */
/******************************************************************************/
Std_ReturnType Fee_InvalidateBlock(uint16 BlockNumber)
{
  Fee_GusBlockNumber = BlockNumber;
  Fee_GucInvalidateBlockCount++;
  return(Fee_GddInvBlockRetVal);
} /* End Fee_InvalidateBlock() */
/*******************************************************************************
**                          TestFee_InvalidateBlock()                          **
*******************************************************************************/
boolean TestFee_InvalidateBlock(App_DataValidateType LucDataValidate,
  uint16 LddExpBlockNumber)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Fee_GucInvalidateBlockCount == 0x01)&&
        (LddExpBlockNumber == Fee_GusBlockNumber))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Fee_GucInvalidateBlockCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fee_GucInvalidateBlockCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFee_InvalidateBlock() */
/*******************************************************************************
**                       TestFee_InvalidateBlockSetRetVal()                   **
*******************************************************************************/
void TestFee_InvalidateBlockSetRetVal(Std_ReturnType ReturnValue)
{
  Fee_GddInvBlockRetVal = ReturnValue;
} /* End TestFee_InvalidateBlockSetRetVal() */
/******************************************************************************/
/*                       Fee_Read()                                           */
/******************************************************************************/
Std_ReturnType Fee_Read(uint16 BlockNumber, uint16 BlockOffset,
  uint8* DataBufferPtr, uint16 Length)
{
  uint8 LucCount;
  Fee_GusBlockNumber = BlockNumber;
  Fee_GusBlockOffset = BlockOffset;
  for(LucCount = 0; LucCount < Length; LucCount++)
  {
    Fee_GaaDataBuffer[LucCount]= *DataBufferPtr;
  }
  Fee_GusLength = Length;
  Fee_GucReadCount++;
  return(Fee_GddReadRetVal);
} /* End Fee_Read() */
/*******************************************************************************
**                              TestFee_Read()                                 **
*******************************************************************************/
boolean TestFee_Read(App_DataValidateType LucDataValidate,
uint16 LddExpBlockNumber, uint16 LddExpBlockOffset,
uint8 *LddExpDataBufferPtr, uint16 LddExpLength)
{
  boolean  LblStepResult;
  uint8 LucCount;
  LblStepResult = STEP_FAILED;
  LucCount = 0;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Fee_GucReadCount == 0x01)&&
        (LddExpBlockNumber == Fee_GusBlockNumber)&&
        (LddExpBlockOffset == Fee_GusBlockOffset)&&
        (LddExpLength == Fee_GusLength))
        {
          while(LucCount != Fee_GusLength)
          {
            if(*LddExpDataBufferPtr != Fee_GaaDataBuffer[LucCount])
            {
              break;
            }
            LucCount++;
          }
          if(LucCount == Fee_GusLength)
          {
            LblStepResult = STEP_PASSED;
          }
        }
      /* Reset API invocation Count after validating the API invocation */
      Fee_GucReadCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fee_GucReadCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFee_Read() */
/*******************************************************************************
**                       TestFee_ReadSetRetVal()                               **
*******************************************************************************/
void TestFee_ReadSetRetVal(Std_ReturnType ReturnValue)
{
  Fee_GddReadRetVal = ReturnValue;
} /* End TestFee_ReadSetRetVal() */
/******************************************************************************/
/*                              Fee_SetMode()                                  */
/******************************************************************************/
void Fee_SetMode(MemIf_ModeType Mode)
{
  Fee_GddMode = Mode;
  Fee_GucSetModeCount++;
} /* End Fee_SetMode() */
/*******************************************************************************
**                                  TestFee_SetMode()                          **
*******************************************************************************/
boolean TestFee_SetMode(App_DataValidateType LucDataValidate,
  MemIf_ModeType LddExpMode)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Fee_GucSetModeCount == 0x01)&&
        (LddExpMode == Fee_GddMode))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Fee_GucSetModeCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fee_GucReadCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFee_SetMode() */
/******************************************************************************/
/*                                 Fee_Write()                                 */
/******************************************************************************/
Std_ReturnType Fee_Write(uint16 BlockNumber, uint8* DataBufferPtr)
{
  uint8 LucCount;
  Fee_GusBlockNumber = BlockNumber;
  Fee_GucDataBufferPtr = *DataBufferPtr;
  for(LucCount = 0; LucCount < Fee_TestBlockLength; LucCount++)
  {
    Fee_GaaDataBuffer[LucCount]= *DataBufferPtr;
  }
  Fee_GucWriteCount++;
  return(Fee_GddWriteRetVal);
}  /* End Fee_Write() */
/*******************************************************************************
**                             TestFee_Write()                                 **
*******************************************************************************/
boolean TestFee_Write(App_DataValidateType LucDataValidate,
  uint16 LddExpBlockNumber, uint8 *LddExpDataBufferPtr)
{
  boolean  LblStepResult;
  uint8 LucCount;
  LucCount = 0;
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Fee_GucWriteCount == 0x01)&&
        (LddExpBlockNumber == Fee_GusBlockNumber))
        {
          while(LucCount != Fee_TestBlockLength)
          {
            if(*LddExpDataBufferPtr != Fee_GaaDataBuffer[LucCount])
            {
              break;
            }
            LucCount++;
          }
          if(LucCount == Fee_GusLength)
          {
            LblStepResult = STEP_PASSED;
          }
        }
      /* Reset API invocation Count after validating the API invocation */
      Fee_GucWriteCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fee_GucWriteCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFee_Write() */
/*******************************************************************************
**                       TestFee_WriteSetRetVal()                              **
*******************************************************************************/
void TestSetFee_WriteRetVal(Std_ReturnType ReturnValue)
{
  Fee_GddWriteRetVal = ReturnValue;
} /* End TestFee_WriteSetRetVal() */
/*******************************************************************************
**                       TestSetFee_GetJobResultRetVal()                       **
*******************************************************************************/
void TestSetFee_GetJobResultRetVal(MemIf_JobResultType JobResult)
{
  Fee_GddJobResult = JobResult;
}/* End TestSetFee_GetJobResultRetVal */
/*******************************************************************************
**                       TestSetFee_GetJobResultRetVal()                       **
*******************************************************************************/
void TestSetFee_GetStatusRetVal(MemIf_StatusType Status)
{
  Fee_GddStatus = Status;
} /* End TestSetFee_GetStatusRetVal */
/*******************************************************************************
**                       TestFee_DefaultBehavior()                          **
*******************************************************************************/
void TestFee_DefaultBehavior(void)
{
  Fee_GucCancelCount = 0;
  Fee_GucEraseImmediateBlkCount = 0;
  Fee_GucGetJobResultCount = 0;
  Fee_GucGetStatusCount = 0;
  Fee_GucInvalidateBlockCount = 0;
  Fee_GucReadCount = 0;
  Fee_GucSetModeCount = 0;
  Fee_GucWriteCount = 0;
  Fee_GddEarImmdiBlkRetVal = E_OK;
  Fee_GddInvBlockRetVal = E_OK;
  Fee_GddReadRetVal = E_OK;
  Fee_GddWriteRetVal = E_OK;
  Fee_GddMode = MEMIF_MODE_SLOW;
  Fee_GddJobResult = MEMIF_JOB_OK;
  Fee_GddStatus = MEMIF_IDLE;
} /* End TestFee_DefaultBehavior() */
/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
