/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: NmStack_Types.h                                               **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Nm Module                                             **
**                                                                            **
**  PURPOSE   :Provision of Nm Stack types                                    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     11-Jul-2011   SSK    Initial Version                             **
*******************************************************************************/

#ifndef NMSTACK_TYPES_H
#define NMSTACK_TYPES_H

/*******************************************************************************
**                      Include Section                                      **
*******************************************************************************/

/*******************************************************************************
**                      Version Information                                  **
*******************************************************************************/
#define NMSTACK_TYPES_AR_MAJOR_VERSION          NM_AR_MAJOR_VERSION
#define NMSTACK_TYPES_AR_MINOR_VERSION          NM_AR_MINOR_VERSION
#define NMSTACK_TYPES_AR_PATCH_VERSION          NM_AR_PATCH_VERSION

#define NMSTACK_TYPES_SW_MAJOR_VERSION          NM_SW_MAJOR_VERSION
#define NMSTACK_TYPES_SW_MINOR_VERSION          NM_SW_MINOR_VERSION

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
typedef enum
{
  NM_E_OK,
  NM_E_NOT_OK,
  NM_E_NOT_EXECUTED
}Nm_ReturnType;

typedef enum
{
  NM_MODE_BUS_SLEEP,
  NM_MODE_PREPARE_BUS_SLEEP,
  NM_MODE_SYNCHRONIZE,
  NM_MODE_NETWORK,
  NM_MODE_EXPULSION
}Nm_ModeType;

typedef enum
{
  NM_STATE_UNINIT,
  NM_STATE_BUS_SLEEP,
  NM_STATE_PREPARE_BUS_SLEEP,
  NM_STATE_READY_SLEEP,
  NM_STATE_NORMAL_OPERATION,
  NM_STATE_REPEAT_MESSAGE,
  NM_STATE_SYNCHRONIZE,
  NM_STATE_EXPULSION
}Nm_StateType;

typedef enum
{
  NM_BUSNM_CANNM,
  NM_BUSNM_FRNM,
  NM_BUSNM_LINNM,
  NM_BUSNM_UDPNM,
  NM_BUSNM_GENERICNM,
  NM_BUSNM_UNDEF = 0xFF
}Nm_BusNmType;


/*******************************************************************************
**                      Global Function Prototypes                            **
*******************************************************************************/

#endif  /* NMSTACK_TYPES_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
