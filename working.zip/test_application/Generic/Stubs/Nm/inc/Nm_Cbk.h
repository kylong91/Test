/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Nm.h                                                          **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CAN StateManager Module                               **
**                                                                            **
**  PURPOSE   : C header for Nm.c                                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0    30-Aug-2012   Ravi Tiwari    Initial version                      **
*******************************************************************************/

#ifndef NM_CBK_H
#define NM_CBK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define NM_CBK_AR_RELEASE_MAJOR_VERSION     4
#define NM_CBK_AR_RELEASE_MINOR_VERSION     0
#define NM_CBK_AR_RELEASE_REVISION_VERSION  3

/* Software Version Information */
#define NM_CBK_SW_MAJOR_VERSION  1
#define NM_CBK_SW_MINOR_VERSION  0
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
# define MAX_INVOKE_NM 5
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void Nm_StateChangeNotification(const NetworkHandleType nmChannelHandle, 
  const Nm_StateType nmPreviousState, const Nm_StateType nmCurrentState);

extern boolean TestNm_StateChangeNotification(
  App_DataValidateType LucDataValidate, 
  const NetworkHandleType ExpNmChannelHandle,
  const Nm_StateType ExpNmPreviousState, const Nm_StateType ExpNmCurrentState);

extern void Nm_RepeatMessageIndication(const NetworkHandleType nmChannelHandle);

extern boolean TestNm_RepeatMessageIndication(
  App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNmChannelHandle);

extern void Nm_NetworkMode(const NetworkHandleType nmChannelHandle);

extern boolean TestNm_NetworkMode(
  App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNmChannelHandle);

extern void Nm_BusSleepMode(const NetworkHandleType nmChannelHandle);

extern boolean TestNm_BusSleepMode(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNmChannelHandle);

extern void Nm_PrepareBusSleepMode(const NetworkHandleType nmChannelHandle);

extern boolean TestNm_PrepareBusSleepMode(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNmChannelHandle);

extern void Nm_RemoteSleepIndication(const NetworkHandleType nmChannelHandle);

extern boolean TestNm_RemoteSleepIndication(
  App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNmChannelHandle);

extern void Nm_RemoteSleepCancellation(const NetworkHandleType nmChannelHandle);

extern boolean TestNm_RemoteSleepCancellation(
  App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNmChannelHandle);

extern void Nm_PduRxIndication(const NetworkHandleType nmChannelHandle);

extern boolean TestNm_PduRxIndication(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNmChannelHandle);

extern void Nm_NetworkStartIndication(const NetworkHandleType nmChannelHandle);

extern boolean TestNm_NetworkStartIndication(
  App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNmChannelHandle);

extern void Nm_TxTimeoutException(const NetworkHandleType nmChannelHandle);

extern boolean TestNm_TxTimeoutException(
  App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNmChannelHandle);

extern void Nm_CarWakeUpIndication( const NetworkHandleType nmChannelHandle );

extern boolean TestNm_CarWakeUpIndication (App_DataValidateType LucDataValidate,
  const NetworkHandleType LddExpNetworkHandle);

extern void Nm_CoordReadyToSleepIndication
                                  ( const NetworkHandleType nmChannelHandle );  

extern boolean TestNm_CoordReadyToSleepIndication
  (App_DataValidateType LucDataValidate, 
  const NetworkHandleType LddExpNetworkHandle);
#endif /* NM_CBK_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
