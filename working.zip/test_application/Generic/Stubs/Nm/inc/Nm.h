/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Nm.h                                                          **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CAN StateManager Module                               **
**                                                                            **
**  PURPOSE   : C header for Nm.c                                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0    30-Aug-2012   Ravi Tiwari    Initial version                      **
*******************************************************************************/

#ifndef NM_H
#define NM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
#include "ComStack_Types.h"
#include "NmStack_Types.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define NM_AR_RELEASE_MAJOR_VERSION  4
#define NM_AR_RELEASE_MINOR_VERSION  0
#define NM_AR_RELEASE_REVISION_VERSION  3

/* Software Version Information */
#define NM_SW_MAJOR_VERSION  1
#define NM_SW_MINOR_VERSION  0
/******************************************************************************
* D E F I N E S
******************************************************************************/

# define MAX_NM_INVOKE 5
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void TestClearNm_GucStateChangeNotifCount(void);
extern Std_ReturnType Nm_PassiveStartUp(const NetworkHandleType NetworkHandle);
extern Std_ReturnType Nm_NetworkRequest(const NetworkHandleType NetworkHandle);
extern Std_ReturnType Nm_NetworkRelease(const NetworkHandleType NetworkHandle);

extern Std_ReturnType Nm_DisableCommunication(const NetworkHandleType 
  NetworkHandle);
extern Std_ReturnType Nm_EnableCommunication(const NetworkHandleType 
  NetworkHandle);

extern boolean TestNm_PassiveStartUp(App_DataValidateType LucDataValidate,
  const NetworkHandleType LddNetworkHandle);
extern boolean TestNm_NetworkRequest(App_DataValidateType LucDataValidate,
  const NetworkHandleType LddNetworkHandle);
extern boolean TestNm_NetworkRelease(App_DataValidateType LucDataValidate,
  const NetworkHandleType LddNetworkHandle);

extern void TestNm_DefaultBehavior(void);
extern void TestNm_SetBehavior(Nm_ReturnType LddReturnVal);

extern  boolean TestNm_DisableCommunication(App_DataValidateType  
  LucDataValidate, const NetworkHandleType LddExpNetworkHandle);
extern  boolean TestNm_EnableCommunication(App_DataValidateType  
  LucDataValidate, const NetworkHandleType LddExpNetworkHandle);

extern void Nm_Init(void);
  
extern void Nm_SynchronizationPoint(const NetworkHandleType nmNetworkHandle);
extern boolean TestNm_SynchronizationPoint(App_DataValidateType LucDataValidate,
  const NetworkHandleType LddExpNetworkHandle);

extern boolean TestNm_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
#endif /* NM_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

