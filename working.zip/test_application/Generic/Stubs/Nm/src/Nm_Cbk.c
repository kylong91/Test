/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Nm_Cbk.c                                                      **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Nm Stub                                               **
**                                                                            **
**  PURPOSE   : This application file contains execution sequences to         **
**              simulate and check the different callbacks for CanNm          **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/


/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0    30-Aug-2012   Ravi Tiwari    Initial version                      **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"   /* ComStack types header file */
#include "NmStack_Types.h"
#include "Nm_Cbk.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
NetworkHandleType Nm_GddNmChannelHandle;
Nm_StateType Nm_GddNmPreviousState;
Nm_StateType Nm_GddNmCurrentState;
uint8 Nm_GucStateChangeNotifCount;
uint8 Nm_GucRepeatMsgIndiCount;
uint8 Nm_GucNetworkModeCount;
uint8 Nm_GucBusSleepModeCount;
uint8 Nm_GucPrepareBusSleepModeCount;
uint8 Nm_GucRemoteSleepIndicationCount;
uint8 Nm_GucRemoteSleepCancelCount;
uint8 Nm_GucPduRxIndicationCount;
uint8 Nm_GucNetworkStartIndiCount;
uint8 Nm_GucTxTimeoutExceptionCount;

uint8 Nm_GucPassiveStartUpCnt;
NetworkHandleType Nm_GddNetworkHandle;
NetworkHandleType Nm_GaaNetworkHandle[MAX_INVOKE_NM];
uint8 Nm_GucNetworkRequestCnt;
uint8 Nm_GucNetworkReleaseCnt;
uint8 Nm_GucRequestExpulsionCnt;

uint8 Nm_GucCarWakeUpIndicationCnt;
uint8 Nm_CoordReadyToSleepIndicationCnt;
Nm_ReturnType Nm_LddReturnVal;

#ifdef BSWM_MODULE_ACTIVE
NetworkHandleType Nm_GddNwHandleEnComm;
NetworkHandleType Nm_GddNwHandleDisComm;
uint8 Nm_GucEnableCommunicationCount;
uint8 Nm_GucdisableCommunicationCount;
Nm_ReturnType Nm_LddReturnVal;
#endif
#ifdef FRNM_MODULE_ACTIVE
uint8 Nm_GddSynChPointNetworkHandle; 
uint8 Nm_GucSyncPointCnt;
#endif
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
void TestClearNm_GucStateChangeNotifCount(void)
{
  Nm_GucStateChangeNotifCount = 0x00;
}
/*******************************************************************************
**                      Nm_StateChangeNotification()                          **
*******************************************************************************/
void Nm_StateChangeNotification(const NetworkHandleType nmChannelHandle,
  const Nm_StateType nmPreviousState, const Nm_StateType nmCurrentState )
{
  #ifndef TYPICAL_CONFIG
  Nm_GddNmChannelHandle = nmChannelHandle;
  Nm_GddNmPreviousState = nmPreviousState;
  Nm_GddNmCurrentState = nmCurrentState;
  Nm_GucStateChangeNotifCount++;
  #endif /* TYPICAL_CONFIG */
} /* End Nm_StateChangeNotification() */

/*******************************************************************************
**                       TestNm_StateChangeNotification()                     **
*******************************************************************************/
boolean TestNm_StateChangeNotification (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNmChannelHandle,
  const Nm_StateType ExpNmPreviousState, const Nm_StateType ExpNmCurrentState)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    case S_VALIDATE:
    {
      /* Validate the channel handle and states */
      if((Nm_GucStateChangeNotifCount == 0x01) &&
      (Nm_GddNmChannelHandle == ExpNmChannelHandle) &&
      (Nm_GddNmPreviousState == ExpNmPreviousState) &&
      (Nm_GddNmCurrentState == ExpNmCurrentState))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API Invocation Count to Zero */
      Nm_GucStateChangeNotifCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Nm_GucStateChangeNotifCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestNm_StateChangeNotification() */

/*******************************************************************************
**                      Nm_RepeatMessageIndication()                          **
*******************************************************************************/
void Nm_RepeatMessageIndication(const NetworkHandleType nmChannelHandle)
{
  #ifndef TYPICAL_CONFIG
  Nm_GddNmChannelHandle = nmChannelHandle;
  Nm_GucRepeatMsgIndiCount++;
  #endif /* TYPICAL_CONFIG */
} /* End Nm_RepeatMessageIndication() */

/*******************************************************************************
**                       TestNm_RepeatMessageIndication()                     **
*******************************************************************************/
boolean TestNm_RepeatMessageIndication(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNmChannelHandle)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    case S_VALIDATE:
    {
      /* Validate the channel handle and states */
      if((Nm_GucRepeatMsgIndiCount == 0x01)
        && (Nm_GddNmChannelHandle == ExpNmChannelHandle))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API Invocation Count to Zero */
      Nm_GucRepeatMsgIndiCount= 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Nm_GucRepeatMsgIndiCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestNm_RepeatMessageIndication() */

/*******************************************************************************
**                            Nm_NetworkMode()                                **
*******************************************************************************/
void Nm_NetworkMode(const NetworkHandleType nmChannelHandle)
{
  #ifndef TYPICAL_CONFIG
  Nm_GddNmChannelHandle = nmChannelHandle;
  Nm_GucNetworkModeCount++;
  #endif /* TYPICAL_CONFIG */
} /* End Nm_NetworkMode() */

/*******************************************************************************
**                             TestNm_NetworkMode()                           **
*******************************************************************************/
boolean TestNm_NetworkMode(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNmChannelHandle)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    case S_VALIDATE:
    {
      /* Validate the channel handle and states */
      if((Nm_GucNetworkModeCount == 0x01)
        && (Nm_GddNmChannelHandle == ExpNmChannelHandle))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API Invocation Count to Zero */
      Nm_GucNetworkModeCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Nm_GucNetworkModeCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestNm_NetworkMode() */

/*******************************************************************************
**                            Nm_BusSleepMode()                               **
*******************************************************************************/
void Nm_BusSleepMode(const NetworkHandleType nmChannelHandle)
{
  #ifndef TYPICAL_CONFIG
  Nm_GddNmChannelHandle = nmChannelHandle;
  Nm_GucBusSleepModeCount++;
  #endif /* TYPICAL_CONFIG */
} /* End Nm_BusSleepMode() */

/*******************************************************************************
**                             TestNm_BusSleepMode()                          **
*******************************************************************************/
boolean TestNm_BusSleepMode(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNmChannelHandle)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    case S_VALIDATE:
    {
      /* Validate the channel handle and states */
      if((Nm_GucBusSleepModeCount == 0x01)
        && (Nm_GddNmChannelHandle == ExpNmChannelHandle))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API Invocation Count to Zero */
      Nm_GucBusSleepModeCount= 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Nm_GucBusSleepModeCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestNm_BusSleepMode() */

/*******************************************************************************
**                      Nm_PrepareBusSleepMode()                              **
*******************************************************************************/
void Nm_PrepareBusSleepMode(const NetworkHandleType nmChannelHandle)
{
  #ifndef TYPICAL_CONFIG
  Nm_GddNmChannelHandle = nmChannelHandle;
  Nm_GucPrepareBusSleepModeCount++;
  #endif /* TYPICAL_CONFIG */
} /* End Nm_PrepareBusSleepMode() */

/*******************************************************************************
**                      TestNm_PrepareBusSleepMode()                          **
*******************************************************************************/
boolean TestNm_PrepareBusSleepMode(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNmChannelHandle)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    case S_VALIDATE:
    {
      /* Validate the channel handle and states */
      if((Nm_GucPrepareBusSleepModeCount == 0x01)
      && (Nm_GddNmChannelHandle == ExpNmChannelHandle))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API Invocation Count to Zero */
      Nm_GucPrepareBusSleepModeCount= 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Nm_GucPrepareBusSleepModeCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestNm_PrepareBusSleepMode() */

/*******************************************************************************
**                      Nm_RemoteSleepIndication()                            **
*******************************************************************************/
void Nm_RemoteSleepIndication(const NetworkHandleType nmChannelHandle)
{
  #ifndef TYPICAL_CONFIG
  Nm_GddNmChannelHandle = nmChannelHandle;
  Nm_GucRemoteSleepIndicationCount++;
  #endif /* TYPICAL_CONFIG */
} /* End NmApp_RemoteSleepIndication() */

/*******************************************************************************
**                    TestNm_RemoteSleepIndication()                          **
*******************************************************************************/
boolean TestNm_RemoteSleepIndication(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNmChannelHandle)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    case S_VALIDATE:
    {
      /* Validate the channel handle and states */
      if((Nm_GucRemoteSleepIndicationCount == 0x01)
        && (Nm_GddNmChannelHandle == ExpNmChannelHandle))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API Invocation Count to Zero */
      Nm_GucRemoteSleepIndicationCount= 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Nm_GucRemoteSleepIndicationCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestNm_RemoteSleepIndication() */

/*******************************************************************************
**                      Nm_RemoteSleepCancellation()                          **
*******************************************************************************/
void Nm_RemoteSleepCancellation(const NetworkHandleType nmChannelHandle)
{
  #ifndef TYPICAL_CONFIG
  Nm_GddNmChannelHandle = nmChannelHandle;
  Nm_GucRemoteSleepCancelCount++;
  #endif /* TYPICAL_CONFIG */
} /* End Nm_RemoteSleepCancellation() */

/*******************************************************************************
**                    TestNm_RemoteSleepCancellation()                        **
*******************************************************************************/
boolean TestNm_RemoteSleepCancellation(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNmChannelHandle)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    case S_VALIDATE:
    {
      /* Validate the channel handle and states */
      if((Nm_GucRemoteSleepCancelCount == 0x01)
        && (Nm_GddNmChannelHandle == ExpNmChannelHandle))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API Invocation Count to Zero */
      Nm_GucRemoteSleepCancelCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Nm_GucRemoteSleepCancelCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestNm_RemoteSleepCancellation() */

/*******************************************************************************
**                           Nm_PduRxIndication()                             **
*******************************************************************************/
void Nm_PduRxIndication(const NetworkHandleType nmChannelHandle)
{
  #ifndef TYPICAL_CONFIG
  Nm_GddNmChannelHandle = nmChannelHandle;
  Nm_GucPduRxIndicationCount++;
  #endif /* TYPICAL_CONFIG */
} /* End Nm_PduRxIndication() */

/*******************************************************************************
**                         TestNm_PduRxIndication()                           **
*******************************************************************************/
boolean TestNm_PduRxIndication(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNmChannelHandle)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    case S_VALIDATE:
    {
      /* Validate the channel handle and states */
      if((Nm_GucPduRxIndicationCount == 0x01)
        && (Nm_GddNmChannelHandle == ExpNmChannelHandle))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API Invocation Count to Zero */
      Nm_GucPduRxIndicationCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Nm_GucPduRxIndicationCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestNm_PduRxIndication() */

/*******************************************************************************
**                         Nm_NetworkStartIndication()                        **
*******************************************************************************/
void Nm_NetworkStartIndication(const NetworkHandleType nmChannelHandle)
{
  #ifndef TYPICAL_CONFIG
  Nm_GddNmChannelHandle = nmChannelHandle;
  Nm_GucNetworkStartIndiCount++;
  #endif /* TYPICAL_CONFIG */
} /* End Nm_NetworkStartIndication() */

/*******************************************************************************
**                     TestNm_NetworkStartIndication()                        **
*******************************************************************************/
boolean TestNm_NetworkStartIndication(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNmChannelHandle)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    case S_VALIDATE:
    {
      /* Validate the channel handle and states */
      if((Nm_GucNetworkStartIndiCount == 0x01)
        && (Nm_GddNmChannelHandle == ExpNmChannelHandle))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API Invocation Count to Zero */
      Nm_GucNetworkStartIndiCount= 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Nm_GucNetworkStartIndiCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestNm_NetworkStartIndication() */

/*******************************************************************************
**                         Nm_TxTimeoutException()                        **
*******************************************************************************/
void Nm_TxTimeoutException(const NetworkHandleType nmChannelHandle)
{
  #ifndef TYPICAL_CONFIG
  Nm_GddNmChannelHandle = nmChannelHandle;
  Nm_GucTxTimeoutExceptionCount++;
  #endif /* TYPICAL_CONFIG */
} /* End Nm_TxTimeoutException() */

/*******************************************************************************
**                      TestNm_TxTimeoutException()                           **
*******************************************************************************/
boolean TestNm_TxTimeoutException(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNmChannelHandle)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    case S_VALIDATE:
    {
      /* Validate the channel handle and states */
      if((Nm_GucTxTimeoutExceptionCount == 0x01)
        && (Nm_GddNmChannelHandle == ExpNmChannelHandle))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API Invocation Count to Zero */
      Nm_GucTxTimeoutExceptionCount= 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Nm_GucTxTimeoutExceptionCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestNm_TxTimeoutException() */

/*******************************************************************************
**                      Nm_PassiveStartUp()                                   **
*******************************************************************************/
Nm_ReturnType Nm_PassiveStartUp(const NetworkHandleType NetworkHandle)
{
  #ifndef TYPICAL_CONFIG
  Nm_GddNetworkHandle = NetworkHandle;
  Nm_GucPassiveStartUpCnt++;
  #endif
	return(Nm_LddReturnVal);
}/* End Nm_PassiveStartUp()  */


/*******************************************************************************
**                       TestNm_PassiveStartUp()                              **
*******************************************************************************/
boolean TestNm_PassiveStartUp(App_DataValidateType LucDataValidate,
const NetworkHandleType LddNetworkHandle)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Nm_GucPassiveStartUpCnt == 0x01) && 
        (LddNetworkHandle == Nm_GddNetworkHandle))
      {
        LblStepResult = APP_TC_PASSED;
      }
      Nm_GucPassiveStartUpCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestNm_PassiveStartUp()  */

/*******************************************************************************
**                      Nm_NetworkRequest()                                     **
*******************************************************************************/
Nm_ReturnType Nm_NetworkRequest(const NetworkHandleType NetworkHandle)
{
  #ifndef TYPICAL_CONFIG
  Nm_GddNetworkHandle = NetworkHandle;
  Nm_GaaNetworkHandle[Nm_GucNetworkRequestCnt] = NetworkHandle;
  Nm_GucNetworkRequestCnt++;
  #endif
	return(Nm_LddReturnVal);
}/* End Nm_NetworkRequest()  */

/*******************************************************************************
**                       TestNm_NetworkRequest()                              **
*******************************************************************************/
boolean TestNm_NetworkRequest(App_DataValidateType LucDataValidate,
  const NetworkHandleType LddNetworkHandle)
 {
  boolean LblStepResult;
  
  uint8 LucCount;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Nm_GucNetworkRequestCnt == 0x01) &&
        (LddNetworkHandle == Nm_GddNetworkHandle))
      {
        LblStepResult = APP_TC_PASSED;
      }
      Nm_GucNetworkRequestCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      for(LucCount = 0; LucCount < Nm_GucNetworkRequestCnt; LucCount++)
      {
        if((LddNetworkHandle == Nm_GaaNetworkHandle[LucCount]))
        {
          LblStepResult = APP_TC_PASSED;
        }
      }
      Nm_GucNetworkRequestCnt = 0;
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult); 
} /* End TestNm_NetworkRequest()  */

/*******************************************************************************
**                     Nm_NetworkRelease()                                    **
*******************************************************************************/
Nm_ReturnType Nm_NetworkRelease( const NetworkHandleType NetworkHandle )
{
  #ifndef TYPICAL_CONFIG
  Nm_GddNetworkHandle = NetworkHandle;
  Nm_GucNetworkReleaseCnt++;
  #endif
	return(Nm_LddReturnVal);
}/* End tNm_NetworkRelease()  */
/*******************************************************************************
**                       TestNm_NetworkRelease()                              **
*******************************************************************************/
boolean TestNm_NetworkRelease(App_DataValidateType LucDataValidate,
  const NetworkHandleType LddNetworkHandle)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Nm_GucNetworkReleaseCnt == 0x01) && 
        (LddNetworkHandle == Nm_GddNetworkHandle)) 
      {
        LblStepResult = APP_TC_PASSED;
      }
      Nm_GucNetworkReleaseCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult); 
} /* End TestNm_NetworkRelease()  */


/*******************************************************************************
**                     Nm_RequestExpulsion()                                    **
*******************************************************************************/
Nm_ReturnType Nm_RequestExpulsion(const NetworkHandleType NetworkHandle )
{
  #ifndef TYPICAL_CONFIG
  Nm_GddNetworkHandle = NetworkHandle;
  Nm_GucRequestExpulsionCnt++;
  #endif
	return(Nm_LddReturnVal);
}/* End tNm_NetworkRelease()  */
/*******************************************************************************
**                       TestNm_NetworkRelease()                              **
*******************************************************************************/
boolean TestNm_RequestExpulsion(App_DataValidateType LucDataValidate,
  const NetworkHandleType LddNetworkHandle)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Nm_GucRequestExpulsionCnt == 0x01) && 
        (LddNetworkHandle == Nm_GddNetworkHandle)) 
      {
        LblStepResult = APP_TC_PASSED;
      }
      Nm_GucRequestExpulsionCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Nm_GucRequestExpulsionCnt == 0x00)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult); 
} /* End TestNm_NetworkRelease()  */

/*******************************************************************************
**                       TestNm_DefaultBehavior()                             **
*******************************************************************************/
void TestNm_DefaultBehavior(void)
{
  Nm_GucStateChangeNotifCount = 0;
  Nm_GucRepeatMsgIndiCount = 0;
  Nm_GucNetworkModeCount = 0;
  Nm_GucBusSleepModeCount = 0;
  Nm_GucPrepareBusSleepModeCount = 0;
  Nm_GucRemoteSleepIndicationCount = 0;
  Nm_GucRemoteSleepCancelCount = 0;
  Nm_GucPduRxIndicationCount = 0;
  Nm_GucNetworkStartIndiCount = 0;
  Nm_GucTxTimeoutExceptionCount = 0;
  
  Nm_GucPassiveStartUpCnt = 0;
  Nm_GucNetworkRequestCnt = 0;
  Nm_GucNetworkReleaseCnt = 0;
  Nm_GucRequestExpulsionCnt = 0;
  
  Nm_GucCarWakeUpIndicationCnt = 0;
  Nm_CoordReadyToSleepIndicationCnt=0;
}

#ifdef BSWM_MODULE_ACTIVE
/******************************************************************************/
/*                         Nm_DisableCommunication                            */
/*****************************************************************************/
Nm_ReturnType Nm_DisableCommunication(NetworkHandleType NetworkHandle)
{
  Nm_GddNwHandleDisComm  = NetworkHandle; 
  Nm_GucdisableCommunicationCount++;
  return(Nm_LddReturnVal);
}
/*******************************************************************************
**                       TestNm_DisableCommunication()                        **
*******************************************************************************/
boolean TestNm_DisableCommunication (App_DataValidateType LucDataValidate,
  const NetworkHandleType LddExpNetworkHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((Nm_GucdisableCommunicationCount != 0x00)&&
        (LddExpNetworkHandle == Nm_GddNwHandleDisComm))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Nm_GucdisableCommunicationCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestNm_disableCommunication() */

/******************************************************************************/
/*                        Nm_EnableCommunication                              */
/*****************************************************************************/
Nm_ReturnType Nm_EnableCommunication(const NetworkHandleType NetworkHandle )
{
  Nm_GddNwHandleEnComm  = NetworkHandle; 
  Nm_GucEnableCommunicationCount++;
  return(Nm_LddReturnVal);
}
/*******************************************************************************
**                      TestNm_EnableCommunication  ()                        **
*******************************************************************************/
boolean TestNm_EnableCommunication (App_DataValidateType LucDataValidate,
  const NetworkHandleType LddExpNetworkHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((Nm_GucEnableCommunicationCount != 0x00)&&
        (LddExpNetworkHandle == Nm_GddNwHandleEnComm))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
			
      Nm_GucEnableCommunicationCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestNm_EnableCommunication() */

#endif
/*******************************************************************************
**                         TestNm_SetBehavior()                         **
*******************************************************************************/
void TestNm_SetBehavior(Nm_ReturnType LddReturnVal)
{
  Nm_GucPassiveStartUpCnt = 0;
  Nm_GucNetworkRequestCnt = 0;
  Nm_GucNetworkReleaseCnt = 0;
  Nm_GucRequestExpulsionCnt = 0;
  Nm_LddReturnVal = LddReturnVal;
}

/******************************************************************************/
/*                         Nm_CarWakeUpIndication                            */
/*****************************************************************************/
void Nm_CarWakeUpIndication( const NetworkHandleType nmChannelHandle )
{
    Nm_GddNetworkHandle = nmChannelHandle;
    Nm_GucCarWakeUpIndicationCnt++;

}
/*******************************************************************************
**                      TestNm_CarWakeUpIndication  ()                        **
*******************************************************************************/
boolean TestNm_CarWakeUpIndication (App_DataValidateType LucDataValidate,
  const NetworkHandleType LddExpNetworkHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((Nm_GucCarWakeUpIndicationCnt != 0x00)&&
        (LddExpNetworkHandle == Nm_GddNetworkHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
			
      Nm_GucCarWakeUpIndicationCnt = 0;
      break;
    }
     /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Nm_GucCarWakeUpIndicationCnt == 0x00)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestNm_CarWakeUpIndication() */

/******************************************************************************/
/*                         Nm_CoordReadyToSleepIndication                     */
/*****************************************************************************/
void Nm_CoordReadyToSleepIndication( const NetworkHandleType nmChannelHandle )
{
    Nm_GddNetworkHandle = nmChannelHandle;
    Nm_CoordReadyToSleepIndicationCnt++;
}

/*******************************************************************************
**                      TestNm_CoordReadyToSleepIndication  ()                **
*******************************************************************************/
boolean TestNm_CoordReadyToSleepIndication(App_DataValidateType LucDataValidate,
  const NetworkHandleType LddExpNetworkHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((Nm_CoordReadyToSleepIndicationCnt != 0x00)&&
        (LddExpNetworkHandle == Nm_GddNetworkHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
			
      Nm_CoordReadyToSleepIndicationCnt = 0;
      break;
    }
     /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Nm_CoordReadyToSleepIndicationCnt == 0x00)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestNm_CoordReadyToSleepIndication() */

#ifdef FRNM_MODULE_ACTIVE
void Nm_SynchronizationPoint(const NetworkHandleType nmNetworkHandle)
{
  Nm_GucSyncPointCnt++;
  Nm_GddSynChPointNetworkHandle = nmNetworkHandle;
}

boolean TestNm_SynchronizationPoint(App_DataValidateType LucDataValidate,
  const NetworkHandleType LddExpNetworkHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((Nm_GucSyncPointCnt != 0x00)&&
        (LddExpNetworkHandle == Nm_GddSynChPointNetworkHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
			
      Nm_GucSyncPointCnt = 0;
      break;
    }
     /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      if(Nm_GucSyncPointCnt > 1)
      {
         LblStepResult = STEP_PASSED;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Nm_GucSyncPointCnt == 0x00)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
}
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
