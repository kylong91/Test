/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Spi.c                                                         **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR SPI Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Spi stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     09-Nov-2012   Vishnu    Initial version                          **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Spi.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#ifdef BSWM_MODULE_ACTIVE
uint8 Spi_GucInitCnt;
uint8 Spi_GucInitSeqCnt;
#endif
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
#ifdef BSWM_MODULE_ACTIVE

/*******************************************************************************
**                          Spi_Init()                                        **
*******************************************************************************/

void Spi_Init(const Spi_ConfigType* ConfigPtr)
{
  UNUSED(ConfigPtr);
  App_GucApiSeqCnt++;
  Spi_GucInitSeqCnt = App_GucApiSeqCnt;
  Spi_GucInitCnt++;
}/* End Spi_Init() */

/*******************************************************************************
**                           TestSpi_Init()                                   **
*******************************************************************************/
boolean TestSpi_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Spi_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Spi_GucInitCnt = 0;
      Spi_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(Spi_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Spi_GucInitCnt = 0;
      Spi_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestSpi_Init() */

#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
