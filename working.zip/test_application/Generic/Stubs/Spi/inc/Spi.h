/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Spi.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR SPI Stub                                              **
**                                                                            **
**  PURPOSE   : Declaration of Spi functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     09-Nov-2012   Vishnu    Initial version                          **
*******************************************************************************/
#ifndef SPI_H
#define SPI_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

#include "ComStack_Types.h"
#include "TC_Generic.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define SPI_AR_RELEASE_MAJOR_VERSION    0x04
#define SPI_AR_RELEASE_MINOR_VERSION    0x00
#define SPI_AR_RELEASE_REVISION_VERSION 0x03

/*******************************************************************************
**                         Global Data                                        **
*******************************************************************************/
typedef uint8 Spi_ConfigType;


/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern void Spi_Init(const Spi_ConfigType* ConfigPtr);

extern boolean TestSpi_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
  
#endif /* SPI_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

