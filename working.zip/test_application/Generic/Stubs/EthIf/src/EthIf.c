/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: EthsM.c                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Ethernet State Manager Module                         **
**                                                                            **
**  PURPOSE   : Declaration of Can functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     15-Jun-2010   MKK    Initial version                             **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h" 
#include "EthIf.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
Std_ReturnType EthIf_GddGetCurrentRetVal;
Std_ReturnType EthIf_GddReqComRetVal;
Std_ReturnType Eth_GdSetCtrlModeRetVal;
Std_ReturnType Eth_GdTrasRceModeRetVal;
EthTrcv_ModeType Eth_GddModeTrcv;
Eth_ModeType Eth_GddMode;
uint8 EthIf_GucControllerInitCount;
uint8 EthIf_GucGetCurrentComModeCount;
uint8 EthIf_GucRequestComModeCount;
uint8 EthIf_GucTransceiverInitCount;
uint8 EthIf_GddRecIdx[NUMBER_OF_CONTROLLER];
uint8 EthIf_GddContIdx[NUMBER_OF_CONTROLLER];
uint8 EthIf_GddCfgIdx[NUMBER_OF_CONTROLLER];
uint8 EthIf_GddRecCfgIdx[NUMBER_OF_CONTROLLER];
uint8 Eth_GucSetCtrlModeCount;
uint8 Eth_GucSetController;
uint8 Eth_GucTrcvIdx;
uint8 Eth_GucTrasRceModeCount;
uint8 EthIf_GddControllerIDCount;
uint8 EthIf_GddControllerIDCount1;
uint8 EthIf_GddRecIDCount;
uint8 EthIf_GddRecIDCount1;

/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
**                      EthIf_RequestComMode()                                **
*******************************************************************************/
Std_ReturnType EthIf_ControllerInit(uint8 CtrlIdx, uint8 CfgIdx)
{
  #ifndef TYPICAL_CONFIG
  EthIf_GddContIdx[EthIf_GddControllerIDCount] = CtrlIdx;
  EthIf_GddCfgIdx[EthIf_GddControllerIDCount] = CfgIdx;
  EthIf_GucControllerInitCount++;
  EthIf_GddControllerIDCount++;
  #endif
  return(EthIf_GddReqComRetVal);
}/* End EthIf_RequestComMode() */

/*******************************************************************************
**                       EthIf_ControllerInit()                               **
*******************************************************************************/
boolean TestEthIf_ControllerInit(App_DataValidateType LucDataValidate,
                                                    uint8 CtrlIdx, uint8 CfgIdx)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((EthIf_GucControllerInitCount == 0x01) && 
        (EthIf_GddContIdx[EthIf_GddControllerIDCount1] == CtrlIdx) &&
        (EthIf_GddCfgIdx[EthIf_GddControllerIDCount1] == CfgIdx))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      EthIf_GucControllerInitCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      if((EthIf_GucControllerInitCount > 0x00) && 
        (EthIf_GddContIdx[EthIf_GddControllerIDCount1] == CtrlIdx) &&
        (EthIf_GddCfgIdx[EthIf_GddControllerIDCount1] == CfgIdx))
      {
        LblStepResult = APP_TC_PASSED;
        EthIf_GucControllerInitCount--;
      }
      else
      {      
        EthIf_GucControllerInitCount = 0x00;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  EthIf_GddControllerIDCount1++;
  return(LblStepResult);
} /* End TestEthIf_ControllerInit() */

/*******************************************************************************
**                       EthIf_TransceiverInit()                              **
*******************************************************************************/
Std_ReturnType EthIf_TransceiverInit(uint8 TrcvIdx, uint8 TrcvCfgIdx)
{
  #ifndef TYPICAL_CONFIG
  EthIf_GucTransceiverInitCount++;
  EthIf_GddRecIdx[EthIf_GddRecIDCount] = TrcvIdx;
  EthIf_GddRecCfgIdx[EthIf_GddRecIDCount] = TrcvCfgIdx;
  EthIf_GddRecIDCount++;
  #endif
  return(EthIf_GddReqComRetVal);
}
/*******************************************************************************
**                       TestEthIf_TransceiverInit()                          **
*******************************************************************************/
boolean TestEthIf_TransceiverInit(App_DataValidateType LucDataValidate,
                                                uint8 TrcvIdx, uint8 TrcvCfgIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((EthIf_GucTransceiverInitCount == 0x01) && 
        (EthIf_GddRecIdx[EthIf_GddRecIDCount1] == TrcvIdx) &&
        (EthIf_GddRecCfgIdx[EthIf_GddRecIDCount] == TrcvCfgIdx))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      EthIf_GucTransceiverInitCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      if((EthIf_GucTransceiverInitCount > 0x00) && 
        (EthIf_GddRecIdx[EthIf_GddRecIDCount1] = TrcvIdx) &&
        (EthIf_GddRecCfgIdx[EthIf_GddRecIDCount] == TrcvCfgIdx))
      {
        LblStepResult = APP_TC_PASSED;
        EthIf_GucTransceiverInitCount--;
      }  
      else
      {
        EthIf_GucTransceiverInitCount = 0;
      }
      
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  EthIf_GddRecIDCount1++;
  return(LblStepResult);
} /* End TestEthIf_TransceiverInit() */
/*******************************************************************************
**                         EthIf_SetControllerMode()                          **
*******************************************************************************/
Std_ReturnType EthIf_SetControllerMode(uint8 CtrlIdx, Eth_ModeType CtrlMode)
{
  /* Load actual Controller and Transition into Global variables */
  Eth_GucSetController = CtrlIdx;
  Eth_GddMode = CtrlMode;
  Eth_GucSetCtrlModeCount++;

  return(Eth_GdSetCtrlModeRetVal);
   
} 
/*******************************************************************************
**                     TestEth_SetControllerMode()                            **
*******************************************************************************/
boolean TestEthIf_SetControllerMode(App_DataValidateType LddDataValidate,
  uint8 LucExpController, Eth_ModeType LddExpMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_GucSetCtrlModeCount > 0x00) &&
        (Eth_GucSetController == LucExpController) &&
        (Eth_GddMode == LddExpMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_GucSetCtrlModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_GucSetCtrlModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_GucSetCtrlModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCan_SetControllerMode() */

/*******************************************************************************
**                         EthIf_SetTransceiverMode()                         **
*******************************************************************************/
    
Std_ReturnType EthIf_SetTransceiverMode(uint8 TrcvIdx,EthTrcv_ModeType TrcvMode)
{
  /* Load actual Controller and Transition into Global variables */
  Eth_GucTrcvIdx = TrcvIdx;
  Eth_GddModeTrcv = TrcvMode;
  Eth_GucTrasRceModeCount++;

  return(Eth_GdTrasRceModeRetVal); 
}
boolean TestEthIf_SetTransceiverMode(App_DataValidateType LddDataValidate,
  uint8 LucExpTrcvIdx,EthTrcv_ModeType LddExpMode )
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_GucTrasRceModeCount > 0x00) &&
        (Eth_GucTrcvIdx == LucExpTrcvIdx) &&
        (Eth_GddModeTrcv == LddExpMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_GucTrasRceModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_GucTrasRceModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_GucTrasRceModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}  

/*******************************************************************************
**                         TestEthIf_DefaultBehavior()                        **
*******************************************************************************/
                                                 
void TestEthIf_DefaultBehavior(void)
{
  uint8 LucCount;
  EthIf_GddRecIDCount = 0;
  EthIf_GddRecIDCount1 = 0;
  EthIf_GddControllerIDCount = 0;  
  EthIf_GddControllerIDCount1 = 0;
  EthIf_GucControllerInitCount = 0;
  EthIf_GucGetCurrentComModeCount = 0;
  EthIf_GucRequestComModeCount = 0;
  EthIf_GucTransceiverInitCount = 0;
  Eth_GucSetCtrlModeCount = 0;
  Eth_GucSetController = 0;
  Eth_GucTrcvIdx = 0;
  Eth_GucTrasRceModeCount = 0;
  EthIf_GddGetCurrentRetVal = 0;
  EthIf_GddReqComRetVal = 0;
  Eth_GdSetCtrlModeRetVal = 0; 
  Eth_GdTrasRceModeRetVal = 0;
  Eth_GddModeTrcv = 0;
  Eth_GddMode = 0;
  for (LucCount = 0;NUMBER_OF_CONTROLLER > LucCount; LucCount++)
  {
    EthIf_GddRecIdx[LucCount] = 0;
    EthIf_GddContIdx[LucCount] = 0;
    EthIf_GddCfgIdx[LucCount] = 0;
    EthIf_GddRecCfgIdx[LucCount] = 0;
  }
}
/*******************************************************************************
**                      TestEthIf_PassiveStartSetRetVal()                     **
*******************************************************************************/
void TestEthIf_PassiveStartSetRetVal(Std_ReturnType ReturnValue)
{
  Eth_GdSetCtrlModeRetVal = ReturnValue;
} /* End TestEthIf_PassiveStartSetRetVal() */
/*******************************************************************************
**                      TestEthIf_PassiveStartSetRecRetVal()                  **
*******************************************************************************/
void TestEthIf_PassiveStartSetRecRetVal(Std_ReturnType ReturnValue)
{
  Eth_GdTrasRceModeRetVal = ReturnValue;
} /* End TestEthIf_PassiveStartSetRecRetVal() */
/*******************************************************************************
**                         TestEthIf_SetBehavior()                         **
*******************************************************************************/
void TestEthIf_RequestComModeSetBeh(Std_ReturnType LddReturnVal)
{
  EthIf_GucGetCurrentComModeCount = 0;
  EthIf_GucRequestComModeCount = 0;
  EthIf_GddReqComRetVal = LddReturnVal;
}

void TestEthIf_GetCurrentComModeSetBeh(Std_ReturnType LddReturnVal)
{
  EthIf_GucGetCurrentComModeCount = 0;
  EthIf_GucRequestComModeCount = 0;
  EthIf_GddGetCurrentRetVal = LddReturnVal;
}
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
