/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: EthSM.h                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Ethernet State Manager Module                         **
**                                                                            **
**  PURPOSE   : Declaration of Can functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     15/06/2011    MKK    Creation of EthSM.h  module                 **
** 4.0.1     20-Dec-2011   RPS    Updated for BswM                            **
*******************************************************************************/
#ifndef ETHIF_H
#define ETHIF_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
#include "Eth.h"
#include "EthTrcv.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR specification version information */
#define ETHIF_AR_RELEASE_MAJOR_VERSION     4
#define ETHIF_AR_RELEASE_MINOR_VERSION     0
#define ETHIF_AR_RELEASE_REVISION_VERSION  4

/* Software version information */
#define ETHIF_SW_MAJOR_VERSION  1
#define ETHIF_SW_MINOR_VERSION  0
#define ETHIF_SW_PATCH_VERSION  0

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/
#define ETHIF_NO_COMMUNICATION       0x01      
#define ETHIF_FULL_COMMUNICATION     0x02  
#define ETHIF_INVALID_NETWORKID	     0x02
#define ETHIF_INVALID_CURRENTSTATE   0x00
#define NUMBER_OF_CONTROLLER         0x10
/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
extern uint8 EthIf_GucRequestComModeCount;
extern uint8 EthIf_GucGetCurrentComModeCount;
extern Std_ReturnType EthIf_GddGetCurrentRetVal;
extern Std_ReturnType EthIf_GddReqComRetVal;
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Std_ReturnType EthIf_ControllerInit(uint8 CtrlIdx, uint8 CfgIdx);
extern boolean TestEthIf_ControllerInit(App_DataValidateType LucDataValidate,
                                                   uint8 CtrlIdx, uint8 CfgIdx);
                                                   
extern Std_ReturnType EthIf_TransceiverInit(uint8 TrcvIdx, uint8 CfgIdx);                                                   
extern boolean TestEthIf_TransceiverInit(App_DataValidateType LucDataValidate,
                                                   uint8 TrcvIdx, uint8 CfgIdx);
                                                   
extern Std_ReturnType EthIf_SetControllerMode(uint8 CtrlIdx,Eth_ModeType CtrlMode);
extern Std_ReturnType EthIf_SetTransceiverMode(uint8 TrcvIdx,
                                                     EthTrcv_ModeType TrcvMode); 
                                                     
extern boolean TestEthIf_SetControllerMode(App_DataValidateType LddDataValidate,
  uint8 LucExpController, Eth_ModeType LddExpMode);
boolean TestEthIf_SetTransceiverMode(App_DataValidateType LddDataValidate,
  uint8 LucExpTrcvIdx,EthTrcv_ModeType LddExpMode); 
extern void TestEthIf_DefaultBehavior(void);
extern void TestEthIf_PassiveStartSetRecRetVal(Std_ReturnType ReturnValue);
extern void TestEthIf_PassiveStartSetRetVal(Std_ReturnType ReturnValue); 
#endif /* EthIf_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
