/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: FrNm.h                                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FrNm Module                                           **
**                                                                            **
**  PURPOSE   : Declaration of FrNm Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/

#ifndef FRNM_H
#define FRNM_H

/*******************************************************************************
* I N C L U D E S
*******************************************************************************/
#include "ComStack_Types.h"
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define FRNM_AR_RELEASE_MAJOR_VERSION  4
#define FRNM_AR_RELEASE_MINOR_VERSION  0
#define FRNM_AR_RELEASE_REVISION_VERSION  3

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define FRNM_SW_MAJOR_VERSION  4
#define FRNM_SW_MINOR_VERSION  0

/*******************************************************************************
**                      Function Prototype                                    **
*******************************************************************************/
extern void FrNm_TxConfirmation(PduIdType TxPduId);

extern boolean TestFrNm_TxConfirmation(App_DataValidateType LucDataValidate,
PduIdType TxPduId);

extern void FrNm_RxIndication(PduIdType RxPduId, PduInfoType* PduInfoPtr);

extern boolean TestFrNm_RxIndication(App_DataValidateType LucDataValidate,
PduIdType RxPduId);

extern Std_ReturnType FrNm_TriggerTransmit(PduIdType TxPduId,
      PduInfoType* PduInfoPtr);
  
extern boolean TestFrNm_TriggerTransmit(App_DataValidateType LucDataValidate,
  PduIdType TxPduId);
#endif /* FRNM_H */

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/

