/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: FrNm.h                                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FrNm Module                                           **
**                                                                            **
**  PURPOSE   : Declaration of FrNm Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/

#ifndef FRNM_H
#define FRNM_H

/*******************************************************************************
* I N C L U D E S
*******************************************************************************/
#include "ComStack_Types.h"
#include "NmStack_Types.h"  /* To resolve Nm types*/
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define FRNM_AR_RELEASE_MAJOR_VERSION  4
#define FRNM_AR_RELEASE_MINOR_VERSION  0
#define FRNM_AR_RELEASE_REVISION_VERSION  3

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define FRNM_SW_MAJOR_VERSION  1
#define FRNM_SW_MINOR_VERSION  0
#define FRNM_ARRAY_SIZE  8

/*******************************************************************************
**                      Function Prototype                                    **
*******************************************************************************/
extern Std_ReturnType FrNm_PassiveStartUp(const NetworkHandleType 
  nmChannelHandle); 

extern  boolean TestFrNm_PassiveStartUp(App_DataValidateType LucDataValidate, 
  const NetworkHandleType LddExpChannelHandle); 
  
extern void TestFrNm_PassiveStartSetRetVal(Std_ReturnType ReturnValue);
                                 
extern Std_ReturnType FrNm_NetworkRequest(const NetworkHandleType 
  nmChannelHandle);

extern  boolean TestFrNm_NetworkRequest(App_DataValidateType LucDataValidate, 
  const NetworkHandleType LddExpChannelHandle); 
  
extern void TestFrNm_NetworkReqSetRetVal(Std_ReturnType ReturnValue);  

extern Std_ReturnType FrNm_NetworkRelease(const NetworkHandleType 
  nmChannelHandle);

extern  boolean TestFrNm_NetworkRelease(App_DataValidateType LucDataValidate, 
const NetworkHandleType LddExpChannelHandle);

extern void TestFrNm_NetworkRelSetRetVal(Std_ReturnType ReturnValue);

extern Std_ReturnType FrNm_DisableCommunication(const NetworkHandleType 
  nmChannelHandle);

extern  boolean TestFrNm_DisableCommunication(App_DataValidateType 
  LucDataValidate, const NetworkHandleType LddExpChannelHandle);
  
extern void TestFrNm_DisableCommnSetRetVal(Std_ReturnType ReturnValue);
                                   
extern Std_ReturnType FrNm_EnableCommunication(const NetworkHandleType 
  nmChannelHandle);

extern  boolean TestFrNm_EnableCommunication (App_DataValidateType 
  LucDataValidate, const NetworkHandleType LddExpChannelHandle);
  
extern void TestFrNm_EnableCommnSetRetVal(Std_ReturnType ReturnValue);

extern Std_ReturnType FrNm_RepeatMessageRequest(const NetworkHandleType 
  nmChannelHandle);
                                   
extern  boolean TestFrNm_RepeatMessageRequest(App_DataValidateType 
  LucDataValidate, const NetworkHandleType LddExpChannelHandle); 
  
extern void TestFrNm_RptMsgReqSetRetVal(Std_ReturnType ReturnValue);

extern Std_ReturnType FrNm_SetUserData(const NetworkHandleType nmChannelHandle, 
  const uint8 * const nmUserDataPtr);

extern  boolean TestFrNm_SetUserData (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle, const uint8 * const ExpUserDataPtr);

extern Std_ReturnType FrNm_GetUserData(const NetworkHandleType nmChannelHandle,
uint8 * const nmUserDataPtr);

extern  boolean TestFrNm_GetUserData (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle);
  
extern void TestFrNm_GetUserDataSetVal(Std_ReturnType RetVal, uint8 UserData);
                         
extern Std_ReturnType FrNm_GetPduData(const NetworkHandleType nmChannelHandle,
  uint8 * const nmPduData);

extern  boolean TestFrNm_GetPduData (App_DataValidateType LucDataValidate, 
  const NetworkHandleType ExpChannelHandle);
  
extern void TestFrNm_GetPduDataSetVal(Std_ReturnType RetVal, uint8 PduData);
           
extern Std_ReturnType FrNm_GetNodeIdentifier(const NetworkHandleType 
  nmChannelHandle, uint8 * const nmNodeIdPtr);

extern  boolean TestFrNm_GetNodeIdentifier(App_DataValidateType 
  LucDataValidate, const NetworkHandleType ExpChannelHandle);
  
extern void TestFrNm_GetNodeIdDataSetVal(Std_ReturnType RetVal, uint8 NodeId);
         
extern Std_ReturnType FrNm_GetLocalNodeIdentifier(const NetworkHandleType 
  nmChannelHandle,uint8 * const nmNodeIdPtr);
         
extern  boolean TestFrNm_GetLocalNodeIdentifier(App_DataValidateType 
  LucDataValidate, const NetworkHandleType ExpChannelHandle);
  
extern void TestFrNm_GetLocalNodeIdDataSetVal(Std_ReturnType RetVal, uint8 NodeId);
         
extern Std_ReturnType FrNm_CheckRemoteSleepIndication(const NetworkHandleType 
nmChannelHandle, boolean * const nmRemoteSleepIndPtr);

extern  boolean TestFrNm_CheckRemoteSleepIndication(App_DataValidateType 
  LucDataValidate, const NetworkHandleType ExpChannelHandle);
  
extern void TestFrNm_CheckRemSleepIndDataSetVal(Std_ReturnType RetVal, 
  boolean SleepInd);
                          
extern Std_ReturnType FrNm_GetState(const NetworkHandleType nmChannelHandle,
  Nm_StateType * const nmStatePtr,Nm_ModeType * const nmModePtr);
 
extern  boolean TestFrNm_GetState(App_DataValidateType LucDataValidate, 
  const NetworkHandleType ExpChannelHandle);
  
extern void TestFrNm_GetStateDataSetVal(Std_ReturnType RetVal, Nm_StateType State, 
  Nm_ModeType Mode);

extern Std_ReturnType FrNm_RequestBusSynchronization
  (const NetworkHandleType nmChannelHandle);

extern boolean TestFrNm_RequestBusSynchronization (App_DataValidateType 
  LucDataValidate, const NetworkHandleType ExpChannelHandle);
  
extern void TestFrNm_ReqBusSynchSetRetVal(Std_ReturnType ReturnValue);


extern void TestFrNm_ModeSetUp(Nm_ModeType Mode);

extern void FrNm_StartupError(const NetworkHandleType NetworkHandle);
 
extern void TestFrNm_DefaultBehavior(void);

extern boolean TestFrNm_SetSleepReadyBit(App_DataValidateType
  LucDataValidate, const NetworkHandleType ExpChannelHandle, 
  const boolean ExpnmSleepReadyBit);
  
extern Std_ReturnType FrNm_SetSleepReadyBit(const NetworkHandleType
  nmChannelHandle, const boolean nmSleepReadyBit);

extern boolean TestFrNm_StartupError(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNetworkHandle);

extern void FrNM_Init(void);

extern boolean TestFrNM_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);

extern void FrNm_RxIndication(PduIdType RxPduId, PduInfoType* PduInfoPtr);

extern boolean TestFrNm_RxIndication(App_DataValidateType LucDataValidate,
  PduIdType RxPduId);

extern void FrNm_TxConfirmation(PduIdType TxPduId);

extern boolean TestFrNm_TxConfirmation(App_DataValidateType LucDataValidate,
  PduIdType TxPduId);

extern Std_ReturnType FrNm_TriggerTransmit(PduIdType TxPduId, 
  PduInfoType* PduInfoPtr);
  
extern boolean TestFrNm_TriggerTransmit(App_DataValidateType LucDataValidate,
  PduIdType TxPduId);

#endif /* FRNM_H */

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
