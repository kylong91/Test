/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: FrNm.c                                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FrNm Module                                           **
**                                                                            **
**  PURPOSE   : This application file contains the FrNm Stub functions        **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "FrNm.h"
#include "FrNm_Cbk.h"
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
NetworkHandleType FrNm_GddPassStartChnlHandle;
NetworkHandleType FrNm_GddNwReqChnlHandle;
NetworkHandleType FrNm_GddNwRelChnlHandle;
NetworkHandleType FrNm_GddDisCommnChnlHandle;
NetworkHandleType FrNm_GddEnCommnChnlHandle;
NetworkHandleType FrNm_GddSetUserDataChnlHandle;
NetworkHandleType FrNm_GddGetUserDataChnlHandle;
NetworkHandleType FrNm_GddRptMsgReqChnlHandle;
NetworkHandleType FrNm_GddGetNodeIdChnlHandle;
NetworkHandleType FrNm_GddGetLocNodeIdChnlHandle;
NetworkHandleType FrNm_GddCheckRemSleepIndChnlHandle;
NetworkHandleType FrNm_GddGetStateIndChnlHandle;
NetworkHandleType FrNm_GddReqBusSynchChnlHandle;
NetworkHandleType FrNm_GddGetPduDataChnlHandle;
#ifdef NM_MODULE_ACTIVE
NetworkHandleType FrNm_GddSetSleepBitChnlHandle;
#endif
uint8 FrNm_GucSetUserData;
boolean * FrNm_GblRemoteSleepIndPtr;
Nm_StateType * FrNm_GddStatePtr; 
Nm_ModeType * FrNm_GddModePtr;
uint8 FrNm_GucPassiveStartCount;
uint8 FrNm_GucNetworkReqCount;
uint8 FrNm_GucNetworkRelCount;
uint8 FrNm_GucDisableCommnCount;
uint8 FrNm_GucEnableCommnCount;
uint8 FrNm_GucRptMsgReqCount;
uint8 FrNm_GucSetUserDataCount;
uint8 FrNm_GucGetUserDataCount;
uint8 FrNm_GucGetPduDataCount;
uint8 FrNm_GucGetNodeIdCount;
uint8 FrNm_GucGetLocalNodeIdCount;
uint8 FrNm_GucCheckRemSleepIndCount;
uint8 FrNm_GucGetStateCount;
uint8 FrNm_GucReqBusSynchCount;
#ifdef NM_MODULE_ACTIVE
uint8 FrNm_GucSetSleepBitCount;
uint8 FrNm_GddSetSleepBitRetVal;
#endif
Std_ReturnType FrNm_GddPassiveStartRetVal;
Std_ReturnType FrNm_GddNetworkReqRetVal;
Std_ReturnType FrNm_GddNetworkRelRetVal;
Std_ReturnType FrNm_GddDisableCommnRetVal;
Std_ReturnType FrNm_GddEnableCommnRetVal;
Std_ReturnType FrNm_GddRptMsgReqRetVal;
Std_ReturnType FrNm_GddSetUserDataRetVal;
Std_ReturnType FrNm_GddGetUserDataRetVal;
Std_ReturnType FrNm_GddGetPduDataRetVal;
Std_ReturnType FrNm_GddGetNodeIdRetVal;
Std_ReturnType FrNm_GddGetLocalNodeIdRetVal;
Std_ReturnType FrNm_GddCheckRemSleepIndRetVal;
Std_ReturnType FrNm_GddGetStateRetVal;
Std_ReturnType FrNm_GddReqBusSynchRetVal;
Std_ReturnType FrNm_GddReqExpulRetVal;
uint8 FrNm_GucGetUserData;
uint8 FrNm_GucPduData;
uint8 FrNm_GucNodeId;
uint8 FrNm_GucLocalNodeId;
boolean FrNm_GblRemSleep;
#ifdef NM_MODULE_ACTIVE
boolean FrNm_GblnmSleepReadyBit;
#endif
Nm_StateType FrNm_GddState;
Nm_ModeType FrNm_GddMode;

uint8 FrNm_GaaStrtupErrNtwrkHndle[FRNM_ARRAY_SIZE];
uint8 FrNm_GucStartupErrorCount;
uint8 FrNm_GucStartupErrorCheckCount;

#ifdef BSWM_MODULE_ACTIVE
uint8 FrNM_GucInitCnt;
uint8 FrNM_GucInitSeqCnt;
#endif

#ifdef FRIF_MODULE_ACTIVE
PduIdType FrNm_GddTxPduId;
uint8 FrNm_GucTxConfirmationcount;
PduIdType FrNm_GddRxPduId;
uint8 FrNm_GucRxConfirmationcount;
uint8 FrNm_GucFrIfTriggerTransmit;
#endif

/******************************************************************************/
/*             FrNm_PassiveStartUp                                            */
/******************************************************************************/
Std_ReturnType FrNm_PassiveStartUp(const NetworkHandleType nmChannelHandle)
{
  FrNm_GddPassStartChnlHandle = nmChannelHandle; 
  FrNm_GucPassiveStartCount++;
  return(FrNm_GddPassiveStartRetVal);
}
/*******************************************************************************
**                       TestFrNm_PassiveStartUp ()                           **
*******************************************************************************/
boolean TestFrNm_PassiveStartUp (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((FrNm_GucPassiveStartCount == 0x01)&&
        (ExpChannelHandle == FrNm_GddPassStartChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      FrNm_GucPassiveStartCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrNm_PassiveStartUp() */
/*******************************************************************************
**                       TestFrNm_PassiveStartSetRetVal()                     **
*******************************************************************************/
void TestFrNm_PassiveStartSetRetVal(Std_ReturnType ReturnValue)
{
  FrNm_GddPassiveStartRetVal = ReturnValue;
} /* End TestFrNm_PassiveStartSetRetVal() */
/******************************************************************************/
/*                       FrNm_NetworkRequest()                                */
/******************************************************************************/
Std_ReturnType FrNm_NetworkRequest(const NetworkHandleType nmChannelHandle)
{
  FrNm_GddNwReqChnlHandle = nmChannelHandle; 
  FrNm_GucNetworkReqCount++;
  return(FrNm_GddNetworkReqRetVal);
}
/*******************************************************************************
**                       TestFrNm_NetworkRequest ()                           **
*******************************************************************************/
boolean TestFrNm_NetworkRequest (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((FrNm_GucNetworkReqCount == 0x01)&&
        (ExpChannelHandle == FrNm_GddNwReqChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      FrNm_GucNetworkReqCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrNm_NetworkRequest() */
/*******************************************************************************
**                       TestFrNm_NetworkReqSetRetVal()                       **
*******************************************************************************/
void TestFrNm_NetworkReqSetRetVal(Std_ReturnType ReturnValue)
{
  FrNm_GddNetworkReqRetVal = ReturnValue;
} /* End TestFrNm_NetworkReqSetRetVal() */
/******************************************************************************/
/*                       FrNm_NetworkRelease()                                */
/******************************************************************************/
Std_ReturnType FrNm_NetworkRelease(const NetworkHandleType nmChannelHandle)
{
  FrNm_GddNwRelChnlHandle = nmChannelHandle; 
  FrNm_GucNetworkRelCount++;
  return(FrNm_GddNetworkRelRetVal);
} /* End FrNm_NetworkRelease() */
/*******************************************************************************
**                       TestFrNm_NetworkRelease ()                           **
*******************************************************************************/
boolean TestFrNm_NetworkRelease (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((FrNm_GucNetworkRelCount == 0x01)&&
        (ExpChannelHandle == FrNm_GddNwRelChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      FrNm_GucNetworkRelCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrNm_GucNetworkRelCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrNm_NetworkRelease() */
#ifdef FRIF_MODULE_ACTIVE
/*******************************************************************************
**                       FrNm_RxIndication()                                  **
*******************************************************************************/
void FrNm_RxIndication(PduIdType RxPduId, PduInfoType* PduInfoPtr)
{
  UNUSED(PduInfoPtr);
  FrNm_GddRxPduId = RxPduId;
  FrNm_GucRxConfirmationcount++;
} /* End FrNm_RxIndication() */
/*******************************************************************************
**                       TestFrNm_RxIndication()                              **
*******************************************************************************/
boolean TestFrNm_RxIndication(App_DataValidateType LucDataValidate,
PduIdType RxPduId)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((FrNm_GucRxConfirmationcount == 0x01) && 
        (FrNm_GddRxPduId == RxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrNm_GucRxConfirmationcount = 0;      
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrNm_GucRxConfirmationcount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}
/*******************************************************************************
**                       FrNm_TxConfirmation()                                **
*******************************************************************************/
void FrNm_TxConfirmation(PduIdType TxPduId)
{
  FrNm_GddTxPduId = TxPduId;
  FrNm_GucTxConfirmationcount++;  
} /* End FrNm_TxConfirmation() */
/*******************************************************************************
**                       TestFrNm_TxConfirmation()                            **
*******************************************************************************/
boolean TestFrNm_TxConfirmation(App_DataValidateType LucDataValidate,
PduIdType TxPduId)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((FrNm_GucTxConfirmationcount == 0x01) && 
        (FrNm_GddTxPduId == TxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrNm_GucTxConfirmationcount = 0;      
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrNm_GucTxConfirmationcount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}
/*******************************************************************************
**                       FrNm_TriggerTransmit()                               **
*******************************************************************************/
Std_ReturnType FrNm_TriggerTransmit(PduIdType TxPduId,
      PduInfoType* PduInfoPtr)
  {
    PduInfoType LddstPduInfoPtr;
    LddstPduInfoPtr.SduLength = PduInfoPtr->SduLength;
    FrNm_GddTxPduId = TxPduId;
    FrNm_GucFrIfTriggerTransmit++;
    return(E_OK);
  }
/*******************************************************************************
**                       TestFrNm_TriggerTransmit()                           **
*******************************************************************************/
boolean TestFrNm_TriggerTransmit(App_DataValidateType LucDataValidate,
PduIdType TxPduId)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((FrNm_GucFrIfTriggerTransmit == 0x01) && 
        (FrNm_GddTxPduId == TxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrNm_GucFrIfTriggerTransmit = 0;      
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrNm_GucFrIfTriggerTransmit == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}  
#endif

/*******************************************************************************
**                       TestFrNm_NetworkRelSetRetVal()                       **
*******************************************************************************/
void TestFrNm_NetworkRelSetRetVal(Std_ReturnType ReturnValue)
{
  FrNm_GddNetworkRelRetVal = ReturnValue;
} /* End TestFrNm_NetworkRelSetRetVal() */
/******************************************************************************/
/*                       FrNm_DisableCommunication()                          */
/******************************************************************************/
Std_ReturnType FrNm_DisableCommunication(const NetworkHandleType 
  nmChannelHandle)
{
  FrNm_GddDisCommnChnlHandle = nmChannelHandle; 
  FrNm_GucDisableCommnCount++;
  return(FrNm_GddDisableCommnRetVal);
} /* End FrNm_DisableCommunication() */
/*******************************************************************************
**                       TestFrNm_DisableCommunication()                      **
*******************************************************************************/
boolean TestFrNm_DisableCommunication (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((FrNm_GucDisableCommnCount == 0x01)&&
        (ExpChannelHandle == FrNm_GddDisCommnChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      FrNm_GucDisableCommnCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrNm_DisableCommunication() */
/*******************************************************************************
**                       TestFrNm_DisableCommnSetRetVal()                     **
*******************************************************************************/
void TestFrNm_DisableCommnSetRetVal(Std_ReturnType ReturnValue)
{
  FrNm_GddDisableCommnRetVal = ReturnValue;
} /* End TestFrNm_DisableCommnReturnValSetUp() */
/******************************************************************************/
/*                       FrNm_EnableCommunication()                           */
/******************************************************************************/
Std_ReturnType FrNm_EnableCommunication(const NetworkHandleType nmChannelHandle)
{
  FrNm_GddEnCommnChnlHandle = nmChannelHandle;
  FrNm_GucEnableCommnCount++;
  return(FrNm_GddEnableCommnRetVal);
} /* End FrNm_EnableCommunication() */
/*******************************************************************************
**                       TestFrNm_EnableCommunication()                       **
*******************************************************************************/
boolean TestFrNm_EnableCommunication (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((FrNm_GucEnableCommnCount == 0x01)&&
        (ExpChannelHandle == FrNm_GddEnCommnChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      FrNm_GucEnableCommnCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrNm_EnableCommunication() */
/*******************************************************************************
**                       TestFrNm_EnableCommnSetRetVal()                      **
*******************************************************************************/
void TestFrNm_EnableCommnSetRetVal(Std_ReturnType ReturnValue)
{
  FrNm_GddEnableCommnRetVal = ReturnValue;
} /* End TestFrNm_EnableCommnSetRetVal() */
/******************************************************************************/
/*                       FrNm_RepeatMessageRequest()                          */
/******************************************************************************/
Std_ReturnType FrNm_RepeatMessageRequest(const NetworkHandleType 
  nmChannelHandle)
{
  FrNm_GddRptMsgReqChnlHandle = nmChannelHandle;
  FrNm_GucRptMsgReqCount++;
  return(FrNm_GddRptMsgReqRetVal);
} /* End FrNm_RepeatMessageRequest() */
/*******************************************************************************
**                       TestFrNm_RepeatMessageRequest()                      **
*******************************************************************************/
boolean TestFrNm_RepeatMessageRequest(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((FrNm_GucRptMsgReqCount == 0x01)&&
        (ExpChannelHandle == FrNm_GddRptMsgReqChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      FrNm_GucRptMsgReqCount = 0;
      break;
      default:
      {
        break;
      }
    }
    
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrNm_RepeatMessageRequest() */
/*******************************************************************************
**                       TestFrNm_RptMsgReqSetRetVal()                        **
*******************************************************************************/
void TestFrNm_RptMsgReqSetRetVal(Std_ReturnType ReturnValue)
{
  FrNm_GddRptMsgReqRetVal = ReturnValue;
} /* End TestFrNm_RptMsgReqSetRetVal() */
/******************************************************************************/
/*                       FrNm_RequestBusSynchronization()                     */
/******************************************************************************/
Std_ReturnType FrNm_RequestBusSynchronization(const NetworkHandleType 
  nmChannelHandle)
{
  FrNm_GddReqBusSynchChnlHandle = nmChannelHandle; 
  FrNm_GucReqBusSynchCount++;
  return(FrNm_GddReqBusSynchRetVal);
} /* End FrNm_RequestBusSynchronization() */
/*******************************************************************************
**                       TestFrNm_RequestBusSynchronization()                 **
*******************************************************************************/
boolean TestFrNm_RequestBusSynchronization(App_DataValidateType 
  LucDataValidate, const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((FrNm_GucReqBusSynchCount == 0x01)&&
        (ExpChannelHandle == FrNm_GddReqBusSynchChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      FrNm_GucReqBusSynchCount = 0;
      break;
      default:
      {
        break;
      }
    }
   
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrNm_RequestBusSynchronization() */
/*******************************************************************************
**                       TestFrNm_ReqBusSynchSetRetVal()                      **
*******************************************************************************/
void TestFrNm_ReqBusSynchSetRetVal(Std_ReturnType ReturnValue)
{
  FrNm_GddReqBusSynchRetVal = ReturnValue;
}
#ifdef NM_MODULE_ACTIVE
/******************************************************************************/
/*                         FrNm_SetSleepReadyBit()                            */
/******************************************************************************/
Std_ReturnType FrNm_SetSleepReadyBit(const NetworkHandleType
  nmChannelHandle, const boolean nmSleepReadyBit)
{
  FrNm_GddSetSleepBitChnlHandle = nmChannelHandle;
  FrNm_GblnmSleepReadyBit = nmSleepReadyBit;
  FrNm_GucSetSleepBitCount++;
  return(FrNm_GddSetSleepBitRetVal);
} /* End FrNm_SetSleepReadyBit() */
/*******************************************************************************
**                       TestFrNm_SetSleepReadyBit()                          **
*******************************************************************************/
boolean TestFrNm_SetSleepReadyBit(App_DataValidateType
  LucDataValidate, const NetworkHandleType ExpChannelHandle,
  const boolean ExpnmSleepReadyBit)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((FrNm_GucSetSleepBitCount == 0x01)&&
        (ExpChannelHandle == FrNm_GddSetSleepBitChnlHandle)&& 
        (ExpnmSleepReadyBit == FrNm_GblnmSleepReadyBit))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      FrNm_GucSetSleepBitCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrNm_GucSetSleepBitCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }    
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrNm_SetSleepReadyBit() */
/******************************************************************************/
/*                       FrNm_SetUserData()                                   */
/******************************************************************************/
Std_ReturnType FrNm_SetUserData(const NetworkHandleType nmChannelHandle, 
  const uint8 * const nmUserDataPtr)
{
  FrNm_GddSetUserDataChnlHandle = nmChannelHandle; 
  FrNm_GucSetUserData = *nmUserDataPtr;
  FrNm_GucSetUserDataCount++;
  return(FrNm_GddSetUserDataRetVal);
}  /* End FrNm_SetUserData() */

/*******************************************************************************
**                       TestFrNm_SetUserData()                               **
*******************************************************************************/
boolean TestFrNm_SetUserData (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle, const uint8 * const ExpUserDataPtr)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((FrNm_GucSetUserDataCount == 0x01)&&
        (ExpChannelHandle == FrNm_GddSetUserDataChnlHandle) && 
        (*ExpUserDataPtr == FrNm_GucSetUserData))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      FrNm_GucSetUserDataCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrNm_SetUserData() */

/******************************************************************************/
/*                       FrNm_GetUserData()                                   */
/******************************************************************************/
Std_ReturnType FrNm_GetUserData(const NetworkHandleType nmChannelHandle, 
  uint8 * const nmUserDataPtr)
{
  FrNm_GddGetUserDataChnlHandle = nmChannelHandle; 
  *nmUserDataPtr = FrNm_GucGetUserData;
  FrNm_GucGetUserDataCount++;
  return(FrNm_GddGetUserDataRetVal);
} /* End FrNm_GetUserData() */
/*******************************************************************************
**                       TestFrNm_GetUserData()                               **
*******************************************************************************/
boolean TestFrNm_GetUserData(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((FrNm_GucGetUserDataCount == 0x01)&&
        (ExpChannelHandle == FrNm_GddGetUserDataChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      FrNm_GucGetUserDataCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrNm_GetUserData() */
/*******************************************************************************
**                       TestFrNm_GetUserDataSetVal()                         **
*******************************************************************************/
void TestFrNm_GetUserDataSetVal(Std_ReturnType RetVal, uint8 UserData)
{
  FrNm_GddGetUserDataRetVal = RetVal;
  FrNm_GucGetUserData = UserData;
} /* End TestFrNm_GetUserDataSetVal() */
/******************************************************************************/
/*                       FrNm_GetPduData()                                    */
/******************************************************************************/
Std_ReturnType FrNm_GetPduData(const NetworkHandleType nmChannelHandle,
  uint8 *const nmPduData)
{
  FrNm_GddGetPduDataChnlHandle = nmChannelHandle; 
  *nmPduData = FrNm_GucPduData;
  FrNm_GucGetPduDataCount++;
  
  return(FrNm_GddGetPduDataRetVal);
} /* End FrNm_GetPduData() */
/*******************************************************************************
**                       TestFrNm_GetPduData()                                **
*******************************************************************************/
boolean TestFrNm_GetPduData (App_DataValidateType LucDataValidate, const 
  NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((FrNm_GucGetPduDataCount == 0x01)&&
        (ExpChannelHandle == FrNm_GddGetPduDataChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      FrNm_GucGetPduDataCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrNm_GetUserData() */
/*******************************************************************************
**                       TestFrNm_GetPduDataSetVal()                          **
*******************************************************************************/
void TestFrNm_GetPduDataSetVal(Std_ReturnType RetVal, uint8 PduData)
{
  FrNm_GddGetPduDataRetVal = RetVal;
  FrNm_GucPduData = PduData;
} /* End TestFrNm_GetPduDataSetVal() */
/******************************************************************************/
/*                       FrNm_GetNodeIdentifier()                             */
/******************************************************************************/
Std_ReturnType FrNm_GetNodeIdentifier(const NetworkHandleType nmChannelHandle,
  uint8 * const nmNodeIdPtr)
{
  FrNm_GddGetNodeIdChnlHandle = nmChannelHandle; 
  *nmNodeIdPtr = FrNm_GucNodeId;
  FrNm_GucGetNodeIdCount++;
  return(FrNm_GddGetNodeIdRetVal);
} /* End FrNm_GetNodeIdentifier() */
/*******************************************************************************
**                       TestFrNm_GetNodeIdentifier()                         **
*******************************************************************************/
boolean TestFrNm_GetNodeIdentifier(App_DataValidateType LucDataValidate,const 
  NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((FrNm_GucGetNodeIdCount == 0x01)&&
        (ExpChannelHandle == FrNm_GddGetNodeIdChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      FrNm_GucGetNodeIdCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrNm_GetNodeIdentifier() */
/*******************************************************************************
**                       TestFrNm_GetNodeIdDataSetVal()                       **
*******************************************************************************/
void TestFrNm_GetNodeIdDataSetVal(Std_ReturnType RetVal, uint8 NodeId)
{
  FrNm_GddGetNodeIdRetVal = RetVal;
  FrNm_GucNodeId = NodeId;
} /* End TestFrNm_GetNodeIdDataSetUp() */
/******************************************************************************/
/*                       FrNm_GetLocalNodeIdentifier()                        */
/******************************************************************************/
Std_ReturnType FrNm_GetLocalNodeIdentifier(const NetworkHandleType nmChannelHandle,
  uint8 * const nmNodeIdPtr)
{
  FrNm_GddGetLocNodeIdChnlHandle = nmChannelHandle; 
  *nmNodeIdPtr = FrNm_GucLocalNodeId;
  FrNm_GucGetLocalNodeIdCount++;
  return(FrNm_GddGetLocalNodeIdRetVal);
} /* End FrNm_GetLocalNodeIdentifier() */
/*******************************************************************************
**                       TestFrNm_GetLocalNodeIdentifier()                    **
*******************************************************************************/
boolean TestFrNm_GetLocalNodeIdentifier(App_DataValidateType LucDataValidate,const 
  NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((FrNm_GucGetLocalNodeIdCount == 0x01)&&
        (ExpChannelHandle == FrNm_GddGetLocNodeIdChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      FrNm_GucGetLocalNodeIdCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrNm_GetLocalNodeIdentifier() */

/*******************************************************************************
**                       TestFrNm_GetLocalNodeIdDataSetVal()                  **
*******************************************************************************/
void TestFrNm_GetLocalNodeIdDataSetVal(Std_ReturnType RetVal, uint8 NodeId)
{
  FrNm_GddGetLocalNodeIdRetVal = RetVal;
  FrNm_GucLocalNodeId = NodeId;
} /* End TestFrNm_GetLocalNodeIdDataSetVal() */

/*******************************************************************************
**             FrNm_CheckRemoteSleepIndication()                              **
*******************************************************************************/
Std_ReturnType FrNm_CheckRemoteSleepIndication(const NetworkHandleType 
  nmChannelHandle, boolean * const nmRemoteSleepIndPtr)
{
  FrNm_GddCheckRemSleepIndChnlHandle = nmChannelHandle; 
  *nmRemoteSleepIndPtr = FrNm_GblRemSleep;
  FrNm_GucCheckRemSleepIndCount++;
  return(FrNm_GddCheckRemSleepIndRetVal);
} /* End FrNm_CheckRemoteSleepIndication() */

/*******************************************************************************
**                       TestFrNm_CheckRemoteSleepIndication()                **
*******************************************************************************/
boolean TestFrNm_CheckRemoteSleepIndication(App_DataValidateType 
  LucDataValidate,const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((FrNm_GucCheckRemSleepIndCount == 0x01)&&
        (ExpChannelHandle == FrNm_GddCheckRemSleepIndChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      FrNm_GucCheckRemSleepIndCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrNm_CheckRemoteSleepIndication() */

/*******************************************************************************
**                       TestFrNm_CheckRemSleepIndDataSetVal()                **
*******************************************************************************/
void TestFrNm_CheckRemSleepIndDataSetVal(Std_ReturnType RetVal, 
  boolean SleepInd)
{
  FrNm_GddCheckRemSleepIndRetVal = RetVal;
  FrNm_GblRemSleep = SleepInd;
} /* End TestFrNm_CheckRemSleepIndDataSetVal() */

/*******************************************************************************
**              Function Name :FrNm_GetState()                                **
*******************************************************************************/
Std_ReturnType FrNm_GetState(const NetworkHandleType nmChannelHandle, 
  Nm_StateType * const nmStatePtr, Nm_ModeType * const nmModePtr)
{
  FrNm_GddGetStateIndChnlHandle = nmChannelHandle; 
  *nmStatePtr = FrNm_GddState;
  *nmModePtr = FrNm_GddMode;
  FrNm_GucGetStateCount++;
  return(FrNm_GddGetStateRetVal);
} /* End FrNm_GetState() */
/*******************************************************************************
**                       TestFrNm_GetState()                                  **
*******************************************************************************/
boolean TestFrNm_GetState(App_DataValidateType LucDataValidate, 
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((FrNm_GucGetStateCount == 0x01)&&
        (ExpChannelHandle == FrNm_GddGetStateIndChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      FrNm_GucGetStateCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrNm_GetState() */
/*******************************************************************************
**                       TestFrNm_GetStateDataSetVal()                        **
*******************************************************************************/
void TestFrNm_GetStateDataSetVal(Std_ReturnType RetVal, Nm_StateType State, 
  Nm_ModeType Mode)
{
  FrNm_GddGetStateRetVal = RetVal;
  FrNm_GddMode = Mode;
  FrNm_GddState = State;
} /* End TestFrNm_GetStateDataSetVal() */
#endif
/*******************************************************************************
**                       TestFrNm_ModeSetUp()                                 **
*******************************************************************************/
void TestFrNm_ModeSetUp(Nm_ModeType Mode)
{
  FrNm_GddMode = Mode;
} /* End TestFrNm_ModeSetUp() */

#ifdef FRSM_MODULE_ACTIVE
/*******************************************************************************
**                       FrNm_StartupError()                                  **
*******************************************************************************/
void FrNm_StartupError( const NetworkHandleType NetworkHandle )
{
  #ifndef TYPICAL_CONFIG
  FrNm_GucStartupErrorCount = 0;
  
  /* Load actual CtrlId into Global variable */
  FrNm_GaaStrtupErrNtwrkHndle[FrNm_GucStartupErrorCount] = NetworkHandle;
  /* Increment the count */
  FrNm_GucStartupErrorCount++;
  #endif
} /* End FrNm_StartupError() */

/*******************************************************************************
**                       TestFrNm_StartupError()                              **
*******************************************************************************/
boolean TestFrNm_StartupError(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpNetworkHandle)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrNm_GucStartupErrorCount == 0x01) && 
        (ExpNetworkHandle == FrNm_GaaStrtupErrNtwrkHndle[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrNm_GucStartupErrorCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrNm_GucStartupErrorCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < FrNm_GucStartupErrorCount; LucIndex++)
      {
        /* Validate the Controller Id */
        if((ExpNetworkHandle ==
          FrNm_GaaStrtupErrNtwrkHndle[FrNm_GucStartupErrorCheckCount]))
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = FrNm_GucStartupErrorCount;
        } /* End if(ExpNetworkHandle == FrNm_GaaStrtupErrNtwrkHndle[LucIndex])*/
      } /* End for(LucIndex = 0; LucIndex < FrNm_GucStartupErrorCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrNm_GucStartupErrorCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrNm_GucStartupErrorCheckCount == FrNm_GucStartupErrorCount)
      {
        FrNm_GucStartupErrorCount = 0;
        FrNm_GucStartupErrorCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    /*
     * Case to handle API invocation with multiple occurance (with sequnce)
     * and to validate parameters of the API with what it has been invoked
     */
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((FrNm_GucStartupErrorCheckCount <= FrNm_GucStartupErrorCount) &&
        (ExpNetworkHandle ==
         FrNm_GaaStrtupErrNtwrkHndle[FrNm_GucStartupErrorCheckCount]))
      {
        LblRetValue = STEP_PASSED;
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrNm_GucStartupErrorCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrNm_GucStartupErrorCheckCount == FrNm_GucStartupErrorCount)
      {
        FrNm_GucStartupErrorCount = 0;
        FrNm_GucStartupErrorCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrNm_GucStartupErrorCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpNetworkHandle == FrNm_GaaStrtupErrNtwrkHndle[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrNm_StartupError() */
#endif
/*******************************************************************************
**                       TestFrNm_DefaultBehavior()                           **
*******************************************************************************/
void TestFrNm_DefaultBehavior(void)
{
  FrNm_GddMode = NM_MODE_BUS_SLEEP;
  FrNm_GddState = NM_STATE_UNINIT;
  #ifdef NM_MODULE_ACTIVE
  FrNm_GblnmSleepReadyBit = 0;
  FrNm_GddSetSleepBitChnlHandle = 0;
  #endif
  FrNm_GucPassiveStartCount = 0;
  FrNm_GucNetworkReqCount = 0;
  FrNm_GucNetworkRelCount = 0;
  FrNm_GucDisableCommnCount = 0;
  FrNm_GucEnableCommnCount = 0;
  FrNm_GucRptMsgReqCount = 0;
  FrNm_GucSetUserDataCount = 0;
  FrNm_GucGetUserDataCount = 0;
  FrNm_GucGetPduDataCount = 0;
  FrNm_GucGetNodeIdCount = 0;
  FrNm_GucGetLocalNodeIdCount = 0;
  FrNm_GucCheckRemSleepIndCount = 0;
  FrNm_GucGetStateCount = 0;
  FrNm_GucReqBusSynchCount = 0;
  FrNm_GucStartupErrorCount = 0;
  #ifdef NM_MODULE_ACTIVE
  FrNm_GucSetSleepBitCount = 0;
  #endif
  FrNm_GddPassiveStartRetVal = E_OK;
  FrNm_GddNetworkReqRetVal = E_OK;
  FrNm_GddNetworkRelRetVal = E_OK;
  FrNm_GddDisableCommnRetVal = E_OK;
  FrNm_GddEnableCommnRetVal = E_OK;
  FrNm_GddRptMsgReqRetVal = E_OK;
  FrNm_GddSetUserDataRetVal = E_OK;
  FrNm_GddGetUserDataRetVal = E_OK;
  FrNm_GddGetPduDataRetVal = E_OK;
  FrNm_GddGetNodeIdRetVal = E_OK;
  FrNm_GddGetLocalNodeIdRetVal = E_OK;
  FrNm_GddCheckRemSleepIndRetVal = E_OK;
  FrNm_GddGetStateRetVal = E_OK;
  FrNm_GddReqBusSynchRetVal = E_OK;
} /* End TestFrNm_DefaultBehavior() */

#ifdef BSWM_MODULE_ACTIVE
/*******************************************************************************
**                          FrNm_Init()                                       **
*******************************************************************************/

void FrNm_Init(void)
{
	App_GucApiSeqCnt++;
	FrNM_GucInitSeqCnt = App_GucApiSeqCnt;
	FrNM_GucInitCnt++;
}/* End FrNM_Init() */

/*******************************************************************************
**                           TestFrNm_Init()                                  **
*******************************************************************************/
boolean TestFrNm_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(FrNM_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      FrNM_GucInitCnt = 0;
      FrNM_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(FrNM_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      FrNM_GucInitCnt = 0;
      FrNM_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrNM_Init() */
#endif
/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
