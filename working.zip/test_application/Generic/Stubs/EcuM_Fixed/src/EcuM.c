/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: EcuM.c                                                        **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR EcuM Stub                                             **
**                                                                            **
**  PURPOSE   : This application file contains the EcuM Stub functions        **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision    Date         By    Description                                 **
********************************************************************************
** 1.0.0     26-Dec-2012    Kiranmai    Initial Version                       **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "EcuM.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 NvM_MultiBlockServiceId[ECUM_ARRAY_SIZE];
uint8 NvM_MultiBlockJobResult[ECUM_ARRAY_SIZE];
uint8 NvM_GucMultiBlkCbkCount;
uint8 NvM_GucMultiBlkCbkCheckCount;
/*******************************************************************************
**                            MULTI_BLOCK_CBK()                               **
*******************************************************************************/
void MULTI_BLOCK_CBK(uint8 ServiceId, NvM_RequestResultType JobResult)
{
  /* Load actual ServiceId and JobResult into Global variables */
  NvM_MultiBlockServiceId[NvM_GucMultiBlkCbkCount] = ServiceId;
  NvM_MultiBlockJobResult[NvM_GucMultiBlkCbkCount] = JobResult;

  /* Increment count variable to handle multiple invocations */
  if(NvM_GucMultiBlkCbkCount < ECUM_ARRAY_SIZE)
  {
    NvM_GucMultiBlkCbkCount++;
  }
}

/*******************************************************************************
**                        Test_MULTI_BLOCK_CBK()                              **
*******************************************************************************/
boolean Test_MULTI_BLOCK_CBK(App_DataValidateType LucDataValidate,
  uint8 LucExpServiceId, NvM_RequestResultType LddExpJobResult)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle callback invocation with single occurance and to validate
     * parameters of the callback with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ControllerId and PduModeRequest */
      if((NvM_GucMultiBlkCbkCount == 0x01) &&
        (NvM_MultiBlockServiceId[0] == LucExpServiceId) &&
        (NvM_MultiBlockJobResult[0] == LddExpJobResult))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      NvM_GucMultiBlkCbkCount = 0;
      NvM_GucMultiBlkCbkCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < NvM_GucMultiBlkCbkCount; LucIndex++)
      {
        /* Validate ControllerId and PduModeRequest */
        if((NvM_MultiBlockServiceId[LucIndex] == LucExpServiceId) &&
          (NvM_MultiBlockJobResult[LucIndex] == LddExpJobResult))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = NvM_GucMultiBlkCbkCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      NvM_GucMultiBlkCbkCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(NvM_GucMultiBlkCbkCheckCount == NvM_GucMultiBlkCbkCount)
      {
        NvM_GucMultiBlkCbkCount = 0;
        NvM_GucMultiBlkCbkCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(NvM_GucMultiBlkCbkCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End Test_MULTI_BLOCK_CBK() */

/*******************************************************************************
**                        TestEcuM_DefaultBehavior()                          **
*******************************************************************************/
void TestEcuM_DefaultBehavior(void)
{
  NvM_GucMultiBlkCbkCount = 0;
  NvM_GucMultiBlkCbkCheckCount = 0;
}

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

