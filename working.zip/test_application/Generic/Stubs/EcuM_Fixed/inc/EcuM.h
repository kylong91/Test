/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: EcuM.h                                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR EcuM Interface module                                 **
**                                                                            **
**  PURPOSE   : Declaration of EcuM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date           By          Description                           **
********************************************************************************
** 1.0.0     26-Dec-2012    Kiranmai    Initial Version                       **
*******************************************************************************/
#ifndef ECUM_H
#define ECUM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "EcuM_Cbk.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define ECUM_AR_RELEASE_MAJOR_VERSION    4
#define ECUM_AR_RELEASE_MINOR_VERSION    0
#define ECUM_AR_RELEASE_REVISION_VERSION 3

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/


/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void TestEcuM_DefaultBehavior(void);
#endif /* ECUM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
