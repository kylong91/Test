/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: EcuM_Cbk.h                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR EcuM Interface module                                 **
**                                                                            **
**  PURPOSE   : Declaration of EcuM Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     26-Dec-2012    Kiranmai    Initial Version                       **
*******************************************************************************/
#ifndef ECUM_CBK_H
#define ECUM_CBK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
#include "NvM.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define ECUM_AR_RELEASE_MAJOR_VERSION    4
#define ECUM_AR_RELEASE_MINOR_VERSION    0
#define ECUM_AR_RELEASE_REVISION_VERSION 3

#define ECUM_ARRAY_SIZE      0x20

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void MULTI_BLOCK_CBK(uint8 ServiceId, NvM_RequestResultType JobResult);

extern boolean Test_MULTI_BLOCK_CBK(App_DataValidateType LucDataValidate, 
  uint8 LucExpServiceId, NvM_RequestResultType LddExpJobResult);

#endif /* ECUM_CBK_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
