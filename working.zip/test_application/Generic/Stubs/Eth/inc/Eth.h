/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Eth.c                                                         **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR ETH Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Eth stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     22-Jun-2011   BJV    Initial version                             **
*******************************************************************************/
#ifndef ETH_H
#define ETH_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"    
#include "TC_Generic.h"
#include "Eth_GeneralTypes.h"   
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR specification version information */
#define ETH_AR_RELEASE_MAJOR_VERSION  4
#define ETH_AR_RELEASE_MINOR_VERSION  0
#define ETH_AR_RELEASE_REVISION_VERSION  3

/* Software version information */
#define ETH_SW_MAJOR_VERSION  1
#define ETH_SW_MINOR_VERSION  0
#define ETH_SW_PATCH_VERSION  0
/*******************************************************************************
**                                                                           **
*******************************************************************************/

extern Std_ReturnType Eth_ControllerInit( uint8 CtrlIdx, uint8 CfgIdx );
extern boolean TestEth_ControllerInit(App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,uint8 LucExpCfgIdx);

extern Std_ReturnType Eth_GetControllerMode(   
            uint8 CtrlIdx, Eth_ModeType* CtrlModePtr);
            
extern boolean TestEth_GetControllerMode(App_DataValidateType LddDataValidate,
  uint8 LucExpController, Eth_ModeType* LddExpMode);
  
extern Std_ReturnType Eth_SetControllerMode( uint8 CtrlIdx, 
                                                        Eth_ModeType CtrlMode ); 

extern boolean TestEth_SetControllerMode(App_DataValidateType LddDataValidate,
  uint8 LucExpController, Eth_ModeType LddExpMode);  

  
 extern BufReq_ReturnType Eth_ProvideTxBuffer(
    uint8 CtrlIdx,
    uint8* BufIdxPtr,
    uint8** BufPtr,
    uint16* LenBytePtr
);

extern boolean TestEth_ProvideTxBuffer (App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,uint8* LucExpBufIdxPtr,
  uint8** LucExpBufPtr, uint16* LucExpLenBytePtr);


extern Std_ReturnType Eth_Transmit(
    uint8 CtrlIdx,
    uint8 BufIdx,
    Eth_FrameType FrameType,
    boolean TxConfirmation,
    uint16 LenByte,
    uint8* PhysAddrPtr
);

extern boolean TestEth_Transmit  (App_DataValidateType LddDataValidate,
   uint8 LucExpCtrlIdx,uint8 LucExpBufIdx,Eth_FrameType LddExpFrameType,
  boolean LucExpTxConfirmation, uint16  LucExpLenByte,
  uint8* LucExpPhysAddrPtr,uint8 LucArrayIndex);

  extern  void Eth_GetPhysAddr(
    uint8 CtrlIdx,
    uint8* PhysAddrPtr);
    
  extern boolean TestEth_GetPhysAddr(App_DataValidateType LddDataValidate,
  uint8 LucExpCtrphylIdx,uint8* LucExpPhysAddr1Ptr);
    
  extern void Eth_Receive( uint8 CtrlIdx, Eth_RxStatusType* RxStatusPtr);
    
  extern boolean TestEth_Receive(App_DataValidateType LddDataValidate,
  uint8* LucExpController, Eth_RxStatusType* LddExpMode);
    
  extern Std_ReturnType Eth_TxConfirmation( uint8 CtrlIdx);
    
  extern boolean TestEth_TxConfirmation(App_DataValidateType LddDataValidate,
  uint8* LucExpController);
  
  #endif /* ETH_H */
    

   
