/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Eth.c                                                         **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR ETH Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Eth stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     22-Jun-2011   BJV    Initial version                             **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Eth.h" 

#ifdef ETHIF_MODULE_ACTIVE  

#include "App_EthIf_Common_Defs_Defs.h"  
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_GucController;
uint8 Eth_GucCfgIdx;
uint8 Eth_GucControllerintCount3;
Std_ReturnType Eth_GdControllerintRetVal;

#endif


/*******************************************************************************
**                     Eth_ControllerInit()                                **
*******************************************************************************/
#ifdef ETHIF_MODULE_ACTIVE  
Std_ReturnType Eth_ControllerInit( uint8 CtrlIdx, uint8 CfgIdx )
{
  /* Load actual Controller and Transition into Global variables */
  Eth_GucController = CtrlIdx;
  Eth_GucCfgIdx = CfgIdx;
  Eth_GucControllerintCount3++;

  return(Eth_GdControllerintRetVal);
} /* End Eth_ControllerInit() */
/*******************************************************************************/

boolean TestEth_ControllerInit(App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,uint8 LucExpCfgIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
{


  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_GucControllerintCount3 > 0x00) &&
        (Eth_GucController == LucExpCtrlIdx) &&
        (Eth_GucCfgIdx == LucExpCfgIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_GucControllerintCount3 = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_GucControllerintCount3 == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_GucControllerintCount3 = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}
}
/*******************************************************************************
**            END OF Eth_ControllerInit()                                     **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_GucGetCtrlModeCount;
uint8 Eth_GucGetController;
Eth_ModeType Eth_GddMode;
Std_ReturnType Eth_GetCtrlModeRetVal;

/*******************************************************************************
**                    EthIf_GetControllerMode()                               **
*******************************************************************************/
Std_ReturnType Eth_GetControllerMode( uint8 CtrlIdx, Eth_ModeType* CtrlModePtr)
{
/* Load actual Controller and Transition into Global variables */
Eth_GucGetController = CtrlIdx;
*CtrlModePtr = ETH_MODE_ACTIVE ;
Eth_GddMode = *CtrlModePtr;
Eth_GucGetCtrlModeCount++;
return(Eth_GetCtrlModeRetVal);
}
/* End Eth_GetCtrlModeRetVal */
/*******************************************************************************
**                     TestEthIf_GetControllerMode()                            **
*******************************************************************************/

boolean TestEth_GetControllerMode(App_DataValidateType LddDataValidate,
  uint8 LucExpController, Eth_ModeType* LddExpMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_GucGetCtrlModeCount > 0x00) &&
        (Eth_GucGetController == LucExpController) &&
        (Eth_GddMode == *LddExpMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_GucGetCtrlModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_GucGetCtrlModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_GucGetCtrlModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End Test EthIf_GetControllerMode() */
/*******************************************************************************
**            END OF EthIf_GetControllerMode()                                **
*******************************************************************************/
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_GucCtrlptbIdx;
uint8  Eth_GucBufptbIdxPtr;
uint8  *Eth_GucBufptbIdxPtr1;
uint8 Eth_GucBuffer[100];
uint8 *Eth_GucBufPtr;
uint8 **Eth_GucBufPtr1;
uint16 *Eth_GucLenBytePtr;
uint8 Eth_GucPrvdTxBufCount;
Std_ReturnType Eth_GdPrvdTxBufRetVal;

/*******************************************************************************
**                        Eth_ProvideTxBuffer()                             **
*******************************************************************************/
    
BufReq_ReturnType Eth_ProvideTxBuffer(
    uint8 CtrlIdx,
    uint8* BufIdxPtr,
    uint8** BufPtr,
    uint16* LenBytePtr)
{
  Eth_GucBufptbIdxPtr = 0x10;
  /* Load actual Controller and Transition into Global variables */
  Eth_GucCtrlptbIdx = CtrlIdx;
  BufIdxPtr = &Eth_GucBufptbIdxPtr ;
  Eth_GucBufptbIdxPtr1 = &Eth_GucBufptbIdxPtr ;
  Eth_GucBufPtr = &Eth_GucBuffer[*BufIdxPtr] ;
  *BufPtr = Eth_GucBufPtr;
  // Eth_GucBufPtr1 = &Eth_GucBufPtr;
  Eth_GucLenBytePtr = *LenBytePtr;
  Eth_GucPrvdTxBufCount++;

  return(Eth_GdPrvdTxBufRetVal);
} /* End Eth_GucTrasRceModeCount */
/*******************************************************************************/

boolean TestEth_ProvideTxBuffer(App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,uint8* LucExpBufIdxPtr,
  uint8** LucExpBufPtr, uint16* LucExpLenBytePtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_GucPrvdTxBufCount > 0x00) &&
        (Eth_GucCtrlptbIdx == LucExpCtrlIdx) &&(*Eth_GucBufptbIdxPtr1 == *LucExpBufIdxPtr)
        &&(Eth_GucBufPtr1 == *LucExpBufPtr)
        &&(Eth_GucLenBytePtr == *LucExpLenBytePtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_GucPrvdTxBufCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_GucPrvdTxBufCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_GucPrvdTxBufCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}
/*******************************************************************************
**           END OF  EthIf_ProvideTxBuffer()                                  **
*******************************************************************************/
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_GucSetCtrlModeCount;
uint8 Eth_GucSetController;
Eth_ModeType Eth_GddMode;
Std_ReturnType Eth_GdSetCtrlModeRetVal;
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
**                     Eth_SetControllerMode()                                **
*******************************************************************************/
Std_ReturnType Eth_SetControllerMode( uint8 CtrlIdx, Eth_ModeType CtrlMode )
{
  /* Load actual Controller and Transition into Global variables */
  Eth_GucSetController = CtrlIdx;
  Eth_GddMode = CtrlMode;
  Eth_GucSetCtrlModeCount++;

  return(Eth_GdSetCtrlModeRetVal);
} /* End Eth_SetControllerMode() */

/*******************************************************************************
**                     TestEth_SetControllerMode()                            **
*******************************************************************************/
boolean TestEth_SetControllerMode(App_DataValidateType LddDataValidate,
  uint8 LucExpController, Eth_ModeType LddExpMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_GucSetCtrlModeCount > 0x00) &&
        (Eth_GucSetController == LucExpController) &&
        (Eth_GddMode == LddExpMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_GucSetCtrlModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_GucSetCtrlModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_GucSetCtrlModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCan_SetControllerMode() */

/*******************************************************************************
**             END OF Eth_SetControllerMode()                                 **
*******************************************************************************/
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_GucCtrlIdx;
Eth_FrameType Eth_GucFrameType;
uint8 Eth_GucBufIdx;
uint16 Eth_GucLenByte;
boolean Eth_GucTxConfirmation;
uint8*  Eth_GucPhysAddrPtr;
uint8 Eth_GucTransmitCount;
Std_ReturnType Eth_GdTransmitRetVal;

/*******************************************************************************
**                  EthIf_Transmit()                             **
*******************************************************************************/

Std_ReturnType Eth_Transmit(
    uint8 CtrlIdx,
    uint8 BufIdx,
    Eth_FrameType FrameType,
    boolean TxConfirmation,
    uint16 LenByte,
    uint8* PhysAddrPtr
)

{
  /* Load actual Controller and Transition into Global variables */
   Eth_GucCtrlIdx = CtrlIdx;
   Eth_GucFrameType=FrameType;
   Eth_GucBufIdx =BufIdx;
   Eth_GucTxConfirmation=TxConfirmation;
   Eth_GucLenByte=LenByte;
   Eth_GucTransmitCount++;
  Eth_GucPhysAddrPtr=PhysAddrPtr;
  return(Eth_GdTransmitRetVal);
} /* End EthIf_Transmit()  */
/*******************************************************************************/

boolean TestEth_Transmit  (App_DataValidateType LddDataValidate,
   uint8 LucExpCtrlIdx,uint8 LucExpBufIdx,Eth_FrameType LddExpFrameType,
  boolean LucExpTxConfirmation, uint16  LucExpLenByte,
  uint8* LucExpPhysAddrPtr,uint8 LucArrayIndex)
{
  boolean LblStepResult;
  boolean Lblcheck = 0x00;
  uint8 i,j;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_GucTransmitCount > 0x00) &&
        (Eth_GucCtrlIdx == LucExpCtrlIdx) &&
        (Eth_GucFrameType == LddExpFrameType)&&
        (Eth_GucTxConfirmation == LucExpTxConfirmation)&&
        (Eth_GucPhysAddrPtr == LucExpPhysAddrPtr)
        &&(Eth_GucLenByte == LucExpLenByte))
      {
        for(i=LucExpBufIdx,j=LucArrayIndex;j< (LucArrayIndex+LucExpLenByte);i++,j++)
        {
          if((Eth_GucBuffer[i] == App_EthIf_GaaDataArray[j])&&(Lblcheck == 0x00))
          {
            LblStepResult = STEP_PASSED;
          }
          else
          {
            Lblcheck =  0x01;
            LblStepResult = STEP_FAILED;
          }
        }
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_GucTransmitCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_GucTransmitCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_GucTransmitCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}
/*******************************************************************************
**             END OF  EthIf_Transmit()                                  **
*******************************************************************************/
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8  Eth_GucGetPhysModeCount;
uint8  Eth_GucGetphyController;
uint8* Eth_GddPhysMode;




/*******************************************************************************
**                  EthIf_GetPhysAddr()                                       **
*******************************************************************************/

void Eth_GetPhysAddr(
    uint8 CtrlIdx,
    uint8* PhysAddrPtr
)
{
  /* Load actual Controller and Transition into Global variables */
 Eth_GucGetphyController = CtrlIdx;
 Eth_GddPhysMode=PhysAddrPtr;
 Eth_GucGetPhysModeCount++;

} /* End EthIf_Transmit()  */
/*******************************************************************************/

boolean TestEth_GetPhysAddr(App_DataValidateType LddDataValidate,
  uint8 LucExpCtrphylIdx,uint8*  LucExpPhysAddr1Ptr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_GucGetPhysModeCount > 0x00) &&
        (Eth_GucGetphyController == LucExpCtrphylIdx) &&
        (Eth_GddPhysMode == LucExpPhysAddr1Ptr))
        
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_GucGetPhysModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_GucGetPhysModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_GucGetPhysModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_GucRxCount;
uint8 Eth_GucRxCheckCount;
uint8 Eth_GucRxController[4];
Eth_RxStatusType Eth_GddRxMode[4];

/*******************************************************************************
**                    Eth_Receive()                                           **
*******************************************************************************/
void Eth_Receive( uint8 CtrlIdx, Eth_RxStatusType* RxStatusPtr)
{
  /* Load actual Controller and Transition into Global variables */
  if(0x02 <= Eth_GucRxCount)
  {
    *RxStatusPtr = ETH_RECEIVED ;
  }
  else
  {
    *RxStatusPtr = ETH_RECEIVED_MORE_DATA_AVAILABLE ;
  }
  Eth_GucRxController[Eth_GucRxCount] = CtrlIdx;
  Eth_GddRxMode[Eth_GucRxCount] = *RxStatusPtr;
  Eth_GucRxCount++;

}
/* End Eth_Receive */

/*******************************************************************************
**                     TestEth_Receive()                                      **
*******************************************************************************/

boolean TestEth_Receive(App_DataValidateType LddDataValidate,
  uint8* LucExpController, Eth_RxStatusType* LddExpMode)
{
  boolean LblStepResult;
  uint8 lucCheck;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  lucCheck = 0x00;
  
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_GucRxCount > 0x00) &&
        (Eth_GucRxController[0] == *LucExpController) &&
        (Eth_GddRxMode[0] == *LddExpMode))
      {
        LblStepResult = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Eth_GucRxCount = 0;
      break;
    } /* End case S_VALIDATE: */
   
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Eth_GucRxCount; LucIndex++)
      {
        /* Validate Network and CurrentState */
        if((Eth_GucRxController[LucIndex] == *LucExpController) &&
          (Eth_GddRxMode[LucIndex] == *LddExpMode)&&(lucCheck == 0x00))
        {
          LblStepResult = STEP_PASSED;          
        }
        else
        {
          lucCheck = 0x01;
        }
        LucExpController++;
        LddExpMode++;
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Eth_GucRxCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Eth_GucRxCheckCount == Eth_GucRxCount)
      {
        Eth_GucRxCount = 0;
        Eth_GucRxCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_GucRxCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_GucRxCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End Test EthIf_GetControllerMode() */


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_GucTxConfCount;
uint8 Eth_GucTxConfCheckCount;
uint8 Eth_GucTxConfCtrlIdx[50];
Std_ReturnType Eth_TxConfRetVal;

/*******************************************************************************
**                    Eth_Receive()                                           **
*******************************************************************************/
Std_ReturnType Eth_TxConfirmation( uint8 CtrlIdx)
{
/* Load actual Controller and Transition into Global variables */

Eth_GucTxConfCtrlIdx[Eth_GucTxConfCount] = CtrlIdx;
Eth_GucTxConfCount++;
return(Eth_TxConfRetVal);
}
/* End Eth_Receive */
/*******************************************************************************
**                     TestEth_TxConfirmation()                               **
*******************************************************************************/

boolean TestEth_TxConfirmation(App_DataValidateType LddDataValidate,
  uint8* LucExpController)
{
  boolean LblStepResult;
  uint8 lucCheck;
  uint8 LucIndex;
  
  LblStepResult = STEP_FAILED;
  lucCheck = 0x00;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_GucTxConfCount > 0x00) &&
        (Eth_GucTxConfCtrlIdx[0] == LucExpController) )
      {
        LblStepResult = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Eth_GucTxConfCount = 0;
      break;
    } /* End case S_VALIDATE: */
   
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Eth_GucTxConfCount; LucIndex++)
      {
        /* Validate Network and CurrentState */
        if((Eth_GucTxConfCtrlIdx[LucIndex] == *LucExpController)&&(0x00 == lucCheck))
        {
          LblStepResult = STEP_PASSED;          
        }
         else
        {
          lucCheck = 0x01;
        }
        LucExpController++;
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Eth_GucTxConfCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Eth_GucTxConfCount == Eth_GucTxConfCheckCount)
      {
        Eth_GucTxConfCheckCount = 0;
        Eth_GucTxConfCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_GucTxConfCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_GucTxConfCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End Test EthIf_GetControllerMode() */
#endif
/*******************************************************************************
**             END OF   EthIf_GetPhysAddr()                                   **
*******************************************************************************/
