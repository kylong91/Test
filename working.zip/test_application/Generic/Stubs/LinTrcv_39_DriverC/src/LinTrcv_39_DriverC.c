/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE:  LinTrcv.c                                                    **
**                                                                            **
**  TARGET    :  ALL                                                          **
**                                                                            **
**  PRODUCT   : AUTOSAR LIN Transceiver Module                                **
**                                                                            **
**  PURPOSE   : This file is a stub for LIN Transceiver Driver Component      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     03-Jan-2012    NKD    Creation of LinTrcv_39_DriverC.c module    **
*******************************************************************************/

/******************************************************************************
**                      Include Section                                      **
******************************************************************************/
#include "LinTrcv_39_DriverC.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/* Variables used for LinIf module  */
Std_ReturnType LinTrcvC_GaaSetOpModeRet[LINTRCV_39_DRIVERC_ARRAY_SIZE];
Std_ReturnType LinTrcvC_GaaGetOpModeRet[LINTRCV_39_DRIVERC_ARRAY_SIZE];

Std_ReturnType LinTrcvC_GaasetWakeupModeRet[LINTRCV_39_DRIVERC_ARRAY_SIZE];
Std_ReturnType LinTrcvC_GaaGetCheckWakeupRet[LINTRCV_39_DRIVERC_ARRAY_SIZE];

Std_ReturnType LinTrcvC_GaaGetBusWuReasonRet[LINTRCV_39_DRIVERC_ARRAY_SIZE];
uint8 LinTrcvC_GucSetOpModeCount;
uint8 LinTrcvC_GucGetOpModeCount;

uint8 LinTrcvC_GucCheckWakeupCount;
uint8 LinTrcvC_GucCheckWakeupCheckCount;
uint8 LinTrcvC_GucSetWakeupModeCount;
uint8 LinTrcvC_GucSetWakeupModeCheckCount;

uint8 LinTrcvC_GucGetBusWuReasonCount;
uint8 LinTrcvC_GucSetOpModeCheckCount;
uint8 LinTrcvC_GucGetOpModeCheckCount;
uint8 LinTrcvC_GucGetBusWuReasChkCount;
uint8 LinTrcvC_GaaSetOpModeNw[LINTRCV_39_DRIVERC_ARRAY_SIZE];
uint8 LinTrcvC_GaaGetOpModeNw[LINTRCV_39_DRIVERC_ARRAY_SIZE];

uint8 LinTrcvC_GaaCheckWakeupNw[LINTRCV_39_DRIVERC_ARRAY_SIZE];
LinTrcv_TrcvWakeupModeType LinTrcvC_GaaSetWakeupMode[LINTRCV_39_DRIVERC_ARRAY_SIZE];
LinTrcv_TrcvWakeupModeType LinTrcvC_GaaSetWakeupModeNw[LINTRCV_39_DRIVERC_ARRAY_SIZE];

uint8 LinTrcvC_GaaGetBusWuReasonNw[LINTRCV_39_DRIVERC_ARRAY_SIZE];
LinTrcv_TrcvModeType LinTrcvC_GaaSetOpMode[LINTRCV_39_DRIVERC_ARRAY_SIZE];
LinTrcv_TrcvModeType LinTrcvC_GaaGetOpMode[LINTRCV_39_DRIVERC_ARRAY_SIZE];
LinTrcv_TrcvWakeupReasonType LinTrcvC_GaaGetBusWuReason[LINTRCV_39_DRIVERC_ARRAY_SIZE];
/* Variables used for LinIf module  */
/*******************************************************************************
**                       TestLinTrcv_39_DriverCDefaultBehavior()              **
*******************************************************************************/
void TestLinTrcv_39_DriverCDefaultBehavior(void)
{
  uint8 LucCount;  
  
  for(LucCount = 0x00; LucCount < LINTRCV_39_DRIVERC_ARRAY_SIZE; LucCount++)
  {
    LinTrcvC_GaaSetOpModeRet[LucCount] = E_OK;
    LinTrcvC_GaaGetOpModeRet[LucCount] = E_OK;
    LinTrcvC_GaaGetBusWuReasonRet[LucCount] = E_OK;
    
    LinTrcvC_GaasetWakeupModeRet[LucCount] = E_OK;
    LinTrcvC_GaaGetCheckWakeupRet[LucCount] = E_OK;
  }
  LinTrcvC_GucSetOpModeCount = 0x00;
  LinTrcvC_GucGetOpModeCount = 0x00;
  
  LinTrcvC_GucCheckWakeupCount = 0x00;
  LinTrcvC_GucSetWakeupModeCount = 0x00;
  LinTrcvC_GucSetWakeupModeCheckCount = 0x00;
  LinTrcvC_GucCheckWakeupCheckCount = 0x00;
  
  LinTrcvC_GucGetBusWuReasonCount = 0x00;
  LinTrcvC_GucSetOpModeCheckCount = 0x00;
  LinTrcvC_GucGetOpModeCheckCount = 0x00;
  LinTrcvC_GucGetBusWuReasChkCount = 0x00;  
} /* End TestLinTrcv_39_DriverCDefaultBehavior() */

/*******************************************************************************
**                       LinTrcv_39_DriverC_CheckWakeup()                     **
*******************************************************************************/
Std_ReturnType LinTrcv_39_DriverC_CheckWakeup(uint8 LinNetwork )
{
  #ifndef TYPICAL_CONFIG
  LinTrcvC_GaaCheckWakeupNw[LinTrcvC_GucCheckWakeupCount] = LinNetwork;
  /* Increment count variable to handle multiple invocations */
  if(LinTrcvC_GucCheckWakeupCount != LINTRCV_39_DRIVERC_ARRAY_SIZE)
  {    
    LinTrcvC_GucCheckWakeupCount++;
  } 
  return(LinTrcvC_GaaGetCheckWakeupRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcv_39_DriverA_CheckWakeup() */

/*******************************************************************************
**                       TestLinTrcv_39_DriverC_CheckWakeup()                 **
*******************************************************************************/
boolean TestLinTrcv_39_DriverC_CheckWakeup(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcvC_GucCheckWakeupCount == 0x01) && 
        (ExpLinNetwork == LinTrcvC_GaaCheckWakeupNw[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcvC_GucCheckWakeupCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcvC_GucCheckWakeupCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcvC_GucCheckWakeupCheckCount <= LinTrcvC_GucCheckWakeupCount) &&
        (ExpLinNetwork == LinTrcvC_GaaCheckWakeupNw[LinTrcvC_GucCheckWakeupCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcvC_GucCheckWakeupCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcvC_GucCheckWakeupCheckCount == LinTrcvC_GucCheckWakeupCount)
      {
        LinTrcvC_GucCheckWakeupCount = 0;
        LinTrcvC_GucCheckWakeupCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcvC_GucCheckWakeupCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcvC_GaaCheckWakeupNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcv_CheckWakeup() */

/*******************************************************************************
**                       LinTrcv_39_DriverC_SetWakeupMode()                   **
*******************************************************************************/
Std_ReturnType LinTrcv_39_DriverC_SetWakeupMode ( uint8 LinNetwork, 
LinTrcv_TrcvWakeupModeType TrcvWakupMode)
{
  #ifndef TYPICAL_CONFIG
  LinTrcvC_GaaSetWakeupModeNw[LinTrcvC_GucSetWakeupModeCount] = LinNetwork;
  LinTrcvC_GaaSetWakeupMode[LinTrcvC_GucSetWakeupModeCount] = TrcvWakupMode;  
  /* Increment count variable to handle multiple invocations */
  if(LinTrcvC_GucSetWakeupModeCount != LINTRCV_39_DRIVERC_ARRAY_SIZE)
  {    
    LinTrcvC_GucSetWakeupModeCount++;
  } 
  return(LinTrcvC_GaasetWakeupModeRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcvC_SetOpMode() */
/*******************************************************************************
**                       TestLinTrcv_39_DriverC_SetWakeupMode()               **
*******************************************************************************/
Std_ReturnType TestLinTrcv_39_DriverC_SetWakeupMode
  (App_DataValidateType LucDataValidate,
  uint8 ExpLinNetwork, LinTrcv_TrcvWakeupModeType ExpOpMode)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcvC_GucSetWakeupModeCount == 0x01) && 
        (ExpLinNetwork == LinTrcvC_GaaSetWakeupModeNw[0]) && 
        (ExpOpMode == LinTrcvC_GaaSetWakeupMode[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcvC_GucSetWakeupModeCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcvC_GucSetWakeupModeCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcvC_GucSetWakeupModeCheckCount <= LinTrcvC_GucSetWakeupModeCount) &&
        (ExpLinNetwork == LinTrcvC_GaaSetWakeupModeNw[LinTrcvC_GucSetWakeupModeCheckCount]) && 
        (ExpOpMode == 
        LinTrcvC_GaaSetWakeupMode[LinTrcvC_GucSetWakeupModeCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcvC_GucSetWakeupModeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcvC_GucSetWakeupModeCheckCount == LinTrcvC_GucSetWakeupModeCount)
      {
        LinTrcvC_GucSetWakeupModeCount = 0;
        LinTrcvC_GucSetWakeupModeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcvC_GucSetWakeupModeCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcvC_GaaSetWakeupModeNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcvC_SetWakeupMode() */


/*******************************************************************************
**                       LinTrcv_39_DriverCSetOpMode()                        **
*******************************************************************************/
Std_ReturnType LinTrcv_39_DriverC_SetOpMode(uint8 LinNetwork, 
  LinTrcv_TrcvModeType OpMode)
{
  #ifndef TYPICAL_CONFIG
  LinTrcvC_GaaSetOpModeNw[LinTrcvC_GucSetOpModeCount] = LinNetwork;
  LinTrcvC_GaaSetOpMode[LinTrcvC_GucSetOpModeCount] = OpMode;  
  /* Increment count variable to handle multiple invocations */
  if(LinTrcvC_GucSetOpModeCount != LINTRCV_39_DRIVERC_ARRAY_SIZE)
  {    
    LinTrcvC_GucSetOpModeCount++;
  } 
  return(LinTrcvC_GaaSetOpModeRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcvC_39_DriverCSetOpMode() */

/*******************************************************************************
**                       TestLinTrcv_39_DriverCSetOpMode()                    **
*******************************************************************************/
boolean TestLinTrcv_39_DriverCSetOpMode(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork, LinTrcv_TrcvModeType ExpOpMode)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcvC_GucSetOpModeCount == 0x01) && 
        (ExpLinNetwork == LinTrcvC_GaaSetOpModeNw[0]) && 
        (ExpOpMode == LinTrcvC_GaaSetOpMode[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcvC_GucSetOpModeCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcvC_GucSetOpModeCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcvC_GucSetOpModeCheckCount <= LinTrcvC_GucSetOpModeCount) &&
        (ExpLinNetwork == LinTrcvC_GaaSetOpModeNw[LinTrcvC_GucSetOpModeCheckCount]) && 
        (ExpOpMode == 
        LinTrcvC_GaaSetOpMode[LinTrcvC_GucSetOpModeCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcvC_GucSetOpModeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcvC_GucSetOpModeCheckCount == LinTrcvC_GucSetOpModeCount)
      {
        LinTrcvC_GucSetOpModeCount = 0;
        LinTrcvC_GucSetOpModeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcvC_GucSetOpModeCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcvC_GaaSetOpModeNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcvC_39_DriverCSetOpMode() */

/*******************************************************************************
**                       TestSetLinTrcv_39_DriverCSetOpModeRetVal()           **
*******************************************************************************/
void TestSetLinTrcv_39_DriverCSetOpModeRetVal(uint8 LinNetwork, 
  Std_ReturnType RetVal)
{
  LinTrcvC_GaaSetOpModeRet[LinNetwork] = RetVal;
} /* End TestSetLinTrcv_39_DriverCSetOpModeRetVal()  */

/*******************************************************************************
**                       LinTrcv_39_DriverCGetOpMode()                        **
*******************************************************************************/
Std_ReturnType LinTrcv_39_DriverC_GetOpMode(uint8 LinNetwork, 
  LinTrcv_TrcvModeType* OpMode)
{
  #ifndef TYPICAL_CONFIG
  LinTrcvC_GaaGetOpModeNw[LinTrcvC_GucGetOpModeCount] = LinNetwork;
  *OpMode = LinTrcvC_GaaGetOpMode[LinNetwork];  
  /* Increment count variable to handle multiple invocations */
  if(LinTrcvC_GucGetOpModeCount != LINTRCV_39_DRIVERC_ARRAY_SIZE)
  {    
    LinTrcvC_GucGetOpModeCount++;
  } 
  return(LinTrcvC_GaaGetOpModeRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcv_39_DriverCGetOpMode() */

/*******************************************************************************
**                       TestLinTrcv_39_DriverCGetOpMode()                    **
*******************************************************************************/
boolean TestLinTrcv_39_DriverCGetOpMode(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcvC_GucGetOpModeCount == 0x01) && 
        (ExpLinNetwork == LinTrcvC_GaaGetOpModeNw[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcvC_GucGetOpModeCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcvC_GucGetOpModeCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcvC_GucGetOpModeCheckCount <= LinTrcvC_GucGetOpModeCount) &&
        (ExpLinNetwork == LinTrcvC_GaaGetOpModeNw[LinTrcvC_GucGetOpModeCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcvC_GucGetOpModeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcvC_GucGetOpModeCheckCount == LinTrcvC_GucGetOpModeCount)
      {
        LinTrcvC_GucGetOpModeCount = 0;
        LinTrcvC_GucGetOpModeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcvC_GucGetOpModeCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcvC_GaaGetOpModeNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcvC_39_DriverCGetOpMode() */

/*******************************************************************************
**                       TestSetLinTrcv_39_DriverCGetOpModeRetVal()           **
*******************************************************************************/
void TestSetLinTrcv_39_DriverCGetOpModeRetVal(uint8 SetLinNetwork, 
  LinTrcv_TrcvModeType SetOpMode, Std_ReturnType RetVal)
{
  LinTrcvC_GaaGetOpMode[SetLinNetwork] = SetOpMode;
  LinTrcvC_GaaGetOpModeRet[SetLinNetwork] = RetVal;  
} /* End TestSetLinTrcvC_39_DriverCGetOpModeRetVal()  */
/*******************************************************************************
**                       LinTrcv_39_DriverCGetBusWuReason()                   **
*******************************************************************************/
Std_ReturnType LinTrcv_39_DriverC_GetBusWuReason(uint8 LinNetwork, 
  LinTrcv_TrcvWakeupReasonType* Reason)
{
  #ifndef TYPICAL_CONFIG  
  LinTrcvC_GaaGetBusWuReasonNw[LinTrcvC_GucGetBusWuReasonCount] = LinNetwork;
  *Reason = LinTrcvC_GaaGetBusWuReason[LinNetwork];  
  /* Increment count variable to handle multiple invocations */
  if(LinTrcvC_GucGetBusWuReasonCount != LINTRCV_39_DRIVERC_ARRAY_SIZE)
  {    
    LinTrcvC_GucGetBusWuReasonCount++;
  } 
  return(LinTrcvC_GaaGetBusWuReasonRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcv_39_DriverCGetBusWuReason() */

/*******************************************************************************
**                            TestLinTrcv_39_DriverCGetBusWuReason()          **
*******************************************************************************/
boolean TestLinTrcv_39_DriverCGetBusWuReason(App_DataValidateType LucDataValidate,
  uint8 ExpLinNetwork)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcvC_GucGetBusWuReasonCount == 0x01) && 
        (ExpLinNetwork == LinTrcvC_GaaGetBusWuReasonNw[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcvC_GucGetBusWuReasonCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcvC_GucGetBusWuReasonCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcvC_GucGetBusWuReasChkCount <= LinTrcvC_GucGetBusWuReasonCount) &&
        (ExpLinNetwork == 
          LinTrcvC_GaaGetBusWuReasonNw[LinTrcvC_GucGetBusWuReasChkCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcvC_GucGetBusWuReasChkCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcvC_GucGetBusWuReasChkCount == LinTrcvC_GucGetBusWuReasonCount)
      {
        LinTrcvC_GucGetBusWuReasonCount = 0;
        LinTrcvC_GucGetBusWuReasChkCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcvC_GucGetBusWuReasonCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcvC_GaaGetBusWuReasonNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcvC_39_DriverCGetBusWuReason() */

/*******************************************************************************
**                       TestSetLinTrcv_39_DriverCGetBusWuReasonRetVal()      **
*******************************************************************************/
void TestSetLinTrcv_39_DriverCGetBusWuReasonRetVal(uint8 SetLinNetwork, 
  LinTrcv_TrcvWakeupReasonType SetReason, Std_ReturnType RetVal)
{
  LinTrcvC_GaaGetBusWuReason[SetLinNetwork] = SetReason;
  LinTrcvC_GaaGetBusWuReasonRet[SetLinNetwork] = RetVal;  
} /* End TestSetLinTrcv_39_DriverCGetBusWuReasonRetVal()  */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
