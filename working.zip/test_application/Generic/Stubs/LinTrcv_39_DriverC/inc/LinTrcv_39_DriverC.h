/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE:  LinTrcv_39_DriverC.h                                         **
**                                                                            **
**  TARGET    :  ALL                                                          **
**                                                                            **
**  PRODUCT   : AUTOSAR LIN Transceiver Module                                **
**                                                                            **
**  PURPOSE   : Provision of Macros, extern declaration of APIs               **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     03-Jan-2012    NKD    Creation of LinTrcv_39_DriverC.h module    **
*******************************************************************************/

#ifndef LINTRCV_39_DRIVERC_H
#define LINTRCV_39_DRIVERC_H

/*******************************************************************************
**                      Include Section                                      **
*******************************************************************************/
#include "TC_Generic.h"
#include "Lin_GeneralTypes.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define LINTRCV_39_DRIVERC_AR_RELEASE_MAJOR_VERSION         0x04
#define LINTRCV_39_DRIVERC_AR_RELEASE_MINOR_VERSION         0x00
#define LINTRCV_39_DRIVERC_AR_RELEASE_REVISION_VERSION      0x02

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define LINTRCV_DATA_LENGTH                      0x08
/* Channel value should be less than LIN_ARRAY_SIZE */
#define LINTRCV_39_DRIVERC_ARRAY_SIZE                       0x04 

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void TestLinTrcv_39_DriverCDefaultBehavior(void);

extern Std_ReturnType LinTrcv_39_DriverC_SetWakeupMode(uint8 LinNetwork, 
  LinTrcv_TrcvWakeupModeType TrcvWakupMode);
  
extern Std_ReturnType TestLinTrcv_39_DriverC_SetWakeupMode(
  App_DataValidateType LucDataValidate, uint8 LinNetwork, 
  LinTrcv_TrcvWakeupModeType TrcvWakupMode);

extern  Std_ReturnType TestLinTrcv_39_DriverC_CheckWakeup(
  App_DataValidateType LucDataValidate, uint8 LinNetwork );

extern  Std_ReturnType LinTrcv_39_DriverC_CheckWakeup( uint8 LinNetwork );

extern Std_ReturnType LinTrcv_39_DriverC_SetOpMode(uint8 LinNetwork, 
  LinTrcv_TrcvModeType OpMode);
extern boolean TestLinTrcv_39_DriverCSetOpMode(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork, LinTrcv_TrcvModeType ExpOpMode);
extern void TestSetLinTrcv_39_DriverCSetOpModeRetVal(uint8 LinNetwork, 
  Std_ReturnType RetVal);
extern Std_ReturnType LinTrcv_39_DriverC_GetOpMode(uint8 LinNetwork, 
  LinTrcv_TrcvModeType* OpMode);
extern boolean TestLinTrcv_39_DriverCGetOpMode(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork);
extern void TestSetLinTrcv_39_DriverCGetOpModeRetVal(uint8 SetLinNetwork, 
  LinTrcv_TrcvModeType SetOpMode, Std_ReturnType RetVal);
extern Std_ReturnType LinTrcv_39_DriverC_GetBusWuReason(uint8 LinNetwork, 
  LinTrcv_TrcvWakeupReasonType* Reason);
extern boolean TestLinTrcv_39_DriverCGetBusWuReason(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork);
extern void TestSetLinTrcv_39_DriverCGetBusWuReasonRetVal(uint8 SetLinNetwork, 
  LinTrcv_TrcvWakeupReasonType SetReason, Std_ReturnType RetVal);
  
#endif  /* LINTRCV_39_DRIVERC_H */

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
