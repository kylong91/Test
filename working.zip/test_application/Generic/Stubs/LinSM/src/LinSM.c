/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: LinSM.c                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR LIN State Manager Module                              **
**                                                                            **
**  PURPOSE   : Declaration of Can functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0    30-Aug-2012   Ravi Tiwari    Initial version                      **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "LinSM.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
NetworkHandleType LinSM_Gddnetwork;

#ifdef COMM_MODULE_ACTIVE
uint8 LinSM_GucRequestComModeCount;
uint8 LinSM_GucGetCurrentComModeCount;
ComM_ModeType LinSM_Gddmode;
ComM_ModeType LinSM_GddGetCurComM_Mode;
Std_ReturnType LinSM_GddGetCurrentRetVal;
Std_ReturnType LinSM_GddReqComRetVal;
#endif

#ifdef BSWM_MODULE_ACTIVE
uint8 LinSM_GucScheduleRequestCount;
LinIf_SchHandleType LinSM_Gddschedule;
Std_ReturnType LinSM_LddReturnVal;
uint8 LinSM_GucInitSeqCnt;
uint8 LinSM_GucInitCnt;
#endif

#ifdef LINIF_MODULE_ACTIVE
/* Variables used for LinIf module  */
NetworkHandleType LinSM_GddSchReqConfNw[LINSM_ARRAY_SIZE];
NetworkHandleType LinSM_GddGotoSleepConfNw[LINSM_ARRAY_SIZE];
NetworkHandleType LinSM_GddWakeUpConfNw[LINSM_ARRAY_SIZE];
LinIf_SchHandleType LinSM_GddSchReqConfSchedule[LINSM_ARRAY_SIZE];
boolean LinSM_GblGotoSleepConfSuccs[LINSM_ARRAY_SIZE];
boolean LinSM_GblWakeUpConfSuccs[LINSM_ARRAY_SIZE];
uint8 LinSM_GucSchReqConfCount;
uint8 LinSM_GucGotoSleepConfCount;
uint8 LinSM_GucWakeUpConfCount;
uint8 LinSM_GucSchReqConfCheckCount;
uint8 LinSM_GucGotoSleepConfCheckCount;
uint8 LinSM_GucWakeUpConfCheckCount;
/* Variables used for LinIf module  */
#endif
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
#ifdef COMM_MODULE_ACTIVE
/*******************************************************************************
**                       LinSM_RequestComMode()                               **
*******************************************************************************/
Std_ReturnType LinSM_RequestComMode
 (NetworkHandleType network,ComM_ModeType mode)
{
  #ifndef TYPICAL_CONFIG
  LinSM_GucRequestComModeCount++;
  LinSM_Gddnetwork = network;
	LinSM_Gddmode = mode;
  #endif
	return(LinSM_GddReqComRetVal);
}/* End LinSM_RequestComMode() */

/*******************************************************************************
**                       TestLinSM_RequestComMode()                           **
*******************************************************************************/
boolean TestLinSM_RequestComMode(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpnetwork, ComM_ModeType LddExpmode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((LinSM_GucRequestComModeCount == 0x01) && 
      (LinSM_Gddnetwork == LddExpnetwork) && (LinSM_Gddmode == LddExpmode))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      LinSM_GucRequestComModeCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestLinSM_RequestComMode() */

/*******************************************************************************
**                       LinSM_GetCurrentComMode()                            **
*******************************************************************************/
Std_ReturnType LinSM_GetCurrentComMode(NetworkHandleType network, 
  P2VAR(ComM_ModeType, AUTOMATIC, COMM_APPL_DATA)mode)  
{
  #ifndef TYPICAL_CONFIG
  LinSM_GucGetCurrentComModeCount++;
  LinSM_Gddnetwork = network;
	*mode = LinSM_GddGetCurComM_Mode;
  #endif
	return(LinSM_GddGetCurrentRetVal);
}/* End LinSM_GetCurrentComMode() */
/*******************************************************************************
**                       TestLinSM_GetCurrentComMode()                        **
*******************************************************************************/
boolean TestLinSM_GetCurrentComMode(App_DataValidateType LucDataValidate, 
  NetworkHandleType LddExpnetwork, 
  P2VAR(ComM_ModeType, AUTOMATIC, COMM_APPL_DATA) LddExpmode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((LinSM_GucGetCurrentComModeCount == 0x01) && 
      (LinSM_Gddnetwork == LddExpnetwork) && (LinSM_Gddmode == *LddExpmode))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      LinSM_GucGetCurrentComModeCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestLinSM_GetCurrentComMode() */

/*******************************************************************************
**                       TestLinSM_GetCurrentComModeSetMode()                 **
*******************************************************************************/
void TestLinSM_GetCurrentComModeSetMode(ComM_ModeType LddComMMode)
{
  LinSM_GddGetCurComM_Mode = LddComMMode;
}/* End TestLinSM_GetCurrentComModeSetMode() */

/*******************************************************************************
**                         TestLinSM_SetBehavior()                            **
*******************************************************************************/
void TestLinSM_RequestComModeSetBeh(Std_ReturnType LddReturnVal)
{
  LinSM_GucGetCurrentComModeCount = 0;
  LinSM_GucRequestComModeCount = 0;
  LinSM_GddReqComRetVal = LddReturnVal;
}

void TestLinSM_GetCurrentComModeSetBeh(Std_ReturnType LddReturnVal)
{
  LinSM_GucGetCurrentComModeCount = 0;
  LinSM_GucRequestComModeCount = 0;
  LinSM_GddGetCurrentRetVal = LddReturnVal;
}
#endif

#ifdef BSWM_MODULE_ACTIVE

/*******************************************************************************
**                          LinSM_Init()                                      **
*******************************************************************************/

void LinSM_Init(const LinSM_ConfigType* ConfigPtr)
{
  UNUSED(ConfigPtr);
	App_GucApiSeqCnt++;
	LinSM_GucInitSeqCnt = App_GucApiSeqCnt;
	LinSM_GucInitCnt++;
}/* End LinSM_Init() */

/*******************************************************************************
**                           TestLinSM_Init()                                   **
*******************************************************************************/
boolean TestLinSM_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(LinSM_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      LinSM_GucInitCnt = 0;
      LinSM_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(LinSM_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      LinSM_GucInitCnt = 0;
      LinSM_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLinSM_Init() */

/*******************************************************************************
**                       LinSM_ScheduleRequest()                              **
*******************************************************************************/
Std_ReturnType LinSM_ScheduleRequest( NetworkHandleType network, 
  LinIf_SchHandleType schedule)
{
  LinSM_GucScheduleRequestCount++;
  LinSM_Gddnetwork = network;
	LinSM_Gddschedule = schedule;
	
	return(LinSM_LddReturnVal);
}/* End LinSM_ScheduleRequest() */

/*******************************************************************************
**                   AppLinSM_SetBehaviorScheduleRequest                      **
*******************************************************************************/
void AppLinSM_SetBehaviorScheduleRequest(Std_ReturnType LddSetRetVal)
{	
  LinSM_LddReturnVal = LddSetRetVal;
}/* End LinSM_ScheduleRequest() */

/*******************************************************************************
**                       TestLinSM_ScheduleRequest()                          **
*******************************************************************************/
boolean TestLinSM_ScheduleRequest(App_DataValidateType LucDataValidate,
 NetworkHandleType LddExpnetwork, LinIf_SchHandleType LddExpschedule)
{
	
	boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((LinSM_GucScheduleRequestCount == 0x01) && 
      (LinSM_Gddnetwork == LddExpnetwork) && 
			(LinSM_Gddschedule == LddExpschedule))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      LinSM_GucScheduleRequestCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End LinSM_ScheduleRequest() */

/*******************************************************************************
**                         TestLinSM_SetBehavior()                         **
*******************************************************************************/
void TestLinSM_SetBeh(Std_ReturnType LddReturnVal)
{
  LinSM_GucScheduleRequestCount = 0;
  LinSM_LddReturnVal = LddReturnVal;
}
#endif

/*******************************************************************************
**                         TestLinSM_DefaultBehavior()                         **
*******************************************************************************/
void TestLinSM_DefaultBehavior(void)
{
  #ifdef COMM_MODULE_ACTIVE
  LinSM_GucGetCurrentComModeCount = 0;
  LinSM_GucRequestComModeCount = 0;
  LinSM_GddGetCurComM_Mode = COMM_NO_COMMUNICATION;
  LinSM_GddReqComRetVal = 0;
  LinSM_GddGetCurrentRetVal = 0;
  #endif
  #ifdef BSWM_MODULE_ACTIVE
  LinSM_GucScheduleRequestCount = 0;
  #endif
  #ifdef LINIF_MODULE_ACTIVE
  LinSM_GucSchReqConfCount = 0;
  LinSM_GucGotoSleepConfCount = 0;
  LinSM_GucWakeUpConfCount = 0;
  LinSM_GucSchReqConfCheckCount = 0;
  LinSM_GucGotoSleepConfCheckCount = 0;
  LinSM_GucWakeUpConfCheckCount = 0;
  #endif
}

#ifdef LINIF_MODULE_ACTIVE
/*******************************************************************************
**                       LinSM_ScheduleRequestConfirmation()                  **
*******************************************************************************/
void LinSM_ScheduleRequestConfirmation(NetworkHandleType network, 
  LinIf_SchHandleType schedule)
{
  #ifndef TYPICAL_CONFIG
  LinSM_GddSchReqConfNw[LinSM_GucSchReqConfCount] = network;
  LinSM_GddSchReqConfSchedule[LinSM_GucSchReqConfCount] = schedule;
  /* Increment count variable to handle multiple invocations */
  if(LinSM_GucSchReqConfCount != LINSM_ARRAY_SIZE)
  {    
    LinSM_GucSchReqConfCount++;
  }
  #endif
} /* End LinSM_ScheduleRequestConfirmation() */

/*******************************************************************************
**                       TestLinSM_ScheduleRequestConfirmation()              **
*******************************************************************************/
boolean TestLinSM_ScheduleRequestConfirmation(App_DataValidateType 
  LucDataValidate, NetworkHandleType Expnetwork, LinIf_SchHandleType 
  Expschedule)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinSM_GucSchReqConfCount == 0x01) && 
        (Expnetwork == LinSM_GddSchReqConfNw[0]) && 
        (Expschedule == LinSM_GddSchReqConfSchedule[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinSM_GucSchReqConfCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinSM_GucSchReqConfCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < LinSM_GucSchReqConfCount; LucIndex++)
      {
        /* Validate Channel and ComMMode */
        if((LinSM_GddSchReqConfNw[LucIndex] == Expnetwork) &&
          (LinSM_GddSchReqConfSchedule[LucIndex] == Expschedule))
        {
          LblRetValue = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = LinSM_GucSchReqConfCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinSM_GucSchReqConfCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinSM_GucSchReqConfCheckCount == LinSM_GucSchReqConfCount)
      {
        LinSM_GucSchReqConfCount = 0;
        LinSM_GucSchReqConfCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinSM_GucSchReqConfCheckCount <= LinSM_GucSchReqConfCount) &&
        (Expnetwork == LinSM_GddSchReqConfNw[LinSM_GucSchReqConfCheckCount]) && 
        (Expschedule == 
        LinSM_GddSchReqConfSchedule[LinSM_GucSchReqConfCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinSM_GucSchReqConfCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinSM_GucSchReqConfCheckCount == LinSM_GucSchReqConfCount)
      {
        LinSM_GucSchReqConfCount = 0;
        LinSM_GucSchReqConfCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinSM_GucSchReqConfCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(Expnetwork == LinSM_GddSchReqConfNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinSM_ScheduleRequestConfirmation() */

/*******************************************************************************
**                       LinSM_GotoSleepConfirmation()                        **
*******************************************************************************/
void LinSM_GotoSleepConfirmation(NetworkHandleType network, boolean success)
{
  #ifndef TYPICAL_CONFIG
  LinSM_GddGotoSleepConfNw[LinSM_GucGotoSleepConfCount] = network;
  LinSM_GblGotoSleepConfSuccs[LinSM_GucGotoSleepConfCount] = success;
  /* Increment count variable to handle multiple invocations */
  if(LinSM_GucGotoSleepConfCount != LINSM_ARRAY_SIZE)
  {    
    LinSM_GucGotoSleepConfCount++;
  }
  #endif
} /* End LinSM_GotoSleepConfirmation() */

/*******************************************************************************
**                       TestLinSM_GotoSleepConfirmation()                    **
*******************************************************************************/
boolean TestLinSM_GotoSleepConfirmation(App_DataValidateType 
  LucDataValidate, NetworkHandleType Expnetwork, boolean Expsuccess)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinSM_GucGotoSleepConfCount == 0x01) && 
        (Expnetwork == LinSM_GddGotoSleepConfNw[0]) && 
        (Expsuccess == LinSM_GblGotoSleepConfSuccs[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinSM_GucGotoSleepConfCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinSM_GucGotoSleepConfCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinSM_GucGotoSleepConfCheckCount <= LinSM_GucGotoSleepConfCount) &&
        (Expnetwork == LinSM_GddGotoSleepConfNw[LinSM_GucGotoSleepConfCheckCount]) && 
        (Expsuccess == 
        LinSM_GblGotoSleepConfSuccs[LinSM_GucGotoSleepConfCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinSM_GucGotoSleepConfCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinSM_GucGotoSleepConfCheckCount == LinSM_GucGotoSleepConfCount)
      {
        LinSM_GucGotoSleepConfCount = 0;
        LinSM_GucGotoSleepConfCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinSM_GucGotoSleepConfCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(Expnetwork == LinSM_GddGotoSleepConfNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinSM_GotoSleepConfirmation() */

/*******************************************************************************
**                       LinSM_WakeupConfirmation()                           **
*******************************************************************************/
void LinSM_WakeupConfirmation(NetworkHandleType network, boolean success)
{
  #ifndef TYPICAL_CONFIG
  LinSM_GddWakeUpConfNw[LinSM_GucWakeUpConfCount] = network;
  LinSM_GblWakeUpConfSuccs[LinSM_GucWakeUpConfCount] = success;
  /* Increment count variable to handle multiple invocations */
  if(LinSM_GucWakeUpConfCount != LINSM_ARRAY_SIZE)
  {    
    LinSM_GucWakeUpConfCount++;
  }
  #endif
} /* End LinSM_WakeupConfirmation() */

/*******************************************************************************
**                       TestLinSM_WakeupConfirmation()                       **
*******************************************************************************/
boolean TestLinSM_WakeupConfirmation(App_DataValidateType 
  LucDataValidate, NetworkHandleType Expnetwork, boolean Expsuccess)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinSM_GucWakeUpConfCount == 0x01) && 
        (Expnetwork == LinSM_GddWakeUpConfNw[0]) && 
        (Expsuccess == LinSM_GblWakeUpConfSuccs[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinSM_GucWakeUpConfCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinSM_GucWakeUpConfCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinSM_GucWakeUpConfCheckCount <= LinSM_GucWakeUpConfCount) &&
        (Expnetwork == LinSM_GddWakeUpConfNw[LinSM_GucWakeUpConfCheckCount]) && 
        (Expsuccess == 
        LinSM_GblWakeUpConfSuccs[LinSM_GucWakeUpConfCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinSM_GucWakeUpConfCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinSM_GucWakeUpConfCheckCount == LinSM_GucWakeUpConfCount)
      {
        LinSM_GucWakeUpConfCount = 0;
        LinSM_GucWakeUpConfCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinSM_GucWakeUpConfCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(Expnetwork == LinSM_GddWakeUpConfNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinSM_WakeupConfirmation() */
#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
