/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: LinSM.h                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR LIN State Manager Module                              **
**                                                                            **
**  PURPOSE   : Declaration of LinSM functions                                **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0    30-Aug-2012   Ravi Tiwari    Initial version                      **
*******************************************************************************/
#ifndef LINSM_H
#define LINSM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"
#include "TC_Generic.h"
#include "LinIf.h"
#include "ComM.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define LINSM_AR_RELEASE_MAJOR_VERSION  4
#define LINSM_AR_RELEASE_MINOR_VERSION  0
#define LINSM_AR_RELEASE_REVISION_VERSION  3

/* Software Version Information */
#define LINSM_SW_MAJOR_VERSION  1
#define LINSM_SW_MINOR_VERSION  0

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/
#define LINSM_FULL_COM                           0x01
#define LINSM_NO_COM                             0x02

#define LINSM_ARRAY_SIZE                         0x08

#define LINSM_INVALID_NETWORKID                  0x02
#define LINSM_INVALID_CURRENTSTATE               0x00
#define LINSM_INVALID_CURRENTSCHEDULESTATE       0x00 
/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
typedef uint8 LinSM_ConfigType;
typedef uint8 LinSM_ModeType;

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Std_ReturnType LinSM_RequestComMode(NetworkHandleType network,
  ComM_ModeType mode);
extern Std_ReturnType LinSM_GetCurrentComMode(NetworkHandleType network,
  P2VAR(ComM_ModeType, AUTOMATIC, COMM_APPL_DATA) mode);
  
extern Std_ReturnType LinSM_ScheduleRequest(NetworkHandleType network,
 LinIf_SchHandleType schedule);


extern boolean TestLinSM_RequestComMode(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpnetwork, ComM_ModeType LddExpmode);
extern boolean TestLinSM_GetCurrentComMode(App_DataValidateType LucDataValidate,
  NetworkHandleType LddExpnetwork, 
  P2VAR(ComM_ModeType, AUTOMATIC, COMM_APPL_DATA) LddExpmode);
 
extern boolean TestLinSM_ScheduleRequest(App_DataValidateType LucDataValidate,
 NetworkHandleType LddExpnetwork, LinIf_SchHandleType LddExpschedule);
  
extern void TestLinSM_DefaultBehavior(void);
extern void TestLinSM_RequestComModeSetBeh(Std_ReturnType LddReturnVal);
extern void TestLinSM_GetCurrentComModeSetBeh(Std_ReturnType LddReturnVal);
extern void TestLinSM_GetCurrentComModeSetMode(ComM_ModeType LddComMMode);      
extern void AppLinSM_SetBehaviorScheduleRequest(Std_ReturnType LddSetRetVal);     

extern void LinSM_Init(const LinSM_ConfigType* ConfigPtr);

extern boolean TestLinSM_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);

#endif /* LINSM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
