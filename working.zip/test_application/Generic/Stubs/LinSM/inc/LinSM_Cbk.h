/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: LinSM_Cbk.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR LINSM MODULE                                          **
**                                                                            **
**  PURPOSE   : Provision of LinSM Call back Functions                        **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0    30-Aug-2012   Ravi Tiwari    Initial version                      **
*******************************************************************************/
#ifndef LINSM_CBK_H
#define LINSM_CBK_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "LinIf.h"

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/


/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern void LinSM_ScheduleRequestConfirmation(NetworkHandleType network, 
  LinIf_SchHandleType schedule);
extern void LinSM_GotoSleepConfirmation(NetworkHandleType network, 
  boolean success);
extern void LinSM_WakeupConfirmation(NetworkHandleType channel, 
  boolean success);

extern boolean TestLinSM_ScheduleRequestConfirmation(App_DataValidateType 
  LucDataValidate, NetworkHandleType Expnetwork, LinIf_SchHandleType 
  Expschedule);
extern boolean TestLinSM_GotoSleepConfirmation(App_DataValidateType 
  LucDataValidate, NetworkHandleType Expnetwork, boolean Expsuccess);
extern boolean TestLinSM_WakeupConfirmation(App_DataValidateType LucDataValidate, 
  NetworkHandleType Expchannel, boolean Expsuccess);
#endif/* LINSM_CBK_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
