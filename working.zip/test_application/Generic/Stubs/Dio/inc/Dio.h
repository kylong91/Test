/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Dio.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Dio Stub                                              **
**                                                                            **
**  PURPOSE   : Declaration of Dio Stub functions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     04-Apr-2012   YNK    Initial version                             **
*******************************************************************************/

#ifndef DIO_H
#define DIO_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/ 
#include "Dio_Cfg.h"
#include "TC_Generic.h"
#include "Std_Types.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define DIO_AR_RELEASE_MAJOR_VERSION    0x04
#define DIO_AR_RELEASE_MINOR_VERSION    0x00
#define DIO_AR_RELEASE_REVISION_VERSION 0x03
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/* Type definition for Dio_ChannelType used by the DIO APIs */
typedef uint8 Dio_ChannelType;
/* Type definition for Dio_PortType used by the DIO APIs */
typedef uint8 Dio_PortType;
/* Type definition for Dio_LevelType used by the DIO APIs */
typedef uint8 Dio_LevelType;
/* Type definition for Dio_PortLevelType used by the DIO APIs */
typedef uint16 Dio_PortLevelType;
/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define DIO_ARRAY_SIZE                0x20
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void Dio_WriteChannel(Dio_ChannelType ChannelId, Dio_LevelType Level);

extern Dio_LevelType Dio_ReadChannel(Dio_ChannelType ChannelId);

extern boolean TestDio_WriteChannel(App_DataValidateType LucDataValidate,
  Dio_ChannelType LddChannelId, Dio_LevelType LddLevel);
  
extern boolean TestDio_ReadChannel(App_DataValidateType LucDataValidate, 
  Dio_ChannelType LddChannelId);
  
extern void TestDio_DefaultBehavior(void);

extern void FrTrcv_Dio_Init(void);

extern boolean TestDio_FrTrcv_WriteChannel(Dio_ChannelType LddSTBN,
  Dio_ChannelType LddEN, Dio_ChannelType LddTXEN, Dio_LevelType Ldd_STBN_Level, 
  Dio_LevelType Ldd_EN_Level, Dio_LevelType Ldd_TXEN_Level);
  
#endif  /* DIO_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
