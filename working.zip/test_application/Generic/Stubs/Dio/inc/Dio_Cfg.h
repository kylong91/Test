/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Dio_Cfg.h                                                     **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR LIN Transceiver Driver Module                         **
**                                                                            **
**  PURPOSE   : Provision of DIO API information                              **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: Yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: No                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     04-Apr-2012   YNK    Initial version                             **
*******************************************************************************/
#ifndef DIO_CFG_H
#define DIO_CFG_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/
#define DioConf_DioChannel_DioChannel0   0
#define DioConf_DioChannel_DioChannel1   1
#define DioConf_DioChannel_DioChannel2   2
#define DioConf_DioChannel_DioChannel3   3
#define DioConf_DioChannel_DioChannel4   4
#define DioConf_DioChannel_DioChannel5   5
#define DioConf_DioChannel_DioChannel6   6
#define DioConf_DioChannel_DioChannel7   7
#define DioConf_DioChannel_DioChannel8   8
#define DioConf_DioChannel_DioChannel9   9
#define DioConf_DioChannel_DioChannel10  10

/* Dio channels for FrTrcv channel-0 */
#define DioConf_DioChannel_DioChannel11  11 /* STBN-0 */
#define DioConf_DioChannel_DioChannel12  12 /* EN-0   */
#define DioConf_DioChannel_DioChannel13  13 /* TXEN-0 */
#define DioConf_DioChannel_DioChannel14  14 /* ERRN-0 */

/* Dio channels for FrTrcv channel-1 */
#define DioConf_DioChannel_DioChannel15  15 /* STBN-1 */
#define DioConf_DioChannel_DioChannel16  16 /* EN-1   */
#define DioConf_DioChannel_DioChannel17  17 /* TXEN-1 */
#define DioConf_DioChannel_DioChannel18  18 /* ERRN-1 */

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#endif /* DIO_CFG_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
