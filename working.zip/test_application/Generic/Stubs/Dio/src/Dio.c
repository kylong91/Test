/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Dio.c                                                         **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Dio Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Dio Driver Stub functions  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     04-Apr-2012   YNK    Initial version                             **
*******************************************************************************/
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dio.h"
// #include "App_LinTrcv_Common_Defs.h"

/* regtc27x inclusion for FrTrcv */
#ifdef FRTRCV_MODULE_ACTIVE
#include "regtc27x.h"
#endif
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Dio_WriteIndCount;
uint8 Dio_ReadIndCount;
uint8 Dio_ReadIndCountCheckCount;
uint8 Dio_WriteIndCountCheckCount;
uint8 Dio_Port12;
uint16 APPL_P1;
uint16 APPL_P3 ;
uint16 APPL_P0 ;
uint16 APPL_PPR0;
uint16 APPL_PPR1;
uint16 APPL_PPR3;
Dio_ChannelType Dio_GaaDioChannelId[DIO_ARRAY_SIZE];
Dio_LevelType   Dio_GaaDioChannelLevel[DIO_ARRAY_SIZE];
Dio_ChannelType Dio_GaaDioReadChannelId[DIO_ARRAY_SIZE];
Dio_LevelType   Dio_GaaDioReadChannelLevel[DIO_ARRAY_SIZE];
#ifdef FRTRCV_MODULE_ACTIVE
Dio_ChannelType Dio_GaaDioChannelId_FrTrcv[DIO_ARRAY_SIZE];
Dio_LevelType   Dio_GaaDioChannelLevel_FrTrcv[DIO_ARRAY_SIZE];
#endif
/*******************************************************************************
**                          Function Definitions                              **
*******************************************************************************/

/*******************************************************************************
**                           Dio_WriteChannel()                               **
*******************************************************************************/
void Dio_WriteChannel(Dio_ChannelType ChannelId, Dio_LevelType Level)
{
  Dio_GaaDioChannelId[Dio_WriteIndCount] = ChannelId;
  Dio_GaaDioChannelLevel[Dio_WriteIndCount] = Level;
  switch(ChannelId)
  {
    case 0:
          if(Level == STD_HIGH)
          {
            Dio_Port12 |= 0x02; /* To set the Sleep0 pin to STD_HIGH */
          }
          else
          {
            Dio_Port12 &= 0xFD; /* To set the Sleep0 pin to STD_LOW */
          }         
          break;
          
    case 1:
          if(Level == STD_HIGH)
          {
            APPL_P1 |= 0x1000;  /* To set the transmit0 pin to STD_HIGH */
          }
          else
          {
            APPL_P1 &= 0xDFFF; /* To set the transmit0 pin to STD_LOW */
          } 
          break;
          
    case 3:
          if(Level == STD_HIGH) 
          {
            Dio_Port12 |= 0x04; /* To set the Sleep1 pin to STD_HIGH */
          }
          else
          {
            Dio_Port12 &= 0xFB;  /* To set the Sleep1 pin to STD_LOW */
          }
          break;
		  
    case 4:
          if(Level == STD_HIGH)
          {
            APPL_P3 |= 0x200; /* To set the transmit1 pin to STD_HIGH */
          }
          else
          {
            APPL_P3 &= 0xDFF; /* To set the transmit1 pin to STD_LOW */
          } 
          break;   
		  
    case 6:
          if(Level == STD_HIGH)
          {
            Dio_Port12 |= 0x08; /* To set the Sleep2 pin to STD_HIGH */
          }
          else
          {
            Dio_Port12 &= 0xFE; /* To set the Sleep2 pin to STD_LOW */
          }         
          break;
  
     case 7:
          if(Level == STD_HIGH) 
          {
            APPL_P0 |= 0x400; /* To set the transmit2 pin to STD_HIGH */
          }
          else 
          {
            APPL_P0 &= 0xBFF;  /* To set the transmit2 pin to STD_LOW */
          }         
          break;
    
    default:
    break;
  }
  
  #ifdef FRTRCV_MODULE_ACTIVE
  switch(ChannelId)
  {
    case 11:
          if(Level == STD_HIGH) 
          {
            /* To set the P15_7 STBN0 pin to STD_HIGH */
            P15_OUT.B.P7 = STD_HIGH;			
            
            Dio_GaaDioChannelId_FrTrcv[0] = ChannelId;
            Dio_GaaDioChannelLevel_FrTrcv[0] = P15_OUT.B.P7;
          }
          else 
          {
            /* To set the P15_7 STBN0 pin to STD_LOW */
            P15_OUT.B.P7 = STD_LOW;
            
            Dio_GaaDioChannelId_FrTrcv[0] = ChannelId;            
            Dio_GaaDioChannelLevel_FrTrcv[0] = P15_OUT.B.P7;
          }         
          break;

    case 12:
          if(Level == STD_HIGH) 
          {
            /* To set the P15_6 EN0 pin to STD_HIGH */
            P15_OUT.B.P6 = STD_HIGH;
            
            Dio_GaaDioChannelId_FrTrcv[1] = ChannelId;
            Dio_GaaDioChannelLevel_FrTrcv[1] = P15_OUT.B.P6;            
          }
          else 
          {
            /* To set the P15_6 EN0 pin to STD_LOW */
            P15_OUT.B.P6 = STD_LOW;
            
            Dio_GaaDioChannelId_FrTrcv[1] = ChannelId;
            Dio_GaaDioChannelLevel_FrTrcv[1] = P15_OUT.B.P6;
		      }
          break;         

    case 13:
          if(Level == STD_HIGH) 
          {
            /* To set the P02_0 TXEN pin to STD_HIGH */
            // P02_OUT.B.P0 = STD_HIGH;
            P02_OUT.B.P4 = STD_HIGH;
			
            
            Dio_GaaDioChannelId_FrTrcv[2] = ChannelId;
            Dio_GaaDioChannelLevel_FrTrcv[2] = P02_OUT.B.P4;
          }
          else 
          {
            /* To set the P02_0 TXEN pin to STD_LOW */
            //P02_OUT.B.P0 = STD_LOW;
            P02_OUT.B.P4 = STD_LOW;
            
            Dio_GaaDioChannelId_FrTrcv[2] = ChannelId;
            Dio_GaaDioChannelLevel_FrTrcv[2] = P02_OUT.B.P4;
          }         
          break;

    case 15:
          if(Level == STD_HIGH) 
          {
            /* To set the FR channel-1 STBN pin P10.6 to STD_HIGH */
            P10_OUT.B.P6 = STD_HIGH;
            
            Dio_GaaDioChannelId_FrTrcv[0] = ChannelId;
            Dio_GaaDioChannelLevel_FrTrcv[0] = P10_OUT.B.P6;
          }
          else 
          {
            /* To set the FR channel-1 STBN pin P10.6 to STD_LOW */
            P10_OUT.B.P6 = STD_LOW;
            
            Dio_GaaDioChannelId_FrTrcv[0] = ChannelId;            
            Dio_GaaDioChannelLevel_FrTrcv[0] = P10_OUT.B.P6;
          }         
          break;

    case 16:
          if(Level == STD_HIGH) 
          {
            /* To set P10.5 the FR channel-1 EN pin to STD_HIGH */
            P10_OUT.B.P5 = STD_HIGH;
            
            Dio_GaaDioChannelId_FrTrcv[1] = ChannelId;
            Dio_GaaDioChannelLevel_FrTrcv[1] = P10_OUT.B.P5;
          }
          else 
          {
            /* To set P10.5 the FR channel-1 EN pin to STD_LOW */
            P10_OUT.B.P5 = STD_LOW;
            
            Dio_GaaDioChannelId_FrTrcv[1] = ChannelId;
            Dio_GaaDioChannelLevel_FrTrcv[1] = P10_OUT.B.P5;
		  }
          break;
          
    case 17:
          if(Level == STD_HIGH) 
          {
            /* To set P02.4 the FR channel-1 TXEN pin to STD_HIGH */
            P02_OUT.B.P5 = STD_HIGH;
            
            Dio_GaaDioChannelId_FrTrcv[2] = ChannelId;
            Dio_GaaDioChannelLevel_FrTrcv[2] = P02_OUT.B.P5;
          }
          else 
          {
            /* To set P02.4 the FR channel-1 TXEN pin to STD_LOW */
            P02_OUT.B.P5 = STD_LOW;
            
            Dio_GaaDioChannelId_FrTrcv[2] = ChannelId;
            Dio_GaaDioChannelLevel_FrTrcv[2] = P02_OUT.B.P5;
          }
		  break;

    default:
    break;
  }
  #endif
  
  Dio_WriteIndCount++;
} /* End Dio_WriteChannel() */

/*******************************************************************************
**                             TestDio_WriteChannel()                         **
*******************************************************************************/
boolean TestDio_WriteChannel(App_DataValidateType LucDataValidate,
  Dio_ChannelType LddChannelId, Dio_LevelType LddLevel)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ControllerId and ControllerMode */
      if((Dio_WriteIndCount == 0x01) &&
        (Dio_GaaDioChannelId[0] == LddChannelId) &&
        (Dio_GaaDioChannelLevel[0] == LddLevel))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Dio_WriteIndCount = 0;
      Dio_WriteIndCountCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Dio_WriteIndCount; LucIndex++)
      {
        /* Validate ControllerId and ControllerMode */
        if((Dio_GaaDioChannelId[LucIndex] == LddChannelId) &&
          (Dio_GaaDioChannelLevel[LucIndex] == LddLevel))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Dio_WriteIndCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Dio_WriteIndCountCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Dio_WriteIndCountCheckCount == Dio_WriteIndCount)
      {
        Dio_WriteIndCount = 0;
        Dio_WriteIndCountCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dio_WriteIndCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  
  return(LblStepResult);
} /* End TestDio_WriteChannel() */

/*******************************************************************************
**                           Dio_ReadChannel()                               **
*******************************************************************************/
Dio_LevelType Dio_ReadChannel(Dio_ChannelType ChannelId)
{
  Dio_LevelType LddDioReturnVl;
  uint16 LusMaskVal1;
  uint16 LusMaskVal3;
  uint16 LusMaskVal0;
  
  Dio_GaaDioReadChannelId[Dio_ReadIndCount] = ChannelId;
  LusMaskVal1 = (APPL_PPR1 & 0x2000);
  LusMaskVal3 = (APPL_PPR3 & 0x100);
  LusMaskVal0 = (APPL_PPR0 & 0x200);
  switch(ChannelId)
  {
   case 2:
          if(LusMaskVal1 == 0x2000)
          {
            LddDioReturnVl = STD_HIGH; /* Set the LddDioReturnVl to STD_HIGH */
          }
          else
          {
            LddDioReturnVl = STD_LOW;  /* Set the LddDioReturnVl to STD_LOW */
          }         
          break;
		  
   case 5:
          if(LusMaskVal3 == 0x0100)
          {
            LddDioReturnVl = STD_HIGH; /* Set the LddDioReturnVl to STD_HIGH */
          }
          else
          {
            LddDioReturnVl = STD_LOW;  /* Set the LddDioReturnVl to STD_LOW */
          }          
          break;
		  
   case 8:
          if(LusMaskVal0 == 0x200)
          {
            LddDioReturnVl = STD_HIGH; /* Set the LddDioReturnVl to STD_HIGH */
          }
          else
          {
            LddDioReturnVl = STD_LOW;  /* Set the LddDioReturnVl to STD_LOW */
          }          
          break;
    default:
    break;
  }
  
  #ifdef FRTRCV_MODULE_ACTIVE
  switch(ChannelId)
  {
    case 14:          
		  if((P10_IN.B.P8 & 1) == 1)
          {
            /* Set the LddDioReturnVl to STD_HIGH */
			      LddDioReturnVl = STD_HIGH;
          }
          else
          {
            /* Set the LddDioReturnVl to STD_LOW */
			      LddDioReturnVl = STD_LOW;
          }          
          break;
   case 18:
          LddDioReturnVl = STD_LOW;
          break;      
    default:
		  break;
  }
  #endif
  
  Dio_ReadIndCount++;
  
  return(LddDioReturnVl);
  
} /* End Dio_ReadChannel() */

/*******************************************************************************
**                             TestDio_ReadChannel()                          **
*******************************************************************************/
boolean TestDio_ReadChannel(App_DataValidateType LucDataValidate,
  Dio_ChannelType LddChannelId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ControllerId and ControllerMode */
      if((Dio_ReadIndCount == 0x01) &&
        (Dio_GaaDioReadChannelId[0] == LddChannelId))      
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Dio_ReadIndCount = 0;
      Dio_ReadIndCountCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Dio_WriteIndCount; LucIndex++)
      {
        /* Validate ControllerId and ControllerMode */
        if((Dio_GaaDioReadChannelId[LucIndex] == LddChannelId)) 
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Dio_ReadIndCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Dio_ReadIndCountCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Dio_ReadIndCountCheckCount == Dio_ReadIndCount)
      {
        Dio_ReadIndCount = 0;
        Dio_ReadIndCountCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dio_ReadIndCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  
  return(LblStepResult);
} /* End TestDio_WriteChannel() */
/*******************************************************************************
**                        TestDio_DefaultBehavior()                           **
*******************************************************************************/
void TestDio_DefaultBehavior(void)
{ 
  Dio_WriteIndCount = 0;
  Dio_ReadIndCount = 0;
  Dio_WriteIndCountCheckCount = 0;
  Dio_ReadIndCountCheckCount = 0;
  
  #ifdef FRTRCV_MODULE_ACTIVE  
  Dio_GaaDioChannelId_FrTrcv[0] = 0;  
  Dio_GaaDioChannelId_FrTrcv[1] = 0;  
  Dio_GaaDioChannelId_FrTrcv[2] = 0;
  
  Dio_GaaDioChannelLevel_FrTrcv[0] = STD_LOW;
  Dio_GaaDioChannelLevel_FrTrcv[1] = STD_LOW;
  Dio_GaaDioChannelLevel_FrTrcv[2] = STD_LOW;
  #endif  
}

#ifdef FRTRCV_MODULE_ACTIVE 
/*******************************************************************************
**                        FrTrcv_Dio_Init()                               **
*******************************************************************************/
void FrTrcv_Dio_Init(void)
{
  /* Cofigure P15.7 as digital out pin . This pin controls FR channel-0 STBN */
  P15_IOCR4.B1.PC7 = 0x10;
    
  /* Cofigure P15.6 as digital out pin . This pin controls FR channel-0 EN */
  P15_IOCR4.B1.PC6 = 0x10;
  
  /* Cofigure P02.4 as digital out pin . This pin controls FR channel-0 TXEN0 */
  
  P02_IOCR4.B1.PC4 = 0x10;
  
  /* Cofigure P10.8 as digital in pin . This pin reads the FR channel-0 ERRN0 
   * 0XX10(B) 000 Input pull-up device connected */
   P10_IOCR8.B1.PC8 = 0x02;
  
  /* Cofigure P10.6 as digital out pin . This pin controls FR channel-1 STBN */
  P10_IOCR4.B1.PC6 = 0x10; 
  
  /* Cofigure P10.5 as digital out pin . This pin controls FR channel-1 EN */
  P10_IOCR4.B1.PC5 = 0x10;
    
  /* Cofigure P02.5 as digital out pin . This pin controls FR channel-1 TXEN0 */
  P02_IOCR4.B1.PC5 = 0x10;
  
  /* Cofigure  P15.8 as digital in pin . This pin reads the FR channel-1 ERRN0 */
  P10_IOCR8.B1.PC8 = 0x02;
  
}

/*******************************************************************************
**                      TestDio_FrTrcv_WriteChannel()                         **
*******************************************************************************/
boolean TestDio_FrTrcv_WriteChannel(Dio_ChannelType LddSTBN,
  Dio_ChannelType LddEN, Dio_ChannelType LddTXEN, Dio_LevelType Ldd_STBN_Level, 
  Dio_LevelType Ldd_EN_Level, Dio_LevelType Ldd_TXEN_Level)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  if(Dio_WriteIndCount > 0)
  {
    /* Check levels of STBN, EN, TXEN */
    if((LddSTBN == Dio_GaaDioChannelId_FrTrcv[0]) && 
      (LddEN == Dio_GaaDioChannelId_FrTrcv[1]) && 
      (LddTXEN == Dio_GaaDioChannelId_FrTrcv[2]) && 
      (Ldd_STBN_Level == Dio_GaaDioChannelLevel_FrTrcv[0]) &&
      (Ldd_EN_Level == Dio_GaaDioChannelLevel_FrTrcv[1]) &&
      (Ldd_TXEN_Level == Dio_GaaDioChannelLevel_FrTrcv[2])
      )
    {
      LblStepResult = STEP_PASSED;
    }
    
    Dio_WriteIndCount = 0;
  }

  return LblStepResult;
}
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
