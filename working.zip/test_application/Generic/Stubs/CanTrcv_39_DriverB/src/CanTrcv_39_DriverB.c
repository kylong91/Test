/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: CanTrcv_39_DriverB.c                                          **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CanTrcv_39_DriverB Stub                               **
**                                                                            **
**  PURPOSE   : This application file contains the CanTrcv_39_DriverB         **
**              Stub functions                                                **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision    Date         By    Description                                 **
********************************************************************************
** 4.0.0     13/06/2011    BJV    Creation of CanTrcv_39_DriverB.c module     **
** 4.0.1     03/08/2011    BJV    Global variable name is changed from        **
**                                  GddGetOpMode to GddDrvBGetOpMode          **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "CanTrcv_39_DriverB.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 CanTrcv_GucDrvBChkWakeCount;
uint8 CanTrcv_GucDrvBChkWakeCheckCount;
uint8 CanTrcv_GucDrvBTransceiver;
Std_ReturnType CanTrcv_GddDrvBCheckWakeupRetVal;

uint8 CanTrcv_GucDrvBGetBusWRCount;
uint8 CanTrcv_GucDrvBGetBusWRCheckCount;
CanTrcv_TrcvWakeupReasonType CanTrcv_GenDrvBReason;

uint8 CanTrcv_GucDrvBGetOpMoCount;
uint8 CanTrcv_GucDrvBGetOpMoCheckCount;
CanTrcv_TrcvModeType CanTrcv_GddDrvBGetOpMode;
Std_ReturnType CanTrcv_GddDrvBGetOpModeRetVal;

uint8 CanTrcv_GucDrvBSetOpMoCount;
uint8 CanTrcv_GucDrvBSetOpMoCheckCount;
CanTrcv_TrcvModeType CanTrcv_GddDrvBSetOpMode;

uint8 CanTrcv_GucDrvBSetWakupCount;
uint8 CanTrcv_GucDrvBSetWakupCheckCount;
CanTrcv_TrcvWakeupModeType CanTrcv_GucDrvBTrcvWakeupMode;

/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
/*******************************************************************************
**                     CanTrcv_39_DriverB_CheckWakeFlag()                  **
*******************************************************************************/
Std_ReturnType CanTrcv_39_DriverB_CheckWakeFlag(uint8 TransceiverId)
{
  /* Load actual Transceiver into Global variables */
  CanTrcv_GucDrvBTransceiver = TransceiverId;
  CanTrcv_GucDrvBChkWakeCount++;

  return(CanTrcv_GddDrvBCheckWakeupRetVal);
} /* End CanTrcv_39_DriverB_CheckWakeFlag() */

/*******************************************************************************
**                     TestCanTrcv_39_DriverB_ClearTrcvWufFlag()              **
*******************************************************************************/
boolean TestCanTrcv_39_DriverB_CheckWakeFlag(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count,Transceiver  */
      if((CanTrcv_GucDrvBChkWakeCount == 0x01) &&
      (CanTrcv_GucDrvBTransceiver == ExpTransceiver))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucDrvBChkWakeCount = 0;
      CanTrcv_GucDrvBChkWakeCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucDrvBChkWakeCount; LucIndex++)
      {
        /* Validate Transceiver */
        if(CanTrcv_GucDrvBTransceiver == ExpTransceiver)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucDrvBChkWakeCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTrcv_GucDrvBChkWakeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTrcv_GucDrvBChkWakeCheckCount == CanTrcv_GucDrvBChkWakeCount)
      {
        CanTrcv_GucDrvBChkWakeCount = 0;
        CanTrcv_GucDrvBChkWakeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucDrvBChkWakeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCanTrcv_39_DriverB_CheckWakeFlag() */










/*******************************************************************************
**                     CanTrcv_39_DriverB_ClearTrcvWufFlag()                  **
*******************************************************************************/
Std_ReturnType CanTrcv_39_DriverB_ClearTrcvWufFlag(uint8 TransceiverId)
{
  /* Load actual Transceiver into Global variables */
  CanTrcv_GucDrvBTransceiver = TransceiverId;
  CanTrcv_GucDrvBChkWakeCount++;

  return(CanTrcv_GddDrvBCheckWakeupRetVal);
} /* End CanTrcv_39_DriverB_ClearTrcvWufFlag() */

/*******************************************************************************
**                     TestCanTrcv_39_DriverB_ClearTrcvWufFlag()              **
*******************************************************************************/
boolean TestCanTrcv_39_DriverB_ClearTrcvWufFlag(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count,Transceiver  */
      if((CanTrcv_GucDrvBChkWakeCount == 0x01) &&
      (CanTrcv_GucDrvBTransceiver == ExpTransceiver))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucDrvBChkWakeCount = 0;
      CanTrcv_GucDrvBChkWakeCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucDrvBChkWakeCount; LucIndex++)
      {
        /* Validate Transceiver */
        if(CanTrcv_GucDrvBTransceiver == ExpTransceiver)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucDrvBChkWakeCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTrcv_GucDrvBChkWakeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTrcv_GucDrvBChkWakeCheckCount == CanTrcv_GucDrvBChkWakeCount)
      {
        CanTrcv_GucDrvBChkWakeCount = 0;
        CanTrcv_GucDrvBChkWakeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucDrvBChkWakeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCanTrcv_39_DriverB_ClearTrcvWufFlag() */






/*******************************************************************************
**                     CanTrcv_39_DriverB_CheckWakeup()                       **
*******************************************************************************/
Std_ReturnType CanTrcv_39_DriverB_CheckWakeup(uint8 Transceiver)
{
  /* Load actual Transceiver into Global variables */
  CanTrcv_GucDrvBTransceiver = Transceiver;
  CanTrcv_GucDrvBChkWakeCount++;

  return(CanTrcv_GddDrvBCheckWakeupRetVal);
} /* End CanTrcv_39_DriverB_CheckWakeup() */

/*******************************************************************************
**                     TestCanTrcv_39_DriverB_CheckWakeup()                   **
*******************************************************************************/
boolean TestCanTrcv_39_DriverB_CheckWakeup(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count,Transceiver  */
      if((CanTrcv_GucDrvBChkWakeCount == 0x01) &&
      (CanTrcv_GucDrvBTransceiver == ExpTransceiver))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucDrvBChkWakeCount = 0;
      CanTrcv_GucDrvBChkWakeCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucDrvBChkWakeCount; LucIndex++)
      {
        /* Validate Transceiver */
        if(CanTrcv_GucDrvBTransceiver == ExpTransceiver)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucDrvBChkWakeCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTrcv_GucDrvBChkWakeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTrcv_GucDrvBChkWakeCheckCount == CanTrcv_GucDrvBChkWakeCount)
      {
        CanTrcv_GucDrvBChkWakeCount = 0;
        CanTrcv_GucDrvBChkWakeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucDrvBChkWakeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCanTrcv_39_DriverB_CheckWakeup() */

/*******************************************************************************
**                       CanTrcv_39_DriverB_GetBusWuReason()                  **
*******************************************************************************/
Std_ReturnType CanTrcv_39_DriverB_GetBusWuReason(uint8 Transceiver,
  CanTrcv_TrcvWakeupReasonType *reason)
{
  /* Load actual Transceiver and reason into Global variables */
  CanTrcv_GucDrvBTransceiver = Transceiver;
  *reason = CanTrcv_GenDrvBReason;
  CanTrcv_GucDrvBGetBusWRCount++;

  return(E_OK);
} /* End CanTrcv_39_DriverB_GetBusWuReason() */

/*******************************************************************************
**                   TestCanTrcv_39_DriverB_GetBusWuReason()                  **
*******************************************************************************/
boolean TestCanTrcv_39_DriverB_GetBusWuReason(
 App_DataValidateType LddDataValidate, uint8 LddExpTransceiver)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Transceiver and reason */
      if((CanTrcv_GucDrvBGetBusWRCount == 0x01) &&
        (CanTrcv_GucDrvBTransceiver == LddExpTransceiver))
     {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucDrvBGetBusWRCount = 0;
      CanTrcv_GucDrvBGetBusWRCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucDrvBGetBusWRCount; LucIndex++)
      {
        /* Validate Transceiver and reason */
        if((CanTrcv_GucDrvBTransceiver == LddExpTransceiver))

        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucDrvBGetBusWRCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTrcv_GucDrvBGetBusWRCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTrcv_GucDrvBGetBusWRCheckCount == CanTrcv_GucDrvBGetBusWRCount)
      {
        CanTrcv_GucDrvBGetBusWRCount = 0;
        CanTrcv_GucDrvBGetBusWRCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucDrvBGetBusWRCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCanTrcv_39_DriverB_GetBusWuReason() */

/*******************************************************************************
**                   CanTrcv_39_DriverB_GetOpMode()                           **
*******************************************************************************/
Std_ReturnType CanTrcv_39_DriverB_GetOpMode(uint8 Transceiver,
  CanTrcv_TrcvModeType *OpMode)
{
  /* Load actual Transceiver and OpMode into Global variables */
  CanTrcv_GucDrvBTransceiver = Transceiver;
  *OpMode = CanTrcv_GddDrvBGetOpMode;
  CanTrcv_GucDrvBGetOpMoCount++;

  return(CanTrcv_GddDrvBGetOpModeRetVal);
} /* End CanTrcv_39_DriverB_GetOpMode() */

/*******************************************************************************
**                   TestCanTrcv_39_DriverB_GetOpMode()                       **
*******************************************************************************/
boolean TestCanTrcv_39_DriverB_GetOpMode(App_DataValidateType LddDataValidate,
  uint8 LddExpTransceiver)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Transceiver and OpMode */
      if((CanTrcv_GucDrvBGetOpMoCount == 0x01) &&
        (CanTrcv_GucDrvBTransceiver == LddExpTransceiver))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucDrvBGetOpMoCount = 0;
      CanTrcv_GucDrvBGetOpMoCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucDrvBGetOpMoCount; LucIndex++)
      {
        /* Validate ControllerId and ControllerMode */
        if(CanTrcv_GucDrvBTransceiver == LddExpTransceiver)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucDrvBGetOpMoCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTrcv_GucDrvBGetOpMoCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTrcv_GucDrvBGetOpMoCheckCount == CanTrcv_GucDrvBGetOpMoCount)
      {
        CanTrcv_GucDrvBGetOpMoCount = 0;
        CanTrcv_GucDrvBGetOpMoCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucDrvBGetOpMoCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCanTrcv_39_DriverB_GetOpMode() */

/*******************************************************************************
**                   CanTrcv_39_DriverB_SetOpMode()                           **
*******************************************************************************/
Std_ReturnType CanTrcv_39_DriverB_SetOpMode(uint8 Transceiver,
  CanTrcv_TrcvModeType OpMode)
{
  /* Load actual Transceiver and OpMode into Global variables */
  CanTrcv_GucDrvBTransceiver = Transceiver;
  CanTrcv_GddDrvBSetOpMode = OpMode;
  CanTrcv_GucDrvBSetOpMoCount++;

  return(E_OK);
} /* End CanTrcv_39_DriverB_SetOpMode() */

/*******************************************************************************
**                   TestCanTrcv_39_DriverB_GetOpMode()                       **
*******************************************************************************/
boolean TestCanTrcv_39_DriverB_SetOpMode(App_DataValidateType LddDataValidate,
uint8 ExpTransceiver, CanTrcv_TrcvModeType ExpOpMode)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Transceiver and OpMode */
      if((CanTrcv_GucDrvBSetOpMoCount == 0x01) &&
        (CanTrcv_GucDrvBTransceiver == ExpTransceiver) &&
        ( CanTrcv_GddDrvBSetOpMode == ExpOpMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucDrvBSetOpMoCount = 0;
      CanTrcv_GucDrvBSetOpMoCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucDrvBSetOpMoCount; LucIndex++)
      {
        /* Validate Transceiver and OpMode */
        if((CanTrcv_GucDrvBTransceiver == ExpTransceiver) &&
          (CanTrcv_GddDrvBSetOpMode == ExpOpMode))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucDrvBSetOpMoCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTrcv_GucDrvBSetOpMoCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTrcv_GucDrvBSetOpMoCheckCount == CanTrcv_GucDrvBSetOpMoCount)
      {
        CanTrcv_GucDrvBSetOpMoCount = 0;
        CanTrcv_GucDrvBSetOpMoCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucDrvBSetOpMoCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCanTrcv_39_DriverB_SetOpMode() */

/*******************************************************************************
**                   CanTrcv_39_DriverB_SetWakeupMode()                       **
*******************************************************************************/
Std_ReturnType CanTrcv_39_DriverB_SetWakeupMode(uint8 Transceiver,
CanTrcv_TrcvWakeupModeType TrcvWakeupMode)
{
  /* Load actual Transceiver and TrcvWakeupMode into Global variables */
  CanTrcv_GucDrvBTransceiver = Transceiver;
  CanTrcv_GucDrvBTrcvWakeupMode = TrcvWakeupMode;
  CanTrcv_GucDrvBSetWakupCount++;

  return(E_OK);
} /* End CanTrcv_39_DriverB_SetWakeupMode() */

/*******************************************************************************
**                   TestCanTrcv_39_DriverB_SetWakeupMode()                   **
*******************************************************************************/
boolean TestCanTrcv_39_DriverB_SetWakeupMode(
  App_DataValidateType LddDataValidate, uint8 ExpTransceiver,
  CanTrcv_TrcvWakeupModeType ExpTrcvWakeupMode)
{
 boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Transceiver and TrcvWakeupMode */
      if((CanTrcv_GucDrvBSetWakupCount == 0x01) &&
         (CanTrcv_GucDrvBTransceiver == ExpTransceiver) &&
         (CanTrcv_GucDrvBTrcvWakeupMode == ExpTrcvWakeupMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucDrvBSetWakupCount = 0;
      CanTrcv_GucDrvBSetWakupCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucDrvBSetWakupCount; LucIndex++)
      {
        /* Validate Transceiver and TrcvWakeupMode  */
        if((CanTrcv_GucDrvBTransceiver == ExpTransceiver) &&
          (CanTrcv_GucDrvBTrcvWakeupMode == ExpTrcvWakeupMode))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucDrvBSetWakupCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTrcv_GucDrvBSetWakupCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTrcv_GucDrvBSetWakupCheckCount == CanTrcv_GucDrvBSetWakupCount)
      {
        CanTrcv_GucDrvBSetWakupCount = 0;
        CanTrcv_GucDrvBSetWakupCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucDrvBSetWakupCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCanTrcv_39_DriverB_SetWakeupMode() */

/*******************************************************************************
**                     TestSetCanTrcv_39_DriverB_GetTrcvModeVal()             **
*******************************************************************************/
void TestSetCanTrcv_39_DriverB_GetTrcvModeVal(CanTrcv_TrcvModeType LddOpMode)
{
  CanTrcv_GddDrvBGetOpMode = LddOpMode;
} /* End of TestSetCanTrcv_39_DriverB_GetTrcvModeVal */

/*******************************************************************************
**                     TestSetCanTrcv_39_DriverB_GetOpModeRetVal()            **
*******************************************************************************/
void TestSetCanTrcv_39_DriverB_GetOpModeRetVal(Std_ReturnType LddRetVal,
  CanTrcv_TrcvModeType LddOpMode)
{
  CanTrcv_GddDrvBGetOpModeRetVal = LddRetVal;
  CanTrcv_GddDrvBGetOpMode = LddOpMode;
} /* TestSetCanTrcv_39_DriverB_GetOpModeRetVal() */

/*******************************************************************************
**                  TestCanTrcv_39_DriverB_CheckWakeupRetVal()                **
*******************************************************************************/
void TestCanTrcv_39_DriverB_CheckWakeupRetVal(Std_ReturnType LddCanTrcvReturnVal)
{
  CanTrcv_GddDrvBCheckWakeupRetVal = LddCanTrcvReturnVal;
}
/* End TestCanTrcv_39_DriverB_CheckWakeupRetVal() */

/*******************************************************************************
**                  TestSetCanTrcv_39_DriverB_GetBusWuReason()                **
*******************************************************************************/
void TestSetCanTrcv_39_DriverB_GetBusWuReason(CanTrcv_TrcvWakeupReasonType
  LenWakeupReason)
{
  CanTrcv_GenDrvBReason = LenWakeupReason;
}
/* End TestSetCanTrcv_39_DriverB_GetBusWuReason() */
/*******************************************************************************
**                        TestCanTrcv_DefaultBehavior()                       **
*******************************************************************************/
void TestCanTrcv_39_DriverB_DefaultBehavior(void)
{
  CanTrcv_GucDrvBChkWakeCount = 0;
  CanTrcv_GucDrvBChkWakeCheckCount = 0;
  CanTrcv_GucDrvBTransceiver = 0;
  CanTrcv_GucDrvBGetBusWRCount = 0;
  CanTrcv_GucDrvBGetBusWRCheckCount = 0;
  CanTrcv_GucDrvBGetOpMoCount = 0;
  CanTrcv_GucDrvBGetOpMoCheckCount = 0;
  CanTrcv_GucDrvBSetOpMoCount = 0;
  CanTrcv_GucDrvBSetOpMoCheckCount = 0;
  CanTrcv_GucDrvBSetWakupCount = 0;
  CanTrcv_GucDrvBSetWakupCheckCount = 0;
  CanTrcv_GddDrvBGetOpMode = CANTRCV_TRCVMODE_NORMAL;
  CanTrcv_GenDrvBReason = CANTRCV_WU_POWER_ON;
  CanTrcv_GddDrvBGetOpModeRetVal = E_OK;
  CanTrcv_GddDrvBCheckWakeupRetVal = E_OK;
}

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

