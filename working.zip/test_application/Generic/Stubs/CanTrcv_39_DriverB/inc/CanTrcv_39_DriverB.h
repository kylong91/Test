/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: CanTrcv_39_DriverB.h                                          **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CAN Interface module                                  **
**                                                                            **
**  PURPOSE   : Declaration of CanTrcv_39_DriverB functions                   **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     13/06/2011    BJV    Creation of CanTrcv_39_DriverB.h module     **
** 4.0.1     03/08/2011    BJV    New Api                                     **
**                                TestSetCanTrcv_39_DriverB_GetTrcvModeVal is **
**                                added                                       **
** 4.0.2     20-Dec-2011   RPS    General Inclusions are updated              **
*******************************************************************************/
#ifndef CANTRCV_39_DRIVERB
#define CANTRCV_39_DRIVERB

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"             /* Com Stack header */
#include "Can_GeneralTypes.h"
#include "TC_Generic.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define CANTRCV_39_DRIVERB_AR_RELEASE_MAJOR_VERSION    0x04
#define CANTRCV_39_DRIVERB_AR_RELEASE_MINOR_VERSION    0x00
#define CANTRCV_AR_RELEASE_REVISION_VERSION 0x02

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Std_ReturnType CanTrcv_39_DriverB_CheckWakeup(uint8 Transceiver);

extern Std_ReturnType CanTrcv_39_DriverB_GetBusWuReason(uint8 Transceiver,
  CanTrcv_TrcvWakeupReasonType *reason);

extern Std_ReturnType CanTrcv_39_DriverB_GetOpMode(uint8 Transceiver,
  CanTrcv_TrcvModeType *OpMode);

extern Std_ReturnType CanTrcv_39_DriverB_SetOpMode(uint8 Transceiver,
  CanTrcv_TrcvModeType OpMode);

extern Std_ReturnType CanTrcv_39_DriverB_SetWakeupMode(uint8 Transceiver,
  CanTrcv_TrcvWakeupModeType TrcvWakeupMode);


extern boolean TestCanTrcv_39_DriverB_CheckWakeup(
  App_DataValidateType LddDataValidate, uint8 ExpTransceiver);

extern boolean TestCanTrcv_39_DriverB_GetBusWuReason(
  App_DataValidateType LddDataValidate, uint8 LddExpTransceiver);

extern boolean TestCanTrcv_39_DriverB_GetOpMode(
  App_DataValidateType LddDataValidate, uint8 LddExpTransceiver);

extern boolean TestCanTrcv_39_DriverB_SetOpMode(
  App_DataValidateType LddDataValidate, uint8 ExpTransceiver,
  CanTrcv_TrcvModeType ExpOpMode);

extern boolean TestCanTrcv_39_DriverB_SetWakeupMode(
  App_DataValidateType LddDataValidate, uint8 ExpTransceiver,
  CanTrcv_TrcvWakeupModeType ExpTrcvWakeupMode);

extern void TestCanTrcv_39_DriverB_DefaultBehavior(void);

extern void TestSetCanTrcv_39_DriverB_GetOpModeRetVal(Std_ReturnType LddRetVal,
  CanTrcv_TrcvModeType LddOpMode);

extern void TestCanTrcv_39_DriverB_CheckWakeupRetVal(Std_ReturnType
  LddCanTrcvReturnVal);

extern void TestSetCanTrcv_39_DriverB_GetBusWuReason(
  CanTrcv_TrcvWakeupReasonType LenWakeupReason);
extern void TestSetCanTrcv_39_DriverB_GetTrcvModeVal
  (CanTrcv_TrcvModeType LddOpMode);
extern boolean TestCanTrcv_39_DriverB_ClearTrcvWufFlag(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver);

extern Std_ReturnType CanTrcv_39_DriverB_ClearTrcvWufFlag(uint8 TransceiverId);

extern Std_ReturnType CanTrcv_39_DriverB_CheckWakeFlag(uint8 TransceiverId);

extern boolean TestCanTrcv_39_DriverB_CheckWakeFlag(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver);  
#endif /* CANTRCV_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
