/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Mcu.c                                                         **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR WdgIf Stub                                            **
**                                                                            **
**  PURPOSE   : This application file contains the WdgIf Stub functions       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Mcu.h"
#ifdef ECUM_MODULE_ACTIVE
#include "EcuM.h"
#include "EcuM_Stub_Generic.h"
#endif

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#ifdef ECUM_MODULE_ACTIVE
Mcu_ResetType Mcu_GddResetReason = MCU_POWER_ON_RESET;
Mcu_ModeType Mcu_GaaMode[MCU_ARRAY_SIZE];
uint8 Mcu_GucConfigData;
uint8 Mcu_GucGetResetReasonSeqCnt;
uint8 Mcu_GucPerformResetSeqCnt;
uint8 Mcu_GucSetModeSeqCnt;
uint8 Mcu_GucInitSeqCnt;
uint8 Mcu_GucSetModeCount;
uint8 Mcu_GucSetModeCheckCount;

/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
**                         Mcu_Init()                                         **
*******************************************************************************/
void Mcu_Init(const Mcu_ConfigType *ConfigPtr)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Mcu_GucInitSeqCnt = App_GucApiSeqCnt;
  if (ConfigPtr != NULL_PTR)
  {
    Mcu_GucConfigData = (ConfigPtr->dummy);
  }
  #endif
}

/*******************************************************************************
**                        TestMcu_Init()                                      **
*******************************************************************************/
boolean TestMcu_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, uint8 LucData)
{
  boolean LblStepResult;  
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Mcu_GucInitSeqCnt == 0x01) && 
        (Mcu_GucConfigData == LucData))
      {
        LblStepResult = STEP_PASSED;
      }
      Mcu_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if((Mcu_GucInitSeqCnt == LucSeqNo) && 
        (Mcu_GucConfigData == LucData))
      {
        LblStepResult = STEP_PASSED;
      }
      Mcu_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */    
    
  return (LblStepResult);
}

/*******************************************************************************
**                     Mcu_GetResetReason()                                   **
*******************************************************************************/
Mcu_ResetType Mcu_GetResetReason(void)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Mcu_GucGetResetReasonSeqCnt = App_GucApiSeqCnt;
  #endif
  return (Mcu_GddResetReason);
}

/*******************************************************************************
**                  TestMcu_GetResetReason()                                  **
*******************************************************************************/
boolean TestMcu_GetResetReason(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;  
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Mcu_GucGetResetReasonSeqCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Mcu_GucGetResetReasonSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(Mcu_GucGetResetReasonSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Mcu_GucGetResetReasonSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */    
    
  return (LblStepResult);
} /* End TestMcu_GetResetReason() */

/*******************************************************************************
**                     Mcu_PerformReset()                                     **
*******************************************************************************/
void Mcu_PerformReset(void)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Mcu_GucPerformResetSeqCnt = App_GucApiSeqCnt;
  #endif
}

/*******************************************************************************
**                    TestMcu_PerformReset()                                  **
*******************************************************************************/
boolean TestMcu_PerformReset(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;  
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Mcu_GucPerformResetSeqCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Mcu_GucPerformResetSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(Mcu_GucPerformResetSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Mcu_GucPerformResetSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */    
    
  return (LblStepResult);
} /* End TestMcu_PerformReset() */

/*******************************************************************************
**                         Mcu_SetMode()                                      **
*******************************************************************************/
void Mcu_SetMode(const Mcu_ModeType McuMode)
{
  #ifndef TYPICAL_CONFIG
  Mcu_GaaMode[Mcu_GucSetModeCount] = McuMode;
  
  if(Mcu_GucSetModeCount < MCU_ARRAY_SIZE)
  {
    Mcu_GucSetModeCount++;
  }
  
  App_GucApiSeqCnt++;
  Mcu_GucSetModeSeqCnt = App_GucApiSeqCnt;
  if(McuMode == ECUM_MCU_NORMAL_MODE)
  {
    EcuMApp_GddInvoke = CLEAR;
  }
  switch(EcuMApp_GddInvoke)
  {
    case SET_POWER:
                    EcuM_SetWakeupEvent(ECUM_WKSOURCE_POWER);
                    EcuMApp_GddInvoke = CLEAR;
                    break;
                    
    case SET_CAN:
                    EcuM_SetWakeupEvent
                      (EcuMConf_EcuMWakeupSource_ECUM_WKSOURCE_CAN);
                    EcuMApp_GddInvoke = CLEAR;
                    break;
                    
    case SET_GPT:
                    EcuM_SetWakeupEvent
                      (EcuMConf_EcuMWakeupSource_ECUM_WKSOURCE_GPT);
                    #if(ECUM_ALARM_CLOCK_PRESENT == STD_OFF)
                    EcuMApp_GddInvoke = CLEAR;
                    #endif
                    
                    break;          
    default:
                    break;
  }
  #endif
}

/*******************************************************************************
**                       TestMcu_SetMode()                                    **
*******************************************************************************/
boolean TestMcu_SetMode(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, const Mcu_ModeType LddMcuMode)
{
  boolean LblStepResult;
  uint8 LucIndex;
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Mcu_GucSetModeCount == 1) && (Mcu_GaaMode[0] == LddMcuMode))
      {
        LblStepResult = STEP_PASSED;
      }
      Mcu_GucSetModeCount = 0;
      Mcu_GucSetModeSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if((Mcu_GucSetModeSeqCnt == LucSeqNo) && (Mcu_GaaMode[0] == LddMcuMode))
      {
        LblStepResult = STEP_PASSED;
      }
      Mcu_GucSetModeCount = 0;
      Mcu_GucSetModeSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Mcu_GucSetModeCount; LucIndex++)
      {
        /* Validate Current state */
        if(Mcu_GaaMode[LucIndex] == LddMcuMode)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Mcu_GucSetModeCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Mcu_GucSetModeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Mcu_GucSetModeCheckCount == Mcu_GucSetModeCount)
      {
        Mcu_GucSetModeCount = 0;
        Mcu_GucSetModeCheckCount = 0;
        Mcu_GucSetModeSeqCnt = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestMcu_SetMode() */

/*******************************************************************************
**                       TestMcu_DefaultBehavior()                            **
*******************************************************************************/
void TestMcu_DefaultBehavior(void)
{
  Mcu_GddResetReason = MCU_POWER_ON_RESET;
  Mcu_GucConfigData = 0;
  Mcu_GucGetResetReasonSeqCnt = 0;
  Mcu_GucPerformResetSeqCnt = 0;
  Mcu_GucInitSeqCnt = 0;
  Mcu_GucSetModeCount = 0;
  Mcu_GucSetModeCheckCount = 0;
}

/*******************************************************************************
**                     TestSetMcu_GetResetReason()                            **
*******************************************************************************/
void TestSetMcu_GetResetReason(Mcu_ResetType reason)
{
  Mcu_GddResetReason = reason;
}
#endif /* #ifdef ECUM_MODULE_ACTIVE */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
