/*******************************************************************************
** (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,          **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Gpt.c                                                         **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR GPT Module                                            **
**                                                                            **
**  PURPOSE   : This file is a stub for GPT Driver Component                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Gpt.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/* Variables used by Gpt module  */
Gpt_ChannelType Gpt_GddChannel;
Gpt_ValueType Gpt_GddValue;
Gpt_ValueType Gpt_GddTimerValue;
uint8 Gpt_GucStartTimerCount;
uint8 Gpt_GucTimeElapsedCount;
uint8 Gpt_GucInitCount;
uint8 Gpt_GucInitSeqCnt;
uint8 Gpt_GucConfigData;
#ifdef ECUM_MODULE_ACTIVE
Gpt_ModeType Gpt_GddMode;
uint8 Gpt_GucSetModeSeqCnt;
uint8 Gpt_GucSetModeCount;
uint8 Gpt_GucEnableWakeupSeqCnt;
uint8 Gpt_GucStartTimerSeqCnt;
uint8 Gpt_GucStopTimerSeqCnt;
uint8 Gpt_GucEnableWakeupCount;
uint8 Gpt_GucStopTimerCount;
#endif
#ifdef DLT_MODULE_ACTIVE
Gpt_ChannelType Gpt_GddDltChannel;
uint8 Gpt_GucEnableNotiCount;
#endif
/*******************************************************************************
**                       TestGpt_DefaultBehavior()                            **
*******************************************************************************/
void TestGpt_DefaultBehavior(void)
{
  Gpt_GddChannel = 0;
  Gpt_GddValue = 0;
  Gpt_GddTimerValue = 0;
  Gpt_GucStartTimerCount = 0;
  Gpt_GucTimeElapsedCount = 0;
  Gpt_GucInitCount = 0;
  Gpt_GucInitSeqCnt = 0;
  Gpt_GucConfigData = 0;
  #ifdef DLT_MODULE_ACTIVE
  Gpt_GddDltChannel = 0;
  Gpt_GucEnableNotiCount = 0;
  #endif
} /* End TestGpt_DefaultBehavior() */

/*******************************************************************************
**                       App_TestGptPrepareData()                             **
*******************************************************************************/
void App_TestGptPrepareData(Gpt_ValueType Value)
{
  Gpt_GddTimerValue = Value;
}
/*******************************************************************************
**                       Gpt_StartTimer()                                     **
*******************************************************************************/
void Gpt_StartTimer(Gpt_ChannelType Channel, Gpt_ValueType Value)
{
  #ifndef TYPICAL_CONFIG
  Gpt_GddChannel = Channel;
  Gpt_GddValue = Value;
  Gpt_GucStartTimerCount++;
  #ifdef ECUM_MODULE_ACTIVE
  App_GucApiSeqCnt++;
  Gpt_GucStartTimerSeqCnt = App_GucApiSeqCnt;
  #endif
  #endif
} /* End Gpt_StartTimer() */

/*******************************************************************************
**                       Gpt_GetTimeElapsed()                                 **
*******************************************************************************/
Gpt_ValueType Gpt_GetTimeElapsed(Gpt_ChannelType Channel)
{
  #ifndef TYPICAL_CONFIG
  Gpt_GddChannel = Channel;
  Gpt_GucTimeElapsedCount++;
  #endif
  return(Gpt_GddTimerValue);
} /* End Gpt_GetTimeElapsed() */

/*******************************************************************************
**                       TestGpt_GetTimeElapsed()                             **
*******************************************************************************/
boolean TestGpt_GetTimeElapsed(App_DataValidateType LucDataValidate, 
  Gpt_ChannelType ExpChannel)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Gpt_GucTimeElapsedCount == 0x01) &&
        (ExpChannel == Gpt_GddChannel))
      {
        LblStepResult = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Gpt_GucTimeElapsedCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End TestGpt_GetTimeElapsed() */

/*******************************************************************************
**                         Gpt_Init()                                         **
*******************************************************************************/
void Gpt_Init(const Gpt_ConfigType *ConfigPtr)
{
  #ifndef TYPICAL_CONFIG
  Gpt_GucInitCount++;
  App_GucApiSeqCnt++;
  Gpt_GucInitSeqCnt = App_GucApiSeqCnt;
  if (ConfigPtr != NULL_PTR)
  {
    Gpt_GucConfigData = (ConfigPtr->dummy);
  }
  #endif
}

/*******************************************************************************
**                        TestGpt_Init()                                      **
*******************************************************************************/
boolean TestGpt_Init(App_DataValidateType LucDataValidate,
  uint8 LucData)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;
  UNUSED(LucData);
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if(Gpt_GucInitCount == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Gpt_GucInitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return (LblStepResult);
} /* End TestGpt_Init() */

#ifdef ECUM_MODULE_ACTIVE
/*******************************************************************************
**                         Gpt_SetMode()                                      **
*******************************************************************************/
void Gpt_SetMode(Gpt_ModeType Mode)
{
  #ifndef TYPICAL_CONFIG
  Gpt_GddMode = Mode;
  Gpt_GucSetModeCount++;
  App_GucApiSeqCnt++;
  Gpt_GucSetModeSeqCnt = App_GucApiSeqCnt;
  #endif
}

/*******************************************************************************
**                        TestGpt_SetMode()                                   **
*******************************************************************************/
boolean TestGpt_SetMode(App_DataValidateType LucDataValidate, uint8 LucSeqNo,
  Gpt_ModeType Mode)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Gpt_GucSetModeCount == 1) && (Gpt_GddMode == Mode))
      {
        LblStepResult = STEP_PASSED;
      }
      Gpt_GucSetModeCount = 0;
      Gpt_GucSetModeSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if((Gpt_GucSetModeSeqCnt == LucSeqNo) && (Gpt_GddMode == Mode))
      {
        LblStepResult = STEP_PASSED;
      }
      Gpt_GucSetModeCount = 0;
      Gpt_GucSetModeSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestGpt_SetMode() */

/*******************************************************************************
**                         Gpt_EnableWakeup()                                 **
*******************************************************************************/
void Gpt_EnableWakeup( Gpt_ChannelType Channel )
{
  #ifndef TYPICAL_CONFIG
  Gpt_GddChannel = Channel;

  Gpt_GucEnableWakeupCount++;
  App_GucApiSeqCnt++;
  Gpt_GucEnableWakeupSeqCnt = App_GucApiSeqCnt;
  #endif
}

/*******************************************************************************
**                        TestGpt_EnableWakeup()                              **
*******************************************************************************/
boolean TestGpt_EnableWakeup(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, Gpt_ChannelType Channel)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Gpt_GucEnableWakeupCount == 1) && (Gpt_GddChannel == Channel))
      {
        LblStepResult = STEP_PASSED;
      }
      Gpt_GucEnableWakeupCount = 0;
      Gpt_GucEnableWakeupSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if((Gpt_GucEnableWakeupSeqCnt == LucSeqNo) && (Gpt_GddChannel == Channel))
      {
        LblStepResult = STEP_PASSED;
      }
      Gpt_GucEnableWakeupCount = 0;
      Gpt_GucEnableWakeupSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {

      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestGpt_SetMode() */

/*******************************************************************************
**                        TestGpt_EnableWakeup()                              **
*******************************************************************************/
boolean TestEcuMGpt_StartTimer(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, Gpt_ChannelType Channel, Gpt_ValueType Value)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Gpt_GucStartTimerCount == 1) && (Gpt_GddChannel == Channel) &&
        (Gpt_GddValue == Value))
      {
        LblStepResult = STEP_PASSED;
      }
      Gpt_GucStartTimerCount = 0;
      Gpt_GucStartTimerSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if((Gpt_GucStartTimerSeqCnt == LucSeqNo) && (Gpt_GddChannel == Channel) &&
        (Gpt_GddValue == Value))
      {
        LblStepResult = STEP_PASSED;
      }
      Gpt_GucStartTimerCount = 0;
      Gpt_GucStartTimerSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {

      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestGpt_SetMode() */

/*******************************************************************************
**                         Gpt_StopTimer()                                    **
*******************************************************************************/
void Gpt_StopTimer( Gpt_ChannelType Channel )
{
  #ifndef TYPICAL_CONFIG
  Gpt_GddChannel = Channel;
  Gpt_GucStopTimerCount++;
  App_GucApiSeqCnt++;
  Gpt_GucStopTimerSeqCnt = App_GucApiSeqCnt;
  #endif
}

/*******************************************************************************
**                        TestGpt_StopTimer()                                 **
*******************************************************************************/
boolean TestGpt_StopTimer(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, Gpt_ChannelType Channel)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Gpt_GucStopTimerCount == 1) && (Gpt_GddChannel == Channel))
      {
        LblStepResult = STEP_PASSED;
      }
      Gpt_GucStopTimerCount = 0;
      Gpt_GucStopTimerSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if((Gpt_GucStopTimerSeqCnt == LucSeqNo) && (Gpt_GddChannel == Channel))
      {
        LblStepResult = STEP_PASSED;
      }
      Gpt_GucStopTimerCount = 0;
      Gpt_GucStopTimerSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {

      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestGpt_SetMode() */

#endif
#ifdef DLT_MODULE_ACTIVE
/*******************************************************************************
**                         Gpt_StopTimer()                                    **
*******************************************************************************/
void Gpt_EnableNotification(Gpt_ChannelType Channel)
{
  #ifndef TYPICAL_CONFIG
  Gpt_GddDltChannel = Channel;
  Gpt_GucEnableNotiCount++;
  #endif
}

/*******************************************************************************
**                        TestGpt_StopTimer()                                 **
*******************************************************************************/
boolean TestGpt_EnableNotification(App_DataValidateType LucDataValidate,
 Gpt_ChannelType Channel)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Gpt_GucEnableNotiCount == 1) && (Gpt_GddDltChannel == Channel))
      {
        LblStepResult = STEP_PASSED;
      }
      Gpt_GucEnableNotiCount = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      break;
    } /* End case S_VALIDATE_SEQ: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {

      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestGpt_SetMode() */
#endif

/*******************************************************************************
**                        TestGpt_StartTimer()                                **
*******************************************************************************/
boolean TestGpt_StartTimer(App_DataValidateType LucDataValidate,
  Gpt_ChannelType Channel, Gpt_ValueType Value)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Gpt_GucStartTimerCount == 1) && (Gpt_GddChannel == Channel) &&
        (Gpt_GddValue == Value))
      {
        LblStepResult = STEP_PASSED;
      }
      Gpt_GucStartTimerCount = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      break;
    } /* End case S_VALIDATE_SEQ: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {

      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestGpt_StartTimer() */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
