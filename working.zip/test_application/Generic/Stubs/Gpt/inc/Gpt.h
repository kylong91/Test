/*******************************************************************************
** (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,          **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Gpt.h                                                         **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR GPT Module                                            **
**                                                                            **
**  PURPOSE   : Provision of AUTOSAR GPT Types and extern datatypes           **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef GPT_H
#define GPT_H

/*******************************************************************************
**                      Include Section                                      **
*******************************************************************************/
#include "Std_Types.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define GPT_AR_RELEASE_MAJOR_VERSION         0x04
#define GPT_AR_RELEASE_MINOR_VERSION         0x00
#define GPT_AR_RELEASE_REVISION_VERSION      0x03

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/

#define GptChannelConfigSet0 &Gpt_GaaConfig[0]
#define GptChannelConfigSet1 &Gpt_GaaConfig[1]

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
typedef struct STag_Gpt_ConfigType
{
  uint8 dummy;
}Gpt_ConfigType;

extern const Gpt_ConfigType Gpt_GaaConfig[2];
extern uint8 Gpt_GucConfigData;
typedef enum 
{
  GPT_MODE_NORMAL,
  GPT_MODE_SLEEP
}Gpt_ModeType;
typedef uint16 Gpt_ChannelType;
typedef uint32 Gpt_ValueType;

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern void Gpt_Init(const Gpt_ConfigType *ConfigPtr);
extern void Gpt_SetMode(Gpt_ModeType Mode);
extern void Gpt_EnableWakeup( Gpt_ChannelType Channel );
extern void Gpt_StopTimer( Gpt_ChannelType Channel );
extern void Gpt_StartTimer(Gpt_ChannelType Channel, Gpt_ValueType Value);
extern Gpt_ValueType Gpt_GetTimeElapsed(Gpt_ChannelType Channel);
extern void Gpt_EnableNotification(Gpt_ChannelType Channel);

extern void App_TestGptPrepareData(Gpt_ValueType Value);
extern void TestGpt_DefaultBehavior(void);
extern boolean TestGpt_GetTimeElapsed(App_DataValidateType LucDataValidate, 
  Gpt_ChannelType ExpChannel);
extern boolean TestEcuMGpt_StartTimer(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, Gpt_ChannelType Channel, Gpt_ValueType Value);
extern boolean TestGpt_Init(App_DataValidateType LucDataValidate, 
  uint8 LucData);
extern boolean TestGpt_SetMode(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, Gpt_ModeType Mode);
extern boolean TestGpt_EnableWakeup(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, Gpt_ChannelType Channel);
extern boolean TestGpt_StopTimer(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, Gpt_ChannelType Channel);
extern boolean TestGpt_EnableNotification(App_DataValidateType LucDataValidate, 
  Gpt_ChannelType Channel);
extern boolean TestGpt_StartTimer(App_DataValidateType LucDataValidate, 
  Gpt_ChannelType ExpChannel, Gpt_ValueType ExpValue);

#endif  /* GPT_H */

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
