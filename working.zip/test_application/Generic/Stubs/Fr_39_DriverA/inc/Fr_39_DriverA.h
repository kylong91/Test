/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Fr_DriverA.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Fr_DriverA Stub                                       **
**                                                                            **
**  PURPOSE   : Declaration of Fr_DriverA Stub functions                      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/

#ifndef FR_DRIVERA_H
#define FR_DRIVERA_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
/*
 * This header file includes all the standard data types, platform dependent
 * header file and common return types
 */
#include "Std_Types.h"
#include "Fr_GeneralTypes.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define FR_AR_RELEASE_MAJOR_VERSION      0x04
#define FR_AR_RELEASE_MINOR_VERSION      0x00
#define FR_AR_RELEASE_REVISION_VERSION   0x03

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/*
 * Defining the structure to store the parameters of Det Report Error function
 */


/*******************************************************************************
**               Function Prototypes  for FR Driver A                         **
*******************************************************************************/
extern Std_ReturnType Fr_39_DriverA_ControllerInit(uint8 Fr_CtrlIdx);
extern uint16 Fr_39_DriverA_GetMacroticksPerCycle(uint8 Fr_CtrlIdx);
extern Std_ReturnType Fr_39_DriverA_SetAbsoluteTimer(uint8 Fr_CtrlIdx,
  uint8 FrIf_AbsTimerIdx, uint8 FrIf_Cycle, uint16 FrIf_Offset);
extern Std_ReturnType Fr_39_DriverA_EnableAbsoluteTimerIRQ(uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx);
extern Std_ReturnType Fr_39_DriverA_AckAbsoluteTimerIRQ(uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx);
extern Std_ReturnType Fr_39_DriverA_StartCommunication(uint8 Fr_CtrlIdx);
extern Std_ReturnType Fr_39_DriverA_HaltCommunication (uint8 Fr_CtrlIdx);
extern Std_ReturnType Fr_39_DriverA_AbortCommunication (uint8 Fr_CtrlIdx);
extern Std_ReturnType Fr_39_DriverA_SetWakeupChannel(uint8 Fr_CtrlIdx, Fr_ChannelType Fr_ChnlIdx);
extern Std_ReturnType Fr_39_DriverA_SendWUP(uint8 Fr_CtrlIdx);
extern Std_ReturnType Fr_39_DriverA_GetPOCStatus(uint8 Fr_CtrlIdx,Fr_POCStatusType* FrIf_POCStatusPtr);
extern Std_ReturnType Fr_39_DriverA_GetGlobalTime(uint8 Fr_CtrlIdx,uint8* FrIf_CyclePtr, uint16* FrIf_MacroTickPtr);
extern Std_ReturnType Fr_39_DriverA_AllowColdstart(uint8 Fr_CtrlIdx);
extern Std_ReturnType Fr_39_DriverA_CancelAbsoluteTimer(uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx);
extern Std_ReturnType Fr_39_DriverA_CancelAbsoluteTimerIRQ(uint8 Fr_CtrlIdx,uint8 Fr_AbsTimerIdx);
extern Std_ReturnType Fr_39_DriverA_DisableAbsoluteTimerIRQ(uint8 Fr_CtrlIdx,uint8 Fr_AbsTimerIdx);
extern Std_ReturnType Fr_39_DriverA_GetAbsoluteTimerIRQStatus(uint8 Fr_CtrlIdx,uint8 Fr_AbsTimerIdx, boolean* FrIf_IRQStatusPtr);
extern Std_ReturnType Fr_39_DriverA_AllSlots(uint8 Fr_CtrlIdx);				   
extern Std_ReturnType Fr_39_DriverA_GetChannelStatus(uint8 Fr_CtrlIdx,uint16* FrIf_ChannelAStatusPtr, uint16* FrIf_ChannelBStatusPtr);
extern Std_ReturnType Fr_39_DriverA_GetClockCorrection(uint8 Fr_CtrlIdx, sint16* FrIf_RateCorrectionPtr, sint32* FrIf_OffsetCorrectionPtr);	
extern Std_ReturnType Fr_39_DriverA_GetSyncFrameList(uint8 Fr_CtrlIdx,uint8 Fr_ListSize,
  uint16* FrIf_ChannelAEvenListPtr, uint16* FrIf_ChannelBEvenListPtr,
  uint16* FrIf_ChannelAOddListPtr, uint16* FrIf_ChannelBOddListPtr);
extern Std_ReturnType Fr_39_DriverA_GetNumOfStartupFrames(uint8 Fr_CtrlIdx,
  uint8* FrIf_NumOfStartupFramesPtr);								
extern Std_ReturnType Fr_39_DriverA_GetWakeupRxStatus(uint8 Fr_CtrlIdx,
  uint8* FrIf_WakeupRxStatusPtr);
extern Std_ReturnType Fr_39_DriverA_CancelTxLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx);
extern Std_ReturnType Fr_39_DriverA_DisableLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx);
extern Std_ReturnType Fr_39_DriverA_ReconfigLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx,uint16 Fr_FrameId, Fr_ChannelType Fr_ChnlIdx, uint8 Fr_CycleRepetition, uint8 Fr_CycleOffset, uint8 Fr_PayloadLength,  uint16 Fr_HeaderCRC );
extern Std_ReturnType Fr_39_DriverA_GetNmVector(uint8 Fr_CtrlIdx, uint8* Fr_NmVectorPtr);
extern Std_ReturnType Fr_39_DriverA_TransmitTxLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx, P2CONST(uint8,AUTOMATIC,FRIF_APPL_DATA)Fr_LSduPtr,uint8 Fr_LSduLength);														
extern Std_ReturnType Fr_39_DriverA_ReceiveRxLPdu(uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx, 
  P2VAR(uint8,AUTOMATIC,FRIF_APPL_DATA)Fr_LSduPtr, 
  P2VAR(Fr_RxLPduStatusType,AUTOMATIC,FRIF_APPL_DATA)Fr_LPduStatusPtr, 
  P2VAR(uint8,AUTOMATIC,FRIF_APPL_DATA)Fr_LSduLengthPtr);
extern Std_ReturnType Fr_39_DriverA_CheckTxLPduStatus(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx, P2VAR(Fr_TxLPduStatusType,AUTOMATIC,FRIF_APPL_DATA)Fr_TxLPduStatusPtr);
extern Std_ReturnType Fr_39_DriverA_PrepareLPdu(uint8 Fr_CtrlIdx,uint16 Fr_LPduIdx);
extern Std_ReturnType Fr_39_DriverA_ReadCCConfig(uint8 Fr_CtrlIdx,
  uint8 FrIf_CCLLParamIndex, uint32* FrIf_CCLLParamValue);
extern boolean Test_Fr_39_DriverACancelTxLPdu(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx);

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
  
extern boolean TestFr_39_DriverADisableLPdu(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx);

extern Std_ReturnType TestFr_39_DriverAControllerInit(App_DataValidateType 
                                              LddDataValidate,uint8 Fr_CtrlIdx);

extern boolean TestFr_39_DriverAAckAbsoluteTimerIRQ(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx);
  
extern boolean TestFr_39_DriverAAllowColdstart(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx);
  
extern boolean TestFr_39_DriverAAbortCommunication(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx);
  
extern boolean TestFr_39_DriverACancelAbsoluteTimer(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx);

extern boolean TestFr_39_DriverADisableAbsoluteTimerIRQ(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx);
  
extern boolean TestFr_39_DriverAEnableAbsoluteTimerIRQ(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx);
  
extern boolean TestFr_39_DriverAGetAbsoluteTimerIRQStatus(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx, 
  boolean* FrIf_IRQStatusPtr);
  
extern boolean TestFr_39_DriverAGetGlobalTime(App_DataValidateType LddDataValidate,
uint8 Fr_CtrlIdx,uint8* FrIf_CyclePtr, uint16* FrIf_MacroTickPtr);

extern boolean TestFr_39_DriverAGetPOCStatus(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, Fr_POCStatusType* FrIf_POCStatusPtr);
  
extern boolean TestFr_39_DriverAHaltCommunication(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx);
  
extern boolean TestFr_39_DriverASendWUP(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx);

extern Std_ReturnType TestFr_39_DriverASetAbsoluteTimer(App_DataValidateType 
  LddDataValidate, uint8 Fr_CtrlIdx, uint8 FrIf_AbsTimerIdx, uint8 FrIf_Cycle,
  uint16 FrIf_Offset);
  
extern boolean TestFr_39_DriverASetWakeupChannel(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx,
  Fr_ChannelType Fr_ChnlIdx);
  
extern boolean TestFr_39_DriverAStartCommunication(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx);
  
extern boolean TestFr_39_DriverAAllSlots(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx);

extern boolean TestFr_39_DriverAGetChannelStatus(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx);
    
extern boolean TestFr_39_DriverAGetClockCorrection(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx,
  sint16* FrIf_RateCorrectionPtr, sint32* FrIf_OffsetCorrectionPtr);
  
extern boolean TestFr_39_DriverAGetNmVector(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint8* Fr_NmVectorPtr);

extern boolean TestFr_39_DriverAGetNumOfStartupFrames(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, uint8* FrIf_NumOfStartupFramesPtr);
  
extern boolean TestFr_39_DriverAGetSyncFrameList(
  App_DataValidateType LddDataValidate,uint8 Fr_CtrlIdx,uint8 Fr_ListSize,
  uint16* FrIf_ChannelAEvenListPtr, uint16* FrIf_ChannelBEvenListPtr,
  uint16* FrIf_ChannelAOddListPtr, uint16* FrIf_ChannelBOddListPtr);
  
extern boolean TestFr_39_DriverAGetWakeupRxStatus(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, uint8* FrIf_WakeupRxStatusPtr);
  
extern boolean TestFr_39_DriverAReadCCConfig(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint8 FrIf_CCLLParamIndex,
  uint32* FrIf_CCLLParamValue);

extern boolean TestFr_39_DriverAReconfigLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx, uint16 Fr_FrameId,
  Fr_ChannelType Fr_ChnlIdx, uint8 Fr_CycleRepetition, uint8 Fr_CycleOffset,
  uint8 Fr_PayloadLength, uint16 Fr_HeaderCRC);
  
extern boolean TestFr_39_DriverACheckTxLPduStatus(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint16 Fr_LpduIdx,
  Fr_TxLPduStatusType* FrTxLPduStatusPtr);
  
extern boolean TestFr_39_DriverAPrepareLPdu(App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx);

#endif /* End FR_DRIVERA_H */  
/*******************************************************************************
**                      End of Function Prototypes                            **
*******************************************************************************/
