/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Fr_DriverA.c                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Fr_DriverA Stub                                       **
**                                                                            **
**  PURPOSE   : This application file contains the Fr_DriverA Stub functions  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Fr_39_DriverA.h"
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

  uint8 Fr_GucDrvACtrlIdx;
  uint8 Fr_GucDrvAStartCommunication;
  uint8 Fr_GucDrvAHaltCommunication;
  uint8 Fr_GucDrvAAbortCommunication;
  uint8 Fr_GucDrvAAllowColdstart;
  uint8 Fr_GucDrvAAllSlots;
  uint8 Fr_GucDrvAControllerInit;
  uint8 Fr_GucDrvAAbsTimerIdx;
  uint8 Fr_GucDrvAcycle;
  uint16 Fr_GusDrvAOffset;
  uint8 Fr_GucDrvAAbsoluteTimer;
  uint8 Fr_GucDrvAEnableAbsoluteTimerIRQ;
  boolean* Fr_GpDrvAIRQStatusPtr;
  Fr_ChannelType Fr_GddDrvAChnlIdx;
  uint8 Fr_GucDrvASetWakeupChannel;
  uint8 Fr_GucDrvASendWUP;
  FrTrcv_TrcvModeType Fr_GddDrvATrcvMode;
  uint8 Fr_GucDrvASetTransceiverMode;
  uint8 Fr_GucDrvATransceivermodecount;
  uint8 Fr_GucDrvAGetChannelStatus;
  uint16* Fr_GpDrvAChannelAStatusPtr;
  uint16* Fr_GpDrvAChannelBStatusPtr;
  sint16* Fr_GpDrvARateCorrectionPtr;
  sint32* Fr_GpDrvAOffsetCorrectionPtr;
  uint8 Fr_GucDrvAGetClockCorrection;
  uint8 Fr_GucDrvAListSize;
  uint16* Fr_GpDrvAChannelAEvenListPtr;
  uint16* Fr_GpDvrAChannelBEvenListPtr;
  uint16* Fr_GpDrvAChannelAOddListPtr;
  uint16* Fr_GpDrvAChannelBOddListPtr;
  uint8 Fr_GucDrvAGetSyncFrameList;
  uint8* Fr_GpDrvANumOfStartupFramesPtr;
  uint8 Fr_GucDrvAGetNumOfStartupFrames;
  uint16 Fr_GusDrvALPduIdx=0; 
  uint8 Fr_GucDrvADisableLPdu;
  uint8* Fr_GpDrvAWakeupRxStatusPtr;
  uint8 Fr_GucDrvAGetWakeupRxStatus;
  uint16 Fr_GusDrvAFrameId;
  uint8 Fr_GucDrvACycleRepetition; 
  uint8 Fr_GucDrvACycleOffset;
  uint8 Fr_GucDrvAPayloadLength;
  uint16 Fr_GusDrvAHeaderCRC;
  uint8 Fr_GucDrvAReconfigLPdu;
  uint8* Fr_GpDrvANmVectorPtr;
  uint8 Fr_GucDrvAGetNmVector;
  uint8 Fr_GucDrvAConfigParamIdx;
  uint32* Fr_GpDrvAConfigParamValuePtr;
  uint8 Fr_GucDrvAReadCCConfig;
  Fr_POCStatusType* Fr_GpDrvAPOCStatusPtr; 
  uint8 Fr_GucDrvAGetPOCStatus;
  uint8* Fr_GpDrvACyclePtr;
  uint16* Fr_GpDrvAMacroTickPtr;
  uint8 Fr_GucDrvAGetGlobalTime;
  uint8 Fr_GucDrvAAckAbsoluteTimerIRQ;
  uint8 Fr_GucDrvACheckTxLPduStatus;
  uint8 Fr_GucDrvAStartCommunicationRetVal;
  uint8 Fr_GucDrvAHaltCommunicationRetVal;
  uint8 Fr_GucDrvAAbortCommunicationRetVal;
  uint8 Fr_GucDrvASetWakeupChannelRetVal;
  uint8 Fr_GucDrvASendWUPRetVal;
  uint8 Fr_GucDrvAGetPOCStatusRetVal;
  uint8 Fr_GucDrvAGetGlobalTimeRetVal;
  uint8 Fr_GucDrvAAllowColdstartRetVal;
  uint8 Fr_GucDrvAAllSlotsRetVal;
  uint8 Fr_GucDrvASetControllerInitRetVal;
  uint8 Fr_GucDrvAGetClockCorrectionRetVal;
  uint8 Fr_GucDrvAGetChannelStatusRetVal;
  uint8 Fr_GucDrvAGetSyncFrameListRetVal;
  uint8 Fr_GucDrvAGetNumOfStartupFramesRetVal;
  uint8 Fr_GucDrvAGetWakeupRxStatusRetVal;
  uint8 Fr_GucDrvADisableLPduRetVal;
  uint8 Fr_GucDrvAReconfigLPduRetVal;
  uint8 Fr_GucDrvAGetNmVectorRetVal;
  uint8 Fr_GucDrvAReadCCConfigRetVal;
  uint8 Fr_GucDrvASetAbsoluteTimerRetVal;
  uint8 Fr_GucDrvAEnableAbsoluteTimerIRQRetVal;
  uint8 Fr_GucDrvAAckAbsoluteTimerIRQRetVal;
  uint8 Fr_GucDrvACheckTxLPduStatusRetVal;
  uint8 Fr_GucDrvACancelAbsoluteTimerRetVal;
  uint8 Fr_GucDrvAGetAbsoluteTimerIRQRetVal;
  uint8 Fr_GucDrvADisableAbsoluteTimerIRQRetVal;
  Fr_TxLPduStatusType* Fr_GpDrvATxLPduStatusPtr;
  uint8* Fr_GpDrvALSduPtr;
  Fr_RxLPduStatusType* Fr_GpDrvALPduStatusPtr;
  uint8* Fr_GpDrvALSduLengthPtr;
  uint8 Fr_GucDrvALSduLength;
  uint8 Fr_GucDrvAReceiveRxLPdu;
  uint8 Fr_GucDrvATransmitTxLPdu;
  uint8 Fr_GucDrvAPrepareLPdu;
  uint8 Fr_GucDrvAReceiveRxLPduRetVal;
  uint8 Fr_GucDrvATransmitTxLPduRetVal;
  uint8 Fr_GucDrvAPrepareLPduRetVal;
  uint8 Fr_GucDriverACancelTxLPdu;
  
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
**                            Fr_39_DriverAAckAbsoluteTimerIRQ()              **
*******************************************************************************/  
  Std_ReturnType Fr_39_DriverA_AckAbsoluteTimerIRQ(uint8 Fr_CtrlIdx,
  uint8 Fr_AbsTimerIdx)
  {
    Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvAAbsTimerIdx = Fr_AbsTimerIdx;
    Fr_GucDrvAAckAbsoluteTimerIRQ++;
    return(Fr_GucDrvAAckAbsoluteTimerIRQRetVal); 
  }
  void TestFr_39_DriverAAckAbsoluteTimerIRQSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvAAckAbsoluteTimerIRQRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_39_DriverAAckAbsoluteTimerIRQ()             **
*******************************************************************************/
boolean TestFr_39_DriverAAckAbsoluteTimerIRQ(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAAckAbsoluteTimerIRQ == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucDrvAAbsTimerIdx == Fr_AbsTimerIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAAckAbsoluteTimerIRQ = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAAckAbsoluteTimerIRQ == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvAAckAbsoluteTimerIRQ = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 


/*******************************************************************************
**                          Fr_DriverACheckTxLPduStatus()                    **
*******************************************************************************/  
  Std_ReturnType Fr_39_DriverA_CheckTxLPduStatus(uint8 Fr_CtrlIdx,
  uint16 Fr_LpduIdx, Fr_TxLPduStatusType* Fr_TxLPduStatusPtr)
  {
    Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
    Fr_GusDrvALPduIdx = Fr_LpduIdx;
    *Fr_TxLPduStatusPtr = FR_TRANSMITTED;
    
    Fr_GucDrvACheckTxLPduStatus++;
    return(Fr_GucDrvACheckTxLPduStatusRetVal); 
  }
  void TestFr_39_DriverACheckTxLPduStatusSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvACheckTxLPduStatusRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_39_DriverA_CheckTxLPduStatus()              **
*******************************************************************************/
boolean TestFr_39_DriverACheckTxLPduStatus(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint16 Fr_LpduIdx,
  Fr_TxLPduStatusType* FrTxLPduStatusPtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  *FrTxLPduStatusPtr =1;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvACheckTxLPduStatus == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GusDrvALPduIdx == Fr_LpduIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvACheckTxLPduStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvACheckTxLPduStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvACheckTxLPduStatus = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*******************************************************************************
**                          Fr_39_DriverAReceiveRxLPdu()                     **
*******************************************************************************/  
  Std_ReturnType Fr_39_DriverA_ReceiveRxLPdu(uint8 Fr_CtrlIdx, 
  uint16 Fr_LPduIdx, P2VAR(uint8, AUTOMATIC, FRIF_APPL_DATA)Fr_LSduPtr, 
  P2VAR(Fr_RxLPduStatusType, AUTOMATIC, FRIF_APPL_DATA)Fr_LPduStatusPtr, 
  P2VAR(uint8,AUTOMATIC,FRIF_APPL_DATA)Fr_LSduLengthPtr)
  {
    Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
    Fr_GusDrvALPduIdx = Fr_LPduIdx;
    Fr_GpDrvALSduPtr = Fr_LSduPtr;
    Fr_GpDrvALPduStatusPtr = Fr_LPduStatusPtr;
    Fr_GpDrvALSduLengthPtr = Fr_LSduLengthPtr;
    
    Fr_GucDrvAReceiveRxLPdu++;
    return(Fr_GucDrvAReceiveRxLPduRetVal); 
  }
  void TestFr_39_DriverAReceiveRxLPduSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvAReceiveRxLPduRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_39_DriverAReceiveRxLPdu()                  **
*******************************************************************************/
boolean TestFr_39_DriverAReceiveRxLPdu(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx, 
  P2VAR(uint8, AUTOMATIC, FRIF_APPL_DATA)Fr_LSduPtr, 
  P2VAR(Fr_RxLPduStatusType, AUTOMATIC, FRIF_APPL_DATA)Fr_LPduStatusPtr, 
  P2VAR(uint8, AUTOMATIC, FRIF_APPL_DATA)Fr_LSduLengthPtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAReceiveRxLPdu == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GusDrvALPduIdx == Fr_LPduIdx) &&
        (Fr_GpDrvALSduPtr == Fr_LSduPtr) &&
        (Fr_GpDrvALPduStatusPtr == Fr_LPduStatusPtr) &&
        (Fr_GpDrvALSduLengthPtr == Fr_LSduLengthPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAReceiveRxLPdu = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAReceiveRxLPdu == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvAReceiveRxLPdu = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*******************************************************************************
**                          Fr_39_DriverATransmitTxLPdu()                    **
*******************************************************************************/  
  Std_ReturnType Fr_39_DriverA_TransmitTxLPdu(uint8 Fr_CtrlIdx, 
  uint16 Fr_LPduIdx, P2CONST(uint8, AUTOMATIC, FRIF_APPL_DATA)Fr_LSduPtr,
  uint8 Fr_LSduLength)
  {
    Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
    Fr_GusDrvALPduIdx = Fr_LPduIdx;
    Fr_GpDrvALSduPtr = (uint8*) Fr_LSduPtr;
    Fr_GucDrvALSduLength = Fr_LSduLength;
        
    Fr_GucDrvATransmitTxLPdu++;
    return(Fr_GucDrvATransmitTxLPduRetVal); 
  }
  void TestFr_39_DriverATransmitTxLPduSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvATransmitTxLPduRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_39_DriverATransmitTxLPdu()                 **
*******************************************************************************/
boolean TestFr_39_DriverATransmitTxLPdu(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx, 
  P2CONST(uint8, AUTOMATIC, FRIF_APPL_DATA)Fr_LSduPtr,
  uint8 Fr_LSduLength)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvATransmitTxLPdu == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GusDrvALPduIdx == Fr_LPduIdx) &&
        (Fr_GpDrvALSduPtr == Fr_LSduPtr) &&
        (Fr_GucDrvALSduLength == Fr_LSduLength))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvATransmitTxLPdu = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvATransmitTxLPdu == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvATransmitTxLPdu = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*******************************************************************************
**                          Fr_39_DriverAPrepareLPdu()                       **
*******************************************************************************/  
  Std_ReturnType Fr_39_DriverA_PrepareLPdu(uint8 Fr_CtrlIdx,
  uint16 Fr_LPduIdx)
  {
    Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
    Fr_GusDrvALPduIdx = Fr_LPduIdx;    
        
    Fr_GucDrvAPrepareLPdu++;
    return(Fr_GucDrvAPrepareLPduRetVal); 
  }
  void TestFr_39_DriverAPrepareLPduSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvAPrepareLPduRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_39_DriverAPrepareLPdu()                     **
*******************************************************************************/

boolean TestFr_39_DriverAPrepareLPdu(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx,
  uint16 Fr_LPduIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAPrepareLPdu == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GusDrvALPduIdx == Fr_LPduIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAPrepareLPdu = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAPrepareLPdu == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*******************************************************************************
**                     Fr_GetNmVector()                                       **
*******************************************************************************/
Std_ReturnType Fr_39_DriverA_GetNmVector(uint8 Fr_CtrlIdx, uint8* Fr_NmVectorPtr)
{
  Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
  Fr_GpDrvANmVectorPtr = Fr_NmVectorPtr;
  Fr_GucDrvAGetNmVector++;
  return(Fr_GucDrvAGetNmVectorRetVal);
}
void TestFr_39_DriverAGetNmVectorSetBeh(Std_ReturnType LddReturnVal)
{
   Fr_GucDrvAGetNmVectorRetVal = LddReturnVal;
}
/*******************************************************************************
**               TestFr_39_DriverAGetNmVector()                               **
*******************************************************************************/
boolean TestFr_39_DriverAGetNmVector(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint8* Fr_NmVectorPtr)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAGetNmVector == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpDrvANmVectorPtr == Fr_NmVectorPtr)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAGetNmVector = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAGetNmVector == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvAGetNmVector = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*******************************************************************************
**                     Fr_39_DriverAReadCCConfig()                            **
*******************************************************************************/
Std_ReturnType Fr_39_DriverA_ReadCCConfig(uint8 Fr_CtrlIdx,
  uint8 FrIf_CCLLParamIndex, uint32* FrIf_CCLLParamValue)
{ 
  Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
  Fr_GucDrvAConfigParamIdx = FrIf_CCLLParamIndex;
  Fr_GpDrvAConfigParamValuePtr = FrIf_CCLLParamValue;
  Fr_GucDrvAReadCCConfig++;
  return(Fr_GucDrvAReadCCConfigRetVal);
}
void TestFr_39_DriverAReadCCConfigSetBeh(Std_ReturnType LddReturnVal)
{
   Fr_GucDrvAReadCCConfigRetVal = LddReturnVal;
}
/*******************************************************************************
**               TestFr_39_DriverAReadCCConfig()                              **
*******************************************************************************/
boolean TestFr_39_DriverAReadCCConfig (App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint8 FrIf_CCLLParamIndex,
  uint32* FrIf_CCLLParamValue) 
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAReadCCConfig == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucDrvAConfigParamIdx == FrIf_CCLLParamIndex) &&
        (Fr_GpDrvAConfigParamValuePtr == FrIf_CCLLParamValue)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAReadCCConfig = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAReadCCConfig == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvAReadCCConfig = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*******************************************************************************
**                     Fr_ReconfigLPdu()                                      **
*******************************************************************************/
Std_ReturnType Fr_39_DriverA_ReconfigLPdu(uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx, 
  uint16 Fr_FrameId, Fr_ChannelType Fr_ChnlIdx, uint8 Fr_CycleRepetition, 
  uint8 Fr_CycleOffset, uint8 Fr_PayloadLength, uint16 Fr_HeaderCRC)
{
  Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
  Fr_GusDrvALPduIdx = Fr_LPduIdx;
  Fr_GusDrvAFrameId = Fr_FrameId;
  Fr_GddDrvAChnlIdx = Fr_ChnlIdx;
  Fr_GucDrvACycleRepetition = Fr_CycleRepetition;
  Fr_GucDrvACycleOffset = Fr_CycleOffset;
  Fr_GucDrvAPayloadLength = Fr_PayloadLength;
  Fr_GusDrvAHeaderCRC = Fr_HeaderCRC;
  Fr_GucDrvAReconfigLPdu++;
  return(Fr_GucDrvAReconfigLPduRetVal);
}
void TestFr_39_DriverAReconfigLPduSetBeh(Std_ReturnType LddReturnVal)
{
   Fr_GucDrvAReconfigLPduRetVal = LddReturnVal;
}
/*******************************************************************************
**               TestFr_39_ReconfigLPdu()                                     **
*******************************************************************************/
boolean TestFr_39_DriverAReconfigLPdu(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx, uint16 Fr_FrameId,
  Fr_ChannelType Fr_ChnlIdx, uint8 Fr_CycleRepetition, uint8 Fr_CycleOffset,
  uint8 Fr_PayloadLength, uint16 Fr_HeaderCRC)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAReconfigLPdu == 0x01) &&
        (Fr_GusDrvALPduIdx == Fr_LPduIdx) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) && 
        (Fr_GusDrvAFrameId == Fr_FrameId) &&
        (Fr_GddDrvAChnlIdx == Fr_ChnlIdx) && 
        (Fr_GucDrvACycleRepetition == Fr_CycleRepetition) &&
        (Fr_GucDrvACycleOffset == Fr_CycleOffset) &&
        (Fr_GucDrvAPayloadLength == Fr_PayloadLength) &&
        (Fr_GusDrvAHeaderCRC == Fr_HeaderCRC))
        {
        LblStepResult = STEP_PASSED;
        }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvATransceivermodecount = 0;
      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAReconfigLPdu = 0;
      break;
    }
     /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAReconfigLPdu == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvAReconfigLPdu = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*******************************************************************************
**                            Fr_39_DriverAStartCommunication()               **
*******************************************************************************/
Std_ReturnType Fr_39_DriverA_StartCommunication(uint8 Fr_CtrlIdx)
{
  
    Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvAStartCommunication++;
    return(Fr_GucDrvAStartCommunicationRetVal);
}  
void TestFr_39_DriverAStartCommunicationSetBeh(uint8 LddReturnVal)
{
   Fr_GucDrvAStartCommunicationRetVal = LddReturnVal;
}
/*******************************************************************************
**                         TestFr_39_DriverAStartCommunication()              **
*******************************************************************************/
boolean TestFr_39_DriverAStartCommunication(App_DataValidateType LddDataValidate
  , uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAStartCommunication == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAStartCommunication = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAStartCommunication == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*******************************************************************************
**                            Fr_39_DriverAHaltCommunication()               **
*******************************************************************************/
Std_ReturnType Fr_39_DriverA_HaltCommunication(uint8 Fr_CtrlIdx)
{
  
    Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvAHaltCommunication++;
    return(Fr_GucDrvAHaltCommunicationRetVal); 
}
void TestFr_39_DriverAHaltCommunicationSetBeh(Std_ReturnType LddReturnVal)
{
   Fr_GucDrvAHaltCommunicationRetVal = LddReturnVal;
}

/*******************************************************************************
**                         TestFr_39_DriverAHaltCommunication()              **
*******************************************************************************/
boolean TestFr_39_DriverAHaltCommunication(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAHaltCommunication == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAHaltCommunication = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAHaltCommunication == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvAHaltCommunication = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*******************************************************************************
**                            Fr_39_DriverAAbortCommunication()               **
*******************************************************************************/
Std_ReturnType Fr_39_DriverA_AbortCommunication(uint8 Fr_CtrlIdx)
{
  Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
  Fr_GucDrvAAbortCommunication++;
  return(Fr_GucDrvAAbortCommunicationRetVal);
}
void TestFr_39_DriverAAbortCommunicationSetBeh(Std_ReturnType LddReturnVal)
{
   Fr_GucDrvAAbortCommunicationRetVal = LddReturnVal;
}

/*******************************************************************************
**                         TestFr_39_DriverAAbortCommunication()              **
*******************************************************************************/
boolean TestFr_39_DriverAAbortCommunication(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAAbortCommunication == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAAbortCommunication = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAAbortCommunication == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvAAbortCommunication = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*******************************************************************************
**                            Fr_39_DriverAGetMacroticksPerCycle()       **
*******************************************************************************/
uint16 Fr_39_DriverA_GetMacroticksPerCycle(uint8 Fr_CtrlIdx)
{
Fr_GucDrvACtrlIdx = Fr_CtrlIdx;

return 294; 
}

/*******************************************************************************
**                            Fr_39_DriverAAllowColdstart()                   **
*******************************************************************************/
Std_ReturnType Fr_39_DriverA_AllowColdstart(uint8 Fr_CtrlIdx)
{
  Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
  Fr_GucDrvAAllowColdstart++;
  return(Fr_GucDrvAAllowColdstartRetVal); 
}
void TestFr_39_DriverAAllowColdstartSetBeh(Std_ReturnType LddReturnVal)
{
   Fr_GucDrvAAllowColdstartRetVal = LddReturnVal;
}
/*******************************************************************************
**                         TestFr_39_DriverAAllowColdstart()                  **
*******************************************************************************/
boolean TestFr_39_DriverAAllowColdstart(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAAllowColdstart == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAAllowColdstart = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAAllowColdstart == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvAAllowColdstart = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*******************************************************************************
**                            Fr_39_DriverAAllSlots()                         **
*******************************************************************************/
Std_ReturnType Fr_39_DriverA_AllSlots(uint8 Fr_CtrlIdx)
{
  Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
  Fr_GucDrvAAllSlots++;
  return(Fr_GucDrvAAllSlotsRetVal);
}
void TestFr_39_DriverAAllSlotsSetBeh(Std_ReturnType LddReturnVal)
{
   Fr_GucDrvAAllSlotsRetVal = LddReturnVal;
}
/*******************************************************************************
**                         TestFr_39_DriverAAllSlots()                  **
*******************************************************************************/
boolean TestFr_39_DriverAAllSlots(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAAllSlots == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAAllSlots = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAAllSlots == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvAAllSlots = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*******************************************************************************
**                            Fr_39_DriverAControllerInit()                   **
*******************************************************************************/
Std_ReturnType Fr_39_DriverA_ControllerInit(uint8 Fr_CtrlIdx)
  {
    Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvAControllerInit++;
    return(Fr_GucDrvASetControllerInitRetVal);
  }
void TestFr_39_DriverASetControllerInitSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvASetControllerInitRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_39_DriverAControllerInit()                  **
*******************************************************************************/
boolean TestFr_39_DriverAControllerInit(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAControllerInit == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAControllerInit = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAControllerInit == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvAControllerInit = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*******************************************************************************
**                            Fr_39_DriverASetAbsoluteTime()                  **
*******************************************************************************/
Std_ReturnType Fr_39_DriverA_SetAbsoluteTimer(uint8 Fr_CtrlIdx,uint8 
  Fr_AbsTimerIdx, uint8 Fr_Cycle, uint16 Fr_Offset)
  {
    Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvAAbsTimerIdx = Fr_AbsTimerIdx;
    Fr_GucDrvAcycle = Fr_Cycle;
    Fr_GusDrvAOffset = Fr_Offset;
    Fr_GucDrvAAbsoluteTimer++;
    return(Fr_GucDrvASetAbsoluteTimerRetVal); 
  }
void TestFr_39_DriverASetAbsoluteTimerSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvASetAbsoluteTimerRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_39_DriverASetAbsoluteTimer()                **
*******************************************************************************/
boolean TestFr_39_DriverASetAbsoluteTimer(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx, uint8 Fr_Cycle, uint16 Fr_Offset)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAAbsoluteTimer == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucDrvAAbsTimerIdx == Fr_AbsTimerIdx) &&
        (Fr_GucDrvAcycle == Fr_Cycle) &&
        (Fr_GusDrvAOffset == Fr_Offset))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAAbsoluteTimer = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAAbsoluteTimer == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvAAbsoluteTimer = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 

/*****************************************************************************
**                            Fr_39_DriverAEnableAbsoluteTimerIRQ()           **
*******************************************************************************/
Std_ReturnType Fr_39_DriverA_EnableAbsoluteTimerIRQ(uint8 Fr_CtrlIdx,
  uint8 Fr_AbsTimerIdx)
  {
    Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvAAbsTimerIdx = Fr_AbsTimerIdx;
    Fr_GucDrvAEnableAbsoluteTimerIRQ++;
    return(Fr_GucDrvAEnableAbsoluteTimerIRQRetVal);
  }
void TestFr_39_DriverAEnableAbsoluteTimerIRQSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvAEnableAbsoluteTimerIRQRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_39_DriverAEnableAbsoluteTimerIRQ()          **
*******************************************************************************/
boolean TestFr_39_DriverAEnableAbsoluteTimerIRQ(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAEnableAbsoluteTimerIRQ == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucDrvAAbsTimerIdx == Fr_AbsTimerIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAEnableAbsoluteTimerIRQ = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAEnableAbsoluteTimerIRQ == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvAEnableAbsoluteTimerIRQ = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*******************************************************************************
**                            Fr_39_DriverACancelAbsoluteTimer()              **
*******************************************************************************/  
  Std_ReturnType Fr_39_DriverA_CancelAbsoluteTimer(uint8 Fr_CtrlIdx,
  uint8 Fr_AbsTimerIdx)
  {
    Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvAAbsTimerIdx = Fr_AbsTimerIdx;
    Fr_GucDrvAEnableAbsoluteTimerIRQ++;
    return(Fr_GucDrvACancelAbsoluteTimerRetVal);
  }
void TestFr_39_DriverACancelAbsoluteTimerSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvACancelAbsoluteTimerRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_39_DriverACancelAbsoluteTimer()             **
*******************************************************************************/
boolean TestFr_39_DriverACancelAbsoluteTimer(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAEnableAbsoluteTimerIRQ == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucDrvAAbsTimerIdx == Fr_AbsTimerIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAEnableAbsoluteTimerIRQ = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAEnableAbsoluteTimerIRQ == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvAEnableAbsoluteTimerIRQ = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*******************************************************************************
**                            Fr_39_DriverAGetAbsoluteTimerIRQStatus()        **
*******************************************************************************/ 
  Std_ReturnType Fr_39_DriverA_GetAbsoluteTimerIRQStatus(uint8 Fr_CtrlIdx,
  uint8 Fr_AbsTimerIdx, boolean* FrIf_IRQStatusPtr)
  {
    Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvAAbsTimerIdx = Fr_AbsTimerIdx;
    Fr_GpDrvAIRQStatusPtr = FrIf_IRQStatusPtr;
    Fr_GucDrvAEnableAbsoluteTimerIRQ++;
    return(Fr_GucDrvAGetAbsoluteTimerIRQRetVal);
  }
void TestFr_39_DriverAGetAbsoluteTimerIRQStatusSetBeh(
  Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvAGetAbsoluteTimerIRQRetVal = LddReturnVal;
  }
/*******************************************************************************
**                     TestFr_39_DriverAGetAbsoluteTimerIRQStatus()           **
*******************************************************************************/
boolean TestFr_39_DriverAGetAbsoluteTimerIRQStatus(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx, 
  boolean* FrIf_IRQStatusPtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAEnableAbsoluteTimerIRQ == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucDrvAAbsTimerIdx == Fr_AbsTimerIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAEnableAbsoluteTimerIRQ = 0;
      *FrIf_IRQStatusPtr =0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAEnableAbsoluteTimerIRQ == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvAEnableAbsoluteTimerIRQ = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} 
/*******************************************************************************
**                            Fr_39_DriverADisableAbsoluteTimerIRQ()   **
*******************************************************************************/ 
  Std_ReturnType Fr_39_DriverA_DisableAbsoluteTimerIRQ(uint8 Fr_CtrlIdx,
  uint8 Fr_AbsTimerIdx)
  {
    Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvAAbsTimerIdx = Fr_AbsTimerIdx;
    Fr_GucDrvAEnableAbsoluteTimerIRQ++;
    return(Fr_GucDrvADisableAbsoluteTimerIRQRetVal);
  }
void TestFr_39_DriverADisableAbsoluteTimerIRQSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvADisableAbsoluteTimerIRQRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_39_DriverADisableAbsoluteTimerIRQ()  **
*******************************************************************************/
boolean TestFr_39_DriverADisableAbsoluteTimerIRQ(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx, uint8 Fr_AbsTimerIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAEnableAbsoluteTimerIRQ == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GucDrvAAbsTimerIdx == Fr_AbsTimerIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAEnableAbsoluteTimerIRQ = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAEnableAbsoluteTimerIRQ == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvAEnableAbsoluteTimerIRQ = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
 
/*******************************************************************************
**                            Fr_39_DriverASetWakeupChannel()                 **
*******************************************************************************/  
  Std_ReturnType Fr_39_DriverA_SetWakeupChannel(uint8 Fr_CtrlIdx,
    Fr_ChannelType Fr_ChnlIdx)
  {
    Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
    Fr_GddDrvAChnlIdx = Fr_ChnlIdx;
    Fr_GucDrvASetWakeupChannel++;
    return(Fr_GucDrvASetWakeupChannelRetVal);
  }
  void TestFr_39_DriverASetWakeupChannelSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvASetWakeupChannelRetVal = LddReturnVal;
  }

/*******************************************************************************
**                         TestFr_39_DriverASetWakeupChannel()                **
*******************************************************************************/
boolean TestFr_39_DriverASetWakeupChannel(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx,
  Fr_ChannelType Fr_ChnlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if(( Fr_GucDrvASetWakeupChannel == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GddDrvAChnlIdx == Fr_ChnlIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvASetWakeupChannel = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvASetWakeupChannel == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}   
/*******************************************************************************
**                            Fr_39_DriverASendWUP()                          **
*******************************************************************************/ 
  
  Std_ReturnType Fr_39_DriverA_SendWUP(uint8 Fr_CtrlIdx)
  {
    Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvASendWUP++;
    return(Fr_GucDrvASendWUPRetVal);
  }
  void TestFr_39_DriverASendWUPSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvASendWUPRetVal = LddReturnVal;
  }
  
/*******************************************************************************
**                         TestFr_39_DriverASendWUP()                         **
*******************************************************************************/
boolean TestFr_39_DriverASendWUP(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvASendWUP == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvASendWUP = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvASendWUP == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Fr_GucDrvASendWUP = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}  
  
/*******************************************************************************
**                            Fr_39_DriverAGetPOCStatus()                     **
*******************************************************************************/  
  Std_ReturnType Fr_39_DriverA_GetPOCStatus(uint8 Fr_CtrlIdx,
    Fr_POCStatusType* FrIf_POCStatusPtr)
  {
    Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
    Fr_GpDrvAPOCStatusPtr = FrIf_POCStatusPtr;
    Fr_GucDrvAGetPOCStatus++;
    return(Fr_GucDrvAGetPOCStatusRetVal);    
  }
  void TestFr_39_DriverAGetPOCStatusSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvAGetPOCStatusRetVal = LddReturnVal;
  }
  
/*******************************************************************************
**                         TestFr_39_DriverAGetPOCStatus()              **
*******************************************************************************/
boolean TestFr_39_DriverAGetPOCStatus(App_DataValidateType LddDataValidate,
  uint8 Fr_CtrlIdx, Fr_POCStatusType* FrIf_POCStatusPtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAGetPOCStatus == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpDrvAPOCStatusPtr == FrIf_POCStatusPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAGetPOCStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAGetPOCStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
/*******************************************************************************
**                            Fr_39_DriverAGetGlobalTime()                    **
*******************************************************************************/
  Std_ReturnType Fr_39_DriverA_GetGlobalTime(uint8 Fr_CtrlIdx,
    uint8* FrIf_CyclePtr, uint16* FrIf_MacroTickPtr)
  {
    Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
    Fr_GpDrvACyclePtr = FrIf_CyclePtr;
    Fr_GpDrvAMacroTickPtr = FrIf_MacroTickPtr;
    Fr_GucDrvAGetGlobalTime++;
    return(Fr_GucDrvAGetGlobalTimeRetVal);
  }
  void TestFr_39_DriverAGetGlobalTimeSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvAGetGlobalTimeRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_39_DriverAGetGlobalTime()                   **
*******************************************************************************/
boolean TestFr_39_DriverAGetGlobalTime(App_DataValidateType LddDataValidate,
uint8 Fr_CtrlIdx,uint8* FrIf_CyclePtr, uint16* FrIf_MacroTickPtr)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAGetGlobalTime == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpDrvACyclePtr == FrIf_CyclePtr) &&
        (Fr_GpDrvAMacroTickPtr == FrIf_MacroTickPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAGetGlobalTime = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAGetGlobalTime == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
  
/*******************************************************************************
**                            Fr_39_DriverA_GetChannelStatus()                **
*******************************************************************************/
Std_ReturnType Fr_39_DriverA_GetChannelStatus(uint8 Fr_CtrlIdx,
  uint16* FrIf_ChannelAStatusPtr, uint16* FrIf_ChannelBStatusPtr)
{ 
  Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
  Fr_GpDrvAChannelAStatusPtr = FrIf_ChannelAStatusPtr;
  Fr_GpDrvAChannelBStatusPtr = FrIf_ChannelBStatusPtr;
  Fr_GucDrvAGetChannelStatus++;
  return(Fr_GucDrvAGetChannelStatusRetVal);
}
void TestFr_39_DriverAGetChannelStatusSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvAGetChannelStatusRetVal = LddReturnVal;
  }

/*******************************************************************************
**                            TestFr_39_DriverAGetChannelStatus()             **
*******************************************************************************/
  boolean TestFr_39_DriverAGetChannelStatus(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx)
  {
    boolean LblStepResult;

    LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAGetChannelStatus == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAGetChannelStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAGetChannelStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
/*******************************************************************************
**                            Fr_39_DriverAGetClockCorrection()               **
*******************************************************************************/
Std_ReturnType Fr_39_DriverA_GetClockCorrection(uint8 Fr_CtrlIdx,
  sint16* FrIf_RateCorrectionPtr, sint32* FrIf_OffsetCorrectionPtr)
  {
    Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
    Fr_GpDrvARateCorrectionPtr = FrIf_RateCorrectionPtr;
    Fr_GpDrvAOffsetCorrectionPtr = FrIf_OffsetCorrectionPtr;
    Fr_GucDrvAGetClockCorrection++;
    return(Fr_GucDrvAGetClockCorrectionRetVal);
  }
void TestFr_39_DriverAGetClockCorrectionSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvAGetClockCorrectionRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_39_DriverAGetClockCorrection()              **
*******************************************************************************/ 
boolean TestFr_39_DriverAGetClockCorrection(
  App_DataValidateType LddDataValidate, uint8 Fr_CtrlIdx,
  sint16* FrIf_RateCorrectionPtr, sint32* FrIf_OffsetCorrectionPtr)
{
    boolean LblStepResult;

    LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAGetClockCorrection == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpDrvARateCorrectionPtr == FrIf_RateCorrectionPtr) &&
        (Fr_GpDrvAOffsetCorrectionPtr == FrIf_OffsetCorrectionPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAGetClockCorrection = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAGetClockCorrection == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}   

/*******************************************************************************
**                            Fr_39_DriverAGetSyncFrameList()                 **
*******************************************************************************/
Std_ReturnType Fr_39_DriverA_GetSyncFrameList(uint8 Fr_CtrlIdx,uint8 Fr_ListSize,
  uint16* FrIf_ChannelAEvenListPtr, uint16* FrIf_ChannelBEvenListPtr,
  uint16* FrIf_ChannelAOddListPtr, uint16* FrIf_ChannelBOddListPtr)
  {
    Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
    Fr_GucDrvAListSize = Fr_ListSize;
    Fr_GpDrvAChannelAEvenListPtr = FrIf_ChannelAEvenListPtr;
    Fr_GpDvrAChannelBEvenListPtr = FrIf_ChannelBEvenListPtr;
    Fr_GpDrvAChannelAOddListPtr = FrIf_ChannelAOddListPtr;
    Fr_GpDrvAChannelBOddListPtr = FrIf_ChannelBOddListPtr;
    Fr_GucDrvAGetSyncFrameList++;
    return(Fr_GucDrvAGetSyncFrameListRetVal);
  }
void TestFr_39_DriverAGetSyncFrameListSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvAGetSyncFrameListRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_39_DriverAGetSyncFrameList()                **
*******************************************************************************/ 
boolean TestFr_39_DriverAGetSyncFrameList(App_DataValidateType LddDataValidate, 
  uint8 Fr_CtrlIdx,uint8 Fr_ListSize,
  uint16* FrIf_ChannelAEvenListPtr, uint16* FrIf_ChannelBEvenListPtr,
  uint16* FrIf_ChannelAOddListPtr, uint16* FrIf_ChannelBOddListPtr)
{
    boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAGetSyncFrameList == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpDrvAChannelAEvenListPtr == FrIf_ChannelAEvenListPtr) &&
        (Fr_GpDvrAChannelBEvenListPtr == FrIf_ChannelBEvenListPtr) &&
        (Fr_GucDrvAListSize == Fr_ListSize) &&
        (Fr_GpDrvAChannelAOddListPtr == FrIf_ChannelAOddListPtr) &&
        (Fr_GpDrvAChannelBOddListPtr == FrIf_ChannelBOddListPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAGetSyncFrameList = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAGetSyncFrameList == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}   
/*******************************************************************************
**                            Fr_39_DriverAGetNumOfStartupFrames()            **
*******************************************************************************/
Std_ReturnType Fr_39_DriverA_GetNumOfStartupFrames(uint8 Fr_CtrlIdx,
  uint8* FrIf_NumOfStartupFramesPtr)
{
  Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
  Fr_GpDrvANumOfStartupFramesPtr = FrIf_NumOfStartupFramesPtr;
  Fr_GucDrvAGetNumOfStartupFrames++;
  return(Fr_GucDrvAGetNumOfStartupFramesRetVal);
}
void TestFr_39_DriverAGetNumOfStartupFramesSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvAGetNumOfStartupFramesRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_39_DriverAGetNumOfStartupFrames()           **
*******************************************************************************/ 
boolean TestFr_39_DriverAGetNumOfStartupFrames(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, uint8* FrIf_NumOfStartupFramesPtr)
{
    boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAGetNumOfStartupFrames == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpDrvANumOfStartupFramesPtr == FrIf_NumOfStartupFramesPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAGetNumOfStartupFrames = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAGetNumOfStartupFrames == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*******************************************************************************
**                            Fr_39_DriverADisableLPdu()                      **
*******************************************************************************/
Std_ReturnType Fr_39_DriverA_DisableLPdu(uint8 Fr_CtrlIdx,
  uint16 Fr_LPduIdx)
{
  Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
  Fr_GusDrvALPduIdx = Fr_LPduIdx;
  Fr_GucDrvADisableLPdu++;
  return(Fr_GucDrvADisableLPduRetVal);
}
void TestFr_39_DriverADisableLPduSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvADisableLPduRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_39_DriverADisableLPdu()                     **
*******************************************************************************/ 
boolean TestFr_39_DriverADisableLPdu(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx)
{
    boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvADisableLPdu == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GusDrvALPduIdx == Fr_LPduIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvADisableLPdu = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvADisableLPdu == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}   
/*******************************************************************************
**                            Fr_39_DriverAGetWakeupRxStatus()                **
*******************************************************************************/
Std_ReturnType Fr_39_DriverA_GetWakeupRxStatus(uint8 Fr_CtrlIdx,
  uint8* FrIf_WakeupRxStatusPtr)
{
  Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
  Fr_GpDrvAWakeupRxStatusPtr = FrIf_WakeupRxStatusPtr;
  Fr_GucDrvAGetWakeupRxStatus++;
  return(Fr_GucDrvAGetWakeupRxStatusRetVal);
  }
void TestFr_39_DriverAGetWakeupRxStatusSetBeh(Std_ReturnType LddReturnVal)
  {
    Fr_GucDrvAGetWakeupRxStatusRetVal = LddReturnVal;
  }
/*******************************************************************************
**                         TestFr_39_DriverAGetWakeupRxStatus()               **
*******************************************************************************/ 
boolean TestFr_39_DriverAGetWakeupRxStatus(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, 
  uint8* FrIf_WakeupRxStatusPtr)
{
  boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDrvAGetWakeupRxStatus == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GpDrvAWakeupRxStatusPtr == FrIf_WakeupRxStatusPtr))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDrvAGetWakeupRxStatus = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDrvAGetWakeupRxStatus == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}

/*******************************************************************************
**                         Fr_39_DriverA_CancelTxLPdu()                       **
*******************************************************************************/
Std_ReturnType Fr_39_DriverA_CancelTxLPdu(uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx)
{
  Fr_GucDrvACtrlIdx = Fr_CtrlIdx;
  Fr_GusDrvALPduIdx = Fr_LPduIdx;
  Fr_GucDriverACancelTxLPdu++;
  return E_OK;
}

/*******************************************************************************
**                         Test_Fr_39_DriverACancelTxLPdu()                   **
*******************************************************************************/
boolean Test_Fr_39_DriverACancelTxLPdu(App_DataValidateType
  LddDataValidate, uint8 Fr_CtrlIdx, uint16 Fr_LPduIdx)
{
  boolean LblStepResult;
    LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Fr_GucDriverACancelTxLPdu == 0x01) &&
        (Fr_GucDrvACtrlIdx == Fr_CtrlIdx) &&
        (Fr_GusDrvALPduIdx == Fr_LPduIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Fr_GucDriverACancelTxLPdu = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Fr_GucDriverACancelTxLPdu == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
}
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
