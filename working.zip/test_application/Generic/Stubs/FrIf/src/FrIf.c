/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: FrIf.c                                                        **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Flexray Interface                                     **
**                                                                            **
**  PURPOSE   : This application file contains the FrIf stub functions        **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By         Description                             **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M    Initial version                         **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "FrIf.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#ifdef FRNM_MODULE_ACTIVE
uint8 FrIf_GaaCntrlId[255];
uint8 FrIf_GaaCycle[64];
#endif

#ifdef FRNM_MODULE_ACTIVE
PduIdType FrIf_GaaFrTxPduId[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaSduLength[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaTransmitData[FRIF_ARRAY_SIZE][FRIF_DATA_LENGTH];
Std_ReturnType FrIf_GddTransmitReturn;
Std_ReturnType FrIf_GddCancelTransmitReturn;
uint8 FrIf_GucTransmitCount;
uint8 FrIf_GucTransmitCheckCount;
PduIdType FrIf_GddPduIdForRet;
#endif
#ifdef FRNM_MODULE_ACTIVE
uint8 FrIf_GucGetGlobalTimeCount;
uint8 FrIf_GucGetGlobalTimeCheckCount;
uint8 FrIf_GucCycleNumber;
uint8 FrIf_Agg_vector[FRIF_GNETWORK_MANAGEMENT_VECTORLENGTH]; 
uint8 FrIf_GucGetNmVectorCnt;
uint8 FrIf_GaaCtrlId[8];
Std_ReturnType FrIf_GddGetGlbReturnVal;
#endif
#ifdef BSWM_MODULE_ACTIVE
uint8 FrIf_GucInitCnt;
uint8 FrIf_GucInitSeqCnt;
#endif

#ifdef FRSM_MODULE_ACTIVE
uint8 FrIf_GaaAllowCSCtrlIdx[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaCtrlInitCtrlIdx[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaSendWUPCtrlIdx[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaAllSlotsCtrlIdx[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaStrtComCtrlIdx[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaHltComCtrlIdx[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaSetStateClstIdx[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaStateTransition[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaSetWupChnlCtrlIdx[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaSetWupChnlIdx[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaClrTrcvrWupCtrlIdx[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaClrTrcvrWupChnlIdx[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaGetPOCCtrlIdx[FRIF_ARRAY_SIZE];
Fr_POCStatusType FrIf_GaaGetPOCStatus[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaGetNumStrFrmsCtrlIdx[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaGetNumStrFrms[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaGetWakeupRxCtrlIdx[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaWakeupRxStatus[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaSetTrncMdeCtrlIdx[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaSetTrncMdeChnlIdx[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaSetTrncMdeType[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaGetTrncWURsnCtrlIdx[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaGetTrncWURsnChnlIdx[FRIF_ARRAY_SIZE];
FrTrcv_TrcvWUReasonType FrIf_GaaTrncWURsn[FRIF_ARRAY_SIZE][0x02];

uint8 FrIf_GucAllowCSCount;
uint8 FrIf_GucAllowCSCheckCount;
uint8 FrIf_GucCtrlInitCount;
uint8 FrIf_GucCtrlInitCheckCount;
uint8 FrIf_GucSenWUPCount;
uint8 FrIf_GucSenWUPCheckCount;
uint8 FrIf_GucAllSlotsCount;
uint8 FrIf_GucAllSlotsCheckCount;
uint8 FrIf_GucStrtComCount;
uint8 FrIf_GucStrtComCheckCount;
uint8 FrIf_GucHltComCount;
uint8 FrIf_GucHltComCheckCount;
uint8 FrIf_GucSetStateCount;
uint8 FrIf_GucSetStateCheckCount;
uint8 FrIf_GucSetWupChnlCount;
uint8 FrIf_GucSetWupChnlcheckCount;
uint8 FrIf_GucClrTrcvrWupCount;
uint8 FrIf_GucClrTrcvrWupCheckCount;
uint8 FrIf_GucGetPOCStatusCount;
uint8 FrIf_GucGetPOCStatusCheckCount;
uint8 FrIf_GucGetNumStrFrmsCount;
uint8 FrIf_GucGetNumStrFrmsCheckCount;
uint8 FrIf_GucWakeupRxCount;
uint8 FrIf_GucWakeupRxCheckCount;
uint8 FrIf_GucSetTrncMdeCount;
uint8 FrIf_GucSetTrncMdeCheckCount;
uint8 FrIf_GucGetTrncWURsnCount;
uint8 FrIf_GucGetTrncWURsnCheckCount;

Std_ReturnType FrIf_GddReturnVal;
#endif

#ifdef FRTP_MODULE_ACTIVE
PduIdType FrIf_GaaFrTxPduId[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaSduLength[FRIF_ARRAY_SIZE];
uint8 FrIf_GaaTransmitData[FRIF_ARRAY_SIZE][FRIF_DATA_LENGTH];
Std_ReturnType FrIf_GddTransmitReturn;
Std_ReturnType FrIf_GddCancelTransmitReturn;
uint8 FrIf_GucTransmitCount;
uint8 FrIf_GucCancelTransmitCount;
uint8 FrIf_GucTransmitCheckCount;
PduIdType FrIf_GddPduIdForRet;
boolean FrIf_GblDecoupled;
#endif
/*******************************************************************************
**                       TestFrIf_DefaultBehavior()                           **
*******************************************************************************/
void TestFrIf_DefaultBehavior(void)
{
  #ifdef BSWM_MODULE_ACTIVE
  FrIf_GucInitCnt = 0;
  FrIf_GucInitSeqCnt = 0;
  #endif
  
  #ifdef FRNM_MODULE_ACTIVE
  FrIf_GddTransmitReturn = E_OK;
  FrIf_GucTransmitCount = 0;
  FrIf_GucTransmitCheckCount = 0;
  FrIf_GddPduIdForRet = (PduIdType)0xFFFF;
  #endif
  
  #ifdef FRNM_MODULE_ACTIVE
  FrIf_GucCycleNumber = 0;
  uint8 LucCount;
  FrIf_GddGetGlbReturnVal = E_OK;
  #endif
  #ifdef FRSM_MODULE_ACTIVE
  uint8 LucCount;
  FrIf_GddReturnVal = E_OK;
  FrIf_GucAllowCSCount = 0;
  FrIf_GucAllowCSCheckCount = 0;
  FrIf_GucCtrlInitCount = 0;
  FrIf_GucCtrlInitCheckCount = 0;
  FrIf_GucSenWUPCount = 0;
  FrIf_GucSenWUPCheckCount = 0;
  FrIf_GucAllSlotsCount = 0;
  FrIf_GucAllSlotsCheckCount = 0;
  FrIf_GucStrtComCount = 0;
  FrIf_GucStrtComCheckCount = 0;
  FrIf_GucHltComCount = 0;
  FrIf_GucHltComCheckCount = 0;
  FrIf_GucSetStateCount = 0;
  FrIf_GucSetStateCheckCount = 0;
  FrIf_GucSetWupChnlCount = 0;
  FrIf_GucSetWupChnlcheckCount = 0;
  FrIf_GucClrTrcvrWupCount = 0;
  FrIf_GucClrTrcvrWupCheckCount = 0;
  FrIf_GucGetPOCStatusCount = 0;
  FrIf_GucGetPOCStatusCheckCount = 0;
  FrIf_GucGetNumStrFrmsCount = 0;
  FrIf_GucGetNumStrFrmsCheckCount = 0;
  FrIf_GucWakeupRxCount = 0;
  FrIf_GucWakeupRxCheckCount = 0;
  FrIf_GucSetTrncMdeCount = 0;
  FrIf_GucSetTrncMdeCheckCount = 0;
  FrIf_GucGetTrncWURsnCount = 0;
  FrIf_GucGetTrncWURsnCheckCount = 0;
  for(LucCount = 0; LucCount <= FRIF_ARRAY_SIZE; LucCount++)
  {
    FrIf_GaaGetPOCStatus[LucCount].Freeze = FALSE;
    FrIf_GaaGetPOCStatus[LucCount].SlotMode = FR_SLOTMODE_ALL;
    FrIf_GaaGetPOCStatus[LucCount].State = FR_POCSTATE_READY;
    FrIf_GaaGetPOCStatus[LucCount].WakeupStatus = FR_WAKEUP_UNDEFINED;
    FrIf_GaaGetNumStrFrms[LucCount] = 0x0A;
  }
  #endif
  
  #ifdef FRNM_MODULE_ACTIVE
  FrIf_GucGetGlobalTimeCount = 0;
  FrIf_GucGetGlobalTimeCheckCount = 0;
  FrIf_GucCycleNumber = 0;
  for(LucCount = 0; LucCount < FRIF_GNETWORK_MANAGEMENT_VECTORLENGTH; 
    LucCount++)
  {
    FrIf_Agg_vector[LucCount] = 0;
  }
 
 FrIf_GucGetNmVectorCnt = 0;
 
 for(LucCount = 0; LucCount <= FRIF_ARRAY_SIZE; LucCount++)
 {
   FrIf_GaaCtrlId[LucCount] = 255;
 }  
  #endif
 
  #ifdef FRTP_MODULE_ACTIVE
  FrIf_GddTransmitReturn = E_OK;
  FrIf_GddCancelTransmitReturn = E_OK;
  FrIf_GucTransmitCount = 0;
  FrIf_GucCancelTransmitCount = 0;
  FrIf_GucTransmitCheckCount = 0;
  FrIf_GddPduIdForRet = (PduIdType)0xFFFF;
  FrIf_GblDecoupled = FALSE;
  #endif
} /* End TestFrIf_DefaultBehavior() */


#ifdef FRTP_MODULE_ACTIVE
/*******************************************************************************
**                     TestSetFrIf_TxPduIdForRet()                           **
*******************************************************************************/
void TestSetFrIf_TxPduIdForRet(PduIdType LddPduIdForRet)
{
  FrIf_GddPduIdForRet = LddPduIdForRet;
} /* TestSetFrIf_TxPduIdForRet */
/*******************************************************************************
**                     TestSetFrIf_TransmitForDec()                        **
*******************************************************************************/
void TestSetFrIf_TransmitForDec(boolean LblDecoupled)
{
  FrIf_GblDecoupled = LblDecoupled;
} /* End TestSetFrIf_TxPduIdForRet() */

/*******************************************************************************
**                              FrIf_Transmit()                              **
*******************************************************************************/
Std_ReturnType FrIf_Transmit(PduIdType FrTxPduId,
const PduInfoType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8* LpSduDataPtr;

  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  FrIf_GaaFrTxPduId[FrIf_GucTransmitCount] = FrTxPduId;
  FrIf_GaaSduLength[FrIf_GucTransmitCount] = (uint8) PduInfoPtr->SduLength;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  if(FrIf_GblDecoupled == FALSE)
  {
    /*Check whether SduLength is exceeding the DATA_LENGTH limit */
    if(PduInfoPtr->SduLength > FRIF_DATA_LENGTH)
    {
      LucDataLength = FRIF_DATA_LENGTH;
    }
    else
    {
      LucDataLength = (uint8) PduInfoPtr->SduLength;
    }
    /* Copy the actual data into global array from actual SduDataPtr */
    for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
    {
      FrIf_GaaTransmitData[FrIf_GucTransmitCount][LucDataIndex] =
        *LpSduDataPtr;
      LpSduDataPtr++;
    }
  }
  /* Increment count variable to handle multiple invocations */
  if(FrIf_GucTransmitCount != FRIF_ARRAY_SIZE)
  {
    FrIf_GucTransmitCount++;
  }
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((FrIf_GddPduIdForRet == FrTxPduId) ||
    (FrIf_GddTransmitReturn == E_NOT_OK))
  {
    FrIf_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif
  #endif
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(FrIf_GddTransmitReturn);
  #endif
} /* End FrIf_Transmit() */

/*******************************************************************************
**                            TestFrIf_Transmit()                            **
*******************************************************************************/
boolean TestFrIf_Transmit(App_DataValidateType LucDataValidate,
PduIdType ExpFrTxPduId, const PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrIf_GucTransmitCount == 0x01) &&
        (ExpFrTxPduId == FrIf_GaaFrTxPduId[0]))
      {
        ActPduInfo.SduLength = FrIf_GaaSduLength[0];
        ActPduInfo.SduDataPtr = &FrIf_GaaTransmitData[0][0];

        if(FrIf_GblDecoupled == FALSE)
        {
          /* Validate SduLength and Data */
          if(FrIfTest_ValidateData((PduInfoType *)ExpPduInfoPtr, &ActPduInfo))
          {
            LblRetValue = STEP_PASSED;
          }
        }
        else
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucTransmitCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }

    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((FrIf_GucTransmitCheckCount <= FrIf_GucTransmitCount) &&
        (ExpFrTxPduId == FrIf_GaaFrTxPduId[FrIf_GucTransmitCheckCount]))
      {
        ActPduInfo.SduLength =
          FrIf_GaaSduLength[FrIf_GucTransmitCheckCount];
        ActPduInfo.SduDataPtr =
          &FrIf_GaaTransmitData[FrIf_GucTransmitCheckCount][0];

        if(FrIf_GblDecoupled == FALSE)
        {
          /* Validate the SduLength and Data */
          if(FrIfTest_ValidateData((PduInfoType *)ExpPduInfoPtr, &ActPduInfo))
          {
            LblRetValue = STEP_PASSED;
          }
        }
        else
        {
          LblRetValue = STEP_PASSED;
        }
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucTransmitCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucTransmitCheckCount == FrIf_GucTransmitCount)
      {
        FrIf_GucTransmitCount = 0;
        FrIf_GucTransmitCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */

    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrIf_GucTransmitCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpFrTxPduId == FrIf_GaaFrTxPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrIf_Transmit() */

/*******************************************************************************
**                       FrIfTest_ValidateData()                             **
*******************************************************************************/
boolean FrIfTest_ValidateData(PduInfoType* LddExpPduInfo,
PduInfoType* LddActPduInfo)
{
  uint8 *LpActualDataPtr;
  uint8 *LpExpDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  LddSduCount = LddExpPduInfo->SduLength;
  LpExpDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  if((LddExpPduInfo->SduLength <= FRIF_DATA_LENGTH) &&
    (LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }
  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    if(*LpActualDataPtr != *LpExpDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualDataPtr++;
    LpExpDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* End FrIfTest_ValidateData() */


/*******************************************************************************
**                          TestFrIf_TransmitSetRetVal()                           **
*******************************************************************************/
void TestFrIf_TransmitSetRetVal(Std_ReturnType LddRetVal)
{
  FrIf_GddTransmitReturn = LddRetVal;
}/* End TestFrIf_TransmitSetRetVal() */

/*******************************************************************************
**                              FrIf_CancelTransmit()                              **
*******************************************************************************/
Std_ReturnType FrIf_CancelTransmit(PduIdType FrTxPduId)
{
  #ifndef TYPICAL_CONFIG
    /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  FrIf_GaaFrTxPduId[FrIf_GucCancelTransmitCount] = FrTxPduId;
  /* Increment count variable to handle multiple invocations */
  if(FrIf_GucCancelTransmitCount != FRIF_ARRAY_SIZE)
  {    
    FrIf_GucCancelTransmitCount++;
  }
  return(FrIf_GddCancelTransmitReturn);
  #endif
} /* End FrIf_CancelTransmit() */

/*******************************************************************************
**                            TestFrIf_CancelTransmit()                            **
*******************************************************************************/
boolean TestFrIf_CancelTransmit(App_DataValidateType LucDataValidate,
  PduIdType ExpFrTxPduId)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrIf_GucCancelTransmitCount == 0x01) && 
        (ExpFrTxPduId == FrIf_GaaFrTxPduId[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucCancelTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrIf_CancelTransmit() */
#endif

#ifdef BSWM_MODULE_ACTIVE
/*******************************************************************************
**                          FrIf_Init()                                       **
*******************************************************************************/
void FrIf_Init(const FrIf_ConfigType* FrIf_ConfigPtr)
{
	UNUSED(FrIf_ConfigPtr);
  App_GucApiSeqCnt++;
	FrIf_GucInitSeqCnt = App_GucApiSeqCnt;
	FrIf_GucInitCnt++;
}/* End FrIf_Init() */

/*******************************************************************************
**                           TestFrIf_Init()                                  **
*******************************************************************************/
boolean TestFrIf_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(FrIf_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      FrIf_GucInitCnt = 0;
      FrIf_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(FrIf_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      FrIf_GucInitCnt = 0;
      FrIf_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFrIf_Init() */
#endif



#ifdef FRNM_MODULE_ACTIVE
/*******************************************************************************
**                     TestSetFrIf_TxPduIdForRet()                            **
*******************************************************************************/
void TestSetFrIf_TxPduIdForRet(PduIdType LddPduIdForRet)
{
  FrIf_GddPduIdForRet = LddPduIdForRet;
} /* End TestSetFrIf_TxPduIdForRet() */

/*******************************************************************************
**                              FrIf_Transmit()                               **
*******************************************************************************/
Std_ReturnType FrIf_Transmit(PduIdType FrTxPduId,
const PduInfoType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8* LpSduDataPtr;
  
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  FrIf_GaaFrTxPduId[FrIf_GucTransmitCount] = FrTxPduId;
  FrIf_GaaSduLength[FrIf_GucTransmitCount] = PduInfoPtr->SduLength;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > FRIF_DATA_LENGTH)
  {
    LucDataLength = FRIF_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->SduLength;
  }
  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    FrIf_GaaTransmitData[FrIf_GucTransmitCount][LucDataIndex] = 
      *LpSduDataPtr;
    LpSduDataPtr++;
  }
  /* Increment count variable to handle multiple invocations */
  if(FrIf_GucTransmitCount != FRIF_ARRAY_SIZE)
  {    
    FrIf_GucTransmitCount++;
  }
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((FrIf_GddPduIdForRet == FrTxPduId) ||
    (FrIf_GddTransmitReturn == E_NOT_OK))
  {
    FrIf_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif  
  #endif
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(FrIf_GddTransmitReturn);
  #endif
} /* End FrIf_Transmit() */

/*******************************************************************************
**                            TestFrIf_Transmit()                             **
*******************************************************************************/
void FrIf_GucTransmitCountClear (void)
{

  FrIf_GucTransmitCount = 0x00;
  
}  

boolean TestFrIf_Transmit(App_DataValidateType LucDataValidate,
PduIdType ExpFrTxPduId, const PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrIf_GucTransmitCount == 0x01) && 
        (ExpFrTxPduId == FrIf_GaaFrTxPduId[0]))
      {
        ActPduInfo.SduLength = FrIf_GaaSduLength[0];
        ActPduInfo.SduDataPtr = &FrIf_GaaTransmitData[0][0];

        /* Validate SduLength and Data */
        if(FrIfTest_ValidateData((PduInfoType *)ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {
     for(FrIf_GucTransmitCheckCount = 0; FrIf_GucTransmitCheckCount <= FrIf_GucTransmitCount; FrIf_GucTransmitCheckCount++)
     {
     
      /* Validating the Sequnce count and ID */
      if(ExpFrTxPduId == FrIf_GaaFrTxPduId[FrIf_GucTransmitCheckCount])
      {
        ActPduInfo.SduLength =
          FrIf_GaaSduLength[FrIf_GucTransmitCheckCount];
        ActPduInfo.SduDataPtr =
          &FrIf_GaaTransmitData[FrIf_GucTransmitCheckCount][0];

        /* Validate the SduLength and Data */
        if(FrIfTest_ValidateData((PduInfoType *)ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
     }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      //FrIf_GucTransmitCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      //if(FrIf_GucTransmitCheckCount == FrIf_GucTransmitCount)
      {
        FrIf_GucTransmitCount = 0;
        FrIf_GucTransmitCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrIf_GucTransmitCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpFrTxPduId == FrIf_GaaFrTxPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrIf_Transmit() */

/*******************************************************************************
**                          TestFrIf_TransmitSetRetVal()                      **
*******************************************************************************/
void TestFrIf_TransmitSetRetVal(Std_ReturnType LddRetVal)
{
  FrIf_GddTransmitReturn = LddRetVal;
}/* End TestFrIf_TransmitSetRetVal() */

/*******************************************************************************
**                       FrIfTest_ValidateData()                              **
*******************************************************************************/
boolean FrIfTest_ValidateData(PduInfoType* LddExpPduInfo, 
PduInfoType* LddActPduInfo)
{
  uint8 *LpActualDataPtr;
  uint8 *LpExpDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  LddSduCount = LddExpPduInfo->SduLength;
  LpExpDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  if((LddExpPduInfo->SduLength <= FRIF_DATA_LENGTH) &&
    (LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }
  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    if(*LpActualDataPtr != *LpExpDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualDataPtr++;
    LpExpDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* End FrIfTest_ValidateData() */
/*******************************************************************************
**                       FrIf_CancelTransmit()                                **
*******************************************************************************/
Std_ReturnType FrIf_CancelTransmit(PduIdType id)
{
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  FrIf_GaaFrTxPduId[FrIf_GucTransmitCount] = id;
  /* Increment count variable to handle multiple invocations */
  if(FrIf_GucTransmitCount != FRIF_ARRAY_SIZE)
  {    
    FrIf_GucTransmitCount++;
  }
  
  #ifdef PDUR_ENABLE_API_RETURN_FOR_PDU
  if((FrIf_GddPduIdForRet == id) ||
    (FrIf_GddCancelTransmitReturn == E_NOT_OK))
  {
    FrIf_GddPduIdForRet = (PduIdType)0xFFFF;
    return(E_NOT_OK);
  }
  else
  {
    return(E_OK);
  }
  #endif
  #ifndef PDUR_ENABLE_API_RETURN_FOR_PDU
  return(FrIf_GddCancelTransmitReturn);
  #endif
}
/*******************************************************************************
**                            TestFrIf_CancelTransmit()                       **
*******************************************************************************/
boolean TestFrIf_CancelTransmit(App_DataValidateType LucDataValidate,
  PduIdType ExpFrIfTxSduId)
{
  boolean LblRetValue;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrIf_GucTransmitCount == 0x01) && 
        (ExpFrIfTxSduId == FrIf_GaaFrTxPduId[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucTransmitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucTransmitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrIf_CancelTransmit() */

/*******************************************************************************
**                          TestFrIf_CancelTransmitSetRetVal()                **
*******************************************************************************/
void TestFrIf_CancelTransmitSetRetVal(Std_ReturnType LddRetVal)
{
  FrIf_GddCancelTransmitReturn = LddRetVal;
}/* End TestFrIf_CancelTransmitSetRetVal() */
#endif

#ifdef FRSM_MODULE_ACTIVE
/*******************************************************************************
**                              FrIf_AllowColdstart()                         **
*******************************************************************************/
Std_ReturnType FrIf_AllowColdstart(uint8 FrIf_CtrlIdx)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual CtrlId into Global variable */
  FrIf_GaaAllowCSCtrlIdx[FrIf_GucAllowCSCount] = FrIf_CtrlIdx;
  if(FrIf_GucAllowCSCount != FRIF_ARRAY_SIZE)
  {
    FrIf_GucAllowCSCount++;
  }
  return(FrIf_GddReturnVal);
  #endif
} /* End FrIf_AllowColdstart() */

/*******************************************************************************
**                            TestFrIf_AllowColdstart()                       **
*******************************************************************************/
boolean TestFrIf_AllowColdstart(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrIf_GucAllowCSCount == 0x01) && 
        (ExpFrIf_CtrlIdx == FrIf_GaaAllowCSCtrlIdx[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucAllowCSCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucAllowCSCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < FrIf_GucAllowCSCount; LucIndex++)
      {
        /* Validate the Controller Id */
        if((ExpFrIf_CtrlIdx == FrIf_GaaAllowCSCtrlIdx[LucIndex]))
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = FrIf_GucAllowCSCount;
        } /* End if(ExpFrIf_CtrlIdx == FrIf_GaaAllowCSCtrlIdx[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < FrIf_GucAllowCSCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucAllowCSCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucAllowCSCheckCount == FrIf_GucAllowCSCount)
      {
        FrIf_GucAllowCSCount = 0;
        FrIf_GucAllowCSCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    /*
     * Case to handle API invocation with multiple occurance (with sequnce)
     * and to validate parameters of the API with what it has been invoked
     */
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((FrIf_GucAllowCSCheckCount <= FrIf_GucAllowCSCount) &&
        (ExpFrIf_CtrlIdx == FrIf_GaaAllowCSCtrlIdx[FrIf_GucAllowCSCheckCount]))
      {
        LblRetValue = STEP_PASSED;
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucAllowCSCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucAllowCSCheckCount == FrIf_GucAllowCSCount)
      {
        FrIf_GucAllowCSCount = 0;
        FrIf_GucAllowCSCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrIf_GucAllowCSCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpFrIf_CtrlIdx == FrIf_GaaAllowCSCtrlIdx[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrIf_AllowColdstart() */

/*******************************************************************************
**                              FrIf_ControllerInit()                         **
*******************************************************************************/
Std_ReturnType FrIf_ControllerInit(uint8 FrIf_CtrlIdx)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual CtrlId into Global variable */
  FrIf_GaaCtrlInitCtrlIdx[FrIf_GucCtrlInitCount] = FrIf_CtrlIdx;
  if(FrIf_GucCtrlInitCount != FRIF_ARRAY_SIZE)
  {
    FrIf_GucCtrlInitCount++;
  }
  return(FrIf_GddReturnVal);
  #endif
} /* End FrIf_ControllerInit() */

/*******************************************************************************
**                            TestFrIf_ControllerInit()                       **
*******************************************************************************/
boolean TestFrIf_ControllerInit(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrIf_GucCtrlInitCount == 0x01) && 
        (ExpFrIf_CtrlIdx == FrIf_GaaCtrlInitCtrlIdx[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucCtrlInitCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucCtrlInitCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < FrIf_GucCtrlInitCount; LucIndex++)
      {
        /* Validate the Controller Id */
        if((ExpFrIf_CtrlIdx ==
          FrIf_GaaCtrlInitCtrlIdx[LucIndex]))
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = FrIf_GucCtrlInitCount;
        } /* End if(ExpFrIf_CtrlIdx == FrIf_GaaCtrlInitCtrlIdx[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < FrIf_GucCtrlInitCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucCtrlInitCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucCtrlInitCheckCount == FrIf_GucCtrlInitCount)
      {
        FrIf_GucCtrlInitCount = 0;
        FrIf_GucCtrlInitCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    /*
     * Case to handle API invocation with multiple occurance (with sequnce)
     * and to validate parameters of the API with what it has been invoked
     */
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((FrIf_GucCtrlInitCheckCount <= FrIf_GucCtrlInitCount) &&
        (ExpFrIf_CtrlIdx == FrIf_GaaCtrlInitCtrlIdx[FrIf_GucCtrlInitCheckCount])
        )
      {
        LblRetValue = STEP_PASSED;
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucCtrlInitCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucCtrlInitCheckCount == FrIf_GucCtrlInitCount)
      {
        FrIf_GucCtrlInitCount = 0;
        FrIf_GucCtrlInitCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrIf_GucCtrlInitCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpFrIf_CtrlIdx == FrIf_GaaCtrlInitCtrlIdx[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrIf_ControllerInit() */

/*******************************************************************************
**                              FrIf_SendWUP()                         **
*******************************************************************************/
Std_ReturnType FrIf_SendWUP(uint8 FrIf_CtrlIdx)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual CtrlId into Global variable */
  FrIf_GaaSendWUPCtrlIdx[FrIf_GucSenWUPCount] = FrIf_CtrlIdx;
  if(FrIf_GucSenWUPCount != FRIF_ARRAY_SIZE)
  {
    FrIf_GucSenWUPCount++;
  }
  return(FrIf_GddReturnVal);
  #endif
} /* End FrIf_SendWUP() */

/*******************************************************************************
**                            TestFrIf_SendWUP()                              **
*******************************************************************************/
boolean TestFrIf_SendWUP(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrIf_GucSenWUPCount == 0x01) && 
        (ExpFrIf_CtrlIdx == FrIf_GaaSendWUPCtrlIdx[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucSenWUPCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucSenWUPCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < FrIf_GucSenWUPCount; LucIndex++)
      {
        /* Validate the Controller Id */
        if((ExpFrIf_CtrlIdx ==
          FrIf_GaaSendWUPCtrlIdx[LucIndex]))
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = FrIf_GucSenWUPCount;
        } /* End if(ExpFrIf_CtrlIdx == FrIf_GaaSendWUPCtrlIdx[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < FrIf_GucSenWUPCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucSenWUPCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucSenWUPCheckCount == FrIf_GucSenWUPCount)
      {
        FrIf_GucSenWUPCount = 0;
        FrIf_GucSenWUPCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    /*
     * Case to handle API invocation with multiple occurance (with sequnce)
     * and to validate parameters of the API with what it has been invoked
     */
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((FrIf_GucSenWUPCheckCount <= FrIf_GucSenWUPCount) &&
        (ExpFrIf_CtrlIdx == FrIf_GaaSendWUPCtrlIdx[FrIf_GucSenWUPCheckCount])
        )
      {
        LblRetValue = STEP_PASSED;
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucSenWUPCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucSenWUPCheckCount == FrIf_GucSenWUPCount)
      {
        FrIf_GucSenWUPCount = 0;
        FrIf_GucSenWUPCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrIf_GucSenWUPCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpFrIf_CtrlIdx == FrIf_GaaSendWUPCtrlIdx[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrIf_SendWUP() */

/*******************************************************************************
**                              FrIf_AllSlots()                               **
*******************************************************************************/
Std_ReturnType FrIf_AllSlots(uint8 FrIf_CtrlIdx)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual CtrlId into Global variable */
  FrIf_GaaAllSlotsCtrlIdx[FrIf_GucAllSlotsCount] = FrIf_CtrlIdx;
  if(FrIf_GucAllSlotsCount != FRIF_ARRAY_SIZE)
  {
    FrIf_GucAllSlotsCount++;
  }
  return(FrIf_GddReturnVal);
  #endif
} /* End FrIf_AllSlots() */

/*******************************************************************************
**                            TestFrIf_AllSlots()                             **
*******************************************************************************/
boolean TestFrIf_AllSlots(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrIf_GucAllSlotsCount == 0x01) && 
        (ExpFrIf_CtrlIdx == FrIf_GaaAllSlotsCtrlIdx[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucAllSlotsCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucAllSlotsCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < FrIf_GucAllSlotsCount; LucIndex++)
      {
        /* Validate the Controller Id */
        if((ExpFrIf_CtrlIdx ==
          FrIf_GaaAllSlotsCtrlIdx[LucIndex]))
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = FrIf_GucAllSlotsCount;
        } /* End if(ExpFrIf_CtrlIdx == FrIf_GaaAllSlotsCtrlIdx[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < FrIf_GucAllSlotsCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucAllSlotsCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucAllSlotsCheckCount == FrIf_GucAllSlotsCount)
      {
        FrIf_GucAllSlotsCount = 0;
        FrIf_GucAllSlotsCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    /*
     * Case to handle API invocation with multiple occurance (with sequnce)
     * and to validate parameters of the API with what it has been invoked
     */
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((FrIf_GucAllSlotsCheckCount <= FrIf_GucAllSlotsCount) &&
        (ExpFrIf_CtrlIdx == FrIf_GaaAllSlotsCtrlIdx[FrIf_GucAllSlotsCheckCount])
        )
      {
        LblRetValue = STEP_PASSED;
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucAllSlotsCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucAllSlotsCheckCount == FrIf_GucAllSlotsCount)
      {
        FrIf_GucAllSlotsCount = 0;
        FrIf_GucAllSlotsCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrIf_GucAllSlotsCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpFrIf_CtrlIdx == FrIf_GaaAllSlotsCtrlIdx[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrIf_AllSlots() */

/*******************************************************************************
**                              FrIf_StartCommunication()                     **
*******************************************************************************/
Std_ReturnType FrIf_StartCommunication(uint8 FrIf_CtrlIdx)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual CtrlId into Global variable */
  FrIf_GaaStrtComCtrlIdx[FrIf_GucStrtComCount] = FrIf_CtrlIdx;
  if(FrIf_GucStrtComCount != FRIF_ARRAY_SIZE)
  {
    FrIf_GucStrtComCount++;
  }
  return(FrIf_GddReturnVal);
  #endif
} /* End FrIf_StartCommunication() */

/*******************************************************************************
**                            TestFrIf_StartCommunication()                   **
*******************************************************************************/
boolean TestFrIf_StartCommunication(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrIf_GucStrtComCount == 0x01) && 
        (ExpFrIf_CtrlIdx == FrIf_GaaStrtComCtrlIdx[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucStrtComCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucStrtComCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < FrIf_GucStrtComCount; LucIndex++)
      {
        /* Validate the Controller Id */
        if((ExpFrIf_CtrlIdx ==
          FrIf_GaaStrtComCtrlIdx[LucIndex]))
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = FrIf_GucStrtComCount;
        } /* End if(ExpFrIf_CtrlIdx == FrIf_GaaStrtComCtrlIdx[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < FrIf_GucStrtComCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucStrtComCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucStrtComCheckCount == FrIf_GucStrtComCount)
      {
        FrIf_GucStrtComCount = 0;
        FrIf_GucStrtComCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    /*
     * Case to handle API invocation with multiple occurance (with sequnce)
     * and to validate parameters of the API with what it has been invoked
     */
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((FrIf_GucStrtComCheckCount <= FrIf_GucStrtComCount) &&
        (ExpFrIf_CtrlIdx == FrIf_GaaStrtComCtrlIdx[FrIf_GucStrtComCheckCount])
        )
      {
        LblRetValue = STEP_PASSED;
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucStrtComCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucStrtComCheckCount == FrIf_GucStrtComCount)
      {
        FrIf_GucStrtComCount = 0;
        FrIf_GucStrtComCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrIf_GucStrtComCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpFrIf_CtrlIdx == FrIf_GaaStrtComCtrlIdx[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrIf_StartCommunication() */

/*******************************************************************************
**                              FrIf_HaltCommunication()                      **
*******************************************************************************/
Std_ReturnType FrIf_HaltCommunication(uint8 FrIf_CtrlIdx)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual CtrlId into Global variable */
  FrIf_GaaHltComCtrlIdx[FrIf_GucHltComCount] = FrIf_CtrlIdx;
  if(FrIf_GucHltComCount != FRIF_ARRAY_SIZE)
  {
    FrIf_GucHltComCount++;
  }
  return(FrIf_GddReturnVal);
  #endif
} /* End FrIf_HaltCommunication() */

/*******************************************************************************
**                            TestFrIf_HaltCommunication()                    **
*******************************************************************************/
boolean TestFrIf_HaltCommunication(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrIf_GucHltComCount == 0x01) && 
        (ExpFrIf_CtrlIdx == FrIf_GaaHltComCtrlIdx[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucHltComCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucHltComCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < FrIf_GucHltComCount; LucIndex++)
      {
        /* Validate the Controller Id */
        if((ExpFrIf_CtrlIdx ==
          FrIf_GaaHltComCtrlIdx[LucIndex]))
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = FrIf_GucHltComCount;
        } /* End if(ExpFrIf_CtrlIdx == FrIf_GaaHltComCtrlIdx[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < FrIf_GucHltComCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucHltComCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucHltComCheckCount == FrIf_GucHltComCount)
      {
        FrIf_GucHltComCount = 0;
        FrIf_GucHltComCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    /*
     * Case to handle API invocation with multiple occurance (with sequnce)
     * and to validate parameters of the API with what it has been invoked
     */
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((FrIf_GucHltComCheckCount <= FrIf_GucHltComCount) &&
        (ExpFrIf_CtrlIdx == FrIf_GaaHltComCtrlIdx[FrIf_GucHltComCheckCount])
        )
      {
        LblRetValue = STEP_PASSED;
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucHltComCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucHltComCheckCount == FrIf_GucHltComCount)
      {
        FrIf_GucHltComCount = 0;
        FrIf_GucHltComCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrIf_GucHltComCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpFrIf_CtrlIdx == FrIf_GaaHltComCtrlIdx[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrIf_HaltCommunication() */

/*******************************************************************************
**                              FrIf_SetState()                         **
*******************************************************************************/
Std_ReturnType FrIf_SetState(uint8 FrIf_ClstIdx, FrIf_StateTransitionType
  FrIf_StateTransition)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual ClstlId into Global variable */
  FrIf_GaaSetStateClstIdx[FrIf_GucSetStateCount] = FrIf_ClstIdx;
  FrIf_GaaStateTransition[FrIf_GucSetStateCount] = FrIf_StateTransition;
  
  if(FrIf_GucSetStateCount != FRIF_ARRAY_SIZE)
  {
    FrIf_GucSetStateCount++;
  }
  return(FrIf_GddReturnVal);
  #endif
} /* End FrIf_SetState() */

/*******************************************************************************
**                            TestFrIf_SetState()                             **
*******************************************************************************/
boolean TestFrIf_SetState(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_ClstIdx, FrIf_StateTransitionType ExpFrIf_StateTransition)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrIf_GucSetStateCount == 0x01) && 
        ((ExpFrIf_ClstIdx == FrIf_GaaSetStateClstIdx[0])&&
        (ExpFrIf_StateTransition == FrIf_GaaStateTransition[0])))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucSetStateCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucSetStateCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < FrIf_GucSetStateCount; LucIndex++)
      {
        /* Validate the Controller Id */
        if((ExpFrIf_ClstIdx ==
          FrIf_GaaSetStateClstIdx[LucIndex]) &&
          (ExpFrIf_StateTransition ==
            FrIf_GaaStateTransition[LucIndex]))
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = FrIf_GucSetStateCount;
        } /* End if(ExpFrIf_ClstIdx == FrIf_GaaSetStateClstIdx[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < FrIf_GucSetStateCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucSetStateCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucSetStateCheckCount == FrIf_GucSetStateCount)
      {
        FrIf_GucSetStateCount = 0;
        FrIf_GucSetStateCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    /*
     * Case to handle API invocation with multiple occurance (with sequnce)
     * and to validate parameters of the API with what it has been invoked
     */
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((FrIf_GucSetStateCheckCount <= FrIf_GucSetStateCount) &&
        (ExpFrIf_ClstIdx == FrIf_GaaSetStateClstIdx[FrIf_GucSetStateCheckCount])
          && (ExpFrIf_StateTransition ==
              FrIf_GaaStateTransition[FrIf_GucSetStateCheckCount]))
      {
        LblRetValue = STEP_PASSED;
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucSetStateCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucSetStateCheckCount == FrIf_GucSetStateCount)
      {
        FrIf_GucSetStateCount = 0;
        FrIf_GucSetStateCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrIf_GucSetStateCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if((ExpFrIf_ClstIdx == FrIf_GaaSetStateClstIdx[LucIndex]) &&
          (ExpFrIf_StateTransition ==
            FrIf_GaaStateTransition[LucIndex]))
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrIf_SetState() */

/*******************************************************************************
**                              FrIf_SetWakeupChannel()                         **
*******************************************************************************/
Std_ReturnType FrIf_SetWakeupChannel(uint8 FrIf_CtrlIdx, Fr_ChannelType
  FrIf_ChnlIdx)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual ClstlId into Global variable */
  FrIf_GaaSetWupChnlCtrlIdx[FrIf_GucSetWupChnlCount] = FrIf_CtrlIdx;
  FrIf_GaaSetWupChnlIdx[FrIf_GucSetWupChnlCount] = FrIf_ChnlIdx;
  
  if(FrIf_GucSetWupChnlCount != FRIF_ARRAY_SIZE)
  {
    FrIf_GucSetWupChnlCount++;
  }
  return(FrIf_GddReturnVal);
  #endif
} /* End FrIf_SetWakeupChannel() */

/*******************************************************************************
**                            TestFrIf_SetWakeupChannel()                     **
*******************************************************************************/
boolean TestFrIf_SetWakeupChannel(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx, Fr_ChannelType ExpFrIf_ChnlIdx)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrIf_GucSetWupChnlCount == 0x01) && 
        ((ExpFrIf_CtrlIdx == FrIf_GaaSetWupChnlCtrlIdx[0])&&
        (ExpFrIf_ChnlIdx == FrIf_GaaSetWupChnlIdx[0])))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucSetWupChnlCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucSetWupChnlCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < FrIf_GucSetWupChnlCount; LucIndex++)
      {
        /* Validate the Controller Id */
        if((ExpFrIf_CtrlIdx ==
          FrIf_GaaSetWupChnlCtrlIdx[LucIndex]) &&
          (ExpFrIf_ChnlIdx ==
            FrIf_GaaSetWupChnlIdx[LucIndex]))
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = FrIf_GucSetWupChnlCount;
        } /* End if(ExpFrIf_CtrlIdx == FrIf_GaaSetWupChnlCtrlIdx[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < FrIf_GucSetWupChnlCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucSetWupChnlcheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucSetWupChnlcheckCount == FrIf_GucSetWupChnlCount)
      {
        FrIf_GucSetWupChnlCount = 0;
        FrIf_GucSetWupChnlcheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    /*
     * Case to handle API invocation with multiple occurance (with sequnce)
     * and to validate parameters of the API with what it has been invoked
     */
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((FrIf_GucSetWupChnlcheckCount <= FrIf_GucSetWupChnlCount) &&
        (ExpFrIf_CtrlIdx == FrIf_GaaSetWupChnlCtrlIdx
        [FrIf_GucSetWupChnlcheckCount])
          && (ExpFrIf_ChnlIdx ==
              FrIf_GaaSetWupChnlIdx[FrIf_GucSetWupChnlcheckCount]))
      {
        LblRetValue = STEP_PASSED;
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucSetWupChnlcheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucSetWupChnlcheckCount == FrIf_GucSetWupChnlCount)
      {
        FrIf_GucSetWupChnlCount = 0;
        FrIf_GucSetWupChnlcheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrIf_GucSetWupChnlCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if((ExpFrIf_CtrlIdx == FrIf_GaaSetWupChnlCtrlIdx[LucIndex]) &&
          (ExpFrIf_ChnlIdx == FrIf_GaaSetWupChnlIdx[LucIndex]))
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrIf_SetWakeupChannel() */

/*******************************************************************************
**                              FrIf_ClearTransceiverWakeup()                 **
*******************************************************************************/
Std_ReturnType FrIf_ClearTransceiverWakeup(uint8 FrIf_CtrlIdx, Fr_ChannelType
  FrIf_ChnlIdx)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual ClstlId into Global variable */
  FrIf_GaaClrTrcvrWupCtrlIdx[FrIf_GucClrTrcvrWupCount] = FrIf_CtrlIdx;
  FrIf_GaaClrTrcvrWupChnlIdx[FrIf_GucClrTrcvrWupCount] = FrIf_ChnlIdx;
  
  if(FrIf_GucClrTrcvrWupCount != FRIF_ARRAY_SIZE)
  {
    FrIf_GucClrTrcvrWupCount++;
  }
  return(FrIf_GddReturnVal);
  #endif
} /* End FrIf_ClearTransceiverWakeup() */

/*******************************************************************************
**                            TestFrIf_ClearTransceiverWakeup()               **
*******************************************************************************/
boolean TestFrIf_ClearTransceiverWakeup(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx, Fr_ChannelType ExpFrIf_ChnlIdx)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrIf_GucClrTrcvrWupCount == 0x01) && 
        ((ExpFrIf_CtrlIdx == FrIf_GaaClrTrcvrWupCtrlIdx[0])&&
        (ExpFrIf_ChnlIdx == FrIf_GaaClrTrcvrWupChnlIdx[0])))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucClrTrcvrWupCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucClrTrcvrWupCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < FrIf_GucClrTrcvrWupCount; LucIndex++)
      {
        /* Validate the Controller Id */
        if((ExpFrIf_CtrlIdx ==
          FrIf_GaaClrTrcvrWupCtrlIdx[LucIndex]) &&
          (ExpFrIf_ChnlIdx ==
            FrIf_GaaClrTrcvrWupChnlIdx[LucIndex]))
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = FrIf_GucClrTrcvrWupCount;
        } /* End if(ExpFrIf_CtrlIdx == FrIf_GaaClrTrcvrWupCtrlIdx[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < FrIf_GucClrTrcvrWupCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucClrTrcvrWupCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucClrTrcvrWupCheckCount == FrIf_GucClrTrcvrWupCount)
      {
        FrIf_GucClrTrcvrWupCount = 0;
        FrIf_GucClrTrcvrWupCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    /*
     * Case to handle API invocation with multiple occurance (with sequnce)
     * and to validate parameters of the API with what it has been invoked
     */
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((FrIf_GucClrTrcvrWupCheckCount <= FrIf_GucClrTrcvrWupCount) &&
        (ExpFrIf_CtrlIdx ==
          FrIf_GaaClrTrcvrWupCtrlIdx[FrIf_GucClrTrcvrWupCheckCount]) &&
          (ExpFrIf_ChnlIdx == 
          FrIf_GaaClrTrcvrWupChnlIdx[FrIf_GucClrTrcvrWupCheckCount]))
      {
        LblRetValue = STEP_PASSED;
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucClrTrcvrWupCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucClrTrcvrWupCheckCount == FrIf_GucClrTrcvrWupCount)
      {
        FrIf_GucClrTrcvrWupCount = 0;
        FrIf_GucClrTrcvrWupCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrIf_GucClrTrcvrWupCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if((ExpFrIf_CtrlIdx == FrIf_GaaClrTrcvrWupCtrlIdx[LucIndex]) &&
          (ExpFrIf_ChnlIdx == FrIf_GaaClrTrcvrWupChnlIdx[LucIndex]))
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrIf_ClearTransceiverWakeup() */

/*******************************************************************************
**                              FrIf_GetPOCStatus()                           **
*******************************************************************************/
Std_ReturnType FrIf_GetPOCStatus(uint8 FrIf_CtrlIdx, Fr_POCStatusType
  *FrIf_POCStatusPtr)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual CtrlId, State, POCstatus into Global variable */
  FrIf_GaaGetPOCCtrlIdx[FrIf_GucGetPOCStatusCount] = FrIf_CtrlIdx;
  FrIf_POCStatusPtr->Freeze = FrIf_GaaGetPOCStatus[FrIf_CtrlIdx].Freeze;
  FrIf_POCStatusPtr->SlotMode = FrIf_GaaGetPOCStatus[FrIf_CtrlIdx].SlotMode;
  FrIf_POCStatusPtr->State = FrIf_GaaGetPOCStatus[FrIf_CtrlIdx].State;
  FrIf_POCStatusPtr->WakeupStatus = FrIf_GaaGetPOCStatus[FrIf_CtrlIdx].
  WakeupStatus;
  
  
  if(FrIf_GucGetPOCStatusCount != FRIF_ARRAY_SIZE)
  {
    FrIf_GucGetPOCStatusCount++;
  }
  return(FrIf_GddReturnVal);
  #endif
} /* End FrIf_GetPOCStatus() */

/*******************************************************************************
**                            TestFrIf_GetPOCStatus()                         **
*******************************************************************************/
boolean TestFrIf_GetPOCStatus(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrIf_GucGetPOCStatusCount == 0x01) && 
        (ExpFrIf_CtrlIdx == FrIf_GaaGetPOCCtrlIdx[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucGetPOCStatusCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucGetPOCStatusCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < FrIf_GucGetPOCStatusCount; LucIndex++)
      {
        /* Validate the Controller Id */
        if(ExpFrIf_CtrlIdx ==
          FrIf_GaaGetPOCCtrlIdx[LucIndex])
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = FrIf_GucGetPOCStatusCount;
        } /* End if(ExpFrIf_CtrlIdx == FrIf_GaaClrTrcvrWupCtrlIdx[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < FrIf_GucGetPOCStatusCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucGetPOCStatusCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucGetPOCStatusCheckCount == FrIf_GucGetPOCStatusCount)
      {
        FrIf_GucGetPOCStatusCount = 0;
        FrIf_GucGetPOCStatusCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    /*
     * Case to handle API invocation with multiple occurance (with sequnce)
     * and to validate parameters of the API with what it has been invoked
     */
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((FrIf_GucGetPOCStatusCheckCount <= FrIf_GucGetPOCStatusCount) &&
        (ExpFrIf_CtrlIdx ==
        FrIf_GaaGetPOCCtrlIdx[FrIf_GucGetPOCStatusCheckCount]))
      {
        LblRetValue = STEP_PASSED;
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucGetPOCStatusCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucGetPOCStatusCheckCount == FrIf_GucGetPOCStatusCount)
      {
        FrIf_GucGetPOCStatusCount = 0;
        FrIf_GucGetPOCStatusCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrIf_GucGetPOCStatusCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpFrIf_CtrlIdx == FrIf_GaaGetPOCCtrlIdx[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrIf_GetPOCStatus() */

/*******************************************************************************
**                              FrIf_GetNumOfStartupFrames()                  **
*******************************************************************************/
Std_ReturnType FrIf_GetNumOfStartupFrames(uint8 FrIf_CtrlIdx,
  uint8 *FrIf_NumOfStartupFramesPtr)
{
  #ifndef TYPICAL_CONFIG  
  /* Load actual CtrlId into Global variable */
  FrIf_GaaGetNumStrFrmsCtrlIdx[FrIf_GucGetNumStrFrmsCount] = FrIf_CtrlIdx;
  *FrIf_NumOfStartupFramesPtr = (uint8)FrIf_GaaGetNumStrFrms[FrIf_CtrlIdx];
  
  if(FrIf_GucGetNumStrFrmsCount != FRIF_ARRAY_SIZE)
  {
    FrIf_GucGetNumStrFrmsCount++;
  }
  return(FrIf_GddReturnVal);
  #endif
} /* End FrIf_GetNumOfStartupFrames() */

/*******************************************************************************
**                            TestFrIf_GetNumOfStartupFrames()                **
*******************************************************************************/
boolean TestFrIf_GetNumOfStartupFrames(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrIf_GucGetNumStrFrmsCount == 0x01) && 
        (ExpFrIf_CtrlIdx == FrIf_GaaGetNumStrFrmsCtrlIdx[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucGetNumStrFrmsCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucGetNumStrFrmsCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < FrIf_GucGetNumStrFrmsCount; LucIndex++)
      {
        /* Validate the Controller Id */
        if(ExpFrIf_CtrlIdx ==
          FrIf_GaaGetNumStrFrmsCtrlIdx[LucIndex])
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = FrIf_GucGetNumStrFrmsCount;
        } /* End if(ExpFrIf_CtrlIdx == FrIf_GaaClrTrcvrWupCtrlIdx[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < FrIf_GucGetNumStrFrmsCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucGetNumStrFrmsCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucGetNumStrFrmsCheckCount == FrIf_GucGetNumStrFrmsCount)
      {
        FrIf_GucGetNumStrFrmsCount = 0;
        FrIf_GucGetNumStrFrmsCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    /*
     * Case to handle API invocation with multiple occurance (with sequnce)
     * and to validate parameters of the API with what it has been invoked
     */
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((FrIf_GucGetNumStrFrmsCheckCount <= FrIf_GucGetNumStrFrmsCount) &&
        (ExpFrIf_CtrlIdx ==
          FrIf_GaaGetNumStrFrmsCtrlIdx[FrIf_GucGetNumStrFrmsCheckCount]))
      {
        LblRetValue = STEP_PASSED;
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucGetNumStrFrmsCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucGetNumStrFrmsCheckCount == FrIf_GucGetNumStrFrmsCount)
      {
        FrIf_GucGetNumStrFrmsCount = 0;
        FrIf_GucGetNumStrFrmsCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrIf_GucGetNumStrFrmsCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpFrIf_CtrlIdx == FrIf_GaaGetNumStrFrmsCtrlIdx[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrIf_GetNumOfStartupFrames() */

/*******************************************************************************
**                              FrIf_GetWakeupRxStatus()                      **
*******************************************************************************/
Std_ReturnType FrIf_GetWakeupRxStatus(uint8 FrIf_CtrlIdx,
  uint8 *FrIf_WakeupRxStatusPtr)
{
  #ifndef TYPICAL_CONFIG
  
  /* Load actual CtrlId into Global variable */
  FrIf_GaaGetWakeupRxCtrlIdx[FrIf_GucWakeupRxCount] = FrIf_CtrlIdx;
  *FrIf_WakeupRxStatusPtr = FrIf_GaaWakeupRxStatus[FrIf_CtrlIdx];
  
  if(FrIf_GucWakeupRxCount != FRIF_ARRAY_SIZE)
  {
    FrIf_GucWakeupRxCount++;
  }
  return(FrIf_GddReturnVal);
  #endif
} /* End FrIf_GetWakeupRxStatus() */

/*******************************************************************************
**                            TestFrIf_GetWakeupRxStatus()                    **
*******************************************************************************/
boolean TestFrIf_GetWakeupRxStatus(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrIf_GucWakeupRxCount == 0x01) && 
        (ExpFrIf_CtrlIdx == FrIf_GaaGetWakeupRxCtrlIdx[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucWakeupRxCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucWakeupRxCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < FrIf_GucWakeupRxCount; LucIndex++)
      {
        /* Validate the Controller Id */
        if(ExpFrIf_CtrlIdx ==
          FrIf_GaaGetWakeupRxCtrlIdx[LucIndex])
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = FrIf_GucWakeupRxCount;
        } /* End if(ExpFrIf_CtrlIdx == FrIf_GaaClrTrcvrWupCtrlIdx[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < FrIf_GucWakeupRxCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucWakeupRxCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucWakeupRxCheckCount == FrIf_GucWakeupRxCount)
      {
        FrIf_GucWakeupRxCount = 0;
        FrIf_GucWakeupRxCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    /*
     * Case to handle API invocation with multiple occurance (with sequnce)
     * and to validate parameters of the API with what it has been invoked
     */
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((FrIf_GucWakeupRxCheckCount <= FrIf_GucWakeupRxCount) &&
        (ExpFrIf_CtrlIdx ==
          FrIf_GaaGetWakeupRxCtrlIdx[FrIf_GucWakeupRxCheckCount]))
      {
        LblRetValue = STEP_PASSED;
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucWakeupRxCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucWakeupRxCheckCount == FrIf_GucWakeupRxCount)
      {
        FrIf_GucWakeupRxCount = 0;
        FrIf_GucWakeupRxCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrIf_GucWakeupRxCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpFrIf_CtrlIdx == FrIf_GaaGetWakeupRxCtrlIdx[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrIf_GetWakeupRxStatus() */

/*******************************************************************************
**                              FrIf_SetTransceiverMode()                     **
*******************************************************************************/
Std_ReturnType FrIf_SetTransceiverMode(uint8 FrIf_CtrlIdx,
 Fr_ChannelType FrIf_ChnlIdx, FrTrcv_TrcvModeType FrIf_TrcvMode)
{
  #ifndef TYPICAL_CONFIG  
  /* Load actual CtrlId into Global variable */
  FrIf_GaaSetTrncMdeCtrlIdx[FrIf_GucSetTrncMdeCount] = FrIf_CtrlIdx;
  FrIf_GaaSetTrncMdeChnlIdx[FrIf_GucSetTrncMdeCount] = FrIf_ChnlIdx;
  FrIf_GaaSetTrncMdeType[FrIf_GucSetTrncMdeCount] = FrIf_TrcvMode;
  
  if(FrIf_GucSetTrncMdeCount != FRIF_ARRAY_SIZE)
  {
    FrIf_GucSetTrncMdeCount++;
  }
  return(FrIf_GddReturnVal);
  #endif
} /* End FrIf_SetTransceiverMode() */

/*******************************************************************************
**                            TestFrIf_SetTransceiverMode()                   **
*******************************************************************************/
boolean TestFrIf_SetTransceiverMode(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx, Fr_ChannelType ExpFrIf_ChnlIdx,
  FrTrcv_TrcvModeType ExpFrIf_TrcvMode)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrIf_GucSetTrncMdeCount == 0x01) && 
        ((ExpFrIf_CtrlIdx == FrIf_GaaSetTrncMdeCtrlIdx[0]) &&
        (ExpFrIf_ChnlIdx == FrIf_GaaSetTrncMdeChnlIdx[0]) &&
        (ExpFrIf_TrcvMode == FrIf_GaaSetTrncMdeType[0]))
        )
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucSetTrncMdeCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucSetTrncMdeCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < FrIf_GucSetTrncMdeCount; LucIndex++)
      {
        /* Validate the Controller Id */
        if((ExpFrIf_CtrlIdx ==
          FrIf_GaaSetTrncMdeCtrlIdx[LucIndex]) &&
          (ExpFrIf_ChnlIdx == 
          FrIf_GaaSetTrncMdeChnlIdx[LucIndex]) &&
          (ExpFrIf_TrcvMode ==
          FrIf_GaaSetTrncMdeType[LucIndex])
          )
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = FrIf_GucSetTrncMdeCount;
        } /* End if(ExpFrIf_CtrlIdx == FrIf_GaaClrTrcvrWupCtrlIdx[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < FrIf_GucSetTrncMdeCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucSetTrncMdeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucSetTrncMdeCheckCount == FrIf_GucSetTrncMdeCount)
      {
        FrIf_GucSetTrncMdeCount = 0;
        FrIf_GucSetTrncMdeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    /*
     * Case to handle API invocation with multiple occurance (with sequnce)
     * and to validate parameters of the API with what it has been invoked
     */
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((FrIf_GucSetTrncMdeCheckCount <= FrIf_GucSetTrncMdeCount) &&
        (ExpFrIf_CtrlIdx ==
          FrIf_GaaSetTrncMdeCtrlIdx[FrIf_GucSetTrncMdeCheckCount]) &&
          (ExpFrIf_ChnlIdx == 
          FrIf_GaaSetTrncMdeChnlIdx[FrIf_GucSetTrncMdeCheckCount]) &&
        (ExpFrIf_TrcvMode == FrIf_GaaSetTrncMdeType
        [FrIf_GucSetTrncMdeCheckCount])
        )
      {
        LblRetValue = STEP_PASSED;
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucSetTrncMdeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucSetTrncMdeCheckCount == FrIf_GucSetTrncMdeCount)
      {
        FrIf_GucSetTrncMdeCount = 0;
        FrIf_GucSetTrncMdeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrIf_GucSetTrncMdeCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if((ExpFrIf_CtrlIdx == FrIf_GaaSetTrncMdeCtrlIdx[LucIndex]) &&
          (ExpFrIf_ChnlIdx == FrIf_GaaSetTrncMdeChnlIdx[LucIndex]) &&
          (ExpFrIf_TrcvMode == FrIf_GaaSetTrncMdeType[LucIndex])
          )
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrIf_SetTransceiverMode() */

/*******************************************************************************
**                              FrIf_GetTransceiverWUReason()                 **
*******************************************************************************/
Std_ReturnType FrIf_GetTransceiverWUReason(uint8 FrIf_CtrlIdx,
 Fr_ChannelType FrIf_ChnlIdx, FrTrcv_TrcvWUReasonType *FrIf_TrcvWUReasonPtr)
{
  #ifndef TYPICAL_CONFIG
  
  /* Load actual CtrlId into Global variable */
  FrIf_GaaGetTrncWURsnCtrlIdx[FrIf_GucGetTrncWURsnCount] = FrIf_CtrlIdx;
  FrIf_GaaGetTrncWURsnChnlIdx[FrIf_GucGetTrncWURsnCount] = FrIf_ChnlIdx;
  
  if(FrIf_ChnlIdx == FR_CHANNEL_A)
  {
    *FrIf_TrcvWUReasonPtr = FrIf_GaaTrncWURsn[FrIf_CtrlIdx][0x00];
  }
  if(FrIf_ChnlIdx == FR_CHANNEL_B)
  {
    *FrIf_TrcvWUReasonPtr = FrIf_GaaTrncWURsn[FrIf_CtrlIdx][0x01];
  } 
  
  if(FrIf_GucGetTrncWURsnCount != FRIF_ARRAY_SIZE)
  {
    FrIf_GucGetTrncWURsnCount++;
  }
  return(FrIf_GddReturnVal);
  #endif
} /* End FrIf_GetTransceiverWUReason() */

/*******************************************************************************
**                            TestFrIf_GetTransceiverWUReason()               **
*******************************************************************************/
boolean TestFrIf_GetTransceiverWUReason(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx, Fr_ChannelType ExpFrIf_ChnlIdx)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((FrIf_GucGetTrncWURsnCount == 0x01) && 
        ((ExpFrIf_CtrlIdx == FrIf_GaaGetTrncWURsnCtrlIdx[0]) &&
        (ExpFrIf_ChnlIdx == FrIf_GaaGetTrncWURsnChnlIdx[0]))
        )
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucGetTrncWURsnCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucGetTrncWURsnCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < FrIf_GucGetTrncWURsnCount; LucIndex++)
      {
        /* Validate the Controller Id */
        if((ExpFrIf_CtrlIdx ==
          FrIf_GaaGetTrncWURsnCtrlIdx[LucIndex]) &&
          (ExpFrIf_ChnlIdx == 
          FrIf_GaaGetTrncWURsnChnlIdx[LucIndex]))
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = FrIf_GucGetTrncWURsnCount;
        } /* End if(ExpFrIf_CtrlIdx == FrIf_GaaClrTrcvrWupCtrlIdx[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < FrIf_GucGetTrncWURsnCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucGetTrncWURsnCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucGetTrncWURsnCheckCount == FrIf_GucGetTrncWURsnCount)
      {
        FrIf_GucGetTrncWURsnCount = 0;
        FrIf_GucGetTrncWURsnCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    /*
     * Case to handle API invocation with multiple occurance (with sequnce)
     * and to validate parameters of the API with what it has been invoked
     */
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((FrIf_GucGetTrncWURsnCheckCount <= FrIf_GucGetTrncWURsnCount) &&
        (ExpFrIf_CtrlIdx == FrIf_GaaGetTrncWURsnCtrlIdx
        [FrIf_GucGetTrncWURsnCheckCount]) &&
        (ExpFrIf_ChnlIdx == FrIf_GaaGetTrncWURsnChnlIdx
        [FrIf_GucGetTrncWURsnCheckCount]))        
      {
        LblRetValue = STEP_PASSED;
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      FrIf_GucGetTrncWURsnCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(FrIf_GucGetTrncWURsnCheckCount == FrIf_GucGetTrncWURsnCount)
      {
        FrIf_GucGetTrncWURsnCount = 0;
        FrIf_GucGetTrncWURsnCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    /* Case to handle API not invoked with given ID for multiple occurances */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrIf_GucGetTrncWURsnCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if((ExpFrIf_CtrlIdx == FrIf_GaaGetTrncWURsnCtrlIdx[LucIndex]) &&
          (ExpFrIf_ChnlIdx == FrIf_GaaGetTrncWURsnChnlIdx[LucIndex]))
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrIf_GetTransceiverWUReason() */

/*******************************************************************************
**                              TestSet_FrIfGetTransceiverWUReason()          **
*******************************************************************************/
void TestSet_FrIfGetTransceiverWUReason(uint8 FrIf_CtrlIdx, 
  Fr_ChannelType FrIf_ChnlIdx,
  FrTrcv_TrcvWUReasonType LddTrcvWUReason)
{
  if(FrIf_ChnlIdx == FR_CHANNEL_A)
  {
    FrIf_GaaTrncWURsn[FrIf_CtrlIdx][0x00] = LddTrcvWUReason;
  }
  if(FrIf_ChnlIdx == FR_CHANNEL_B)
  {
    FrIf_GaaTrncWURsn[FrIf_CtrlIdx][0x01] = LddTrcvWUReason;
  }
} /* End TestSet_FrIfGetTransceiverWUReason() */

/*******************************************************************************
**                              TestSet_FrIfGetWakeupRxStatus()               **
*******************************************************************************/
void TestSet_FrIfGetWakeupRxStatus(uint8 FrIf_CtrlIdx, 
  uint8 LucWakeupRxStatus)
{
  FrIf_GaaWakeupRxStatus[FrIf_CtrlIdx] = LucWakeupRxStatus;
} /* End TestSet_FrIfGetWakeupRxStatus() */

/*******************************************************************************
**                              TestSet_FrIfGetNumOfStartupFrames()           **
*******************************************************************************/
void TestSet_FrIfGetNumOfStartupFrames(uint8 FrIf_CtrlIdx, 
  uint8 LucNumOfStartupFrames)
{
  FrIf_GaaGetNumStrFrms[FrIf_CtrlIdx] = LucNumOfStartupFrames;
} /* End TestSet_FrIfGetNumOfStartupFrames() */
/*******************************************************************************
**                              TestSet_FrIfGetPOCStatus()                    **
*******************************************************************************/
void TestSet_FrIfGetPOCStatus(uint8 FrIf_CtrlIdx, 
  Fr_POCStatusType LddPOCStatus)
{
  FrIf_GaaGetPOCStatus[FrIf_CtrlIdx] = LddPOCStatus;
} /* End TestSet_FrIfGetPOCStatus() */

/*******************************************************************************
**                              TestSet_SimulateFrIf()                        **
*******************************************************************************/
void TestSet_SimulateFrIf(Std_ReturnType LddReturnValue)
{
  FrIf_GddReturnVal = LddReturnValue;
} /* End TestSet_SimulateFrIf() */
#endif

#ifdef FRNM_MODULE_ACTIVE
/*******************************************************************************
**                              FrIf_GetGlobalTime()                        **
*******************************************************************************/
Std_ReturnType FrIf_GetGlobalTime
(uint8 FrIf_CtrlIdx, uint8* FrIf_CyclePtr, uint16* FrIf_MacroTickPtr)
{
   
  UNUSED(FrIf_MacroTickPtr);
  UNUSED(FrIf_CtrlIdx);
  
  FrIf_GucCycleNumber++;
  *FrIf_CyclePtr = FrIf_GucCycleNumber;
   /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  FrIf_GaaCntrlId[FrIf_GucGetGlobalTimeCount] = FrIf_CtrlIdx;
  FrIf_GaaCycle[FrIf_GucGetGlobalTimeCount] = FrIf_GucCycleNumber;
  /* Increment count variable to handle multiple invocations */
  if(FrIf_GucGetGlobalTimeCount != 63)
  {    
    FrIf_GucGetGlobalTimeCount++;
  }
  if(FrIf_GucCycleNumber > 63)
  {
    FrIf_GucCycleNumber = 0;
  }
  
  return (FrIf_GddGetGlbReturnVal);
}

/*******************************************************************************
**                      SetReturn_FrIf_GetGlobalTime()                        **
*******************************************************************************/
void SetReturn_FrIf_GetGlobalTime(Std_ReturnType LddReturnVal)
{
   FrIf_GddGetGlbReturnVal = LddReturnVal;
}

/*******************************************************************************
**                      Test_SetFrCycleNumber()                               **
*******************************************************************************/
void Test_SetFrCycleNumber(uint8 CycleNumber)
{
  FrIf_GucCycleNumber = CycleNumber;
}
boolean TestFrIf_GetGlobalTime(App_DataValidateType LucDataValidate,
uint8 CntrlIdId, const uint8 CyclePtr)
{
  boolean LblRetValue;
  uint8 LucIndex;
  UNUSED(CyclePtr);

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if(FrIf_GucGetGlobalTimeCount == 0x01)
      {
       
          LblRetValue = STEP_PASSED;
       
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucGetGlobalTimeCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucGetGlobalTimeCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if(FrIf_GucGetGlobalTimeCount > 1)
      {
       
          LblRetValue = STEP_PASSED;
       
      }

      FrIf_GucGetGlobalTimeCount = 0;
      
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrIf_GucGetGlobalTimeCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(CntrlIdId == FrIf_GaaCntrlId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestFrIf_GetGlobalTime() */

/*******************************************************************************
**                      FrIf_GetNmVector()                                    **
*******************************************************************************/
Std_ReturnType FrIf_GetNmVector(uint8 FrIf_CtrlIdx, uint8* FrIf_NmVectorPtr)
{
  uint8 LucVectorLength;
  boolean LblRetValue;
  LblRetValue = (Std_ReturnType)E_OK;
  FrIf_GaaCtrlId[FrIf_GucGetNmVectorCnt] = FrIf_CtrlIdx;
  for(LucVectorLength = 0; LucVectorLength < FRIF_GNETWORK_MANAGEMENT_VECTORLENGTH; LucVectorLength++)
  {
    FrIf_NmVectorPtr[LucVectorLength] = FrIf_Agg_vector[LucVectorLength]; /* Any bits set */
  }
  
  FrIf_GucGetNmVectorCnt++;
  return(LblRetValue);
}
/*******************************************************************************
**                      FrIf_SetAggVectordata()                               **
*******************************************************************************/
void FrIf_SetAggVectordata(uint8* LucVectordata)
{
  uint8 LucVectorLength;
  for(LucVectorLength = 0; LucVectorLength < FRIF_GNETWORK_MANAGEMENT_VECTORLENGTH; LucVectorLength++)
  {
   FrIf_Agg_vector[LucVectorLength] = LucVectordata[LucVectorLength]; /* Any bits set */
  }
}

/*******************************************************************************
**                      TestFrIf_GetNmVector()                               **
*******************************************************************************/
boolean TestFrIf_GetNmVector(App_DataValidateType LucDataValidate,
  uint8 CntrlIdId)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if(FrIf_GucGetNmVectorCnt == 0x01)
      {
       
          LblRetValue = STEP_PASSED;
       
      }
      /* Reset API invocation Count after validating the API invocation */
      FrIf_GucGetNmVectorCnt = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(FrIf_GucGetNmVectorCnt == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if(FrIf_GucGetNmVectorCnt > 1)
      {
       
          LblRetValue = STEP_PASSED;
       
      }

      FrIf_GucGetNmVectorCnt = 0;
      
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < FrIf_GucGetNmVectorCnt) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(CntrlIdId == FrIf_GaaCtrlId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
