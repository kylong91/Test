/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: FrIf.h                                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FrIf Interface Stub                                   **
**                                                                            **
**  PURPOSE   : Declaration of FrIf Stub functions                            **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Kavya M             Initial version                **
*******************************************************************************/

#ifndef FRIF_H
#define FRIF_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"   /* ComStack types header file */
#include "Fr_GeneralTypes.h"
#include "TC_Generic.h"


/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define FRIF_AR_RELEASE_MAJOR_VERSION         0x04
#define FRIF_AR_RELEASE_MINOR_VERSION         0x00
#define FRIF_AR_RELEASE_REVISION_VERSION      0x03

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define FRIF_DATA_LENGTH                      0xFE

#define FRIF_ARRAY_SIZE                       0x08
#define FRIF_GNETWORK_MANAGEMENT_VECTORLENGTH 0x02

/*******************************************************************************
**                        Type Definitions                                    **
*******************************************************************************/
typedef uint8 FrIf_ConfigType;

/* FrIf_StateTransitionType  */
typedef enum
{
  FRIF_GOTO_OFFLINE,
  FRIF_GOTO_ONLINE,
} FrIf_StateTransitionType;

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void FrIf_SetAggVectordata(uint8* LucVectordata);
extern void TestFrIf_DefaultBehavior(void);

extern void TestSetFrIf_TxPduIdForRet(PduIdType LddPduIdForRet);

extern Std_ReturnType FrIf_Transmit(PduIdType FrTxPduId,
  const PduInfoType *PduInfoPtr);

extern void TestFrIf_TransmitSetRetVal(Std_ReturnType LddRetVal);

extern boolean TestFrIf_Transmit(App_DataValidateType LucDataValidate,
  PduIdType ExpFrTxPduId, const PduInfoType *ExpPduInfoPtr);

extern boolean FrIfTest_ValidateData(PduInfoType* LddExpPduInfo,
  PduInfoType* LddActPduInfo);
  
extern Std_ReturnType FrIf_CancelTransmit(PduIdType id);

extern boolean TestFrIf_CancelTransmit(App_DataValidateType LucDataValidate,
  PduIdType ExpFrIfTxSduId);
  
extern void TestFrIf_CancelTransmitSetRetVal(Std_ReturnType LddRetVal);

extern Std_ReturnType FrIf_ControllerInit(uint8 FrIf_CtrlIdx);

extern Std_ReturnType FrIf_StartCommunication(uint8 FrIf_CtrlIdx);

extern Std_ReturnType FrIf_HaltCommunication(uint8 FrIf_CtrlIdx);

extern Std_ReturnType FrIf_SetState(uint8 FrIf_ClstIdx,
  FrIf_StateTransitionType FrIf_StateTransition);
  
extern Std_ReturnType FrIf_SetWakeupChannel(uint8 FrIf_CtrlIdx,
  Fr_ChannelType FrIf_ChnlIdx);
  
extern Std_ReturnType FrIf_SendWUP(uint8 FrIf_CtrlIdx);

extern Std_ReturnType FrIf_GetPOCStatus(uint8
                           FrIf_CtrlIdx, Fr_POCStatusType* FrIf_POCStatusPtr);
extern Std_ReturnType FrIf_AllowColdstart(uint8 FrIf_CtrlIdx);

extern Std_ReturnType FrIf_SetTransceiverMode(uint8
       FrIf_CtrlIdx, Fr_ChannelType FrIf_ChnlIdx,
        FrTrcv_TrcvModeType FrIf_TrcvMode);
        
extern Std_ReturnType FrIf_GetTransceiverWUReason(uint8
       FrIf_CtrlIdx, Fr_ChannelType FrIf_ChnlIdx,
        FrTrcv_TrcvWUReasonType *FrIf_TrcvWUReasonPtr);
        
extern Std_ReturnType FrIf_ClearTransceiverWakeup(
       uint8 FrIf_CtrlIdx, Fr_ChannelType FrIf_ChnlIdx);
       
extern Std_ReturnType FrIf_AllSlots(uint8 FrIf_CtrlIdx);

extern Std_ReturnType FrIf_GetNumOfStartupFrames(uint8 FrIf_CtrlIdx,
  uint8 *FrIf_NumOfStartupFramesPtr);
  
extern Std_ReturnType FrIf_GetWakeupRxStatus(uint8 FrIf_CtrlIdx,
  uint8 *FrIf_WakeupRxStatusPtr);
  
extern boolean TestFrIf_AllowColdstart(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx);
  
extern boolean TestFrIf_ControllerInit(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx);
  
extern boolean TestFrIf_SendWUP(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx);

extern boolean TestFrIf_AllSlots(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx);
  
extern boolean TestFrIf_StartCommunication(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx);
  
extern boolean TestFrIf_HaltCommunication(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx);
  
extern boolean TestFrIf_SetState(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_ClstIdx, FrIf_StateTransitionType ExpFrIf_StateTransition);
  
extern boolean TestFrIf_SetWakeupChannel(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx, Fr_ChannelType ExpFrIf_ChnlIdx);
  
extern boolean TestFrIf_ClearTransceiverWakeup(App_DataValidateType 
  LucDataValidate,
  uint8 ExpFrIf_CtrlIdx, Fr_ChannelType ExpFrIf_ChnlIdx);
  
extern boolean TestFrIf_GetPOCStatus(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx);
  
extern boolean TestFrIf_GetNumOfStartupFrames(App_DataValidateType 
  LucDataValidate,
  uint8 ExpFrIf_CtrlIdx);
  
extern boolean TestFrIf_GetWakeupRxStatus(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx);
  
extern boolean TestFrIf_SetTransceiverMode(App_DataValidateType LucDataValidate,
  uint8 ExpFrIf_CtrlIdx, Fr_ChannelType ExpFrIf_ChnlIdx,
  FrTrcv_TrcvModeType ExpFrIf_TrcvMode);

extern boolean TestFrIf_GetTransceiverWUReason(App_DataValidateType 
  LucDataValidate,
  uint8 ExpFrIf_CtrlIdx, Fr_ChannelType ExpFrIf_ChnlIdx);
  
extern void TestSet_FrIfGetPOCStatus(uint8 FrIf_CtrlIdx, 
  Fr_POCStatusType LddPOCStatus);
  
extern void TestSet_FrIfGetNumOfStartupFrames(uint8 FrIf_CtrlIdx, 
  uint8 LucNumOfStartupFrames);  
  
extern void TestSet_FrIfGetWakeupRxStatus(uint8 FrIf_CtrlIdx, 
  uint8 LucWakeupRxStatus);
  
extern void TestSet_FrIfGetTransceiverWUReason(uint8 FrIf_CtrlIdx, 
  Fr_ChannelType FrIf_ChnlIdx,
  FrTrcv_TrcvWUReasonType LddTrcvWUReason);

extern void TestSet_SimulateFrIf(Std_ReturnType LddReturnValue);

extern void FrIf_Init(const FrIf_ConfigType* FrIf_ConfigPtr);

extern boolean TestFrIf_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);  

extern Std_ReturnType FrIf_GetGlobalTime
(uint8 FrIf_CtrlIdx,
uint8* FrIf_CyclePtr,
uint16* FrIf_MacroTickPtr);  

extern void SetReturn_FrIf_GetGlobalTime(Std_ReturnType LddReturnVal);
extern boolean TestFrIf_GetGlobalTime(App_DataValidateType LucDataValidate,
uint8 CntrlIdId, const uint8 CyclePtr);

extern Std_ReturnType FrIf_GetNmVector(uint8 FrIf_CtrlIdx, uint8* FrIf_NmVectorPtr);
extern boolean TestFrIf_GetNmVector(App_DataValidateType LucDataValidate,
  uint8 CntrlIdId);
extern void FrIf_GucTransmitCountClear (void);

extern void TestSetFrIf_TransmitForDec(boolean LblDecoupled);
#endif /* FRIF_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
