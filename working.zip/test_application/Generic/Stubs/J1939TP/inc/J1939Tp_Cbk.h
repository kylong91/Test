/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: J1939TP_Cbk.h                                                 **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CAN J1939TP Stub                                      **
**                                                                            **
**  PURPOSE   : Declaration of J1939TP functions                              **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     14/06/2011    BJV    Creation of J1939TP.h module                **
** 4.0.1     20-Dec-2011   RPS    General inclusions are updated              **
** 4.0.2     10-Feb-2012   RPS    Version information has been removed        **
*******************************************************************************/
#ifndef J1939TP_CBK_H
#define J1939TP_CBK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void J1939Tp_TxConfirmation(PduIdType TxPduId);

extern void J1939Tp_RxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr);

extern boolean TestJ1939Tp_TxConfirmation(App_DataValidateType LddDataValidate,
  PduIdType ExpTxPduId);

extern boolean TestJ1939Tp_RxIndication(App_DataValidateType LddDataValidate,
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr);

extern boolean J1939TP_Test_ValidateData(PduInfoType* LddExpPduInfo,
  PduInfoType* LddActPduInfo);

#endif /* J1939TP_CBK_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
