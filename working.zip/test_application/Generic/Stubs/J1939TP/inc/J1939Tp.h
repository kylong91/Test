/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: J1939TP.h                                                     **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CAN J1939TP Stub                                      **
**                                                                            **
**  PURPOSE   : Declaration of J1939TP functions                              **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     14/06/2011    BJV    Creation of J1939TP.h module                **
** 4.0.1     20-Dec-2011   RPS    General inclusions are updated              **
** 4.0.2     30-Dec-2011   RPS    Updated for CanIf                           **
*******************************************************************************/
#ifndef J1939TP_H
#define J1939TP_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"            /* Com Stack header */
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
#define J1939TP_AR_RELEASE_MAJOR_VERSION 4
#define J1939TP_AR_RELEASE_MINOR_VERSION 0
#define J1939TP_AR_RELEASE_REVISION_VERSION 2
#define J1939TP_SW_MAJOR_VERSION 4
#define J1939TP_SW_MINOR_VERSION 0

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define J1939TP_ARRAY_SIZE                  0x08
#define J1939TP_DATA_LENGTH                 0x08

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void TestJ1939Tp_DefaultBehavior(void);

#endif /* J1939TP_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
