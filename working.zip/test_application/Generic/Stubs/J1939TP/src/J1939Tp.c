/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: J1939TP.c                                                     **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR J1939TP Stub                                          **
**                                                                            **
**  PURPOSE   : This application file contains the J1939TP stub  functions    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision    Date         By    Description                                 **
********************************************************************************
** 4.0.0     13/06/2011    BJV    Creation of J1939TP.c module                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "J1939Tp.h"
#include "J1939Tp_Cbk.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 J1939TP_GucTxConfirmCount;
uint8 J1939TP_GucTxConfirmCheckCount;
PduIdType J1939TP_GucTxPduId;

uint8 J1939TP_GucRxIndiCount;
PduIdType J1939TP_GucRxPduId;
uint8 J1939TP_GaaRxIndSduData[J1939TP_DATA_LENGTH];
uint8 J1939TP_GucRxIndSduLength;

/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
**                     J1939TP_TxConfirmation()                               **
*******************************************************************************/
void J1939Tp_TxConfirmation(PduIdType TxPduId)
{
  /* Load actual TxPduId into Global variables */
  J1939TP_GucTxPduId = TxPduId;
  J1939TP_GucTxConfirmCount++;
}  /* End of J1939TP_TxConfirmation() */

/*******************************************************************************
**                     TestJ1939Tp_TxConfirmation()                           **
*******************************************************************************/
boolean TestJ1939Tp_TxConfirmation(App_DataValidateType LddDataValidate,
  PduIdType ExpTxPduId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TxPduId */
      if((J1939TP_GucTxConfirmCount == 0x01) &&
        (J1939TP_GucTxPduId == ExpTxPduId))

      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      J1939TP_GucTxConfirmCount = 0;
      J1939TP_GucTxConfirmCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < J1939TP_GucTxConfirmCount; LucIndex++)
      {
        /* Validate TxPduId */
        if(J1939TP_GucTxPduId == ExpTxPduId)

        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = J1939TP_GucTxConfirmCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      J1939TP_GucTxConfirmCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(J1939TP_GucTxConfirmCheckCount == J1939TP_GucTxConfirmCount)
      {
        J1939TP_GucTxConfirmCount = 0;
        J1939TP_GucTxConfirmCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(J1939TP_GucTxConfirmCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestJ1939Tp_TxConfirmation() */

/*******************************************************************************
**                       J1939TP_RxIndication()                               **
*******************************************************************************/
void J1939Tp_RxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr)
{
  uint8 LucDataIndex;
  uint8* LpSduDataPtr;

  /* Load actual TxPduId, Sdulength and SduDataPt into Global variables */
  J1939TP_GucRxPduId = RxPduId;
  J1939TP_GucRxIndiCount++;

  J1939TP_GucRxIndSduLength = PduInfoPtr->SduLength;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;

  for(LucDataIndex = 0x00; LucDataIndex < PduInfoPtr->SduLength; LucDataIndex++)
  {
    J1939TP_GaaRxIndSduData[LucDataIndex] = *LpSduDataPtr;
    LpSduDataPtr++;
  }
}  /* End of J1939TP_RxIndication() */

/*******************************************************************************
**                   TestJ1939Tp_RxIndication()                               **
*******************************************************************************/
boolean TestJ1939Tp_RxIndication(App_DataValidateType LddDataValidate,
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType LstActPduInfo;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((J1939TP_GucRxIndiCount == 0x01) && (J1939TP_GucRxPduId == ExpRxPduId))
      {
        LstActPduInfo.SduLength = J1939TP_GucRxIndSduLength;
        LstActPduInfo.SduDataPtr = &J1939TP_GaaRxIndSduData[0];

        /* Validate SduLength and Data */
        if(J1939TP_Test_ValidateData((PduInfoType *)ExpPduInfoPtr,
          &LstActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      J1939TP_GucRxIndiCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(J1939TP_GucRxIndiCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
       default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End of TestJ1939Tp_RxIndication() */

/*******************************************************************************
**                       J1939TP_Test_ValidateData()                          **
*******************************************************************************/
boolean J1939TP_Test_ValidateData(PduInfoType* LddExpPduInfo,
  PduInfoType* LddActPduInfo)
{
  uint8 *LpActualSduDataPtr;
  uint8 *LpExpSduDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  LddSduCount = LddExpPduInfo->SduLength;
  LpExpSduDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualSduDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  if((LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }

  while((LddSduCount > 0) && (LblReturnValue != FALSE))
 {
    if(*LpActualSduDataPtr != *LpExpSduDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualSduDataPtr++;
    LpExpSduDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* J1939TP_Test_ValidateData() */

/*******************************************************************************
**                     TestJ1939Tp_DefaultBehavior()                          **
*******************************************************************************/
void TestJ1939Tp_DefaultBehavior(void)
{
  J1939TP_GucTxConfirmCount = 0;
  J1939TP_GucTxConfirmCheckCount = 0;
  J1939TP_GucRxIndiCount = 0;
} /* End TestCdd_DefaultBehavior() */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

