/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Xcp_Cbk.h                                                     **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Xcp Stub                                              **
**                                                                            **
**  PURPOSE   : Provision of external declaration of APIs                     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     09-Nov-2012   Arun    Initial version                            **
*******************************************************************************/

#ifndef XCP_CBK_H
#define XCP_CBK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"             /* Com Stack header */
#include "TC_Generic.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define XCP_AR_RELEASE_MAJOR_VERSION    0x04
#define XCP_AR_RELEASE_MINOR_VERSION    0x00
#define XCP_AR_RELEASE_REVISION_VERSION 0x03


/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void Xcp_CanIfTxConfirmation(PduIdType TxPduId);

extern void Xcp_CanIfRxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr);

extern boolean TestXcp_CanIfTxConfirmation(App_DataValidateType LddDataValidate,
  PduIdType ExpTxPduId);

extern boolean TestXcp_CanIfRxIndication(App_DataValidateType LddDataValidate,
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr);

extern boolean Xcp_Test_ValidateData(PduInfoType* LddExpPduInfo,
  PduInfoType* LddActPduInfo);

#endif /* XCP_CBK_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
