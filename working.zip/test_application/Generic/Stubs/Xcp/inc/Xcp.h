/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Xcp.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Xcp Stub                                              **
**                                                                            **
**  PURPOSE   : Declaration of Xcp stub functions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     09-Nov-2012   Arun    Initial version                            **
*******************************************************************************/
#ifndef XCP_H
#define XCP_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"             /* Com Stack header */
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define XCP_AR_RELEASE_MAJOR_VERSION    0x04
#define XCP_AR_RELEASE_MINOR_VERSION    0x00
#define XCP_AR_RELEASE_REVISION_VERSION 0x03

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define XCP_ARRAY_SIZE                  0x08
#define XCP_DATA_LENGTH                 0x08

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void TestXcp_DefaultBehavior(void);
#ifdef FRIF_MODULE_ACTIVE
extern void Xcp_FrIfTxConfirmation(PduIdType TxPduId);

extern Std_ReturnType Xcp_FrIfTriggerTransmit(PduIdType TxPduId,
  PduInfoType* PduInfoPtr);

extern void Xcp_FrIfRxIndication(PduIdType RxPduId, PduInfoType* PduInfoPtr);

extern boolean TestXcp_FrIfRxIndication(App_DataValidateType LucDataValidate,
PduIdType RxPduId);

extern boolean TestXcp_FrIfTriggerTransmit(App_DataValidateType LucDataValidate,
PduIdType TxPduId);

extern boolean TestXcp_FrIfTxConfirmation(App_DataValidateType LucDataValidate,
PduIdType TxPduId);
#endif

#endif /* XCP_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
