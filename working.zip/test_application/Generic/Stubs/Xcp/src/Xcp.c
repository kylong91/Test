/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Xcp.c                                                         **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Xcp Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Xcp stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision    Date         By    Description                                 **
********************************************************************************
** 1.0.0     09-Nov-2012   Arun    Initial version                            **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Xcp.h"
#include "Xcp_Cbk.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Xcp_GucTxConfirmCount;
uint8 Xcp_GucTxConfirmCheckCount;
PduIdType Xcp_GucTxPduId;

uint8 Xcp_GucRxIndiCount;
PduIdType Xcp_GucRxPduId;
uint8 Xcp_GaaRxIndSduData[XCP_DATA_LENGTH];
uint8 Xcp_GucRxIndSduLength;

PduInfoType *Xcp_GstPduInfoPtr;

#ifdef FRIF_MODULE_ACTIVE
uint8 Xcp_GucFrIfTxPduId;
uint8 Xcp_GucFrIfTriggerTransmit;
PduIdType Xcp_GucFrIfRxPduId;
uint8 Xcp_GucFrIfRxConfirmationcount;
#endif

#ifdef CANIF_MODULE_ACTIVE
uint8 Xcp_GucCanIfTxPduId;
uint8 Xcp_GucCanIfRxPduId;
#endif
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
#ifdef CANIF_MODULE_ACTIVE
/*******************************************************************************
**                     Xcp_CanIfTxConfirmation()                                   **
*******************************************************************************/
void Xcp_CanIfTxConfirmation(PduIdType TxPduId)
{
  /* Load actual TxPduId into Global variables */
  Xcp_GucCanIfTxPduId = TxPduId;
  Xcp_GucTxConfirmCount++;
} /* End of Xcp_CanIfTxConfirmation() */

/*******************************************************************************
**                     TestXcp_CanIfTxConfirmation()                              **
*******************************************************************************/
boolean TestXcp_CanIfTxConfirmation(App_DataValidateType LddDataValidate,
PduIdType ExpTxPduId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, TxPduId */
      if((Xcp_GucTxConfirmCount == 0x01) && (Xcp_GucCanIfTxPduId == ExpTxPduId))

      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Xcp_GucTxConfirmCount = 0;
      Xcp_GucTxConfirmCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Xcp_GucTxConfirmCount; LucIndex++)
      {
        /* Validate TxPduId */
        if(Xcp_GucCanIfTxPduId == ExpTxPduId)

        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Xcp_GucTxConfirmCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Xcp_GucTxConfirmCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Xcp_GucTxConfirmCheckCount == Xcp_GucTxConfirmCount)
      {
        Xcp_GucTxConfirmCount = 0;
        Xcp_GucTxConfirmCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Xcp_GucTxConfirmCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestXcp_CanIfTxConfirmation() */
#endif
#ifdef FRIF_MODULE_ACTIVE
/*******************************************************************************
**                       Xcp_FrIfRxIndication()                               **
*******************************************************************************/
void Xcp_FrIfRxIndication(PduIdType RxPduId, PduInfoType* PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  UNUSED(PduInfoPtr);
  Xcp_GucFrIfRxPduId = RxPduId;
  Xcp_GucFrIfRxConfirmationcount++;
  #endif
} /* End Xcp_RxIndication() */
/*******************************************************************************
**                       TestXcp_FrIfRxIndication()                           **
*******************************************************************************/
boolean TestXcp_FrIfRxIndication(App_DataValidateType LucDataValidate,
PduIdType RxPduId)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Xcp_GucFrIfRxConfirmationcount == 0x01) && 
        (Xcp_GucFrIfRxPduId == RxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Xcp_GucFrIfRxConfirmationcount = 0;      
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Xcp_GucFrIfRxConfirmationcount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}

/*******************************************************************************
**                     Xcp_FrIfTxConfirmation()                               **
*******************************************************************************/
void Xcp_FrIfTxConfirmation(PduIdType TxPduId)
{
  #ifndef TYPICAL_CONFIG
  /* Load actual TxPduId into Global variables */
  Xcp_GucFrIfTxPduId = TxPduId;
  Xcp_GucTxConfirmCount++;
  #endif
} /* End of Xcp_FrIfTxConfirmation() */

/*******************************************************************************
**                     TestXcp_FrIfTxConfirmation()                           **
*******************************************************************************/
boolean TestXcp_FrIfTxConfirmation(App_DataValidateType LucDataValidate,
PduIdType TxPduId)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Xcp_GucTxConfirmCount == 0x01) && 
        (Xcp_GucFrIfTxPduId == TxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Xcp_GucTxConfirmCount = 0;      
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Xcp_GucTxConfirmCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}

/*******************************************************************************
**                     Xcp_FrIfTriggerTransmit()                              **
*******************************************************************************/
Std_ReturnType Xcp_FrIfTriggerTransmit(PduIdType TxPduId,
  PduInfoType* PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  PduInfoType LddstPduInfoPtr;
  LddstPduInfoPtr.SduLength = PduInfoPtr->SduLength;
  Xcp_GucFrIfTxPduId = TxPduId;
  Xcp_GucFrIfTriggerTransmit++;
  #endif
  return(E_OK);
}

/*******************************************************************************
**                     TestXcp_FrIfTriggerTransmit()                          **
*******************************************************************************/
boolean TestXcp_FrIfTriggerTransmit(App_DataValidateType LucDataValidate,
PduIdType TxPduId)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Xcp_GucFrIfTriggerTransmit == 0x01) && 
        (Xcp_GucFrIfTxPduId == TxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Xcp_GucFrIfTriggerTransmit = 0;      
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Xcp_GucFrIfTriggerTransmit == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
}
#endif
#ifdef CANIF_MODULE_ACTIVE
/*******************************************************************************
**                       Xcp_CanIfRxIndication()                                   **
*******************************************************************************/
void Xcp_CanIfRxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8* LpSduDataPtr;

  /* Load actual TxPduId  Sdulength and SduDataPt into Global variables */
  Xcp_GucRxIndiCount++;
  Xcp_GucCanIfRxPduId = RxPduId;

  Xcp_GucRxIndSduLength = PduInfoPtr->SduLength;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;

  for(LucDataIndex = 0x00; LucDataIndex < PduInfoPtr->SduLength; LucDataIndex++)
  {
    Xcp_GaaRxIndSduData[LucDataIndex] = *LpSduDataPtr;
    LpSduDataPtr++;
  }
  #endif
}
/* End of Xcp_CanIfRxIndication() */

/*******************************************************************************
**                   TestXcp_CanIfRxIndication()                                   **
*******************************************************************************/
boolean TestXcp_CanIfRxIndication(App_DataValidateType LddDataValidate,
PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType LstActPduInfo;

  LblRetValue = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Xcp_GucRxIndiCount == 0x01) && (Xcp_GucCanIfRxPduId == ExpRxPduId))
      {
        LstActPduInfo.SduLength = Xcp_GucRxIndSduLength;
        LstActPduInfo.SduDataPtr = &Xcp_GaaRxIndSduData[0];

        /* Validate SduLength and Data */
        if(Xcp_Test_ValidateData((PduInfoType *)ExpPduInfoPtr,
          &LstActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      Xcp_GucRxIndiCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Xcp_GucRxIndiCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
       default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End of TestXcp_CanIfRxIndication() */
#endif
/*******************************************************************************
**                       Xcp_Test_ValidateData()                              **
*******************************************************************************/
boolean Xcp_Test_ValidateData(PduInfoType* LddExpPduInfo,
  PduInfoType* LddActPduInfo)
{
  uint8 *LpActualSduDataPtr;
  uint8 *LpExpSduDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  LddSduCount = LddExpPduInfo->SduLength;
  LpExpSduDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualSduDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  if((LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }

  while((LddSduCount > 0) && (LblReturnValue != FALSE))
 {
    if(*LpActualSduDataPtr != *LpExpSduDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualSduDataPtr++;
    LpExpSduDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* Xcp_Test_ValidateData() */

/*******************************************************************************
**                     TestXcp_DefaultBehavior()                              **
*******************************************************************************/
void TestXcp_DefaultBehavior(void)
{
  Xcp_GucTxConfirmCount = 0;
  Xcp_GucTxConfirmCheckCount = 0;
  Xcp_GucRxIndiCount = 0;
} /* End of TestXcp_DefaultBehavior() */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

