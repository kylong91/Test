/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Com.c                                                         **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR PDU Router                                            **
**                                                                            **
**  PURPOSE   : This application file contains the Com Stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Com.h"
#include "Com_Cbk.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Version Check                                         **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Com_GucSendSigCount;
#ifdef COMM_MODULE_ACTIVE
uint8 Com_GucReceiveSigCount;

uint8* Com_GpSignalDataPtrCOMM;
Com_SignalIdType Com_GaaSignalId[COM_ARRAY_SIZE];
uint8 Com_GaaSignalRxData[6];
uint8 Com_GucLength;

Com_SignalIdType Com_GddRxSignalId;
#endif

PduIdType Com_GaaTxConfPduId[COM_ARRAY_SIZE];
uint8 Com_GucTxConfCount;
uint8 Com_GucTxConfCheckCount;

PduIdType Com_GaaRxIndPduId[COM_ARRAY_SIZE];
uint8 Com_GaaRxIndSduLength[COM_ARRAY_SIZE];
uint8 Com_GaaRxIndSduData[COM_ARRAY_SIZE][COM_DATA_LENGTH];
uint8 Com_GucRxIndCount;
uint8 Com_GucRxIndCheckCount;

PduIdType Com_GddRxIndPduId;
NotifResultType Com_GddRxIndResult;
uint8 Com_GucTpRxIndCount;

PduIdType Com_GddTrigTransTxPduId;
uint8 Com_GucTrigTransCount;
PduIdType Com_GddSorPduId;
PduLengthType Com_GddSorTpSduLength;
PduLengthType Com_GddSorRxBuffer;
uint8 Com_GucSorCount;
PduLengthType Com_GddCopyRxDataRxBuffer;
BufReq_ReturnType Com_GddSorRetVal;
BufReq_ReturnType Com_GddCopyRxDataRetVal;
uint8 Com_GaaCopyRxDataSduData[COM_DATA_LENGTH];
uint8 Com_GucCopyRxDataCount;

uint8 Com_GucTrigTransSetSduLength;
uint8 Com_GaaTrigTransSetData[COM_DATA_LENGTH];
Std_ReturnType Com_GddTrigTransRetVal;
const void* Com_GpSignalDataPtr;
Com_SignalIdType Com_GddSignalId;

#ifdef BSWM_MODULE_ACTIVE
 Com_IpduGroupIdType Com_GaaIpduGroupId[NO_OF_IPDU_GROUPIDS];
 boolean Com_Gblbitval[NO_OF_BITVAL];
 boolean Com_GblVectorBitVal;
 uint8 Com_GucIndexId = 0;
 uint8* Com_GpIpduGroupVector;
 boolean  Com_Gddinitialize;
 uint8 Com_GucSetIpduGroupCount = 0;
 uint8 Com_GucSwitchIPDUTxModeCount = 0;
 uint8 Com_GucTriggerIPDUCheckCount = 0;
 uint8 Com_GucSwitchPduId = 0;
 uint8 Com_GucSetIpduGroupCheckCount = 0;
 uint8 Com_GucIpduGroupControlCount = 0;
 uint8 Com_GblSwitchMode = 0;
 uint8 Com_GucIpduGroupControlCheckCount = 0;
 uint8 Com_GucReceptionDMControlCount = 0;
 uint8 Com_GucClearIpduGroupVectorCount = 0;
 uint8 Com_GucTriggerIPDUSendCount = 0;
 uint8 Com_GucTriggerPduId = 0;
 uint8 Com_GucInitCnt;
  uint8 Com_GucInitSeqCnt;
 
/*******************************************************************************
**                          Com_Init()                                        **
*******************************************************************************/

void Com_Init(const Com_ConfigType* config)
{
  UNUSED(config);
	App_GucApiSeqCnt++;  
	Com_GucInitSeqCnt = App_GucApiSeqCnt;
	Com_GucInitCnt++;
}/* End Com_Init() */

/*******************************************************************************
**                           TestCom_Init()                                   **
*******************************************************************************/
boolean TestCom_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Com_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Com_GucInitCnt = 0;
      Com_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(Com_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Com_GucInitCnt = 0;
      Com_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestCom_Init() */
 
/*******************************************************************************
**                         Com_SetIpduGroup                                   **
*******************************************************************************/
void Com_SetIpduGroup(Com_IpduGroupVector ipduGroupVector, 
  Com_IpduGroupIdType ipduGroupId, boolean bitval)
{
  Com_GpIpduGroupVector = ipduGroupVector;
  Com_GaaIpduGroupId[Com_GucSetIpduGroupCount]  = ipduGroupId;
  Com_Gblbitval[Com_GucSetIpduGroupCount] = bitval;
  
  if(Com_GucSetIpduGroupCount < NO_OF_IPDU_GROUPIDS)
  {
    Com_GucSetIpduGroupCount++;
  }
}/* End Com_SetIpduGroup() */
/*******************************************************************************
**                       TestCom_SetIpduGroup()                               **
*******************************************************************************/
boolean TestCom_SetIpduGroup(App_DataValidateType LucDataValidate,
  Com_IpduGroupVector LddExpipduGroupVector, 
  Com_IpduGroupIdType LddExpipduGroupId, boolean LddExpbitval)
{

  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Com_GucSetIpduGroupCount != 0x00) && 
        (Com_GpIpduGroupVector == LddExpipduGroupVector) && 
        (Com_GaaIpduGroupId[0] == LddExpipduGroupId) && 
        (Com_Gblbitval[0] == LddExpbitval))
      {
        LblStepResult = APP_TC_PASSED;
      }
      
      /* Reset API invocation Count after validating the API invocation */
      Com_GucSetIpduGroupCount = 0;
      Com_GucSetIpduGroupCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
       
      /*
       * Loop through the array and check for the Occurrence  of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Com_GucSetIpduGroupCount; LucIndex++)
      {
      
        /* Validate ControllerId */
        if((Com_GpIpduGroupVector == LddExpipduGroupVector) && 
          (Com_GaaIpduGroupId[LucIndex] == LddExpipduGroupId) && 
          (Com_Gblbitval[LucIndex] == LddExpbitval))
          {
          LblStepResult = STEP_PASSED;
          
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Com_GucSetIpduGroupCount;
        }
      } 
      
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Com_GucSetIpduGroupCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Com_GucSetIpduGroupCheckCount == Com_GucSetIpduGroupCount)
      {
        Com_GucSetIpduGroupCount = 0;
        Com_GucSetIpduGroupCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
      if(Com_GucSetIpduGroupCheckCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestCom_SetIpduGroup() */
/*******************************************************************************
**                         Com_IpduGroupControl                               **
*******************************************************************************/
void Com_IpduGroupControl(Com_IpduGroupVector ipduGroupVector, 
  boolean initialize)
{
  Com_GpIpduGroupVector = ipduGroupVector;
  Com_GblVectorBitVal = initialize;
  
  Com_GucIpduGroupControlCount++;

}/* End Com_IpduGroupControl() */
/*******************************************************************************
**                       TestCom_IpduGroupControl()                           **
*******************************************************************************/
boolean TestCom_IpduGroupControl(App_DataValidateType LucDataValidate, 
  Com_IpduGroupVector LddExpipduGroupVector, boolean LddExpinitialize)
{
  boolean LblStepResult;
  // uint8 LucIndex;
  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Com_GucIpduGroupControlCount != 0x00) && 
        (Com_GpIpduGroupVector == LddExpipduGroupVector) && 
        (Com_GblVectorBitVal == LddExpinitialize))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Com_GucIpduGroupControlCount = 0x00;
      Com_GucIpduGroupControlCheckCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
      if(Com_GucSetIpduGroupCheckCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestCom_IpduGroupControl() */
/*******************************************************************************
**                         Com_ReceptionDMControl                             **
*******************************************************************************/
void Com_ReceptionDMControl(Com_IpduGroupVector ipduGroupVector)
{
  Com_GpIpduGroupVector = ipduGroupVector;
  Com_GucReceptionDMControlCount++;
}/* End Com_ReceptionDMControl() */
/*******************************************************************************
**                       TestCom_ReceptionDMControl()                         **
*******************************************************************************/
 boolean TestCom_ReceptionDMControl(App_DataValidateType LucDataValidate, 
   Com_IpduGroupVector LddExpipduGroupVector)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Com_GucReceptionDMControlCount != 0x00) && 
        (Com_GpIpduGroupVector == LddExpipduGroupVector)) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Com_GucReceptionDMControlCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
      if(Com_GucSetIpduGroupCheckCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);

} /* End TestCom_ReceptionDMControl() */
/*******************************************************************************
**                         Com_ClearIpduGroupVector                           **
*******************************************************************************/
void Com_ClearIpduGroupVector(Com_IpduGroupVector ipduGroupVector)
{
  Com_GpIpduGroupVector = ipduGroupVector;
  Com_GucClearIpduGroupVectorCount++;
}/* End Com_ClearIpduGroupVector() */
/*******************************************************************************
**                       TestCom_ClearIpduGroupVector()                       **
*******************************************************************************/
boolean TestCom_ClearIpduGroupVector(App_DataValidateType LucDataValidate, 
  Com_IpduGroupVector LddExpipduGroupVector)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Com_GucClearIpduGroupVectorCount != 0x00) && 
        (Com_GpIpduGroupVector == LddExpipduGroupVector)) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Com_GucClearIpduGroupVectorCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
    if(Com_GucSetIpduGroupCheckCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);

} /* End TestCom_ClearIpduGroupVector() */

/*******************************************************************************
**                       Com_TriggerIPDUSend()                                **
*******************************************************************************/
void Com_TriggerIPDUSend(PduIdType PduId)
{
  Com_GucTriggerIPDUSendCount++;
  Com_GucTriggerPduId = PduId;
}

/*******************************************************************************
**                       TestCom_TriggerIPDUSend()                            **
*******************************************************************************/
boolean TestCom_TriggerIPDUSend(App_DataValidateType LucDataValidate, 
PduIdType PduId)
{
  boolean LblStepResult;
  // uint8 LucIndex;
  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Com_GucTriggerIPDUSendCount != 0x00) && 
        (Com_GucTriggerPduId == PduId))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Com_GucTriggerIPDUSendCount = 0x00;
      Com_GucTriggerPduId = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
      if(Com_GucTriggerIPDUCheckCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestCom_TriggerIPDUSend() */

/*******************************************************************************
**                       Com_SwitchIpduTxMode()                               **
*******************************************************************************/
void Com_SwitchIpduTxMode(PduIdType PduId, boolean Mode)
{
  Com_GucSwitchIPDUTxModeCount++;
  Com_GucSwitchPduId = PduId;
  Com_GblSwitchMode = Mode;
}

/*******************************************************************************
**                       TestCom_SwitchIpduTxMode()                           **
*******************************************************************************/
boolean TestCom_SwitchIpduTxMode(App_DataValidateType LucDataValidate, 
PduIdType PduId, boolean Mode)
{
  boolean LblStepResult;
  // uint8 LucIndex;
  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Com_GucSwitchIPDUTxModeCount != 0x00) && 
        (Com_GucSwitchPduId == PduId) && (Com_GblSwitchMode == Mode))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Com_GucSwitchIPDUTxModeCount = 0x00;
      Com_GucSwitchPduId = 0x00;
      Com_GblSwitchMode = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
    
      if(Com_GucSwitchIPDUTxModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestCom_TriggerIPDUSend() */
#endif /* #ifdef BSWM_MODULE_ACTIVE */

/*******************************************************************************
**                     TestCom_DefaultBehavior()                              **
*******************************************************************************/
void TestCom_DefaultBehavior(void)
{
  uint8 LucDataIndex;
  
  #ifdef COMM_MODULE_ACTIVE
  uint8 LucCount;
  Com_GucSendSigCount = 0x00;
  
  for(LucCount = 0; LucCount < 6 ; LucCount++)
  {
    Com_GaaSignalRxData[LucCount] = 0;
  }
  #endif
  
  #ifdef BSWM_MODULE_ACTIVE
  Com_GucSetIpduGroupCount = 0;
  Com_GucSetIpduGroupCheckCount = 0;
  Com_GucTriggerIPDUCheckCount = 0;
  Com_GucReceptionDMControlCount = 0;
  Com_GucIpduGroupControlCount = 0;
  Com_GucTriggerIPDUSendCount = 0;
  Com_GucTriggerPduId = 0;
  Com_GucIpduGroupControlCheckCount = 0;
  Com_GblVectorBitVal = 0;
  #endif /* #ifdef BSWM_MODULE_ACTIVE */
  
  Com_GucTxConfCount = 0x00;
  Com_GucTxConfCheckCount = 0x00;
  Com_GucRxIndCount = 0x00;
  Com_GucRxIndCheckCount = 0x00;
  Com_GddSorRetVal = BUFREQ_OK;
  Com_GucTrigTransSetSduLength = 0x08;
  for(LucDataIndex = 0x00; LucDataIndex < COM_DATA_LENGTH; LucDataIndex++)
  {
    Com_GaaTrigTransSetData[LucDataIndex] = LucDataIndex;
  }
  Com_GucSendSigCount = 0x00;
  Com_GucTrigTransCount = 0x00;
  Com_GddTrigTransRetVal = E_OK;
}/* End TestCom_DefaultBehavior() */

#ifndef COMM_MODULE_ACTIVE
/*******************************************************************************
**                         Com_TxConfirmation()                               **
*******************************************************************************/
void Com_TxConfirmation(PduIdType TxPduId)
{
  #ifndef TYPICAL_CONFIG 
 /* Load actual PduId into Global variables */
  Com_GaaTxConfPduId[Com_GucTxConfCount] = TxPduId;
  /* Increment count variable to handle multiple invocations */
  if(Com_GucTxConfCount != COM_ARRAY_SIZE)
  {    
    Com_GucTxConfCount++;
  }
  #endif
} /* End Com_TxConfirmation() */

/*******************************************************************************
**                       TestCom_TxConfirmation()                             **
*******************************************************************************/
boolean TestCom_TxConfirmation(App_DataValidateType LucDataValidate,
  PduIdType ExpTxPduId)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count and Id */
      if((Com_GucTxConfCount == 0x01) &&  
        (ExpTxPduId == Com_GaaTxConfPduId[0]))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Com_GucTxConfCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Com_GucTxConfCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Com_GucTxConfCount; LucIndex++)
      {
        if(ExpTxPduId == Com_GaaTxConfPduId[LucIndex])
        {
          LblRetValue = STEP_PASSED;          
          LucIndex = Com_GucTxConfCount;
        } /* End if(ExpTxPduId == Com_GaaTxConfPduId[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < Com_GucTxConfCount; ...) */
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Com_GucTxConfCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Com_GucTxConfCount == Com_GucTxConfCheckCount)
      {
        Com_GucTxConfCount = 0;
        Com_GucTxConfCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < Com_GucTxConfCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpTxPduId == Com_GaaTxConfPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCom_TxConfirmation() */

/*******************************************************************************
**                       Com_RxIndication()                                   **
*******************************************************************************/
void Com_RxIndication(PduIdType RxPduId, PduInfoType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG 
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8* LpSduDataPtr;
  
  /* Load actual PduId, SduLength and SduDataPtr into Global variables */
  Com_GaaRxIndPduId[Com_GucRxIndCount] = RxPduId;
  Com_GaaRxIndSduLength[Com_GucRxIndCount] = (uint8)(PduInfoPtr->SduLength);
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > COM_DATA_LENGTH)
  {
    LucDataLength = COM_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = (uint8)(PduInfoPtr->SduLength);
  }
  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0x00; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    Com_GaaRxIndSduData[Com_GucRxIndCount][LucDataIndex] = *LpSduDataPtr;
    LpSduDataPtr++;
  }
  /* Increment count variable to handle multiple invocations */
  if(Com_GucRxIndCount != COM_ARRAY_SIZE)
  {    
    Com_GucRxIndCount++;
  }
  #endif
} /* End Com_RxIndication()*/

/*******************************************************************************
**                       TestCom_RxIndication()                               **
*******************************************************************************/
boolean TestCom_RxIndication(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Com_GucRxIndCount == 0x01) && (ExpRxPduId == Com_GaaRxIndPduId[0]))
      {
        ActPduInfo.SduLength = Com_GaaRxIndSduLength[0];
        ActPduInfo.SduDataPtr = &Com_GaaRxIndSduData[0][0];

        /* Validate SduLength and Data */
        if(ComTest_ValidateData(ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      Com_GucRxIndCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Com_GucRxIndCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Com_GucRxIndCount; LucIndex++)
      {
        if(ExpRxPduId == Com_GaaRxIndPduId[LucIndex])
        {
          ActPduInfo.SduLength = Com_GaaRxIndSduLength[LucIndex];
          ActPduInfo.SduDataPtr = &Com_GaaRxIndSduData[LucIndex][0];

          if(ComTest_ValidateData((PduInfoType *)ExpPduInfoPtr, &ActPduInfo))
          {
            LblRetValue = STEP_PASSED;
          }
          LucIndex = Com_GucRxIndCount;
        } /* End if(ExpRxPduId == Com_GaaRxIndPduId[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < Com_GucRxIndCount; ...) */
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Com_GucRxIndCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Com_GucRxIndCount == Com_GucRxIndCheckCount)
      {
        Com_GucRxIndCount = 0;
        Com_GucRxIndCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < Com_GucRxIndCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpRxPduId == Com_GaaRxIndPduId[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    } /* End case M_NOT_INVOKED: */
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCom_RxIndication() */

/*******************************************************************************
**                       Com_TpRxIndication()                                 **
*******************************************************************************/
void Com_TpRxIndication(PduIdType DcmRxPduId, NotifResultType Result)
{
  #ifndef TYPICAL_CONFIG 
  /* Load actual PduId and result into Global variables */
  Com_GddRxIndPduId = DcmRxPduId;
  Com_GddRxIndResult = Result;
  /* Increment count variable to handle multiple invocations */
  Com_GucTpRxIndCount++;
  #endif
} /* End Com_TpRxIndication() */
/*******************************************************************************
**                       TestCom_TpRxIndication()                             **
*******************************************************************************/
boolean TestCom_TpRxIndication(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, NotifResultType ExpResult)
{
  boolean LblRetValue;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count and Id */
      if((Com_GucTpRxIndCount == 0x01) && (ExpRxPduId == Com_GddRxIndPduId) && 
        (Com_GddRxIndResult == ExpResult))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Com_GucTpRxIndCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Com_GucTpRxIndCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);

} /* End TestCom_TpRxIndication() */


/*******************************************************************************
**                       Com_TriggerTransmit()                                **
*******************************************************************************/
Std_ReturnType Com_TriggerTransmit(PduIdType TxPduId, PduInfoType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG 
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8 *LpSduDataPtr;
  
  /* Load actual PduId, and adress of PduInfoPtr into Global variables */
  Com_GddTrigTransTxPduId = TxPduId;
  /* Copy the actual SduLength into actual SduDataPtr from global SduLength  */
  PduInfoPtr->SduLength = Com_GucTrigTransSetSduLength;
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > COM_DATA_LENGTH)
  {
    LucDataLength = COM_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = (uint8)(PduInfoPtr->SduLength);
  }
  
  /* Copy the actual data into actual SduDataPtr from global array */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    *LpSduDataPtr = Com_GaaTrigTransSetData[LucDataIndex];
    LpSduDataPtr++;
  }
  Com_GucTrigTransCount++;
  #endif
  return(Com_GddTrigTransRetVal);
}

/*******************************************************************************
**                       TestCom_TriggerTransmit()                            **
*******************************************************************************/
boolean TestCom_TriggerTransmit(App_DataValidateType LucDataValidate, 
  PduIdType ExpTxPduId, PduInfoType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  LblRetValue = STEP_FAILED;

  UNUSED(ExpPduInfoPtr);
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Com_GucTrigTransCount == 0x01) && 
        (ExpTxPduId == Com_GddTrigTransTxPduId))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Com_GucTrigTransCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Com_GucTrigTransCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCom_TriggerTransmit() */

/*******************************************************************************
**                       TestCom_TriggerTransmitSetRetVal()                   **
*******************************************************************************/
void TestCom_TriggerTransmitSetRetVal(Std_ReturnType RetVal, 
  PduInfoType *SetPduInfoPtr)
{
  uint8* LpSduDataPtr;
  uint8 LucDataLength;
  uint8 LucDataIndex;
  Com_GddTrigTransRetVal = RetVal;
  Com_GucTrigTransSetSduLength = (uint8)(SetPduInfoPtr->SduLength);
  LpSduDataPtr = SetPduInfoPtr->SduDataPtr;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(SetPduInfoPtr->SduLength > COM_DATA_LENGTH)
  {
    LucDataLength = COM_DATA_LENGTH;    
  }
  else
  {
    LucDataLength =(uint8)(SetPduInfoPtr->SduLength);
  }
  /* Copy the actual data into global array from actual SduDataPtr */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    Com_GaaTrigTransSetData[LucDataIndex] = *LpSduDataPtr;
    LpSduDataPtr++;
  }
  
} /* End TestCom_TriggerTransmitSetRetVal() */
/*******************************************************************************
**                       ComTest_ValidateData()                                  **
*******************************************************************************/
boolean ComTest_ValidateData(PduInfoType* LddExpPduInfo, 
  PduInfoType* LddActPduInfo)
{
  uint8 *LpActualDataPtr;
  uint8 *LpExpDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  LddSduCount = LddExpPduInfo->SduLength;
  LpExpDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  if((LddExpPduInfo->SduLength <= COM_DATA_LENGTH) &&
    (LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }

  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    if(*LpActualDataPtr != *LpExpDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualDataPtr++;
    LpExpDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* End ComTest_ValidateData() */
/*******************************************************************************
**                       Com_SendSignal()                                     **
*******************************************************************************/
uint8 Com_SendSignal( Com_SignalIdType SignalId, const void* SignalDataPtr)
{
  Com_GddSignalId = SignalId;
  Com_GpSignalDataPtr = SignalDataPtr;
  Com_GucSendSigCount++;
  return(0);
}
/*******************************************************************************
**                       TestCom_SendSignal()                                 **
*******************************************************************************/
boolean TestCom_SendSignal(App_DataValidateType LucDataValidate, 
  Com_SignalIdType ExpSignalId, const void* ExpSignalDataPtr)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((Com_GucSendSigCount == 0x01)&&
        (ExpSignalId == Com_GddSignalId) && 
        (ExpSignalDataPtr == Com_GpSignalDataPtr))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      Com_GucSendSigCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
}
/*******************************************************************************
**                       Com_StartOfReception()                               **
*******************************************************************************/
BufReq_ReturnType Com_StartOfReception(PduIdType ComRxPduId, 
  PduLengthType TpSduLength, PduLengthType *RxBufferSizePtr)
{
  #ifndef TYPICAL_CONFIG 
  /* Load actual PduId, TpSduLength into Global variables */
  Com_GddSorPduId = ComRxPduId;
  Com_GddSorTpSduLength = TpSduLength;
  /* Load RxBufferSizePtr with data of Com_GddSorRxBuffer  */
  *RxBufferSizePtr = Com_GddSorRxBuffer;
  /* Increment count variable to handle multiple invocations */
  Com_GucSorCount++;
  #endif
  return(Com_GddSorRetVal);
} /* End Com_StartOfReception() */

/*******************************************************************************
**                       TestCom_StartOfReceptionSetVal()                     **
*******************************************************************************/
void TestCom_StartOfReceptionSetVal(BufReq_ReturnType RetVal, 
  PduLengthType RxBufferSize)
{
  Com_GddSorRetVal = RetVal;
  Com_GddSorRxBuffer = RxBufferSize;
} /* End TestCom_StartOfReceptionSetVal() */

/*******************************************************************************
**                       TestCom_StartOfReception()                           **
*******************************************************************************/
boolean TestCom_StartOfReception(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, PduLengthType ExpTpSduLength, 
  PduLengthType *RxBufferSizePtr)
{
  boolean LblRetValue;
  *RxBufferSizePtr = 0;
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, Id and TpSduLength */
      if((Com_GucSorCount == 0x01) && (ExpRxPduId == Com_GddSorPduId) && 
        (Com_GddSorTpSduLength == ExpTpSduLength))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Com_GucSorCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Com_GucSorCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCom_StartOfReception() */

/*******************************************************************************
**                       Com_CopyRxData()                                     **
*******************************************************************************/
PduIdType Com_GddCopyRxDataPduId;
uint8 Com_GddCopyRxDataSduLength;
BufReq_ReturnType Com_CopyRxData(PduIdType ComRxPduId,
  const PduInfoType *PduInfoPtr, PduLengthType *RxBufferSizePtr)
{
  #ifndef TYPICAL_CONFIG 
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8 *LpSduDataPtr;
  /* Load the address of SduDataPtr into Local Variable */
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  
  /* Load actual PduId, SduLength into Global variables */
  Com_GddCopyRxDataPduId = ComRxPduId;
  Com_GddCopyRxDataSduLength = (uint8)(PduInfoPtr->SduLength);
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > COM_DATA_LENGTH)
  {
    LucDataLength = COM_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = (uint8)(PduInfoPtr->SduLength);
  }
  /* 
   * Load Com_GaaCopyRxDataSduData with SduDataPtr and RxBufferSizePtr 
   * with data of Com_GddCopyRxDataRxBuffer  
   */
  /* Load the SduDataPtr with the global array */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    Com_GaaCopyRxDataSduData[LucDataIndex] = *LpSduDataPtr;
    LpSduDataPtr++;
  }
  *RxBufferSizePtr = Com_GddCopyRxDataRxBuffer;
  /* Increment count variable to handle multiple invocations */
  Com_GucCopyRxDataCount++;
  #endif
  return(Com_GddCopyRxDataRetVal);
} /* End Com_CopyRxData() */

/*******************************************************************************
**                       TestCom_CopyRxData()                                 **
*******************************************************************************/
boolean TestCom_CopyRxData(App_DataValidateType LucDataValidate, 
  const PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr, 
  PduLengthType *ExpRxBufferSizePtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  *ExpRxBufferSizePtr = 0;
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, Id and SduLength */
      if((Com_GucCopyRxDataCount == 0x01) && 
      (Com_GddCopyRxDataPduId == ExpRxPduId))
      {
        ActPduInfo.SduLength = Com_GddCopyRxDataSduLength;
        ActPduInfo.SduDataPtr = &Com_GaaCopyRxDataSduData[0];

        /* Validate SduLength and Data */
        if(ComTest_ValidateData(ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      Com_GucCopyRxDataCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Com_GucCopyRxDataCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestCom_CopyRxData() */
#endif

#ifdef COMM_MODULE_ACTIVE
/*******************************************************************************
**                           ComMTest_ValidateData()                          **
*******************************************************************************/
boolean ComMTest_ValidateData(uint8* LpExpData, 
  uint8* LpActData)
{
  uint8 LucCount;
  boolean LblReturnValue;
  
  LblReturnValue = TRUE;
  LucCount = 0;

  while((LblReturnValue != FALSE) && (LucCount < Com_GucLength))
  {
    if(*LpActData != *LpExpData)
    {
      LblReturnValue = FALSE;
    }
    LpActData++;
    LpExpData++;
    LucCount++;
  }
  return(LblReturnValue);
} /* End ComMTest_ValidateData() */

/*******************************************************************************
**                       Com_SendSignal()                                     **
*******************************************************************************/
uint8 Com_SendSignal( Com_SignalIdType SignalId, const void* SignalDataPtr)
{
  Com_GaaSignalId[Com_GucSendSigCount] = SignalId;
  Com_GpSignalDataPtrCOMM = (uint8*)SignalDataPtr;
  Com_GucSendSigCount++;
  return(0);
}
/*******************************************************************************
**                       TestCom_SendSignal()                                 **
*******************************************************************************/
boolean TestCom_SendSignal(App_DataValidateType LucDataValidate, 
  Com_SignalIdType ExpSignalId, const void* ExpSignalDataPtr)
{
  boolean  LblStepResult;
  uint8 LucIndex;
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((Com_GucSendSigCount == 0x01)&&
        (ExpSignalId == Com_GaaSignalId[0]))
        {
          /* Validating the Data */
          if(ComMTest_ValidateData((uint8 *)ExpSignalDataPtr, 
            (uint8 *)Com_GpSignalDataPtrCOMM))
          {
            LblStepResult = STEP_PASSED;
          }
        }
      /* Reset API invocation Count after validating the API invocation */
      Com_GucSendSigCount = 0;
      break;
    }
     
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Com_GucSendSigCount; LucIndex++)
      {
        /* Validate SignalId and SignalDataPtr */
        if(ExpSignalId == Com_GaaSignalId[LucIndex])
        {
          /* Validating the Data */
          if(ComMTest_ValidateData((uint8 *)ExpSignalDataPtr, 
            (uint8 *)Com_GpSignalDataPtrCOMM))
          {
            LblStepResult = STEP_PASSED;
          }
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      Com_GucSendSigCount = 0;
      break;
    } /* End case M_VALIDATE: */
    
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
}
/*******************************************************************************
**                       TestCom_SignalMaxLength()                            **
*******************************************************************************/
void TestCom_SignalMaxLength(uint8 LucMaxPncData)
{
  Com_GucLength = LucMaxPncData;
}

/*******************************************************************************
**                       TestCom_ReceiveSignalSetPNC()                        **
*******************************************************************************/
void TestCom_ReceiveSignalSetPNC( PNCHandleType LddPncId)
{
  uint8 LucByteIndex;
  uint8 LucBitIndex;
  uint8 LucMask;
  /*Calculation Of Byte Index*/
  LucByteIndex = (LddPncId >> 3);
  /*Calculation Of Bit Index within the Byte */
  LucBitIndex =  (LddPncId % 8);
  /*Calculating the Mask Value for the bit Index*/
  LucMask = (uint8)(1 << LucBitIndex);
  /*set the receive buffer */
  Com_GaaSignalRxData[LucByteIndex] = 
    (Com_GaaSignalRxData[LucByteIndex] | LucMask);
}
/*******************************************************************************
**                       TestCom_ReceiveSignalClearPNC()                      **
*******************************************************************************/
void TestCom_ReceiveSignalClearPNC( PNCHandleType LddPncId)
{
  uint8 LucByteIndex;
  uint8 LucBitIndex;
  uint8 LucMask;
  /*Calculation Of Byte Index*/
  LucByteIndex = (LddPncId >> 3);
  /*Calculation Of Bit Index within the Byte */
  LucBitIndex =  (LddPncId % 8);
  /*Calculating the Mask Value for the bit Index*/
  LucMask = (uint8)(1 << LucBitIndex);
  /*Clear the receive buffer */
  Com_GaaSignalRxData[LucByteIndex] = 
    (Com_GaaSignalRxData[LucByteIndex] & (~LucMask));                                      
                                   
}

/*******************************************************************************
**                       Com_ReceiveSignal()                                  **
*******************************************************************************/
uint8 Com_ReceiveSignal(Com_SignalIdType SignalId, void* SignalDataPtr)
{
  uint8 LucByteIndex;

  for(LucByteIndex = 0; LucByteIndex < Com_GucLength; LucByteIndex++)
  {
    *((uint8* ) SignalDataPtr + LucByteIndex) = Com_GaaSignalRxData[LucByteIndex];
  }
  Com_GddRxSignalId = SignalId;
  
  Com_GucReceiveSigCount++;
  return(0);
}
/*******************************************************************************
**                       TestCom_ReceiveSignal()                              **
*******************************************************************************/
boolean TestCom_ReceiveSignal(App_DataValidateType LucDataValidate, 
  Com_SignalIdType ExpSignalId, void* ExpSignalDataPtr)
{
  boolean  LblStepResult;
  uint8* LpSignalDataPtr;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
     if((Com_GucReceiveSigCount == 0x01)&&
      (ExpSignalId == Com_GddRxSignalId))
      {
        LpSignalDataPtr = Com_GaaSignalRxData;
        /* Validating the Data */
        if(ComMTest_ValidateData((uint8 *)ExpSignalDataPtr, 
            LpSignalDataPtr))
        {
          LblStepResult = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      Com_GucReceiveSigCount = 0;
      
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
}
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

