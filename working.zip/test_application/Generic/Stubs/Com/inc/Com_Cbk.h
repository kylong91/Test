/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Com_Cbk.h                                                     **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Com_Cbk Stub                                          **
**                                                                            **
**  PURPOSE   : Declaration of Com_Cbk functions                              **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/


/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

#ifndef COM_CBK_H
#define COM_CBK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern void Com_TxConfirmation(PduIdType TxPduId);

extern boolean TestCom_TxConfirmation(App_DataValidateType LucDataValidate,
  PduIdType ExpTxPduId);

extern void Com_RxIndication(PduIdType RxPduId,
  PduInfoType *PduInfoPtr);

extern void Com_TpRxIndication(PduIdType DcmRxPduId, NotifResultType Result);

extern boolean TestCom_RxIndication(App_DataValidateType LucDataValidate,
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr);

extern boolean TestCom_TpRxIndication(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, NotifResultType ExpResult);

extern Std_ReturnType Com_TriggerTransmit(PduIdType TxPduId,
  PduInfoType *PduInfoPtr);

extern boolean TestCom_TriggerTransmit(App_DataValidateType LucDataValidate,
  PduIdType ExpTxPduId, PduInfoType *ExpPduInfoPtr);

extern void TestCom_TriggerTransmitSetRetVal(Std_ReturnType RetVal,
  PduInfoType *SetPduInfoPtr);

extern boolean ComTest_ValidateData(PduInfoType* LddExpPduInfo,
  PduInfoType* LddActPduInfo);
  
extern BufReq_ReturnType Com_CopyRxData(PduIdType ComRxPduId,
  const PduInfoType *PduInfoPtr, PduLengthType *RxBufferSizePtr);
  
extern boolean TestCom_CopyRxData(App_DataValidateType LucDataValidate, 
  const PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr, 
  PduLengthType *ExpRxBufferSizePtr);
  
extern boolean TestCom_StartOfReception(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, PduLengthType ExpTpSduLength, 
  PduLengthType *RxBufferSizePtr);

extern BufReq_ReturnType Com_StartOfReception(PduIdType ComRxPduId, 
  PduLengthType TpSduLength, PduLengthType *RxBufferSizePtr);
  
extern void TestCom_StartOfReceptionSetVal(BufReq_ReturnType RetVal, 
  PduLengthType RxBufferSize);
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/



