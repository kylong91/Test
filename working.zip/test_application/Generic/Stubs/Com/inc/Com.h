/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Com.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Com Stub                                              **
**                                                                            **
**  PURPOSE   : Declaration of Com Stub functions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/


/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

#ifndef COM_H
#define COM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/          
#include "ComStack_Types.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/
#define NO_OF_IPDU_GROUPIDS 0x0A
#define NO_OF_BITVAL 0x03
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
typedef uint8 Com_ConfigType;

/* Signal object identifier */
typedef uint16 Com_SignalIdType;

/* ComIpduGroupVector */
typedef uint16 Com_IpduGroupIdType;
typedef uint8 Com_IpduGroupVector[10];

extern Com_IpduGroupIdType Com_GddIpduGroupId;
extern uint8* Com_GpIpduGroupVector;
extern boolean Com_Gddinitialize;
extern boolean Com_Gddbitval;
extern uint8 Com_GucSetIpduGroupCount;
extern uint8 Com_GucSetIpduGroupCheckCount;
extern uint8 Com_GucIpduGroupControlCount;
extern uint8 Com_GucIpduGroupControlCheckCount;
extern uint8 Com_GucReceptionDMControlCount;
extern uint8 Com_GucClearIpduGroupVectorCount;

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define COM_AR_RELEASE_MAJOR_VERSION         0x04
#define COM_AR_RELEASE_MINOR_VERSION         0x00
#define COM_AR_RELEASE_REVISION_VERSION      0x03

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define COM_DATA_LENGTH                      0x0B
#define COM_ARRAY_SIZE                       0x04

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern uint8 Com_SendSignal(Com_SignalIdType SignalId, 
  const void* SignalDataPtr);
  
extern uint8 Com_ReceiveSignal(Com_SignalIdType SignalId, void* SignalDataPtr);

extern void TestCom_ReceiveSignalSetPNC( PNCHandleType LddPncId);

extern void TestCom_ReceiveSignalClearPNC( PNCHandleType LddPncId);

extern boolean TestCom_SendSignal(App_DataValidateType LucDataValidate, 
  Com_SignalIdType ExpSignalId, const void* ExpSignalDataPtr);

extern void TestCom_DefaultBehavior(void);

extern void Com_SetIpduGroup(Com_IpduGroupVector ipduGroupVector, 
  Com_IpduGroupIdType ipduGroupId, boolean bitval);
  
extern void Com_IpduGroupControl(Com_IpduGroupVector ipduGroupVector, 
  boolean initialize);

extern void Com_ReceptionDMControl(Com_IpduGroupVector ipduGroupVector);

extern void Com_ClearIpduGroupVector(Com_IpduGroupVector ipduGroupVector);

extern void Com_TriggerIPDUSend(PduIdType PduId);

extern void Com_SwitchIpduTxMode(PduIdType PduId, boolean Mode);

extern boolean TestCom_TriggerIPDUSend(App_DataValidateType LucDataValidate, 
PduIdType PduId);

extern boolean TestCom_SwitchIpduTxMode(App_DataValidateType LucDataValidate, 
PduIdType PduId, boolean Mode);

extern  boolean TestCom_SetIpduGroup(App_DataValidateType LucDataValidate, 
  Com_IpduGroupVector LddExpipduGroupVector, 
  Com_IpduGroupIdType LddExpipduGroupId, boolean LddExpbitval); 
  
extern  boolean TestCom_IpduGroupControl
  (App_DataValidateType LucDataValidate,Com_IpduGroupVector 
  LddExpipduGroupVector, boolean LddExpinitialize);
  
extern  boolean TestCom_ReceptionDMControl(App_DataValidateType 
  LucDataValidate, Com_IpduGroupVector LddExpipduGroupVector); 
  
extern  boolean TestCom_ClearIpduGroupVector
  (App_DataValidateType LucDataValidate, 
  Com_IpduGroupVector LddExpipduGroupVector);
  
extern boolean TestCom_ReceiveSignal(App_DataValidateType LucDataValidate, 
  Com_SignalIdType ExpSignalId, void* ExpSignalDataPtr);

extern void TestCom_SignalMaxLength(uint8 LucMaxPncData);  
extern void Com_Init(const Com_ConfigType* config);

extern boolean TestCom_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);     
  
#endif /* COM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

