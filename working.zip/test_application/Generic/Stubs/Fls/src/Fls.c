/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Fls.c                                                         **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FLS Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Fls Stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0    30-Aug-2012   Ravi Tiwari    Initial version                      **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Fls.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#ifdef BSWM_MODULE_ACTIVE
uint8 Fls_GucInitCnt;
uint8 Fls_GucInitSeqCnt;
#endif
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
#ifdef BSWM_MODULE_ACTIVE

/*******************************************************************************
**                          Fls_Init()                                        **
*******************************************************************************/

void Fls_Init(const Fls_ConfigType* ConfigPtr)
{
  UNUSED(ConfigPtr);
	App_GucApiSeqCnt++;
	Fls_GucInitSeqCnt = App_GucApiSeqCnt;
	Fls_GucInitCnt++;
}/* End Fls_Init() */

/*******************************************************************************
**                           TestFls_Init()                                   **
*******************************************************************************/
boolean TestFls_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Fls_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Fls_GucInitCnt = 0;
      Fls_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(Fls_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Fls_GucInitCnt = 0;
      Fls_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestFls_Init() */

#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
