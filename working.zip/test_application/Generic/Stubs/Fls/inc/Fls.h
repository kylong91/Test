/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Fls.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FLS Stub                                              **
**                                                                            **
**  PURPOSE   : Declaration of Fls Stub functions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/
#ifndef FLS_H
#define FLS_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

#include "ComStack_Types.h"
#include "TC_Generic.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define FLS_AR_RELEASE_MAJOR_VERSION    4
#define FLS_AR_RELEASE_MINOR_VERSION    0
#define FLS_AR_RELEASE_REVISION_VERSION 3

/*******************************************************************************
**                         Global Data                                        **
*******************************************************************************/
typedef uint8 Fls_ConfigType;

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern void Fls_Init(const Fls_ConfigType* ConfigPtr);

extern boolean TestFls_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);
  
#endif /* FLS_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

