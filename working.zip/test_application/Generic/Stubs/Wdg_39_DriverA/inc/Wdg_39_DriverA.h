/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Wdg_39_DriverA.h                                              **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Wdg_39_DriverA Interface module                       **
**                                                                            **
**  PURPOSE   : Declaration of Wdg_39_DriverA functions                       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By             Description                         **
********************************************************************************
** 1.0.0     05/12/2012    JAISON JOHN    Creation of Wdg.h module            **
*******************************************************************************/
#ifndef WDG_39_DRIVERA_H
#define WDG_39_DRIVERA_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "WdgIf_Types.h"
#include "TC_Generic.h"
/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define WDG_39_DRIVERA_AR_RELEASE_MAJOR_VERSION      4
#define WDG_39_DRIVERA_AR_RELEASE_MINOR_VERSION      0
#define WDG_39_DRIVERA_AR_RELEASE_REVISION_VERSION   3

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Std_ReturnType Wdg_39_DriverA_SetMode(WdgIf_ModeType Mode);

extern boolean TestWdg_39_DriverA_SetMode(App_DataValidateType LddDataValidate,
  WdgIf_ModeType LddExpMode);
  
extern void Wdg_39_DriverA_SetTriggerCondition(uint16 timeout);

extern boolean TestWdg_39_DriverA_SetTriggerCondition(App_DataValidateType 
  LddDataValidate, uint16 LddExptimeout);
  
extern void TestWdg_39_DriverA_SetModeRetVal(Std_ReturnType LddWdgReturnVal);

extern void TestWdg_39_DriverA_DefaultBehavior(void);

#endif /* Wdg_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
