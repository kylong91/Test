/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Wdg_39_DriverA.c                                              **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Wdg_39_DriverA Stub                                   **
**                                                                            **
**  PURPOSE   : This application file contains the Wdg_39_DriverA stub        **
**              functions                                                     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By             Description                         **
********************************************************************************
** 1.0.0     05-Dec-2012   JAISON JOHN    Initial version                     **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Wdg_39_DriverA.h"
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Wdg_GucDrvASetModeCount;
WdgIf_ModeType Wdg_GddDrvAMode;

uint8 Wdg_GucDrvASetTriggerCondCount;
uint16 Wdg_GucDrvAtimeout;

Std_ReturnType Wdg_GddDrvASetModeRetVal;
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
**                            Wdg_39_DriverA_SetMode()                        **
*******************************************************************************/
Std_ReturnType Wdg_39_DriverA_SetMode(WdgIf_ModeType Mode)
{
  /* Load actual Mode into Global variables */
  Wdg_GddDrvAMode = Mode;
  Wdg_GucDrvASetModeCount++;

  return(Wdg_GddDrvASetModeRetVal);
} /* End Wdg_39_DriverA_SetMode() */

/*******************************************************************************
**                         TestWdg_39_DriverA_SetMode()                       **
*******************************************************************************/
boolean TestWdg_39_DriverA_SetMode(App_DataValidateType LddDataValidate,
  WdgIf_ModeType LddExpMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Mode  */
      if((Wdg_GucDrvASetModeCount == 0x01) &&
        (Wdg_GddDrvAMode == LddExpMode)) 
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Wdg_GucDrvASetModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Wdg_GucDrvASetModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Wdg_GucDrvASetModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */
  return(LblStepResult);
} /* End TestWdg_39_DriverA_SetMode() */

/*******************************************************************************
**                          Wdg_39_DriverA_SetTriggerCondition()              **
*******************************************************************************/
void Wdg_39_DriverA_SetTriggerCondition(uint16 timeout)
{
  /* Load actual timeout into Global variables */
  Wdg_GucDrvASetTriggerCondCount++;
  Wdg_GucDrvAtimeout = timeout;
}  /* End Wdg_39_DriverA_SetTriggerCondition() */

/*******************************************************************************
**                        TestWdg_39_DriverA_SetTriggerCondition()            **
*******************************************************************************/
boolean TestWdg_39_DriverA_SetTriggerCondition(App_DataValidateType 
  LddDataValidate,uint16 LddExptimeout)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and timeout  */
      if((Wdg_GucDrvASetTriggerCondCount == 0x01) &&
        (Wdg_GucDrvAtimeout == LddExptimeout))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Wdg_GucDrvASetTriggerCondCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Wdg_GucDrvASetTriggerCondCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Wdg_GucDrvASetTriggerCondCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestWdg_39_DriverA_SetTriggerCondition() */
/*******************************************************************************
**                    TestWdg_39_DriverA_SetModeRetVal()                      **
*******************************************************************************/
void TestWdg_39_DriverA_SetModeRetVal(Std_ReturnType LddWdgReturnVal)
{
  Wdg_GddDrvASetModeRetVal = LddWdgReturnVal;
}
/* End TestWdg_39_DriverA_SetModeRetVal() */
/*******************************************************************************
**                     TestWdg_39_DriverA_DefaultBehavior()                   **
*******************************************************************************/
void TestWdg_39_DriverA_DefaultBehavior(void)
{
 Wdg_GddDrvASetModeRetVal = E_OK;
 Wdg_GucDrvASetModeCount = 0;
 Wdg_GucDrvASetTriggerCondCount = 0;
 Wdg_GucDrvAtimeout = 0;
} /* End TestWdg_39_DriverA_DefaultBehavior() */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

