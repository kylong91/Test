/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: MemIf.c                                                       **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR MemIf Stub                                            **
**                                                                            **
**  PURPOSE   : This application file contains the MemIf Stub functions       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     24-Nov-2012   Ankur    Initial Version                           **
*******************************************************************************/
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "MemIf.h"
#ifdef NVM_MODULE_ACTIVE
#include "App_NvM_Sub_Functions.h"
#endif

/*******************************************************************************
**                          Global Data Types                                 **
*******************************************************************************/
#ifdef NVM_MODULE_ACTIVE
uint8 NvM_GucReadIndCount = 0;
uint8 NvM_GaaCurrentDeviceIndex[NVM_ARRAY_SIZE];
uint16 NvM_GaaCurrentBlockNumber[NVM_ARRAY_SIZE];
uint16 NvM_GaaCurrentBlockOffset[NVM_ARRAY_SIZE];
uint16 NvM_GaaCurrentBlockLength[NVM_ARRAY_SIZE];
uint8 NvM_GucDeviceIndex;
uint8 NvM_GucCurrentDeviceInd;
uint8 NvM_GaaWriteDataBuffer[NVM_ARRAY_SIZE];
uint8 NvM_GaaDeviceInvoked[NVM_ARRAY_SIZE];

uint8 NvM_GaaBlkInvoked[NVM_ARRAY_SIZE];
uint8 NvM_GucCurrentBlkCrc[NVM_TOTAL_NUM_OF_NVRAM_BLOCKS];
uint8 NvM_GaaReadDataBuffer[NVM_ARRAY_SIZE];
uint8 NvM_GucWriteIndCount = 0;
uint8 NvM_GucModeIndCount = 0;
uint8 NvM_GucInvalidateIndCount = 0;
uint8 NvM_GucEraseIndCount = 0;
uint8 NvM_GucCancelIndCount = 0;
uint8 NvM_GucJobResultIndCount = 0;
MemIf_ModeType NvM_GucCurrentMode[NVM_ARRAY_SIZE];

Std_ReturnType NvM_GddInvalidateBlkRetVal;
Std_ReturnType NvM_GddEraseBlkRetVal;
Std_ReturnType NvM_GddWriteRetVal;
Std_ReturnType NvM_GddReadRetVal;
MemIf_JobResultType NvM_GddGetJobResultRetVal;
#endif

/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
#ifdef NVM_MODULE_ACTIVE
/*******************************************************************************
**                          App_TestMemIfPrepareData()                        **
*******************************************************************************/
void App_TestMemIfPrepareData(uint8 Length, uint8 *LpDataPtr)
{
  uint8 LucIndex;
  for(LucIndex = 0x00; LucIndex < Length; LucIndex++)
  {
    NvM_GaaReadDataBuffer[LucIndex] = *LpDataPtr;
    LpDataPtr++;
  }
} /* End App_TestMemIfPrepareData() */

/*******************************************************************************
**                             MemIf_Read()                                   **
*******************************************************************************/
Std_ReturnType MemIf_Read(uint8 DeviceIndex, uint16 BlockNumber, 
  uint16 BlockOffset, uint8 *DataBufferPtr, uint16 Length)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8 *LpDataBufferPtr;
  
  NvM_GaaCurrentDeviceIndex[NvM_GucReadIndCount] = DeviceIndex;
  NvM_GaaCurrentBlockNumber[NvM_GucReadIndCount] = BlockNumber;
  NvM_GaaCurrentBlockLength[NvM_GucReadIndCount] = Length;
  NvM_GaaCurrentBlockOffset[NvM_GucReadIndCount] = BlockOffset;
  
  LpDataBufferPtr = (uint8 *)DataBufferPtr;
  
  for(LucDataIndex = 0x00; LucDataIndex < NvM_GaaCurrentBlockLength[NvM_GucReadIndCount]; 
    LucDataIndex++)
  {
    *LpDataBufferPtr = NvM_GaaReadDataBuffer[LucDataIndex];
    LpDataBufferPtr++;
  }
  NvM_GucReadIndCount++;
  
  return(NvM_GddReadRetVal);
  #endif
} /* End MemIf_Read() */

/*******************************************************************************
**                             TestMemIf_Read()                               **
*******************************************************************************/
boolean TestMemIf_Read(App_DataValidateType LucDataValidate, 
  uint8 LucExpDeviceIndex, uint16 LucExpBlockNumber, uint16 LucExpBlockOffset, 
  const uint8* LpExpDataBufferPtr, uint16 LucExpLength)
{
  boolean LblStepResult;
  uint8 *ActData;
  uint8 LucIndex;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((NvM_GucReadIndCount == 0x01) 
        && (LucExpDeviceIndex == NvM_GaaCurrentDeviceIndex[0]) 
        && (LucExpBlockNumber == NvM_GaaCurrentBlockNumber[0])
        && (LucExpLength == NvM_GaaCurrentBlockLength[0])
        && (LucExpBlockOffset == NvM_GaaCurrentBlockOffset[0]))
      {
        ActData = &NvM_GaaReadDataBuffer[0];
        
        /* Validating the Data */
        if(NvMTest_ValidateData((uint8 *)LpExpDataBufferPtr, ActData, 
          LucExpLength))
        {
          LblStepResult = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      NvM_GucReadIndCount = 0;      
      break;
    } /* End case S_VALIDATE: */
     case M_VALIDATE:
    {
      for(LucIndex = 0; LucIndex < NvM_GucReadIndCount; LucIndex++)
      {
        if((NvM_GaaCurrentDeviceIndex[LucIndex] == LucExpDeviceIndex) && 
          (NvM_GaaCurrentBlockNumber[LucIndex] == LucExpBlockNumber))
        {
          ActData = &NvM_GaaReadDataBuffer[0];
          if(NvMTest_ValidateData((uint8 *)LpExpDataBufferPtr, ActData, 
            LucExpLength))
          {
            LblStepResult = STEP_PASSED;
          }
          LucIndex = NvM_GucReadIndCount;
        }
      }
      NvM_GucReadIndCount = 0;      
      break;
    } /* End case M_VALIDATE: */
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(NvM_GucReadIndCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End TestMemIf_Read() */

/*******************************************************************************
**                        TestNvM_MultiBlkMemIf_Read()                        **
*******************************************************************************/
boolean TestNvM_MultiBlkMemIf_Read(App_DataValidateType LucDataValidate, 
  uint8 LucExpDeviceIndex, uint16 LucExpBlockNumber, uint16 BlockOffset, 
  uint8* LpExpDataBufferPtr, uint16 LucExpLength)
{
  uint8 *ActData;
  uint8 LucIndex;
  uint8 NvM_LucIndex;
  boolean LblStepResult;
  UNUSED(LucExpDeviceIndex);
  UNUSED(LucExpBlockNumber);
  
  LblStepResult = STEP_FAILED;
  
  for(NvM_LucIndex = 0; NvM_LucIndex <= NVM_TOTAL_NUM_OF_NVRAM_BLOCKS; 
    NvM_LucIndex++)
  {
    if(NvM_GaaCurrentBlockNumber[(NvM_GucReadIndCount-1)] == NvM_GaaBlockNumber[NvM_LucIndex])
    {
      NvM_GaaBlkInvoked[NvM_LucIndex] = BLOCK_INVOKED;
      NvM_GaaDeviceInvoked[NvM_GucDevIndex] = NvM_GaaCurrentDeviceIndex[NvM_GucReadIndCount-1];
      NvM_GucDevIndex++;
      break;
    }
  }
  
  NvM_GaaCurrentBlockOffset[NvM_GucReadIndCount] = BlockOffset;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      {
        if((NvM_GucReadIndCount == 0x01) && 
          (NvM_GaaCurrentDeviceIndex[0] == NvM_GaaDeviceInvoked[NvM_GucDevIndex-1]) && 
          (NvM_GaaCurrentBlockNumber[0] == NvM_GaaBlockNumber[NvM_LucIndex]))
        {
          ActData = &NvM_GaaReadDataBuffer[0];
          
          if(NvMTest_ValidateData((uint8 *)LpExpDataBufferPtr, ActData, 
            (uint16) LucExpLength))
          {
            LblStepResult = STEP_PASSED;
          }
        }
        /* Reset API invocation Count after validating the API invocation */
        NvM_GucReadIndCount = 0;
        break;
      }
    }
    case M_VALIDATE:
    {
      for(LucIndex = 0; LucIndex < NvM_GucReadIndCount; LucIndex++)
      {
        if((NvM_GaaCurrentDeviceIndex[LucIndex] == NvM_GaaDeviceInvoked[NvM_GucDevIndex-1]) && 
          (NvM_GaaCurrentBlockNumber[LucIndex] == NvM_GaaBlockNumber[NvM_LucIndex]))
        {
          ActData = &NvM_GaaReadDataBuffer[0];
          
          if(NvMTest_ValidateData((uint8 *)LpExpDataBufferPtr, ActData, 
            (uint16) LucExpLength))
          {
            LblStepResult = STEP_PASSED;
          }
          LucIndex = NvM_GucReadIndCount;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      NvM_GucReadIndCount = 0;      
      break;
    } /* End case M_VALIDATE: */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(NvM_GucReadIndCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End of TestNvM_MultiBlkMemIf_Read */

/*******************************************************************************
**                                MemIf_Write()                               **
*******************************************************************************/
Std_ReturnType MemIf_Write(uint8 DeviceIndex, uint16 BlockNumber,
  uint8* DataBufferPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  
  NvM_GaaCurrentDeviceIndex[NvM_GucWriteIndCount] = DeviceIndex;
  NvM_GaaCurrentBlockNumber[NvM_GucWriteIndCount] = BlockNumber;
  
  for(LucDataIndex = 0x00; LucDataIndex < NVM_WRITE_LENGTH; LucDataIndex++)
  {
    NvM_GaaWriteDataBuffer[LucDataIndex] = *DataBufferPtr;
    // NvM_GaaWriteDataBuffer1[LucDataIndex] = *DataBufferPtr;
    DataBufferPtr++;
  }
  NvM_GucWriteIndCount++;
  
  return(NvM_GddWriteRetVal);
  #endif
} /* End of MemIf_Write */

/*******************************************************************************
**                                TestMemIf_Write()                           **
*******************************************************************************/
boolean TestMemIf_Write(App_DataValidateType LucDataValidate, 
  uint8 LucExpDeviceIndex, uint16 LucExpBlockNumber, 
  const uint8* LpExpDataBufferPtr, uint16 LucExpLength)
{
  boolean LblStepResult;
  uint8 LucIndex;
  uint8 *ActData;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((NvM_GucWriteIndCount == 0x01) 
        && (LucExpDeviceIndex == NvM_GaaCurrentDeviceIndex[0]) 
        && (LucExpBlockNumber == NvM_GaaCurrentBlockNumber[0]))
      {
        ActData = &NvM_GaaWriteDataBuffer[0];
        
        /* Validating the Data */
        if(NvMTest_ValidateData((uint8 *)LpExpDataBufferPtr, ActData, 
          LucExpLength))
        {
          LblStepResult = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      NvM_GucWriteIndCount = 0;
      break;
    } /* End case S_VALIDATE: */
    case M_VALIDATE:
    {
      for(LucIndex = 0; LucIndex < NvM_GucWriteIndCount; LucIndex++)
      {
        if((NvM_GaaCurrentDeviceIndex[LucIndex] == LucExpDeviceIndex) && 
          (NvM_GaaCurrentBlockNumber[LucIndex] == LucExpBlockNumber))
        {
          ActData = &NvM_GaaWriteDataBuffer[0];
          
          if(NvMTest_ValidateData((uint8 *)LpExpDataBufferPtr, ActData, 
            LucExpLength))
          {
            LblStepResult = STEP_PASSED;
          }
          LucIndex = NvM_GucWriteIndCount;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      NvM_GucWriteIndCount = 0;      
      break;
    } /* End case M_VALIDATE: */
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(NvM_GucWriteIndCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End TestMemIf_Write() */

/*******************************************************************************
**                     TestNvM_MultiBlkMemIf_Write()                          **
*******************************************************************************/
boolean TestNvM_MultiBlkMemIf_Write(App_DataValidateType LucDataValidate, 
  uint8 LucExpDeviceIndex, uint16 LucExpBlockNumber, 
  const uint8* LpExpDataBufferPtr, uint16 LucExpLength)
{
  boolean LblStepResult;
  uint8 LucIndex;
  uint8 *ActData;
  uint8 NvM_LucIndex;
  UNUSED(LucExpDeviceIndex);
  UNUSED(LucExpBlockNumber);
  
  LblStepResult = STEP_FAILED;
  
  for(NvM_LucIndex = 0; NvM_LucIndex <= NVM_TOTAL_NUM_OF_NVRAM_BLOCKS; 
    NvM_LucIndex++)
  {
    if(NvM_GaaCurrentBlockNumber[NvM_GucWriteIndCount-1] == NvM_GaaBlockNumber[NvM_LucIndex])
    {
      NvM_GaaBlkInvoked[NvM_LucIndex] = BLOCK_INVOKED;
      NvM_GaaDeviceInvoked[NvM_GucDevIndex] = NvM_GaaCurrentDeviceIndex[NvM_GucWriteIndCount-1];
      NvM_GucDevIndex++;
      break;
    }
  }
    
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((NvM_GucWriteIndCount == 0x01) && 
        (NvM_GaaCurrentDeviceIndex[0] == NvM_GaaDeviceInvoked[NvM_GucDevIndex-1]) && 
        (NvM_GaaCurrentBlockNumber[0] == NvM_GaaBlockNumber[NvM_LucIndex]))
      {
        ActData = &NvM_GaaWriteDataBuffer[0];
        
        if(NvMTest_ValidateData((uint8 *)LpExpDataBufferPtr, ActData, 
          (uint16) LucExpLength))
        {
          LblStepResult = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      NvM_GucWriteIndCount = 0;
      break;
    }
    case M_VALIDATE:
    {
      for(LucIndex = 0; LucIndex < NvM_GucWriteIndCount; LucIndex++)
      {
        if((NvM_GaaCurrentDeviceIndex[LucIndex] == NvM_GaaDeviceInvoked[NvM_GucDevIndex-1]) && 
          (NvM_GaaCurrentBlockNumber[LucIndex] == NvM_GaaBlockNumber[NvM_LucIndex]))
        {
          ActData = &NvM_GaaWriteDataBuffer[0];
          
          if(NvMTest_ValidateData((uint8 *)LpExpDataBufferPtr, ActData, 
            (uint16) LucExpLength))
          {
            LblStepResult = STEP_PASSED;
          }
          LucIndex = NvM_GucWriteIndCount;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      NvM_GucWriteIndCount = 0;      
      break;
    } /* End case M_VALIDATE: */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(NvM_GucWriteIndCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End TestNvM_MultiBlkMemIf_Write() */

/*******************************************************************************
**                            MemIf_GetJobResult()                            **
*******************************************************************************/
MemIf_JobResultType MemIf_GetJobResult(uint8 DeviceIndex)
{
  #ifndef TYPICAL_CONFIG
  NvM_GaaCurrentDeviceIndex[NvM_GucJobResultIndCount] = DeviceIndex;
  NvM_GucJobResultIndCount++;
  
  return(NvM_GddGetJobResultRetVal);
  #endif
} /* End MemIf_GetJobResult() */

/*******************************************************************************
**                         TestMemIf_GetJobResult()                           **
*******************************************************************************/
boolean TestMemIf_GetJobResult(App_DataValidateType LucDataValidate, 
  uint8 LucExpDeviceIndex)
{
  boolean LblStepResult;
  uint8 LucIndex;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((NvM_GucJobResultIndCount == 0x01) 
        && (LucExpDeviceIndex == NvM_GaaCurrentDeviceIndex[0]))
      {
        LblStepResult = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      NvM_GucJobResultIndCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    case M_VALIDATE:
    {
      for(LucIndex = 0; LucIndex < NvM_GucJobResultIndCount; LucIndex++)
      {
        /* Validate ControllerId and ControllerMode */
        if((LucExpDeviceIndex == NvM_GaaCurrentDeviceIndex[LucIndex]))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = NvM_GucJobResultIndCount;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      NvM_GucJobResultIndCount = 0;      
      break;
    } /* End case M_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(NvM_GucJobResultIndCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End TestMemIf_GetJobResult() */

/*******************************************************************************
**                     TestNvM_MultiBlkMemIf_GetJobResult()                   **
*******************************************************************************/
boolean TestNvM_MultiBlkMemIf_GetJobResult(App_DataValidateType LucDataValidate, 
  uint8 LucExpDeviceIndex)
{
  boolean LblStepResult;
  uint8 LucIndex;
  
  LblStepResult = STEP_FAILED;
  
  NvM_GucCurrentDeviceInd = LucExpDeviceIndex;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((NvM_GucJobResultIndCount == 0x01) && 
        (NvM_GaaCurrentDeviceIndex[0] == 
        NvM_GaaDeviceInvoked[NvM_GucDevIndex-1]))
      {
        LblStepResult = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      NvM_GucJobResultIndCount = 0;      
      break;
    }
    case M_VALIDATE:
    {
      for(LucIndex = 0; LucIndex < NvM_GucJobResultIndCount; LucIndex++)
      {
        /* Validate ControllerId and ControllerMode */
        if((NvM_GaaCurrentDeviceIndex[LucIndex] == 
        NvM_GaaDeviceInvoked[NvM_GucDevIndex-1]))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = NvM_GucJobResultIndCount;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      NvM_GucJobResultIndCount = 0;      
      break;
    } /* End case M_VALIDATE: */
    case S_NOT_INVOKED:
    {
      if(NvM_GucJobResultIndCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End TestNvM_MultiBlkMemIf_GetJobResult() */

/*******************************************************************************
**                               MemIf_Cancel()                               **
*******************************************************************************/
void MemIf_Cancel(uint8 DeviceIndex)
{
  #ifndef TYPICAL_CONFIG
  NvM_GaaCurrentDeviceIndex[NvM_GucCancelIndCount] = DeviceIndex;
  NvM_GucCancelIndCount++;
  #endif
} /* End MemIf_Cancel() */

/*******************************************************************************
**                              TestMemIf_Cancel()                            **
*******************************************************************************/
boolean TestMemIf_Cancel(App_DataValidateType LucDataValidate, 
  uint8 LucExpDeviceIndex)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((NvM_GucCancelIndCount == 0x01) 
        && (LucExpDeviceIndex == NvM_GaaCurrentDeviceIndex[0]))
      {
        LblStepResult = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      NvM_GucCancelIndCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(NvM_GucCancelIndCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End TestMemIf_Cancel() */

/*******************************************************************************
**                         MemIf_EraseImmediateBlock()                        **
*******************************************************************************/
Std_ReturnType MemIf_EraseImmediateBlock(uint8 DeviceIndex, uint16 BlockNumber)
{
  #ifndef TYPICAL_CONFIG
  NvM_GaaCurrentDeviceIndex[NvM_GucEraseIndCount] = DeviceIndex;
  NvM_GaaCurrentBlockNumber[NvM_GucEraseIndCount] = BlockNumber;
  NvM_GucEraseIndCount++;
  
  return(NvM_GddEraseBlkRetVal);
  #endif
} /* End MemIf_EraseImmediateBlock() */

/*******************************************************************************
**                     TestMemIf_EraseImmediateBlock()                        **
*******************************************************************************/
boolean TestMemIf_EraseImmediateBlock(App_DataValidateType LucDataValidate, 
  uint8 LucExpDeviceIndex, uint16 LucExpBlockNumber)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((NvM_GucEraseIndCount == 0x01) 
        && (LucExpDeviceIndex == NvM_GaaCurrentDeviceIndex[0])
        && (LucExpBlockNumber == NvM_GaaCurrentBlockNumber[0]))
      {
        LblStepResult = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      NvM_GucEraseIndCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(NvM_GucEraseIndCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End TestMemIf_EraseImmediateBlock() */

/*******************************************************************************
**                           MemIf_InvalidateBlock()                          **
*******************************************************************************/
Std_ReturnType MemIf_InvalidateBlock(uint8 DeviceIndex, uint16 BlockNumber)
{
  #ifndef TYPICAL_CONFIG
  NvM_GaaCurrentDeviceIndex[NvM_GucInvalidateIndCount] = DeviceIndex;
  NvM_GaaCurrentBlockNumber[NvM_GucInvalidateIndCount] = BlockNumber;
  NvM_GucInvalidateIndCount++;
  
  return(NvM_GddInvalidateBlkRetVal);
  #endif
} /* End MemIf_InvalidateBlock() */

/*******************************************************************************
**                         TestMemIf_InvalidateBlock()                        **
*******************************************************************************/
boolean TestMemIf_InvalidateBlock(App_DataValidateType LucDataValidate, 
  uint8 LucExpDeviceIndex, uint16 LucExpBlockNumber)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((NvM_GucInvalidateIndCount == 0x01) 
        && (LucExpDeviceIndex == NvM_GaaCurrentDeviceIndex[0])
        && (LucExpBlockNumber == NvM_GaaCurrentBlockNumber[0]))
      {
        LblStepResult = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      NvM_GucInvalidateIndCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(NvM_GucInvalidateIndCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End TestMemIf_InvalidateBlock() */

/*******************************************************************************
**                               MemIf_GetStatus()                            **
*******************************************************************************/
MemIf_StatusType MemIf_GetStatus(uint8 DeviceIndex)
{
  #ifndef TYPICAL_CONFIG
  NvM_GucDeviceIndex = DeviceIndex;
  return(MEMIF_IDLE);
  #endif
} /* End MemIf_GetStatus() */

/*******************************************************************************
**                                MemIf_SetMode()                             **
*******************************************************************************/
void MemIf_SetMode(MemIf_ModeType Mode)
{
  #ifndef TYPICAL_CONFIG
  NvM_GucCurrentMode[NvM_GucModeIndCount] = Mode;
  NvM_GucModeIndCount++;
  #endif
} /* End MemIf_SetMode() */

/*******************************************************************************
**                              TestMemIf_SetMode()                           **
*******************************************************************************/
boolean TestMemIf_SetMode(App_DataValidateType LucDataValidate, 
  MemIf_ModeType LddExpMode)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((NvM_GucModeIndCount == 0x01) 
        && (NvM_GucCurrentMode[0] == LddExpMode))
      {
        LblStepResult = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      NvM_GucModeIndCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(NvM_GucModeIndCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End TestMemIf_SetMode() */

/*******************************************************************************
**                          TestSetMemIf_ReadRetVal()                         **
*******************************************************************************/
void TestSetMemIf_ReadRetVal(Std_ReturnType LddReadRetVal)
{
  NvM_GddReadRetVal = LddReadRetVal;
} /* End TestSetMemIf_ReadRetVal() */

/*******************************************************************************
**                        TestSetMemIf_WriteRetVal()                          **
*******************************************************************************/
void TestSetMemIf_WriteRetVal(Std_ReturnType LddWriteRetVal)
{
  NvM_GddWriteRetVal = LddWriteRetVal;
} /* End TestSetMemIf_WriteRetVal() */

/*******************************************************************************
**                    TestSetMemIf_GetJobResultRetVal()                       **
*******************************************************************************/
void TestSetMemIf_GetJobResultRetVal(MemIf_JobResultType LddJobResultRetVal)
{
  NvM_GddGetJobResultRetVal = LddJobResultRetVal;
} /* End TestSetMemIf_GetJobResultRetVal() */

/*******************************************************************************
**               TestSetMemIf_EraseImmediateBlockRetVal()                     **
*******************************************************************************/
void TestSetMemIf_EraseImmediateBlockRetVal(Std_ReturnType LddEraseBlkRetVal)
{
  NvM_GddEraseBlkRetVal = LddEraseBlkRetVal;
} /* End TestSetMemIf_EraseImmediateBlockRetVal() */

/*******************************************************************************
**                    TestSetMemIf_InvalidateBlockRetVal()                    **
*******************************************************************************/
void TestSetMemIf_InvalidateBlockRetVal(Std_ReturnType LddInvalidateBlkRetVal)
{
  NvM_GddInvalidateBlkRetVal = LddInvalidateBlkRetVal;
} /* End TestSetMemIf_InvalidateBlockRetVal() */

/*******************************************************************************
**                           NvMTest_ValidateData()                           **
*******************************************************************************/
boolean NvMTest_ValidateData(uint8* LpExpData, 
  uint8* LpActData, uint32 LucLength)
{
  uint8 LucCount;
  boolean LblReturnValue;
  
  LblReturnValue = TRUE;
  LucCount = 0;

  while((LblReturnValue != FALSE) && (LucCount < LucLength))
  {
    if(*LpActData != *LpExpData)
    {
      LblReturnValue = FALSE;
    }
    LpActData++;
    LpExpData++;
    LucCount++;
  }
  return(LblReturnValue);
} /* End NvMTest_ValidateData() */

/*******************************************************************************
**                           TestMemIf_DefaultBehavior()                        **
*******************************************************************************/
void TestMemIf_DefaultBehavior(void)
{
  NvM_GucReadIndCount = 0;
  NvM_GucWriteIndCount = 0;
  NvM_GucModeIndCount = 0;
  NvM_GucInvalidateIndCount = 0;
  NvM_GucEraseIndCount = 0;
  NvM_GucCancelIndCount = 0;
  NvM_GucJobResultIndCount = 0;
} /* End TestMemIf_DefaultBehavior() */

#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
