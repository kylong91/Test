/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: MemIf.h                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR MemIf Module                                          **
**                                                                            **
**  PURPOSE   : Provision of header for Version Check                         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/


/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     24-Nov-2012   Ankur    Initial Version                           **
*******************************************************************************/
#ifndef MEMIF_H
#define MEMIF_H

/******************************************************************************
**                      Include Section                                      **
******************************************************************************/
#include "Std_Types.h"                  /* Standard type header */
#include "TC_Generic.h"
#include "MemIf_Types.h"                  /* Standard type header */

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define MEMIF_AR_RELEASE_MAJOR_VERSION  4
#define MEMIF_AR_RELEASE_MINOR_VERSION  0
#define MEMIF_AR_RELEASE_REVISION_VERSION  3

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/
#define NVM_ARRAY_SIZE                  (uint8)50
#define BLOCK_INVOKED                   (uint8)0xFF
#define NVM_WRITE_LENGTH                (uint8)0x08

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

extern uint8 NvM_GaaExpReadBlock[];
extern uint8 NvM_GaaExpWriteBlock[];
extern uint8 NvM_GaaReadDataBuffer[];
extern uint8 NvM_GaaWriteDataBuffer[];


/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern Std_ReturnType MemIf_Read(uint8 DeviceIndex, uint16 BlockNumber, 
  uint16 BlockOffset, uint8 *DataBufferPtr, uint16 Length);
  
extern boolean TestMemIf_Read(App_DataValidateType LucDataValidate, 
  uint8 LucExpDeviceIndex, uint16 LucExpBlockNumber, uint16 BlockOffset, 
  const uint8* LpExpDataBufferPtr, uint16 LucExpLength);
  
extern boolean TestNvM_MultiBlkMemIf_Read(App_DataValidateType LucDataValidate, 
  uint8 LucExpDeviceIndex, uint16 LucExpBlockNumber, uint16 BlockOffset, 
  uint8* LpExpDataBufferPtr, uint16 LucExpLength);
  
extern Std_ReturnType MemIf_Write(uint8 DeviceIndex, uint16 BlockNumber,
  uint8* DataBufferPtr);
  
extern boolean TestMemIf_Write(App_DataValidateType LucDataValidate, 
  uint8 LucExpDeviceIndex, uint16 LucExpBlockNumber, 
  const uint8* LpExpDataBufferPtr, uint16 LucExpLength);
  
extern boolean TestNvM_MultiBlkMemIf_Write(App_DataValidateType LucDataValidate, 
  uint8 LucExpDeviceIndex, uint16 LucExpBlockNumber, 
  const uint8* LpExpDataBufferPtr, uint16 LucExpLength);
  
extern MemIf_JobResultType MemIf_GetJobResult(uint8 DeviceIndex);

extern boolean TestMemIf_GetJobResult(App_DataValidateType LucDataValidate, 
  uint8 LucExpDeviceIndex);
  
extern boolean TestNvM_MultiBlkMemIf_GetJobResult(App_DataValidateType LucDataValidate, 
  uint8 LucExpDeviceIndex);
  
extern void MemIf_Cancel(uint8 DeviceIndex);

extern boolean TestMemIf_Cancel(App_DataValidateType LucDataValidate, 
  uint8 LucExpDeviceIndex);
  
extern Std_ReturnType MemIf_EraseImmediateBlock(uint8 DeviceIndex, 
  uint16 BlockNumber);

extern boolean TestMemIf_EraseImmediateBlock(App_DataValidateType 
  LucDataValidate, uint8 LucExpDeviceIndex, uint16 LucExpBlockNumber);
  
extern Std_ReturnType MemIf_InvalidateBlock(uint8 DeviceIndex, 
  uint16 BlockNumber);

extern boolean TestMemIf_InvalidateBlock(App_DataValidateType LucDataValidate, 
  uint8 LucExpDeviceIndex, uint16 LucExpBlockNumber);
  
extern MemIf_StatusType MemIf_GetStatus(uint8 DeviceIndex);

extern void MemIf_SetMode(MemIf_ModeType Mode);

extern boolean TestMemIf_SetMode(App_DataValidateType LucDataValidate, 
  MemIf_ModeType LddExpMode);
  
extern void TestSetMemIf_ReadRetVal(Std_ReturnType LddReadRetVal);

extern void TestSetMemIf_WriteRetVal(Std_ReturnType LddWriteRetVal);

extern void TestSetMemIf_GetJobResultRetVal(MemIf_JobResultType 
  LddJobResultRetVal);

extern void TestSetMemIf_EraseImmediateBlockRetVal(Std_ReturnType 
  LddEraseBlkRetVal);

extern void TestSetMemIf_InvalidateBlockRetVal(Std_ReturnType 
  LddInvalidateBlkRetVal);

extern boolean NvMTest_ValidateData(uint8* LpExpData, uint8* LpActData, 
  uint32 LucLength);
  
extern void App_TestMemIfPrepareData(uint8 Length, uint8 *DataPtr);

extern void TestMemIf_DefaultBehavior(void);

#endif /* MEMIF_H */
/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
