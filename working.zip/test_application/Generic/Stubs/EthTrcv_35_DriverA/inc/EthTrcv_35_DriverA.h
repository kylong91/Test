/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: EthTrcv_35_DriverA.h                                          **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR ETH-TRCV Stub                                         **
**                                                                            **
**  PURPOSE   : This application file contains the EthTrcv stub functions     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     22-Jun-2011   BJV    Initial version                             **
*******************************************************************************/
#ifndef ETHTRCV_35_DRIVERA_H
#define ETHTRCV_35_DRIVERA_H

/*******************************************************************************
**                      Include Section                                      **
*******************************************************************************/
#include "TC_Generic.h"
#include "ComStack_Types.h"
#include "EthTrcv_GeneralTypes.h"

extern Std_ReturnType EthTrcv_35_DriverA_TransceiverInit
                                                ( uint8 TrcvIdx, uint8 CfgIdx );

/******************************************************************************/

extern  boolean TestEthTrcv_35_DriverA_TransceiverInit(App_DataValidateType LddDataValidate,
  uint8 LucExpTrcvIdx,uint8 LucExpCfgIdx);
/*******************************************************************************
**            END OF EthTrcv_35_DriverA_ControllerInit()                      **
*******************************************************************************/
/*******************************************************************************
**                    EthTrcv_35_DriverA_TrcvGetTransceiverMode()             **
*******************************************************************************/
extern Std_ReturnType EthTrcv_35_DriverA_GetTransceiverMode(
    uint8 TrcvIdx,
    EthTrcv_ModeType* TrcvModePtr
);

/*******************************************************************************
**                     TestEthTrcv_35_DriverA_TrcvGetTransceiverMode()        **
*******************************************************************************/

extern boolean TestEthTrcv_35_DriverA_GetTransceiverMode
  (App_DataValidateType LddDataValidate,
  uint8 LucExpTrcvIdx, EthTrcv_ModeType* LddExpMode);
/*******************************************************************************
**                     EthTrcv_35_DriverA_TrcvSetTransceiverMode()            **
*******************************************************************************/
extern Std_ReturnType EthTrcv_35_DriverA_SetTransceiverMode( uint8 TrcvIdx, 
                                                   EthTrcv_ModeType CtrlMode );

extern boolean TestEthTrcv_35_DriverA_SetTransceiverMode
(App_DataValidateType LddDataValidate,
  uint8 LucExpTrcvIdx, EthTrcv_ModeType LddExpMode);
  
extern Std_ReturnType EthTrcv_35_DriverA_GetLinkState(
    uint8 TrcvIdx,
    EthTrcv_LinkStateType* LinkStatePtr
);

#endif
/*******************************************************************************
**             END OF  EthIf_Transmit()                                       **
*******************************************************************************/
