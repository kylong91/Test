/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: EthTrcv_35_DriverA.c                                          **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR ETH-TRCV Stub                                         **
**                                                                            **
**  PURPOSE   : This application file contains the EthTrcv stub functions     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     22-Jun-2011   BJV    Initial version                             **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "EthTrcv_35_DriverA.h"    

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_Guc_DrvATrcvInit_TrcvIdx;
uint8 Eth_Guc_DrvATrcvInit_CfgIdx;
uint8 Eth_Guc_DrvATrcvInitCount;
Std_ReturnType Eth_Gdd_DrvATrcvInitRetVal;

/*******************************************************************************
**                     EthTrcv_35_DriverA_ControllerInit()                    **
*******************************************************************************/

Std_ReturnType EthTrcv_35_DriverA_TransceiverInit( uint8 TrcvIdx, uint8 CfgIdx )
{
  /* Load actual Controller and Transition into Global variables */
  Eth_Guc_DrvATrcvInit_TrcvIdx = TrcvIdx;
  Eth_Guc_DrvATrcvInit_CfgIdx = CfgIdx;
  Eth_Guc_DrvATrcvInitCount++;

  return(Eth_Gdd_DrvATrcvInitRetVal);
} /* End EthTrcv_35_DriverA_ControllerInit() */
/*******************************************************************************/

boolean TestEthTrcv_35_DriverA_TransceiverInit(App_DataValidateType LddDataValidate,
  uint8 LucExpTrcvIdx,uint8 LucExpCfgIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_Guc_DrvATrcvInitCount > 0x00) &&
        (Eth_Guc_DrvATrcvInit_TrcvIdx == LucExpTrcvIdx) &&
        (Eth_Guc_DrvATrcvInit_CfgIdx == LucExpCfgIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_Guc_DrvATrcvInitCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_Guc_DrvATrcvInitCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_Guc_DrvATrcvInitCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}
/*******************************************************************************
**            END OF EthTrcv_35_DriverA_ControllerInit()                          **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_Guc_DrvAGetTrcvModeCount;
uint8 Eth_Guc_DrvAGetTrcvCtrlIdx;
EthTrcv_ModeType* Eth_Gdd_DrvAGetTrcvMode;
Std_ReturnType Eth_Gdd_DrvAGetTrcvModeRetVal;


/*******************************************************************************
**                    EthTrcv_35_DriverA_TrcvGetTransceiverMode()             **
*******************************************************************************/
Std_ReturnType EthTrcv_35_DriverA_GetTransceiverMode(
    uint8 TrcvIdx,
    EthTrcv_ModeType* TrcvModePtr
)

/* Load actual Controller and Transition into Global variables */
{
  Eth_Guc_DrvAGetTrcvCtrlIdx = TrcvIdx;
  Eth_Gdd_DrvAGetTrcvMode = TrcvModePtr;
  Eth_Guc_DrvAGetTrcvModeCount++;
  return(Eth_Gdd_DrvAGetTrcvModeRetVal);
}
/* End EthTrcv_35_DriverA_TrcvGetTransceiverMode */
/*******************************************************************************
**                     TestEthTrcv_35_DriverA_TrcvGetTransceiverMode()        **
*******************************************************************************/

boolean TestEthTrcv_35_DriverA_GetTransceiverMode
  (App_DataValidateType LddDataValidate,
  uint8 LucExpTrcvIdx, EthTrcv_ModeType* LddExpMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_Guc_DrvAGetTrcvModeCount > 0x00) &&
        (Eth_Guc_DrvAGetTrcvCtrlIdx == LucExpTrcvIdx) &&
        (Eth_Gdd_DrvAGetTrcvMode != LddExpMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_Guc_DrvAGetTrcvModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_Guc_DrvAGetTrcvModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_Guc_DrvAGetTrcvModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestEthTrcv_35_DriverA_TrcvGetTransceiverMode() */
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Eth_Guc_DrvASetTrcvModeCount;
uint8 Eth_Guc_DrvASetTrcvTrcvIdx;
EthTrcv_ModeType Eth_Gdd_DrvASetTrcvMode;
Std_ReturnType Eth_Gdd_DrvASetTrcvModeRetVal;
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/

/*******************************************************************************
**                     EthTrcv_35_DriverA_TrcvSetTransceiverMode()            **
*******************************************************************************/
Std_ReturnType EthTrcv_35_DriverA_SetTransceiverMode( uint8 TrcvIdx, 
                                                   EthTrcv_ModeType CtrlMode )
{
  /* Load actual Controller and Transition into Global variables */
  Eth_Guc_DrvASetTrcvTrcvIdx = TrcvIdx;
  Eth_Gdd_DrvASetTrcvMode = CtrlMode;
  Eth_Guc_DrvASetTrcvModeCount++;

  return(Eth_Gdd_DrvASetTrcvModeRetVal);
} 
/*******************************************************************************
**                     TestEthTrcv_35_DriverA_TrcvSetTransceiverMode()        **
*******************************************************************************/
boolean TestEthTrcv_35_DriverA_SetTransceiverMode(App_DataValidateType LddDataValidate,
  uint8 LucExpTrcvIdx, EthTrcv_ModeType LddExpMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((Eth_Guc_DrvASetTrcvModeCount > 0x00) &&
        (Eth_Guc_DrvASetTrcvTrcvIdx == LucExpTrcvIdx) &&
        (Eth_Gdd_DrvASetTrcvMode == LddExpMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Eth_Guc_DrvASetTrcvModeCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Eth_Guc_DrvASetTrcvModeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      Eth_Guc_DrvASetTrcvModeCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCan_SetControllerMode() */


Std_ReturnType EthTrcv_35_DriverA_GetLinkState(
    uint8 TrcvIdx,
    EthTrcv_LinkStateType* LinkStatePtr
){
UNUSED(TrcvIdx);
UNUSED(LinkStatePtr);
return(E_OK);
}
/*******************************************************************************
**             END OF  EthIf_Transmit()                                       **
*******************************************************************************/

