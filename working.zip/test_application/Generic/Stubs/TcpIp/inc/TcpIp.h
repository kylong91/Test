/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: TcpIp.h                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Ethernet State Manager Module                         **
**                                                                            **
**  PURPOSE   : Declaration of Can functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     15/06/2011    MKK    Creation of TcpIp.h  module                 **
*******************************************************************************/
#ifndef TCPIP_H
#define TCPIP_H


/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/ 
#include "TC_Generic.h"
#include "ComStack_Types.h"
#include "Eth_GeneralTypes.h" 
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/
/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern void TcpIp_TxConfirmation(uint8 CtrlIdx,uint8 BufIdx) ;

extern void TcpIp_RxIndication(uint8 CtrlIdx,
  Eth_FrameType FrameType,P2VAR(uint8,AUTOMATIC,ETHIF_APPL_CONST) PhysAddrPtr,
  P2VAR(uint8,AUTOMATIC,ETHIF_APPL_CONST) DataPtr,uint16 LenByte) ;

extern boolean TestTcpIp_RxIndication  (App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,Eth_FrameType LddExpFrameType,uint8* LucExpPhysAddrPtr,
  uint8* LucExpDataPtr, uint16  LucExpLenByte);
  
extern boolean TestTcpIp_TxConfirmation(App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,uint8 LucExpBufIdx);


#endif /* TCPIP_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
