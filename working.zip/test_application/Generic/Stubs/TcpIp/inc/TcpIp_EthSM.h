/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: TcpIp_EthSM.h                                                 **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Ethernet State Manager Module                         **
**                                                                            **
**  PURPOSE   : Declaration of Can functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     15/06/2011    MKK    Creation of TcpIp_EthSM.h  module           **
*******************************************************************************/
#ifndef TCPIP_H
#define TCPIP_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"
#include "TC_Generic.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR specification version information */
#define TCPIP_AR_RELEASE_MAJOR_VERSION     4
#define TCPIP_AR_RELEASE_MINOR_VERSION     0
#define TCPIP_AR_RELEASE_REVISION_VERSION  4

/* Software version information */
#define TCPIP_SW_MAJOR_VERSION  1
#define TCPIP_SW_MINOR_VERSION  0
#define TCPIP_SW_PATCH_VERSION  0

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/
/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
typedef enum 
{
  TCPIP_STATE_ONLINE = 0,
  TCPIP_STATE_ONHOLD,
  TCPIP_STATE_OFFLINE,
  TCPIP_STATE_STARTUP,
  TCPIP_STATE_SHUTDOWN
}TcpIp_StateType;
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Std_ReturnType TcpIp_RequestComMode(uint8 CtrlIdx, TcpIp_StateType State);
extern boolean TestTcpIp_RequestComMode(App_DataValidateType LucDataValidate,
                                         uint8 CtrlIdx, TcpIp_StateType State);                                                         
extern void TestTcpIp_DefaultBehavior(void);
extern void TestTcpIp_RequestComModeSetBeh(Std_ReturnType LddReturnVal);
extern void TestTcpIp_PassiveStartSetRetVal(Std_ReturnType ReturnValue);

#endif /* ETHSM_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
