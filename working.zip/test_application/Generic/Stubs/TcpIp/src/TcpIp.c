/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Eth.c                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Ethernet State Manager Module                         **
**                                                                            **
**  PURPOSE   : Declaration of Can functions                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     30-Jul-2012   BCC    Initial version                             **
*******************************************************************************/

// /*******************************************************************************
// **                      Include Section                                       **
// *******************************************************************************/
// #include "ComStack_Types.h" 
// #include "Eth.h"

// /*******************************************************************************
// **                      Version Information                                   **
// *******************************************************************************/

// /*******************************************************************************
// **                       Global Data Types                                    **
// *******************************************************************************/
// uint8 Eth_InitCount;
// uint8 Eth_ControllerInitCount;
// uint8 EthSM_GucGetCurrentComModeCount;
// NetworkHandleType EthSM_GddNetworkHandle;
// ComM_ModeType EthSM_GddComM_Mode;
// ComM_ModeType EthSM_GddGetCurComM_Mode;
// Std_ReturnType EthSM_GddGetCurrentRetVal;
// Std_ReturnType EthSM_GddReqComRetVal;
// /*******************************************************************************
// **                      Function Definitions                                  **
// *******************************************************************************/

// /*******************************************************************************
// **                      Eth_Init()                                            **
// *******************************************************************************/
// void Eth_Init( const Eth_ConfigType* CfgPtr )
// {
  // UNUSED(CfgPtr);
  // Eth_InitCount++;
// }

// /*******************************************************************************
// **                       TestEth_Init()                                       **
// *******************************************************************************/
// boolean TestEth_Init(App_DataValidateType LucDataValidate,
  // const Eth_ConfigType* CfgPtr )
// {
  // boolean LblStepResult;

  // LblStepResult = STEP_FAILED;

  // switch(LucDataValidate)
  // {
    // /*
     // * Case to handle API invocation with single occurance and to validate
     // * parameters of the API with what it has been invoked
     // */
    // case S_VALIDATE:
    // {
      // if(Eth_InitCount == 0x01)
      // {
        // LblStepResult = APP_TC_PASSED;
      // }  
      // Eth_InitCount = 0x00;
      // break;
    // } /* End case S_VALIDATE: */
  // } /* End switch(LucDataValidate) */
  // return(LblStepResult);
// } /* End TestEth_Init() */

// /*******************************************************************************
// **                       TestEth_ControllerInit()                             **
// *******************************************************************************/

// void TestEth_ControllerInit( uint8 CtrlIdx, uint8 CfgIdx)
// {
  // EthSM_GddGetCurComM_Mode = LddComMMode;
// }/* End TestEth_ControllerInit() */

// /*******************************************************************************
// **                       Eth_ControllerInit()                            **
// *******************************************************************************/
// Std_ReturnType Eth_ControllerInit( uint8 CtrlIdx, uint8 CfgIdx )
// {
  // #ifndef TYPICAL_CONFIG
  // Eth_ControllerInitCount++;
  // EthSM_GddCfgIdx = CfgIdx;
  // #endif
	// return(EthSM_GddGetCurrentRetVal);
// }/* End Eth_ControllerInit() */

// /*******************************************************************************
// **                       TestEthSM_GetCurrentComMode()                        **
// *******************************************************************************/
// boolean TestEthSM_GetCurrentComMode(App_DataValidateType LucDataValidate,
// NetworkHandleType LddExpNetworkHandle, 
// P2VAR(ComM_ModeType, AUTOMATIC, COMM_APPL_DATA) LddExpComM_ModePtr)
// {
  // boolean LblStepResult;

  // LblStepResult = STEP_FAILED;

  // switch(LucDataValidate)
  // {
    // /*
     // * Case to handle API invocation with single occurance and to validate
     // * parameters of the API with what it has been invoked
     // */
    // case S_VALIDATE:
    // {  
      // if((EthSM_GucGetCurrentComModeCount != 0x00) && 
        // (EthSM_GddNetworkHandle == LddExpNetworkHandle) && 
        // (EthSM_GddGetCurComM_Mode == *LddExpComM_ModePtr))
      // {
        // LblStepResult = APP_TC_PASSED;
      // }  
      // EthSM_GucGetCurrentComModeCount = 0x00;
      // break;
    // } /* End case S_VALIDATE: */

    // /*
     // * Case to handle API invocation with multiple occurance (with out any
     // * sequnce) and to validate parameters of the API with what it has been
     // * invoked
     // */
    // case M_VALIDATE:
    // {
      // break;
    // } /* End case M_VALIDATE: */

    // /* Case to handle API not invoked for single occurance */
    // case S_NOT_INVOKED:
    // {
      // break;
    // }
    // default:
    // {
      // LblStepResult = STEP_FAILED;
      // break;
    // }
  // } /* End switch(LucDataValidate) */
  // return(LblStepResult);
// } /* End TestEthSM_GetCurrentComMode() */

// /*******************************************************************************
// **                         TestEthSM_DefaultBehavior()                         **
// *******************************************************************************/
// void TestEthSM_DefaultBehavior(void)
// {
  // EthSM_GucGetCurrentComModeCount = 0;
  // EthSM_GucRequestComModeCount = 0;
  // EthSM_GddGetCurComM_Mode = COMM_NO_COMMUNICATION;
  // EthSM_GddReqComRetVal = 0;
  // EthSM_GddGetCurrentRetVal = 0;
// }

// /*******************************************************************************
// **                         TestEthSM_SetBehavior()                         **
// *******************************************************************************/
// void TestEthSM_RequestComModeSetBeh(Std_ReturnType LddReturnVal)
// {
  // EthSM_GucGetCurrentComModeCount = 0;
  // EthSM_GucRequestComModeCount = 0;
  // EthSM_GddReqComRetVal = LddReturnVal;
// }

// void TestEthSM_GetCurrentComModeSetBeh(Std_ReturnType LddReturnVal)
// {
  // EthSM_GucGetCurrentComModeCount = 0;
  // EthSM_GucRequestComModeCount = 0;
  // EthSM_GddGetCurrentRetVal = LddReturnVal;
// }


#ifdef ETHIF_MODULE_ACTIVE
#include "TcpIp.h"
#include "App_EthIf_Common_Defs_Defs.h"
uint8 DataArray[100];
uint8 TcpIp_GucRxIndCtrlIdx;
Eth_FrameType TcpIp_FrameType;
uint8 *TcpIp_PhyAddrPtr;
uint8 TcpIp_GucLenByte;
uint8 TcpIp_GucRxIndCount;
uint8 i;
#endif

#ifdef ETHSM_MODULE_ACTIVE
#include "TcpIp_EthSM.h"
uint8 TcpIp_GucRequestComModeCount;
uint8 TcpIp_GucGetCurrentComModeCount;
uint8 TcpIp_GddControllerIDCount1;
uint8 TcpIp_GddControllerIDCount;
uint8 TcpIp_GddCntrId[50];
TcpIp_StateType TcpIp_GddComM_Mode[50];
TcpIp_StateType TcpIp_GddGetCurComM_Mode;
Std_ReturnType TcpIp_GddGetCurrentRetVal;
Std_ReturnType TcpIp_GddReqComRetVal;
#endif

#ifdef ETHSM_MODULE_ACTIVE
/*******************************************************************************
**                      TcpIp_RequestComMode()                                **
*******************************************************************************/
Std_ReturnType TcpIp_RequestComMode(uint8 CtrlIdx, TcpIp_StateType State)
{
  #ifndef TYPICAL_CONFIG
  TcpIp_GucRequestComModeCount++;
  TcpIp_GddCntrId[TcpIp_GddControllerIDCount] = CtrlIdx;
  TcpIp_GddComM_Mode[TcpIp_GddControllerIDCount] = State;
  #endif
  return(TcpIp_GddReqComRetVal);
}/* End TcpIp_RequestComMode() */
/*******************************************************************************
**                      TestTcpIp_PassiveStartSetRetVal()                     **
*******************************************************************************/
void TestTcpIp_PassiveStartSetRetVal(Std_ReturnType ReturnValue)
{
  TcpIp_GddReqComRetVal = ReturnValue;
} /* End TestTcpIp_PassiveStartSetRetVal() */
/*******************************************************************************
**                       TestTcpIp_RequestComMode()                            **
*******************************************************************************/
boolean TestTcpIp_RequestComMode(App_DataValidateType LucDataValidate,
uint8 CtrlIdx, TcpIp_StateType State)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((TcpIp_GucRequestComModeCount == 0x01) && 
        (TcpIp_GddCntrId[TcpIp_GddControllerIDCount1] == CtrlIdx) && 
        (TcpIp_GddComM_Mode[TcpIp_GddControllerIDCount1] == State))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      TcpIp_GucRequestComModeCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      if((TcpIp_GucRequestComModeCount > 0x00) && 
        (TcpIp_GddCntrId[TcpIp_GddControllerIDCount1] == CtrlIdx) && 
        (TcpIp_GddComM_Mode[TcpIp_GddControllerIDCount1] == State))
      {
        LblStepResult = APP_TC_PASSED;
				TcpIp_GucRequestComModeCount--;
      } 
			else
			{
			  TcpIp_GucRequestComModeCount = 0x00;
			}
			break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestTcpIp_RequestComMode() */

/*******************************************************************************
**                         TestTcpIp_DefaultBehavior()                         **
*******************************************************************************/
void TestTcpIp_DefaultBehavior(void)
{
  uint8 LucIndex;
	TcpIp_GucGetCurrentComModeCount = 0;
  TcpIp_GucRequestComModeCount = 0;
	TcpIp_GddControllerIDCount1 = 0;
	TcpIp_GddControllerIDCount = 0;
  TcpIp_GddGetCurComM_Mode = TCPIP_STATE_OFFLINE;
  TcpIp_GddReqComRetVal = 0;
  TcpIp_GddGetCurrentRetVal = 0;
	for (LucIndex = 0; LucIndex < 50;LucIndex++)
	{
	  TcpIp_GddComM_Mode[LucIndex] = 0;
		TcpIp_GddComM_Mode[LucIndex] = 0;
	}
}

/*******************************************************************************
**                         TestTcpIp_SetBehavior()                         **
*******************************************************************************/
void TestTcpIp_RequestComModeSetBeh(Std_ReturnType LddReturnVal)
{
  TcpIp_GucGetCurrentComModeCount = 0;
  TcpIp_GucRequestComModeCount = 0;
  TcpIp_GddReqComRetVal = LddReturnVal;
}
#endif

#ifdef ETHIF_MODULE_ACTIVE
void TcpIp_RxIndication(uint8 CtrlIdx,
  Eth_FrameType FrameType,P2VAR(uint8,AUTOMATIC,ETHIF_APPL_CONST) PhysAddrPtr,
  P2VAR(uint8,AUTOMATIC,ETHIF_APPL_CONST) DataPtr,uint16 LenByte) 
{
  TcpIp_GucRxIndCtrlIdx = CtrlIdx;
  TcpIp_FrameType = FrameType;
  TcpIp_PhyAddrPtr = PhysAddrPtr;
  for(i=0;i<LenByte;i++)
  {
    DataArray[i] = *DataPtr;
    DataPtr++;
  }
  TcpIp_GucRxIndCount++;
}
boolean TestTcpIp_RxIndication  (App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,Eth_FrameType LddExpFrameType,uint8* LucExpPhysAddrPtr,
  uint8* LucExpDataPtr, uint16  LucExpLenByte
  )
{
  boolean LblStepResult;
  boolean Lblcheck = 0x00;
  uint8 i;
  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((TcpIp_GucRxIndCount > 0x00) &&
        (TcpIp_GucRxIndCtrlIdx == LucExpCtrlIdx) &&
        (TcpIp_FrameType == LddExpFrameType)&&
        (TcpIp_PhyAddrPtr == LucExpPhysAddrPtr))
      {
        for(i=0;i<LucExpLenByte;i++)
        {
          if((DataArray[i] == App_EthIf_GaaDataArray[i])&&(Lblcheck == 0x00))
          {
            LblStepResult = STEP_PASSED;
          }
          else
          {
            Lblcheck =  0x01;
            LblStepResult = STEP_FAILED;
          }
        }
      }

      /* Reset API invocation Count after validating the API invocation */
      TcpIp_GucRxIndCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(TcpIp_GucRxIndCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      TcpIp_GucRxIndCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}


/*******************************************************************************
**                     TcpIp_TxConfirmation()                                 **
*******************************************************************************/
uint8 TcpIp_GucTxConfCtrlIdx;
uint8 TcpIp_GucTxConfBufIdx;
uint8 TcpIp_GucTxonfCount;

void TcpIp_TxConfirmation( uint8 CtrlIdx, uint8 BufIdx )
{
  /* Load actual Controller and Transition into Global variables */
  TcpIp_GucTxConfCtrlIdx = CtrlIdx;
  TcpIp_GucTxConfBufIdx = BufIdx;
  TcpIp_GucTxonfCount++;
} /* End TcpIp_TxConfirmation() */
/*******************************************************************************/

boolean TestTcpIp_TxConfirmation(App_DataValidateType LddDataValidate,
  uint8 LucExpCtrlIdx,uint8 LucExpBufIdx)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Controller and Transition  */
      if((TcpIp_GucTxonfCount > 0x00) &&
        (TcpIp_GucTxConfCtrlIdx == LucExpCtrlIdx) &&
        (TcpIp_GucTxConfBufIdx == LucExpBufIdx))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      TcpIp_GucTxonfCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(TcpIp_GucTxonfCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      TcpIp_GucTxonfCount = 0;
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
}
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
