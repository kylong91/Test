/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: CanTrcv_39_DriverA.h                                          **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CAN Interface module                                  **
**                                                                            **
**  PURPOSE   : Declaration of CanTrcv_39_DriverA functions                   **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     13/06/2011    BJV    Creation of CanTrcv_39_DriverA.h module     **
** 4.0.1     03/08/2011    BJV    New Api                                     **
**                                TestSetCanTrcv_39_DriverA_GetTrcvModeVal is **
**                                added                                       **
** 4.0.2     20-Dec-2011   RPS    General Inclusions are updated              **
*******************************************************************************/
#ifndef CANTRCV_39_DRIVERA
#define CANTRCV_39_DRIVERA

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"             /* Com Stack header */
#include "Can_GeneralTypes.h"
#include "TC_Generic.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define CANTRCV_39_DRIVERA_AR_RELEASE_MAJOR_VERSION    0x04
#define CANTRCV_39_DRIVERA_AR_RELEASE_MINOR_VERSION    0x00
#define CANTRCV_AR_RELEASE_REVISION_VERSION 0x02

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Std_ReturnType CanTrcv_39_DriverA_CheckWakeup(uint8 Transceiver);

extern Std_ReturnType CanTrcv_39_DriverA_GetBusWuReason(uint8 Transceiver,
  CanTrcv_TrcvWakeupReasonType *reason);

extern Std_ReturnType CanTrcv_39_DriverA_GetOpMode(uint8 Transceiver,
  CanTrcv_TrcvModeType *OpMode);

extern Std_ReturnType CanTrcv_39_DriverA_SetOpMode(uint8 Transceiver,
  CanTrcv_TrcvModeType OpMode);

extern Std_ReturnType CanTrcv_39_DriverA_SetWakeupMode(uint8 Transceiver,
  CanTrcv_TrcvWakeupModeType TrcvWakeupMode);


extern boolean TestCanTrcv_39_DriverA_CheckWakeup(
  App_DataValidateType LddDataValidate, uint8 ExpTransceiver);

extern boolean TestCanTrcv_39_DriverA_GetBusWuReason(
  App_DataValidateType LddDataValidate, uint8 LddExpTransceiver);

extern boolean TestCanTrcv_39_DriverA_GetOpMode(
  App_DataValidateType LddDataValidate, uint8 LddExpTransceiver);

extern boolean TestCanTrcv_39_DriverA_SetOpMode(
  App_DataValidateType LddDataValidate, uint8 ExpTransceiver,
  CanTrcv_TrcvModeType ExpOpMode);

extern boolean TestCanTrcv_39_DriverA_SetWakeupMode(
  App_DataValidateType LddDataValidate, uint8 ExpTransceiver,
  CanTrcv_TrcvWakeupModeType ExpTrcvWakeupMode);

extern void TestCanTrcv_39_DriverA_DefaultBehavior(void);

extern void TestSetCanTrcv_39_DriverA_GetOpModeRetVal(Std_ReturnType LddRetVal,
  CanTrcv_TrcvModeType LddOpMode);

extern void TestCanTrcv_39_DriverA_CheckWakeupRetVal(Std_ReturnType
  LddCanTrcvReturnVal);

extern void TestSetCanTrcv_39_DriverA_GetBusWuReason(
  CanTrcv_TrcvWakeupReasonType LenWakeupReason);
extern void TestSetCanTrcv_39_DriverA_GetTrcvModeVal(
  CanTrcv_TrcvModeType LddOpMode);
  
extern boolean TestCanTrcv_39_DriverA_ClearTrcvWufFlag(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver);

extern Std_ReturnType CanTrcv_39_DriverA_ClearTrcvWufFlag(uint8 TransceiverId);

extern Std_ReturnType CanTrcv_39_DriverA_CheckWakeFlag(uint8 TransceiverId);

extern boolean TestCanTrcv_39_DriverA_CheckWakeFlag(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver);   
#endif /* CANTRCV_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
