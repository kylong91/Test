/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: CanTrcv_39_DriverA.c                                          **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR CanTrcv_39_DriverA Stub                               **
**                                                                            **
**  PURPOSE   : This application file contains the CanTrcv_39_DriverA         **
**              Stub functions                                                **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision    Date         By    Description                                 **
********************************************************************************
** 4.0.0     13/06/2011    BJV    Creation of CanTrcv_39_DriverA.c module     **
** 4.0.1     03/08/2011    BJV    Global variable name is changed from        **
**                                  GddGetOpMode to GddDrvAGetOpMode          **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "CanTrcv_39_DriverA.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 CanTrcv_GucDrvAChkWakeCount;
uint8 CanTrcv_GucDrvAChkWakeCheckCount;
uint8 CanTrcv_GucDrvATransceiver;
Std_ReturnType CanTrcv_GddDrvACheckWakeupRetVal;

uint8 CanTrcv_GucDrvAGetBusWRCount;
uint8 CanTrcv_GucDrvAGetBusWRCheckCount;
CanTrcv_TrcvWakeupReasonType CanTrcv_GenDrvAReason;

uint8 CanTrcv_GucDrvAGetOpMoCount;
uint8 CanTrcv_GucDrvAGetOpMoCheckCount;
CanTrcv_TrcvModeType CanTrcv_GddDrvAGetOpMode;
Std_ReturnType CanTrcv_GddDrvAGetOpModeRetVal;

uint8 CanTrcv_GucDrvASetOpMoCount;
uint8 CanTrcv_GucDrvASetOpMoCheckCount;
CanTrcv_TrcvModeType CanTrcv_GddDrvASetOpMode;

uint8 CanTrcv_GucDrvASetWakupCount;
uint8 CanTrcv_GucDrvASetWakupCheckCount;
CanTrcv_TrcvWakeupModeType CanTrcv_GucDrvATrcvWakeupMode;

/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/



/*******************************************************************************
**                     CanTrcv_39_DriverA_CheckWakeFlag()                  **
*******************************************************************************/
Std_ReturnType CanTrcv_39_DriverA_CheckWakeFlag(uint8 TransceiverId)
{
  /* Load actual Transceiver into Global variables */
  CanTrcv_GucDrvATransceiver = TransceiverId;
  CanTrcv_GucDrvAChkWakeCount++;

  return(CanTrcv_GddDrvACheckWakeupRetVal);
} /* End CanTrcv_39_DriverA_CheckWakeFlag() */

/*******************************************************************************
**                     TestCanTrcv_39_DriverA_ClearTrcvWufFlag()              **
*******************************************************************************/
boolean TestCanTrcv_39_DriverA_CheckWakeFlag(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count,Transceiver  */
      if((CanTrcv_GucDrvAChkWakeCount == 0x01) &&
      (CanTrcv_GucDrvATransceiver == ExpTransceiver))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucDrvAChkWakeCount = 0;
      CanTrcv_GucDrvAChkWakeCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucDrvAChkWakeCount; LucIndex++)
      {
        /* Validate Transceiver */
        if(CanTrcv_GucDrvATransceiver == ExpTransceiver)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucDrvAChkWakeCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTrcv_GucDrvAChkWakeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTrcv_GucDrvAChkWakeCheckCount == CanTrcv_GucDrvAChkWakeCount)
      {
        CanTrcv_GucDrvAChkWakeCount = 0;
        CanTrcv_GucDrvAChkWakeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucDrvAChkWakeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCanTrcv_39_DriverA_CheckWakeFlag() */










/*******************************************************************************
**                     CanTrcv_39_DriverA_ClearTrcvWufFlag()                  **
*******************************************************************************/
Std_ReturnType CanTrcv_39_DriverA_ClearTrcvWufFlag(uint8 TransceiverId)
{
  /* Load actual Transceiver into Global variables */
  CanTrcv_GucDrvATransceiver = TransceiverId;
  CanTrcv_GucDrvAChkWakeCount++;

  return(CanTrcv_GddDrvACheckWakeupRetVal);
} /* End CanTrcv_39_DriverA_ClearTrcvWufFlag() */

/*******************************************************************************
**                     TestCanTrcv_39_DriverA_ClearTrcvWufFlag()              **
*******************************************************************************/
boolean TestCanTrcv_39_DriverA_ClearTrcvWufFlag(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count,Transceiver  */
      if((CanTrcv_GucDrvAChkWakeCount == 0x01) &&
      (CanTrcv_GucDrvATransceiver == ExpTransceiver))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucDrvAChkWakeCount = 0;
      CanTrcv_GucDrvAChkWakeCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucDrvAChkWakeCount; LucIndex++)
      {
        /* Validate Transceiver */
        if(CanTrcv_GucDrvATransceiver == ExpTransceiver)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucDrvAChkWakeCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTrcv_GucDrvAChkWakeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTrcv_GucDrvAChkWakeCheckCount == CanTrcv_GucDrvAChkWakeCount)
      {
        CanTrcv_GucDrvAChkWakeCount = 0;
        CanTrcv_GucDrvAChkWakeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucDrvAChkWakeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCanTrcv_39_DriverA_ClearTrcvWufFlag() */










/*******************************************************************************
**                     CanTrcv_39_DriverA_CheckWakeup()                       **
*******************************************************************************/
Std_ReturnType CanTrcv_39_DriverA_CheckWakeup(uint8 Transceiver)
{
  /* Load actual Transceiver into Global variables */
  CanTrcv_GucDrvATransceiver = Transceiver;
  CanTrcv_GucDrvAChkWakeCount++;

  return(CanTrcv_GddDrvACheckWakeupRetVal);
} /* End CanTrcv_39_DriverA_CheckWakeup() */

/*******************************************************************************
**                     TestCanTrcv_39_DriverA_CheckWakeup()                   **
*******************************************************************************/
boolean TestCanTrcv_39_DriverA_CheckWakeup(App_DataValidateType LddDataValidate,
  uint8 ExpTransceiver)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count,Transceiver  */
      if((CanTrcv_GucDrvAChkWakeCount == 0x01) &&
      (CanTrcv_GucDrvATransceiver == ExpTransceiver))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucDrvAChkWakeCount = 0;
      CanTrcv_GucDrvAChkWakeCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucDrvAChkWakeCount; LucIndex++)
      {
        /* Validate Transceiver */
        if(CanTrcv_GucDrvATransceiver == ExpTransceiver)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucDrvAChkWakeCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTrcv_GucDrvAChkWakeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTrcv_GucDrvAChkWakeCheckCount == CanTrcv_GucDrvAChkWakeCount)
      {
        CanTrcv_GucDrvAChkWakeCount = 0;
        CanTrcv_GucDrvAChkWakeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucDrvAChkWakeCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End TestCanTrcv_39_DriverA_CheckWakeup() */

/*******************************************************************************
**                       CanTrcv_39_DriverA_GetBusWuReason()                  **
*******************************************************************************/
Std_ReturnType CanTrcv_39_DriverA_GetBusWuReason(uint8 Transceiver,
  CanTrcv_TrcvWakeupReasonType *reason)
{
  /* Load actual Transceiver and reason into Global variables */
  CanTrcv_GucDrvATransceiver = Transceiver;
  *reason = CanTrcv_GenDrvAReason;
  CanTrcv_GucDrvAGetBusWRCount++;

  return(E_OK);
} /* End CanTrcv_39_DriverA_GetBusWuReason() */

/*******************************************************************************
**                   TestCanTrcv_39_DriverA_GetBusWuReason()                  **
*******************************************************************************/
boolean TestCanTrcv_39_DriverA_GetBusWuReason(
 App_DataValidateType LddDataValidate, uint8 LddExpTransceiver)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Transceiver and reason */
      if((CanTrcv_GucDrvAGetBusWRCount == 0x01) &&
        (CanTrcv_GucDrvATransceiver == LddExpTransceiver))
     {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucDrvAGetBusWRCount = 0;
      CanTrcv_GucDrvAGetBusWRCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucDrvAGetBusWRCount; LucIndex++)
      {
        /* Validate Transceiver and reason */
        if((CanTrcv_GucDrvATransceiver == LddExpTransceiver))
          
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucDrvAGetBusWRCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTrcv_GucDrvAGetBusWRCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTrcv_GucDrvAGetBusWRCheckCount == CanTrcv_GucDrvAGetBusWRCount)
      {
        CanTrcv_GucDrvAGetBusWRCount = 0;
        CanTrcv_GucDrvAGetBusWRCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucDrvAGetBusWRCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCanTrcv_39_DriverA_GetBusWuReason() */

/*******************************************************************************
**                   CanTrcv_39_DriverA_GetOpMode()                           **
*******************************************************************************/
Std_ReturnType CanTrcv_39_DriverA_GetOpMode(uint8 Transceiver,
  CanTrcv_TrcvModeType *OpMode)
{
  /* Load actual Transceiver and OpMode into Global variables */
  CanTrcv_GucDrvATransceiver = Transceiver;
  *OpMode = CanTrcv_GddDrvAGetOpMode;
  CanTrcv_GucDrvAGetOpMoCount++;

  return(CanTrcv_GddDrvAGetOpModeRetVal);
} /* End CanTrcv_39_DriverA_GetOpMode() */

/*******************************************************************************
**                   TestCanTrcv_39_DriverA_GetOpMode()                       **
*******************************************************************************/
boolean TestCanTrcv_39_DriverA_GetOpMode(App_DataValidateType LddDataValidate,
  uint8 LddExpTransceiver)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Transceiver and OpMode */
      if((CanTrcv_GucDrvAGetOpMoCount == 0x01) &&
        (CanTrcv_GucDrvATransceiver == LddExpTransceiver))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucDrvAGetOpMoCount = 0;
      CanTrcv_GucDrvAGetOpMoCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucDrvAGetOpMoCount; LucIndex++)
      {
        /* Validate ControllerId and ControllerMode */
        if(CanTrcv_GucDrvATransceiver == LddExpTransceiver)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucDrvAGetOpMoCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTrcv_GucDrvAGetOpMoCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTrcv_GucDrvAGetOpMoCheckCount == CanTrcv_GucDrvAGetOpMoCount)
      {
        CanTrcv_GucDrvAGetOpMoCount = 0;
        CanTrcv_GucDrvAGetOpMoCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucDrvAGetOpMoCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCanTrcv_39_DriverA_GetOpMode() */

/*******************************************************************************
**                   CanTrcv_39_DriverA_SetOpMode()                           **
*******************************************************************************/
Std_ReturnType CanTrcv_39_DriverA_SetOpMode(uint8 Transceiver, 
  CanTrcv_TrcvModeType OpMode)
{
  /* Load actual Transceiver and OpMode into Global variables */
  CanTrcv_GucDrvATransceiver = Transceiver;
  CanTrcv_GddDrvASetOpMode = OpMode;
  CanTrcv_GucDrvASetOpMoCount++;

  return(E_OK);
} /* End CanTrcv_39_DriverA_SetOpMode() */

/*******************************************************************************
**                   TestCanTrcv_39_DriverA_GetOpMode()                       **
*******************************************************************************/
boolean TestCanTrcv_39_DriverA_SetOpMode(App_DataValidateType LddDataValidate,
uint8 ExpTransceiver, CanTrcv_TrcvModeType ExpOpMode)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Transceiver and OpMode */
      if((CanTrcv_GucDrvASetOpMoCount == 0x01) &&
        (CanTrcv_GucDrvATransceiver == ExpTransceiver) &&
        ( CanTrcv_GddDrvASetOpMode == ExpOpMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucDrvASetOpMoCount = 0;
      CanTrcv_GucDrvASetOpMoCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucDrvASetOpMoCount; LucIndex++)
      {
        /* Validate Transceiver and OpMode */
        if((CanTrcv_GucDrvATransceiver == ExpTransceiver) &&
          (CanTrcv_GddDrvASetOpMode == ExpOpMode))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucDrvASetOpMoCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTrcv_GucDrvASetOpMoCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTrcv_GucDrvASetOpMoCheckCount == CanTrcv_GucDrvASetOpMoCount)
      {
        CanTrcv_GucDrvASetOpMoCount = 0;
        CanTrcv_GucDrvASetOpMoCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucDrvASetOpMoCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCanTrcv_39_DriverA_SetOpMode() */

/*******************************************************************************
**                   CanTrcv_39_DriverA_SetWakeupMode()                       **
*******************************************************************************/
Std_ReturnType CanTrcv_39_DriverA_SetWakeupMode(uint8 Transceiver,
CanTrcv_TrcvWakeupModeType TrcvWakeupMode)
{
  /* Load actual Transceiver and TrcvWakeupMode into Global variables */
  CanTrcv_GucDrvATransceiver = Transceiver;
  CanTrcv_GucDrvATrcvWakeupMode = TrcvWakeupMode;
  CanTrcv_GucDrvASetWakupCount++;

  return(E_OK);
} /* End CanTrcv_39_DriverA_SetWakeupMode() */

/*******************************************************************************
**                   TestCanTrcv_39_DriverA_SetWakeupMode()                   **
*******************************************************************************/
boolean TestCanTrcv_39_DriverA_SetWakeupMode(
  App_DataValidateType LddDataValidate, uint8 ExpTransceiver, 
  CanTrcv_TrcvWakeupModeType ExpTrcvWakeupMode)
{
 boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LddDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, Transceiver and TrcvWakeupMode */
      if((CanTrcv_GucDrvASetWakupCount == 0x01) &&
         (CanTrcv_GucDrvATransceiver == ExpTransceiver) &&
         (CanTrcv_GucDrvATrcvWakeupMode == ExpTrcvWakeupMode))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      CanTrcv_GucDrvASetWakupCount = 0;
      CanTrcv_GucDrvASetWakupCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < CanTrcv_GucDrvASetWakupCount; LucIndex++)
      {
        /* Validate Transceiver and TrcvWakeupMode  */
        if((CanTrcv_GucDrvATransceiver == ExpTransceiver) &&
          (CanTrcv_GucDrvATrcvWakeupMode == ExpTrcvWakeupMode))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = CanTrcv_GucDrvASetWakupCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      CanTrcv_GucDrvASetWakupCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(CanTrcv_GucDrvASetWakupCheckCount == CanTrcv_GucDrvASetWakupCount)
      {
        CanTrcv_GucDrvASetWakupCount = 0;
        CanTrcv_GucDrvASetWakupCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(CanTrcv_GucDrvASetWakupCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LddDataValidate) */

  return(LblStepResult);
} /* End of TestCanTrcv_39_DriverA_SetWakeupMode() */

/*******************************************************************************
**                     TestSetCanTrcv_39_DriverA_GetTrcvModeVal()             **
*******************************************************************************/
void TestSetCanTrcv_39_DriverA_GetTrcvModeVal(CanTrcv_TrcvModeType LddOpMode)
{
  CanTrcv_GddDrvAGetOpMode = LddOpMode;
} /* End of TestSetCanTrcv_39_DriverA_GetTrcvModeVal */

/*******************************************************************************
**                     TestSetCanTrcv_39_DriverA_GetOpModeRetVal()            **
*******************************************************************************/
void TestSetCanTrcv_39_DriverA_GetOpModeRetVal(Std_ReturnType LddRetVal,
  CanTrcv_TrcvModeType LddOpMode)
{
  CanTrcv_GddDrvAGetOpModeRetVal = LddRetVal;
  CanTrcv_GddDrvAGetOpMode = LddOpMode;
} /* TestSetCanTrcv_39_DriverA_GetOpModeRetVal() */

/*******************************************************************************
**                  TestCanTrcv_39_DriverA_CheckWakeupRetVal()                **
*******************************************************************************/
void TestCanTrcv_39_DriverA_CheckWakeupRetVal(Std_ReturnType LddCanTrcvReturnVal)
{
  CanTrcv_GddDrvACheckWakeupRetVal = LddCanTrcvReturnVal;
}
/* End TestCanTrcv_39_DriverA_CheckWakeupRetVal() */

/*******************************************************************************
**                  TestSetCanTrcv_39_DriverA_GetBusWuReason()                **
*******************************************************************************/
void TestSetCanTrcv_39_DriverA_GetBusWuReason(CanTrcv_TrcvWakeupReasonType 
  LenWakeupReason)
{
  CanTrcv_GenDrvAReason = LenWakeupReason;
}
/* End TestSetCanTrcv_39_DriverA_GetBusWuReason() */
/*******************************************************************************
**                        TestCanTrcv_DefaultBehavior()                       **
*******************************************************************************/
void TestCanTrcv_39_DriverA_DefaultBehavior(void)
{
  CanTrcv_GucDrvAChkWakeCount = 0;
  CanTrcv_GucDrvAChkWakeCheckCount = 0;
  CanTrcv_GucDrvATransceiver = 0;
  CanTrcv_GucDrvAGetBusWRCount = 0;
  CanTrcv_GucDrvAGetBusWRCheckCount = 0;
  CanTrcv_GucDrvAGetOpMoCount = 0;
  CanTrcv_GucDrvAGetOpMoCheckCount = 0;
  CanTrcv_GucDrvASetOpMoCount = 0;
  CanTrcv_GucDrvASetOpMoCheckCount = 0;
  CanTrcv_GucDrvASetWakupCount = 0;
  CanTrcv_GucDrvASetWakupCheckCount = 0;
  CanTrcv_GddDrvAGetOpMode = CANTRCV_TRCVMODE_NORMAL;
  CanTrcv_GenDrvAReason = CANTRCV_WU_POWER_ON;
  CanTrcv_GddDrvAGetOpModeRetVal = E_OK;
  CanTrcv_GddDrvACheckWakeupRetVal = E_OK;
}

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

