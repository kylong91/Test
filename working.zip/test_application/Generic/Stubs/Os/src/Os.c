/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Os.c                                                          **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Os Stub                                               **
**                                                                            **
**  PURPOSE   : This application file contains the Os Stub functions          **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Os.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#ifdef DBG_MODULE_ACTIVE
AlarmType Os_GddAlarmID;
TickType Os_GddStart;
TickType Os_GddCycle;
uint8 Os_GucSetAbsAlarmCount;
uint8 Os_GucCancelAlarm;
#endif 
#ifdef ECUM_MODULE_ACTIVE
AppModeType Os_GddMode = 0;
StatusType Os_GddStatus = E_OK;
ResourceType Os_GddResourceId = 0;
CoreIdType OsApp_GddCoreId;
uint8 Os_GucStartCount;
uint8 Os_GucStartSeqCnt;
uint8 Os_GucShutdownSeqCnt;
uint8 Os_GucShutdownCount;
uint8 Os_GucGetResourceCount;
uint8 Os_GucGetResourceSeqCnt;
uint8 Os_GucReleaseResourceCount;
uint8 Os_GucReleaseResourceSeqCnt;
uint8 Os_GucStartCoreCount;
uint8 Os_GaaStartCoreSeqCnt[OS_ARRAY_SIZE];
uint8 Os_GaaGetResource[OS_ARRAY_SIZE];
uint8 Os_GaaReleaseResource[OS_ARRAY_SIZE];
uint8 Os_GucGetCoreIDSeqCnt[OS_ARRAY_SIZE];
uint8 Os_GucGetCoreIDCount;
uint8 Os_GucShutdownAllCoresSeqCnt;
uint8 Os_GucShutdownAllCoresCount;
uint8 Os_GucEnableAllSeqCnt[OS_ARRAY_SIZE];
uint8 Os_GucEnableAllCount = 0;
uint8 Os_GucDisableAllSeqCnt[OS_ARRAY_SIZE];
uint8 Os_GucDisableAllCount = 0;
uint8 Os_GucEnableCheckStateCount = 0;
uint8 Os_GucDisableCheckStateCount = 0;
uint8 Os_GucStartCoreStateCount = 0;
uint8 Os_GucGetResCheckCount = 0;
uint8 Os_GucRelResCheckCount = 0;
uint8 Os_GucSetEventCount = 0;
uint8 Os_GucSetEventSeqCnt = 0;
uint8 Os_GucSetEventCheckCount = 0;
uint8 Os_GaaSetEventTaskId[OS_ARRAY_SIZE];
uint8 Os_GaaSetEventMask[OS_ARRAY_SIZE];
uint8 Os_GucWaitEventCount = 0;
uint8 Os_GucWaitEventSeqCnt = 0;
uint8 Os_GucWaitEventCheckCount = 0;
uint8 Os_GucGetCoreStateCount = 0;
uint8 Os_GaaWaitEventMask[OS_ARRAY_SIZE];
#endif
#ifdef BSWM_MODULE_ACTIVE
uint8 Os_GucActivateTaskcnt;
TaskType Os_GddTaskId;
#endif
#ifdef STBM_MODULE_ACTIVE
TickType Os_GddCurrentValue;
TickType Os_GddElapsedValue;
TickType Os_GddScheduleTickValue;
CounterType Os_GddCounterID;
StatusType Os_GddGetElapsedValueRetStatus;
StatusType Os_GddGetScheduleTableStatusRetStatus;
StatusType Os_GddSyncScheduleTableRetStatus;
ScheduleTableStatusType Os_GddScheduleStatus;
ScheduleTableType Os_GddScheduleID;
uint8 Os_GddGetElapsedValueCount;
uint8 Os_GddGetScheduleTableStatusCount;
uint8 Os_GddSyncScheduleTableCount;
#endif /* #ifdef STBM_MODULE_ACTIVE */

#ifdef STBM_MODULE_ACTIVE
/******************************************************************************/
void TestResetOsInvocationCounts(void)
{
  Os_GddGetElapsedValueCount = 0;
  Os_GddGetScheduleTableStatusCount = 0;
  Os_GddSyncScheduleTableCount = 0;
}
/******************************************************************************/
StatusType GetElapsedValue
(CounterType CounterID, TickRefType Value, TickRefType ElapsedValue)
{
  *Value = Os_GddCurrentValue;
  *ElapsedValue = Os_GddElapsedValue;
  Os_GddCounterID = CounterID;
  Os_GddGetElapsedValueCount++;
  return Os_GddGetElapsedValueRetStatus;
}

void TestGetElapsedValueSetVal
(StatusType RetStatus, TickType Value, TickType ElapsedValue)
{
  Os_GddGetElapsedValueRetStatus = RetStatus;
  Os_GddCurrentValue = Value;
  Os_GddElapsedValue = ElapsedValue;
}

boolean TestGetElapsedValue(App_DataValidateType LucDataValidate,
 CounterType CounterID, TickType Value, TickType ElapsedValue)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Value == Os_GddCurrentValue) && 
        (ElapsedValue == Os_GddElapsedValue) &&
        (CounterID == Os_GddCounterID) && (1 == Os_GddGetElapsedValueCount))
      {
        LblStepResult = STEP_PASSED;
        Os_GddGetElapsedValueCount = 0x00;
      }
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Os_GddGetElapsedValueCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
}
/******************************************************************************/
StatusType GetScheduleTableStatus
(ScheduleTableType ScheduleTableID, ScheduleTableStatusRefType ScheduleStatus)
{
  Os_GddScheduleID = ScheduleTableID;
  *ScheduleStatus = Os_GddScheduleStatus;
  Os_GddGetScheduleTableStatusCount++;
  return Os_GddGetScheduleTableStatusRetStatus;
}

void TestGetScheduleTableStatusSetVal
(StatusType RetStatus, ScheduleTableStatusType ScheduleStatus)
{
  Os_GddGetScheduleTableStatusRetStatus = RetStatus;
  Os_GddScheduleStatus = ScheduleStatus;
}

boolean TestGetScheduleTableStatus
(App_DataValidateType LucDataValidate, ScheduleTableType ScheduleTableID,
 ScheduleTableStatusType ScheduleStatus)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((ScheduleStatus == Os_GddScheduleStatus) && 
        (ScheduleTableID == Os_GddScheduleID) &&
        (1 == Os_GddGetScheduleTableStatusCount))
      {
        LblStepResult = STEP_PASSED;
        Os_GddGetScheduleTableStatusCount = 0;
      }
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Os_GddGetScheduleTableStatusCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
}
/******************************************************************************/
StatusType SyncScheduleTable
(ScheduleTableType ScheduleTableID, TickType Value)
{
  Os_GddScheduleID = ScheduleTableID;
  Os_GddScheduleTickValue = Value;
  Os_GddSyncScheduleTableCount++;
  return Os_GddSyncScheduleTableRetStatus;
}

void TestSyncScheduleTableSetVal(StatusType RetStatus)
{
  Os_GddSyncScheduleTableRetStatus = RetStatus;
}

boolean TestSyncScheduleTable
(App_DataValidateType LucDataValidate,
 ScheduleTableType ScheduleTableID, TickType Value)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Value == Os_GddScheduleTickValue) && 
        (ScheduleTableID == Os_GddScheduleID) &&
        (1 == Os_GddSyncScheduleTableCount))
      {
        LblStepResult = STEP_PASSED;
        Os_GddSyncScheduleTableCount = 0;
      }
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Os_GddSyncScheduleTableCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
}
/******************************************************************************/
void TestOs_DefaultBehavior(void)
{
  
} /* End TestOs_DefaultBehavior() */
#endif /* #ifdef STBM_MODULE_ACTIVE */
#ifdef DBG_MODULE_ACTIVE
/*******************************************************************************
**                       SetAbsAlarm()                                        **
*******************************************************************************/
StatusType SetAbsAlarm(AlarmType AlarmID, TickType start, TickType cycle)
{
  #ifndef TYPICAL_CONFIG
  Os_GddAlarmID = AlarmID;
  Os_GddStart = start;
  Os_GddCycle = cycle;
  Os_GucSetAbsAlarmCount++;
  #endif
  return(E_OK);
} /* End SetAbsAlarm() */

/*******************************************************************************
**                       TestSetAbsAlarm()                                    **
*******************************************************************************/
boolean TestSetAbsAlarm(App_DataValidateType LucDataValidate, 
  AlarmType ExpAlarmID, TickType Expstart, TickType Expcycle)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Os_GucSetAbsAlarmCount == 0x01) && 
        (ExpAlarmID == Os_GddAlarmID) && 
        (Expstart == Os_GddStart) && 
        (Expcycle == Os_GddCycle))
      {
        LblStepResult = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Os_GucSetAbsAlarmCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End TestSetAbsAlarm() */

/*******************************************************************************
**                       CancelAlarm()                                        **
*******************************************************************************/
StatusType CancelAlarm(AlarmType AlarmID)
{
  #ifndef TYPICAL_CONFIG
  Os_GddAlarmID = AlarmID;
  Os_GucCancelAlarm++;
  #endif
  return(E_OK);
} /* End CancelAlarm() */

/*******************************************************************************
**                       TestCancelAlarm()                                    **
*******************************************************************************/
boolean TestCancelAlarm(App_DataValidateType LucDataValidate, 
  AlarmType ExpAlarmID)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Os_GucCancelAlarm == 0x01) && 
        (ExpAlarmID == Os_GddAlarmID))
      {
        LblStepResult = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Os_GucCancelAlarm = 0;      
      break;
    } /* End case S_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End TestCancelAlarm() */
#endif
#ifdef WDGM_MODULE_ACTIVE
StatusType GetCounterValue(CounterType CounterID, TickRefType Value)
{
  CounterID++;
  Value++;
  return(E_OK);
}

StatusType GetElapsedValue(CounterType CounterID, TickRefType Value, 
  TickRefType ElapsedValue)
{
  CounterID++;
  Value++;
  ElapsedValue++;
  return(E_OK);
}
#endif

#ifdef BSWM_MODULE_ACTIVE

/*******************************************************************************
**                       GetCoreID()                                          **
*******************************************************************************/

CoreIdType GetCoreID(void)
{
  return(1);
}


/*******************************************************************************
**                       TestCancelAlarm()                                    **
*******************************************************************************/

StatusType ActivateTask(TaskType TaskID)
{
  Os_GucActivateTaskcnt++;
  Os_GddTaskId = TaskID;
  return(E_OK);
}

/*******************************************************************************
**                       TestActivateTask()                                   **
*******************************************************************************/
boolean TestActivateTask(App_DataValidateType LucDataValidate, TaskType TaskID)
{
  boolean LblStepResult;
  
  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Os_GucActivateTaskcnt != 0x00) && 
        (Os_GddTaskId == TaskID))
      {
        LblStepResult = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Os_GucActivateTaskcnt = 0;      
      break;
    } /* End case S_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  }
  return(LblStepResult);
} /* End TestActivateTask() */

#endif
#ifdef ECUM_MODULE_ACTIVE

/*******************************************************************************
**                             StartOS()                                      **
*******************************************************************************/
void StartOS(AppModeType mode)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GucStartSeqCnt = App_GucApiSeqCnt;
  Os_GucStartCount++;
  Os_GddMode = mode;
  #endif
}

/*******************************************************************************
**                             TestStartOS()                                  **
*******************************************************************************/
boolean TestStartOS(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, AppModeType LddMode)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Os_GddMode == LddMode) && (Os_GucStartCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucStartCount = 0;
      Os_GucStartSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if((Os_GddMode == LddMode) && (Os_GucStartSeqCnt == LucSeqNo))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucStartSeqCnt = 0;
      Os_GucStartCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestStartOS() */

/*******************************************************************************
**                             ShutdownOS()                                   **
*******************************************************************************/
void ShutdownOS(StatusType Error)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GucShutdownSeqCnt = App_GucApiSeqCnt;
  Os_GucShutdownCount++;
  Os_GddStatus = Error;
  #endif
}

/*******************************************************************************
**                             TestShutdownOS()                               **
*******************************************************************************/
boolean TestShutdownOS(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, StatusType LddError)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Os_GddStatus == LddError) && (Os_GucShutdownCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucShutdownCount = 0;
      Os_GucShutdownSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if((Os_GddStatus == LddError) && (Os_GucShutdownSeqCnt == LucSeqNo))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucShutdownSeqCnt = 0;
      Os_GucShutdownCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Os_GucShutdownCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestShutdownOS() */

/*******************************************************************************
**                             GetResource()                                  **
*******************************************************************************/
StatusType GetResource(ResourceType ResID)
{
  #ifndef TYPICAL_CONFIG
  Os_GaaGetResource[Os_GucGetResourceCount] = ResID;
  if(Os_GucGetResourceCount < OS_ARRAY_SIZE)
  {
    Os_GucGetResourceCount++;
  }
  App_GucApiSeqCnt++;
  Os_GucGetResourceSeqCnt = App_GucApiSeqCnt;
  #endif
  return(Os_GddStatus);
}

/*******************************************************************************
**                             TestGetResource()                              **
*******************************************************************************/
boolean TestGetResource(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, ResourceType LddResID)
{
  uint8 LucIndex;
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Os_GaaGetResource[0] == LddResID) && (Os_GucGetResourceCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucGetResourceCount = 0;
      Os_GucGetResourceSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if((Os_GaaGetResource[0] == LddResID) &&
        (Os_GucGetResourceSeqCnt == LucSeqNo))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucGetResourceSeqCnt = 0;
      Os_GucGetResourceCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Os_GucGetResourceCount; LucIndex++)
      {
        /* Validate Current state */
        if(Os_GaaGetResource[LucIndex] == LddResID)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucGetResourceCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucGetResCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucGetResCheckCount == Os_GucGetResourceCount)
      {
        Os_GucGetResourceCount = 0;
        Os_GucGetResCheckCount = 0;
        Os_GucGetResourceSeqCnt = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestGetResource() */

/*******************************************************************************
**                           ReleaseResource()                                **
*******************************************************************************/
StatusType ReleaseResource(ResourceType ResID)
{
  #ifndef TYPICAL_CONFIG
  Os_GaaReleaseResource[Os_GucGetResourceCount] = ResID;
  if(Os_GucReleaseResourceCount < OS_ARRAY_SIZE)
  {
    Os_GucReleaseResourceCount++;
  }
  App_GucApiSeqCnt++;
  Os_GucReleaseResourceSeqCnt = App_GucApiSeqCnt;
  #endif
  return(Os_GddStatus);
}

/*******************************************************************************
**                         TestReleaseResource()                              **
*******************************************************************************/
boolean TestReleaseResource(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, ResourceType LddResID)
{
  uint8 LucIndex;
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Os_GaaReleaseResource[0] == LddResID) && (Os_GucReleaseResourceCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucReleaseResourceCount = 0;
      Os_GucReleaseResourceSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if((Os_GaaReleaseResource[0] == LddResID) &&
        (Os_GucReleaseResourceSeqCnt == LucSeqNo))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucReleaseResourceSeqCnt = 0;
      Os_GucReleaseResourceCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Os_GucReleaseResourceCount; LucIndex++)
      {
        /* Validate Current state */
        if(Os_GaaReleaseResource[LucIndex] == LddResID)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucReleaseResourceCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucRelResCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucRelResCheckCount == Os_GucReleaseResourceCount)
      {
        Os_GucReleaseResourceCount = 0;
        Os_GucRelResCheckCount = 0;
        Os_GucReleaseResourceSeqCnt = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestReleaseResource() */

/*******************************************************************************
**                         SetEvent()                                         **
*******************************************************************************/
StatusType SetEvent(TaskType TaskID, EventMaskType Mask)
{
  #ifndef TYPICAL_CONFIG
  Os_GaaSetEventTaskId[Os_GucSetEventCount] = TaskID;
  Os_GaaSetEventMask[Os_GucSetEventCount] = Mask;
  if(Os_GucSetEventCount < OS_ARRAY_SIZE)
  {
    Os_GucSetEventCount++;
  }
  App_GucApiSeqCnt++;
  Os_GucSetEventSeqCnt = App_GucApiSeqCnt;
  #endif
  return(0);
}

/*******************************************************************************
**                         TestSetEvent()                                     **
*******************************************************************************/
boolean TestSetEvent(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, TaskType TaskID, EventMaskType Mask)
{
  uint8 LucIndex;
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Os_GaaSetEventTaskId[0] == TaskID) && (Os_GaaSetEventMask[0] == Mask) &&
        (Os_GucSetEventCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucSetEventCount = 0;
      Os_GucSetEventSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if((Os_GaaSetEventTaskId[0] == TaskID) && (Os_GaaSetEventMask[0] == Mask) &&
        (Os_GucSetEventSeqCnt == LucSeqNo))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucSetEventSeqCnt = 0;
      Os_GucSetEventCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Os_GucSetEventCount; LucIndex++)
      {
        /* Validate Current state */
        if((Os_GaaSetEventTaskId[LucIndex] == TaskID) &&
          (Os_GaaSetEventMask[LucIndex] == Mask))
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucSetEventCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucSetEventCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucSetEventCheckCount == Os_GucSetEventCount)
      {
        Os_GucSetEventCount = 0;
        Os_GucSetEventCheckCount = 0;
        Os_GucSetEventSeqCnt = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestReleaseResource() */
/*******************************************************************************
**                         WaitEvent()                                        **
*******************************************************************************/
StatusType WaitEvent(EventMaskType Mask)
{
  #ifndef TYPICAL_CONFIG
  Os_GaaWaitEventMask[Os_GucWaitEventCount] = Mask;
  if(Os_GucWaitEventCount < OS_ARRAY_SIZE)
  {
    Os_GucWaitEventCount++;
  }
  App_GucApiSeqCnt++;
  Os_GucWaitEventSeqCnt = App_GucApiSeqCnt;
  #endif
  return(0);
}

/*******************************************************************************
**                         TestSetEvent()                                     **
*******************************************************************************/
boolean TestWaitEvent(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, EventMaskType Mask)
{
  uint8 LucIndex;
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Os_GaaWaitEventMask[0] == Mask) &&
        (Os_GucWaitEventCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucWaitEventCount = 0;
      Os_GucWaitEventSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if((Os_GaaWaitEventMask[0] == Mask) &&
        (Os_GucWaitEventSeqCnt == LucSeqNo))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucWaitEventSeqCnt = 0;
      Os_GucWaitEventCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Os_GucWaitEventCount; LucIndex++)
      {
        /* Validate Current state */
        if(Os_GaaWaitEventMask[LucIndex] == Mask)
        {
          LblStepResult = STEP_PASSED;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucWaitEventCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucWaitEventCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucWaitEventCheckCount == Os_GucWaitEventCount)
      {
        Os_GucWaitEventCount = 0;
        Os_GucWaitEventCheckCount = 0;
        Os_GucWaitEventSeqCnt = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestReleaseResource() */
/*******************************************************************************
**                         EnableAllInterrupts()                              **
*******************************************************************************/
void EnableAllInterrupts(void)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GucEnableAllSeqCnt[Os_GucEnableAllCount] = App_GucApiSeqCnt;
  if(Os_GucEnableAllCount < OS_ARRAY_SIZE)
  {
    Os_GucEnableAllCount++;
  }
  else
  {
    Os_GucEnableAllCount = 0;
  }
  #endif
}
/*******************************************************************************
**                         DisableAllInterrupts()                             **
*******************************************************************************/
void DisableAllInterrupts(void)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GucDisableAllSeqCnt[Os_GucDisableAllCount] = App_GucApiSeqCnt;
  if(Os_GucDisableAllCount < OS_ARRAY_SIZE)
  {
    Os_GucDisableAllCount++;
  }
  else
  {
    Os_GucDisableAllCount = 0;
  }
  #endif
}
/*******************************************************************************
**                         TestEnableAllInterrupts()                          **
*******************************************************************************/
boolean TestEnableAllInterrupts(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Os_GucEnableAllCount == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucEnableAllCount = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if(Os_GucEnableAllSeqCnt[0] == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucEnableAllCount = 0;

      break;
    } /* End case S_VALIDATE_SEQ: */

    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Os_GucEnableAllCount; LucIndex++)
      {
        /* Validate Current state */
        if(Os_GucEnableAllSeqCnt[LucIndex] == LucSeqNo)
        {
          LblStepResult = STEP_PASSED;
          Os_GucEnableAllSeqCnt[LucIndex] = 0;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucEnableAllCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucEnableCheckStateCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucEnableCheckStateCount == Os_GucEnableAllCount)
      {
        Os_GucEnableAllCount = 0;
        Os_GucEnableCheckStateCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
}
/*******************************************************************************
**                         TestDisableAllInterrupts()                         **
*******************************************************************************/
boolean TestDisableAllInterrupts(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Os_GucDisableAllCount == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucDisableAllCount = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if(Os_GucDisableAllSeqCnt[0] == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucDisableAllCount = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Os_GucDisableAllCount; LucIndex++)
      {
        /* Validate Current state */
        if(Os_GucDisableAllSeqCnt[LucIndex] == LucSeqNo)
        {
          LblStepResult = STEP_PASSED;
          Os_GucDisableAllSeqCnt[LucIndex] = 0;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucDisableAllCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucDisableCheckStateCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucDisableCheckStateCount == Os_GucDisableAllCount)
      {
        Os_GucDisableAllCount = 0;
        Os_GucDisableCheckStateCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
}
/*******************************************************************************
**                         StartCore()                                        **
*******************************************************************************/
void StartCore(CoreIdType CoreID, StatusType* Status)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GaaStartCoreSeqCnt[Os_GucStartCoreCount] = App_GucApiSeqCnt;
  if(Os_GucStartCoreCount < OS_ARRAY_SIZE)
  {
    Os_GucStartCoreCount++;
  }
  else
  {
    Os_GucStartCoreCount = 0;
  }
  UNUSED(CoreID);
  UNUSED(Status);
  #endif
}
/*******************************************************************************
**                         ShutdownAllCores()                                 **
*******************************************************************************/
void ShutdownAllCores(StatusType Error)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GucShutdownAllCoresSeqCnt = App_GucApiSeqCnt;
  Os_GucShutdownAllCoresCount++;
	UNUSED(Error);
  #endif
}
/*******************************************************************************
**                         AppOs_SimulateGetCoreID()                          **
*******************************************************************************/
void AppOs_SimulateGetCoreID(CoreIdType Type)
{
  OsApp_GddCoreId = Type;
}
/*******************************************************************************
**                         GetCoreID()                                        **
*******************************************************************************/
CoreIdType GetCoreID(void)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Os_GucGetCoreIDSeqCnt[Os_GucGetCoreIDCount] = App_GucApiSeqCnt;
  if(Os_GucGetCoreIDCount < OS_ARRAY_SIZE)
  {
    Os_GucGetCoreIDCount++;
  }
  else
  {
    Os_GucGetCoreIDCount = 0;
  }
  #endif
  return(OsApp_GddCoreId);
}

/*******************************************************************************
**                         TestStartCore()                                    **
*******************************************************************************/
boolean TestStartCore(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, CoreIdType LddCoreId, StatusType *LddStatus)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Os_GucStartCoreCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucStartCoreCount = 0;
      Os_GaaStartCoreSeqCnt[Os_GucStartCoreCount] = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if(Os_GaaStartCoreSeqCnt[Os_GucStartCoreCount] == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucStartCoreCount = 0;
      Os_GaaStartCoreSeqCnt[Os_GucStartCoreCount] = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Os_GucStartCoreCount; LucIndex++)
      {
        /* Validate Current state */
        if(Os_GaaStartCoreSeqCnt[LucIndex] == LucSeqNo)
        {
          LblStepResult = STEP_PASSED;
          Os_GaaStartCoreSeqCnt[LucIndex] = 0;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucStartCoreCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucStartCoreStateCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucStartCoreStateCount == Os_GucStartCoreCount)
      {
        Os_GucStartCoreCount = 0;
        Os_GucStartCoreStateCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  UNUSED(LddCoreId);
	UNUSED(LddStatus);
  return(LblStepResult);
} /* End TestReleaseResource() */

/*******************************************************************************
**                         TestGetCoreID()                                    **
*******************************************************************************/
boolean TestGetCoreID(App_DataValidateType LucDataValidate, uint8 LucSeqNo)
{
  uint8 LucIndex;
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Os_GucGetCoreIDCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucGetCoreIDCount = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if(Os_GucGetCoreIDSeqCnt[0] == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucGetCoreIDCount = 0;
      Os_GucGetCoreIDSeqCnt[0] = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */


    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Os_GucGetCoreIDCount; LucIndex++)
      {
        /* Validate Current state */
        if(Os_GucGetCoreIDSeqCnt[LucIndex] == LucSeqNo)
        {
          LblStepResult = STEP_PASSED;
          Os_GucGetCoreIDSeqCnt[LucIndex] = 0;
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Os_GucGetCoreIDCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Os_GucGetCoreStateCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Os_GucGetCoreStateCount == Os_GucGetCoreIDCount)
      {
        Os_GucGetCoreIDCount = 0;
        Os_GucGetCoreStateCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestReleaseResource() */

/*******************************************************************************
**                         TestShutdownAllCores()                             **
*******************************************************************************/
boolean TestShutdownAllCores(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo, StatusType Error)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;


  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
   case S_VALIDATE:
    {
      if((Os_GucShutdownAllCoresCount == 0x01))
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucShutdownAllCoresCount = 0;
      Os_GucShutdownAllCoresSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */

    case S_VALIDATE_SEQ:
    {
      if(Os_GucShutdownAllCoresSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Os_GucShutdownAllCoresCount = 0;
      Os_GucShutdownAllCoresSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Os_GucShutdownAllCoresCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }

    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  UNUSED(Error);
  return(LblStepResult);
} /* End TestShutdownAllCores() */
#endif
#ifndef STBM_MODULE_ACTIVE
/*******************************************************************************
**                       TestOs_DefaultBehavior()                             **
*******************************************************************************/
void TestOs_DefaultBehavior(void)
{
  #ifdef DBG_MODULE_ACTIVE
  Os_GddAlarmID = 0;
  Os_GddStart = 0;
  Os_GddCycle = 0;
  Os_GucSetAbsAlarmCount = 0;
  Os_GucCancelAlarm = 0;
  #endif
  #ifdef ECUM_MODULE_ACTIVE
  Os_GddMode = 0;
  Os_GddStatus = E_OK;
  Os_GddResourceId = 0;
  Os_GucStartCount = 0;
  Os_GucStartSeqCnt = 0;
  Os_GucShutdownSeqCnt = 0;
  Os_GucShutdownCount = 0;
  Os_GucGetResourceSeqCnt = 0;
  Os_GucGetResourceCount = 0;
  Os_GucReleaseResourceSeqCnt = 0;
  Os_GucReleaseResourceCount = 0;
  Os_GucEnableAllCount = 0;
  Os_GucDisableAllCount = 0;
  Os_GucEnableCheckStateCount = 0;
  Os_GucDisableCheckStateCount = 0;
  Os_GucStartCoreStateCount = 0;
  Os_GucGetCoreIDCount = 0;
  #endif
} /* End TestOs_DefaultBehavior() */
#endif /* ifndef STBM_MODULE_ACTIVE */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
