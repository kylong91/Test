/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Os.h                                                          **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Os Stub                                               **
**                                                                            **
**  PURPOSE   : Declaration of Os Stub functions                              **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By          Description                            **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/
#ifndef OS_H
#define OS_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
#include "Std_Types.h"
#include "Os_Types.h"

/*******************************************************************************
**                      Version Information                                  **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define OS_AR_RELEASE_MAJOR_VERSION    0x04
#define OS_AR_RELEASE_MINOR_VERSION    0x00
#define OS_AR_RELEASE_REVISION_VERSION 0x03

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#define OsAlarm0 (AlarmType)0

extern AppModeType Os_GddMode;
extern StatusType Os_GddStatus;
extern ResourceType Os_GddResourceId;
#define OsConf_OsAppMode_OsAppMode0 (AppModeType)0
#define OsConf_OsResource_OsResource0 (ResourceType)0
#define OsConf_OsResource_OsResource1 (ResourceType)1
#define OS_CORE_ID_MASTER (CoreIdType)0
#define OS_CORE_ID_0 (CoreIdType)1
#define OS_CORE_ID_1 (CoreIdType)2

#define OS_ARRAY_SIZE 25

#define OsApplication1 (ApplicationType)0
#define OsApplication0 (ApplicationType)0
#define OsTask0 (TaskType)0
#define OsTask1 (TaskType)1
#define OsCounter1 (CounterType)0
#define OsCounter0 (CounterType)0
#define EcucPartition0 0
#define OsConf_OsCounter_OsCounter0 0
#define OsConf_OsScheduleTable_OsScheduleTable0 0
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern void StartOS(AppModeType mode);
extern void ShutdownOS(StatusType Error);

extern void TestOs_DefaultBehavior(void);

extern StatusType SetAbsAlarm(AlarmType AlarmID, TickType start, 
  TickType cycle);
extern StatusType CancelAlarm(AlarmType AlarmID);

extern StatusType GetCounterValue(CounterType CounterID, TickRefType Value);
extern StatusType GetElapsedValue(CounterType CounterID, TickRefType Value, 
  TickRefType ElapsedValue);
extern boolean TestGetElapsedValue(App_DataValidateType LucDataValidate,
 CounterType CounterID, TickType Value, TickType ElapsedValue);

extern boolean TestSetAbsAlarm(App_DataValidateType LucDataValidate, 
  AlarmType ExpAlarmID, TickType Expstart, TickType Expcycle);
extern boolean TestCancelAlarm(App_DataValidateType LucDataValidate, 
  AlarmType ExpAlarmID);

extern void TestResetOsInvocationCounts(void);

extern void TestGetElapsedValueSetVal
(StatusType RetStatus, TickType Value, TickType ElapsedValue);

extern StatusType GetScheduleTableStatus
(ScheduleTableType ScheduleTableID, ScheduleTableStatusRefType ScheduleStatus);

extern boolean TestGetScheduleTableStatus
(App_DataValidateType LucDataValidate, ScheduleTableType ScheduleTableID,
 ScheduleTableStatusType ScheduleStatus);

extern void TestGetScheduleTableStatusSetVal
(StatusType RetStatus, ScheduleTableStatusType ScheduleStatus);

extern StatusType SyncScheduleTable
(ScheduleTableType ScheduleTableID, TickType Value);

extern boolean TestSyncScheduleTable
(App_DataValidateType LucDataValidate,
 ScheduleTableType ScheduleTableID, TickType Value);

extern void TestSyncScheduleTableSetVal(StatusType RetStatus);

extern CoreIdType GetCoreID( void );
extern StatusType GetResource(ResourceType ResID);
extern StatusType ReleaseResource(ResourceType ResID);
extern StatusType SetEvent(TaskType TaskID, EventMaskType Mask);
extern StatusType WaitEvent(EventMaskType Mask);
extern void EnableAllInterrupts(void);
extern void DisableAllInterrupts(void);
extern void StartCore(CoreIdType CoreID, StatusType* Status);
extern void ShutdownAllCores(StatusType Error);
extern boolean TestStartOS(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, AppModeType LddMode);
extern boolean TestShutdownOS(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, StatusType LddError);
extern boolean TestGetResource(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, ResourceType LddResID);
extern boolean TestReleaseResource(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, ResourceType LddResID);
extern boolean TestEnableAllInterrupts(App_DataValidateType LucDataValidate,
  uint8 LucSeqNo);
extern boolean TestDisableAllInterrupts(App_DataValidateType LucDataValidate,
	uint8 LucSeqNo);
extern boolean TestGetCoreID(App_DataValidateType LucDataValidate,
	uint8 LucSeqNo);
extern boolean TestStartCore(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, CoreIdType LddCoreId, StatusType *LddStatus);
extern boolean TestShutdownAllCores(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, StatusType Error);
extern boolean TestSetEvent(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, TaskType TaskID, EventMaskType Mask);
extern boolean TestWaitEvent(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo, EventMaskType Mask);
extern void AppOs_SimulateGetCoreID(CoreIdType Type);

extern StatusType ActivateTask(TaskType TaskID);

extern boolean TestActivateTask(App_DataValidateType LucDataValidate, TaskType TaskID);

#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
