/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Os_Types.h                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR OS                                                    **
**                                                                            **
**  PURPOSE   : ApplicationType  and CoreIdType                               **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/
#ifndef OS_TYPES_H
#define OS_TYPES_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/

typedef uint8 ApplicationType;
typedef uint16 CoreIdType;
typedef uint8 TaskType;
typedef uint8 AlarmType;
typedef uint32 TickType;
typedef TickType * TickRefType;
typedef uint8 ScheduleTableType;
typedef uint8 ScheduleTableStatusType;
typedef ScheduleTableStatusType * ScheduleTableStatusRefType;
typedef uint8 CounterType;
typedef uint8  AppModeType;
typedef uint8  ResourceType;
typedef uint8 EventMaskType;

/*
 * @def E_OS_ID
 *
 * This error code means : invalid identifier
 *
 * @warning OSEK error code meanings are not globally defined. Refer to each
 * standard service definition to know the exact meaning.
 */
#define E_OS_ID                               (uint8) 3
/*******************************************************************************
** Schedule Table states and actions                                          **
*******************************************************************************/
/**
 * @def SCHEDULETABLE_STOPPED
 *
 * This is a state of a ScheduleTable.
 */
#define SCHEDULETABLE_STOPPED                 ((ScheduleTableStatusType) 0)

/**
 * @def SCHEDULETABLE_NEXT
 *
 * This is a state of a ScheduleTable.
 */
#define SCHEDULETABLE_NEXT                    ((ScheduleTableStatusType) 1)

/**
 * @def SCHEDULETABLE_RUNNING
 *
 * This is a state of a ScheduleTable.
 */
#define SCHEDULETABLE_RUNNING                 ((ScheduleTableStatusType) 2)

/**
 * @def SCHEDULETABLE_STOPPED
 *
 * This is a state of a ScheduleTable.
 */
#define SCHEDULETABLE_WAITING                 ((ScheduleTableStatusType) 3)

/**
 * @def OS_SCHEDULETABLE_EXP_DEV
 *
 * This is a state of a ScheduleTable.
 */
#define OS_SCHEDULETABLE_EXP_DEV              ((ScheduleTableStatusType) 4)

/**
 * @def SCHEDULETABLE_RUNNING_AND_SYNCHRONOUS
 *
 * This is a state of a ScheduleTable.
 */
#define SCHEDULETABLE_RUNNING_AND_SYNCHRONOUS ((ScheduleTableStatusType) 5)

/**
 * @def OS_SCHEDULETABLE_EXP_REQ
 *
 * This is a state of a ScheduleTable.
 */
#define OS_SCHEDULETABLE_EXP_REQ              ((ScheduleTableStatusType) 6)

/**
 * @def OS_SCHEDULETABLE_EXP_PRE
 *
 * This is a state of a ScheduleTable.
 */
#define OS_SCHEDULETABLE_EXP_PRE              ((ScheduleTableStatusType) 7)
#endif 

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
