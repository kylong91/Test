/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE:  LinTrcv.c                                                    **
**                                                                            **
**  TARGET    :  ALL                                                          **
**                                                                            **
**  PRODUCT   : AUTOSAR LIN Transceiver Module                                **
**                                                                            **
**  PURPOSE   : This file is a stub for LIN Transceiver Driver Component      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     03-Jan-2012    NKD    Creation of LinTrcv_39_DriverB.c module    **
*******************************************************************************/

/******************************************************************************
**                      Include Section                                      **
******************************************************************************/
#include "LinTrcv_39_DriverB.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/* Variables used for LinIf module  */
Std_ReturnType LinTrcvB_GaaSetOpModeRet[LINTRCV_39_DRIVERB_ARRAY_SIZE];
Std_ReturnType LinTrcvB_GaaGetOpModeRet[LINTRCV_39_DRIVERB_ARRAY_SIZE];

Std_ReturnType LinTrcvB_GaasetWakeupModeRet[LINTRCV_39_DRIVERB_ARRAY_SIZE];
Std_ReturnType LinTrcvB_GaaGetCheckWakeupRet[LINTRCV_39_DRIVERB_ARRAY_SIZE];

Std_ReturnType LinTrcvB_GaaGetBusWuReasonRet[LINTRCV_39_DRIVERB_ARRAY_SIZE];
uint8 LinTrcvB_GucSetOpModeCount;
uint8 LinTrcvB_GucGetOpModeCount;

uint8 LinTrcvB_GucCheckWakeupCount;
uint8 LinTrcvB_GucCheckWakeupCheckCount;
uint8 LinTrcvB_GucSetWakeupModeCount;
uint8 LinTrcvB_GucSetWakeupModeCheckCount;

uint8 LinTrcvB_GucGetBusWuReasonCount;
uint8 LinTrcvB_GucSetOpModeCheckCount;
uint8 LinTrcvB_GucGetOpModeCheckCount;
uint8 LinTrcvB_GucGetBusWuReasChkCount;
uint8 LinTrcvB_GaaSetOpModeNw[LINTRCV_39_DRIVERB_ARRAY_SIZE];
uint8 LinTrcvB_GaaGetOpModeNw[LINTRCV_39_DRIVERB_ARRAY_SIZE];

uint8 LinTrcvB_GaaCheckWakeupNw[LINTRCV_39_DRIVERB_ARRAY_SIZE];
LinTrcv_TrcvWakeupModeType LinTrcvB_GaaSetWakeupMode[LINTRCV_39_DRIVERB_ARRAY_SIZE];
LinTrcv_TrcvWakeupModeType LinTrcvB_GaaSetWakeupModeNw[LINTRCV_39_DRIVERB_ARRAY_SIZE];

uint8 LinTrcvB_GaaGetBusWuReasonNw[LINTRCV_39_DRIVERB_ARRAY_SIZE];
LinTrcv_TrcvModeType LinTrcvB_GaaSetOpMode[LINTRCV_39_DRIVERB_ARRAY_SIZE];
LinTrcv_TrcvModeType LinTrcvB_GaaGetOpMode[LINTRCV_39_DRIVERB_ARRAY_SIZE];
LinTrcv_TrcvWakeupReasonType LinTrcvB_GaaGetBusWuReason[LINTRCV_39_DRIVERB_ARRAY_SIZE];
/* Variables used for LinIf module  */
/*******************************************************************************
**                       TestLinTrcv_39_DriverBDefaultBehavior()              **
*******************************************************************************/
void TestLinTrcv_39_DriverBDefaultBehavior(void)
{
  uint8 LucCount;  
  
  for(LucCount = 0x00; LucCount < LINTRCV_39_DRIVERB_ARRAY_SIZE; LucCount++)
  {
    LinTrcvB_GaaSetOpModeRet[LucCount] = E_OK;
    LinTrcvB_GaaGetOpModeRet[LucCount] = E_OK;
    LinTrcvB_GaaGetBusWuReasonRet[LucCount] = E_OK;
    
    LinTrcvB_GaasetWakeupModeRet[LucCount] = E_OK;
    LinTrcvB_GaaGetCheckWakeupRet[LucCount] = E_OK; 
  }
  LinTrcvB_GucSetOpModeCount = 0x00;
  LinTrcvB_GucGetOpModeCount = 0x00;
  
  LinTrcvB_GucCheckWakeupCount = 0x00;
  LinTrcvB_GucSetWakeupModeCount = 0x00;
  LinTrcvB_GucSetWakeupModeCheckCount = 0x00;
  LinTrcvB_GucCheckWakeupCheckCount = 0x00;
  
  LinTrcvB_GucGetBusWuReasonCount = 0x00;
  LinTrcvB_GucSetOpModeCheckCount = 0x00;
  LinTrcvB_GucGetOpModeCheckCount = 0x00;
  LinTrcvB_GucGetBusWuReasChkCount = 0x00;  
} /* End TestLinTrcv_39_DriverBDefaultBehavior() */


/*******************************************************************************
**                       LinTrcv_39_DriverB_CheckWakeup()                     **
*******************************************************************************/
Std_ReturnType LinTrcv_39_DriverB_CheckWakeup(uint8 LinNetwork )
{
  #ifndef TYPICAL_CONFIG
  LinTrcvB_GaaCheckWakeupNw[LinTrcvB_GucCheckWakeupCount] = LinNetwork;
  /* Increment count variable to handle multiple invocations */
  if(LinTrcvB_GucCheckWakeupCount != LINTRCV_39_DRIVERB_ARRAY_SIZE)
  {    
    LinTrcvB_GucCheckWakeupCount++;
  } 
  return(LinTrcvB_GaaGetCheckWakeupRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcv_39_DriverB_CheckWakeup() */

/*******************************************************************************
**                       TestLinTrcv_39_DriverB_CheckWakeup()                 **
*******************************************************************************/
boolean TestLinTrcv_39_DriverB_CheckWakeup(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcvB_GucCheckWakeupCount == 0x01) && 
        (ExpLinNetwork == LinTrcvB_GaaCheckWakeupNw[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcvB_GucCheckWakeupCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcvB_GucCheckWakeupCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcvB_GucCheckWakeupCheckCount <= LinTrcvB_GucCheckWakeupCount) &&
        (ExpLinNetwork == LinTrcvB_GaaCheckWakeupNw[LinTrcvB_GucCheckWakeupCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcvB_GucCheckWakeupCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcvB_GucCheckWakeupCheckCount == LinTrcvB_GucCheckWakeupCount)
      {
        LinTrcvB_GucCheckWakeupCount = 0;
        LinTrcvB_GucCheckWakeupCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcvB_GucCheckWakeupCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcvB_GaaCheckWakeupNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcvB_39_DriverB_CheckWakeup */

/*******************************************************************************
**                       LinTrcv_39_DriverB_SetWakeupMode()                   **
*******************************************************************************/
Std_ReturnType LinTrcv_39_DriverB_SetWakeupMode ( uint8 LinNetwork, 
LinTrcv_TrcvWakeupModeType TrcvWakupMode)
{
  #ifndef TYPICAL_CONFIG
  LinTrcvB_GaaSetWakeupModeNw[LinTrcvB_GucSetWakeupModeCount] = LinNetwork;
  LinTrcvB_GaaSetWakeupMode[LinTrcvB_GucSetWakeupModeCount] = TrcvWakupMode;  
  /* Increment count variable to handle multiple invocations */
  if(LinTrcvB_GucSetWakeupModeCount != LINTRCV_39_DRIVERB_ARRAY_SIZE)
  {    
    LinTrcvB_GucSetWakeupModeCount++;
  } 
  return(LinTrcvB_GaasetWakeupModeRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcv_SetOpMode() */
/*******************************************************************************
**                       TestLinTrcv_39_DriverB_SetWakeupMode()               **
*******************************************************************************/
Std_ReturnType TestLinTrcv_39_DriverB_SetWakeupMode
  (App_DataValidateType LucDataValidate,
  uint8 ExpLinNetwork, LinTrcv_TrcvWakeupModeType ExpOpMode)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcvB_GucSetWakeupModeCount == 0x01) && 
        (ExpLinNetwork == LinTrcvB_GaaSetWakeupModeNw[0]) && 
        (ExpOpMode == LinTrcvB_GaaSetWakeupMode[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcvB_GucSetWakeupModeCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcvB_GucSetWakeupModeCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcvB_GucSetWakeupModeCheckCount <= LinTrcvB_GucSetWakeupModeCount) &&
        (ExpLinNetwork == LinTrcvB_GaaSetWakeupModeNw[LinTrcvB_GucSetWakeupModeCheckCount]) && 
        (ExpOpMode == 
        LinTrcvB_GaaSetWakeupMode[LinTrcvB_GucSetWakeupModeCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcvB_GucSetWakeupModeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcvB_GucSetWakeupModeCheckCount == LinTrcvB_GucSetWakeupModeCount)
      {
        LinTrcvB_GucSetWakeupModeCount = 0;
        LinTrcvB_GucSetWakeupModeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcvB_GucSetWakeupModeCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcvB_GaaSetWakeupModeNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcvB_SetWakeupMode() */

/*******************************************************************************
**                       LinTrcv_39_DriverBSetOpMode()                        **
*******************************************************************************/
Std_ReturnType LinTrcv_39_DriverB_SetOpMode(uint8 LinNetwork, 
  LinTrcv_TrcvModeType OpMode)
{
  #ifndef TYPICAL_CONFIG
  LinTrcvB_GaaSetOpModeNw[LinTrcvB_GucSetOpModeCount] = LinNetwork;
  LinTrcvB_GaaSetOpMode[LinTrcvB_GucSetOpModeCount] = OpMode;  
  /* Increment count variable to handle multiple invocations */
  if(LinTrcvB_GucSetOpModeCount != LINTRCV_39_DRIVERB_ARRAY_SIZE)
  {    
    LinTrcvB_GucSetOpModeCount++;
  } 
  return(LinTrcvB_GaaSetOpModeRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcv_39_DriverBSetOpMode() */

/*******************************************************************************
**                       TestLinTrcv_39_DriverBSetOpMode()                    **
*******************************************************************************/
boolean TestLinTrcv_39_DriverBSetOpMode(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork, LinTrcv_TrcvModeType ExpOpMode)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcvB_GucSetOpModeCount == 0x01) && 
        (ExpLinNetwork == LinTrcvB_GaaSetOpModeNw[0]) && 
        (ExpOpMode == LinTrcvB_GaaSetOpMode[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcvB_GucSetOpModeCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcvB_GucSetOpModeCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcvB_GucSetOpModeCheckCount <= LinTrcvB_GucSetOpModeCount) &&
        (ExpLinNetwork == LinTrcvB_GaaSetOpModeNw[LinTrcvB_GucSetOpModeCheckCount]) && 
        (ExpOpMode == 
        LinTrcvB_GaaSetOpMode[LinTrcvB_GucSetOpModeCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcvB_GucSetOpModeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcvB_GucSetOpModeCheckCount == LinTrcvB_GucSetOpModeCount)
      {
        LinTrcvB_GucSetOpModeCount = 0;
        LinTrcvB_GucSetOpModeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcvB_GucSetOpModeCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcvB_GaaSetOpModeNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcvB_39_DriverBSetOpMode() */

/*******************************************************************************
**                       TestSetLinTrcv_39_DriverBSetOpModeRetVal()           **
*******************************************************************************/
void TestSetLinTrcv_39_DriverBSetOpModeRetVal(uint8 LinNetwork, 
  Std_ReturnType RetVal)
{
  LinTrcvB_GaaSetOpModeRet[LinNetwork] = RetVal;
} /* End TestSetLinTrcvB_39_DriverBSetOpModeRetVal()  */

/*******************************************************************************
**                       LinTrcv_39_DriverBGetOpMode()                        **
*******************************************************************************/
Std_ReturnType LinTrcv_39_DriverB_GetOpMode(uint8 LinNetwork, 
  LinTrcv_TrcvModeType* OpMode)
{
  #ifndef TYPICAL_CONFIG
  LinTrcvB_GaaGetOpModeNw[LinTrcvB_GucGetOpModeCount] = LinNetwork;
  *OpMode = LinTrcvB_GaaGetOpMode[LinNetwork];  
  /* Increment count variable to handle multiple invocations */
  if(LinTrcvB_GucGetOpModeCount != LINTRCV_39_DRIVERB_ARRAY_SIZE)
  {    
    LinTrcvB_GucGetOpModeCount++;
  } 
  return(LinTrcvB_GaaGetOpModeRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcv_39_DriverBGetOpMode() */

/*******************************************************************************
**                       TestLinTrcv_39_DriverBGetOpMode()                    **
*******************************************************************************/
boolean TestLinTrcv_39_DriverBGetOpMode(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcvB_GucGetOpModeCount == 0x01) && 
        (ExpLinNetwork == LinTrcvB_GaaGetOpModeNw[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcvB_GucGetOpModeCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcvB_GucGetOpModeCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcvB_GucGetOpModeCheckCount <= LinTrcvB_GucGetOpModeCount) &&
        (ExpLinNetwork == LinTrcvB_GaaGetOpModeNw[LinTrcvB_GucGetOpModeCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcvB_GucGetOpModeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcvB_GucGetOpModeCheckCount == LinTrcvB_GucGetOpModeCount)
      {
        LinTrcvB_GucGetOpModeCount = 0;
        LinTrcvB_GucGetOpModeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcvB_GucGetOpModeCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcvB_GaaGetOpModeNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcv_39_DriverBGetOpMode() */

/*******************************************************************************
**                       TestSetLinTrcv_39_DriverBGetOpModeRetVal()           **
*******************************************************************************/
void TestSetLinTrcv_39_DriverBGetOpModeRetVal(uint8 SetLinNetwork, 
  LinTrcv_TrcvModeType SetOpMode, Std_ReturnType RetVal)
{
  LinTrcvB_GaaGetOpMode[SetLinNetwork] = SetOpMode;
  LinTrcvB_GaaGetOpModeRet[SetLinNetwork] = RetVal;  
} /* End TestSetLinTrcv_39_DriverBGetOpModeRetVal()  */
/*******************************************************************************
**                       LinTrcv_39_DriverBGetBusWuReason()                   **
*******************************************************************************/
Std_ReturnType LinTrcv_39_DriverB_GetBusWuReason(uint8 LinNetwork, 
  LinTrcv_TrcvWakeupReasonType* Reason)
{
  #ifndef TYPICAL_CONFIG  
  LinTrcvB_GaaGetBusWuReasonNw[LinTrcvB_GucGetBusWuReasonCount] = LinNetwork;
  *Reason = LinTrcvB_GaaGetBusWuReason[LinNetwork];  
  /* Increment count variable to handle multiple invocations */
  if(LinTrcvB_GucGetBusWuReasonCount != LINTRCV_39_DRIVERB_ARRAY_SIZE)
  {    
    LinTrcvB_GucGetBusWuReasonCount++;
  } 
  return(LinTrcvB_GaaGetBusWuReasonRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcvB_39_DriverBGetBusWuReason() */

/*******************************************************************************
**                            TestLinTrcvB_39_DriverBGetBusWuReason()          **
*******************************************************************************/
boolean TestLinTrcv_39_DriverBGetBusWuReason(App_DataValidateType LucDataValidate,
  uint8 ExpLinNetwork)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcvB_GucGetBusWuReasonCount == 0x01) && 
        (ExpLinNetwork == LinTrcvB_GaaGetBusWuReasonNw[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcvB_GucGetBusWuReasonCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcvB_GucGetBusWuReasonCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcvB_GucGetBusWuReasChkCount <= LinTrcvB_GucGetBusWuReasonCount) &&
        (ExpLinNetwork == 
          LinTrcvB_GaaGetBusWuReasonNw[LinTrcvB_GucGetBusWuReasChkCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcvB_GucGetBusWuReasChkCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcvB_GucGetBusWuReasChkCount == LinTrcvB_GucGetBusWuReasonCount)
      {
        LinTrcvB_GucGetBusWuReasonCount = 0;
        LinTrcvB_GucGetBusWuReasChkCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcvB_GucGetBusWuReasonCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcvB_GaaGetBusWuReasonNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcv_39_DriverBGetBusWuReason() */

/*******************************************************************************
**                       TestSetLinTrcv_39_DriverBGetBusWuReasonRetVal()      **
*******************************************************************************/
void TestSetLinTrcv_39_DriverBGetBusWuReasonRetVal(uint8 SetLinNetwork, 
  LinTrcv_TrcvWakeupReasonType SetReason, Std_ReturnType RetVal)
{
  LinTrcvB_GaaGetBusWuReason[SetLinNetwork] = SetReason;
  LinTrcvB_GaaGetBusWuReasonRet[SetLinNetwork] = RetVal;  
} /* End TestSetLinTrcv_39_DriverBGetBusWuReasonRetVal()  */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
