/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE:  LinTrcv.c                                                    **
**                                                                            **
**  TARGET    :  ALL                                                          **
**                                                                            **
**  PRODUCT   : AUTOSAR LIN Transceiver Module                                **
**                                                                            **
**  PURPOSE   : This file is a stub for LIN Transceiver Driver Component      **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     03-Jan-2012   NKD    Creation of LinTrcv_39_DriverA.c module     **
*******************************************************************************/

/******************************************************************************
**                      Include Section                                      **
******************************************************************************/
#include "LinTrcv_39_DriverA.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/* Variables used for LinIf module  */
Std_ReturnType LinTrcvA_GaaSetOpModeRet[LINTRCV_39_DRIVERA_ARRAY_SIZE];
Std_ReturnType LinTrcvA_GaaGetOpModeRet[LINTRCV_39_DRIVERA_ARRAY_SIZE];
Std_ReturnType LinTrcvA_GaaGetBusWuReasonRet[LINTRCV_39_DRIVERA_ARRAY_SIZE];

Std_ReturnType LinTrcvA_GaaSetWakeupModeRet[LINTRCV_39_DRIVERA_ARRAY_SIZE];
Std_ReturnType LinTrcvA_GaaGetCheckWakeupRet[LINTRCV_39_DRIVERA_ARRAY_SIZE];

uint8 LinTrcvA_GucSetOpModeCount;
uint8 LinTrcvA_GucGetOpModeCount;
uint8 LinTrcvA_GucGetBusWuReasonCount;
uint8 LinTrcvA_GucSetOpModeCheckCount;

uint8 LinTrcvA_GucCheckWakeupCount;
uint8 LinTrcvA_GucCheckWakeupCheckCount;
uint8 LinTrcvA_GucSetWakeupModeCount;
uint8 LinTrcvA_GucSetWakeupModeCheckCount;

uint8 LinTrcvA_GucGetOpModeCheckCount;
uint8 LinTrcvA_GucGetBusWuReasChkCount;
uint8 LinTrcvA_GaaSetOpModeNw[LINTRCV_39_DRIVERA_ARRAY_SIZE];
uint8 LinTrcvA_GaaGetOpModeNw[LINTRCV_39_DRIVERA_ARRAY_SIZE];

uint8 LinTrcvA_GaaCheckWakeupNw[LINTRCV_39_DRIVERA_ARRAY_SIZE];
LinTrcv_TrcvWakeupModeType LinTrcvA_GaaSetWakeupMode[LINTRCV_39_DRIVERA_ARRAY_SIZE];
LinTrcv_TrcvWakeupModeType LinTrcvA_GaaSetWakeupModeNw[LINTRCV_39_DRIVERA_ARRAY_SIZE];

uint8 LinTrcvA_GaaGetBusWuReasonNw[LINTRCV_39_DRIVERA_ARRAY_SIZE];
LinTrcv_TrcvModeType LinTrcvA_GaaSetOpMode[LINTRCV_39_DRIVERA_ARRAY_SIZE];
LinTrcv_TrcvModeType LinTrcvA_GaaGetOpMode[LINTRCV_39_DRIVERA_ARRAY_SIZE];
LinTrcv_TrcvWakeupReasonType LinTrcvA_GaaGetBusWuReason[LINTRCV_39_DRIVERA_ARRAY_SIZE];
/* Variables used for LinIf module  */
/*******************************************************************************
**                       TestLinTrcv_39_DriverADefaultBehavior()              **
*******************************************************************************/
void TestLinTrcv_39_DriverADefaultBehavior(void)
{
  uint8 LucCount;  
  
  for(LucCount = 0x00; LucCount < LINTRCV_39_DRIVERA_ARRAY_SIZE; LucCount++)
  {
    LinTrcvA_GaaSetOpModeRet[LucCount] = E_OK;
    LinTrcvA_GaaGetOpModeRet[LucCount] = E_OK;
    LinTrcvA_GaaGetBusWuReasonRet[LucCount] = E_OK;

    LinTrcvA_GaaSetWakeupModeRet[LucCount] = E_OK;
    LinTrcvA_GaaGetCheckWakeupRet[LucCount] = E_OK;   
  }
  LinTrcvA_GucSetOpModeCount = 0x00;
  LinTrcvA_GucGetOpModeCount = 0x00;
  
  LinTrcvA_GucCheckWakeupCount = 0x00;
  LinTrcvA_GucSetWakeupModeCount = 0x00;
  LinTrcvA_GucSetWakeupModeCheckCount = 0x00;
  LinTrcvA_GucCheckWakeupCheckCount = 0x00;
  
  LinTrcvA_GucGetBusWuReasonCount = 0x00;
  LinTrcvA_GucSetOpModeCheckCount = 0x00;
  LinTrcvA_GucGetOpModeCheckCount = 0x00;
  LinTrcvA_GucGetBusWuReasChkCount = 0x00;
} /* End TestLinTrcvA_39_DriverADefaultBehavior() */

/*******************************************************************************
**                       LinTrcv_39_DriverA_CheckWakeup()                     **
*******************************************************************************/
Std_ReturnType LinTrcv_39_DriverA_CheckWakeup(uint8 LinNetwork)
{
  #ifndef TYPICAL_CONFIG
  LinTrcvA_GaaCheckWakeupNw[LinTrcvA_GucCheckWakeupCount] = LinNetwork;
  /* Increment count variable to handle multiple invocations */
  if(LinTrcvA_GucCheckWakeupCount != LINTRCV_39_DRIVERA_ARRAY_SIZE)
  {    
    LinTrcvA_GucCheckWakeupCount++;
  } 
  return(LinTrcvA_GaaGetCheckWakeupRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcvA_39_DriverA_CheckWakeup() */

/*******************************************************************************
**                       TestLinTrcv_39_DriverA_CheckWakeup()                 **
*******************************************************************************/
boolean TestLinTrcv_39_DriverA_CheckWakeup(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcvA_GucCheckWakeupCount == 0x01) && 
        (ExpLinNetwork == LinTrcvA_GaaCheckWakeupNw[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcvA_GucCheckWakeupCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcvA_GucCheckWakeupCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcvA_GucCheckWakeupCheckCount <= LinTrcvA_GucCheckWakeupCount) &&
        (ExpLinNetwork == LinTrcvA_GaaCheckWakeupNw[LinTrcvA_GucCheckWakeupCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcvA_GucCheckWakeupCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcvA_GucCheckWakeupCheckCount == LinTrcvA_GucCheckWakeupCount)
      {
        LinTrcvA_GucCheckWakeupCount = 0;
        LinTrcvA_GucCheckWakeupCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcvA_GucCheckWakeupCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcvA_GaaCheckWakeupNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcvA_CheckWakeup() */

/*******************************************************************************
**                       LinTrcvA_39_DriverA_SetWakeupMode()                   **
*******************************************************************************/
Std_ReturnType LinTrcv_39_DriverA_SetWakeupMode ( uint8 LinNetwork, 
LinTrcv_TrcvWakeupModeType TrcvWakupMode)
{
  #ifndef TYPICAL_CONFIG
  LinTrcvA_GaaSetWakeupModeNw[LinTrcvA_GucSetWakeupModeCount] = LinNetwork;
  LinTrcvA_GaaSetWakeupMode[LinTrcvA_GucSetWakeupModeCount] = TrcvWakupMode;  
  /* Increment count variable to handle multiple invocations */
  if(LinTrcvA_GucSetWakeupModeCount != LINTRCV_39_DRIVERA_ARRAY_SIZE)
  {    
    LinTrcvA_GucSetWakeupModeCount++;
  } 
  return(LinTrcvA_GaaSetWakeupModeRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcv_SetOpMode() */
/*******************************************************************************
**                       TestLinTrcv_39_DriverA_SetWakeupMode()               **
*******************************************************************************/
Std_ReturnType TestLinTrcv_39_DriverA_SetWakeupMode
  (App_DataValidateType LucDataValidate,
  uint8 ExpLinNetwork, LinTrcv_TrcvWakeupModeType ExpOpMode)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcvA_GucSetWakeupModeCount == 0x01) && 
        (ExpLinNetwork == LinTrcvA_GaaSetWakeupModeNw[0]) && 
        (ExpOpMode == LinTrcvA_GaaSetWakeupMode[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcvA_GucSetWakeupModeCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcvA_GucSetWakeupModeCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcvA_GucSetWakeupModeCheckCount <= LinTrcvA_GucSetWakeupModeCount) &&
        (ExpLinNetwork == LinTrcvA_GaaSetWakeupModeNw[LinTrcvA_GucSetWakeupModeCheckCount]) && 
        (ExpOpMode == 
        LinTrcvA_GaaSetWakeupMode[LinTrcvA_GucSetWakeupModeCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcvA_GucSetWakeupModeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcvA_GucSetWakeupModeCheckCount == LinTrcvA_GucSetWakeupModeCount)
      {
        LinTrcvA_GucSetWakeupModeCount = 0;
        LinTrcvA_GucSetWakeupModeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcvA_GucSetWakeupModeCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcvA_GaaSetWakeupModeNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcvA_SetWakeupMode() */

/*******************************************************************************
**                       LinTrcvA_39_DriverASetOpMode()                        **
*******************************************************************************/
Std_ReturnType LinTrcv_39_DriverA_SetOpMode(uint8 LinNetwork, LinTrcv_TrcvModeType OpMode)
{
  #ifndef TYPICAL_CONFIG
  LinTrcvA_GaaSetOpModeNw[LinTrcvA_GucSetOpModeCount] = LinNetwork;
  LinTrcvA_GaaSetOpMode[LinTrcvA_GucSetOpModeCount] = OpMode;  
  /* Increment count variable to handle multiple invocations */
  if(LinTrcvA_GucSetOpModeCount != LINTRCV_39_DRIVERA_ARRAY_SIZE)
  {    
    LinTrcvA_GucSetOpModeCount++;
  } 
  return(LinTrcvA_GaaSetOpModeRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcvA_39_DriverASetOpMode() */

/*******************************************************************************
**                       TestLinTrcvA_39_DriverASetOpMode()                    **
*******************************************************************************/
boolean TestLinTrcv_39_DriverASetOpMode(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork, LinTrcv_TrcvModeType ExpOpMode)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcvA_GucSetOpModeCount == 0x01) && 
        (ExpLinNetwork == LinTrcvA_GaaSetOpModeNw[0]) && 
        (ExpOpMode == LinTrcvA_GaaSetOpMode[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcvA_GucSetOpModeCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcvA_GucSetOpModeCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcvA_GucSetOpModeCheckCount <= LinTrcvA_GucSetOpModeCount) &&
        (ExpLinNetwork == LinTrcvA_GaaSetOpModeNw[LinTrcvA_GucSetOpModeCheckCount]) && 
        (ExpOpMode == 
        LinTrcvA_GaaSetOpMode[LinTrcvA_GucSetOpModeCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcvA_GucSetOpModeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcvA_GucSetOpModeCheckCount == LinTrcvA_GucSetOpModeCount)
      {
        LinTrcvA_GucSetOpModeCount = 0;
        LinTrcvA_GucSetOpModeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcvA_GucSetOpModeCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcvA_GaaSetOpModeNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcvA_39_DriverASetOpMode() */

/*******************************************************************************
**                       TestSetLinTrcvA_39_DriverASetOpModeRetVal()                     **
*******************************************************************************/
void TestSetLinTrcv_39_DriverASetOpModeRetVal(uint8 LinNetwork, Std_ReturnType RetVal)
{
  LinTrcvA_GaaSetOpModeRet[LinNetwork] = RetVal;
} /* End TestSetLinTrcv_39_DriverASetOpModeRetVal()  */

/*******************************************************************************
**                       LinTrcv_39_DriverAGetOpMode()                                  **
*******************************************************************************/
Std_ReturnType LinTrcv_39_DriverA_GetOpMode(uint8 LinNetwork, 
  LinTrcv_TrcvModeType* OpMode)
{
  #ifndef TYPICAL_CONFIG
  LinTrcvA_GaaGetOpModeNw[LinTrcvA_GucGetOpModeCount] = LinNetwork;
  *OpMode = LinTrcvA_GaaGetOpMode[LinNetwork];  
  /* Increment count variable to handle multiple invocations */
  if(LinTrcvA_GucGetOpModeCount != LINTRCV_39_DRIVERA_ARRAY_SIZE)
  {    
    LinTrcvA_GucGetOpModeCount++;
  } 
  return(LinTrcvA_GaaGetOpModeRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcvA_39_DriverAGetOpMode() */

/*******************************************************************************
**                       TestLinTrcv_39_DriverAGetOpMode()                              **
*******************************************************************************/
boolean TestLinTrcv_39_DriverAGetOpMode(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcvA_GucGetOpModeCount == 0x01) && 
        (ExpLinNetwork == LinTrcvA_GaaGetOpModeNw[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcvA_GucGetOpModeCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcvA_GucGetOpModeCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcvA_GucGetOpModeCheckCount <= LinTrcvA_GucGetOpModeCount) &&
        (ExpLinNetwork == LinTrcvA_GaaGetOpModeNw[LinTrcvA_GucGetOpModeCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcvA_GucGetOpModeCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcvA_GucGetOpModeCheckCount == LinTrcvA_GucGetOpModeCount)
      {
        LinTrcvA_GucGetOpModeCount = 0;
        LinTrcvA_GucGetOpModeCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcvA_GucGetOpModeCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcvA_GaaGetOpModeNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcvA_39_DriverAGetOpMode() */

/*******************************************************************************
**             TestSetLinTrcv_39_DriverAGetOpModeRetVal()                     **
*******************************************************************************/
void TestSetLinTrcv_39_DriverAGetOpModeRetVal(uint8 SetLinNetwork, 
  LinTrcv_TrcvModeType SetOpMode, Std_ReturnType RetVal)
{
  LinTrcvA_GaaGetOpMode[SetLinNetwork] = SetOpMode;
  LinTrcvA_GaaGetOpModeRet[SetLinNetwork] = RetVal;  
} /* End TestSetLinTrcvA_39_DriverAGetOpModeRetVal()  */
/*******************************************************************************
**             LinTrcv_39_DriverAGetBusWuReason()                             **
*******************************************************************************/
Std_ReturnType LinTrcv_39_DriverA_GetBusWuReason(uint8 LinNetwork, 
  LinTrcv_TrcvWakeupReasonType* Reason)
{
  #ifndef TYPICAL_CONFIG  
  LinTrcvA_GaaGetBusWuReasonNw[LinTrcvA_GucGetBusWuReasonCount] = LinNetwork;
  *Reason = LinTrcvA_GaaGetBusWuReason[LinNetwork];  
  /* Increment count variable to handle multiple invocations */
  if(LinTrcvA_GucGetBusWuReasonCount != LINTRCV_39_DRIVERA_ARRAY_SIZE)
  {    
    LinTrcvA_GucGetBusWuReasonCount++;
  } 
  return(LinTrcvA_GaaGetBusWuReasonRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcvA_39_DriverAGetBusWuReason() */

/*******************************************************************************
**                  TestLinTrcv_39_DriverAGetBusWuReason()                    **
*******************************************************************************/
boolean TestLinTrcv_39_DriverAGetBusWuReason(App_DataValidateType LucDataValidate,
  uint8 ExpLinNetwork)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinTrcvA_GucGetBusWuReasonCount == 0x01) && 
        (ExpLinNetwork == LinTrcvA_GaaGetBusWuReasonNw[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinTrcvA_GucGetBusWuReasonCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinTrcvA_GucGetBusWuReasonCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinTrcvA_GucGetBusWuReasChkCount <= LinTrcvA_GucGetBusWuReasonCount) &&
        (ExpLinNetwork == 
          LinTrcvA_GaaGetBusWuReasonNw[LinTrcvA_GucGetBusWuReasChkCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinTrcvA_GucGetBusWuReasChkCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinTrcvA_GucGetBusWuReasChkCount == LinTrcvA_GucGetBusWuReasonCount)
      {
        LinTrcvA_GucGetBusWuReasonCount = 0;
        LinTrcvA_GucGetBusWuReasChkCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinTrcvA_GucGetBusWuReasonCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinTrcvA_GaaGetBusWuReasonNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLinTrcvA_39_DriverAGetBusWuReason() */

/*******************************************************************************
**          TestSetLinTrcv_39_DriverAGetBusWuReasonRetVal()                   **
*******************************************************************************/
void TestSetLinTrcv_39_DriverAGetBusWuReasonRetVal(uint8 SetLinNetwork, 
  LinTrcv_TrcvWakeupReasonType SetReason, Std_ReturnType RetVal)
{
  LinTrcvA_GaaGetBusWuReason[SetLinNetwork] = SetReason;
  LinTrcvA_GaaGetBusWuReasonRet[SetLinNetwork] = RetVal;  
} /* End TestSetLinTrcvA_39_DriverAGetBusWuReasonRetVal()  */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
