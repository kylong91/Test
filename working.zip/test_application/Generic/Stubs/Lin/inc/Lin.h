/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE:  Lin.h                                                        **
**                                                                            **
**  TARGET    :  ALL                                                          **
**                                                                            **
**  PRODUCT   : AUTOSAR LIN Module                                            **
**                                                                            **
**  PURPOSE   : Provision of AUTOSAR LIN Types and extern datatypes           **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By          Description                            **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Creation of Lin.h module               **
*******************************************************************************/

#ifndef LIN_H
#define LIN_H

/*******************************************************************************
**                      Include Section                                      **
*******************************************************************************/
#include "TC_Generic.h"
#include "Lin_GeneralTypes.h"
#include "ComStack_Types.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define LIN_AR_RELEASE_MAJOR_VERSION         0x04
#define LIN_AR_RELEASE_MINOR_VERSION         0x00
#define LIN_AR_RELEASE_REVISION_VERSION      0x02

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define LIN_DATA_LENGTH                      0x08
/* Channel value should be less than LIN_ARRAY_SIZE */
#define LIN_ARRAY_SIZE                       0x05 

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
typedef uint8 Lin_ConfigType;

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
extern Std_ReturnType Lin_Wakeup(uint8 Channel);
extern Std_ReturnType Lin_SendFrame(uint8 Channel, Lin_PduType* PduInfoPtr);
extern Std_ReturnType Lin_GoToSleep(uint8 Channel);
extern Std_ReturnType Lin_GoToSleepInternal(uint8 Channel);
extern Lin_StatusType Lin_GetStatus(uint8 Channel, uint8 **Lin_SduPtr);

extern  Std_ReturnType Lin_CheckWakeup( uint8 LinNetwork );

extern  Std_ReturnType TestLin_CheckWakeup(
  App_DataValidateType LucDataValidate, uint8 LinNetwork );

extern void TestLin_DefaultBehavior(void);
extern boolean TestLin_Wakeup(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel);
extern boolean TestLin_SendFrame(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel, Lin_PduType *ExpPduInfoPtr);
extern boolean TestLin_GoToSleep(App_DataValidateType LucDataValidate,   
  uint8 ExpChannel);
extern boolean TestLin_GoToSleepInternal(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel);
extern boolean TestLin_GetStatus(App_DataValidateType LucDataValidate,   
  uint8 ExpChannel);
extern void TestSetLin_GetStatusRetVal(uint8 LucChannel, uint8 *LpSduData, 
  Lin_StatusType LddRetVal);
extern boolean LinTest_ValidateData(PduInfoType *LddExpPduInfo, 
  PduInfoType *LddActPduInfo);

extern void Lin_Init(const Lin_ConfigType* Config);
extern boolean TestLin_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo);

#endif  /* LIN_H */

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/

