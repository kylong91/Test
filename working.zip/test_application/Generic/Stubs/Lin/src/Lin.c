/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE:  Lin.c                                                        **
**                                                                            **
**  TARGET    :  ALL                                                          **
**                                                                            **
**  PRODUCT   : AUTOSAR LIN Module                                            **
**                                                                            **
**  PURPOSE   : This file is a stub for LIN Driver Component                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Creation of Lin.c module               **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Lin.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#ifdef LINIF_MODULE_ACTIVE
/* Variables used for LinIf module  */
Lin_StatusType Lin_GaaGetStatRet[LIN_ARRAY_SIZE];

Std_ReturnType Lin_GaaGetCheckWakeupRet[LIN_ARRAY_SIZE];

uint8 Lin_GucWakeupValCount;
uint8 Lin_GucWakeupCount;
uint8 Lin_GucSendFrameCount;
uint8 Lin_GucGoToSleepCount;
uint8 Lin_GucGoToSleepIntCount;
uint8 Lin_GucGetStatCount;
uint8 Lin_GucWakeupCheckCount;
uint8 Lin_GucSendFrameCheckCount;

uint8 Lin_GucCheckWakeupCheckCount;
uint8 Lin_GucCheckWakeupCount;

uint8 Lin_GucGoToSleepCheckCount;
uint8 Lin_GucGoToSleepIntCheckCount;
uint8 Lin_GucCheckGetStatCount;

uint8 Lin_GaaCheckWakeupNw[LIN_ARRAY_SIZE];

uint8 Lin_GaaWakeupChnl[LIN_ARRAY_SIZE];
uint8 Lin_GaaSendFrameChnl[LIN_ARRAY_SIZE];
uint8 Lin_GaaGoToSleepChnl[LIN_ARRAY_SIZE];
uint8 Lin_GaaGoToSleepIntChnl[LIN_ARRAY_SIZE];
uint8 Lin_GaaGetStatChnl[LIN_ARRAY_SIZE];
uint8 Lin_GaaSendFrameSduData[LIN_ARRAY_SIZE][LIN_DATA_LENGTH];
uint8 Lin_GaaGetStatSduData[LIN_ARRAY_SIZE][LIN_DATA_LENGTH];
Lin_FramePidType Lin_GaaSendFramePid[LIN_ARRAY_SIZE];
Lin_FrameCsModelType Lin_GaaSendFrameCs[LIN_ARRAY_SIZE];
Lin_FrameResponseType Lin_GaaSendFrameResp[LIN_ARRAY_SIZE];
Lin_FrameDlType Lin_GaaSendFrameDl[LIN_ARRAY_SIZE];
#endif
/* Variables used for LinIf module  */
#ifdef BSWM_MODULE_ACTIVE
uint8 Lin_GucInitSeqCnt;
uint8 Lin_GucInitCnt;
#endif

/*******************************************************************************
**                       TestLin_DefaultBehavior()                            **
*******************************************************************************/
#ifdef LINIF_MODULE_ACTIVE
void TestLin_DefaultBehavior(void)
{
  uint8 LucCount;
  uint8 LucDataCount;
  
  for(LucCount = 0x00; LucCount < LIN_ARRAY_SIZE ; LucCount++)
  {
    Lin_GaaGetStatRet[LucCount] = LIN_OPERATIONAL;
    Lin_GaaSendFrameChnl[LucCount] = 0xFF;
    Lin_GaaGoToSleepChnl[LucCount] = 0xFF;
    Lin_GaaGoToSleepIntChnl[LucCount] = 0xFF;
    Lin_GaaGetStatChnl[LucCount] = 0xFF;
    Lin_GaaSendFramePid[LucCount] = 0xFF;
    
    Lin_GaaGetCheckWakeupRet[LucCount] = E_OK;
    
    Lin_GaaSendFrameCs[LucCount] = LIN_ENHANCED_CS;
    Lin_GaaSendFrameResp[LucCount] = LIN_MASTER_RESPONSE;
    Lin_GaaSendFrameDl[LucCount] = 0xFF;
    for(LucDataCount = 0x00; LucDataCount < LIN_DATA_LENGTH ; LucDataCount++)
    {
      Lin_GaaSendFrameSduData[LucCount][LucDataCount] = 0x00;
      Lin_GaaGetStatSduData[LucCount][LucDataCount] = LucDataCount;
    }    
  }
  Lin_GucWakeupValCount = 0x00;
  Lin_GucWakeupCount = 0x00;
  Lin_GucSendFrameCount = 0x00;
  Lin_GucGoToSleepCount = 0x00;
  Lin_GucGoToSleepIntCount = 0x00;
  Lin_GucGetStatCount = 0x00;
  
  Lin_GucCheckWakeupCheckCount = 0x00;
  Lin_GucCheckWakeupCount = 0x00;
  
  Lin_GucWakeupCheckCount = 0x00;
  Lin_GucSendFrameCheckCount = 0x00;
  Lin_GucGoToSleepCheckCount = 0x00;
  Lin_GucGoToSleepIntCheckCount = 0x00;
  Lin_GucCheckGetStatCount = 0x00;  
} /* End TestLin_DefaultBehavior() */

/*******************************************************************************
**                       Lin_Wakeup()                                         **
*******************************************************************************/
Std_ReturnType Lin_Wakeup(uint8 Channel)
{
  #ifndef TYPICAL_CONFIG
  Lin_GaaWakeupChnl[Lin_GucWakeupCount] = Channel;
  /* Increment count variable to handle multiple invocations */
  if(Lin_GucWakeupCount != LIN_ARRAY_SIZE)
  {    
    Lin_GucWakeupCount++;
  }
  #endif
  return(E_OK);
} /* End Lin_Wakeup() */

/*******************************************************************************
**                       TestLin_Wakeup()                                     **
*******************************************************************************/
boolean TestLin_Wakeup(App_DataValidateType LucDataValidate, uint8 ExpChannel)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Lin_GucWakeupCount == 0x01) && 
        (ExpChannel == Lin_GaaWakeupChnl[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      Lin_GucWakeupCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Lin_GucWakeupCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((Lin_GucWakeupCheckCount <= Lin_GucWakeupCount) &&
        (ExpChannel == Lin_GaaWakeupChnl[Lin_GucWakeupCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Lin_GucWakeupCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Lin_GucWakeupCheckCount == Lin_GucWakeupCount)
      {
        Lin_GucWakeupCount = 0;
        Lin_GucWakeupCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < Lin_GucWakeupCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == Lin_GaaWakeupChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_Wakeup() */

/*******************************************************************************
**                       Lin_CheckWakeup()                                    **
*******************************************************************************/
Std_ReturnType Lin_CheckWakeup(uint8 LinNetwork )
{
  #ifndef TYPICAL_CONFIG
  Lin_GaaCheckWakeupNw[Lin_GucCheckWakeupCount] = LinNetwork;
  /* Increment count variable to handle multiple invocations */
  if(Lin_GucCheckWakeupCount != LIN_ARRAY_SIZE)
  {    
    Lin_GucCheckWakeupCount++;
  } 
  return(Lin_GaaGetCheckWakeupRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End Lin_CheckWakeup() */

/*******************************************************************************
**                       TestLin_CheckWakeup()                                **
*******************************************************************************/
boolean TestLin_CheckWakeup(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Lin_GucCheckWakeupCount == 0x01) && 
        (ExpLinNetwork == Lin_GaaCheckWakeupNw[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      Lin_GucCheckWakeupCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Lin_GucCheckWakeupCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((Lin_GucCheckWakeupCheckCount <= Lin_GucCheckWakeupCount) &&
        (ExpLinNetwork == Lin_GaaCheckWakeupNw[Lin_GucCheckWakeupCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Lin_GucCheckWakeupCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Lin_GucCheckWakeupCheckCount == Lin_GucCheckWakeupCount)
      {
        Lin_GucCheckWakeupCount = 0;
        Lin_GucCheckWakeupCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < Lin_GucCheckWakeupCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == Lin_GaaCheckWakeupNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_CheckWakeup() */

/*******************************************************************************
**                       Lin_SendFrame()                                      **
*******************************************************************************/
Std_ReturnType Lin_SendFrame(uint8 Channel, Lin_PduType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8 *LpSduPtr;
  Lin_GaaSendFrameChnl[Lin_GucSendFrameCount] = Channel;
  Lin_GaaSendFramePid[Lin_GucSendFrameCount] = PduInfoPtr->Pid;
  Lin_GaaSendFrameCs[Lin_GucSendFrameCount] = PduInfoPtr->Cs;
  Lin_GaaSendFrameResp[Lin_GucSendFrameCount] = PduInfoPtr->Drc;
  Lin_GaaSendFrameDl[Lin_GucSendFrameCount] = PduInfoPtr->Dl;
  /*Check whether Frame Length is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->Dl > LIN_DATA_LENGTH)
  {
    LucDataLength = LIN_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->Dl;
  }
  if(PduInfoPtr->Drc == LIN_MASTER_RESPONSE)
  {
    LpSduPtr = PduInfoPtr->SduPtr;
    /* Copy the actual data into global array from actual SduPtr */
    for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
    {
      Lin_GaaSendFrameSduData[Lin_GucSendFrameCount][LucDataIndex] = 
        *LpSduPtr;
      LpSduPtr++;
    }
  }
  /* Increment count variable to handle multiple invocations */
  if(Lin_GucSendFrameCount != LIN_ARRAY_SIZE)
  {    
    Lin_GucSendFrameCount++;
  }  
  #endif
  return(E_OK);
} /* End Lin_SendFrame() */

/*******************************************************************************
**                            TestLin_SendFrame()                             **
*******************************************************************************/
boolean TestLin_SendFrame(App_DataValidateType LucDataValidate,
  uint8 ExpChannel, Lin_PduType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  PduInfoType ExpPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Lin_GucSendFrameCount == 0x01) && 
        (ExpChannel == Lin_GaaSendFrameChnl[0]) && 
        (ExpPduInfoPtr->Pid == Lin_GaaSendFramePid[0]) && 
        (ExpPduInfoPtr->Cs == Lin_GaaSendFrameCs[0]) && 
        (ExpPduInfoPtr->Drc == Lin_GaaSendFrameResp[0]))
      {
        if(ExpPduInfoPtr->SduPtr != NULL_PTR)
        {
          ActPduInfo.SduLength = Lin_GaaSendFrameDl[0];
          ActPduInfo.SduDataPtr = &Lin_GaaSendFrameSduData[0][0];
          ExpPduInfo.SduLength = ExpPduInfoPtr->Dl;
          ExpPduInfo.SduDataPtr = ExpPduInfoPtr->SduPtr;

          /* Validate Data Length and Data */
          if(LinTest_ValidateData(&ExpPduInfo, &ActPduInfo))
          {
            LblRetValue = STEP_PASSED;
          }
        }
        else
        {
          LblRetValue = STEP_PASSED;
        }        
      }
      /* Reset API invocation Count after validating the API invocation */
      Lin_GucSendFrameCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Lin_GucSendFrameCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((Lin_GucSendFrameCheckCount <= Lin_GucSendFrameCount) &&
        (ExpChannel == Lin_GaaSendFrameChnl[Lin_GucSendFrameCheckCount])&& 
        (ExpPduInfoPtr->Pid == Lin_GaaSendFramePid[Lin_GucSendFrameCheckCount]) 
        && (ExpPduInfoPtr->Cs == Lin_GaaSendFrameCs[Lin_GucSendFrameCheckCount]) 
        && (ExpPduInfoPtr->Drc == 
        Lin_GaaSendFrameResp[Lin_GucSendFrameCheckCount]))
      {
        if(ExpPduInfoPtr->SduPtr != NULL_PTR)
        {
          ActPduInfo.SduLength = Lin_GaaSendFrameDl[Lin_GucSendFrameCheckCount];
          ActPduInfo.SduDataPtr = 
            &Lin_GaaSendFrameSduData[Lin_GucSendFrameCheckCount][0];
          ExpPduInfo.SduLength = ExpPduInfoPtr->Dl;
          ExpPduInfo.SduDataPtr = ExpPduInfoPtr->SduPtr;

          /* Validate Data Length and Data */
          if(LinTest_ValidateData(&ExpPduInfo, &ActPduInfo))
          {
            LblRetValue = STEP_PASSED;
          }
        }
        else
        {
          LblRetValue = STEP_PASSED;
        }
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Lin_GucSendFrameCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Lin_GucSendFrameCheckCount == Lin_GucSendFrameCount)
      {
        Lin_GucSendFrameCount = 0;
        Lin_GucSendFrameCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < Lin_GucSendFrameCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == Lin_GaaSendFrameChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_SendFrame() */

/*******************************************************************************
**                       Lin_GoToSleep()                                      **
*******************************************************************************/
Std_ReturnType Lin_GoToSleep(uint8 Channel)
{
  #ifndef TYPICAL_CONFIG
  Lin_GaaGoToSleepChnl[Lin_GucGoToSleepCount] = Channel;
  /* Increment count variable to handle multiple invocations */
  if(Lin_GucGoToSleepCount != LIN_ARRAY_SIZE)
  {    
    Lin_GucGoToSleepCount++;
  }
  #endif
  return(E_OK);
} /* End Lin_GoToSleep() */

/*******************************************************************************
**                       TestLin_GoToSleep()                                  **
*******************************************************************************/
boolean TestLin_GoToSleep(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Lin_GucGoToSleepCount == 0x01) && 
        (ExpChannel == Lin_GaaGoToSleepChnl[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      Lin_GucGoToSleepCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Lin_GucGoToSleepCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((Lin_GucGoToSleepCheckCount <= Lin_GucGoToSleepCount) &&
        (ExpChannel == Lin_GaaGoToSleepChnl[Lin_GucGoToSleepCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Lin_GucGoToSleepCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Lin_GucGoToSleepCheckCount == Lin_GucGoToSleepCount)
      {
        Lin_GucGoToSleepCount = 0;
        Lin_GucGoToSleepCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < Lin_GucGoToSleepCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == Lin_GaaGoToSleepChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_GoToSleep() */

/*******************************************************************************
**                       Lin_GoToSleepInternal()                              **
*******************************************************************************/
Std_ReturnType Lin_GoToSleepInternal(uint8 Channel)
{
  #ifndef TYPICAL_CONFIG
  Lin_GaaGoToSleepIntChnl[Lin_GucGoToSleepIntCount] = Channel;
  /* Increment count variable to handle multiple invocations */
  if(Lin_GucGoToSleepIntCount != LIN_ARRAY_SIZE)
  {    
    Lin_GucGoToSleepIntCount++;
  }
  #endif
  return(E_OK);
} /* End Lin_GoToSleepInternal() */

/*******************************************************************************
**                       TestLin_GoToSleepInternal()                          **
*******************************************************************************/
boolean TestLin_GoToSleepInternal(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Lin_GucGoToSleepIntCount == 0x01) && 
        (ExpChannel == Lin_GaaGoToSleepIntChnl[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      Lin_GucGoToSleepIntCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Lin_GucGoToSleepIntCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((Lin_GucGoToSleepIntCheckCount <= Lin_GucGoToSleepIntCount) &&
        (ExpChannel == Lin_GaaGoToSleepIntChnl[Lin_GucGoToSleepIntCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Lin_GucGoToSleepIntCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Lin_GucGoToSleepIntCheckCount == Lin_GucGoToSleepIntCount)
      {
        Lin_GucGoToSleepIntCount = 0;
        Lin_GucGoToSleepIntCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < Lin_GucGoToSleepIntCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == Lin_GaaGoToSleepIntChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_GoToSleepInternal() */

/*******************************************************************************
**                       Lin_GetStatus()                                      **
*******************************************************************************/
Lin_StatusType Lin_GetStatus(uint8 Channel, uint8 **Lin_SduPtr)
{
  #ifndef TYPICAL_CONFIG
  Lin_GaaGetStatChnl[Lin_GucGetStatCount] = Channel;
  /* Copy the actual data into actual SduPtr from global array  */
  *Lin_SduPtr = &Lin_GaaGetStatSduData[Channel][0];
  /* Increment count variable to handle multiple invocations */
  if(Lin_GucGetStatCount != LIN_ARRAY_SIZE)
  {    
    Lin_GucGetStatCount++;
  }
  return(Lin_GaaGetStatRet[Channel]);
  #else
  return(LIN_TX_OK);
  #endif
  
} /* End Lin_GetStatus() */

/*******************************************************************************
**                       TestLin_GetStatus()                                  **
*******************************************************************************/
boolean TestLin_GetStatus(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((Lin_GucGetStatCount == 0x01) && 
        (ExpChannel == Lin_GaaGetStatChnl[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      Lin_GucGetStatCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Lin_GucGetStatCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
    */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
      */
      for(LucIndex = 0; LucIndex < Lin_GucGetStatCount; LucIndex++)
      {
        /* Validate the PduId */
        if((ExpChannel == Lin_GaaGetStatChnl[LucIndex]))
        {
          LblRetValue = STEP_PASSED;
        /*
         * Break the loop by reseting LucIndex with max after validating the
         * API invocation
        */
         LucIndex = Lin_GucGetStatCount;
        } /* End if(ExpPduId == PduR_GucComActPduId[LucIndex]) */
      } /* End for(LucIndex = 0; LucIndex < Lin_GucGetStatCount; ...) */

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Lin_GucCheckGetStatCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Lin_GucCheckGetStatCount == Lin_GucGetStatCount)
      {
        Lin_GucGetStatCount = 0;
        Lin_GucCheckGetStatCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((Lin_GucCheckGetStatCount <= Lin_GucGetStatCount) &&
        (ExpChannel == Lin_GaaGetStatChnl[Lin_GucCheckGetStatCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Lin_GucCheckGetStatCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Lin_GucCheckGetStatCount == Lin_GucGetStatCount)
      {
        Lin_GucGetStatCount = 0;
        Lin_GucCheckGetStatCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < Lin_GucGetStatCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == Lin_GaaGetStatChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_GetStatus() */

/*******************************************************************************
**                     TestSetLin_GetStatusRetVal()                           **
*******************************************************************************/
void TestSetLin_GetStatusRetVal(uint8 LucChannel, uint8 *LpSduData, 
  Lin_StatusType LddRetVal)
{
  uint8 LucCount;
  Lin_GaaGetStatRet[LucChannel] = LddRetVal;
  if( LpSduData != NULL_PTR)
  {
    for(LucCount = 0 ; LucCount < LIN_DATA_LENGTH ; LucCount++)
    {
      Lin_GaaGetStatSduData[LucChannel][LucCount] = *LpSduData;
      LpSduData++;
    }
  }  
} /* End TestSetLin_GetStatusRetVal */

/*******************************************************************************
**                       LinTest_ValidateData()                               **
*******************************************************************************/
boolean LinTest_ValidateData(PduInfoType *LddExpPduInfo, 
  PduInfoType *LddActPduInfo)
{
  uint8 *LpActualDataPtr;
  uint8 *LpExpDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  /* Load the ExpPduInfo to local variables */
  LddSduCount = LddExpPduInfo->SduLength;
  LpExpDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  /* Check the Data length */
  if((LddExpPduInfo->SduLength <= LIN_DATA_LENGTH) &&
    (LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }
   /* Check the sdu data */
  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    if(*LpActualDataPtr != *LpExpDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualDataPtr++;
    LpExpDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* End LinTest_ValidateData() */
#endif
#ifdef BSWM_MODULE_ACTIVE
/*******************************************************************************
**                          Lin_Init()                                      **
*******************************************************************************/

void Lin_Init(const Lin_ConfigType* Config)
{
  UNUSED(Config);
	App_GucApiSeqCnt++;
	Lin_GucInitSeqCnt = App_GucApiSeqCnt;
	Lin_GucInitCnt++;
}/* End Lin_Init() */

/*******************************************************************************
**                           TestLin_Init()                                 **
*******************************************************************************/
boolean TestLin_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Lin_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Lin_GucInitCnt = 0;
      Lin_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(Lin_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Lin_GucInitCnt = 0;
      Lin_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLin_Init() */
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
