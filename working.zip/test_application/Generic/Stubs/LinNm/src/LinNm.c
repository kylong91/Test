/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: LinNm.c                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Nm Module                                             **
**                                                                            **
**  PURPOSE   : Provision of LinNm.c for testing applications                 **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"
#include "LinNm.h"
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
NetworkHandleType LinNm_GddPassStartChnlHandle;
NetworkHandleType LinNm_GddNwReqChnlHandle;
NetworkHandleType LinNm_GddNwRelChnlHandle;
NetworkHandleType LinNm_GddDisCommnChnlHandle;
NetworkHandleType LinNm_GddEnCommnChnlHandle;
NetworkHandleType LinNm_GddSetUserDataChnlHandle;
NetworkHandleType LinNm_GddGetUserDataChnlHandle;
NetworkHandleType LinNm_GddRptMsgReqChnlHandle;
NetworkHandleType LinNm_GddGetNodeIdChnlHandle;
NetworkHandleType LinNm_GddGetLocNodeIdChnlHandle;
NetworkHandleType LinNm_GddCheckRemSleepIndChnlHandle;
NetworkHandleType LinNm_GddGetStateIndChnlHandle;
NetworkHandleType LinNm_GddReqBusSynchChnlHandle;
NetworkHandleType LinNm_GddGetPduDataChnlHandle;
NetworkHandleType LinNm_GddReqExpulChnlHandle;
NetworkHandleType LinNm_GddSetSleepBitChnlHandle;
uint8 LinNm_GucSetUserData;
boolean * LinNm_GblRemoteSleepIndPtr;
Nm_StateType * LinNm_GddStatePtr; 
Nm_ModeType * LinNm_GddModePtr;
uint8 LinNm_GucPassiveStartCount;
uint8 LinNm_GucNetworkReqCount;
uint8 LinNm_GucNetworkRelCount;
uint8 LinNm_GucDisableCommnCount;
uint8 LinNm_GucEnableCommnCount;
uint8 LinNm_GucRptMsgReqCount;
uint8 LinNm_GucSetUserDataCount;
uint8 LinNm_GucGetUserDataCount;
uint8 LinNm_GucGetPduDataCount;
uint8 LinNm_GucGetNodeIdCount;
uint8 LinNm_GucGetLocalNodeIdCount;
uint8 LinNm_GucCheckRemSleepIndCount;
uint8 LinNm_GucGetStateCount;
uint8 LinNm_GucReqBusSynchCount;
uint8 LinNm_GucReqExpulCount;
uint8 LinNm_GucSetSleepBitCount;
uint8 LinNm_GddSetSleepBitRetVal;
Std_ReturnType LinNm_GddPassiveStartRetVal;
Std_ReturnType LinNm_GddNetworkReqRetVal;
Std_ReturnType LinNm_GddNetworkRelRetVal;
Std_ReturnType LinNm_GddDisableCommnRetVal;
Std_ReturnType LinNm_GddEnableCommnRetVal;
Std_ReturnType LinNm_GddRptMsgReqRetVal;
Std_ReturnType LinNm_GddSetUserDataRetVal;
Std_ReturnType LinNm_GddGetUserDataRetVal;
Std_ReturnType LinNm_GddGetPduDataRetVal;
Std_ReturnType LinNm_GddGetNodeIdRetVal;
Std_ReturnType LinNm_GddGetLocalNodeIdRetVal;
Std_ReturnType LinNm_GddCheckRemSleepIndRetVal;
Std_ReturnType LinNm_GddGetStateRetVal;
Std_ReturnType LinNm_GddReqBusSynchRetVal;
Std_ReturnType LinNm_GddReqExpulRetVal;
uint8 LinNm_GucGetUserData;
uint8 LinNm_GucPduData;
uint8 LinNm_GucNodeId;
uint8 LinNm_GucLocalNodeId;
boolean LinNm_GblRemSleep;
boolean LinNm_GblnmSleepReadyBit;
Nm_StateType LinNm_GddState;
Nm_ModeType LinNm_GddMode;
/******************************************************************************/
/*             LinNm_PassiveStartUp                                           */
/*****************************************************************************/
Std_ReturnType LinNm_PassiveStartUp(const NetworkHandleType nmChannelHandle)
{
  LinNm_GddPassStartChnlHandle = nmChannelHandle; 
  LinNm_GucPassiveStartCount++;
  return(LinNm_GddPassiveStartRetVal);
}
/*******************************************************************************
**                       TestLinNm_PassiveStartUp ()                          **
*******************************************************************************/
boolean TestLinNm_PassiveStartUp (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((LinNm_GucPassiveStartCount == 0x01)&&
        (ExpChannelHandle == LinNm_GddPassStartChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      LinNm_GucPassiveStartCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLinNm_PassiveStartUp() */
/*******************************************************************************
**                       TestLinNm_PassiveStartSetRetVal()                    **
*******************************************************************************/
void TestLinNm_PassiveStartSetRetVal(Std_ReturnType ReturnValue)
{
  LinNm_GddPassiveStartRetVal = ReturnValue;
} /* End TestLinNm_PassiveStartSetRetVal() */
/******************************************************************************/
/*                       LinNm_NetworkRequest()                               */
/******************************************************************************/
Std_ReturnType LinNm_NetworkRequest(const NetworkHandleType nmChannelHandle)
{
  LinNm_GddNwReqChnlHandle = nmChannelHandle; 
  LinNm_GucNetworkReqCount++;
  return(LinNm_GddNetworkReqRetVal);
}
/*******************************************************************************
**                       TestLinNm_NetworkRequest ()                          **
*******************************************************************************/
boolean TestLinNm_NetworkRequest (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((LinNm_GucNetworkReqCount == 0x01)&&
        (ExpChannelHandle == LinNm_GddNwReqChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      LinNm_GucNetworkReqCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLinNm_NetworkRequest() */
/*******************************************************************************
**                       TestLinNm_NetworkReqSetRetVal()                **
*******************************************************************************/
void TestLinNm_NetworkReqSetRetVal(Std_ReturnType ReturnValue)
{
  LinNm_GddNetworkReqRetVal = ReturnValue;
} /* End TestLinNm_NetworkReqSetRetVal() */
/******************************************************************************/
/*                       LinNm_NetworkRelease()                               */
/******************************************************************************/
Std_ReturnType LinNm_NetworkRelease(const NetworkHandleType nmChannelHandle)
{
  LinNm_GddNwRelChnlHandle = nmChannelHandle; 
  LinNm_GucNetworkRelCount++;
  return(LinNm_GddNetworkRelRetVal);
} /* End LinNm_NetworkRelease() */
/*******************************************************************************
**                       TestLinNm_NetworkRelease ()                          **
*******************************************************************************/
boolean TestLinNm_NetworkRelease (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((LinNm_GucNetworkRelCount == 0x01)&&
        (ExpChannelHandle == LinNm_GddNwRelChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      LinNm_GucNetworkRelCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinNm_GucNetworkRelCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLinNm_NetworkRelease() */
/*******************************************************************************
**                       TestLinNm_NetworkRelSetRetVal()                      **
*******************************************************************************/
void TestLinNm_NetworkRelSetRetVal(Std_ReturnType ReturnValue)
{
  LinNm_GddNetworkRelRetVal = ReturnValue;
} /* End TestLinNm_NetworkRelSetRetVal() */
/******************************************************************************/
/*                       LinNm_DisableCommunication()                         */
/******************************************************************************/
Std_ReturnType LinNm_DisableCommunication(const NetworkHandleType 
  nmChannelHandle)
{
  LinNm_GddDisCommnChnlHandle = nmChannelHandle; 
  LinNm_GucDisableCommnCount++;
  return(LinNm_GddDisableCommnRetVal);
} /* End LinNm_DisableCommunication() */
/*******************************************************************************
**                       TestLinNm_DisableCommunication()                     **
*******************************************************************************/
boolean TestLinNm_DisableCommunication (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((LinNm_GucDisableCommnCount == 0x01)&&
        (ExpChannelHandle == LinNm_GddDisCommnChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      LinNm_GucDisableCommnCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLinNm_DisableCommunication() */
/*******************************************************************************
**                       TestLinNm_DisableCommnSetRetVal()                    **
*******************************************************************************/
void TestLinNm_DisableCommnSetRetVal(Std_ReturnType ReturnValue)
{
  LinNm_GddDisableCommnRetVal = ReturnValue;
} /* End TestLinNm_DisableCommnReturnValSetUp() */
/******************************************************************************/
/*                       LinNm_EnableCommunication()                          */
/******************************************************************************/
Std_ReturnType LinNm_EnableCommunication(const NetworkHandleType nmChannelHandle)
{
  LinNm_GddEnCommnChnlHandle = nmChannelHandle;
  LinNm_GucEnableCommnCount++;
  return(LinNm_GddEnableCommnRetVal);
} /* End LinNm_EnableCommunication() */
/*******************************************************************************
**                       TestLinNm_EnableCommunication()                     **
*******************************************************************************/
boolean TestLinNm_EnableCommunication (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((LinNm_GucEnableCommnCount == 0x01)&&
        (ExpChannelHandle == LinNm_GddEnCommnChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      LinNm_GucEnableCommnCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLinNm_EnableCommunication() */
/*******************************************************************************
**                       TestLinNm_EnableCommnSetRetVal()                     **
*******************************************************************************/
void TestLinNm_EnableCommnSetRetVal(Std_ReturnType ReturnValue)
{
  LinNm_GddEnableCommnRetVal = ReturnValue;
} /* End TestLinNm_EnableCommnSetRetVal() */
/******************************************************************************/
/*                       LinNm_RepeatMessageRequest()                         */
/******************************************************************************/
Std_ReturnType LinNm_RepeatMessageRequest(const NetworkHandleType 
  nmChannelHandle)
{
  LinNm_GddRptMsgReqChnlHandle = nmChannelHandle;
  LinNm_GucRptMsgReqCount++;
  return(LinNm_GddRptMsgReqRetVal);
} /* End LinNm_RepeatMessageRequest() */
/*******************************************************************************
**                       TestLinNm_RepeatMessageRequest()                     **
*******************************************************************************/
boolean TestLinNm_RepeatMessageRequest(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((LinNm_GucRptMsgReqCount == 0x01)&&
        (ExpChannelHandle == LinNm_GddRptMsgReqChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      LinNm_GucRptMsgReqCount = 0;
      break;
      default:
      {
        break;
      }
    }
    
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLinNm_RepeatMessageRequest() */
/*******************************************************************************
**                       TestLinNm_RptMsgReqSetRetVal()                       **
*******************************************************************************/
void TestLinNm_RptMsgReqSetRetVal(Std_ReturnType ReturnValue)
{
  LinNm_GddRptMsgReqRetVal = ReturnValue;
} /* End TestLinNm_RptMsgReqSetRetVal() */
/******************************************************************************/
/*                       LinNm_RequestBusSynchronization()                    */
/******************************************************************************/
Std_ReturnType LinNm_RequestBusSynchronization(const NetworkHandleType 
  nmChannelHandle)
{
  LinNm_GddReqBusSynchChnlHandle = nmChannelHandle; 
  LinNm_GucReqBusSynchCount++;
  return(LinNm_GddReqBusSynchRetVal);
} /* End LinNm_RequestBusSynchronization() */
/*******************************************************************************
**                       TestLinNm_RequestBusSynchronization()                **
*******************************************************************************/
boolean TestLinNm_RequestBusSynchronization(App_DataValidateType 
  LucDataValidate, const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((LinNm_GucReqBusSynchCount == 0x01)&&
        (ExpChannelHandle == LinNm_GddReqBusSynchChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      LinNm_GucReqBusSynchCount = 0;
      break;
      default:
      {
        break;
      }
    }
   
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLinNm_RequestBusSynchronization() */
/*******************************************************************************
**                       TestLinNm_ReqBusSynchSetRetVal()                     **
*******************************************************************************/
void TestLinNm_ReqBusSynchSetRetVal(Std_ReturnType ReturnValue)
{
  LinNm_GddReqBusSynchRetVal = ReturnValue;
}

/******************************************************************************/
/*                         LinNm_SetSleepReadyBit()                           */
/******************************************************************************/
Std_ReturnType LinNm_SetSleepReadyBit(const NetworkHandleType
  nmChannelHandle, const boolean nmSleepReadyBit)
{
  LinNm_GddSetSleepBitChnlHandle = nmChannelHandle;
  LinNm_GblnmSleepReadyBit = nmSleepReadyBit;
  LinNm_GucSetSleepBitCount++;
  return(LinNm_GddSetSleepBitRetVal);
} /* End LinNm_SetSleepReadyBit() */
/*******************************************************************************
**                       TestLinNm_SetSleepReadyBit()                        **
*******************************************************************************/
boolean TestLinNm_SetSleepReadyBit(App_DataValidateType
  LucDataValidate, const NetworkHandleType ExpChannelHandle,
  const boolean ExpnmSleepReadyBit)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((LinNm_GucSetSleepBitCount == 0x01)&&
        (ExpChannelHandle == LinNm_GddSetSleepBitChnlHandle)&& 
        (ExpnmSleepReadyBit == LinNm_GblnmSleepReadyBit))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      LinNm_GucSetSleepBitCount = 0;
      break;
    }
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinNm_GucSetSleepBitCount == 0x00)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }    
    default:
    {
      break;
    }     

  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLinNm_SetSleepReadyBit() */
/******************************************************************************/
/*                       LinNm_SetUserData()                                  */
/******************************************************************************/
Std_ReturnType LinNm_SetUserData(const NetworkHandleType nmChannelHandle, 
  const uint8 * const nmUserDataPtr)
{
  LinNm_GddSetUserDataChnlHandle = nmChannelHandle; 
  LinNm_GucSetUserData = *nmUserDataPtr;
  LinNm_GucSetUserDataCount++;
  return(LinNm_GddSetUserDataRetVal);
}  /* End LinNm_SetUserData() */

/*******************************************************************************
**                       TestLinNm_SetUserData()                     **
*******************************************************************************/
boolean TestLinNm_SetUserData (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle, const uint8 * const ExpUserDataPtr)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((LinNm_GucSetUserDataCount == 0x01)&&
        (ExpChannelHandle == LinNm_GddSetUserDataChnlHandle) && 
        (*ExpUserDataPtr == LinNm_GucSetUserData))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      LinNm_GucSetUserDataCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLinNm_SetUserData() */

/******************************************************************************/
/*                       LinNm_GetUserData()                                  */
/******************************************************************************/
Std_ReturnType LinNm_GetUserData(const NetworkHandleType nmChannelHandle, 
  uint8 * const nmUserDataPtr)
{
  LinNm_GddGetUserDataChnlHandle = nmChannelHandle; 
  *nmUserDataPtr = LinNm_GucGetUserData;
  LinNm_GucGetUserDataCount++;
  return(LinNm_GddGetUserDataRetVal);
} /* End LinNm_GetUserData() */
/*******************************************************************************
**                       TestLinNm_GetUserData()                              **
*******************************************************************************/
boolean TestLinNm_GetUserData(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((LinNm_GucGetUserDataCount == 0x01)&&
        (ExpChannelHandle == LinNm_GddGetUserDataChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      LinNm_GucGetUserDataCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLinNm_GetUserData() */
/*******************************************************************************
**                       TestLinNm_GetUserDataSetVal()                        **
*******************************************************************************/
void TestLinNm_GetUserDataSetVal(Std_ReturnType RetVal, uint8 UserData)
{
  LinNm_GddGetUserDataRetVal = RetVal;
  LinNm_GucGetUserData = UserData;
} /* End TestLinNm_GetUserDataSetVal() */
/******************************************************************************/
/*                       LinNm_GetPduData()                                  */
/******************************************************************************/
Std_ReturnType LinNm_GetPduData(const NetworkHandleType nmChannelHandle,
  uint8 *const nmPduData)
{
  LinNm_GddGetPduDataChnlHandle = nmChannelHandle; 
  *nmPduData = LinNm_GucPduData;
  LinNm_GucGetPduDataCount++;
  
  return(LinNm_GddGetPduDataRetVal);
} /* End LinNm_GetPduData() */
/*******************************************************************************
**                       TestLinNm_GetPduData()                              **
*******************************************************************************/
boolean TestLinNm_GetPduData (App_DataValidateType LucDataValidate, const 
  NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((LinNm_GucGetPduDataCount == 0x01)&&
        (ExpChannelHandle == LinNm_GddGetPduDataChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      LinNm_GucGetPduDataCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLinNm_GetUserData() */
/*******************************************************************************
**                       TestLinNm_GetPduDataSetVal()                         **
*******************************************************************************/
void TestLinNm_GetPduDataSetVal(Std_ReturnType RetVal, uint8 PduData)
{
  LinNm_GddGetPduDataRetVal = RetVal;
  LinNm_GucPduData = PduData;
} /* End TestLinNm_GetPduDataSetVal() */
/******************************************************************************/
/*                       LinNm_GetNodeIdentifier()                            */
/******************************************************************************/
Std_ReturnType LinNm_GetNodeIdentifier(const NetworkHandleType nmChannelHandle,
  uint8 * const nmNodeIdPtr)
{
  LinNm_GddGetNodeIdChnlHandle = nmChannelHandle; 
  *nmNodeIdPtr = LinNm_GucNodeId;
  LinNm_GucGetNodeIdCount++;
  return(LinNm_GddGetNodeIdRetVal);
} /* End LinNm_GetNodeIdentifier() */
/*******************************************************************************
**                       TestLinNm_GetNodeIdentifier()                        **
*******************************************************************************/
boolean TestLinNm_GetNodeIdentifier(App_DataValidateType LucDataValidate,const 
  NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((LinNm_GucGetNodeIdCount == 0x01)&&
        (ExpChannelHandle == LinNm_GddGetNodeIdChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      LinNm_GucGetNodeIdCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLinNm_GetNodeIdentifier() */
/*******************************************************************************
**                       TestLinNm_GetNodeIdDataSetVal()                      **
*******************************************************************************/
void TestLinNm_GetNodeIdDataSetVal(Std_ReturnType RetVal, uint8 NodeId)
{
  LinNm_GddGetNodeIdRetVal = RetVal;
  LinNm_GucNodeId = NodeId;
} /* End TestLinNm_GetNodeIdDataSetUp() */
/******************************************************************************/
/*                       LinNm_GetLocalNodeIdentifier()                       */
/******************************************************************************/
Std_ReturnType LinNm_GetLocalNodeIdentifier(const NetworkHandleType nmChannelHandle,
  uint8 * const nmNodeIdPtr)
{
  LinNm_GddGetLocNodeIdChnlHandle = nmChannelHandle; 
  *nmNodeIdPtr = LinNm_GucLocalNodeId;
  LinNm_GucGetLocalNodeIdCount++;
  return(LinNm_GddGetLocalNodeIdRetVal);
} /* End LinNm_GetLocalNodeIdentifier() */
/*******************************************************************************
**                       TestLinNm_GetLocalNodeIdentifier()                   **
*******************************************************************************/
boolean TestLinNm_GetLocalNodeIdentifier(App_DataValidateType LucDataValidate,const 
  NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((LinNm_GucGetLocalNodeIdCount == 0x01)&&
        (ExpChannelHandle == LinNm_GddGetLocNodeIdChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      LinNm_GucGetLocalNodeIdCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLinNm_GetLocalNodeIdentifier() */

/*******************************************************************************
**                       TestLinNm_GetLocalNodeIdDataSetVal()                 **
*******************************************************************************/
void TestLinNm_GetLocalNodeIdDataSetVal(Std_ReturnType RetVal, uint8 NodeId)
{
  LinNm_GddGetLocalNodeIdRetVal = RetVal;
  LinNm_GucLocalNodeId = NodeId;
} /* End TestLinNm_GetLocalNodeIdDataSetVal() */

/*******************************************************************************
**             LinNm_CheckRemoteSleepIndication()                             **
*******************************************************************************/
Std_ReturnType LinNm_CheckRemoteSleepIndication(const NetworkHandleType 
  nmChannelHandle, boolean * const nmRemoteSleepIndPtr)
{
  LinNm_GddCheckRemSleepIndChnlHandle = nmChannelHandle; 
  *nmRemoteSleepIndPtr = LinNm_GblRemSleep;
  LinNm_GucCheckRemSleepIndCount++;
  return(LinNm_GddCheckRemSleepIndRetVal);
} /* End LinNm_CheckRemoteSleepIndication() */

/*******************************************************************************
**                       TestLinNm_CheckRemoteSleepIndication()               **
*******************************************************************************/
boolean TestLinNm_CheckRemoteSleepIndication(App_DataValidateType 
  LucDataValidate,const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((LinNm_GucCheckRemSleepIndCount == 0x01)&&
        (ExpChannelHandle == LinNm_GddCheckRemSleepIndChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      LinNm_GucCheckRemSleepIndCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLinNm_CheckRemoteSleepIndication() */

/*******************************************************************************
**                       TestLinNm_CheckRemSleepIndDataSetVal()             **
*******************************************************************************/
void TestLinNm_CheckRemSleepIndDataSetVal(Std_ReturnType RetVal, 
  boolean SleepInd)
{
  LinNm_GddCheckRemSleepIndRetVal = RetVal;
  LinNm_GblRemSleep = SleepInd;
} /* End TestLinNm_CheckRemSleepIndDataSetVal() */

/*******************************************************************************
**              Function Name :LinNm_GetState()                               **
*******************************************************************************/
Std_ReturnType LinNm_GetState(const NetworkHandleType nmChannelHandle, 
  Nm_StateType * const nmStatePtr, Nm_ModeType * const nmModePtr)
{
  LinNm_GddGetStateIndChnlHandle = nmChannelHandle; 
  *nmStatePtr = LinNm_GddState;
  *nmModePtr = LinNm_GddMode;
  LinNm_GucGetStateCount++;
  return(LinNm_GddGetStateRetVal);
} /* End LinNm_GetState() */
/*******************************************************************************
**                       TestLinNm_GetState()                              **
*******************************************************************************/
boolean TestLinNm_GetState(App_DataValidateType LucDataValidate, 
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((LinNm_GucGetStateCount == 0x01)&&
        (ExpChannelHandle == LinNm_GddGetStateIndChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      LinNm_GucGetStateCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLinNm_GetState() */
/*******************************************************************************
**                       TestLinNm_GetStateDataSetVal()                       **
*******************************************************************************/
void TestLinNm_GetStateDataSetVal(Std_ReturnType RetVal, Nm_StateType State, 
  Nm_ModeType Mode)
{
  LinNm_GddGetStateRetVal = RetVal;
  LinNm_GddMode = Mode;
  LinNm_GddState = State;
} /* End TestLinNm_GetStateDataSetVal() */
/*******************************************************************************
**                       TestLinNm_ModeSetUp()                                **
*******************************************************************************/
void TestLinNm_ModeSetUp(Nm_ModeType Mode)
{
  LinNm_GddMode = Mode;
} /* End TestLinNm_ModeSetUp() */
/*******************************************************************************
**                       LinNm_RequestExpulsion()                             **
*******************************************************************************/
Std_ReturnType LinNm_RequestExpulsion(const NetworkHandleType nmChannelHandle)
{
  LinNm_GddReqExpulChnlHandle = nmChannelHandle;
  LinNm_GucReqExpulCount++;  
  return(LinNm_GddReqExpulRetVal);
} /* End LinNm_RequestExpulsion() */
/*******************************************************************************
**                       TestLinNm_RequestExpulsion()                         **
*******************************************************************************/
boolean TestLinNm_RequestExpulsion(App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle)
{
  boolean  LblStepResult;
  LblStepResult = STEP_FAILED;
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {

      if((LinNm_GucReqExpulCount == 0x01)&&
        (ExpChannelHandle == LinNm_GddReqExpulChnlHandle))
        {
          LblStepResult = STEP_PASSED;
        }
      /* Reset API invocation Count after validating the API invocation */
      LinNm_GucReqExpulCount = 0;
      break;
    }
    default:
    {
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestLinNm_RequestExpulsion() */
/*******************************************************************************
**                       TestLinNm_ReqExpulSetRetVal()                        **
*******************************************************************************/
void TestLinNm_ReqExpulReturnValSetUp(Std_ReturnType ReturnValue)
{
  LinNm_GddReqExpulRetVal = ReturnValue;
} /* End TestLinNm_ReqExpulReturnValSetUp() */

/*******************************************************************************
**                       TestLinNm_DefaultBehavior()                          **
*******************************************************************************/
void TestLinNm_DefaultBehavior(void)
{
  LinNm_GddMode = NM_MODE_BUS_SLEEP;
  LinNm_GddState = NM_STATE_UNINIT;
  LinNm_GucPassiveStartCount = 0;
  LinNm_GucNetworkReqCount = 0;
  LinNm_GucNetworkRelCount = 0;  
  LinNm_GucDisableCommnCount = 0;
  LinNm_GucEnableCommnCount = 0;
  LinNm_GucRptMsgReqCount = 0;
  LinNm_GucSetUserDataCount = 0;
  LinNm_GucGetUserDataCount = 0;
  LinNm_GucGetPduDataCount = 0;
  LinNm_GucGetNodeIdCount = 0;
  LinNm_GucGetLocalNodeIdCount = 0;
  LinNm_GucCheckRemSleepIndCount = 0;
  LinNm_GucGetStateCount = 0;
  LinNm_GucReqBusSynchCount = 0;
  LinNm_GucReqExpulCount = 0;
  LinNm_GddPassiveStartRetVal = E_OK;
  LinNm_GddNetworkReqRetVal = E_OK;
  LinNm_GddNetworkRelRetVal = E_OK;
  LinNm_GddDisableCommnRetVal = E_OK;
  LinNm_GddEnableCommnRetVal = E_OK;
  LinNm_GddRptMsgReqRetVal = E_OK;
  LinNm_GddSetUserDataRetVal = E_OK;
  LinNm_GddGetUserDataRetVal = E_OK;
  LinNm_GddGetPduDataRetVal = E_OK;
  LinNm_GddGetNodeIdRetVal = E_OK;
  LinNm_GddGetLocalNodeIdRetVal = E_OK;
  LinNm_GddCheckRemSleepIndRetVal = E_OK;
  LinNm_GddGetStateRetVal = E_OK;
  LinNm_GddReqBusSynchRetVal = E_OK;
  LinNm_GddReqExpulRetVal = E_OK;
} /* End TestLinNm_DefaultBehavior() */

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
