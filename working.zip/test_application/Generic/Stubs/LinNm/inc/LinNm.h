/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: LinNm.h                                                       **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Nm Module                                             **
**                                                                            **
**  PURPOSE   : Provision of header for LinNm.c                               **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By          Description                            **
********************************************************************************
** 1.0.0     22-Nov-2012   Kiranmai    Initial version                        **
*******************************************************************************/

#ifndef LINNM_H
#define LINNM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h" 
#include "NmStack_Types.h"
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/* AUTOSAR Specification Version Information */
#define LINNM_AR_RELEASE_MAJOR_VERSION  4
#define LINNM_AR_RELEASE_MINOR_VERSION  0
#define LINNM_AR_RELEASE_REVISION_VERSION  2

#define LINNM_SW_MAJOR_VERSION  1
#define LINNM_SW_MINOR_VERSION  0
/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/*******************************************************************************
**                      Function Prototype                                    **
*******************************************************************************/
extern Std_ReturnType LinNm_PassiveStartUp(const NetworkHandleType 
  nmChannelHandle); 

extern  boolean TestLinNm_PassiveStartUp(App_DataValidateType LucDataValidate, 
  const NetworkHandleType LddExpChannelHandle); 
  
extern void TestLinNm_PassiveStartSetRetVal(Std_ReturnType ReturnValue);
                                 
extern Std_ReturnType LinNm_NetworkRequest(const NetworkHandleType 
  nmChannelHandle);

extern  boolean TestLinNm_NetworkRequest(App_DataValidateType LucDataValidate, 
  const NetworkHandleType LddExpChannelHandle); 
  
extern void TestLinNm_NetworkReqSetRetVal(Std_ReturnType ReturnValue);  

extern Std_ReturnType LinNm_NetworkRelease(const NetworkHandleType 
  nmChannelHandle);

extern  boolean TestLinNm_NetworkRelease(App_DataValidateType LucDataValidate, 
const NetworkHandleType LddExpChannelHandle);

extern void TestLinNm_NetworkRelSetRetVal(Std_ReturnType ReturnValue);

extern Std_ReturnType LinNm_DisableCommunication(const NetworkHandleType 
  nmChannelHandle);

extern  boolean TestLinNm_DisableCommunication(App_DataValidateType 
  LucDataValidate, const NetworkHandleType LddExpChannelHandle);
  
extern void TestLinNm_DisableCommnSetRetVal(Std_ReturnType ReturnValue);
                                   
extern Std_ReturnType LinNm_EnableCommunication(const NetworkHandleType 
  nmChannelHandle);

extern  boolean TestLinNm_EnableCommunication (App_DataValidateType 
  LucDataValidate, const NetworkHandleType LddExpChannelHandle);
  
extern void TestLinNm_EnableCommnSetRetVal(Std_ReturnType ReturnValue);

extern Std_ReturnType LinNm_RepeatMessageRequest(const NetworkHandleType 
  nmChannelHandle);
                                   
extern  boolean TestLinNm_RepeatMessageRequest(App_DataValidateType 
  LucDataValidate, const NetworkHandleType LddExpChannelHandle); 
  
extern void TestLinNm_RptMsgReqSetRetVal(Std_ReturnType ReturnValue);

extern Std_ReturnType LinNm_SetUserData(const NetworkHandleType nmChannelHandle, 
  const uint8 * const nmUserDataPtr);

extern  boolean TestLinNm_SetUserData (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle, const uint8 * const ExpUserDataPtr);

extern Std_ReturnType LinNm_GetUserData(const NetworkHandleType nmChannelHandle,
uint8 * const nmUserDataPtr);

extern  boolean TestLinNm_GetUserData (App_DataValidateType LucDataValidate,
  const NetworkHandleType ExpChannelHandle);
  
extern void TestLinNm_GetUserDataSetVal(Std_ReturnType RetVal, uint8 UserData);
                         
extern Std_ReturnType LinNm_GetPduData(const NetworkHandleType nmChannelHandle,
  uint8 * const nmPduData);

extern  boolean TestLinNm_GetPduData (App_DataValidateType LucDataValidate, 
  const NetworkHandleType ExpChannelHandle);
  
extern void TestLinNm_GetPduDataSetVal(Std_ReturnType RetVal, uint8 PduData);
           
extern Std_ReturnType LinNm_GetNodeIdentifier(const NetworkHandleType 
  nmChannelHandle, uint8 * const nmNodeIdPtr);

extern  boolean TestLinNm_GetNodeIdentifier(App_DataValidateType 
  LucDataValidate, const NetworkHandleType ExpChannelHandle);
  
extern void TestLinNm_GetNodeIdDataSetVal(Std_ReturnType RetVal, uint8 NodeId);
         
extern Std_ReturnType LinNm_GetLocalNodeIdentifier(const NetworkHandleType 
  nmChannelHandle,uint8 * const nmNodeIdPtr);
         
extern  boolean TestLinNm_GetLocalNodeIdentifier(App_DataValidateType 
  LucDataValidate, const NetworkHandleType ExpChannelHandle);
  
extern void TestLinNm_GetLocalNodeIdDataSetVal(Std_ReturnType RetVal, uint8 NodeId);
         
extern Std_ReturnType LinNm_CheckRemoteSleepIndication(const NetworkHandleType 
nmChannelHandle, boolean * const nmRemoteSleepIndPtr);

extern  boolean TestLinNm_CheckRemoteSleepIndication(App_DataValidateType 
  LucDataValidate, const NetworkHandleType ExpChannelHandle);
  
extern void TestLinNm_CheckRemSleepIndDataSetVal(Std_ReturnType RetVal, 
  boolean SleepInd);
                          
extern Std_ReturnType LinNm_GetState(const NetworkHandleType nmChannelHandle,
  Nm_StateType * const nmStatePtr,Nm_ModeType * const nmModePtr);
 
extern  boolean TestLinNm_GetState(App_DataValidateType LucDataValidate, 
  const NetworkHandleType ExpChannelHandle);
  
extern void TestLinNm_GetStateDataSetVal(Std_ReturnType RetVal, Nm_StateType State, 
  Nm_ModeType Mode);

extern Std_ReturnType LinNm_RequestBusSynchronization
  (const NetworkHandleType nmChannelHandle);

extern boolean TestLinNm_RequestBusSynchronization (App_DataValidateType 
  LucDataValidate, const NetworkHandleType ExpChannelHandle);
  
extern void TestLinNm_ReqBusSynchSetRetVal(Std_ReturnType ReturnValue);

extern void TestLinNm_ModeSetUp(Nm_ModeType Mode);
 
extern void TestLinNm_DefaultBehavior(void);

extern boolean TestLinNm_SetSleepReadyBit(App_DataValidateType
  LucDataValidate, const NetworkHandleType ExpChannelHandle, 
  const boolean ExpnmSleepReadyBit);

extern Std_ReturnType LinNm_SetSleepReadyBit(const NetworkHandleType
  nmChannelHandle, const boolean nmSleepReadyBit);
#endif /* LINNM_H */

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
