/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE:  Lin.c                                                        **
**                                                                            **
**  TARGET    :  ALL                                                          **
**                                                                            **
**  PRODUCT   : AUTOSAR LIN Module                                            **
**                                                                            **
**  PURPOSE   : This file is a stub for LIN Driver Component                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     03-Jan-2012   NKD    Creation of Lin.c module                    **
** 4.0.1     12-Jan-2012   RPS    Updated for LinIf                           **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Lin_39_DriverA.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#ifdef LINIF_MODULE_ACTIVE
/* Variables used for LinIf module  */
Lin_StatusType LinDrvA_GaaGetStatRet[LIN_39_DRIVERA_ARRAY_SIZE];

Std_ReturnType LinDrvA_GaaGetCheckWakeupRet[LIN_39_DRIVERA_ARRAY_SIZE];

uint8 LinDrvA_GucWakeupValCount;
uint8 LinDrvA_GucWakeupCount;
uint8 LinDrvA_GucSendFrameCount;
uint8 LinDrvA_GucGoToSleepCount;
uint8 LinDrvA_GucGoToSleepIntCount;
uint8 LinDrvA_GucGetStatCount;
uint8 LinDrvA_GucWakeupCheckCount;
uint8 LinDrvA_GucSendFrameCheckCount;
uint8 LinDrvA_GucGoToSleepCheckCount;

uint8 LinDrvA_GucCheckWakeupCheckCount;
uint8 LinDrvA_GucCheckWakeupCount;

uint8 LinDrvA_GucGoToSleepIntCheckCount;
uint8 LinDrvA_GucCheckGetStatCount;

uint8 LinDrvA_GaaCheckWakeupNw[LIN_39_DRIVERA_ARRAY_SIZE];

uint8 LinDrvA_GaaWakeupChnl[LIN_39_DRIVERA_ARRAY_SIZE];
uint8 LinDrvA_GaaSendFrameChnl[LIN_39_DRIVERA_ARRAY_SIZE];
uint8 LinDrvA_GaaGoToSleepChnl[LIN_39_DRIVERA_ARRAY_SIZE];
uint8 LinDrvA_GaaGoToSleepIntChnl[LIN_39_DRIVERA_ARRAY_SIZE];
uint8 LinDrvA_GaaGetStatChnl[LIN_39_DRIVERA_ARRAY_SIZE];
uint8 LinDrvA_GaaSendFrameSduData[LIN_39_DRIVERA_ARRAY_SIZE][LIN_39_DRIVERA_DATA_LENGTH];
uint8 LinDrvA_GaaGetStatSduData[LIN_39_DRIVERA_ARRAY_SIZE][LIN_39_DRIVERA_DATA_LENGTH];
Lin_FramePidType LinDrvA_GaaSendFramePid[LIN_39_DRIVERA_ARRAY_SIZE];
Lin_FrameCsModelType LinDrvA_GaaSendFrameCs[LIN_39_DRIVERA_ARRAY_SIZE];
Lin_FrameResponseType LinDrvA_GaaSendFrameResp[LIN_39_DRIVERA_ARRAY_SIZE];
Lin_FrameDlType LinDrvA_GaaSendFrameDl[LIN_39_DRIVERA_ARRAY_SIZE];
/* Variables used for LinIf module  */


/*******************************************************************************
**                       TestLin_39_DriverADefaultBehavior()                  **
*******************************************************************************/
void TestLin_39_DriverADefaultBehavior(void)
{
  uint8 LucCount;
  uint8 LucDataCount;
  
  for(LucCount = 0x00; LucCount < LIN_39_DRIVERA_ARRAY_SIZE ; LucCount++)
  {
    LinDrvA_GaaGetStatRet[LucCount] = LIN_OPERATIONAL;
    LinDrvA_GaaSendFrameChnl[LucCount] = 0xFF;
    LinDrvA_GaaGoToSleepChnl[LucCount] = 0xFF;
    LinDrvA_GaaGoToSleepIntChnl[LucCount] = 0xFF;
    
    LinDrvA_GaaGetCheckWakeupRet[LucCount] = E_OK;
    
    LinDrvA_GaaGetStatChnl[LucCount] = 0xFF;
    LinDrvA_GaaSendFramePid[LucCount] = 0xFF;
    LinDrvA_GaaSendFrameCs[LucCount] = LIN_ENHANCED_CS;
    LinDrvA_GaaSendFrameResp[LucCount] = LIN_MASTER_RESPONSE;
    LinDrvA_GaaSendFrameDl[LucCount] = 0xFF;
    for(LucDataCount = 0x00; LucDataCount < LIN_39_DRIVERA_DATA_LENGTH ; 
      LucDataCount++)
    {
      LinDrvA_GaaSendFrameSduData[LucCount][LucDataCount] = 0x00;
      LinDrvA_GaaGetStatSduData[LucCount][LucDataCount] = LucDataCount;
    }    
  }
  LinDrvA_GucWakeupValCount = 0x00;
  LinDrvA_GucWakeupCount = 0x00;
  LinDrvA_GucSendFrameCount = 0x00;
  LinDrvA_GucGoToSleepCount = 0x00;
  LinDrvA_GucGoToSleepIntCount = 0x00;
  LinDrvA_GucGetStatCount = 0x00;
  
  LinDrvA_GucCheckWakeupCheckCount = 0x00;
  LinDrvA_GucCheckWakeupCount = 0x00;
  
  LinDrvA_GucWakeupCheckCount = 0x00;
  LinDrvA_GucSendFrameCheckCount = 0x00;
  LinDrvA_GucGoToSleepCheckCount = 0x00;
  LinDrvA_GucGoToSleepIntCheckCount = 0x00;
  LinDrvA_GucCheckGetStatCount = 0x00;  
} /* End TestLin_39_DriverADefaultBehavior() */

/*******************************************************************************
**                       Lin_39_DriverAWakeupValidation()                     **
*******************************************************************************/
void Lin_39_DriverA_WakeupValidation(void)
{
  #ifndef TYPICAL_CONFIG
  /* Increment count variable to handle multiple invocations */
  if(LinDrvA_GucWakeupValCount != LIN_39_DRIVERA_ARRAY_SIZE)
  {    
    LinDrvA_GucWakeupValCount++;
  } 
  #endif
} /* End Lin_39_DriverAWakeupValidation() */

/*******************************************************************************
**                       TestLin_39_DriverAWakeupValidation()                 **
*******************************************************************************/
boolean TestLin_39_DriverAWakeupValidation(App_DataValidateType LucDataValidate)
{
  boolean LblRetValue;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if(LinDrvA_GucWakeupValCount == 0x01)
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvA_GucWakeupValCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvA_GucWakeupValCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverAWakeupValidation() */

/*******************************************************************************
**                       Lin_39_DriverAWakeup()                               **
*******************************************************************************/
Std_ReturnType Lin_39_DriverA_Wakeup(uint8 Channel)
{
  #ifndef TYPICAL_CONFIG
  LinDrvA_GaaWakeupChnl[LinDrvA_GucWakeupCount] = Channel;
  /* Increment count variable to handle multiple invocations */
  if(LinDrvA_GucWakeupCount != LIN_39_DRIVERA_ARRAY_SIZE)
  {    
    LinDrvA_GucWakeupCount++;
  }
  #endif
  return(E_OK);
} /* End Lin_39_DriverAWakeup() */

/*******************************************************************************
**                       TestLin_39_DriverA_Wakeup()                          **
*******************************************************************************/
boolean TestLin_39_DriverA_Wakeup(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinDrvA_GucWakeupCount == 0x01) && 
        (ExpChannel == LinDrvA_GaaWakeupChnl[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvA_GucWakeupCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvA_GucWakeupCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinDrvA_GucWakeupCheckCount <= LinDrvA_GucWakeupCount) &&
        (ExpChannel == LinDrvA_GaaWakeupChnl[LinDrvA_GucWakeupCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinDrvA_GucWakeupCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinDrvA_GucWakeupCheckCount == LinDrvA_GucWakeupCount)
      {
        LinDrvA_GucWakeupCount = 0;
        LinDrvA_GucWakeupCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinDrvA_GucWakeupCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == LinDrvA_GaaWakeupChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverAWakeup() */


/*******************************************************************************
**                       Lin_39_DriverA_CheckWakeup()                         **
*******************************************************************************/
Std_ReturnType Lin_39_DriverA_CheckWakeup(uint8 LinNetwork )
{
  #ifndef TYPICAL_CONFIG
  LinDrvA_GaaCheckWakeupNw[LinDrvA_GucCheckWakeupCount] = LinNetwork;
  /* Increment count variable to handle multiple invocations */
  if(LinDrvA_GucCheckWakeupCount != LIN_39_DRIVERA_ARRAY_SIZE)
  {    
    LinDrvA_GucCheckWakeupCount++;
  } 
  return(LinDrvA_GaaGetCheckWakeupRet[LinNetwork]);
  #else
  return(E_OK);
  #endif
} /* End LinTrcv_CheckWakeup() */

/*******************************************************************************
**                       TestLin_39_DriverA_CheckWakeup()                     **
*******************************************************************************/
boolean TestLin_39_DriverA_CheckWakeup(App_DataValidateType LucDataValidate, 
  uint8 ExpLinNetwork)
{
  boolean LblRetValue;
  uint8 LucIndex;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinDrvA_GucCheckWakeupCount == 0x01) && 
        (ExpLinNetwork == LinDrvA_GaaCheckWakeupNw[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvA_GucCheckWakeupCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvA_GucCheckWakeupCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinDrvA_GucCheckWakeupCheckCount <= LinDrvA_GucCheckWakeupCount) &&
        (ExpLinNetwork == LinDrvA_GaaCheckWakeupNw[LinDrvA_GucCheckWakeupCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinDrvA_GucCheckWakeupCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinDrvA_GucCheckWakeupCheckCount == LinDrvA_GucCheckWakeupCount)
      {
        LinDrvA_GucCheckWakeupCount = 0;
        LinDrvA_GucCheckWakeupCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinDrvA_GucCheckWakeupCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpLinNetwork == LinDrvA_GaaCheckWakeupNw[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverA_CheckWakeup() */

/*******************************************************************************
**                       Lin_39_DriverASendFrame()                            **
*******************************************************************************/
Std_ReturnType Lin_39_DriverA_SendFrame(uint8 Channel, Lin_PduType *PduInfoPtr)
{
  #ifndef TYPICAL_CONFIG
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8 *LpSduPtr;
  LinDrvA_GaaSendFrameChnl[LinDrvA_GucSendFrameCount] = Channel;
  LinDrvA_GaaSendFramePid[LinDrvA_GucSendFrameCount] = PduInfoPtr->Pid;
  LinDrvA_GaaSendFrameCs[LinDrvA_GucSendFrameCount] = PduInfoPtr->Cs;
  LinDrvA_GaaSendFrameResp[LinDrvA_GucSendFrameCount] = PduInfoPtr->Drc;
  LinDrvA_GaaSendFrameDl[LinDrvA_GucSendFrameCount] = PduInfoPtr->Dl;
  /*Check whether Frame Length is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->Dl > LIN_39_DRIVERA_DATA_LENGTH)
  {
    LucDataLength = LIN_39_DRIVERA_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->Dl;
  }
  if(PduInfoPtr->Drc == LIN_MASTER_RESPONSE)
  {
    LpSduPtr = PduInfoPtr->SduPtr;
    /* Copy the actual data into global array from actual SduPtr */
    for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
    {
      LinDrvA_GaaSendFrameSduData[LinDrvA_GucSendFrameCount][LucDataIndex] = 
        *LpSduPtr;
      LpSduPtr++;
    }
  }
  /* Increment count variable to handle multiple invocations */
  if(LinDrvA_GucSendFrameCount != LIN_39_DRIVERA_ARRAY_SIZE)
  {    
    LinDrvA_GucSendFrameCount++;
  }  
  #endif
  return(E_OK);
} /* End Lin_39_DriverASendFrame() */

/*******************************************************************************
**                            TestLin_39_DriverASendFrame()                   **
*******************************************************************************/
boolean TestLin_39_DriverASendFrame(App_DataValidateType LucDataValidate,
  uint8 ExpChannel, Lin_PduType *ExpPduInfoPtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  PduInfoType ExpPduInfo;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinDrvA_GucSendFrameCount == 0x01) && 
        (ExpChannel == LinDrvA_GaaSendFrameChnl[0]) && 
        (ExpPduInfoPtr->Pid == LinDrvA_GaaSendFramePid[0]) && 
        (ExpPduInfoPtr->Cs == LinDrvA_GaaSendFrameCs[0]) && 
        (ExpPduInfoPtr->Drc == LinDrvA_GaaSendFrameResp[0]))
      {
        if(ExpPduInfoPtr->SduPtr != NULL_PTR)
        {
          ActPduInfo.SduLength = LinDrvA_GaaSendFrameDl[0];
          ActPduInfo.SduDataPtr = &LinDrvA_GaaSendFrameSduData[0][0];
          ExpPduInfo.SduLength = ExpPduInfoPtr->Dl;
          ExpPduInfo.SduDataPtr = ExpPduInfoPtr->SduPtr;

        /* Validate Data Length and Data */
        if(LinDriverATest_ValidateData(&ExpPduInfo, &ActPduInfo))
          {
            LblRetValue = STEP_PASSED;
          }
        }
        else
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvA_GucSendFrameCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvA_GucSendFrameCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinDrvA_GucSendFrameCheckCount <= LinDrvA_GucSendFrameCount) &&
        (ExpChannel == LinDrvA_GaaSendFrameChnl[LinDrvA_GucSendFrameCheckCount])&& 
        (ExpPduInfoPtr->Pid == LinDrvA_GaaSendFramePid[LinDrvA_GucSendFrameCheckCount]) 
        && (ExpPduInfoPtr->Cs == LinDrvA_GaaSendFrameCs[LinDrvA_GucSendFrameCheckCount]) 
        && (ExpPduInfoPtr->Drc == 
        LinDrvA_GaaSendFrameResp[LinDrvA_GucSendFrameCheckCount]))
      {
        if(ExpPduInfoPtr->SduPtr != NULL_PTR)
        {
        ActPduInfo.SduLength = LinDrvA_GaaSendFrameDl[LinDrvA_GucSendFrameCheckCount];
        ActPduInfo.SduDataPtr = 
          &LinDrvA_GaaSendFrameSduData[LinDrvA_GucSendFrameCheckCount][0];
        ExpPduInfo.SduLength = ExpPduInfoPtr->Dl;
        ExpPduInfo.SduDataPtr = ExpPduInfoPtr->SduPtr;

        /* Validate Data Length and Data */
        if(LinDriverATest_ValidateData(&ExpPduInfo, &ActPduInfo))
          {
            LblRetValue = STEP_PASSED;
          }
        }
        else
        {
          LblRetValue = STEP_PASSED;
        }
      }

      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinDrvA_GucSendFrameCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinDrvA_GucSendFrameCheckCount == LinDrvA_GucSendFrameCount)
      {
        LinDrvA_GucSendFrameCount = 0;
        LinDrvA_GucSendFrameCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinDrvA_GucSendFrameCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == LinDrvA_GaaSendFrameChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverASendFrame() */

/*******************************************************************************
**                       Lin_39_DriverAGoToSleep()                            **
*******************************************************************************/
Std_ReturnType Lin_39_DriverA_GoToSleep(uint8 Channel)
{
  #ifndef TYPICAL_CONFIG
  LinDrvA_GaaGoToSleepChnl[LinDrvA_GucGoToSleepCount] = Channel;
  /* Increment count variable to handle multiple invocations */
  if(LinDrvA_GucGoToSleepCount != LIN_39_DRIVERA_ARRAY_SIZE)
  {    
    LinDrvA_GucGoToSleepCount++;
  }
  #endif
  return(E_OK);
} /* End Lin_39_DriverAGoToSleep() */

/*******************************************************************************
**                       TestLin_39_DriverAGoToSleep()                        **
*******************************************************************************/
boolean TestLin_39_DriverAGoToSleep(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinDrvA_GucGoToSleepCount == 0x01) && 
        (ExpChannel == LinDrvA_GaaGoToSleepChnl[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvA_GucGoToSleepCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvA_GucGoToSleepCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinDrvA_GucGoToSleepCheckCount <= LinDrvA_GucGoToSleepCount) &&
        (ExpChannel == LinDrvA_GaaGoToSleepChnl[LinDrvA_GucGoToSleepCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinDrvA_GucGoToSleepCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinDrvA_GucGoToSleepCheckCount == LinDrvA_GucGoToSleepCount)
      {
        LinDrvA_GucGoToSleepCount = 0;
        LinDrvA_GucGoToSleepCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinDrvA_GucGoToSleepCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == LinDrvA_GaaGoToSleepChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverAGoToSleep() */

/*******************************************************************************
**                       Lin_39_DriverAGoToSleepInternal()                    **
*******************************************************************************/
Std_ReturnType Lin_39_DriverA_GoToSleepInternal(uint8 Channel)
{
  #ifndef TYPICAL_CONFIG
  LinDrvA_GaaGoToSleepIntChnl[LinDrvA_GucGoToSleepIntCount] = Channel;
  /* Increment count variable to handle multiple invocations */
  if(LinDrvA_GucGoToSleepIntCount != LIN_39_DRIVERA_ARRAY_SIZE)
  {    
    LinDrvA_GucGoToSleepIntCount++;
  }
  #endif
  return(E_OK);
} /* End Lin_39_DriverAGoToSleepInternal() */

/*******************************************************************************
**                       TestLin_39_DriverAGoToSleepInternal()                **
*******************************************************************************/
boolean TestLin_39_DriverAGoToSleepInternal(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinDrvA_GucGoToSleepIntCount == 0x01) && 
        (ExpChannel == LinDrvA_GaaGoToSleepIntChnl[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvA_GucGoToSleepIntCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvA_GucGoToSleepIntCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinDrvA_GucGoToSleepIntCheckCount <= LinDrvA_GucGoToSleepIntCount) &&
        (ExpChannel == LinDrvA_GaaGoToSleepIntChnl[LinDrvA_GucGoToSleepIntCheckCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinDrvA_GucGoToSleepIntCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinDrvA_GucGoToSleepIntCheckCount == LinDrvA_GucGoToSleepIntCount)
      {
        LinDrvA_GucGoToSleepIntCount = 0;
        LinDrvA_GucGoToSleepIntCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinDrvA_GucGoToSleepIntCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == LinDrvA_GaaGoToSleepIntChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverAGoToSleepInternal() */

/*******************************************************************************
**                       Lin_39_DriverAGetStatus()                            **
*******************************************************************************/
Lin_StatusType Lin_39_DriverA_GetStatus(uint8 Channel, uint8 **Lin_SduPtr)
{
  #ifndef TYPICAL_CONFIG
  LinDrvA_GaaGetStatChnl[LinDrvA_GucGetStatCount] = Channel;
  /* Copy the actual data into actual SduPtr from global array  */
  *Lin_SduPtr = &LinDrvA_GaaGetStatSduData[Channel][0];
  /* Increment count variable to handle multiple invocations */
  if(LinDrvA_GucGetStatCount != LIN_39_DRIVERA_ARRAY_SIZE)
  {    
    LinDrvA_GucGetStatCount++;
  }
  return(LinDrvA_GaaGetStatRet[Channel]);
  #else
  return(LIN_TX_OK);
  #endif
  
} /* End Lin_39_DriverAGetStatus() */

/*******************************************************************************
**                       TestLin_39_DriverAGetStatus()                        **
*******************************************************************************/
boolean TestLin_39_DriverAGetStatus(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel)
{
  boolean LblRetValue;
  uint8 LucIndex;

  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count and Id */
      if((LinDrvA_GucGetStatCount == 0x01) && 
        (ExpChannel == LinDrvA_GaaGetStatChnl[0]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /* Reset API invocation Count after validating the API invocation */
      LinDrvA_GucGetStatCount = 0;      
      break;
    } /* End case S_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(LinDrvA_GucGetStatCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    case M_VALIDATE_SEQ:
    {

      /* Validating the Sequnce count and ID */
      if((LinDrvA_GucCheckGetStatCount <= LinDrvA_GucGetStatCount) &&
        (ExpChannel == LinDrvA_GaaGetStatChnl[LinDrvA_GucCheckGetStatCount]))
      {
        LblRetValue = STEP_PASSED;        
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      LinDrvA_GucCheckGetStatCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(LinDrvA_GucCheckGetStatCount == LinDrvA_GucGetStatCount)
      {
        LinDrvA_GucGetStatCount = 0;
        LinDrvA_GucCheckGetStatCount = 0;
      }
      break;
    } /* End case M_VALIDATE_SEQ: */
    
    case M_NOT_INVOKED:
    {
      LblRetValue = STEP_PASSED;
      for(LucIndex = 0; (LucIndex < LinDrvA_GucGetStatCount) &&
        (LblRetValue == STEP_PASSED); LucIndex++)
      {
        if(ExpChannel == LinDrvA_GaaGetStatChnl[LucIndex])
        {
          LblRetValue = STEP_FAILED;
        }
      }
      break;
    }
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestLin_39_DriverAGetStatus() */

/*******************************************************************************
**                     TestSetLin_39_DriverAGetStatusRetVal()                 **
*******************************************************************************/
void TestSetLin_39_DriverAGetStatusRetVal(uint8 LucChannel, uint8 *LpSduData, 
  Lin_StatusType LddRetVal)
{
  uint8 LucCount;
  LinDrvA_GaaGetStatRet[LucChannel] = LddRetVal;
  if( LpSduData != NULL_PTR)
  {
    for(LucCount = 0 ; LucCount < LIN_39_DRIVERA_DATA_LENGTH ; LucCount++)
    {
      LinDrvA_GaaGetStatSduData[LucChannel][LucCount] = *LpSduData;
      LpSduData++;
    }
  }  
} /* End TestSetLin_39_DriverAGetStatusRetVal */

/*******************************************************************************
**                       LinDriverATest_ValidateData()                               **
*******************************************************************************/
boolean LinDriverATest_ValidateData(PduInfoType *LddExpPduInfo, 
  PduInfoType *LddActPduInfo)
{
  uint8 *LpActualDataPtr;
  uint8 *LpExpDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  /* Load the ExpPduInfo to local variables */
  LddSduCount = LddExpPduInfo->SduLength;
  LpExpDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  /* Check the Data length */
  if((LddExpPduInfo->SduLength <= LIN_39_DRIVERA_DATA_LENGTH) &&
    (LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }
   /* Check the sdu data */
  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    if(*LpActualDataPtr != *LpExpDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualDataPtr++;
    LpExpDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* End LinDriverATest_ValidateData() */
#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
