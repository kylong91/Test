/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE:  Lin_39_DriverA.h                                             **
**                                                                            **
**  TARGET    :  ALL                                                          **
**                                                                            **
**  PRODUCT   : AUTOSAR LIN Module                                            **
**                                                                            **
**  PURPOSE   : Provision of AUTOSAR LIN Types and extern datatypes           **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     03-Jan-2012   NKD    Creation of Lin_39_DriverA.h module         **
*******************************************************************************/

#ifndef LIN_39_DRIVERA_H
#define LIN_39_DRIVERA_H

/*******************************************************************************
**                      Include Section                                      **
*******************************************************************************/
#include "TC_Generic.h"
#include "Lin_GeneralTypes.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define LIN_39_DRIVERA_AR_RELEASE_MAJOR_VERSION         0x04
#define LIN_39_DRIVERA_AR_RELEASE_MINOR_VERSION         0x00
#define LIN_39_DRIVERA_AR_RELEASE_REVISION_VERSION      0x02

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define LIN_39_DRIVERA_DATA_LENGTH                      0x08
/* Channel value should be less than LIN_ARRAY_SIZE */
#define LIN_39_DRIVERA_ARRAY_SIZE                       0x04 

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern void Lin_39_DriverA_WakeupValidation(void);
extern Std_ReturnType Lin_39_DriverA_Wakeup(uint8 Channel);
extern Std_ReturnType Lin_39_DriverA_SendFrame(uint8 Channel, 
  Lin_PduType* PduInfoPtr);
extern Std_ReturnType Lin_39_DriverA_GoToSleep(uint8 Channel);
extern Std_ReturnType Lin_39_DriverA_GoToSleepInternal(uint8 Channel);
extern Lin_StatusType Lin_39_DriverA_GetStatus(uint8 Channel, 
  uint8 **Lin_SduPtr);

extern  Std_ReturnType Lin_39_DriverA_CheckWakeup( uint8 LinNetwork );

extern  Std_ReturnType TestLin_39_DriverA_CheckWakeup(
  App_DataValidateType LucDataValidate, uint8 LinNetwork );
  
extern void TestLin_39_DriverADefaultBehavior(void);
extern boolean TestLin_39_DriverAWakeupValidation(App_DataValidateType LucDataValidate);
extern boolean TestLin_39_DriverA_Wakeup(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel);
extern boolean TestLin_39_DriverASendFrame(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel, Lin_PduType *ExpPduInfoPtr);
extern boolean TestLin_39_DriverAGoToSleep(App_DataValidateType LucDataValidate,   
  uint8 ExpChannel);
extern boolean TestLin_39_DriverAGoToSleepInternal(App_DataValidateType LucDataValidate, 
  uint8 ExpChannel);
extern boolean TestLin_39_DriverAGetStatus(App_DataValidateType LucDataValidate,   
  uint8 ExpChannel);
extern void TestSetLin_39_DriverAGetStatusRetVal(uint8 LucChannel, 
  uint8 *LpSduData, Lin_StatusType LddRetVal);
extern boolean LinDriverATest_ValidateData(PduInfoType *LddExpPduInfo, 
  PduInfoType *LddActPduInfo);


#endif  /* LIN_39_DRIVERA_H */

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
