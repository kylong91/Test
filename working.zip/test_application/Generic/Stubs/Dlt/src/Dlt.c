/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Dlt.c                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Dlt Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Dlt Stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     03-Jan-2012   MKK    Creation of Dlt.c module                    **
** 4.0.1     05-Apr-2012   RPS    Updated for Dem                             **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#ifdef DEM_MODULE_ACTIVE
#include "Dem.h"
#endif
#include "Dlt.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#ifdef DET_MODULE_ACTIVE
uint8 Dlt_GucReportCount;
uint8 Dlt_GucReportCheckCount;
uint16 Dlt_GusModuleId[DLT_ARRAY_SIZE];
uint8 Dlt_GucInstanceId[DLT_ARRAY_SIZE];
uint16 Dlt_GusApiId[DLT_ARRAY_SIZE];
uint8 Dlt_GucErrorId[DLT_ARRAY_SIZE];
#endif

#ifdef DEM_MODULE_ACTIVE
Dem_EventIdType Dem_GddDltEventId;
Dem_EventStatusExtendedType Dem_GucDltEventStatusOld;
Dem_EventStatusExtendedType Dem_GucDltEventStatusNew;
uint8 Dem_GucDltTriggerCounter;
#endif

#ifdef DET_MODULE_ACTIVE
/*******************************************************************************
**                       Dlt_DetForwardErrorTrace()                           **
*******************************************************************************/
void Dlt_DetForwardErrorTrace(uint16 ModuleId, uint8 InstanceId, 
  uint8 ApiId, uint8 ErrorId)
{
  #ifndef TYPICAL_CONFIG
  /*
   * Load actual ModuleId, InstanceId, ApiId and ErrorId into Global variables
   */
  Dlt_GusModuleId[Dlt_GucReportCount] = ModuleId;
  Dlt_GucInstanceId[Dlt_GucReportCount] = InstanceId;
  Dlt_GusApiId[Dlt_GucReportCount] = ApiId;
  Dlt_GucErrorId[Dlt_GucReportCount] = ErrorId;
   
  /* Increment count variable to handle multiple invocations */
  Dlt_GucReportCount++;
  #endif /* TYPICAL_CONFIG */
} /* End Dlt_DetForwardErrorTrace() */

/*******************************************************************************
**                        Dlt_DetForwardErrorTrace()                          **
*******************************************************************************/
boolean TestDlt_DetForwardErrorTrace(App_DataValidateType LucDataValidate,
  uint16 ExpModuleId, uint8 ExpInstanceId,uint16 ExpApiId, uint8 ExpErrorId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ModuleId, InstanceId, ApiId and ErrorId */
      if((Dlt_GucReportCount == 0x01) &&
        (Dlt_GusModuleId[0] == ExpModuleId) &&
        (Dlt_GucInstanceId[0] == ExpInstanceId) &&
        (Dlt_GusApiId[0] == ExpApiId) && (Dlt_GucErrorId[0] == ExpErrorId))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Dlt_GucReportCount = 0;
      Dlt_GucReportCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Dlt_GucReportCount; LucIndex++)
      {
        /* Validate Network and Current State */
        if((Dlt_GusModuleId[LucIndex] == ExpModuleId) &&
          (Dlt_GucInstanceId[LucIndex] == ExpInstanceId) &&
          (Dlt_GusApiId[LucIndex] == ExpApiId) &&
          (Dlt_GucErrorId[LucIndex] == ExpErrorId))
        {
          LblStepResult = STEP_PASSED;          
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Dlt_GucReportCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Dlt_GucReportCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Dlt_GucReportCheckCount == Dlt_GucReportCount)
      {
        Dlt_GucReportCount = 0;
        Dlt_GucReportCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dlt_GucReportCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestDlt_DetForwardErrorTrace() */
#endif

#ifdef DEM_MODULE_ACTIVE
/*******************************************************************************
**                       Dlt_DemTriggerOnEventStatus()                        **
*******************************************************************************/
void Dlt_DemTriggerOnEventStatus(Dem_EventIdType EventId, 
Dem_EventStatusExtendedType EventStatusOld,
Dem_EventStatusExtendedType EventStatusNew)
{
  #ifndef TYPICAL_CONFIG
  Dem_GddDltEventId = EventId;
  Dem_GucDltEventStatusOld = EventStatusOld;
  Dem_GucDltEventStatusNew = EventStatusNew;
  #endif
  Dem_GucDltTriggerCounter++;

}/* End Dlt_DemTriggerOnEventStatus() */
/*******************************************************************************
**                        TestDlt_DemTriggerOnEventStatus()                   **
*******************************************************************************/
boolean TestDlt_DemTriggerOnEventStatus(App_DataValidateType LucDataValidate,
Dem_EventIdType ExpEventId, Dem_EventStatusExtendedType ExpEventStatusOld, 
Dem_EventStatusExtendedType ExpEventStatusNew)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Dem_GucDltTriggerCounter == 0x01) && (Dem_GddDltEventId == ExpEventId) 
        && (Dem_GucDltEventStatusOld == ExpEventStatusOld) 
        && (Dem_GucDltEventStatusNew == ExpEventStatusNew)) 
      {
        LblStepResult = APP_TC_PASSED;
      }
      Dem_GucDltTriggerCounter = 0;
      break;
    }
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Dem_GucDltTriggerCounter == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestDlt_DemTriggerOnEventStatus() */
#endif
/*******************************************************************************
**              TestDet_DefaultBehavior()                                     **
*******************************************************************************/
void TestDlt_DefaultBehavior(void)
{
  #ifdef DET_MODULE_ACTIVE
  Dlt_GucReportCount = 0;
  Dlt_GucReportCheckCount = 0;
  #endif
  
  #ifdef DEM_MODULE_ACTIVE
  Dem_GucDltTriggerCounter = 0;
  #endif
}

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
