/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Dlt.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Dlt Stub                                              **
**                                                                            **
**  PURPOSE   : Declaration of Dlt Stub functions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 4.0.0     03-Jan-2012   MKK    Initial version                             **
** 4.0.1     05-Apr-2012   RPS    Updated for Dem                             **
*******************************************************************************/

#ifndef DLT_H
#define DLT_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define DLT_AR_RELEASE_MAJOR_VERSION        0x04
#define DLT_AR_RELEASE_MINOR_VERSION        0x00
#define DLT_AR_RELEASE_REVISION_VERSION     0x02

/* Software Version Information */
#define DLT_SW_MAJOR_VERSION         4
#define DLT_SW_MINOR_VERSION         0

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define DLT_ARRAY_SIZE                    0x10

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#ifdef DET_MODULE_ACTIVE
extern void Dlt_DetForwardErrorTrace(uint16 ModuleId, uint8 InstanceId,
  uint8 ApiId, uint8 ErrorId);

extern boolean TestDlt_DetForwardErrorTrace
  (App_DataValidateType LucDataValidate,uint16 ExpModuleId, uint8 ExpInstanceId,
  uint16 ExpApiId, uint8 ExpErrorId);
#endif

#ifdef DEM_MODULE_ACTIVE
extern void Dlt_DemTriggerOnEventStatus(Dem_EventIdType EventId, 
  Dem_EventStatusExtendedType EventStatusOld,
  Dem_EventStatusExtendedType EventStatusNew);

extern boolean TestDlt_DemTriggerOnEventStatus(App_DataValidateType
  LucDataValidate, Dem_EventIdType ExpEventId, uint8 ExpEventStatusOld,
  uint8 ExpEventStatusNew);
#endif

extern void TestDlt_DefaultBehavior(void);

#endif /* End DLT_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

