/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Dcm_Cbk.h                                                     **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Dcm Stub                                              **
**                                                                            **
**  PURPOSE   : Declaration of Dcm Stub functions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/


/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

#ifndef DCM_CBK_H
#define DCM_CBK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "TC_Generic.h"

/*******************************************************************************
**                                Macros                                      **
*******************************************************************************/
#define DCM_DATA_LENGTH                      0x08
#define DCM_ARRAY_SIZE                       0x04

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

extern void Dcm_ChangeParameterConfirmation(PduIdType id, 
  NotifResultType result);

extern void Dcm_TpRxIndication(PduIdType DcmRxPduId, NotifResultType Result);

extern boolean TestDcm_RxIndication(App_DataValidateType LucDataValidate,
  PduIdType ExpRxPduId, NotifResultType ExpResult);

extern void Dcm_TpTxConfirmation(PduIdType DcmTxPduId, NotifResultType Result);

extern boolean TestDcm_TxConfirmation(App_DataValidateType LucDataValidate,
  PduIdType ExpTxPduId, NotifResultType ExpResult);

extern BufReq_ReturnType Dcm_StartOfReception(PduIdType DcmRxPduId,
  PduLengthType TpSduLength, PduLengthType *RxBufferSizePtr);

extern  boolean TestDcm_StartOfReception(App_DataValidateType LucDataValidate,
  PduIdType ExpRxPduId, PduLengthType ExpTpSduLength,
  PduLengthType *RxBufferSizePtr);

extern  void TestDcm_StartOfReceptionSetVal(BufReq_ReturnType RetVal,
  PduLengthType RxBufferSize);

extern  BufReq_ReturnType Dcm_CopyRxData(PduIdType DcmRxPduId,
  PduInfoType *PduInfoPtr, PduLengthType *RxBufferSizePtr);

extern  boolean TestDcm_CopyRxData(App_DataValidateType LucDataValidate,
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr,
  PduLengthType *ExpRxBufferSizePtr);

extern  void TestDcm_CopyRxDataSetVal(BufReq_ReturnType RetVal, 
  PduLengthType RxBufferSize);

extern  BufReq_ReturnType Dcm_CopyTxData(PduIdType DcmTxPduId,
  PduInfoType* PduInfoPtr, RetryInfoType* RetryInfoPtr,
  PduLengthType* TxDataCntPtr);

extern  boolean TestDcm_CopyTxData(App_DataValidateType LucDataValidate,
  PduIdType DcmTxPduId, PduInfoType* PduInfoPtr, RetryInfoType* RetryInfoPtr,
  PduLengthType* TxDataCntPtr);

extern  void TestDcm_CopyTxDataSetVal(BufReq_ReturnType RetVal, uint8 *TxData,
  PduLengthType TxDataCnt);
  
extern boolean DcmTest_ValidateData(PduInfoType* LddExpPduInfo, 
  PduInfoType* LddActPduInfo);

extern void Dcm_ComM_NoComModeEntered(uint8 NetworkId);
extern void Dcm_ComM_SilentComModeEntered(uint8 NetworkId);
extern void Dcm_ComM_FullComModeEntered(uint8 NetworkId);
 
extern boolean TestDcm_ComM_NoComModeEntered(App_DataValidateType 
  LucDataValidate, uint8 LddNetworkId);
extern boolean TestDcm_ComM_SilentComModeEntered(App_DataValidateType 
  LucDataValidate, uint8 LddNetworkId);
extern boolean TestDcm_ComM_FullComModeEntered(App_DataValidateType 
  LucDataValidate, uint8 LddNetworkId);

#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
