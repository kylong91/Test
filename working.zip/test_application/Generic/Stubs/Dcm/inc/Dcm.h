/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Dcm.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR DCM Stub                                              **
**                                                                            **
**  PURPOSE   : Declaration of DCM Stub functions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/


/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

#ifndef DCM_H
#define DCM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"             /* Com Stack header */
#include "TC_Generic.h"        
#include "Dcm_Types.h"        

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR Specification Version Information */
#define DCM_AR_RELEASE_MAJOR_VERSION  4
#define DCM_AR_RELEASE_MINOR_VERSION  0
#define DCM_AR_RELEASE_REVISION_VERSION  3
/* Software Version Information */
#define DCM_SW_MAJOR_VERSION  1
#define DCM_SW_MINOR_VERSION  0

/*******************************************************************************
**                      Macros                                                **
*******************************************************************************/
/* Macro for Dcm_CommunicationModeType */
#define DCM_ENABLE_RX_TX_NORM                     0x00
#define DCM_ENABLE_RX_DISABLE_TX_NORM             0x01
#define DCM_DISABLE_RX_ENABLE_TX_NORM             0x02
#define DCM_DISABLE_RX_TX_NORMAL                  0x03 
#define DCM_ENABLE_RX_TX_NM                       0x04  
#define DCM_ENABLE_RX_DISABLE_TX_NM               0x05
#define DCM_DISABLE_RX_ENABLE_TX_NM               0x06
#define DCM_DISABLE_RX_TX_NM                      0x07
#define DCM_ENABLE_RX_TX_NORM_NM                  0x08  
#define DCM_ENABLE_RX_DISABLE_TX_NORM_NM          0x09
#define DCM_DISABLE_RX_ENABLE_TX_NORM_NM          0x0A
#define DCM_DISABLE_RX_TX_NORM_NM                 0x0B
#define DCM_ENABLE_TX_RX_NORM                     0x00

/* Macro for Dcm_SesCtrlType */
#define DCM_DEFAULT_SESSION                       0x01
#define DCM_PROGRAMMING_SESSION                   0x02
#define DCM_EXTENDED_DIAGNOSTIC_SESSION           0x03
#define DCM_SAFETY_SYSTEM_DIAGNOSTIC_SESSION      0x04
#define DCM_ALL_SESSION_LEVEL                     0xFF

/* Macro for Dcm_ResetModeType */
#define DCM_NO_RESET                              0x00 
#define DCM_HARD_RESET                            0x01
#define DCM_KEY_ON_OFF_RESET                      0x02
#define DCM_SOFT_RESET                            0x03
#define DCM_ENABLE_RAPID_POWER_SHUTDOWN_RESET     0x04
#define DCM_DISABLE_RAPID_POWER_SHUTDOWN_RESET    0x05
#define DCM_BOOTLOADER_RESET                      0x06
#define DCM_SS_BOOTLOADER_RESET                   0x07  
#define DCM_RESET_EXECUTION                       0x08

#define DCM_INVALID_COMMUNICATIONMODETYPE         0x00
#define DCM_INVALID_NETWORKID                     0x02
#define DCM_INVALID_SESSIONMODETYPE               0x00 
#define DCM_INVALID_RESETMODETYPE                 0x00

#define DCM_E_CONDITIONSNOTCORRECT  (Dcm_NegativeResponseCodeType)0x22

/*******************************************************************************
**                       Global Data Types                                    **
*******************************************************************************/
typedef uint8 Dcm_ConfigType;

typedef uint8 Dcm_CommunicationModeType;
typedef uint8 Dcm_SesCtrlType;
typedef uint8 Dcm_ResetModeType;

typedef uint8 Dcm_RoeStateType;
typedef uint8 Dcm_NegativeResponseCodeType;



/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
 
 /* List of call back function for Dcm_CommunicationType() */
extern void Dcm_EnableRxTxNormModeEntry(void);
extern void Dcm_DisableRxTxNormModeEntry(void);
extern void Dcm_EnableRxDisableTxNormModeEntry(void);
extern void Dcm_DisableRxEnableTxNormModeEntry(void);
extern void Dcm_EnableRxTxNmModeEntry(void);
extern void Dcm_DisableRxTxNmModeEntry(void);
extern void Dcm_EnableRxDisableTxNmModeEntry(void);
extern void Dcm_EnableRxDisableTxNormNmModeEntry(void);
extern void Dcm_DisableRxTxNormNmModeEntry(void);

/* List of Call back function for Dcm_Sessionctrl() */
extern void Dcm_ProgrammingSessionModeEntry(void);
extern void Dcm_ExtendedDiagnosticSessionModeEntry(void);
extern void Dcm_SafetySystemDiagnosticSessionModeEntry(void);
extern void Dcm_AllSessionLevelModeEntry(void);
extern void Dcm_NoResetModeEntry(void);
extern void Dcm_SoftResetModeEntry(void);
extern void Dcm_EnableRapidPowerShutdownResetModeEntry(void);
extern void Dcm_BootloaderResetModeEntry(void);
extern void Dcm_EnableRxTxNormNmModeEntry(void);
extern void Dcm_DefaultSessionModeEntry(void);
extern void Dcm_SsBootLoaderResetModeEntry(void);
extern void Dcm_KeyOnOffResetModeEntry(void);
extern void Dcm_DisableRapidPowerShutdownResetModeEntry(void);

extern boolean TestDcm_EnableRxTxNormModeEntry(App_DataValidateType 
  LucDataValidate);
extern boolean TestDcm_DisableRxTxNormModeEntry(App_DataValidateType 
  LucDataValidate);
extern boolean TestDcm_EnableRxDisableTxNormModeEntry(App_DataValidateType 
  LucDataValidate);
extern boolean TestDcm_DisableRxEnableTxNormModeEntry(App_DataValidateType 
  LucDataValidate);
extern boolean TestDcm_EnableRxTxNmModeEntry(App_DataValidateType 
  LucDataValidate);
extern boolean TestDcm_DisableRxTxNmModeEntry(App_DataValidateType  
  LucDataValidate);
extern boolean TestDcm_EnableRxDisableTxNmModeEntry(App_DataValidateType  
  LucDataValidate);
extern boolean TestDcm_EnableRxDisableTxNormNmModeEntry(App_DataValidateType  
  LucDataValidate);
extern boolean TestDcm_DisableRxTxNormNmModeEntry(App_DataValidateType  
  LucDataValidate);
extern boolean TestDcm_ProgrammingSessionModeEntry(App_DataValidateType  
  LucDataValidate);
extern boolean TestDcm_ExtendedDiagnosticSessionModeEntry(App_DataValidateType  
  LucDataValidate);
extern boolean TestDcm_SafetySystemDiagnosticSessionModeEntry
 (App_DataValidateType LucDataValidate);
extern boolean TestDcm_AllSessionLevelModeEntry(App_DataValidateType  
  LucDataValidate);
extern boolean TestDcm_NoResetModeEntry(App_DataValidateType  
  LucDataValidate);
extern boolean TestDcm_SoftResetModeEntry(App_DataValidateType  
  LucDataValidate);
extern boolean TestDcm_EnableRapidPowerShutdownResetModeEntry
 (App_DataValidateType LucDataValidate);
extern boolean TestDcm_BootloaderResetModeEntry(App_DataValidateType  
  LucDataValidate);
extern boolean TestDcm_EnableRxTxNormNmModeEntry(App_DataValidateType  
  LucDataValidate);
extern boolean TestDcm_DefaultSessionModeEntry(App_DataValidateType  
  LucDataValidate);
extern boolean TestDcm_SsBootLoaderResetModeEntry(App_DataValidateType  
  LucDataValidate);
extern boolean TestDcm_KeyOnOffResetModeEntry(App_DataValidateType  
  LucDataValidate);
extern boolean TestDcm_DisableRapidPowerShutdownResetModeEntry
 (App_DataValidateType LucDataValidate);
 
extern Std_ReturnType Dcm_TriggerOnEvent(uint8 RoeEventId);
extern void TestSetDcm_TriggerOnEvent(Std_ReturnType LddReturnVal);
extern Std_ReturnType TestDcm_TriggerOnEvent(App_DataValidateType LucDataValidate,uint8
LucRoeEventId);

extern Std_ReturnType Dcm_DemTriggerOnDTCStatus(uint32 DTC, uint8 DTCStatusOld,
uint8 DTCStatusNew);

extern boolean TestDcm_DemTriggerOnDTCStatus(App_DataValidateType 
LucDataValidate, uint32 ExpDTC, uint8 ExpDTCStatusOld, uint8 ExpDTCStatusNew);

extern void TestDcm_DefaultBehavior(void);

extern void Dcm_Init(Dcm_ConfigType* ConfigPtr);

extern boolean TestDcm_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo); 

#endif /* Dcm_H */


/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
