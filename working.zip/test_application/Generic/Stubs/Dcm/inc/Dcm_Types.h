/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Dcm_Types.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR DCM Stub                                              **
**                                                                            **
**  PURPOSE   : Declaration of Dcm Stub functions                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/


/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

#ifndef DCM_TYPES_H
#define DCM_TYPES_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

#include "Std_Types.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/* AUTOSAR SPECIFICATION VERSION */
#define DCM_TYPES_AR_RELEASE_MAJOR_VERSION      4
#define DCM_TYPES_AR_RELEASE_MINOR_VERSION      0
#define DCM_TYPES_AR_RELEASE_REVISION_VERSION   3

/* SOFTWARE VERSION INFORMATION */
#define DCM_TYPES_SW_MAJOR_VERSION       1
#define DCM_TYPES_SW_MINOR_VERSION       0
/*******************************************************************************
**                Dcm_OpStatusType                                            **
*******************************************************************************/

typedef uint8 Dcm_OpStatusType;

/* Indicates the initial call to the operation */
#define DCM_INITIAL                                      (Dcm_OpStatusType)0x00

/* Indicates that a pending return has been done on the previous 
 * call of the operation 
 */
#define DCM_PENDING                                      (Dcm_OpStatusType)0x01

/* Indicates that the DCM requests to cancel the pending operation */
#define DCM_CANCEL                                       (Dcm_OpStatusType)0x02

/* Confirm a response pending transmission */
#define DCM_FORCE_RCRRP_OK                               (Dcm_OpStatusType)0x03

#endif /* DCM_TYPES_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
