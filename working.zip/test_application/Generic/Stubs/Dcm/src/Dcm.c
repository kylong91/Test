/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Dcm.c                                                         **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Dcm Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Dcm Stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm.h"
#include "Dcm_Cbk.h"

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
#ifdef DLT_MODULE_ACTIVE
uint8 Dlt_GucRoeEventId;
uint8 Dlt_GucTriggerOnEvent;
Std_ReturnType Dlt_GddTriggerOnEventRetVal;
#endif

#ifdef COMM_MODULE_ACTIVE
uint8 Dcm_GucNetworkId;
uint8 Dcm_GucNoComModeEnteredCount;
uint8 Dcm_GucSilentComModeEnteredCount;
uint8 Dcm_GucFullComModeEnteredCount;
#endif

#ifdef PDUR_MODULE_ACTIVE
uint8 Dcm_GaaCopyRxDataSduData[DCM_DATA_LENGTH];
uint8 Dcm_GaaCopyTxDataSduData[DCM_DATA_LENGTH];
PduLengthType Dcm_GddCopyRxDataRxBuffer;
BufReq_ReturnType Dcm_GddCopyRxDataRetVal;
uint8 Dcm_GucCopyRxDataCount;

PduIdType Dcm_GddCopyTxDataPduId;
uint8 Dcm_GddCopyTxDataSduLength;
PduIdType Dcm_GddRxIndPduId;
NotifResultType Dcm_GddRxIndResult;
uint8 Dcm_GucRxIndCount;

PduIdType Dcm_GddTxConfPduId;
NotifResultType Dcm_GddTxConfResult;
uint8 Dcm_GucTxConfCount;

PduIdType Dcm_GddSorPduId;
PduLengthType Dcm_GddSorTpSduLength;
PduLengthType Dcm_GddSorRxBuffer;
BufReq_ReturnType Dcm_GddSorRetVal;
uint8 Dcm_GucSorCount;

PduIdType Dcm_GddCopyRxDataPduId;
uint8 Dcm_GddCopyRxDataSduLength;

RetryInfoType Dcm_GddCopyTxDataRetryInfo;
PduLengthType Dcm_GddCopyTxDataTxDataCnt;
BufReq_ReturnType Dcm_GddCopyTxDataRetVal;
uint8 Dcm_GucCopyTxDataCount;
#endif

#ifdef BSWM_MODULE_ACTIVE
uint8 Dcm_GucEnableRxTxNormModeEntryCount;
uint8 Dcm_GucDisableRxTxNormModeEntryCount;
uint8 Dcm_GucEnableRxDisableTxNormModeEntryCount;
uint8 Dcm_GucDisableRxEnableTxNormModeEntryCount;
uint8 Dcm_GucEnableRxTxNmModeEntryCount;
uint8 Dcm_GucDisableRxTxNmModeEntryCount;
uint8 Dcm_GucEnableRxDisableTxNmModeEntryCount;
uint8 Dcm_GucEnableRxDisableTxNormNmModeEntryCount;
uint8 Dcm_GucDisableRxTxNormNmModeEntryCount;
uint8 Dcm_GucEnableRxTxNormNmModeEntryCount;
uint8 Dcm_GucSafetySystemDiagnosticSessionModeEntryCount;
uint8 Dcm_GucNoResetModeEntryCount;
uint8 Dcm_GucSoftResetModeEntryCount;
uint8 Dcm_GucEnableRapidPowerShutdownResetModeEntryCount;
uint8 Dcm_GucBootloaderResetModeEntryCount;
uint8 Dcm_GucSsBootLoaderResetModeEntryCount;
uint8 Dcm_GucKeyOnOffResetModeEntryCount;
uint8 Dcm_GucDisableRapidPowerShutdownResetModeEntryCount;
uint8 Dcm_GucDefaultSessionModeEntryCount = 0;
uint8 Dcm_GucProgrammingSessionModeEntryCount = 0;
uint8 Dcm_GucExtendedDiagnosticSessionModeEntryCount = 0;
uint8 Dcm_GucAllSessionLevelModeEntryCount = 0;
uint8 Dcm_GucInitCnt;
uint8 Dcm_GucInitSeqCnt;
#endif

#ifdef DEM_MODULE_ACTIVE
uint32 Dem_GulDTC;
uint8 Dem_GucDTCStatusOld;
uint8 Dem_GucDTCStatusNew;
uint8 Dem_GucDcmTriggerCounter;
Std_ReturnType Dem_GddReturnVal;
#endif
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
#ifdef PDUR_MODULE_ACTIVE
/*******************************************************************************
**                       Dcm_TpRxIndication()                                   **
*******************************************************************************/
void Dcm_TpRxIndication(PduIdType DcmRxPduId, NotifResultType Result)
{
  #ifndef TYPICAL_CONFIG  
  /* Load actual PduId and result into Global variables */
  Dcm_GddRxIndPduId = DcmRxPduId;
  Dcm_GddRxIndResult = Result;
  /* Increment count variable to handle multiple invocations */
  Dcm_GucRxIndCount++;
  #endif
} /* End Dcm_TpRxIndication() */

/*******************************************************************************
**                       TestDcm_RxIndication()                               **
*******************************************************************************/
boolean TestDcm_RxIndication(App_DataValidateType LucDataValidate, PduIdType ExpRxPduId, 
  NotifResultType ExpResult)
{
  boolean LblRetValue;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count and Id */
      if((Dcm_GucRxIndCount == 0x01) && (ExpRxPduId == Dcm_GddRxIndPduId) && 
        (Dcm_GddRxIndResult == ExpResult))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucRxIndCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucRxIndCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);

} /* End TestDcm_RxIndication() */

/*******************************************************************************
**                       Dcm_TpTxConfirmation()                               **
*******************************************************************************/
void Dcm_TpTxConfirmation(PduIdType DcmTxPduId, NotifResultType Result)
{
  #ifndef TYPICAL_CONFIG 
  /* Load actual PduId and result into Global variables */
  Dcm_GddTxConfPduId = DcmTxPduId;
  Dcm_GddTxConfResult = Result;
  /* Increment count variable to handle multiple invocations */
  Dcm_GucTxConfCount++;
  #endif
} /* End Dcm_TpTxConfirmation() */

/*******************************************************************************
**                       TestDcm_TxConfirmation()                             **
*******************************************************************************/
boolean TestDcm_TxConfirmation(App_DataValidateType LucDataValidate, 
  PduIdType ExpTxPduId, NotifResultType ExpResult)
{
  boolean LblRetValue;
  
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count and Id */
      if((Dcm_GucTxConfCount == 0x01) && (ExpTxPduId == Dcm_GddTxConfPduId) && 
        (Dcm_GddTxConfResult == ExpResult))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucTxConfCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucTxConfCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);

} /* End TestDcm_TxConfirmation() */
#endif
/*******************************************************************************
**                       Dcm_StartOfReception()                               **
*******************************************************************************/
#ifdef PDUR_MODULE_ACTIVE
BufReq_ReturnType Dcm_StartOfReception(PduIdType DcmRxPduId, 
  PduLengthType TpSduLength, PduLengthType *RxBufferSizePtr)
{
  #ifndef TYPICAL_CONFIG 
  /* Load actual PduId, TpSduLength into Global variables */
  Dcm_GddSorPduId = DcmRxPduId;
  Dcm_GddSorTpSduLength = TpSduLength;
  /* Load RxBufferSizePtr with data of Dcm_GddSorRxBuffer  */
  *RxBufferSizePtr = Dcm_GddSorRxBuffer;
  /* Increment count variable to handle multiple invocations */
  Dcm_GucSorCount++;
  #endif
  return(Dcm_GddSorRetVal);
} /* End Dcm_StartOfReception() */
#endif
/*******************************************************************************
**                       TestDcm_StartOfReception()                           **
*******************************************************************************/
#ifdef PDUR_MODULE_ACTIVE
boolean TestDcm_StartOfReception(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, PduLengthType ExpTpSduLength, 
  PduLengthType *RxBufferSizePtr)
{
  boolean LblRetValue;
  RxBufferSizePtr++;
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, Id and TpSduLength */
      if((Dcm_GucSorCount == 0x01) && (ExpRxPduId == Dcm_GddSorPduId) && 
        (Dcm_GddSorTpSduLength == ExpTpSduLength))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucSorCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucSorCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestDcm_StartOfReception() */
#endif
/*******************************************************************************
**                       TestDcm_StartOfReceptionSetVal()                     **
*******************************************************************************/
#ifdef PDUR_MODULE_ACTIVE
void TestDcm_StartOfReceptionSetVal(BufReq_ReturnType RetVal, 
  PduLengthType RxBufferSize)
{
  Dcm_GddSorRetVal = RetVal;
  Dcm_GddSorRxBuffer = RxBufferSize;
} /* End TestDcm_StartOfReceptionSetVal() */
#endif
/*******************************************************************************
**                       Dcm_CopyRxData()                                     **
*******************************************************************************/
#ifdef PDUR_MODULE_ACTIVE
BufReq_ReturnType Dcm_CopyRxData(PduIdType DcmRxPduId,
  PduInfoType *PduInfoPtr, PduLengthType *RxBufferSizePtr)
{
  #ifndef TYPICAL_CONFIG 
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8 *LpSduDataPtr;
  /* Load the address of SduDataPtr into Local Variable */
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  
  /* Load actual PduId, SduLength into Global variables */
  Dcm_GddCopyRxDataPduId = DcmRxPduId;
  Dcm_GddCopyRxDataSduLength = PduInfoPtr->SduLength;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > DCM_DATA_LENGTH)
  {
    LucDataLength = DCM_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->SduLength;
  }
  /* 
   * Load Dcm_GaaCopyRxDataSduData with SduDataPtr and RxBufferSizePtr 
   * with data of Dcm_GddCopyRxDataRxBuffer  
   */
  /* Load the SduDataPtr with the global array */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    Dcm_GaaCopyRxDataSduData[LucDataIndex] = *LpSduDataPtr;
    LpSduDataPtr++;
  }
  *RxBufferSizePtr = Dcm_GddCopyRxDataRxBuffer;
  /* Increment count variable to handle multiple invocations */
  Dcm_GucCopyRxDataCount++;
  #endif
  return(Dcm_GddCopyRxDataRetVal);
} /* End Dcm_CopyRxData() */

/*******************************************************************************
**                       TestDcm_CopyRxData()                                 **
*******************************************************************************/
boolean TestDcm_CopyRxData(App_DataValidateType LucDataValidate, 
  PduIdType ExpRxPduId, PduInfoType *ExpPduInfoPtr, 
  PduLengthType *ExpRxBufferSizePtr)
{
  boolean LblRetValue;
  PduInfoType ActPduInfo;
  ExpRxBufferSizePtr++;
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, Id and SduLength */
      if((Dcm_GucCopyRxDataCount == 0x01) && 
      (Dcm_GddCopyRxDataPduId == ExpRxPduId))
      {
        ActPduInfo.SduLength = Dcm_GddCopyRxDataSduLength;
        ActPduInfo.SduDataPtr = &Dcm_GaaCopyRxDataSduData[0];

        /* Validate SduLength and Data */
        if(DcmTest_ValidateData(ExpPduInfoPtr, &ActPduInfo))
        {
          LblRetValue = STEP_PASSED;
        }
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucCopyRxDataCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucCopyRxDataCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestDcm_CopyRxData() */

/*******************************************************************************
**                       TestDcm_CopyRxDataSetVal()                           **
*******************************************************************************/
void TestDcm_CopyRxDataSetVal(BufReq_ReturnType RetVal, 
  PduLengthType RxBufferSize)
{
  Dcm_GddCopyRxDataRetVal = RetVal;
  Dcm_GddCopyRxDataRxBuffer = RxBufferSize;
} /* End TestDcm_CopyRxDataSetVal() */
#endif
/*******************************************************************************
**                       Dcm_CopyTxData()                                     **
*******************************************************************************/
#ifdef PDUR_MODULE_ACTIVE
BufReq_ReturnType Dcm_CopyTxData(PduIdType DcmTxPduId, PduInfoType* PduInfoPtr, 
  RetryInfoType* RetryInfoPtr, PduLengthType* TxDataCntPtr)
{
  #ifndef TYPICAL_CONFIG 
  uint8 LucDataIndex;
  uint8 LucDataLength;
  uint8 *LpSduDataPtr;
  
  /* Load the address of SduDataPtr into Local Variable */
  LpSduDataPtr = PduInfoPtr->SduDataPtr;
  
  /* Load actual PduId, SduLength and RetryInfoPtr into Global variables */
  Dcm_GddCopyTxDataPduId = DcmTxPduId;
  Dcm_GddCopyTxDataSduLength = PduInfoPtr->SduLength;
  /*Check whether SduLength is exceeding the DATA_LENGTH limit */
  if(PduInfoPtr->SduLength > DCM_DATA_LENGTH)
  {
    LucDataLength = DCM_DATA_LENGTH;    
  }
  else
  {
    LucDataLength = PduInfoPtr->SduLength;
  }
  Dcm_GddCopyTxDataRetryInfo.TpDataState = RetryInfoPtr->TpDataState;
  Dcm_GddCopyTxDataRetryInfo.TxTpDataCnt = RetryInfoPtr->TxTpDataCnt;
  /* 
   * Load SduDataPtr with data of Dcm_GaaCopyTxDataSduData and TxDataCntPtr 
   * with data of Dcm_GddCopyTxDataTxDataCnt  
   */
  /* Load the SduDataPtr with the global array */
  for(LucDataIndex = 0; LucDataIndex < LucDataLength; LucDataIndex++)
  {
    *LpSduDataPtr = Dcm_GaaCopyTxDataSduData[LucDataIndex];
    LpSduDataPtr++;
  }
  *TxDataCntPtr = Dcm_GddCopyTxDataTxDataCnt;
  /* Increment count variable to handle multiple invocations */
  Dcm_GucCopyTxDataCount++;
  #endif
  return(Dcm_GddCopyTxDataRetVal);
} /* End Dcm_CopyTxData() */

/*******************************************************************************
**                       TestDcm_CopyTxData()                                 **
*******************************************************************************/
boolean TestDcm_CopyTxData(App_DataValidateType LucDataValidate, PduIdType ExpTxPduId, 
  PduInfoType* ExpPduInfoPtr, RetryInfoType* ExpRetryInfoPtr, 
  PduLengthType* ExpTxDataCntPtr)
{
  boolean LblRetValue;
  ExpTxDataCntPtr++;
  LblRetValue = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
       /* Validate invocation count, Id, SduLength and RetryInfoPtr */
      if((Dcm_GucCopyTxDataCount == 0x01) && 
      (Dcm_GddCopyTxDataPduId == ExpTxPduId) && 
      (Dcm_GddCopyTxDataSduLength == ExpPduInfoPtr->SduLength) &&
      (Dcm_GddCopyTxDataRetryInfo.TpDataState == ExpRetryInfoPtr->TpDataState) && 
      (Dcm_GddCopyTxDataRetryInfo.TxTpDataCnt == ExpRetryInfoPtr->TxTpDataCnt))
      {
        LblRetValue = STEP_PASSED;
      }
      /* Reset API invocation Count after validating the API invocation */
      Dcm_GucCopyTxDataCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Dcm_GucCopyTxDataCount == 0)
      {
        LblRetValue = STEP_PASSED;
      }
      break;
    }
    
    default:
    {
      LblRetValue = STEP_FAILED;
      break;
    }
  }
  return(LblRetValue);
} /* End TestDcm_CopyTxData() */

/*******************************************************************************
**                       TestDcm_CopyTxDataSetVal()                           **
*******************************************************************************/
void TestDcm_CopyTxDataSetVal(BufReq_ReturnType RetVal, uint8 *TxData,
  PduLengthType TxDataCnt)
{
  uint8 LucDataIndex;
  Dcm_GddCopyTxDataRetVal = RetVal;
  for(LucDataIndex = 0x00; LucDataIndex < DCM_DATA_LENGTH; LucDataIndex++)
  {
    Dcm_GaaCopyTxDataSduData[LucDataIndex] = *TxData;
    TxData++;
  }
  Dcm_GddCopyTxDataTxDataCnt = TxDataCnt;
} /* End TestDcm_CopyTxDataSetVal() */

/*******************************************************************************
**                       DcmTest_ValidateData()                             **
*******************************************************************************/
boolean DcmTest_ValidateData(PduInfoType* LddExpPduInfo, 
  PduInfoType* LddActPduInfo)
{
  uint8 *LpActualDataPtr;
  uint8 *LpExpDataPtr;
  boolean LblReturnValue;
  PduLengthType LddSduCount;

  /* Load the ExpPduInfo to local variables */
  LddSduCount = LddExpPduInfo->SduLength;
  LpExpDataPtr = LddExpPduInfo->SduDataPtr;
  LpActualDataPtr = LddActPduInfo->SduDataPtr;
  LblReturnValue = FALSE;

  /* Check the sdu length */
  if((LddExpPduInfo->SduLength <= DCM_DATA_LENGTH) &&
    (LddExpPduInfo->SduLength == LddActPduInfo->SduLength))
  {
    LblReturnValue = TRUE;
  }
   /* Check the sdu data */
  while((LddSduCount > 0) && (LblReturnValue != FALSE))
  {
    if(*LpActualDataPtr != *LpExpDataPtr)
    {
      LblReturnValue = FALSE;
    }
    LpActualDataPtr++;
    LpExpDataPtr++;
    LddSduCount--;
  }
  return(LblReturnValue);
} /* End DcmTest_ValidateData() */
#endif
/*******************************************************************************
**                       Dcm_ComM_NoComModeEntered()                          **
*******************************************************************************/
#ifdef COMM_MODULE_ACTIVE
void Dcm_ComM_NoComModeEntered(uint8 NetworkId)
{
  #ifndef TYPICAL_CONFIG
  Dcm_GucNoComModeEnteredCount++;
  Dcm_GucNetworkId = NetworkId;
  #endif
}/* End Dcm_ComM_NoComModeEntered() */

/*******************************************************************************
**                       TestDcm_ComM_NoComModeEntered()                      **
*******************************************************************************/
boolean TestDcm_ComM_NoComModeEntered(App_DataValidateType 
  LucDataValidate, uint8 LddNetworkId)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Dcm_GucNoComModeEnteredCount == 0x01) && 
        (Dcm_GucNetworkId == LddNetworkId))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucNoComModeEnteredCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestDcm_ComM_NoComModeEntered() */
/*******************************************************************************
**                       Dcm_ComM_SilentComModeEntered()                      **
*******************************************************************************/
void Dcm_ComM_SilentComModeEntered(uint8 NetworkId)
{
  #ifndef TYPICAL_CONFIG
  Dcm_GucSilentComModeEnteredCount++;
  Dcm_GucNetworkId = NetworkId;
  #endif
} /* End Dcm_ComM_SilentComModeEntered() */
/*******************************************************************************
**                       TestDcm_ComM_SilentComModeEntered()                  **
*******************************************************************************/
boolean TestDcm_ComM_SilentComModeEntered(App_DataValidateType 
  LucDataValidate, uint8 LddNetworkId)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    { 
      if((Dcm_GucSilentComModeEnteredCount != 0x00) && 
        (Dcm_GucNetworkId == LddNetworkId))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucSilentComModeEnteredCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestDcm_ComM_SilentComModeEntered() */
/*******************************************************************************
**                       Dcm_ComM_FullComModeEntered()                      **
*******************************************************************************/
void Dcm_ComM_FullComModeEntered(uint8 NetworkId)
{
  #ifndef TYPICAL_CONFIG
  Dcm_GucFullComModeEnteredCount++;
  Dcm_GucNetworkId = NetworkId;
  #endif
} /* End Dcm_ComM_FullComModeEntered() */
/*******************************************************************************
**                       TestDcm_ComM_FullComModeEntered()                    **
*******************************************************************************/
boolean TestDcm_ComM_FullComModeEntered(App_DataValidateType 
  LucDataValidate, uint8 LddNetworkId)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {   
      if((Dcm_GucFullComModeEnteredCount != 0x00) && 
        (Dcm_GucNetworkId == LddNetworkId))
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucFullComModeEnteredCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestDcm_ComM_FullComModeEntered() */
#endif
/*******************************************************************************
**                       Dcm_ChangeParameterConfirmation()                    **
*******************************************************************************/
#ifdef PDUR_MODULE_ACTIVE
void Dcm_ChangeParameterConfirmation(PduIdType id, 
  NotifResultType result)
{
  id++;
  result++;
}
#endif

#ifdef BSWM_MODULE_ACTIVE

/*******************************************************************************
**                          Dcm_Init()                                        **
*******************************************************************************/

void Dcm_Init(Dcm_ConfigType* ConfigPtr)
{
	UNUSED(ConfigPtr);
  App_GucApiSeqCnt++;
	Dcm_GucInitSeqCnt = App_GucApiSeqCnt;
	Dcm_GucInitCnt++;
}/* End Dcm_Init() */

/*******************************************************************************
**                           TestDcm_Init()                                   **
*******************************************************************************/
boolean TestDcm_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Dcm_GucInitCnt == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Dcm_GucInitCnt = 0;
      Dcm_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(Dcm_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Dcm_GucInitCnt = 0;
      Dcm_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestDcm_Init() */

/*******************************************************************************
**                       Dcm_EnableRxTxNormModeEntry                          **
*******************************************************************************/
void Dcm_EnableRxTxNormModeEntry(void)
{
Dcm_GucEnableRxTxNormModeEntryCount++;
}

/*******************************************************************************
**                       TestDcm_EnableRxTxNormModeEntry ()                   **
*******************************************************************************/
boolean TestDcm_EnableRxTxNormModeEntry(App_DataValidateType  
  LucDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Dcm_GucEnableRxTxNormModeEntryCount != 0x00) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucEnableRxTxNormModeEntryCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestDcm_EnableRxTxNormModeEntry() */
/*******************************************************************************
**                       Dcm_DisableRxTxNormModeEntry                         **
*******************************************************************************/
 void Dcm_DisableRxTxNormModeEntry()
 {
  Dcm_GucEnableRxTxNormModeEntryCount++;
 }

/*******************************************************************************
**                       TestDcm_DisableRxTxNormModeEntry()                  **
*******************************************************************************/
boolean TestDcm_DisableRxTxNormModeEntry(App_DataValidateType  
  LucDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Dcm_GucEnableRxTxNormModeEntryCount != 0x00) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucEnableRxTxNormModeEntryCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestDcm_DisableRxTxNormModeEntry() */

/*******************************************************************************
**                       Dcm_EnableRxDisableTxNormModeEntry                   **
*******************************************************************************/
void Dcm_EnableRxDisableTxNormModeEntry(void)
{
Dcm_GucEnableRxDisableTxNormModeEntryCount++;
}

/*******************************************************************************
**                       TestDcm_EnableRxDisableTxNormModeEntry ()            **
*******************************************************************************/
boolean TestDcm_EnableRxDisableTxNormModeEntry(App_DataValidateType  
  LucDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Dcm_GucEnableRxDisableTxNormModeEntryCount != 0x00) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucEnableRxDisableTxNormModeEntryCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestDcm_EnableRxDisableTxNormModeEntry() */

/*******************************************************************************
**                       Dcm_DisableRxEnableTxNormModeEntry                   **
*******************************************************************************/
void Dcm_DisableRxEnableTxNormModeEntry(void)
{
Dcm_GucDisableRxEnableTxNormModeEntryCount++;
}

/*******************************************************************************
**                       TestDcm_DisableRxEnableTxNormModeEntry ()            **
*******************************************************************************/
boolean TestDcm_DisableRxEnableTxNormModeEntry(App_DataValidateType  
  LucDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Dcm_GucDisableRxEnableTxNormModeEntryCount != 0x00) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucDisableRxEnableTxNormModeEntryCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestDcm_DisableRxEnableTxNormModeEntry() */

/*******************************************************************************
**                       Dcm_EnableRxTxNmModeEntry                            **
*******************************************************************************/
void Dcm_EnableRxTxNmModeEntry(void)
{
Dcm_GucEnableRxTxNmModeEntryCount++;
}

/*******************************************************************************
**                       TestDcm_EnableRxTxNmModeEntry ()                     **
*******************************************************************************/
boolean TestDcm_EnableRxTxNmModeEntry(App_DataValidateType  
  LucDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Dcm_GucEnableRxTxNmModeEntryCount != 0x00) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucEnableRxTxNmModeEntryCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestDcm_EnableRxTxNmModeEntry() */

/*******************************************************************************
**                          Dcm_DisableRxTxNmModeEntry                        **
*******************************************************************************/
void Dcm_DisableRxTxNmModeEntry(void)
{
Dcm_GucDisableRxTxNmModeEntryCount++;
}

/*******************************************************************************
**                       TestDcm_DisableRxTxNmModeEntry ()                    **
*******************************************************************************/
boolean TestDcm_DisableRxTxNmModeEntry(App_DataValidateType  
  LucDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Dcm_GucDisableRxTxNmModeEntryCount != 0x00) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucDisableRxTxNmModeEntryCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestDcm_DisableRxTxNmModeEntry() */

/*******************************************************************************
**                          Dcm_EnableRxDisableTxNmModeEntry                  **
*******************************************************************************/
void Dcm_EnableRxDisableTxNmModeEntry(void)
{
Dcm_GucEnableRxDisableTxNmModeEntryCount++;
}

/*******************************************************************************
**                       TestDcm_EnableRxDisableTxNmModeEntry()               **
*******************************************************************************/
boolean TestDcm_EnableRxDisableTxNmModeEntry(App_DataValidateType  
  LucDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Dcm_GucEnableRxDisableTxNmModeEntryCount != 0x00) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucEnableRxDisableTxNmModeEntryCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestDcm_EnableRxDisableTxNmModeEntry() */

/*******************************************************************************
**                          Dcm_EnableRxDisableTxNormNmModeEntry              **
*******************************************************************************/
void Dcm_EnableRxDisableTxNormNmModeEntry(void)
{
Dcm_GucEnableRxDisableTxNormNmModeEntryCount++;
}

/*******************************************************************************
**                       TestDcm_EnableRxDisableTxNormNmModeEntry()           **
*******************************************************************************/
boolean TestDcm_EnableRxDisableTxNormNmModeEntry(App_DataValidateType  
  LucDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Dcm_GucEnableRxDisableTxNormNmModeEntryCount != 0x00) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucEnableRxDisableTxNormNmModeEntryCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestDcm_EnableRxDisableTxNormNmModeEntry() */

/*******************************************************************************
**                          Dcm_DisableRxTxNormNmModeEntry                    **
*******************************************************************************/
void Dcm_DisableRxTxNormNmModeEntry(void)
{
Dcm_GucDisableRxTxNormNmModeEntryCount++;
}

/*******************************************************************************
**                       TestDcm_DisableRxTxNormNmModeEntry()                 **
*******************************************************************************/
boolean TestDcm_DisableRxTxNormNmModeEntry(App_DataValidateType  
  LucDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Dcm_GucDisableRxTxNormNmModeEntryCount != 0x00) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucDisableRxTxNormNmModeEntryCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestDcm_DisableRxTxNormNmModeEntry() */

/*******************************************************************************
**                          Dcm_EnableRxTxNormNmModeEntry                     **
*******************************************************************************/
void Dcm_EnableRxTxNormNmModeEntry(void)
{
Dcm_GucEnableRxTxNormNmModeEntryCount++;
}

/*******************************************************************************
**                       TestDcm_EnableRxTxNormNmModeEntry()                  **
*******************************************************************************/
boolean TestDcm_EnableRxTxNormNmModeEntry(App_DataValidateType  
  LucDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Dcm_GucEnableRxTxNormNmModeEntryCount != 0x00) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucEnableRxTxNormNmModeEntryCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestDcm_EnableRxTxNormNmModeEntry() */

/*******************************************************************************
**                       Dcm_DefaultSessionModeEntry                          **
*******************************************************************************/
void Dcm_DefaultSessionModeEntry(void)
{
Dcm_GucDefaultSessionModeEntryCount++;
}

/*******************************************************************************
**                       TestDcm_EnableRxTxNormModeEntry ()                   **
*******************************************************************************/
boolean TestDcm_DefaultSessionModeEntry(App_DataValidateType  
  LucDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Dcm_GucDefaultSessionModeEntryCount != 0x00) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucDefaultSessionModeEntryCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestDcm_DefaultSessionModeEntry() */

/*******************************************************************************
**                       Dcm_ProgrammingSessionModeEntry                      **
*******************************************************************************/
void Dcm_ProgrammingSessionModeEntry(void)
{
Dcm_GucProgrammingSessionModeEntryCount++;
}

/*******************************************************************************
**                       TestDcm_ProgrammingSessionModeEntry ()               **
*******************************************************************************/
boolean TestDcm_ProgrammingSessionModeEntry(App_DataValidateType  
  LucDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Dcm_GucProgrammingSessionModeEntryCount != 0x00) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucProgrammingSessionModeEntryCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestDcm_ProgrammingSessionModeEntry() */


/*******************************************************************************
**                       Dcm_ExtendedDiagnosticSessionModeEntry               **
*******************************************************************************/
void Dcm_ExtendedDiagnosticSessionModeEntry(void)
{
Dcm_GucExtendedDiagnosticSessionModeEntryCount++;
}

/*******************************************************************************
**                       TestDcm_ExtendedDiagnosticSessionModeEntry ()        **
*******************************************************************************/
boolean TestDcm_ExtendedDiagnosticSessionModeEntry(App_DataValidateType  
  LucDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Dcm_GucExtendedDiagnosticSessionModeEntryCount != 0x00) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucExtendedDiagnosticSessionModeEntryCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestDcm_ExtendedDiagnosticSessionModeEntry() */

/*******************************************************************************
**                       Dcm_ExtendedDiagnosticSessionModeEntry               **
*******************************************************************************/
void Dcm_SafetySystemDiagnosticSessionModeEntry(void)
{
Dcm_GucExtendedDiagnosticSessionModeEntryCount++;
}

/*******************************************************************************
**                       TestDcm_SafetySystemDiagnosticSessionModeEntry ()    **
*******************************************************************************/
boolean TestDcm_SafetySystemDiagnosticSessionModeEntry(App_DataValidateType  
  LucDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Dcm_GucExtendedDiagnosticSessionModeEntryCount != 0x00) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucExtendedDiagnosticSessionModeEntryCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestDcm_SafetySystemDiagnosticSessionModeEntry() */

/*******************************************************************************
**                       Dcm_AllSessionLevelModeEntry                         **
*******************************************************************************/
void Dcm_AllSessionLevelModeEntry(void)
{
Dcm_GucAllSessionLevelModeEntryCount++;
}

/*******************************************************************************
**                       TestDcm_AllSessionLevelModeEntry ()    **
*******************************************************************************/
boolean TestDcm_AllSessionLevelModeEntry(App_DataValidateType  
  LucDataValidate)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Dcm_GucAllSessionLevelModeEntryCount != 0x00) 
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dcm_GucAllSessionLevelModeEntryCount = 0x00;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestDcm_AllSessionLevelModeEntry() */
#endif

#ifdef DLT_MODULE_ACTIVE
/*******************************************************************************
**                        TestSetDcm_TriggerOnEvent()                         **
*******************************************************************************/
void TestSetDcm_TriggerOnEvent(Std_ReturnType LddReturnVal)
{
  Dlt_GddTriggerOnEventRetVal = LddReturnVal;
}
/*******************************************************************************
**                     Dcm_TriggerOnEvent()                                   **
*******************************************************************************/
Std_ReturnType Dcm_TriggerOnEvent(uint8 RoeEventId)
{
  #ifndef TYPICAL_CONFIG
  Dlt_GucRoeEventId = RoeEventId;
  Dlt_GucTriggerOnEvent++;
  #endif
  return(Dlt_GddTriggerOnEventRetVal);
}
/*******************************************************************************
**                       TestDcm_TriggerOnEvent()                             **
*******************************************************************************/
Std_ReturnType TestDcm_TriggerOnEvent(App_DataValidateType LucDataValidate,uint8
LucRoeEventId)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single Occurrence  and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Dlt_GucRoeEventId == LucRoeEventId)
      {
        LblStepResult = APP_TC_PASSED;
      }  
      Dlt_GucTriggerOnEvent = 0;
      break;
    } /* End case S_VALIDATE: */

    /*
     * Case to handle API invocation with multiple Occurrence  (with out any
     * sequence) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE: */

    /* Case to handle API not invoked for single Occurrence  */
    case S_NOT_INVOKED:
    {
      if(Dlt_GucTriggerOnEvent == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }      
      break;
    }
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */

  return(LblStepResult);
} /* End TestDcm_AllSessionLevelModeEntry() */
#endif
/*******************************************************************************
**                     TestDcm_DefaultBehavior()                              **
*******************************************************************************/
void TestDcm_DefaultBehavior(void)
{
  #ifdef PDUR_MODULE_ACTIVE
  uint8 LucDataIndex;
  
  Dcm_GucRxIndCount = 0x00;
  Dcm_GucTxConfCount = 0x00;
  Dcm_GucSorCount = 0x00;
  Dcm_GddSorRetVal = BUFREQ_OK;
  Dcm_GddCopyRxDataRxBuffer = 0x00;
  Dcm_GddCopyRxDataRetVal = BUFREQ_OK;
  Dcm_GucCopyRxDataCount = 0x00;
  for(LucDataIndex = 0x00; LucDataIndex < DCM_DATA_LENGTH; LucDataIndex++)
  {
    Dcm_GaaCopyTxDataSduData[LucDataIndex] = LucDataIndex;
  }
  Dcm_GddCopyTxDataTxDataCnt = 0x00;
  Dcm_GddCopyTxDataRetVal = BUFREQ_OK;
  Dcm_GucCopyTxDataCount = 0x00;
  #endif
  #ifdef COMM_MODULE_ACTIVE
  Dcm_GucNoComModeEnteredCount = 0;
  Dcm_GucSilentComModeEnteredCount = 0;
  Dcm_GucFullComModeEnteredCount = 0;
  #endif
  #ifdef DLT_MODULE_ACTIVE
  Dlt_GucRoeEventId = 0;
  Dlt_GddTriggerOnEventRetVal = 0;
  Dlt_GucTriggerOnEvent = 0;
  #endif
  #ifdef DEM_MODULE_ACTIVE
  Dem_GucDcmTriggerCounter = 0;
  Dem_GddReturnVal = 0;
  #endif
}/* End TestDcm_DefaultBehavior() */

#ifdef DEM_MODULE_ACTIVE
/*******************************************************************************
**                       Dcm_DemTriggerOnDTCStatus()                          **
*******************************************************************************/
Std_ReturnType Dcm_DemTriggerOnDTCStatus(uint32 DTC, uint8 DTCStatusOld,
uint8 DTCStatusNew)
{
  #ifndef TYPICAL_CONFIG
  Dem_GulDTC = DTC;
  Dem_GucDTCStatusOld = DTCStatusOld;
  Dem_GucDTCStatusNew = DTCStatusNew;
  #endif
  Dem_GucDcmTriggerCounter++;
  
  return (Dem_GddReturnVal);
  
} /* End Dcm_DemTriggerOnDTCStatus() */
/*******************************************************************************
**                        TestDcm_DemTriggerOnDTCStatus()                     **
*******************************************************************************/
boolean TestDcm_DemTriggerOnDTCStatus(App_DataValidateType LucDataValidate,
uint32 ExpDTC, uint8 ExpDTCStatusOld, uint8 ExpDTCStatusNew)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;
  
  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if((Dem_GucDcmTriggerCounter == 0x01) && (Dem_GulDTC == ExpDTC) &&
         (Dem_GucDTCStatusOld == ExpDTCStatusOld) && (Dem_GucDTCStatusNew 
         == ExpDTCStatusNew))
      {
        LblStepResult = APP_TC_PASSED;
      }
      Dem_GucDcmTriggerCounter = 0;
      break;
    }
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      break;
    } /* End case M_VALIDATE */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      if(Dem_GucDcmTriggerCounter == 0)
      {
        LblStepResult = APP_TC_PASSED;
      }
     
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestDcm_DemTriggerOnDtcStatus() */
#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
