/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Det.c                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Det Stub                                              **
**                                                                            **
**  PURPOSE   : This application file contains the Det Stub functions         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By                  Description                    **
********************************************************************************
** 1.0.0     15-Nov-2012   Shanthi Vishwanath  Initial version                **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Det.h"

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
uint8 Det_GucReportCount;
uint8 Det_GucReportCheckCount;
uint16 Det_GusModuleId[DET_ARRAY_SIZE];
uint8 Det_GucInstanceId[DET_ARRAY_SIZE];
uint8 Det_GucApiId[DET_ARRAY_SIZE];
uint8 Det_GucErrorId[DET_ARRAY_SIZE];
Std_ReturnType Det_GddRetVal = E_OK;
boolean Det_GblErrorLog = TRUE;
#ifdef ECUM_MODULE_ACTIVE
uint8 Det_GucInitCount;
uint8 Det_GucInitSeqCnt;
uint8 Det_GucStartCount;
uint8 Det_GucStartSeqCnt;
#endif
/*******************************************************************************
**                      Det_ReportError()                                     **
*******************************************************************************/
Std_ReturnType Det_ReportError(uint16 ModuleId, uint8 InstanceId, uint8 ApiId,
  uint8 ErrorId)
{
  #ifndef TYPICAL_CONFIG
  /*
   * Load actual ModuleId, InstanceId, ApiId and ErrorId into Global variables
   */
  Det_GusModuleId[Det_GucReportCount] = ModuleId;
  Det_GucInstanceId[Det_GucReportCount] = InstanceId;
  Det_GucApiId[Det_GucReportCount] = ApiId;
  Det_GucErrorId[Det_GucReportCount] = ErrorId;
  
  if(Det_GblErrorLog)
  {
    App_LogTestResult(APP_TC_FAILED_DET);
  }
  
  /* Increment count variable to handle multiple invocations */
  Det_GucReportCount++;
  #endif /* TYPICAL_CONFIG */
  return(Det_GddRetVal);
} /* End Det_ReportError() */

/*******************************************************************************
**                       TestDet_ReportError()                                **
*******************************************************************************/
boolean TestDet_ReportError(App_DataValidateType LucDataValidate,
  uint16 ExpModuleId, uint8 ExpInstanceId, uint8 ExpApiId, uint8 ExpErrorId)
{
  boolean LblStepResult;
  uint8 LucIndex;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      /* Validate invocation count, ModuleId, InstanceId, ApiId and ErrorId */
      if(((Det_GucReportCount == 0x01)||(Det_GucReportCount == 0x02)) &&
        (Det_GusModuleId[0] == ExpModuleId) &&
        (Det_GucInstanceId[0] == ExpInstanceId) &&
        (Det_GucApiId[0] == ExpApiId) && (Det_GucErrorId[0] == ExpErrorId))
      {
        LblStepResult = STEP_PASSED;
      }

      /* Reset API invocation Count after validating the API invocation */
      Det_GucReportCount = 0;
      Det_GucReportCheckCount = 0;
      break;
    } /* End case S_VALIDATE: */
    
    /*
     * Case to handle API invocation with multiple occurance (with out any
     * sequnce) and to validate parameters of the API with what it has been
     * invoked
     */
    case M_VALIDATE:
    {
      /*
       * Loop through the array and check for the occurance of the ID with what
       * it has been invoked
       */
      for(LucIndex = 0; LucIndex < Det_GucReportCount; LucIndex++)
      {
        /* Validate Network and CurrentState */
        if((Det_GusModuleId[LucIndex] == ExpModuleId) &&
          (Det_GucInstanceId[LucIndex] == ExpInstanceId) &&
          (Det_GucApiId[LucIndex] == ExpApiId) &&
          (Det_GucErrorId[LucIndex] == ExpErrorId))
        {
          LblStepResult = STEP_PASSED;          
          /*
           * Break the loop by reseting LucIndex with max after validating the
           * API invocation
           */
          LucIndex = Det_GucReportCount;
        }
      }
      /*
       * Increment global variable to check number of times the API invocation
       * is verified
       */
      Det_GucReportCheckCount++;

      /*
       * Reset all the count variables once after verifying the API invocation
       * for maximum number of API invocations
       */
      if(Det_GucReportCheckCount == Det_GucReportCount)
      {
        Det_GucReportCount = 0;
        Det_GucReportCheckCount = 0;
      }
      break;
    } /* End case M_VALIDATE: */
    
    /* Case to handle API not invoked for single occurance */
    case S_NOT_INVOKED:
    {
      /* Checking the API invocation count */
      if(Det_GucReportCount == 0)
      {
        LblStepResult = STEP_PASSED;
      }
      break;
    }
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestDet_ReportError() */
#ifdef ECUM_MODULE_ACTIVE

/*******************************************************************************
**                          Det_Init()                                        **
*******************************************************************************/
void Det_Init(void)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Det_GucInitSeqCnt = App_GucApiSeqCnt;
  Det_GucInitCount++;
  #endif
} /* End Det_Init() */

/*******************************************************************************
**                           TestDet_Init()                                   **
*******************************************************************************/
boolean TestDet_Init(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Det_GucInitCount == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Det_GucInitCount = 0;
      Det_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(Det_GucInitSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Det_GucInitCount = 0;
      Det_GucInitSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestDet_Init() */

/*******************************************************************************
**                         Det_Start()                                        **
*******************************************************************************/
void Det_Start(void)
{
  #ifndef TYPICAL_CONFIG
  App_GucApiSeqCnt++;
  Det_GucStartSeqCnt = App_GucApiSeqCnt;
  Det_GucStartCount++;
  #endif
} /* End Det_Start() */

/*******************************************************************************
**                          TestDet_Start()                                   **
*******************************************************************************/
boolean TestDet_Start(App_DataValidateType LucDataValidate, 
  uint8 LucSeqNo)
{
  boolean LblStepResult;

  LblStepResult = STEP_FAILED;

  switch(LucDataValidate)
  {
    /*
     * Case to handle API invocation with single occurance and to validate
     * parameters of the API with what it has been invoked
     */
    case S_VALIDATE:
    {
      if(Det_GucStartCount == 0x01)
      {
        LblStepResult = STEP_PASSED;
      }
      Det_GucStartCount = 0;
      Det_GucStartSeqCnt = 0;
      break;
    } /* End case S_VALIDATE: */
    
    case S_VALIDATE_SEQ:
    {
      if(Det_GucStartSeqCnt == LucSeqNo)
      {
        LblStepResult = STEP_PASSED;
      }
      Det_GucStartCount = 0;
      Det_GucStartSeqCnt = 0;
      break;
    } /* End case S_VALIDATE_SEQ: */
    
    default:
    {
      LblStepResult = STEP_FAILED;
      break;
    }
  } /* End switch(LucDataValidate) */
  return(LblStepResult);
} /* End TestDet_Start() */

#endif
/*******************************************************************************
**              TestDet_DefaultBehavior()                                     **
*******************************************************************************/
void TestDet_DefaultBehavior(void)
{
  Det_GucReportCount = 0;
  Det_GucReportCheckCount = 0;
  Det_GddRetVal = E_OK;
  Det_GblErrorLog = TRUE;
  #ifdef ECUM_MODULE_ACTIVE
  Det_GucInitCount = 0;
  Det_GucInitSeqCnt = 0;
  Det_GucStartCount = 0;
  Det_GucStartSeqCnt = 0;
  #endif
}

/*******************************************************************************
**                     TestSetDet_ReportErrorRetVal()                         **
*******************************************************************************/
void TestSetDet_ReportErrorRetVal(Std_ReturnType LddRetVal)
{
  Det_GddRetVal = LddRetVal;
}

/*******************************************************************************
**                     TestSetDet_ReportErrorLogEnable()                      **
*******************************************************************************/
void TestSetDet_ReportErrorLogEnable(boolean LblErrorLog)
{
  Det_GblErrorLog = LblErrorLog;
}

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
