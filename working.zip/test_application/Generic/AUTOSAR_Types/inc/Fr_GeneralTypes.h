/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Fr_GeneralTypes.h                                             **
**                                                                            **
**  TARGET    : ALL                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR FR MODULE                                             **
**                                                                            **
**  PURPOSE   : Provision of DataTypes of all Fr Modules header               **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision     Date           By           Description                       **
********************************************************************************
** 1.0.0     30/10/2012     Ravi Tiwari       Initial version                 **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

#ifndef FR_GENERAL_TYPES_H
#define FR_GENERAL_TYPES_H

/*******************************************************************************
**                      Include Section                                      **
*******************************************************************************/
#include "ComStack_Types.h"
#include "Platform_Types.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR SPECIFICATION VERSION INFORMATION */

#define FR_GENERAL_TYPES_AR_MAJOR_VERSION 4
#define FR_GENERAL_TYPES_AR_MINOR_VERSION 0
#define FR_GENERAL_TYPES_AR_PATCH_VERSION 3
/* FR SOFTWARE VERSION INFORMATION */
#define FR_GENERAL_TYPES_SW_MAJOR_VERSION 1
#define FR_GENERAL_TYPES_SW_MINOR_VERSION 0
#define FR_GENERAL_TYPES_SW_PATCH_VERSION 0

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/* Enumeration for CC is synchroniztion */
typedef enum
{
  FR_ASYNC = 0,
  FR_SYNC
} Fr_SyncStateType;

/*Enumeration for offset correction */
typedef enum
{
  FR_OFFSET_INC = 0,
  FR_OFFSET_DEC,
  FR_OFFSET_NOCHANGE
} Fr_OffsetCorrectionType;

/*Enumeration for rate correction */
typedef enum
{
  FR_RATE_INC = 0,
  FR_RATE_DEC,
  FR_RATE_NOCHANGE
} Fr_RateCorrectionType;

/*Enumeration for selecting CC parameters for validating consistency of the
configuration */
typedef enum
{
  FR_PSAMPLESPERMICROTICK_IDX = 0,
  FR_GNUMBEROFSTATICSLOTS_IDX,
  FR_GDSTATICSLOT_IDX,
  FR_GDACTIONPOINTOFFSET_IDX,
  FR_GDTSSTRANSMITTER_IDX,
  FR_GPAYLOADLENGTHSTATIC_IDX,
  FR_GDMINISLOT_IDX,
  FR_GDMINISLOTACTIONPOINTOFFSET_IDX,
  FR_GDNIT_IDX,
  FR_GNETWORKMANAGEMENTVECTORLENGTH_IDX,
  FR_PMACROINITIALOFFSETA_IDX,
  FR_PMACROINITIALOFFSETB_IDX,
  FR_PMICROINITIALOFFSETA_IDX,
  FR_PMICROINITIALOFFSETB_IDX,
  FR_GCOLDSTARTATTEMPTS_IDX,
  FR_GLISTENNOISE_IDX,
  FR_GDCASRXLOWMAX_IDX,
  FR_GDWAKEUPSYMBOLRXIDLE_IDX,
  FR_GDWAKEUPSYMBOLRXLOW_IDX,
  FR_GDWAKEUPSYMBOLTXIDLE_IDX,
  FR_GDWAKEUPSYMBOLTXLOW_IDX,
  FR_PWAKEUPCHANNEL_IDX,
  FR_PWAKEUPPATTERN_IDX,
  FR_PDMAXDRIFT_IDX,
  FR_POFFSETCORRECTIONOUT_IDX,
  FR_PRATECORRECTIONOUT_IDX,
  FR_PKEYSLOTID_IDX,
  FR_GMAXWITHOUTCLOCKCORRECTIONFATAL_IDX,
  FR_GMAXWITHOUTCLOCKCORRECTIONPASSIVE_IDX,
  FR_PALLOWPASSIVETOACTIVE_IDX,
  FR_PCLUSTERDRIFTDAMPING_IDX,
  FR_PDELAYCOMPENSATIONA_IDX,
  FR_PDELAYCOMPENSATIONB_IDX,
  FR_PDECODINGCORRECTION_IDX,
  FR_GDSAMPLECLOCKPERIOD_IDX,
  FR_GDBIT_IDX,
  FR_GMACROPERCYCLE_IDX,
  FR_GNUMBEROFMINISLOTS_IDX,
  FR_GDWAKEUPSYMBOLRXWINDOW_IDX,
  FR_PDACCEPTEDSTARTUPRANGE_IDX,
  FR_GOFFSETCORRECTIONSTART_IDX,
  FR_PLATESTTX_IDX,
  FR_PMICROPERCYCLE_IDX,
  FR_PDLISTENTIMEOUT_IDX,
  FR_PCHANNELSA_IDX,
  FR_PCHANNELSB_IDX,
  FR_PKEYSLOTUSEDFORSTARTUP_IDX,
  FR_PKEYSLOTUSEDFORSYNC_IDX,
  FR_PALLOWHALTDUETOCLOCK_IDX
}Fr_CCLLParamIndexType;

/*Enumeration for POC states correction */
typedef enum
{
  FR_POCSTATE_CONFIG=0,
  FR_POCSTATE_DEFAULT_CONFIG,
  FR_POCSTATE_HALT,
  FR_POCSTATE_NORMAL_ACTIVE,
  FR_POCSTATE_NORMAL_PASSIVE,
  FR_POCSTATE_READY,
  FR_POCSTATE_STARTUP,
  FR_POCSTATE_WAKEUP
}Fr_POCStateType;

/* Fr SlotMode type */
typedef enum
{
  FR_SLOTMODE_KEYSLOT=0,
  FR_SLOTMODE_ALL_PENDING,
  FR_SLOTMODE_ALL
}Fr_SlotModeType;

/* Fr Error Mode type */
typedef enum
{
  FR_ERRORMODE_ACTIVE=0,
  FR_ERRORMODE_PASSIVE,
  FR_ERRORMODE_COMM_HALT
}Fr_ErrorModeType;

/* Fr Wakeup Status type */
typedef enum
{
  FR_WAKEUP_UNDEFINED=0,
  FR_WAKEUP_RECEIVED_HEADER,
  FR_WAKEUP_RECEIVED_WUP,
  FR_WAKEUP_COLLISION_HEADER,
  FR_WAKEUP_COLLISION_WUP,
  FR_WAKEUP_COLLISION_UNKNOWN,
  FR_WAKEUP_TRANSMITTED
}Fr_WakeupStatusType;

/* Fr Strartup State type */
typedef enum
{
  FR_STARTUP_UNDEFINED=0,
  FR_STARTUP_COLDSTART_LISTEN,
  FR_STARTUP_INTEGRATION_COLDSTART_CHECK,
  FR_STARTUP_COLDSTART_JOIN,
  FR_STARTUP_COLDSTART_COLLISION_RESOLUTION,
  FR_STARTUP_COLDSTART_CONSISTENCY_CHECK,
  FR_STARTUP_INTEGRATION_LISTEN,
  FR_STARTUP_INITIALIZE_SCHEDULE,
  FR_STARTUP_INTEGRATION_CONSISTENCY_CHECK,
  FR_STARTUP_COLDSTART_GAP
}Fr_StartupStateType;

/* Fr POC Status Type */
typedef struct
{
  Fr_POCStateType State;
  boolean Freeze;
  boolean CHIHaltRequest;
  boolean ColdstartNoise;
  Fr_SlotModeType SlotMode;
  Fr_ErrorModeType ErrorMode;
  Fr_WakeupStatusType WakeupStatus;
  Fr_StartupStateType StartupState;
}Fr_POCStatusType;

/* Enumeration for Transmission status */
typedef enum
{
  FR_TRANSMITTED = 0,
  FR_NOT_TRANSMITTED
} Fr_TxLPduStatusType;

/* Enumeration for Receive status */
typedef enum
{
  FR_RECEIVED = 0,
  FR_NOT_RECEIVED,
  FR_RECEIVED_MORE_DATA_AVAILABLE
} Fr_RxLPduStatusType;

/* Enumeration for MTS status */
typedef enum
{
  FR_MTS_RCV = 0,
  FR_MTS_RCV_SYNERR,
  FR_MTS_RCV_BVIO,
  FR_MTS_RCV_SYNERR_BVIO,
  FR_MTS_NOT_RCV,
  FR_MTS_NOT_RCV_SYNERR,
  FR_MTS_NOT_RCV_BVIO,
  FR_MTS_NOT_RCV_SYNERR_BVIO
}Fr_MTSStatusType;

/* Fr Channel type */
typedef enum
{
  FR_CHANNEL_A=0,
  FR_CHANNEL_B,
  FR_CHANNEL_AB
}Fr_ChannelType;

/* Fr Transceiver mode type*/
typedef enum
{
  FRTRCV_TRCVMODE_NORMAL,
  FRTRCV_TRCVMODE_STANDBY,
  FRTRCV_TRCVMODE_SLEEP,
  FRTRCV_TRCVMODE_RECEIVEONLY
}FrTrcv_TrcvModeType;

/* Fr Transceiver wakeup reason type*/
typedef enum
{
  FRTRCV_WU_NOT_SUPPORTED,
  FRTRCV_WU_BY_BUS,
  FRTRCV_WU_BY_PIN,
  FRTRCV_WU_INTERNALLY,
  FRTRCV_WU_RESET,
  FRTRCV_WU_POWER_ON
}FrTrcv_TrcvWUReasonType;

/* Macros for Configuration Parameter indices */
/* Symbolic names that can be passed into API function Fr_ReadCCConfig as 
   parameter Fr_ConfigParamIdx*/
   
#define   FR_CIDX_GDCYCLE       	                (0U)
#define   FR_CIDX_PMICROPERCYCLE	                (1U)
#define   FR_CIDX_PDLISTENTIMEOUT	                (2U)
#define   FR_CIDX_GMACROPERCYCLE	                (3U)
#define   FR_CIDX_GDMACROTICK	                    (4U)
#define   FR_CIDX_GNUMBEROFMINISLOTS	            (5U)
#define   FR_CIDX_GNUMBEROFSTATICSLOTS	          (6U)
#define   FR_CIDX_GDNIT	                          (7U)
#define   FR_CIDX_GDSTATICSLOT	                  (8U)
#define   FR_CIDX_GDWAKEUPRXWINDOW	              9U
#define   FR_CIDX_PKEYSLOTID	                    (10U)
#define   FR_CIDX_PLATESTTX 	                    (11U)
#define   FR_CIDX_POFFSETCORRECTIONOUT	          (12U)
#define   FR_CIDX_POFFSETCORRECTIONSTART	        (13U)
#define   FR_CIDX_PRATECORRECTIONOUT	            (14U)
#define   FR_CIDX_PSECONDKEYSLOTID	              (15U)
#define   FR_CIDX_PDACCEPTEDSTARTUPRANGE	        (16U)
#define   FR_CIDX_GCOLDSTARTATTEMPTS	            (17U)
#define   FR_CIDX_GCYCLECOUNTMAX	                (18U)
#define   FR_CIDX_GLISTENNOISE	                  (19U)
#define   FR_CIDX_GMAXWITHOUTCLOCKCORRECTFATAL 	  (20U)
#define   FR_CIDX_GMAXWITHOUTCLOCKCORRECTPASSIVE	(21U)
#define   FR_CIDX_GNETWORKMANAGEMENTVECTORLENGTH	(22U)
#define   FR_CIDX_GPAYLOADLENGTHSTATIC	          (23U)
#define   FR_CIDX_GSYNCFRAMEIDCOUNTMAX	          (24U)
#define   FR_CIDX_GDACTIONPOINTOFFSET	            (25U)
#define   FR_CIDX_GDBIT	                          (26U)
#define   FR_CIDX_GDCASRXLOWMAX	                  (27U)
#define   FR_CIDX_GDDYNAMICSLOTIDLEPHASE	        (28U)
#define   FR_CIDX_GDMINISLOTACTIONPOINTOFFSET	    (29U)
#define   FR_CIDX_GDMINISLOT	                    (30U)
#define   FR_CIDX_GDSAMPLECLOCKPERIOD	            (31U)
#define   FR_CIDX_GDSYMBOLWINDOW	                (32U)
#define   FR_CIDX_GDSYMBOLWINDOWACTIONPOINTOFFSET	(33U)
#define   FR_CIDX_GDTSSTRANSMITTER	              (34U)
#define   FR_CIDX_GDWAKEUPRXIDLE	                (35U)
#define   FR_CIDX_GDWAKEUPRXLOW	                  (36U)
#define   FR_CIDX_GDWAKEUPTXACTIVE	              (37U)
#define   FR_CIDX_GDWAKEUPTXIDLE	                (38U)
#define   FR_CIDX_PALLOWPASSIVETOACTIVE	          (39U)
#define   FR_CIDX_PCHANNELS 	                    (40U)
#define   FR_CIDX_PCLUSTERDRIFTDAMPING	          (41U)
#define   FR_CIDX_PDECODINGCORRECTION	            (42U)
#define   FR_CIDX_PDELAYCOMPENSATIONA	            (43U)
#define   FR_CIDX_PDELAYCOMPENSATIONB	            (44U)
#define   FR_CIDX_PMACROINITIALOFFSETA	          (45U)
#define   FR_CIDX_PMACROINITIALOFFSETB	          (46U)
#define   FR_CIDX_PMICROINITIALOFFSETA	          (47U)
#define   FR_CIDX_PMICROINITIALOFFSETB	          (48U)
#define   FR_CIDX_PPAYLOADLENGTHDYNMAX	          (49U)
#define   FR_CIDX_PSAMPLESPERMICROTICK 	          (50U)
#define   FR_CIDX_PWAKEUPCHANNEL	                (51U)
#define   FR_CIDX_PWAKEUPPATTERN	                (52U)
#define   FR_CIDX_PDMICROTICK	                    (53U)
#define   FR_CIDX_GDIGNOREAFTERTX	                (54U)
#define   FR_CIDX_PALLOWHALTDUETOCLOCK 	          (55U)
#define   FR_CIDX_PEXTERNALSYNC	                  (56U)
#define   FR_CIDX_PFALLBACKINTERNAL	              (57U)
#define   FR_CIDX_PKEYSLOTONLYENABLED	            (58U)
#define   FR_CIDX_PKEYSLOTUSEDFORSTARTUP	        (59U)
#define   FR_CIDX_PKEYSLOTUSEDFORSYNC	            (60U)
#define   FR_CIDX_PNMVECTOREARLYUPDATE	          (61U)
#define   FR_CIDX_PTWOKEYSLOTMODE       	        (62U)

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#endif  /* FR_GENERAL_TYPES_H */

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
