/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: ComStack_Cfg.h                                                **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BSW R4.0.3 Modules                                    **
**                                                                            **
**  PURPOSE   : Provision for Communication Stack Configuration file          **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: yes                                       **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     04/06/2012    MKT    Initial version                             **
*******************************************************************************/

/******************************************************************************/

#ifndef COMSTACK_CFG_H
#define COMSTACK_CFG_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/*
 * AUTOSAR specification version information
 */
#define COMSTACK_CFG_AR_RELEASE_MAJOR_VERSION      4
#define COMSTACK_CFG_AR_RELEASE_MINOR_VERSION      0
#define COMSTACK_CFG_AR_RELEASE_REVISION_VERSION   3

/*
 * File version information
 */
#define COMSTACK_CFG_SW_MAJOR_VERSION        1
#define COMSTACK_CFG_SW_MINOR_VERSION        0

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/


/*******************************************************************************
**                      Global Data Types (ECU dependent)                     **
*******************************************************************************/
/* Chapter 8.1.1 */
typedef uint8        PduIdType;     /* Type of PDU ID.
                                       Allowed ranges: uint8 .. uint16 */

/* Chapter 8.1.2 */
typedef uint32       PduLengthType; /* Type of PDU Length.
                                       Allowed ranges: uint8 .. uint32 */
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#endif /* COMSTACK_CFG_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
