/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Std_Types.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BSW R4.0.3 Modules                                    **
**                                                                            **
**  PURPOSE   : Provision of Standard Types.                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     09-May-2014    KPIT    Initial version                           **
*******************************************************************************/

#ifndef STD_TYPES_H
#define STD_TYPES_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Compiler.h"                  /* mapping compiler specific keywords */
#include "Platform_Types.h"            /* platform specific type definitions */

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/*
 * File version information
*/

/*
 * AUTOSAR specification version information
 */
#define STD_AR_RELEASE_MAJOR_VERSION 4
#define STD_AR_RELEASE_MINOR_VERSION 4
#define STD_AR_RELEASE_PATCH_VERSION 0

/*
 * File version information
 */
#define STDTYPES_SW_MAJOR_VERSION 1
#define STDTYPES_SW_MINOR_VERSION 0
#define STDTYPES_SW_PATCH_VERSION 0

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/

/* for OSEK compliance this typedef has been added */
#ifndef STATUSTYPEDEFINED
  #define STATUSTYPEDEFINED

typedef unsigned char StatusType;
  #define E_OK      (uint8)0x00

#endif

/*
  The Std_ReturnType (STD005) may be used with the following values (STD011):
  E_OK:     0
  E_NOT_OK: 1
*/
typedef uint8 Std_ReturnType;
#define E_NOT_OK               (uint8)0x01
/* user specific */
#define E_PENDING              (uint8)0x02 
#define E_NO_DTC_AVAILABLE     0x03
#define E_SESSION_NOT_ALLOWED  0x04
#define E_PROTOCOL_NOT_ALLOWED 0x05
#define E_REQUEST_NOT_ACCEPTED 0x08
#define E_REQUEST_ENV_NOK      0x09
#define E_COMPARE_KEY_FAILED   0x01
#define E_FORCE_RCRRP          0x0C
#define DEM_E_NO_DTC_AVAILABLE 0x03
/* ComM return types */
#define COMM_E_MODE_LIMITATION 0x02
#define COMM_E_UNINIT          0x03

typedef struct
{
   uint16 vendorID;
   uint16 moduleID;
   uint8  sw_major_version;
   uint8  sw_minor_version;
   uint8  sw_patch_version;
} Std_VersionInfoType; /* STD015                                */


#define STD_HIGH    (uint8)0x01  /* Physical state 5V or 3.3V             */
#define STD_LOW     (uint8)0x00  /* Physical state 0V                     */

#define STD_ACTIVE  0x01  /* Logical state active                  */
#define STD_IDLE    0x00  /* Logical state idle                    */

#ifndef STD_ON             /* avoid clash with existing definitions */
   #define STD_ON       0x01
#endif

#ifndef STD_OFF            /* avoid clash with existing definitions */
   #define STD_OFF      0x00
#endif

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#endif  /* STD_TYPES_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
