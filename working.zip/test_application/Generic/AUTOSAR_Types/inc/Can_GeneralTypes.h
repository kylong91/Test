/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Can_GeneralTypes.h                                            **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BSW R4.0.3 Modules                                    **
**                                                                            **
**  PURPOSE   : Provision for Communication Stack dependent types             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: yes                                       **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     04/06/2012    MKT    Initial version                             **
*******************************************************************************/

/******************************************************************************/

#ifndef CAN_GENERALTYPES_H
#define CAN_GENERALTYPES_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/*
 * AUTOSAR specification version information
 */
#define CAN_GENERALTYPES_AR_MAJOR_VERSION 4
#define CAN_GENERALTYPES_AR_MINOR_VERSION 0
#define CAN_GENERALTYPES_AR_PATCH_VERSION 3

/*
 * File version information
 */
#define CAN_GENERALTYPES_SW_MAJOR_VERSION 1
#define CAN_GENERALTYPES_SW_MINOR_VERSION 0
#define CAN_GENERALTYPES_SW_PATCH_VERSION 0

/*******************************************************************************
**                      Global Data Types (ECU independent)                   **
*******************************************************************************/
typedef uint32 Can_IdType;
typedef uint16 Can_HwHandleType;

/* This is used to provide CAN-ID, DLC and SDU from CanIf to CAN Driver */
typedef struct Can_PduType
{
  /* CAN-ID */
  Can_IdType id;
  /* DLC */
  uint8 length;
  /* Pointer to L-SDU */
  uint8 *sdu;
  /* swPduHandle */
  PduIdType swPduHandle ;
} Can_PduType;

/* State transitions that are used by the function Can_SetControllerMode */
typedef enum
{
  CAN_T_START = 0,
  CAN_T_STOP,
  CAN_T_SLEEP,
  CAN_T_WAKEUP
}Can_StateTransitionType;

/* Return values of CAN Driver API */
typedef enum
{
  CAN_OK = 0,
  CAN_NOT_OK,
  CAN_BUSY
}Can_ReturnType;


/* CanTrcv163 */
typedef enum
{
  CANTRCV_TRCVMODE_NORMAL = 0,
  CANTRCV_TRCVMODE_SLEEP,
  CANTRCV_TRCVMODE_STANDBY
} CanTrcv_TrcvModeType;

/* CanTrcv164 */
typedef enum
{
  CANTRCV_WUMODE_ENABLE = 0,
  CANTRCV_WUMODE_CLEAR,
  CANTRCV_WUMODE_DISABLE  
} CanTrcv_TrcvWakeupModeType;

/* CanTrcv164 */
typedef enum
{
  CANTRCV_WU_ERROR = 0, 
  CANTRCV_WU_BY_BUS,
  CANTRCV_WU_BY_PIN, 
  CANTRCV_WU_INTERNALLY,
  CANTRCV_WU_NOT_SUPPORTED,
  CANTRCV_WU_POWER_ON,
  CANTRCV_WU_RESET
} CanTrcv_TrcvWakeupReasonType;

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#endif /* CAN_GENERALTYPES_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
