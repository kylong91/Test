/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: ComStack_Types.h                                              **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BSW R4.0.3 Modules                                    **
**                                                                            **
**  PURPOSE   : Provision for Communication Stack dependent types             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: yes                                       **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     04/06/2012    MKT    Initial version                             **
*******************************************************************************/

#ifndef COMSTACK_TYPES_H
#define COMSTACK_TYPES_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

#include "Std_Types.h"                  /* Standard AUTOSAR types           */
#include "ComStack_Cfg.h"               /* Communication Stack Configuration 
                                           file */

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/*
 * AUTOSAR specification version information
 */
#define COMSTACK_TYPES_AR_RELEASE_MAJOR_VERSION      4
#define COMSTACK_TYPES_AR_RELEASE_MINOR_VERSION      0
#define COMSTACK_TYPES_AR_RELEASE_REVISION_VERSION   3

/*
 * File version information
 */
#define COMSTACK_TYPES_SW_MAJOR_VERSION        1
#define COMSTACK_TYPES_SW_MINOR_VERSION        0

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/
/* COMTYPE018 General return codes for NotifResultType */
#define NTFRSLT_OK                     (uint8)0x00
#define NTFRSLT_E_NOT_OK               (uint8)0x01
#define NTFRSLT_E_TIMEOUT_A            (uint8)0x02
#define NTFRSLT_E_TIMEOUT_BS           (uint8)0x03
#define NTFRSLT_E_TIMEOUT_CR           (uint8)0x04
#define NTFRSLT_E_WRONG_SN             (uint8)0x05
#define NTFRSLT_E_INVALID_FS           (uint8)0x06
#define NTFRSLT_E_UNEXP_PDU            (uint8)0x07
#define NTFRSLT_E_WFT_OVRN             (uint8)0x08
#define NTFRSLT_E_ABORT                (uint8)0x09
#define NTFRSLT_E_NO_BUFFER            (uint8)0x0A
#define NTFRSLT_E_CANCELATION_OK       (uint8)0x0B
#define NTFRSLT_E_CANCELATION_NOT_OK   (uint8)0x0C
#define NTFRSLT_PARAMETER_OK           (uint8)0x0D
#define NTFRSLT_E_PARAMETER_NOT_OK     (uint8)0x0E
#define NTFRSLT_E_RX_ON                (uint8)0x0F
#define NTFRSLT_E_VALUE_NOT_OK         (uint8)0x10
#define NTFRSLT_E_FR_ML_MISMATCH       (uint8)0x5B
#define NTFRSLT_E_FR_WRONG_BP          (uint8)0x5C
#define NTFRSLT_E_FR_TX_ON             (uint8)0x5D
/* COMTYPE021 General return codes for BusTrcvErrorType */
#define BUSTRCV_OK                     (uint8)0x00
#define BUSTRCV_E_ERROR                (uint8)0x01

/*******************************************************************************
**                      Global Data Types (ECU dependent)                     **
*******************************************************************************/
/* Chapter 8.1.6 */
typedef uint8        NotifResultType;

/* Chapter 8.1.7 */
typedef uint8        BusTrcvErrorType;

/* Chapter 8.1.10 */
typedef uint8        NetworkHandleType;

typedef uint8        PNCHandleType;

/*******************************************************************************
**                      Global Data Types (ECU independent)                   **
*******************************************************************************/

/* Chapter 8.1.3 */
typedef struct STag_PduInfoType
{
  P2VAR(uint8,AUTOMATIC,AUTOSAR_COMSTACKDATA) SduDataPtr;
  PduLengthType  SduLength;
} PduInfoType;                   /* Basic information about a PDU of any type */
/* Chapter 8.1.8 */
typedef enum
{
  TP_DATACONF,
  TP_DATARETRY,
  TP_CONFPENDING,
  TP_NORETRY
} TpDataStateType;                 /* Store the state of TP buffer          */
/* Chapter 8.1.9 */
typedef struct STag_RetryInfoType
{
  TpDataStateType TpDataState;
  PduLengthType TxTpDataCnt;
} RetryInfoType;                   /* Store the information about Tp buffer 
                                      handling */
/* Chapter 8.1.4 */
typedef enum
{
  STMIN,
  BS,
  BC
} TPParameterType;             /* parameter to which the value has to be changed
                                  (BS or STmin)          */
/* Chapter 8.1.5 */
typedef enum
{
  BUFREQ_OK,
  BUFREQ_E_NOT_OK,
  BUFREQ_E_BUSY,
  BUFREQ_E_OVFL
} BufReq_ReturnType;                 /* result of a buffer request          */

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#endif /* COMSTACK_TYPES_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
