/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: Lin_GeneralTypes.h                                            **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BSW R4.0.3 Modules                                    **
**                                                                            **
**  PURPOSE   : Provision for Lin Communication Stack dependent types         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     04/06/2012    MKT    Initial version                             **
*******************************************************************************/

#ifndef LIN_GENERALTYPES_H
#define LIN_GENERALTYPES_H

/*******************************************************************************
**                      Include Section                                      **
*******************************************************************************/

#include "ComStack_Types.h"   /* ComStack types header file */
#include "Std_Types.h"        /* Type definition header file */

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/*
 * AUTOSAR specification version information
 */
#define LIN_GENERALTYPES_AR_MAJOR_VERSION 4
#define LIN_GENERALTYPES_AR_MINOR_VERSION 0
#define LIN_GENERALTYPES_AR_PATCH_VERSION 3

/*
 * File version information
 */
#define LIN_GENERALTYPES_SW_MAJOR_VERSION 1
#define LIN_GENERALTYPES_SW_MINOR_VERSION 0
#define LIN_GENERALTYPES_SW_PATCH_VERSION 0

/*******************************************************************************
**                      Global Data Types (ECU independent)                   **
*******************************************************************************/
/* Lin Protected Identifiers Type */
typedef uint8 Lin_FramePidType;

/* Checksum type to be used for LIN Frame */
typedef enum 
{
  LIN_CLASSIC_CS = 0,
  LIN_ENHANCED_CS  
} Lin_FrameCsModelType;

/* LIN Frame Types */
typedef enum
{
  LIN_MASTER_RESPONSE = 0,
  LIN_SLAVE_RESPONSE,
  LIN_SLAVE_TO_SLAVE
} Lin_FrameResponseType;

/* Lin Frame data length  */
typedef uint8 Lin_FrameDlType;

/* Lin PDU Type */
typedef struct
{
  Lin_FramePidType      Pid;
  Lin_FrameCsModelType  Cs;
  Lin_FrameResponseType Drc;
  Lin_FrameDlType	Dl;
  uint8	*SduPtr;
} Lin_PduType;

/* Lin Frame or Channel Status Types */
typedef enum
{
  LIN_NOT_OK = 0,
  LIN_TX_OK,
  LIN_TX_BUSY,
  LIN_TX_HEADER_ERROR,
  LIN_TX_ERROR,
  LIN_RX_OK,
  LIN_RX_BUSY,
  LIN_RX_ERROR,
  LIN_RX_NO_RESPONSE,
  LIN_OPERATIONAL,
  LIN_CH_SLEEP  
} Lin_StatusType;

/* Enum for TrcvWakeupReasonType mode */
typedef enum
{
  /* Due to an error wake up reason was not detected. */
  LINTRCV_WU_ERROR = 0,
  /* The transceiver does not support any information for the wake up reason. */
  LINTRCV_WU_NOT_SUPPORTED,
  /* The transceiver has detected, that the network has caused the wake up of 
   * the ECU. 
  */
  LINTRCV_WU_BY_BUS,
  /* The transceiver has detected a wake-up event at one of the transceiver's 
   * pins (not at the LIN bus).
  */
  LINTRCV_WU_BY_PIN,
  /* The transceiver has detected, that the network has woken up by the ECU via 
   * a request to NORMAL mode.
  */
  LINTRCV_WU_INTERNALLY,
  /* The transceiver has detected, that the wake up is due to an ECU reset. */
  LINTRCV_WU_RESET,
  /* The transceiver has detected, that the wake up is due to an ECU reset after
   * power on.
  */
  LINTRCV_WU_POWER_ON
}LinTrcv_TrcvWakeupReasonType;

typedef enum
{
  LINTRCV_TRCV_MODE_NORMAL = 0,
  LINTRCV_TRCV_MODE_STANDBY,
  LINTRCV_TRCV_MODE_SLEEP
}LinTrcv_TrcvModeType;

typedef enum
{
  LINTRCV_WUMODE_ENABLE = 0,
  LINTRCV_WUMODE_DISABLE,
  LINTRCV_WUMODE_CLEAR
}LinTrcv_TrcvWakeupModeType;

#endif  /* LIN_GENERALTYPES_H */

/*******************************************************************************
**                          END OF FILE                                       **
*******************************************************************************/
