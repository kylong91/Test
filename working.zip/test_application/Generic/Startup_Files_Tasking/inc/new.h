/**************************************************************************
**
**  FILE        :  new.h
**
**  DESCRIPTION :  Include file for C++ default operator new
**
**  COPYRIGHT   :  Copyright 1998-2012 Altium BV
**
**************************************************************************/

#ifndef __NEW_H
#define __NEW_H

#include <tasking_config.h>
#include __TASKING_CXX_NATIVE_HEADER(new)

#endif  /* ifndef __NEW_H */
