/**************************************************************************
**
**  FILE        :  defines.h
**
**  DESCRIPTION :  Common definitions for the current target
**
**  COPYRIGHT   :  Copyright 1998-2012 Altium BV
**
**************************************************************************/

#ifndef _DEFINES_H
#define _DEFINES_H

#include "tasking_def.h"

/*
 * Include target specific defines
 */

#endif /* _DEFINES_H */
