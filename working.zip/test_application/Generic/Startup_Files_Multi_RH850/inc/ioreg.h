/***
 * Copyright (C) 2013 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 ***/


#define	OSTM0_BASE	0xffec0000
#define	OSTM0CMP	(*((volatile unsigned int   *)OSTM0_BASE))
#define	OSTM0CNT	(*((volatile unsigned char  *)(OSTM0_BASE + 0x04)))
#define	OSTM0TO		(*((volatile unsigned char  *)(OSTM0_BASE + 0x08)))
#define	OSTM0TOE	(*((volatile unsigned char  *)(OSTM0_BASE + 0x0c)))
#define	OSTM0TE		(*((volatile unsigned char  *)(OSTM0_BASE + 0x10)))
#define	OSTM0TS		(*((volatile unsigned char  *)(OSTM0_BASE + 0x14)))
#define	OSTM0TT		(*((volatile unsigned char  *)(OSTM0_BASE + 0x18)))
#define	OSTM0CTL	(*((volatile unsigned char  *)(OSTM0_BASE + 0x20)))
#define	ADDR_EIC76	(*((volatile unsigned char  *) 0xffffa098))

