#define VECTOR_C
/******************************************************************************
*
*   Freescale(TM) and the Freescale logo are trademarks of Freescale Semiconductor, Inc. 
*   All other product or service names are the property of their respective owners. 
*   (c) Copyright 2013 Freescale Semiconductor Inc.
*   All Rights Reserved.
*
*   You can use this example for any purpose on any computer system with the
*   following restrictions:
*
*   1. This example is provided  as is , without warranty.
*
*   2. You don't remove this copyright notice from this example or any direct
*      derivation thereof.
*
* Description:    Vector table for OS/MPC5600
*
* Notes:
*
******************************************************************************/
#include <Os.h>
#include <app_compiler_abstraction.h>

#define OSVECTORS_START_SEC_CODE
#include <MemMap.h>

#if defined(OSDIABPPC)
#define VEC_ALIGN   asm volatile (" .skip 0x0C ")
#endif

#if defined(OSGHSPPC)
#define VEC_ALIGN   asm (" .skip 0x0C ")
#endif

#if defined(OSDIABPPC) || defined(OSGHSPPC)
    PPCASMF(   .globl VTABLE                   );
    PPCASMF(VTABLE:                            ); /* Vector table start address */

#elif defined(OSCWPPC)  /* defined(OSDIABPPC) || defined(OSGHSPPC) */

extern void OSCriticalException( void );
extern void OSMachineCheckException( void );
extern void OSNonCriticalException( void );
extern void OSInterruptDispatcher( void );
extern void OSSystemCallHandler( void );
extern void OSTLBErrorException( void );
extern void OSDebugException( void );
extern void VTABLE( void );
#define SIXTEEN_BYTES 16
#pragma force_active on
#pragma function_align 16

#define VEC_ALIGN  .align SIXTEEN_BYTES

asm void VTABLE( void )
{
    nofralloc
#endif

#if 0
    PPCASMF(    e_b   OSCriticalException        ); /* Critical input */

    VEC_ALIGN;
    PPCASMF(    e_b   OSMachineCheckException        ); /* Machine check */

    VEC_ALIGN;
    PPCASMF(    e_b   OSDataStorageException    ); /* Data storage */

    VEC_ALIGN;
    PPCASMF(    e_b   OSNonCriticalException     ); /* Instruction storage */

    VEC_ALIGN;
    PPCASMF(    e_b   OSInterruptDispatcher      ); /* External input */

    VEC_ALIGN;
    PPCASMF(    e_b   OSNonCriticalException     ); /* Alignment */

    VEC_ALIGN;
    PPCASMF(    e_b   OSNonCriticalException     ); /* Program */

    VEC_ALIGN;
    PPCASMF(    e_b   OSNonCriticalException     ); /* Floating-point unavailable */

    VEC_ALIGN;
#if defined(OSSC3) || defined(OSSC4)              /* System call */
    PPCASMF(    e_b   OSSystemCallHandler        );
#else
    PPCASMF(    e_b   OSNonCriticalException     );
#endif

    VEC_ALIGN;
    PPCASMF(    e_b   OSNonCriticalException     );

    VEC_ALIGN;
    PPCASMF(    e_b   OSNonCriticalException     );  /* Decrementer */

    VEC_ALIGN;
    PPCASMF(    e_b   OSNonCriticalException     );  /* Fixed Interval Timer */

    VEC_ALIGN;
    PPCASMF(    e_b   OSCriticalException        ); /* Watchdog Timer */

    VEC_ALIGN;
#if defined(OSSC3)  || defined(OSSC4)
    PPCASMF(    e_b   OSTLBErrorException        ); /* Data TLB Error */
#else
    PPCASMF(    e_b   OSNonCriticalException     );
#endif

    VEC_ALIGN;
#if defined(OSSC3)  || defined(OSSC4)
    PPCASMF(    e_b   OSTLBErrorException        ); /* Instruction TLB Error */
#else
    PPCASMF(    e_b   OSNonCriticalException     );
#endif

    VEC_ALIGN;
    PPCASMF(    e_b   OSDebugException           ); /* Debug */
#endif

#if defined(OSCWPPC)
}
#endif

#define OSVECTORS_STOP_SEC_CODE
#include <MemMap.h>


#if defined(FLASH_START)

#define SRAM_BASE_ADDR 0x40000000


/* The size of internal RAM */
#if defined(OSMPC5602P)
        #define OSLOOP_SIZE (20*1024)>>7

    #elif defined(OSMPC5604P)
        #define OSLOOP_SIZE (40*1024)>>7

    #elif defined(OSMPC5602D)
        #define OSLOOP_SIZE (16*1024)>>7

    #elif defined(OSMPC5604B)
        #define OSLOOP_SIZE (48*1024)>>7

    #elif defined(OSMPC5606B)
        #define OSLOOP_SIZE (80*1024)>>7

    #elif defined(OSMPC5607B)
        #define OSLOOP_SIZE (96*1024)>>7

    #else
        #error "MCU type is not specified"
#endif


/* Code to initialize all internal RAM.
   This must be executed before using RAM to avoid ECC errors. */
#if defined(OSDIABPPC) || defined(OSGHSPPC)

    PPCASMF2( .set BASE_SRAM_ADDRESS, SRAM_BASE_ADDR );
    PPCASMF2( .set OS_LOOP_SIZE, OSLOOP_SIZE         );
#if defined(OSGHSPPC)

    PPCASMF(     .globl __ghs_board_memory_init      );
    PPCASMF( __ghsautoimport_ghs_board_memory_init:  );
    PPCASMF( __ghs_board_memory_init:                );
#else

    PPCASMF(    .globl          usr_init             );
    PPCASMF( usr_init:                               );
#endif

    PPCASMF2(    e_lis r11,%hi(BASE_SRAM_ADDRESS)    );

#elif defined(OSCWPPC)
void usr_init( void );    
asm void usr_init( void )
{
    nofralloc

    PPCASMF2(    e_lis r11,SRAM_BASE_ADDR@h          );    /* Base address of the L2SRAM, 64-bit word aligned */
#endif
    
    PPCASMF2(    e_li r12,OSLOOP_SIZE                );/* Loop counter to get all of L2SRAM; SIZE/4 bytes/32 GPRs */
    PPCASMF(     mtctr r12                           );

    PPCASMF( init_l2sram_loop:                       );
    PPCASMF2(    e_stmw r0,0(r11)                    );/* Write all 32 GPRs to L2SRAM */
    PPCASMF3(    e_addi r11,r11,128                  );/* Inc the ram ptr; 32 GPRs * 4 bytes = 128 */
    PPCASMF(     e_bdnz init_l2sram_loop             );/* Branch OSLOOP_SIZE-1 times */
    PPCASMF(     se_blr                              );

#if defined(OSCWPPC)
}
#endif

#endif /* if defined(FLASH_START) */
