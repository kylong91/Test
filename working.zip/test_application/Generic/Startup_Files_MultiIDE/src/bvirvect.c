#define OS_ASM_ALIGN_INTCVEC      .align 4

void VirtualVectorTable(void);

#pragma ghs section text=".VT_VECT_TBL"

/* This table is located at a fixed address to handle it from Boot SW */

void VirtualVectorTable(void)
{
#pragma asm
    OS_ASM_ALIGN_INTCVEC
    e_b _start
#pragma endasm
}