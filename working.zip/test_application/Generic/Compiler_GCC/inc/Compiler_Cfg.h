/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: Compiler_Cfg.h                                                **
**                                                                            **
**  TARGET    : x86                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BSW R4.0.3 Modules                                    **
**                                                                            **
**  PURPOSE   : This file contains compiler macro                             **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: yes                                       **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision Control History                              **
********************************************************************************
********************************************************************************
** 1.0.2     09-Mar-2015   Sinil   Wdg related macros are added               **
** 1.0.1     25-Feb-2015   SW.Lee  TcpIp related macros are added             **
** 1.0.0     09-Sep-2012   MKT    Initial Version                             **
*******************************************************************************/
/******************************************************************************/
#ifndef COMPILER_CFG_H
#define COMPILER_CFG_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Version Information                                  **
*******************************************************************************/
/*
 * AUTOSAR specification version information
 */
#define COMPILER_CFG_AR_MAJOR_VERSION  4
#define COMPILER_CFG_AR_MINOR_VERSION  0
#define COMPILER_CFG_AR_PATCH_VERSION  3

/*
 * File version information
 */
#define COMPILER_CFG_SW_MAJOR_VERSION  1
#define COMPILER_CFG_SW_MINOR_VERSION  0

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/

/*******************************************************************************
 **                      Configuration data                                   **
*******************************************************************************/
/*
 * The following memory and pointer classes can be configured per module.
 * These #defines are passed to the compiler abstraction macros in Compiler.h
 *
 * Note:
 * module internal functions (statics) that get into one section
 * (together with API) shall fit into one page.
 */

 #define AUTOSAR_COMSTACKDATA

/* ---------------------------------------------------------------------------*/
/*                                  CAL                                       */
/* ---------------------------------------------------------------------------*/
#define CAL_CODE                       /* memory class for code             */
#define CAL_VAR_POWER_ON_INIT
#define CAL_VAR_NOINIT
#define CAL_CONST
#define CAL_APPL_DATA                  /* Applications' RAM Data            */
/* ---------------------------------------------------------------------------*/
/*                                  CSM                                       */
/* ---------------------------------------------------------------------------*/ 
#define CSM_CODE                       /* memory class for code             */
#define CSM_VAR_POWER_ON_INIT
#define CSM_VAR_NOINIT
#define CSM_CONST
#define CSM_APPL_DATA                  /* Applications' RAM Data            */

/* --------------------------------------------------------------------------*/
/*                   TCPIP                                                */
/* --------------------------------------------------------------------------*/
#define TCPIP_CODE        /* To be used for code API Functions              */ 
#define TCPIP_CN_CODE     /* To be used for callout code <CN> is the callback 
                                   name (including module reference) written in 
							                uppercase letters                              */
#define TCPIP_CODE_FAST   /* To be used for code that shall go into fast code 
                               memory segments. The FAST sections should be used
							   when the execution does not happen in a well-
							   defined period time but with the knowledge of 
							   high frequent access and /or high execution time,
							   for example, a callback for a frequent 
							   notification.                          */
#define TCPIP_CODE_SLOW   /* To be used for code that shall go into slow code 
                               memory segments. The SLOW sections should be used
							   when the execution does not happen in a well-
							   defined period time but with the knowledge of low
							   frequent access,for example, a callback in case 
							   of seldom error.                               */
#define TCPIP_CONST       /* To be used for global or static constants      */
#define TCPIP_CONFIG_DATA /* To be used for module configuration constants  */
#define TCPIP_APPL_DATA	/* To be used for references on application data 
                               (expected to be in RAM or ROM) passed via API  */ 
#define TCPIP_APPL_CONST  /* To be used for references on application 
                               constants (expected to be certainly in ROM, for 
							   instance pointer of Init-function) passed via 
							   API                                            */
#define TCPIP_APPL_CODE                  /* Callbacks of the Application      */
									   
/* <INIT_POLICY> is the initialization policy of variables. 
   Possible values are:
   NO_INIT: Used for variables that are never cleared and never initialized.
   CLEARED: Used for variables that are cleared to zero after every reset.
   POWER_ON_CLEARED: Used for variables that are cleared to zero only after 
   power on reset.
   INIT: Used for variables that are initialized with values after every reset.
   POWER_ON_INIT: Used for variables that are initialized with values only after
   power on reset                                                             */
   
/* <PREFIX>_VAR_<INIT_POLICY> To be used for all global or static variables.  */
#define TCPIP_VAR_NO_INIT			
#define TCPIP_VAR_CLEARED         
#define TCPIP_VAR_POWER_ON_CLEARED
#define TCPIP_VAR_INIT            
#define TCPIP_VAR_POWER_ON_INIT   									  
 
/* <PREFIX>_VAR_FAST_<INIT_POLICY> To be used for all global or static 
variables that have at least one of the following properties:
A. accessed bitwise
B. frequently used
C. high number of accesses in source code
Some platforms allow the use of bit instructions for variables located in this 
specific RAM area as well as shorter addressing instructions. This saves code 
and runtime.                                                                  */									   
#define TCPIP_VAR_FAST_NO_INIT	
#define TCPIP_VAR_FAST_CLEARED    
#define TCPIP_VAR_FAST_POWER_ON_CLEARED
#define TCPIP_VAR_FAST_INIT       
#define TCPIP_VAR_FAST_POWER_ON_INIT 

/* <PREFIX>_VAR_SLOW_<INIT_POLICY> To be used for all infrequently accessed 
global or static variables                                                    */										
#define TCPIP_VAR_SLOW_NO_INIT
#define TCPIP_VAR_SLOW_CLEARED
#define TCPIP_VAR_SLOW_POWER_ON_CLEARED
#define TCPIP_VAR_SLOW_INIT
#define TCPIP_VAR_SLOW_POWER_ON_INIT


/* --------------------------------------------------------------------------*/
/*                   SOAD                                                */
/* --------------------------------------------------------------------------*/
#define SOAD_CODE        /* To be used for code API Functions              */ 
#define SOAD_CN_CODE     /* To be used for callout code <CN> is the callback 
                                   name (including module reference) written in 
							                uppercase letters                              */
#define SOAD_CODE_FAST   /* To be used for code that shall go into fast code 
                               memory segments. The FAST sections should be used
							   when the execution does not happen in a well-
							   defined period time but with the knowledge of 
							   high frequent access and /or high execution time,
							   for example, a callback for a frequent 
							   notification.                          */
#define SOAD_CODE_SLOW   /* To be used for code that shall go into slow code 
                               memory segments. The SLOW sections should be used
							   when the execution does not happen in a well-
							   defined period time but with the knowledge of low
							   frequent access,for example, a callback in case 
							   of seldom error.                               */
#define SOAD_CONST       /* To be used for global or static constants      */
#define SOAD_CONFIG_DATA /* To be used for module configuration constants  */
#define SOAD_APPL_DATA	/* To be used for references on application data 
                               (expected to be in RAM or ROM) passed via API  */ 
#define SOAD_APPL_CONST  /* To be used for references on application 
                               constants (expected to be certainly in ROM, for 
							   instance pointer of Init-function) passed via 
							   API                                            */
#define SOAD_APPL_CODE                  /* Callbacks of the Application      */
									   
/* <INIT_POLICY> is the initialization policy of variables. 
   Possible values are:
   NO_INIT: Used for variables that are never cleared and never initialized.
   CLEARED: Used for variables that are cleared to zero after every reset.
   POWER_ON_CLEARED: Used for variables that are cleared to zero only after 
   power on reset.
   INIT: Used for variables that are initialized with values after every reset.
   POWER_ON_INIT: Used for variables that are initialized with values only after
   power on reset                                                             */
   
/* <PREFIX>_VAR_<INIT_POLICY> To be used for all global or static variables.  */
#define SOAD_VAR_NO_INIT			
#define SOAD_VAR_CLEARED         
#define SOAD_VAR_POWER_ON_CLEARED
#define SOAD_VAR_INIT            
#define SOAD_VAR_POWER_ON_INIT   									  
 
/* <PREFIX>_VAR_FAST_<INIT_POLICY> To be used for all global or static 
variables that have at least one of the following properties:
A. accessed bitwise
B. frequently used
C. high number of accesses in source code
Some platforms allow the use of bit instructions for variables located in this 
specific RAM area as well as shorter addressing instructions. This saves code 
and runtime.                                                                  */									   
#define SOAD_VAR_FAST_NO_INIT	
#define SOAD_VAR_FAST_CLEARED    
#define SOAD_VAR_FAST_POWER_ON_CLEARED
#define SOAD_VAR_FAST_INIT       
#define SOAD_VAR_FAST_POWER_ON_INIT 

/* <PREFIX>_VAR_SLOW_<INIT_POLICY> To be used for all infrequently accessed 
global or static variables                                                    */										
#define SOAD_VAR_SLOW_NO_INIT
#define SOAD_VAR_SLOW_CLEARED
#define SOAD_VAR_SLOW_POWER_ON_CLEARED
#define SOAD_VAR_SLOW_INIT
#define SOAD_VAR_SLOW_POWER_ON_INIT

/* ---------------------------------------------------------------------------*/
/*                   OS                                                     */
/* ---------------------------------------------------------------------------*/

#define OS_CODE                /* API functions                               */
#define OS_CONST               /* API constants                               */

#define OS_VAR                 /* To be used for references on appl data      */
#define OS_CONST          /* To be used for references on appl const     */

#define OS_APPL_CODE           /* Callbacks of the Application                */
#define OS_CALLOUT_CODE        /* To be used for references on appl functions */

#define OS_VAR_NOINIT          /* Data which is not initialized during Startup*/
#define OS_VAR_POWER_ON_INIT   /* Data which is initialized during Startup    */
#define OS_VAR_FAST            /* 'Near' RAM Data                             */

#define OS_VAR                 /*
                                * To be used for global or static variables
                                * that are initialized after every reset */

                                
/*----------------------------------------------------------------------------*/
/*                                  SOAD                                      */
/*----------------------------------------------------------------------------*/
#define SOAD_CODE                /* API functions                               */
#define SOAD_CONST               /* API constants                               */
#define SOAD_APPL_DATA
#define SOAD_VAR                 /* To be used for references on appl data      */
#define SOAD_CONST          /* To be used for references on appl const     */

#define SOAD_APPL_CODE           /* Callbacks of the Application                */
#define SOAD_CALLOUT_CODE        /* To be used for references on appl functions */

#define SOAD_VAR_NOINIT          /* Data which is not initialized during Startup*/
#define SOAD_VAR_POWER_ON_INIT   /* Data which is initialized during Startup    */
#define SOAD_VAR_FAST            /* 'Near' RAM Data                             */

#define SOAD_VAR                 /*
                                * To be used for global or static variables
                                * that are initialized after every reset */                                
/* ---------------------------------------------------------------------------*/
/*                   LINIF                                                    */
/* ---------------------------------------------------------------------------*/

#define LINIF_CODE                       /* memory class for code      */
#define LINIF_DATA               /* Module internal data               */
#define LINIF_CONST              /* Internal ROM Data ,Constant data   */

#define LINIF_APPL_DATA                  /* Applications' RAM Data            */
#define LINIF_APPL_CONST                 /* Applications' ROM Data            */

#define LINIF_APPL_CODE                  /* Callbacks of the Application      */
#define LINIF_CALLOUT_CODE          /* memory class for pointers to application 
                                    functions (e.g. callout function pointers)*/
#define LINIF_VAR_NOINIT            /* Data which is not initialized during
                                           Startup                            */
#define LINIF_VAR_POWER_ON_INIT     /* memory class for all global or static 
                                      variables that are initialized only after 
                                                               power on reset */
#define LINIF_VAR_FAST  /* memory class for all global or static variables that 
                           have at least one of the following properties:
                           1. accessed bitwise 2. frequently used 
                           3.high number of accesses in source code */
#define LINIF_VAR       /* memory class for all global or static variables that
                           are initialized after every reset */

/* ---------------------------------------------------------------------------*/
/*                   LINTP                                                    */
/* ---------------------------------------------------------------------------*/

#define LINTP_CODE                /* API functions                     */
#define LINTP_CONST               /* API constants                     */

#define LINTP_CODE               /* Internal functions                */

#define LINTP_DATA               /* Module internal data              */
#define LINTP_CONST              /* Internal ROM Data                 */

#define LINTP_APPL_CODE                  /* callbacks of the Application      */

#define LINTP_CODE                       /* memory class for code             */
#define LINTP_CONST                      /* Constant data                     */
#define LINTP_APPL_DATA                  /* Applications' RAM Data            */

#define LINTP_APPL_CONST                 /* Applications' ROM Data            */
#define LINTP_APPL_CODE                  /* Callbacks of the Application      */
#define LINTP_CALLOUT_CODE          /* memory class for pointers to application 
                                    functions (e.g. callout function pointers)*/
#define LINTP_VAR_NOINIT            /* Data which is not initialized during
                                           Startup                            */
#define LINTP_VAR_POWER_ON_INIT     /* memory class for all global or static 
                                      variables that are initialized only after 
                                                               power on reset */
#define LINTP_VAR_FAST  /* memory class for all global or static variables that 
                           have at least one of the following properties:
                           1. accessed bitwise 2. frequently used 
                           3.high number of accesses in source code */
#define LINTP_VAR       /* memory class for all global or static variables that
                           are initialized after every reset */
/* ---------------------------------------------------------------------------*/
/*                                  ETHSM                                       */
/* ---------------------------------------------------------------------------*/
#define ETHSM_CODE                       /* memory class for code               */
#define ETHSM_CONST                      /* Constant data                       */
#define ETHSM_APPL_DATA                  /* Applications' RAM Data              */
#define ETHSM_APPL_CONST                 /* Applications' ROM Data              */
#define ETHSM_APPL_CODE                  /* Callbacks of the Application        */
#define ETHSM_CALLOUT_CODE          /* memory class for pointers to application
                                    functions (e.g. callout function pointers)*/
#define ETHSM_VAR_NOINIT            /* Data which is not initialized during
                                           Startup                            */
#define ETHSM_VAR_POWER_ON_INIT     /* memory class for all global or static
                                      variables that are initialized only after
                                                               power on reset */
#define ETHSM_VAR_FAST  /* memory class for all global or static variables that
                           have at least one of the following properties:
                           1. accessed bitwise 2. frequently used
                           3.high number of accesses in source code */
#define ETHSM_VAR       /* memory class for all global or static variables that
                           are initialized after every reset */
/* ---------------------------------------------------------------------------*/
/*                   UDPNM                                                    */
/* ---------------------------------------------------------------------------*/

#define UDPNM_CODE                /* API functions                     */
#define UDPNM_CONST               /* Constant data                     */
#define UDPNM_APPL_DATA           /* Applications' RAM Data            */
#define UDPNM_APPL_CONST          /* Applications' ROM Data            */
#define UDPNM_APPL_CODE           /* Callbacks of the Application      */
#define UDPNM_CALLOUT_CODE    /* memory class for pointers to application
                                    functions (e.g. callout function pointers)*/
#define UDPNM_VAR_NOINIT      /* Data which is not initialized during
                                           Startup                            */
#define UDPNM_VAR_POWER_ON_INIT  /* memory class for all global or static
                                      variables that are initialized only after
                                                               power on reset */
#define UDPNM_VAR_FAST  /* memory class for all global or static
                               variables that have at least one of the
							   following properties:
                               1. accessed bitwise 2. frequently used
                               3.high number of accesses in source code */
#define UDPNM_VAR       /* memory class for all global or static
                               variables that are initialized after
							                                                   every reset */

#define UDPNM_INIT_DATA                  /* Data which is initialized during
                                            Startup                           */
#define UDPNM_NOINIT_DATA                /* Data which is not initialized during
                                            Startup                           */
/* ---------------------------------------------------------------------------*/
/*                                  E2E                                       */
/* ---------------------------------------------------------------------------*/
#define E2E_CODE

#define E2E_CONST
#define E2E_VAR
#define E2E_CODE

#define E2E_APPL_DATA

#define E2E_CODE                       /* memory class for code               */
#define E2E_CONST                      /* Constant data                       */
#define E2E_APPL_DATA                  /* Applications' RAM Data              */
#define E2E_APPL_CONST                 /* Applications' ROM Data              */
#define E2E_APPL_CODE                  /* Callbacks of the Application        */
#define E2E_CALLOUT_CODE          /* memory class for pointers to application 
                                    functions (e.g. callout function pointers)*/
#define E2E_VAR_NOINIT            /* Data which is not initialized during
                                           Startup                            */
#define E2E_VAR_POWER_ON_INIT     /* memory class for all global or static 
                                      variables that are initialized only after 
                                                               power on reset */
#define E2E_VAR_FAST  /* memory class for all global or static variables that 
                           have at least one of the following properties:
                           1. accessed bitwise 2. frequently used 
                           3.high number of accesses in source code */
#define E2E_VAR       /* memory class for all global or static variables that
                           are initialized after every reset */


/* ---------------------------------------------------------------------------*/
/*                   CANTP                                                    */
/* ---------------------------------------------------------------------------*/

#define CANTP_CODE                /* API functions                     */
#define CANTP_CONST               /* API constants                     */

#define CANTP_CODE               /* Internal functions                */

#define CANTP_CONST              /* Internal ROM Data                 */

#define CANTP_APPL_CODE                  /* callbacks of the Application      */

#define CANTP_CODE                       /* memory class for code             */
#define CANTP_CONST                      /* Constant data                     */
#define CANTP_APPL_DATA                  /* Applications' RAM Data            */

#define CANTP_APPL_CONST                 /* Applications' ROM Data            */
#define CANTP_APPL_CODE                  /* Callbacks of the Application      */
#define CANTP_CALLOUT_CODE          /* memory class for pointers to application 
                                    functions (e.g. callout function pointers)*/
#define CANTP_VAR_NOINIT            /* Data which is not initialized during
                                           Startup                            */
#define CANTP_VAR_POWER_ON_INIT     /* memory class for all global or static 
                                      variables that are initialized only after 
                                                               power on reset */
#define CANTP_VAR_FAST  /* memory class for all global or static variables that 
                           have at least one of the following properties:
                           1. accessed bitwise 2. frequently used 
                           3.high number of accesses in source code */
#define CANTP_VAR       /* memory class for all global or static variables that
                           are initialized after every reset */
                           
#define CANTP_ZERO_INIT_DATA 
#define CANTP_NOINIT_DATA                           
/* ---------------------------------------------------------------------------*/
/*                                  STBM                                      */
/* ---------------------------------------------------------------------------*/
#define STBM_CODE                       /* memory class for code              */

#define STBM_CONST                      /* Constant data                      */

#define STBM_APPL_DATA                  /* Applications' RAM Data             */

#define STBM_APPL_CONST                 /* Applications' ROM Data             */

#define STBM_APPL_CODE                  /* Callbacks of the Application       */

#define STBM_CALLOUT_CODE          /* memory class for pointers to application
                                    functions (e.g. callout function pointers)*/

#define STBM_VAR_NOINIT            /* Data which is not initialized during
                                           Startup                            */

#define STBM_VAR_POWER_ON_INIT     /* memory class for all global or static
                                      variables that are initialized only after
                                                               power on reset */

#define STBM_VAR_FAST  /* memory class for all global or static variables that
                           have at least one of the following properties:
                           1. accessed bitwise 2. frequently used
                           3.high number of accesses in source code */

#define STBM_VAR       /* memory class for all global or static variables that
                           are initialized after every reset */

/* ---------------------------------------------------------------------------*/
/*                                  CanTrcv Driver                            */
/* ---------------------------------------------------------------------------*/
#define CANTRCV_6251DS_CODE                /* memory class for code           */
#define CANTRCV_6251DS_CONST               /* Constant data                   */
#define CANTRCV_6251DS_APPL_DATA           /* Applications' RAM Data          */
#define CANTRCV_6251DS_APPL_CONST          /* Applications' ROM Data          */
#define CANTRCV_6251DS_APPL_CODE           /* Callbacks of the Application    */
#define CANTRCV_6251DS_CALLOUT_CODE    /* memory class for pointers to application
                                    functions (e.g. callout function pointers)*/
#define CANTRCV_6251DS_VAR_NOINIT      /* Data which is not initialized during
                                           Startup                            */
#define CANTRCV_6251DS_VAR_POWER_ON_INIT  /* memory class for all global or static
                                      variables that are initialized only after
                                                               power on reset */
#define CANTRCV_6251DS_VAR_FAST  /* memory class for all global or static
                               variables that have at least one of the
							   following properties:
                               1. accessed bitwise 2. frequently used
                               3.high number of accesses in source code */
#define CANTRCV_6251DS_VAR       /* memory class for all global or static
                               variables that are initialized after
							   every reset */

/* ---------------------------------------------------------------------------*/
/*                   CANNM                                                    */
/* ---------------------------------------------------------------------------*/

#define CANNM_CODE                /* API functions                     */
#define CANNM_CONST               /* Constant data                     */
#define CANNM_APPL_DATA           /* Applications' RAM Data            */
#define CANNM_APPL_CONST          /* Applications' ROM Data            */
#define CANNM_APPL_CODE           /* Callbacks of the Application      */
#define CANNM_CALLOUT_CODE    /* memory class for pointers to application
                                    functions (e.g. callout function pointers)*/
#define CANNM_VAR_NOINIT      /* Data which is not initialized during
                                           Startup                            */
#define CANNM_VAR_POWER_ON_INIT  /* memory class for all global or static
                                      variables that are initialized only after
                                                               power on reset */
#define CANNM_VAR_FAST  /* memory class for all global or static
                               variables that have at least one of the
							   following properties:
                               1. accessed bitwise 2. frequently used
                               3.high number of accesses in source code */
#define CANNM_VAR       /* memory class for all global or static
                               variables that are initialized after
							                                                   every reset */

#define CANNM_INIT_DATA                  /* Data which is initialized during
                                            Startup                           */
#define CANNM_NOINIT_DATA                /* Data which is not initialized during
                                            Startup                           */
/* ---------------------------------------------------------------------------*/
/*                   FRNM                                                    */
/* ---------------------------------------------------------------------------*/
#define FRNM_PUBLIC_CODE                /* API functions                     */

#define FRNM_CODE                /* memory class for code             */
#define FRNM_CONST               /* Constant data                     */
#define FRNM_APPL_DATA           /* Applications' RAM Data            */
#define FRNM_APPL_CONST          /* Applications' ROM Data            */
#define FRNM_APPL_CODE           /* Callbacks of the Application      */
#define FRNM_CALLOUT_CODE    /* memory class for pointers to application 
                                    functions (e.g. callout function pointers)*/
#define FRNM_VAR_NOINIT      /* Data which is not initialized during
                                           Startup                            */
#define FRNM_VAR_POWER_ON_INIT  /* memory class for all global or static 
                                      variables that are initialized only after 
                                                               power on reset */
#define FRNM_VAR_FAST  /* memory class for all global or static 
                               variables that have at least one of the 
							   following properties:
                               1. accessed bitwise 2. frequently used 
                               3.high number of accesses in source code */
#define FRNM_VAR       /* memory class for all global or static 
                               variables that are initialized after 
							   every reset */                 


                                            
/* ---------------------------------------------------------------------------*/
/*                                  ETHIF                                     */
/* ---------------------------------------------------------------------------*/
#define ETHIF_CODE                       /* memory class for code             */
#define ETHIF_CONST                      /* Constant data                     */
#define ETHIF_APPL_DATA                  /* Applications' RAM Data            */
#define ETHIF_APPL_CONST                 /* Applications' ROM Data            */
#define ETHIF_APPL_CODE                  /* Callbacks of the Application      */
#define ETHIF_CALLOUT_CODE          /* memory class for pointers to application 
                                    functions (e.g. callout function pointers)*/
#define ETHIF_VAR_NOINIT            /* Data which is not initialized during
                                           Startup                            */
#define ETHIF_VAR_POWER_ON_INIT     /* memory class for all global or static 
                                      variables that are initialized only after 
                                                               power on reset */
#define ETHIF_VAR_FAST  /* memory class for all global or static variables that 
                           have at least one of the following properties:
                           1. accessed bitwise 2. frequently used 
                           3.high number of accesses in source code */
#define ETHIF_VAR       /* memory class for all global or static variables that
                           are initialized after every reset 
                           are initialized after every reset */
/* ---------------------------------------------------------------------------*/
/*                                  J1939TP                                   */
/* ---------------------------------------------------------------------------*/
#define J1939TP_CODE                       /* memory class for code           */
#define J1939TP_CONST                      /* Constant data                   */
#define J1939TP_APPL_DATA                  /* Applications' RAM Data          */
#define J1939TP_APPL_CONST                 /* Applications' ROM Data          */
#define J1939TP_APPL_CODE                  /* Callbacks of the Application    */
#define J1939TP_CALLOUT_CODE         /* memory class for pointers to application
                                   functions (e.g. callout function pointers)*/
#define J1939TP_VAR_NOINIT            /* Data which is not initialized during
                                           Startup                            */
#define J1939TP_VAR_POWER_ON_INIT     /* memory class for all global or static
                                      variables that are initialized only after
                                                               power on reset */
#define J1939TP_VAR_FAST /* memory class for all global or static variables that
                           have at least one of the following properties:
                           1. accessed bitwise 2. frequently used
                           3.high number of accesses in source code */
#define J1939TP_VAR      /* memory class for all global or static variables that
                           are initialized after every reset */

/* ---------------------------------------------------------------------------*/
/*                   DOIP                                                    */
/* ---------------------------------------------------------------------------*/

#define DOIP_CODE                /* API functions                     */
#define DOIP_CONST               /* Constant data                     */
#define DOIP_APPL_DATA           /* Applications' RAM Data            */
#define DOIP_APPL_CONST          /* Applications' ROM Data            */
#define DOIP_APPL_CODE           /* Callbacks of the Application      */
#define DOIP_CALLOUT_CODE    /* memory class for pointers to application
                                    functions (e.g. callout function pointers)*/
#define DOIP_VAR_NOINIT      /* Data which is not initialized during
                                           Startup                            */
#define DOIP_VAR_POWER_ON_INIT  /* memory class for all global or static
                                      variables that are initialized only after
                                                               power on reset */
#define DOIP_VAR_FAST  /* memory class for all global or static
                               variables that have at least one of the
							   following properties:
                               1. accessed bitwise 2. frequently used
                               3.high number of accesses in source code */
#define DOIP_VAR       /* memory class for all global or static
                               variables that are initialized after
							                                                   every reset */

#define DOIP_INIT_DATA                  /* Data which is initialized during
                                            Startup                           */
#define DOIP_NOINIT_DATA                /* Data which is not initialized during
                                            Startup                           */    
/* ---------------------------------------------------------------------------*/
/*                             LINNM                                          */
/* ---------------------------------------------------------------------------*/
#define LINNM_VAR                   /* For variables which are initialised
                                       during startup */
#define LINNM_CODE                  /* APIs and functions            */

#define LINNM_APPL_CODE                   /* memory class for pointers to
                                      application functions
                                      (e.g. call back function pointers)   */

#define LINNM_CALLOUT_CODE            /* memory class for pointers to
                                      application functions
                                     (e.g. callout function pointers).  */

#define LINNM_VAR_NOINIT            /* For variables that are
                                        never initialised */

#define LINNM_VAR_POWER_ON_INIT     /* For variables that are
                                    initialized only after power on reset */

#define LINNM_VAR_FAST              /* For variables that are
                          either accessed bitwise or frequently used or have
                           high number of accesses in source code */

#define LINNM_APPL_CONST           /* memory class for pointers to application
                                     constants  */

#define LINNM_APPL_DATA            /* Memory class for pointers to application
                                      data            */

#define LINNM_CONST                /* Data Constants                    */

/* ---------------------------------------------------------------------------*/
/*                             MEMIF                                          */
/* ---------------------------------------------------------------------------*/
#define MEMIF_CODE                       /* API functions */

/* ---------------------------------------------------------------------------*/
/*                             WDGIF                                          */
/* ---------------------------------------------------------------------------*/
#define WDGIF_CODE                       /* API functions */
#define WDGIF_CONST
#define WDGIF_APPL_DATA            /* Memory class for pointers to application
                                      data            */

/* ---------------------------------------------------------------------------*/
/*                             WDG_39_ACW                                     */
/* ---------------------------------------------------------------------------*/
#define WDG_39_ACW_CODE                  /* API functions                     */
#define WDG_39_ACW_CONST                 /* Constant data                     */

/* ---------------------------------------------------------------------------*/
/*                   FRTP                                                    */
/* ---------------------------------------------------------------------------*/
#define FRTP_CODE                       /* API functions                     */

#define FRTP_APPL_CODE                  /* callbacks of the Application      */
#define FRTP_APPL_CONST                 /* Applications' ROM Data            */
#define FRTP_APPL_DATA                  /* Applications' RAM Data            */

#define FRTP_CONST                      /* Data Constants                    */

/* ---------------------------------------------------------------------------*/
/*                   LINSM                                                    */
/* ---------------------------------------------------------------------------*/
#define LINSM_CODE                       /* memory class for code             */

#define LINSM_CONST                      /* Constant data                     */

#define LINSM_APPL_DATA                  /* Applications' RAM Data            */

#define LINSM_APPL_CONST                 /* Applications' ROM Data            */

#define LINSM_APPL_CODE                  /* Callbacks of the Application      */

#define LINSM_VAR       /* memory class for all global or static variables that
                           are initialized after every reset */
/* ---------------------------------------------------------------------------*/
/*                   FRIF                                                    */
/* ---------------------------------------------------------------------------*/
#define FRIF_CODE                /* API functions                             */

#define FRIF_CONST               /* API constants                             */

#define FRIF_APPL_CODE                  /* callbacks of the Application      */

#define FRIF_APPL_CONST                 /* Applications' ROM Data            */

#define FRIF_APPL_DATA                  /* Applications' RAM Data            */

#define FRIF_VAR       /* memory class for all global or static variables that
                           are initialized after every reset */

#define FRIF_VAR_NOINIT            /* For variables that are
                                        never initialised */

#define FRIF_VAR_POWER_ON_INIT     /* For variables that are
                                    initialized only after power on reset */

/* ---------------------------------------------------------------------------*/
/*                   FrSM                                                    */
/* ---------------------------------------------------------------------------*/

#define FRSM_CODE                       /* API functions                     */

#define FRSM_CONST                      /* API constants                     */

#define FRSM_APPL_DATA                  /* Applications' RAM Data            */

#define FRSM_APPL_CONST                  /* Applications' ROM Data            */

#define FRSM_VAR_POWER_ON_INIT           /* Data which is initialized during
                                           Startup                           */
#define FRSM_VAR_NOINIT                /* Data which is not initialized during
                                            Startup                           */
#define FRSM_VAR                /* Data which is not initialized during
                                            Startup                           */
/* ---------------------------------------------------------------------------*/
/*                   FrTrcv                                                   */
/* ---------------------------------------------------------------------------*/

#define FRTRCV_1080A_CODE                /* API functions */

#define FRTRCV_1080A_CONST                      /* API constants       */

#define FRTRCV_1080A_APPL_DATA                  /* Applications' RAM Data   */

#define FRTRCV_1080A_APPL_CONST                  /* Applications' ROM Data   */

#define FRTRCV_1080A_VAR_POWER_ON_INIT    /* Data which is initialized during
                                           * Startup   */
#define FRTRCV_1080A_VAR_NOINIT /* Data which is not initialized during
                                 * Startup */
#define FRTRCV_1080A_VAR                /* Data which is not initialized during
                                            Startup */
/* ---------------------------------------------------------------------------*/
/*                   FIM                                                    */
/* ---------------------------------------------------------------------------*/
#define FIM_CODE                       /* API functions                       */

#define FIM_VAR                       /* Module internal data                */

#define FIM_APPL_CONST                 /* Applications' ROM Data              */

#define FIM_APPL_DATA                  /* Applications' RAM Data              */

#define FIM_VAR_POWER_ON_INIT          /* Data which is initialized during
                                          Startup                           */

#define FIM_CONST                      /* Data Constants                      */

#define FIM_VAR_NOINIT                 /* Data which is not initialized during
                                           Startup                            */

/* ---------------------------------------------------------------------------*/
/*                   BswM                                                     */
/* ---------------------------------------------------------------------------*/
#define BSWM_CODE                /* API functions                      */

#define BSWM_CONST               /* API constants                      */

#define BSWM_APPL_CONST                 /* Applications' ROM Data             */

#define BSWM_APPL_DATA                  /* Applications' RAM Data             */

#define BSWM_VAR_NOINIT               /* Data which is not initialized during
                                          Startup                             */
#define BSWM_VAR_POWER_ON_INIT             /* Data which is initialized with ZERO
                                         during startup                       */


/* ---------------------------------------------------------------------------*/
/*                                  CANIF                                     */
/* ---------------------------------------------------------------------------*/

#define CANIF_CODE                /* API functions                     */
#define CANIF_CONST               /* API constants                     */

#define CANIF_CODE               /* Internal functions                */

#define CANIF_CONST              /* Internal ROM Data                 */

#define CANIF_APPL_CODE                  /* callbacks of the Application      */

#define CANIF_CODE                       /* memory class for code             */
#define CANIF_CONST                      /* Constant data                     */
#define CANIF_APPL_DATA                  /* Applications' RAM Data            */

#define CANIF_APPL_CONST                 /* Applications' ROM Data            */
#define CANIF_APPL_CODE                  /* Callbacks of the Application      */
#define CANIF_CALLOUT_CODE          /* memory class for pointers to application
                                    functions (e.g. callout function pointers)*/
#define CANIF_VAR_NOINIT            /* Data which is not initialized during
                                           Startup                            */
#define CANIF_VAR_POWER_ON_INIT     /* memory class for all global or static
                                      variables that are initialized only after
                                                               power on reset */
#define CANIF_VAR_FAST  /* memory class for all global or static variables that
                           have at least one of the following properties:
                           1. accessed bitwise 2. frequently used
                           3.high number of accesses in source code */
#define CANIF_VAR       /* memory class for all global or static variables that
                           are initialized after every reset */


/* ---------------------------------------------------------------------------*/
/*                   CANSM                                                    */
/* ---------------------------------------------------------------------------*/

#define CANSM_CODE                /* API functions                     */
#define CANSM_CONST               /* API constants                     */
#define CANSM_APPL_CODE                  /* callbacks of the Application      */

#define CANSM_CODE                       /* memory class for code             */
#define CANSM_CONST                      /* Constant data                     */
#define CANSM_APPL_DATA                  /* Applications' RAM Data            */

#define CANSM_APPL_CONST                 /* Applications' ROM Data            */

#define CANSM_APPL_DATA                  /* Applications' RAM Data            */
#define CANSM_CALLOUT_CODE          /* memory class for pointers to application
                                    functions (e.g. callout function pointers)*/
#define CANSM_VAR_POWER_ON_INIT     /* memory class for all global or static
                                      variables that are initialized only after
                                                               power on reset */
#define CANSM_VAR_FAST  /* memory class for all global or static variables that
                           have at least one of the following properties:
                           1. accessed bitwise 2. frequently used
                           3.high number of accesses in source code */

#define CANSM_VAR                       /* Data which is initialized during
                                          Startup                             */
#define CANSM_VAR_NOINIT                /* Data which is not initialized during
                                          Startup                             */
#define CANSM_CONST                      /* Data Constants                    */

#define CANSM_APPL_CODE                  /* Callbacks of the Application      */
#define CANSM_CALLOUT_CODE          /* memory class for pointers to application
                                    functions (e.g. callout function pointers)*/
#define CANSM_VAR_NOINIT            /* Data which is not initialized during
                                           Startup                            */
#define CANSM_VAR_POWER_ON_INIT     /* memory class for all global or static
                                      variables that are initialized only after
                                                               power on reset */
#define CANSM_VAR_FAST  /* memory class for all global or static variables that
                           have at least one of the following properties:
                           1. accessed bitwise 2. frequently used
                           3.high number of accesses in source code */
#define CANSM_VAR       /* memory class for all global or static variables that
                           are initialized after every reset */

/* ---------------------------------------------------------------------------*/
/*                   IPDUM                                                    */
/* ---------------------------------------------------------------------------*/
#define IPDUM_CODE                       /* memory class for code             */
#define IPDUM_CONST                      /* Constant data                     */
#define IPDUM_APPL_DATA                  /* Applications' RAM Data            */
#define IPDUM_APPL_CONST                 /* Applications' ROM Data            */
#define IPDUM_APPL_CODE                  /* Callbacks of the Application      */
#define IPDUM_CALLOUT_CODE          /* memory class for pointers to application
                                    functions (e.g. callout function pointers)*/
#define IPDUM_VAR_NOINIT            /* Data which is not initialized during
                                           Startup                            */
#define IPDUM_VAR_POWER_ON_INIT     /* memory class for all global or static
                                      variables that are initialized only after
                                                               power on reset */
#define IPDUM_VAR_FAST  /* memory class for all global or static variables that
                           have at least one of the following properties:
                           1. accessed bitwise 2. frequently used
                           3.high number of accesses in source code */
#define IPDUM_VAR       /* memory class for all global or static variables that
                           are initialized after every reset */

/* ---------------------------------------------------------------------------*/
/*                       COMM                                                 */
/* ---------------------------------------------------------------------------*/
#define COMM_CODE                /* API functions                      */
#define COMM_CONST               /* API constants                      */
#define COMM_APPL_CODE           /* Callbacks of the Application       */
#define COMM_APPL_CONST          /* Applications' ROM Data             */
#define COMM_APPL_DATA           /* Applications' RAM Data             */
#define COMM_VAR_NOINIT          /* Data is not initialized during Startup */
#define COMM_VAR_POWER_ON_INIT   /* Data which is initialized with ZERO */


/* --------------------------------------------------------------------------*/
/*                   PDUR                                                     */
/* ---------------------------------------------------------------------------*/
#define PDUR_CODE                /* API functions */
#define PDUR_CONST               /* API constants */
#define PDUR_APPL_CODE           /* callbacks of the Application */
#define PDUR_APPL_DATA           /* Applications' RAM Data */
#define PDUR_APPL_CONST          /* Applications' ROM Data */
#define PDUR_CALLOUT_CODE        /* memory class for pointers to application
                                    functions (e.g. callout function pointers)*/
#define PDUR_VAR_NOINIT          /* Data which is not initialized during
                                    Startup                            */
#define PDUR_VAR_POWER_ON_INIT   /* memory class for all global or static
                                    variables that are initialized only after
                                                               power on reset */
#define PDUR_VAR_FAST  /* memory class for all global or static variables that
                           have at least one of the following properties:
                           1. accessed bitwise 2. frequently used
                           3.high number of accesses in source code */
#define PDUR_VAR       /* memory class for all global or static variables that
                           are initialized after every reset */
/* ---------------------------------------------------------------------------*/
/*                        CRC                                                */
/* ---------------------------------------------------------------------------*/

#define CRC_CODE                           /*  functions                      */

#define CRC_APPL_CONST                  /* Applications' ROM Data             */
#define CRC_APPL_DATA                   /* Applications' RAM Data             */

#define CRC_CONST                       /* Data Constants                     */

/* ---------------------------------------------------------------------------*/
/*                   EA                                                       */
/* ---------------------------------------------------------------------------*/

#define EA_CODE                /* API functions                        */
#define EA_CONST               /* API constants                        */

#define EA_APPL_DATA                  /* Applications' RAM Data            */
#define EA_APPL_CONST                 /* Applications' ROM Data            */

#define EA_VAR_NOINIT            /* Data which is not initialized during */

#define EA_VAR_POWER_ON_INIT            /* Data which is initialized with ZERO
                                         during startup                       */

/* ---------------------------------------------------------------------------*/
/*                                  LinTrcv Driver                           */
/* ---------------------------------------------------------------------------*/
#define LINTRCV_7259GE_CODE             /* API functions                     */
#define LINTRCV_7259GE_CONST            /* API constants                     */
#define LINTRCV_7259GE_APPL_DATA        /* Applications' RAM Data            */
#define LINTRCV_7259GE_VAR_NOINIT       /* Data which is not initialized during
                                              Startup                         */
#define LINTRCV_7259GE_VAR       /* memory class for all global or static
                            variables that are initialized after every reset */

/* ---------------------------------------------------------------------------*/
/*                           ECUM                                             */
/* ---------------------------------------------------------------------------*/
#define ECUM_CODE                       /* API functions                      */
#define ECUM_CALLOUT_CODE               /* Callouts                           */

#define ECUM_APPL_CODE                  /* callbacks of the Application       */
#define ECUM_APPL_CONST                 /* Applications' ROM Data             */
#define ECUM_APPL_DATA                  /* Applications' RAM Data             */

#define ECUM_VAR_NOINIT                 /* Data which is not initialized during
                                          Startup                             */
#define ECUM_VAR                        /* Data which is initialized during
                                          Startup                             */
#define ECUM_CONST                      /* Data Constants                     */
#define ECUM_VAR_POWER_ON_INIT             /* Data which is initialized to zero
                                           during Startup                     */

/* ---------------------------------------------------------------------------*/
/*                   NVM                                                      */
/* ---------------------------------------------------------------------------*/
#define NVM_CODE                /* API functions                       */
#define NVM_CONST               /* API constants                       */
#define NVM_VAR_NOINIT            /* Data which is not initialized during
                                           Startup                            */
#define NVM_VAR_POWER_ON_INIT     /* memory class for all global or static 
                                      variables that are initialized only after 
                                                               power on reset */
#define NVM_APPL_CODE                  /* callbacks of the Application        */
#define NVM_APPL_CONST                 /* Applications' ROM Data              */
#define NVM_APPL_DATA                  /* Applications' RAM Data              */

/* ---------------------------------------------------------------------------*/
/*                   DEM                                                       */
/* ---------------------------------------------------------------------------*/

#define DEM_CODE                /* API functions                        */
#define DEM_CONST               /* API constants                        */

#define DEM_APPL_DATA                  /* Applications' RAM Data            */
#define DEM_APPL_CONST                 /* Applications' ROM Data            */
#define DEM_APPL_CODE                /* Callbacks of the Application      */

#define DEM_VAR_NOINIT            /* Data which is not initialized during */

#define DEM_VAR             /* Global or static variables that are initialized
                               after every reset. */
/* ---------------------------------------------------------------------------*/
/*                   NM                                                       */
/* ---------------------------------------------------------------------------*/
#define NM_CODE                       /* API functions                        */

#define NM_APPL_CODE                  /* callbacks of the Application         */
#define NM_APPL_CONST                 /* Applications' ROM Data               */
#define NM_APPL_DATA                  /* Applications' RAM Data               */
#define NM_VAR_NOINIT
#define NM_VAR_POWER_ON_INIT

#define NM_CONST                      /* Data Constants                       */

/* ---------------------------------------------------------------------------*/
/*                             DET                                          */
/* ---------------------------------------------------------------------------*/
#define DET_CODE                       /* API functions                       */
#define DET_CONST                      /* Internal ROM Data                   */
#define DET_APPL_CODE                  /* Callbacks of the Application        */
#define DET_APPL_CONST                 /* Applications' ROM Data              */
#define DET_APPL_DATA                  /* Applications' RAM Data              */

/* ---------------------------------------------------------------------------*/
/*                   DBG                                                      */
/* ---------------------------------------------------------------------------*/
#define DBG_CODE                       /* API functions                       */

#define DBG_APPL_CODE                  /* callbacks of the Application        */
#define DBG_APPL_CONST                 /* Applications' ROM Data              */
#define DBG_APPL_DATA                  /* Applications' RAM Data              */
#define DBG_VAR_NOINIT                 /* Data which is not initialized during
                                           Startup                            */
#define DBG_VAR_POWER_ON_INIT          /* memory class for all global or static 
                     variables that are initialized only after power on reset */
#define DBG_CONST                      /* Data Constants                      */

/* ---------------------------------------------------------------------------*/
/*                       TC_GENERIC                                           */
/* ---------------------------------------------------------------------------*/
#define TCGENERIC_APPL_CODE                /* pointer class for pointers to
                                      application functions
                                      (e.g. call back function pointers)   */

/* ---------------------------------------------------------------------------*/
/*                             COM                                          */
/* ---------------------------------------------------------------------------*/
#define COM_VAR                   /* For variables which are initialised
                                       during startup */
#define COM_CODE                  /* APIs and functions            */

#define COM_APPL_CODE                   /* memory class for pointers to
                                      application functions
                                      (e.g. call back function pointers)   */

#define COM_CALLOUT_CODE            /* memory class for pointers to
                                      application functions
                                     (e.g. callout function pointers).  */

#define COM_VAR_NOINIT            /* For variables that are
                                        never initialised */

#define COM_VAR_POWER_ON_INIT     /* For variables that are
                                    initialized only after power on reset */

#define COM_VAR_FAST              /* For variables that are
                          either accessed bitwise or frequently used or have
                           high number of accesses in source code */

#define COM_APPL_CONST           /* memory class for pointers to application
                                     constants  */

#define COM_APPL_DATA            /* Memory class for pointers to application
                                      data            */

#define COM_CONST                /* Data Constants                    */
/* --------------------------------------------------------------------------*/
/*                       DLT                                                 */
/* --------------------------------------------------------------------------*/
#define DLT_CODE                /* API functions                     */



#define DLT_APPL_CODE                  /* Callbacks of the Application      */
#define DLT_APPL_CONST                 /* Applications' ROM Data            */
#define DLT_APPL_DATA                  /* Applications' RAM Data            */

#define DLT_VAR_NOINIT                  /* Data which is not initialized during
                                           Startup                           */
#define DLT_VAR_POWER_ON_INIT             /* Data which is initialized with ZERO
                                            during startup                    */
#define DLT_CONST                      /* Constant data                     */

/* --------------------------------------------------------------------------*/
/*                       WDGM                                                 */
/* --------------------------------------------------------------------------*/
#define WDGM_CODE                /* API functions                     */

#define WDGM_DATA                /* Constant data */

#define WDGM_APPL_CODE                  /* Callbacks of the Application      */
#define WDGM_APPL_CONST                 /* Applications' ROM Data            */
#define WDGM_APPL_DATA                  /* Applications' RAM Data            */

#define WDGM_VAR_NOINIT                  /* Data which is not initialized during
                                           Startup */
#define WDGM_VAR_POWER_ON_INIT            /* Data which is initialized with ZERO
                                            during startup                    */
#define WDGM_CONST                       /* Constant data                     */

/* ---------------------------------------------------------------------------*/
/*                             DCM                                            */
/* ---------------------------------------------------------------------------*/
#define DCM_VAR                   /* For variables which are initialised
                                       during startup */
#define DCM_CODE                  /* APIs and functions            */

#define DCM_APPL_CODE                   /* memory class for pointers to
                                      application functions
                                      (e.g. call back function pointers)   */

#define DCM_CALLOUT_CODE            /* memory class for pointers to
                                      application functions
                                     (e.g. callout function pointers).  */

#define DCM_VAR_POWER_ON_INIT     /* For variables that are
                                    initialized only after power on reset */

#define DCM_APPL_CONST           /* memory class for pointers to application
                                     constants  */

#define DCM_APPL_DATA            /* Memory class for pointers to application
                                      data            */

#define DCM_CONST                /* Data Constants                    */

/* ---------------------------------------------------------------------------*/
/*                   XCP                                                     */
/* ---------------------------------------------------------------------------*/


#define XCP_CODE                  /* callbacks of the Application       */
#define XCP_DATA                  /* Applications' RAM Data             */

#define XCP_VAR_NOINIT               /* Data which is not initialized during */
#define XCP_CONST                      /* Data Constants                     */
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#endif /* COMPILER_CFG_H */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
