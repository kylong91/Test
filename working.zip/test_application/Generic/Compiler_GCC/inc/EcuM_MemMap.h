/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: MemMap.h                                                      **
**                                                                            **
**  TARGET    : x86                                                           **
**                                                                            **
**  PRODUCT   : Memmap sections for ECUM Module                               **
**                                                                            **
**  PURPOSE   : Provision for sections for memory mapping.                    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: yes                                       **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date           By                  Description                   **
********************************************************************************
** 1.0.1     30-Jan-2014   Srujana K            Updated EcuM memory section   **
** 1.0.0     04-Oct-2013   Amruta K             Initial Version               **
*******************************************************************************/
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR specification version information */
#define ECUM_MEMMAP_AR_MAJOR_VERSION   4
#define ECUM_MEMMAP_AR_MINOR_VERSION   0
#define ECUM_MEMMAP_AR_PATCH_VERSION   3

/* File version information */
#define ECUM_MEMMAP_SW_MAJOR_VERSION   1
#define ECUM_MEMMAP_SW_MINOR_VERSION   0

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Module section mapping                                **
*******************************************************************************/
/*
 * The symbol 'START_WITH_IF' is undefined.
 *
 * Thus, the preprocessor continues searching for defined symbols.
 * This first #ifdef makes integration of delivered parts of MemMap.h
 * easier because every supplier starts with #elif
 */

#if defined (START_WITH_IF)

/* -------------------------------------------------------------------------- */
/*             ECUM                                                          */
/* -------------------------------------------------------------------------- */
#elif defined (ECUM_START_SEC_CONFIG_CONST_32)
   #undef      ECUM_START_SEC_CONFIG_CONST_32
   #define ECUM_START_SEC_CONFIG_CONST_32
#elif defined (ECUM_STOP_SEC_CONFIG_CONST_32)
   #undef      ECUM_STOP_SEC_CONFIG_CONST_32
   #define ECUM_STOP_SEC_CONFIG_CONST_32
   
#elif defined (ECUM_START_SEC_CONFIG_CONST_UNSPECIFIED)
   #undef      ECUM_START_SEC_CONFIG_CONST_UNSPECIFIED
   #define ECUM_START_SEC_CONFIG_CONST_UNSPECIFIED
#elif defined (ECUM_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
   #undef      ECUM_STOP_SEC_CONFIG_CONST_UNSPECIFIED
   #define ECUM_STOP_SEC_CONFIG_CONST_UNSPECIFIED
   
#elif defined (ECUM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      ECUM_START_SEC_VAR_CLEARED_BOOLEAN
   #define ECUM_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (ECUM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      ECUM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define ECUM_STOP_SEC_VAR_CLEARED_BOOLEAN
   
#elif defined (ECUM_START_SEC_VAR_CLEARED_32)
   #undef      ECUM_START_SEC_VAR_CLEARED_32
   #define ECUM_START_SEC_VAR_CLEARED_32
#elif defined (ECUM_STOP_SEC_VAR_CLEARED_32)
   #undef      ECUM_STOP_SEC_VAR_CLEARED_32
   #define ECUM_STOP_SEC_VAR_CLEARED_32
   
#elif defined (ECUM_START_SEC_VAR_CLEARED_16)
   #undef      ECUM_START_SEC_VAR_CLEARED_16
   #define ECUM_START_SEC_VAR_CLEARED_16
#elif defined (ECUM_STOP_SEC_VAR_CLEARED_16)
   #undef      ECUM_STOP_SEC_VAR_CLEARED_16
   #define ECUM_STOP_SEC_VAR_CLEARED_16

#elif defined (ECUM_START_SEC_VAR_NO_INIT_8)
   #undef      ECUM_START_SEC_VAR_NO_INIT_8
   #define ECUM_START_SEC_VAR_NO_INIT_8
#elif defined (ECUM_STOP_SEC_VAR_NO_INIT_8)
   #undef      ECUM_STOP_SEC_VAR_NO_INIT_8
   #define ECUM_STOP_SEC_VAR_NO_INIT_8

#elif defined (ECUM_START_SEC_VAR_POWER_ON_CLEARED_16)
   #undef      ECUM_START_SEC_VAR_POWER_ON_CLEARED_16 
   #define ECUM_START_SEC_VAR_POWER_ON_CLEARED_16
#elif defined (ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_16)
   #undef      ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_16
   #define ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_16
   
#elif defined (ECUM_START_SEC_VAR_POWER_ON_CLEARED_32)
   #undef      ECUM_START_SEC_VAR_POWER_ON_CLEARED_32 
   #define ECUM_START_SEC_VAR_POWER_ON_CLEARED_32
#elif defined (ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_32)
   #undef      ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_32
   #define ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_32
   
#elif defined (ECUM_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      ECUM_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define ECUM_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
#elif defined (ECUM_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      ECUM_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define ECUM_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED

#elif defined (ECUM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
   #undef      ECUM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED 
   #define ECUM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
#elif defined (ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
   #undef      ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
   #define ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED

#elif defined (ECUM_START_SEC_CONST_32)
   #undef      ECUM_START_SEC_CONST_32
   #define ECUM_START_SEC_CONST_32
#elif defined (ECUM_STOP_SEC_CONST_32)
   #undef      ECUM_STOP_SEC_CONST_32
   #define ECUM_STOP_SEC_CONST_32

#elif defined (ECUM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      ECUM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define ECUM_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (ECUM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      ECUM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define ECUM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (ECUM_START_SEC_CONST_UNSPECIFIED)
   #undef      ECUM_START_SEC_CONST_UNSPECIFIED
   #define ECUM_START_SEC_CONST_UNSPECIFIED
#elif defined (ECUM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      ECUM_STOP_SEC_CONST_UNSPECIFIED
   #define ECUM_STOP_SEC_CONST_UNSPECIFIED

#elif defined (ECUM_START_SEC_CODE)
   #undef      ECUM_START_SEC_CODE
     #define     ECUM_START_SEC_CODE
#elif defined (ECUM_STOP_SEC_CODE)
   #undef      ECUM_STOP_SEC_CODE
   #define ECUM_STOP_SEC_CODE

#elif defined (ECUM_START_SEC_CALLOUT_CODE)
   #undef      ECUM_START_SEC_CALLOUT_CODE
     #define     ECUM_START_SEC_CALLOUT_CODE
#elif defined (ECUM_STOP_SEC_CALLOUT_CODE)
   #undef      ECUM_STOP_SEC_CALLOUT_CODE
   #define ECUM_STOP_SEC_CALLOUT_CODE

#elif defined (ECUM_START_SEC_CONST_8)
   #undef      ECUM_START_SEC_CONST_8
   #define ECUM_START_SEC_CONST_8
#elif defined (ECUM_STOP_SEC_CONST_8)
   #undef      ECUM_STOP_SEC_CONST_8
   #define ECUM_STOP_SEC_CONST_8
   
#elif defined (ECUM_START_SEC_CONFIG_DATA_UNSPECIFIED)
  #undef      ECUM_START_SEC_CONFIG_DATA_UNSPECIFIED
  #define ECUM_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (ECUM_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
  #undef      ECUM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
  #define ECUM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
  
/* ---------------------------------------------------------------------------*/
/*                 POST-BUILD COMPLETE                                        */
/* -------------------------------------------------------------------------- */
   #elif defined (ECUM_START_SEC_PBCHECK_CODE)
   #undef   ECUM_START_SEC_PBCHECK_CODE
   #define  ECUM_START_SEC_PBCHECK_CODE
#elif defined (ECUM_STOP_SEC_PBCHECK_CODE)
   #undef   ECUM_STOP_SEC_PBCHECK_CODE
   #define  ECUM_STOP_SEC_PBCHECK_CODE
   
   #elif defined (ECUM_START_SEC_PBCHECK_DATA)
   #undef   ECUM_START_SEC_PBCHECK_DATA
   #define  ECUM_START_SEC_PBCHECK_DATA
#elif defined (ECUM_STOP_SEC_PBCHECK_DATA)
   #undef   ECUM_STOP_SEC_PBCHECK_DATA
   #define  ECUM_STOP_SEC_PBCHECK_DATA
   
   
/*************************** Stack section ************************************/

/******************************END*********************************************/
/* -------------------------------------------------------------------------- */
/* End of module section mapping                                              */
/* -------------------------------------------------------------------------- */
#else
  #error "MemMap.h: No valid section define found"
#endif    /* START_WITH_IF */
/*******************************************************************************
**                      Default section mapping                               **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/

