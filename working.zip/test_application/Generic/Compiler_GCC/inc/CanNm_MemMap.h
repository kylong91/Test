/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: CanNm_MemMap.h                                                **
**                                                                            **
**  TARGET    : x86                                                           **
**                                                                            **
**  PRODUCT   : Memmap sections for CanNm Module                              **
**                                                                            **
**  PURPOSE   : Provision for sections for memory mapping.                    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: yes                                       **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date           By            Description                         **
********************************************************************************
** 1.0.0     16-Aug-2013   Amruta K       Initial Version                      **
*******************************************************************************/
#ifndef CANNM_MEMMAP_H
#define CANNM_MEMMAP_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR specification version information */
#define CANNM_MEMMAP_AR_MAJOR_VERSION   4
#define CANNM_MEMMAP_AR_MINOR_VERSION   0
#define CANNM_MEMMAP_AR_PATCH_VERSION   3

/* File version information */
#define CANNM_MEMMAP_SW_MAJOR_VERSION   1
#define CANNM_MEMMAP_SW_MINOR_VERSION   0

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Module section mapping                                **
*******************************************************************************/
/*
 * The symbol 'START_WITH_IF' is undefined.
 *
 * Thus, the preprocessor continues searching for defined symbols.
 * This first #ifdef makes integration of delivered parts of MemMap.h
 * easier because every supplier starts with #elif
 */
#if defined (START_WITH_IF)

/* -------------------------------------------------------------------------- */
/*             CanNm                                                          */
/* -------------------------------------------------------------------------- */

#elif defined (CANNM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANNM_START_SEC_VAR_CLEARED_BOOLEAN
   #define CANNM_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (CANNM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANNM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define CANNM_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (CANNM_START_SEC_VAR_NO_INIT_8)
   #undef      CANNM_START_SEC_VAR_NO_INIT_8
   #define CANNM_START_SEC_VAR_NO_INIT_8
#elif defined (CANNM_STOP_SEC_VAR_NO_INIT_8)
   #undef      CANNM_STOP_SEC_VAR_NO_INIT_8
   #define CANNM_STOP_SEC_VAR_NO_INIT_8

#elif defined (CANNM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CANNM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define CANNM_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (CANNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CANNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define CANNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (CANNM_START_SEC_CONST_8)
   #undef      CANNM_START_SEC_CONST_8
   #define CANNM_START_SEC_CONST_8
#elif defined (CANNM_STOP_SEC_CONST_8)
   #undef      CANNM_STOP_SEC_CONST_8
   #define CANNM_STOP_SEC_CONST_8

#elif defined (CANNM_START_SEC_CONST_UNSPECIFIED)
   #undef      CANNM_START_SEC_CONST_UNSPECIFIED
   #define CANNM_START_SEC_CONST_UNSPECIFIED
#elif defined (CANNM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      CANNM_STOP_SEC_CONST_UNSPECIFIED
   #define CANNM_STOP_SEC_CONST_UNSPECIFIED

#elif defined (CANNM_START_SEC_VAR_UNSPECIFIED)
   #undef      CANNM_START_SEC_VAR_UNSPECIFIED
   #define CANNM_START_SEC_VAR_UNSPECIFIED
#elif defined (CANNM_STOP_SEC_VAR_UNSPECIFIED)
   #undef      CANNM_STOP_SEC_VAR_UNSPECIFIED
   #define CANNM_STOP_SEC_CONST_UNSPECIFIED

#elif defined (CANNM_START_SEC_CODE)
   #undef      CANNM_START_SEC_CODE
   #define CANNM_START_SEC_CODE
#elif defined (CANNM_STOP_SEC_CODE)
   #undef      CANNM_STOP_SEC_CODE
   #define CANNM_STOP_SEC_CODE

#elif defined (CANNM_START_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      CANNM_START_SEC_CONFIG_DATA_UNSPECIFIED
   #define CANNM_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (CANNM_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      CANNM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
   #define CANNM_STOP_SEC_CONFIG_DATA_UNSPECIFIED	 
   
#elif defined (CANNM_START_SEC_CONFIG_CONST_UNSPECIFIED)
   #undef      CANNM_START_SEC_CONFIG_CONST_UNSPECIFIED
   #define CANNM_START_SEC_CONFIG_CONST_UNSPECIFIED
#elif defined (CANNM_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
   #undef      CANNM_STOP_SEC_CONFIG_CONST_UNSPECIFIED
   #define CANNM_STOP_SEC_CONFIG_CONST_UNSPECIFIED	 

#elif defined (CANNM_START_SEC_CONFIG_CONST_BOOLEAN)
   #undef      CANNM_START_SEC_CONFIG_CONST_BOOLEAN
   #define CANNM_START_SEC_CONFIG_CONST_BOOLEAN
#elif defined (CANNM_STOP_SEC_CONFIG_CONST_BOOLEAN)
   #undef      CANNM_STOP_SEC_CONFIG_CONST_BOOLEAN
   #define CANNM_STOP_SEC_CONFIG_CONST_BOOLEAN	 
/*************************** Stack section ************************************/

/******************************END*********************************************/
/* -------------------------------------------------------------------------- */
/* End of module section mapping                                              */
/* -------------------------------------------------------------------------- */
#else
  #error "MemMap.h: No valid section define found"
#endif    /* START_WITH_IF */
/*******************************************************************************
**                      Default section mapping                               **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
#endif   /*CANNM_MEMMAP_H*/
