/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: MemMap.h                                                      **
**                                                                            **
**  TARGET    : x86                                                           **
**                                                                            **
**  PRODUCT   : Memmap sections for CANSM Module                              **
**                                                                            **
**  PURPOSE   : Provision for sections for memory mapping.                    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: yes                                       **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date           By              Description                       **
********************************************************************************
** 1.0.0     16-Aug-2013   Amruta K    Initial Version                   **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR specification version information */
#define CANSM_MEMMAP_AR_MAJOR_VERSION   4
#define CANSM_MEMMAP_AR_MINOR_VERSION   0
#define CANSM_MEMMAP_AR_PATCH_VERSION   3

/* File version information */
#define CANSM_MEMMAP_SW_MAJOR_VERSION   1
#define CANSM_MEMMAP_SW_MINOR_VERSION   0

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Module section mapping                                **
*******************************************************************************/
/*
 * The symbol 'START_WITH_IF' is undefined.
 *
 * Thus, the preprocessor continues searching for defined symbols.
 * This first #ifdef makes integration of delivered parts of MemMap.h
 * easier because every supplier starts with #elif
 */
#if defined (START_WITH_IF)

/* -------------------------------------------------------------------------- */
/*                             CANSM                                          */
/* -------------------------------------------------------------------------- */
#elif defined (CANSM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANSM_START_SEC_VAR_CLEARED_BOOLEAN
   #define CANSM_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (CANSM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANSM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define CANSM_STOP_SEC_VAR_CLEARED_BOOLEAN
   
#elif defined (CANSM_START_SEC_CONFIG_CONST_UNSPECIFIED)
   #undef    CANSM_START_SEC_CONFIG_CONST_UNSPECIFIED
   #define   CANSM_START_SEC_CONFIG_CONST_UNSPECIFIED
#elif defined (CANSM_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
   #undef    CANSM_STOP_SEC_CONFIG_CONST_UNSPECIFIED
   #define   CANSM_STOP_SEC_CONFIG_CONST_UNSPECIFIED

#elif defined (CANSM_START_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef    CANSM_START_SEC_CONFIG_DATA_UNSPECIFIED
   #define   CANSM_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (CANSM_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef    CANSM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
   #define   CANSM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
   
#elif defined (CANSM_START_SEC_CONST_8)
   #undef      CANSM_START_SEC_CONST_8
   #define CANSM_START_SEC_CONST_8
#elif defined (CANSM_STOP_SEC_CONST_8)
   #undef      CANSM_STOP_SEC_CONST_8
   #define CANSM_STOP_SEC_CONST_8
   
#elif defined (CANSM_START_SEC_VAR_NO_INIT_16)
   #undef      CANSM_START_SEC_VAR_NO_INIT_16
   #define CANSM_START_SEC_VAR_NO_INIT_16
#elif defined (CANSM_STOP_SEC_VAR_NO_INIT_16)
   #undef      CANSM_STOP_SEC_VAR_NO_INIT_16
   #define CANSM_STOP_SEC_VAR_NO_INIT_16

#elif defined (CANSM_START_SEC_VAR_CLEARED_8)
   #undef      CANSM_START_SEC_VAR_CLEARED_8
   #define CANSM_START_SEC_VAR_CLEARED_8
#elif defined (CANSM_STOP_SEC_VAR_CLEARED_8)
   #undef      CANSM_STOP_SEC_VAR_CLEARED_8
   #define CANSM_STOP_SEC_VAR_CLEARED_8

#elif defined (CANSM_START_SEC_VAR_NO_INIT_8)
   #undef      CANSM_START_SEC_VAR_NO_INIT_8
   #define CANSM_START_SEC_VAR_NO_INIT_8
#elif defined (CANSM_STOP_SEC_VAR_NO_INIT_8)
   #undef      CANSM_STOP_SEC_VAR_NO_INIT_8
   #define CANSM_STOP_SEC_VAR_NO_INIT_8

#elif defined (CANSM_START_SEC_CONST_UNSPECIFIED)
   #undef      CANSM_START_SEC_CONST_UNSPECIFIED
   #define CANSM_START_SEC_CONST_UNSPECIFIED
#elif defined (CANSM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      CANSM_STOP_SEC_CONST_UNSPECIFIED
   #define CANSM_STOP_SEC_CONST_UNSPECIFIED

#elif defined (CANSM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CANSM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define CANSM_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (CANSM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CANSM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define CANSM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (CANSM_START_SEC_CODE)
   #undef      CANSM_START_SEC_CODE
   #define     CANSM_START_SEC_CODE
#elif defined (CANSM_STOP_SEC_CODE)
   #undef      CANSM_STOP_SEC_CODE
   #define CANSM_STOP_SEC_CODE

#elif defined (CANSM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      CANSM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define CANSM_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (CANSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      CANSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define CANSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED

/*************************** Stack section ************************************/

/******************************END*********************************************/
/* -------------------------------------------------------------------------- */
/* End of module section mapping                                              */
/* -------------------------------------------------------------------------- */
#else
  #error "MemMap.h: No valid section define found"
#endif    /* START_WITH_IF */
/*******************************************************************************
**                      CANSM section mapping                               **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
