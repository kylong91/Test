/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: MemMap.h                                                      **
**                                                                            **
**  TARGET    : x86                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BSW R4.0.3 Modules                                    **
**                                                                            **
**  PURPOSE   : Provision for sections for memory mapping.                    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: yes                                       **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.0     16-Aug-2013   Amruta K    Initial Version                             **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#ifndef PDUR_MEMMAP_H
#define PDUR_MEMMAP_H
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR specification version information */
#define PDUR_MEMMAP_AR_MAJOR_VERSION   4
#define PDUR_MEMMAP_AR_MINOR_VERSION   0
#define PDUR_MEMMAP_AR_PATCH_VERSION   3

/* File version information */
#define PDUR_MEMMAP_SW_MAJOR_VERSION   1
#define PDUR_MEMMAP_SW_MINOR_VERSION   0

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Module section mapping                                **
*******************************************************************************/
/*
 * The symbol 'START_WITH_IF' is undefined.
 *
 * Thus, the preprocessor continues searching for defined symbols.
 * This first #ifdef makes integration of delivered parts of MemMap.h
 * easier because every supplier starts with #elif
 */
#if defined (START_WITH_IF)
/* -------------------------------------------------------------------------- */
/*             PduR                                                           */
/* -------------------------------------------------------------------------- */
#elif defined (PDUR_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      PDUR_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_PDUR_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (PDUR_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_PDUR_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

/* Section name shall be PDUR_START_SEC_NO_INIT_VAR_8 */
#elif defined (PDUR_START_SEC_VAR_NO_INIT_8)
   #undef      PDUR_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
/* Section name shall be PDUR_STOP_SEC_NO_INIT_VAR_8 */
#elif defined (PDUR_STOP_SEC_VAR_NO_INIT_8)
   #undef      PDUR_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

/* Section name shall be PDUR_START_SEC_CONFIG_NO_INIT_VAR_8 */
#elif defined (PDUR_START_SEC_CONFIG_VAR_NO_INIT_8)
   #undef      PDUR_START_SEC_CONFIG_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_CONFIG_VAR_NO_INIT_8
/* Section name shall be PDUR_STOP_SEC_CONFIG_NO_INIT_VAR_8 */
#elif defined (PDUR_STOP_SEC_CONFIG_VAR_NO_INIT_8)
   #undef      PDUR_STOP_SEC_CONFIG_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_CONFIG_VAR_NO_INIT_8

#elif defined (PDUR_START_SEC_VAR_NO_INIT_16)
   #undef      PDUR_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (PDUR_STOP_SEC_VAR_NO_INIT_16)
   #undef      PDUR_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

 #elif defined (PDUR_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      PDUR_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (PDUR_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      PDUR_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (PDUR_START_SEC_VAR_CLEARED_8)
   #undef      PDUR_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (PDUR_STOP_SEC_VAR_CLEARED_8)
   #undef      PDUR_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (PDUR_START_SEC_CONFIG_VAR_CLEARED_8)
   #undef      PDUR_START_SEC_CONFIG_VAR_CLEARED_8
   #define DEFAULT_START_SEC_CONFIG_VAR_CLEARED_8
#elif defined (PDUR_STOP_SEC_CONFIG_VAR_CLEARED_8)
   #undef      PDUR_STOP_SEC_CONFIG_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_CONFIG_VAR_CLEARED_8

#elif defined (PDUR_START_SEC_VAR_CLEARED_32)
   #undef      PDUR_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (PDUR_STOP_SEC_VAR_CLEARED_32)
   #undef      PDUR_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (PDUR_START_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      PDUR_START_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (PDUR_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED

#elif defined (PDUR_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      PDUR_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (PDUR_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (PDUR_START_SEC_CONST_UNSPECIFIED)
   #undef      PDUR_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (PDUR_STOP_SEC_CONST_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (PDUR_START_SEC_CONFIG_CONST_UNSPECIFIED)
   #undef      PDUR_START_SEC_CONFIG_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_CONST_UNSPECIFIED
#elif defined (PDUR_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_CONFIG_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_CONST_UNSPECIFIED

#elif defined (PDUR_START_SEC_CONFIG_VAR_NO_INIT_UNSPECIFIED)
   #undef      PDUR_START_SEC_CONFIG_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_PDUR_START_CONFIG_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (PDUR_STOP_SEC_CONFIG_VAR_NO_INIT_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_CONFIG_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_PDUR_STOP_SEC_CONFIG_VAR_NO_INIT_UNSPECIFIED

#elif defined (PDUR_START_SEC_CONFIG_VAR_NO_INIT_16)
   #undef      PDUR_START_SEC_CONFIG_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_CONFIG_VAR_NO_INIT_16
#elif defined (PDUR_STOP_SEC_CONFIG_VAR_NO_INIT_16)
   #undef      PDUR_STOP_SEC_CONFIG_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_CONFIG_VAR_NO_INIT_16

#elif defined (PDUR_START_SEC_CONFIG_CONST_8)
   #undef      PDUR_START_SEC_CONFIG_CONST_8
   #define DEFAULT_START_SEC_CONFIG_CONST_8
#elif defined (PDUR_STOP_SEC_CONFIG_CONST_8)
   #undef      PDUR_STOP_SEC_CONFIG_CONST_8
   #define DEFAULT_STOP_SEC_CONFIG_CONST_8

#elif defined (PDUR_START_SEC_CONFIG_CONST_16)
   #undef      PDUR_START_SEC_CONFIG_CONST_16
   #define DEFAULT_START_SEC_CONFIG_CONST_16
#elif defined (PDUR_STOP_SEC_CONFIG_CONST_16)
   #undef      PDUR_STOP_SEC_CONFIG_CONST_16
   #define DEFAULT_STOP_SEC_CONFIG_CONST_16

#elif defined (PDUR_START_SEC_CODE)
   #undef      PDUR_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (PDUR_STOP_SEC_CODE)
   #undef      PDUR_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE


/*************************** Stack section ************************************/

/******************************END*********************************************/
/* -------------------------------------------------------------------------- */
/* End of module section mapping                                              */
/* -------------------------------------------------------------------------- */
#else
  #error "MemMap.h: No valid section define found"
#endif  /* START_WITH_IF */

/*******************************************************************************
**                      Default section mapping                               **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#endif  /*PDUR_MEMMAP_H*/

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
