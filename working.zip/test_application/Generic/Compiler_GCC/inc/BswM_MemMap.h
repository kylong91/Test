/*******************************************************************************
**                  KPIT Cummins Infosystems Limited                          **
**                                                                            **
** KPIT Cummins Infosystems Limited owns all the rights to this work. This    **
** work shall not be copied, reproduced, used, modified or its information    **
** disclosed without the prior written authorization of KPIT Cummins          **
** Infosystems Limited.                                                       **
**                                                                            **
**  SRC-MODULE: BSWM_MemMap.h                                                 **
**                                                                            **
**  TARGET    : x86                                                           **
**                                                                            **
**  PRODUCT   : Memmap sections for BswM Module                               **
**                                                                            **
**  PURPOSE   : Provision for sections for memory mapping.                    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: yes                                       **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By            Description                          **
********************************************************************************
** 1.0.0     17-Jul-2013   Chandan     Initial Version                         **
*******************************************************************************/
#ifndef BSWM_MEMMAP_H
#define BSWM_MEMMAP_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR specification version information */
#define BSWM_MEMMAP_AR_MAJOR_VERSION   4
#define BSWM_MEMMAP_AR_MINOR_VERSION   0
#define BSWM_MEMMAP_AR_PATCH_VERSION   3

/* File version information */
#define BSWM_MEMMAP_SW_MAJOR_VERSION   1
#define BSWM_MEMMAP_SW_MINOR_VERSION   0

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Module section mapping                                **
*******************************************************************************/
/*
 * The symbol 'START_WITH_IF' is undefined.
 *
 * Thus, the preprocessor continues searching for defined symbols.
 * This first #ifdef makes integration of delivered parts of MemMap.h
 * easier because every supplier starts with #elif
 */

#if defined (START_WITH_IF)

/*----------------------------------------------------------------------------*/
/*                          BswM                                             */
/*----------------------------------------------------------------------------*/
#elif defined (BSWM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      BSWM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (BSWM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      BSWM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN
	 
	 #elif defined (BSWM_START_SEC_CONFIG_CONST_UNSPECIFIED)
   #undef      BSWM_START_SEC_CONFIG_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_CONST_UNSPECIFIED
#elif defined (BSWM_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
   #undef      BSWM_STOP_SEC_CONFIG_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_CONST_UNSPECIFIED

#elif defined (BSWM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      BSWM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (BSWM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      BSWM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (BSWM_START_SEC_CONST_UNSPECIFIED)
   #undef      BSWM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (BSWM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      BSWM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (BSWM_START_SEC_CODE)
   #undef      BSWM_START_SEC_CODE
     #define     DEFAULT_START_SEC_CODE
#elif defined (BSWM_STOP_SEC_CODE)
   #undef      BSWM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (BSWM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      BSWM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (BSWM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      BSWM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/* End of module section mapping                                              */
/* -------------------------------------------------------------------------- */
#else
  #error "MemMap.h: No valid section define found"
#endif    /* START_WITH_IF */
/*******************************************************************************
**                      Default section mapping                               **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
#endif   /*BSWM_MEMMAP_H*/
