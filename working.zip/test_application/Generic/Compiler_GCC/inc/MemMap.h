/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: MemMap.h                                                      **
**                                                                            **
**  TARGET    : x86                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR BSW R4.0.3 Modules                                    **
**                                                                            **
**  PURPOSE   : Provision for sections for memory mapping.                    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: yes                                       **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.2     09-Mar-2015   Sinil   Wdg related macros are added               **
** 1.0.1     25-Feb-2015   SW.Lee  TcpIp related macros are added             **
** 1.0.0     09-May-2014   KPIT   Initial Version                             **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#if defined (IPDUM_MODULE_ACTIVE)
#include "IpduM_MemMap.h"    /* Memmap section header for IpduM*/
#endif
#if defined (COMM_MODULE_ACTIVE)
#include "ComM_MemMap.h"     /* Memmap section header for ComM*/
#endif
#if defined (COM_MODULE_ACTIVE)
#include "Com_MemMap.h"      /* Memmap section header for Com*/
#endif 
#if defined (NM_MODULE_ACTIVE)
#include "Nm_MemMap.h"       /* Memmap section header for NM*/
#endif
#if defined (CANTP_MODULE_ACTIVE)
#include "CanTp_MemMap.h"    /* Memmap section header for CanTp*/
#endif
#if defined (CANSM_MODULE_ACTIVE)
#include "CanSM_MemMap.h"    /* Memmap section header for CanSM*/
#endif
#if defined (PDUR_MODULE_ACTIVE)
#include "PduR_MemMap.h"     /* Memmap section header for PduR*/
#endif
#if defined (BSWM_MODULE_ACTIVE)
#include "BswM_MemMap.h"     /* Memmap section header for BswM*/
#endif
#if defined (ECUM_MODULE_ACTIVE)
#include "EcuM_MemMap.h"     /* Memmap section header for EcuM*/
#endif
#if defined (CANNM_MODULE_ACTIVE)
#include "CanNm_MemMap.h"    /* Memmap section header for CanNM*/
#endif
#if defined (CANIF_MODULE_ACTIVE)
#include "CanIf_MemMap.h"    /* Memmap section header for CanIf*/
#endif
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR specification version information */
#define MEMMAP_AR_MAJOR_VERSION   4
#define MEMMAP_AR_MINOR_VERSION   0
#define MEMMAP_AR_PATCH_VERSION   3

/* File version information */
#define MEMMAP_SW_MAJOR_VERSION   1
#define MEMMAP_SW_MINOR_VERSION   0

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Module section mapping                                **
*******************************************************************************/
/*
 * The symbol 'START_WITH_IF' is undefined.
 *
 * Thus, the preprocessor continues searching for defined symbols.
 * This first #ifdef makes integration of delivered parts of MemMap.h
 * easier because every supplier starts with #elif
 */
#if defined (START_WITH_IF)

/* -------------------------------------------------------------------------- */
/*                 CAL                                                        */
/* -------------------------------------------------------------------------- */
#elif defined (CAL_START_SEC_CODE)
   #undef      CAL_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (CAL_STOP_SEC_CODE)
   #undef      CAL_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (CAL_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CAL_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (CAL_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CAL_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (CAL_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CAL_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (CAL_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CAL_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (CAL_START_SEC_CONST_UNSPECIFIED)
   #undef      CAL_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (CAL_STOP_SEC_CONST_UNSPECIFIED)
   #undef      CAL_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED
/* -------------------------------------------------------------------------- */
/*                 CSM                                                        */
/* -------------------------------------------------------------------------- */
#elif defined (CSM_START_SEC_CODE)
   #undef      CSM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (CSM_STOP_SEC_CODE)
   #undef      CSM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (CSM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CSM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (CSM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CSM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (CSM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CSM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (CSM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CSM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (CSM_START_SEC_CONST_UNSPECIFIED)
   #undef      CSM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (CSM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      CSM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED
/* -------------------------------------------------------------------------- */
/*             LinIf                                                          */
/* -------------------------------------------------------------------------- */

#elif defined (LINIF_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINIF_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (LINIF_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINIF_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (LINIF_START_SEC_DBTOC_CONST_UNSPECIFIED)
   #undef      LINIF_START_SEC_DBTOC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_DBTOC_CONST_UNSPECIFIED
#elif defined (LINIF_STOP_SEC_DBTOC_CONST_UNSPECIFIED)
   #undef      LINIF_STOP_SEC_DBTOC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_DBTOC_CONST_UNSPECIFIED

#elif defined (LINIF_START_SEC_CONST_UNSPECIFIED)
   #undef      LINIF_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (LINIF_STOP_SEC_CONST_UNSPECIFIED)
   #undef      LINIF_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

   #elif defined (LINIF_START_SEC_VAR_NO_INIT_8)
   #undef      LINIF_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (LINIF_STOP_SEC_VAR_NO_INIT_8)
   #undef      LINIF_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (LINIF_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      LINIF_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (LINIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      LINIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (LINIF_START_SEC_CONST_8)
   #undef      LINIF_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (LINIF_STOP_SEC_CONST_8)
   #undef      LINIF_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (LINIF_START_SEC_CONST_UNSPECIFIED)
   #undef      LINIF_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (LINIF_STOP_SEC_CONST_UNSPECIFIED)
   #undef      LINIF_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (LINIF_START_SEC_CODE)
   #undef      LINIF_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (LINIF_STOP_SEC_CODE)
   #undef      LINIF_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (LINIF_START_SEC_CODE)
   #undef      LINIF_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (LINIF_STOP_SEC_CODE)
   #undef      LINIF_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*             LinTp                                                          */
/* -------------------------------------------------------------------------- */

#elif defined (LINTP_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINTP_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (LINTP_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINTP_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (LINTP_START_SEC_VAR_NO_INIT_8)
   #undef      LINTP_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (LINTP_STOP_SEC_VAR_NO_INIT_8)
   #undef      LINTP_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (LINTP_START_SEC_CONST_UNSPECIFIED)
   #undef      LINTP_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (LINTP_STOP_SEC_CONST_UNSPECIFIED)
   #undef      LINTP_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

   #elif defined (LINTP_START_SEC_VAR_NO_INIT_8)
   #undef      LINTP_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (LINTP_STOP_SEC_VAR_NO_INIT_8)
   #undef      LINTP_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (LINTP_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      LINTP_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (LINTP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      LINTP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (LINTP_START_SEC_CONST_8)
   #undef      LINTP_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (LINTP_STOP_SEC_CONST_8)
   #undef      LINTP_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (LINTP_START_SEC_CONST_UNSPECIFIED)
   #undef      LINTP_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (LINTP_STOP_SEC_CONST_UNSPECIFIED)
   #undef      LINTP_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (LINTP_START_SEC_CODE)
   #undef      LINTP_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (LINTP_STOP_SEC_CODE)
   #undef      LINTP_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (LINTP_START_SEC_VAR_CLEARED_16)
   #undef      LINTP_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (LINTP_STOP_SEC_VAR_CLEARED_16)
   #undef      LINTP_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (LINTP_START_SEC_DBTOC_CONST_UNSPECIFIED)
   #undef      LINTP_START_SEC_DBTOC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_DBTOC_CONST_UNSPECIFIED
#elif defined (LINTP_STOP_SEC_DBTOC_CONST_UNSPECIFIED)
   #undef      LINTP_STOP_SEC_DBTOC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_DBTOC_CONST_UNSPECIFIED
/* -------------------------------------------------------------------------- */
/*                                 OS                                         */
/* -------------------------------------------------------------------------- */
   /*  No INIT Var Section */

#elif defined (OS_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      OS_START_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (OS_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      OS_STOP_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN

#elif defined (OS_START_SEC_VAR_NO_INIT_8)
   #undef      OS_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (OS_STOP_SEC_VAR_NO_INIT_8)
   #undef      OS_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (OS_START_SEC_VAR_NO_INIT_16)
   #undef      OS_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (OS_STOP_SEC_VAR_NO_INIT_16)
   #undef      OS_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (OS_START_SEC_VAR_NO_INIT_32)
   #undef      OS_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (OS_STOP_SEC_VAR_NO_INIT_32)
   #undef      OS_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (OS_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      OS_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (OS_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      OS_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

  /*  Zero INIT Var Section */
#elif defined (OS_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      OS_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (OS_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      OS_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (OS_START_SEC_VAR_CLEARED_8)
   #undef      OS_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (OS_STOP_SEC_VAR_CLEARED_8)
   #undef      OS_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (OS_START_SEC_VAR_CLEARED_16)
   #undef      OS_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (OS_STOP_SEC_VAR_CLEARED_16)
   #undef      OS_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (OS_START_SEC_VAR_CLEARED_32)
   #undef      OS_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (OS_STOP_SEC_VAR_CLEARED_32)
   #undef      OS_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (OS_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      OS_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (OS_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      OS_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

	  /* INIT Var Section */

#elif defined (OS_START_SEC_VAR_INIT_BOOLEAN)
   #undef      OS_START_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_INIT_BOOLEAN
#elif defined (OS_STOP_SEC_VAR_INIT_BOOLEAN)
   #undef      OS_STOP_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_INIT_BOOLEAN

#elif defined (OS_START_SEC_VAR_INIT_8)
   #undef      OS_START_SEC_VAR_INIT_8
   #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (OS_STOP_SEC_VAR_INIT_8)
   #undef      OS_STOP_SEC_VAR_INIT_8
   #define DEFAULT_STOP_SEC_VAR_INIT_8

#elif defined (OS_START_SEC_VAR_INIT_16)
   #undef      OS_START_SEC_VAR_INIT_16
   #define DEFAULT_START_SEC_VAR_INIT_16
#elif defined (OS_STOP_SEC_VAR_INIT_16)
   #undef      OS_STOP_SEC_VAR_INIT_16
   #define DEFAULT_STOP_SEC_VAR_INIT_16

#elif defined (OS_START_SEC_VAR_INIT_32)
   #undef      OS_START_SEC_VAR_INIT_32
   #define DEFAULT_START_SEC_VAR_INIT_32
#elif defined (OS_STOP_SEC_VAR_INIT_32)
   #undef      OS_STOP_SEC_VAR_INIT_32
   #define DEFAULT_STOP_SEC_VAR_INIT_32

#elif defined (OS_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      OS_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (OS_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      OS_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED

	/* Fast Var Section */

#elif defined (OS_START_SEC_VAR_FAST_NO_INIT_BOOLEAN)
   #undef      OS_START_SEC_VAR_FAST_NO_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_FAST_NO_INIT_BOOLEAN
#elif defined (OS_STOP_SEC_VAR_FAST_NO_INIT_BOOLEAN)
   #undef      OS_STOP_SEC_VAR_FAST_NO_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_BOOLEAN

#elif defined (OS_START_SEC_VAR_FAST_NO_INIT_8)
   #undef      OS_START_SEC_VAR_FAST_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_FAST_NO_INIT_8
#elif defined (OS_STOP_SEC_VAR_FAST_NO_INIT_8)
   #undef      OS_STOP_SEC_VAR_FAST_8
   #define DEFAULT_STOP_SEC_VAR_FAST_8

#elif defined (OS_START_SEC_VAR_FAST_NO_INIT_16)
   #undef      OS_START_SEC_VAR_FAST_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_FAST_NO_INIT_16
#elif defined (OS_STOP_SEC_VAR_FAST_NO_INIT_16)
   #undef      OS_STOP_SEC_VAR_FAST_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_16

#elif defined (OS_START_SEC_VAR_FAST_NO_INIT_32)
   #undef      OS_START_SEC_VAR_FAST_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_FAST_NO_INIT_32
#elif defined (OS_STOP_SEC_VAR_FAST_NO_INIT_32)
   #undef      OS_STOP_SEC_VAR_FAST_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_32

#elif defined (OS_START_SEC_VAR_FAST_NO_INIT_UNSPECIFIED)
   #undef      OS_START_SEC_VAR_FAST_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_FAST_NO_INIT_UNSPECIFIED
#elif defined (OS_STOP_SEC_VAR_FAST_NO_INIT_UNSPECIFIED)
   #undef      OS_STOP_SEC_VAR_FAST_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_UNSPECIFIED

   /* Constant Variable section */

#elif defined (OS_START_SEC_CONST_BOOLEAN)
   #undef      OS_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (OS_STOP_SEC_CONST_BOOLEAN)
   #undef      OS_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (OS_START_SEC_CONST_8)
   #undef      OS_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (OS_STOP_SEC_CONST_8)
   #undef      OS_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (OS_START_SEC_CONST_16)
   #undef      OS_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (OS_STOP_SEC_CONST_16)
   #undef      OS_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

#elif defined (OS_START_SEC_CONST_32)
   #undef      OS_START_SEC_CONST_32
   #define DEFAULT_START_SEC_CONST_32
#elif defined (OS_STOP_SEC_CONST_32)
   #undef      OS_STOP_SEC_CONST_32
   #define DEFAULT_STOP_SEC_CONST_32

#elif defined (OS_START_SEC_CONST_UNSPECIFIED)
   #undef      OS_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (OS_STOP_SEC_CONST_UNSPECIFIED)
   #undef      OS_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

	 /* Config Data Section */

#elif defined (OS_START_SEC_CONFIG_DATA_BOOLEAN)
   #undef      OS_START_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
#elif defined (OS_STOP_SEC_CONFIG_DATA_BOOLEAN)
   #undef      OS_STOP_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN

#elif defined (OS_START_SEC_CONFIG_DATA_8)
   #undef      OS_START_SEC_CONFIG_DATA_8
   #define DEFAULT_START_SEC_CONFIG_DATA_8
#elif defined (OS_STOP_SEC_CONFIG_DATA_8)
   #undef      OS_STOP_SEC_CONFIG_DATA_8
   #define DEFAULT_STOP_SEC_CONFIG_DATA_8

#elif defined (OS_START_SEC_CONFIG_DATA_16)
   #undef      OS_START_SEC_CONFIG_DATA_16
   #define DEFAULT_START_SEC_CONFIG_DATA_16
#elif defined (OS_STOP_SEC_CONFIG_DATA_16)
   #undef      OS_STOP_SEC_CONFIG_DATA_16
   #define DEFAULT_STOP_SEC_CONFIG_DATA_16

#elif defined (OS_START_SEC_CONFIG_DATA_32)
   #undef      OS_START_SEC_CONFIG_DATA_32
   #define DEFAULT_START_SEC_CONFIG_DATA_32
#elif defined (OS_STOP_SEC_CONFIG_DATA_32)
   #undef      OS_STOP_SEC_CONFIG_DATA_32
   #define DEFAULT_STOP_SEC_CONFIG_DATA_32

#elif defined (OS_START_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      OS_START_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (OS_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      OS_STOP_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED


#elif defined (OS_START_SEC_CODE)
   #undef      OS_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (OS_STOP_SEC_CODE)
   #undef      OS_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*             SoAd                                                           */
/* -------------------------------------------------------------------------- */
#elif defined (SOAD_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      SOAD_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (SOAD_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      SOAD_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (SOAD_START_SEC_VAR_CLEARED_8)
   #undef      SOAD_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (SOAD_STOP_SEC_VAR_CLEARED_8)
   #undef      SOAD_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (SOAD_START_SEC_VAR_CLEARED_16)
   #undef      SOAD_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (SOAD_STOP_SEC_VAR_CLEARED_16)
   #undef      SOAD_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (SOAD_START_SEC_VAR_CLEARED_32)
   #undef      SOAD_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (SOAD_STOP_SEC_VAR_CLEARED_32)
   #undef      SOAD_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (SOAD_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      SOAD_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (SOAD_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      SOAD_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (SOAD_START_SEC_VAR_INIT_1)
   #undef      SOAD_START_SEC_VAR_INIT_1
   #define DEFAULT_START_SEC_VAR_INIT_1
#elif defined (SOAD_STOP_SEC_VAR_INIT_1)
   #undef      SOAD_STOP_SEC_VAR_INIT_1
   #define DEFAULT_STOP_SEC_VAR_INIT_1

#elif defined (SOAD_START_SEC_VAR_INIT_8)
   #undef      SOAD_START_SEC_VAR_INIT_8
   #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (SOAD_STOP_SEC_VAR_INIT_8)
   #undef      SOAD_STOP_SEC_VAR_INIT_8
   #define DEFAULT_STOP_SEC_VAR_INIT_8

#elif defined (SOAD_START_SEC_VAR_INIT_16)
   #undef      SOAD_START_SEC_VAR_INIT_16
   #define DEFAULT_START_SEC_VAR_INIT_16
#elif defined (SOAD_STOP_SEC_VAR_INIT_16)
   #undef      SOAD_STOP_SEC_VAR_INIT_16
   #define DEFAULT_STOP_SEC_VAR_INIT_16

#elif defined (SOAD_START_SEC_VAR_INIT_32)
   #undef      SOAD_START_SEC_VAR_INIT_32
   #define DEFAULT_START_SEC_VAR_INIT_32
#elif defined (SOAD_STOP_SEC_VAR_INIT_32)
   #undef      SOAD_STOP_SEC_VAR_INIT_32
   #define DEFAULT_STOP_SEC_VAR_INIT_32

#elif defined (SOAD_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      SOAD_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (SOAD_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      SOAD_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED

#elif defined (SOAD_START_SEC_VAR_NO_INIT_1)
   #undef      SOAD_START_SEC_VAR_NO_INIT_1
   #define DEFAULT_START_SEC_VAR_NO_INIT_1
#elif defined (SOAD_STOP_SEC_VAR_NO_INIT_1)
   #undef      SOAD_STOP_SEC_VAR_NO_INIT_1
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_1

#elif defined (SOAD_START_SEC_VAR_NO_INIT_8)
   #undef      SOAD_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (SOAD_STOP_SEC_VAR_NO_INIT_8)
   #undef      SOAD_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (SOAD_START_SEC_VAR_NO_INIT_16)
   #undef      SOAD_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (SOAD_STOP_SEC_VAR_NO_INIT_16)
   #undef      SOAD_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (SOAD_START_SEC_VAR_NO_INIT_32)
   #undef      SOAD_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (SOAD_STOP_SEC_VAR_NO_INIT_32)
   #undef      SOAD_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (SOAD_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      SOAD_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (SOAD_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      SOAD_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (SOAD_START_SEC_CONST_1)
   #undef      SOAD_START_SEC_CONST_1
   #define DEFAULT_START_SEC_CONST_1
#elif defined (SOAD_STOP_SEC_CONST_1)
   #undef      SOAD_STOP_SEC_CONST_1
   #define DEFAULT_STOP_SEC_CONST_1

#elif defined (SOAD_START_SEC_CONST_8)
   #undef      SOAD_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (SOAD_STOP_SEC_CONST_8)
   #undef      SOAD_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (SOAD_START_SEC_CONST_16)
   #undef      SOAD_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (SOAD_STOP_SEC_CONST_16)
   #undef      SOAD_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

#elif defined (SOAD_START_SEC_CONST_32)
   #undef      SOAD_START_SEC_CONST_32
   #define DEFAULT_START_SEC_CONST_32
#elif defined (SOAD_STOP_SEC_CONST_32)
   #undef      SOAD_STOP_SEC_CONST_32
   #define DEFAULT_STOP_SEC_CONST_32

#elif defined (SOAD_START_SEC_CONST_UNSPECIFIED)
   #undef      SOAD_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (SOAD_STOP_SEC_CONST_UNSPECIFIED)
   #undef      SOAD_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (SOAD_START_SEC_VAR_UNSPECIFIED)
   #undef      SOAD_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (SOAD_STOP_SEC_VAR_UNSPECIFIED)
   #undef      SOAD_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED
#elif defined (SOAD_START_SEC_CODE)
   #undef      SOAD_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (SOAD_STOP_SEC_CODE)
   #undef      SOAD_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE


/* -------------------------------------------------------------------------- */
/*             TcpIp                                                           */
/* -------------------------------------------------------------------------- */
#elif defined (TCPIP_START_SEC_VAR_CLEARED_1)
   #undef      TCPIP_START_SEC_VAR_CLEARED_1
   #define DEFAULT_START_SEC_VAR_CLEARED_1
#elif defined (TCPIP_STOP_SEC_VAR_CLEARED_1)
   #undef      TCPIP_STOP_SEC_VAR_CLEARED_1
   #define DEFAULT_STOP_SEC_VAR_CLEARED_1
   
#elif defined (TCPIP_START_SEC_VAR_CLEARED_8)
   #undef      TCPIP_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (TCPIP_STOP_SEC_VAR_CLEARED_8)
   #undef      TCPIP_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8
   
#elif defined (TCPIP_START_SEC_VAR_CLEARED_16)
   #undef      TCPIP_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (TCPIP_STOP_SEC_VAR_CLEARED_16)
   #undef      TCPIP_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16 
   
#elif defined (TCPIP_START_SEC_VAR_CLEARED_32)
   #undef      TCPIP_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (TCPIP_STOP_SEC_VAR_CLEARED_32)
   #undef      TCPIP_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32  

#elif defined (TCPIP_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      TCPIP_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (TCPIP_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      TCPIP_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED     

#elif defined (TCPIP_START_SEC_VAR_INIT_1)
   #undef      TCPIP_START_SEC_VAR_INIT_1
   #define DEFAULT_START_SEC_VAR_INIT_1
#elif defined (TCPIP_STOP_SEC_VAR_INIT_1)
   #undef      TCPIP_STOP_SEC_VAR_INIT_1
   #define DEFAULT_STOP_SEC_VAR_INIT_1
   
#elif defined (TCPIP_START_SEC_VAR_INIT_8)
   #undef      TCPIP_START_SEC_VAR_INIT_8
   #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (TCPIP_STOP_SEC_VAR_INIT_8)
   #undef      TCPIP_STOP_SEC_VAR_INIT_8
   #define DEFAULT_STOP_SEC_VAR_INIT_8
   
#elif defined (TCPIP_START_SEC_VAR_INIT_16)
   #undef      TCPIP_START_SEC_VAR_INIT_16
   #define DEFAULT_START_SEC_VAR_INIT_16
#elif defined (TCPIP_STOP_SEC_VAR_INIT_16)
   #undef      TCPIP_STOP_SEC_VAR_INIT_16
   #define DEFAULT_STOP_SEC_VAR_INIT_16
   
#elif defined (TCPIP_START_SEC_VAR_INIT_32)
   #undef      TCPIP_START_SEC_VAR_INIT_32
   #define DEFAULT_START_SEC_VAR_INIT_32
#elif defined (TCPIP_STOP_SEC_VAR_INIT_32)
   #undef      TCPIP_STOP_SEC_VAR_INIT_32
   #define DEFAULT_STOP_SEC_VAR_INIT_32
   
#elif defined (TCPIP_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      TCPIP_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (TCPIP_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      TCPIP_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED   
   
#elif defined (TCPIP_START_SEC_VAR_NOINIT_1)
   #undef      TCPIP_START_SEC_VAR_NOINIT_1
   #define DEFAULT_START_SEC_VAR_NOINIT_1
#elif defined (TCPIP_STOP_SEC_VAR_NOINIT_1)
   #undef      TCPIP_STOP_SEC_VAR_NOINIT_1
   #define DEFAULT_STOP_SEC_VAR_NOINIT_1  
   
#elif defined (TCPIP_START_SEC_VAR_NOINIT_8)
   #undef      TCPIP_START_SEC_VAR_NOINIT_8
   #define DEFAULT_START_SEC_VAR_NOINIT_8
#elif defined (TCPIP_STOP_SEC_VAR_NOINIT_8)
   #undef      TCPIP_STOP_SEC_VAR_NOINIT_8
   #define DEFAULT_STOP_SEC_VAR_NOINIT_8

#elif defined (TCPIP_START_SEC_VAR_NOINIT_16)
   #undef      TCPIP_START_SEC_VAR_NOINIT_16
   #define DEFAULT_START_SEC_VAR_NOINIT_16
#elif defined (TCPIP_STOP_SEC_VAR_NOINIT_16)
   #undef      TCPIP_STOP_SEC_VAR_NOINIT_16
   #define DEFAULT_STOP_SEC_VAR_NOINIT_16
   
#elif defined (TCPIP_START_SEC_VAR_NOINIT_32)
   #undef      TCPIP_START_SEC_VAR_NOINIT_32
   #define DEFAULT_START_SEC_VAR_NOINIT_32
#elif defined (TCPIP_STOP_SEC_VAR_NOINIT_32)
   #undef      TCPIP_STOP_SEC_VAR_NOINIT_32
   #define DEFAULT_STOP_SEC_VAR_NOINIT_32   
   
#elif defined (TCPIP_START_SEC_VAR_NOINIT_UNSPECIFIED)
   #undef      TCPIP_START_SEC_VAR_NOINIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NOINIT_UNSPECIFIED
#elif defined (TCPIP_STOP_SEC_VAR_NOINIT_UNSPECIFIED)
   #undef      TCPIP_STOP_SEC_VAR_NOINIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NOINIT_UNSPECIFIED

#elif defined (TCPIP_START_SEC_CONST_1)
   #undef      TCPIP_START_SEC_CONST_1
   #define DEFAULT_START_SEC_CONST_1
#elif defined (TCPIP_STOP_SEC_CONST_1)
   #undef      TCPIP_STOP_SEC_CONST_1
   #define DEFAULT_STOP_SEC_CONST_1
   
#elif defined (TCPIP_START_SEC_CONST_8)
   #undef      TCPIP_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (TCPIP_STOP_SEC_CONST_8)
   #undef      TCPIP_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8
   
#elif defined (TCPIP_START_SEC_CONST_16)
   #undef      TCPIP_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (TCPIP_STOP_SEC_CONST_16)
   #undef      TCPIP_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16   
   
#elif defined (TCPIP_START_SEC_CONST_32)
   #undef      TCPIP_START_SEC_CONST_32
   #define DEFAULT_START_SEC_CONST_32
#elif defined (TCPIP_STOP_SEC_CONST_32)
   #undef      TCPIP_STOP_SEC_CONST_32
   #define DEFAULT_STOP_SEC_CONST_32    

#elif defined (TCPIP_START_SEC_CONST_UNSPECIFIED)
   #undef      TCPIP_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (TCPIP_STOP_SEC_CONST_UNSPECIFIED)
   #undef      TCPIP_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (TCPIP_START_SEC_CODE)
   #undef      TCPIP_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (TCPIP_STOP_SEC_CODE)
   #undef      TCPIP_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE  
  

/* -------------------------------------------------------------------------- */
/*             UdpNm                                                          */
/* -------------------------------------------------------------------------- */

#elif defined (UDPNM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      UDPNM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (UDPNM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      UDPNM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (UDPNM_START_SEC_VAR_NO_INIT_8)
   #undef      UDPNM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (UDPNM_STOP_SEC_VAR_NO_INIT_8)
   #undef      UDPNM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (UDPNM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      UDPNM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (UDPNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      UDPNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (UDPNM_START_SEC_CONST_8)
   #undef      UDPNM_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (UDPNM_STOP_SEC_CONST_8)
   #undef      UDPNM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (UDPNM_START_SEC_CONST_UNSPECIFIED)
   #undef      UDPNM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (UDPNM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      UDPNM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (UDPNM_START_SEC_VAR_UNSPECIFIED)
   #undef      UDPNM_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (UDPNM_STOP_SEC_VAR_UNSPECIFIED)
   #undef      UDPNM_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (UDPNM_START_SEC_CODE)
   #undef      UDPNM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (UDPNM_STOP_SEC_CODE)
   #undef      UDPNM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/*----------------------------------------------------------------------------*/
/*                           ETHSM                                              */
/*----------------------------------------------------------------------------*/

  #elif defined (ETHSM_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      ETHSM_START_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (ETHSM_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      ETHSM_STOP_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN

#elif defined (ETHSM_START_SEC_VAR_NO_INIT_8)
   #undef      ETHSM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (ETHSM_STOP_SEC_VAR_NO_INIT_8)
   #undef      ETHSM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (ETHSM_START_SEC_VAR_NO_INIT_16)
   #undef      ETHSM_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (ETHSM_STOP_SEC_VAR_NO_INIT_16)
   #undef      ETHSM_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (ETHSM_START_SEC_VAR_NO_INIT_32)
   #undef      ETHSM_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (ETHSM_STOP_SEC_VAR_NO_INIT_32)
   #undef      ETHSM_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (ETHSM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      ETHSM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (ETHSM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      ETHSM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (ETHSM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      ETHSM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (ETHSM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      ETHSM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (ETHSM_START_SEC_VAR_CLEARED_8)
   #undef      ETHSM_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (ETHSM_STOP_SEC_VAR_CLEARED_8)
   #undef      ETHSM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (ETHSM_START_SEC_VAR_CLEARED_16)
   #undef      ETHSM_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (ETHSM_STOP_SEC_VAR_CLEARED_16)
   #undef      ETHSM_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (ETHSM_START_SEC_VAR_CLEARED_32)
   #undef      ETHSM_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (ETHSM_STOP_SEC_VAR_CLEARED_32)
   #undef      ETHSM_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (ETHSM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      ETHSM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (ETHSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      ETHSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (ETHSM_START_SEC_VAR_INIT_BOOLEAN)
   #undef      ETHSM_START_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_INIT_BOOLEAN
#elif defined (ETHSM_STOP_SEC_VAR_INIT_BOOLEAN)
   #undef      ETHSM_STOP_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_INIT_BOOLEAN

#elif defined (ETHSM_START_SEC_VAR_INIT_8)
   #undef      ETHSM_START_SEC_VAR_INIT_8
   #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (ETHSM_STOP_SEC_VAR_INIT_8)
   #undef      ETHSM_STOP_SEC_VAR_INIT_8
   #define DEFAULT_STOP_SEC_VAR_INIT_8

#elif defined (ETHSM_START_SEC_VAR_INIT_16)
   #undef      ETHSM_START_SEC_VAR_INIT_16
   #define DEFAULT_START_SEC_VAR_INIT_16
#elif defined (ETHSM_STOP_SEC_VAR_INIT_16)
   #undef      ETHSM_STOP_SEC_VAR_INIT_16
   #define DEFAULT_STOP_SEC_VAR_INIT_16

#elif defined (ETHSM_START_SEC_VAR_INIT_32)
   #undef      ETHSM_START_SEC_VAR_INIT_32
   #define DEFAULT_START_SEC_VAR_INIT_32
#elif defined (ETHSM_STOP_SEC_VAR_INIT_32)
   #undef      ETHSM_STOP_SEC_VAR_INIT_32
   #define DEFAULT_STOP_SEC_VAR_INIT_32

#elif defined (ETHSM_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      ETHSM_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (ETHSM_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      ETHSM_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED

#elif defined (ETHSM_START_SEC_CONST_BOOLEAN)
   #undef      ETHSM_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (ETHSM_STOP_SEC_CONST_BOOLEAN)
   #undef      ETHSM_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (ETHSM_START_SEC_CONST_8)
   #undef      ETHSM_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (ETHSM_STOP_SEC_CONST_8)
   #undef      ETHSM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (ETHSM_START_SEC_CONST_16)
   #undef      ETHSM_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (ETHSM_STOP_SEC_CONST_16)
   #undef      ETHSM_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

#elif defined (ETHSM_START_SEC_CONST_UNSPECIFIED)
   #undef      ETHSM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (ETHSM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      ETHSM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (ETHSM_START_SEC_CODE)
   #undef      ETHSM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (ETHSM_STOP_SEC_CODE)
   #undef      ETHSM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/*----------------------------------------------------------------------------*/
/*                           E2E                                              */
/*----------------------------------------------------------------------------*/

  #elif defined (E2E_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      E2E_START_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (E2E_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      E2E_STOP_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN

#elif defined (E2E_START_SEC_VAR_NO_INIT_8)
   #undef      E2E_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (E2E_STOP_SEC_VAR_NO_INIT_8)
   #undef      E2E_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (E2E_START_SEC_VAR_NO_INIT_16)
   #undef      E2E_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (E2E_STOP_SEC_VAR_NO_INIT_16)
   #undef      E2E_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (E2E_START_SEC_VAR_NO_INIT_32)
   #undef      E2E_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (E2E_STOP_SEC_VAR_NO_INIT_32)
   #undef      E2E_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (E2E_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      E2E_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (E2E_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      E2E_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (E2E_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      E2E_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (E2E_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      E2E_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (E2E_START_SEC_VAR_CLEARED_8)
   #undef      E2E_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (E2E_STOP_SEC_VAR_CLEARED_8)
   #undef      E2E_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (E2E_START_SEC_VAR_CLEARED_16)
   #undef      E2E_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (E2E_STOP_SEC_VAR_CLEARED_16)
   #undef      E2E_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (E2E_START_SEC_VAR_CLEARED_32)
   #undef      E2E_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (E2E_STOP_SEC_VAR_CLEARED_32)
   #undef      E2E_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (E2E_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      E2E_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (E2E_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      E2E_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (E2E_START_SEC_VAR_INIT_BOOLEAN)
   #undef      E2E_START_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_INIT_BOOLEAN
#elif defined (E2E_STOP_SEC_VAR_INIT_BOOLEAN)
   #undef      E2E_STOP_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_INIT_BOOLEAN

#elif defined (E2E_START_SEC_VAR_INIT_8)
   #undef      E2E_START_SEC_VAR_INIT_8
   #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (E2E_STOP_SEC_VAR_INIT_8)
   #undef      E2E_STOP_SEC_VAR_INIT_8
   #define DEFAULT_STOP_SEC_VAR_INIT_8

#elif defined (E2E_START_SEC_VAR_INIT_16)
   #undef      E2E_START_SEC_VAR_INIT_16
   #define DEFAULT_START_SEC_VAR_INIT_16
#elif defined (E2E_STOP_SEC_VAR_INIT_16)
   #undef      E2E_STOP_SEC_VAR_INIT_16
   #define DEFAULT_STOP_SEC_VAR_INIT_16

#elif defined (E2E_START_SEC_VAR_INIT_32)
   #undef      E2E_START_SEC_VAR_INIT_32
   #define DEFAULT_START_SEC_VAR_INIT_32
#elif defined (E2E_STOP_SEC_VAR_INIT_32)
   #undef      E2E_STOP_SEC_VAR_INIT_32
   #define DEFAULT_STOP_SEC_VAR_INIT_32

#elif defined (E2E_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      E2E_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (E2E_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      E2E_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED

#elif defined (E2E_START_SEC_CONST_BOOLEAN)
   #undef      E2E_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (E2E_STOP_SEC_CONST_BOOLEAN)
   #undef      E2E_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (E2E_START_SEC_CONST_8)
   #undef      E2E_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (E2E_STOP_SEC_CONST_8)
   #undef      E2E_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (E2E_START_SEC_CONST_16)
   #undef      E2E_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (E2E_STOP_SEC_CONST_16)
   #undef      E2E_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

#elif defined (E2E_START_SEC_CONST_UNSPECIFIED)
   #undef      E2E_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (E2E_STOP_SEC_CONST_UNSPECIFIED)
   #undef      E2E_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (E2E_START_SEC_CODE)
   #undef      E2E_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (E2E_STOP_SEC_CODE)
   #undef      E2E_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*                 CAN Transceiver                                            */
/* -------------------------------------------------------------------------- */

#elif defined (CANTRCV_6251DS_START_SEC_CODE)
   #undef      CANTRCV_6251DS_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE

#elif defined (CANTRCV_6251DS_STOP_SEC_CODE)
   #undef      CANTRCV_6251DS_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (CANTRCV_6251DS_START_SEC_CONST_UNSPECIFIED)
   #undef      CANTRCV_6251DS_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED

#elif defined (CANTRCV_6251DS_STOP_SEC_CONST_UNSPECIFIED)
   #undef      CANTRCV_6251DS_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (CANTRCV_6251DS_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANTRCV_6251DS_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (CANTRCV_6251DS_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANTRCV_6251DS_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (CANTRCV_6251DS_START_SEC_VAR_CLEARED_8)
   #undef      CANTRCV_6251DS_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (CANTRCV_6251DS_STOP_SEC_VAR_CLEARED_8)
   #undef      CANTRCV_6251DS_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

/* -------------------------------------------------------------------------- */
/*             StbM                                                           */
/* -------------------------------------------------------------------------- */

#elif defined (STBM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      STBM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (STBM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      STBM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (STBM_START_SEC_VAR_CLEARED_8)
   #undef      STBM_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (STBM_STOP_SEC_VAR_CLEARED_8)
   #undef      STBM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (STBM_START_SEC_VAR_CLEARED_16)
   #undef      STBM_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (STBM_STOP_SEC_VAR_CLEARED_16)
   #undef      STBM_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (STBM_START_SEC_VAR_CLEARED_32)
   #undef      STBM_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (STBM_STOP_SEC_VAR_CLEARED_32)
   #undef      STBM_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (STBM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      STBM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (STBM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      STBM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (STBM_START_SEC_VAR_INIT_BOOLEAN)
   #undef      STBM_START_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_INIT_BOOLEAN
#elif defined (STBM_STOP_SEC_VAR_INIT_BOOLEAN)
   #undef      STBM_STOP_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_INIT_BOOLEAN

#elif defined (STBM_START_SEC_VAR_INIT_8)
   #undef      STBM_START_SEC_VAR_INIT_8
   #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (STBM_STOP_SEC_VAR_INIT_8)
   #undef      STBM_STOP_SEC_VAR_INIT_8
   #define DEFAULT_STOP_SEC_VAR_INIT_8

#elif defined (STBM_START_SEC_VAR_INIT_16)
   #undef      STBM_START_SEC_VAR_INIT_16
   #define DEFAULT_START_SEC_VAR_INIT_16
#elif defined (STBM_STOP_SEC_VAR_INIT_16)
   #undef      STBM_STOP_SEC_VAR_INIT_16
   #define DEFAULT_STOP_SEC_VAR_INIT_16

#elif defined (STBM_START_SEC_VAR_INIT_32)
   #undef      STBM_START_SEC_VAR_INIT_32
   #define DEFAULT_START_SEC_VAR_INIT_32
#elif defined (STBM_STOP_SEC_VAR_INIT_32)
   #undef      STBM_STOP_SEC_VAR_INIT_32
   #define DEFAULT_STOP_SEC_VAR_INIT_32

#elif defined (STBM_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      STBM_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (STBM_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      STBM_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED

#elif defined (STBM_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      STBM_START_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (STBM_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      STBM_STOP_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN

#elif defined (STBM_START_SEC_VAR_NO_INIT_8)
   #undef      STBM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (STBM_STOP_SEC_VAR_NO_INIT_8)
   #undef      STBM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (STBM_START_SEC_VAR_NO_INIT_16)
   #undef      STBM_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (STBM_STOP_SEC_VAR_NO_INIT_16)
   #undef      STBM_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (STBM_START_SEC_VAR_NO_INIT_32)
   #undef      STBM_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (STBM_STOP_SEC_VAR_NO_INIT_32)
   #undef      STBM_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (STBM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      STBM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (STBM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      STBM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (STBM_START_SEC_CONST_BOOLEAN)
   #undef      STBM_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (STBM_STOP_SEC_CONST_BOOLEAN)
   #undef      STBM_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (STBM_START_SEC_CONST_8)
   #undef      STBM_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (STBM_STOP_SEC_CONST_8)
   #undef      STBM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (STBM_START_SEC_CONST_16)
   #undef      STBM_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (STBM_STOP_SEC_CONST_16)
   #undef      STBM_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

#elif defined (STBM_START_SEC_CONST_32)
   #undef      STBM_START_SEC_CONST_32
   #define DEFAULT_START_SEC_CONST_32
#elif defined (STBM_STOP_SEC_CONST_32)
   #undef      STBM_STOP_SEC_CONST_32
   #define DEFAULT_STOP_SEC_CONST_32

#elif defined (STBM_START_SEC_CONST_UNSPECIFIED)
   #undef      STBM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (STBM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      STBM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (STBM_START_SEC_CODE)
   #undef      STBM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (STBM_STOP_SEC_CODE)
   #undef      STBM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*                 DLT                                                        */
/* -------------------------------------------------------------------------- */
#elif defined (DLT_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DLT_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (DLT_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DLT_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (DLT_START_SEC_VAR_CLEARED_8)
   #undef      DLT_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (DLT_STOP_SEC_VAR_CLEARED_8)
   #undef      DLT_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (DLT_START_SEC_VAR_CLEARED_16)
   #undef      DLT_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (DLT_STOP_SEC_VAR_CLEARED_16)
   #undef      DLT_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (DLT_START_SEC_VAR_CLEARED_32)
   #undef      DLT_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (DLT_STOP_SEC_VAR_CLEARED_32)
   #undef      DLT_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (DLT_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      DLT_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (DLT_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      DLT_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (DLT_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      DLT_START_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (DLT_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      DLT_STOP_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN

#elif defined (DLT_START_SEC_VAR_NO_INIT_8)
   #undef      DLT_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (DLT_STOP_SEC_VAR_NO_INIT_8)
   #undef      DLT_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (DLT_START_SEC_VAR_NO_INIT_16)
   #undef      DLT_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (DLT_STOP_SEC_VAR_NO_INIT_16)
   #undef      DLT_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (DLT_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DLT_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (DLT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DLT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (DLT_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      DLT_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
#elif defined (DLT_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      DLT_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED

#elif defined (DLT_START_SEC_CONST_UNSPECIFIED)
   #undef      DLT_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DLT_STOP_SEC_CONST_UNSPECIFIED)
   #undef      DLT_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DLT_START_SEC_CODE)
   #undef      DLT_START_SEC_CODE
   #define     DEFAULT_START_SEC_CODE
#elif defined (DLT_STOP_SEC_CODE)
   #undef      DLT_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*             ETHIF                                                          */
/* -------------------------------------------------------------------------- */
#elif defined (ETHIF_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      ETHIF_START_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (ETHIF_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      ETHIF_STOP_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN

#elif defined (ETHIF_START_SEC_VAR_NO_INIT_8)
   #undef      ETHIF_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (ETHIF_STOP_SEC_VAR_NO_INIT_8)
   #undef      ETHIF_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (ETHIF_START_SEC_VAR_NO_INIT_16)
   #undef      ETHIF_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (ETHIF_STOP_SEC_VAR_NO_INIT_16)
   #undef      ETHIF_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (ETHIF_START_SEC_VAR_NO_INIT_32)
   #undef      ETHIF_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (ETHIF_STOP_SEC_VAR_NO_INIT_32)
   #undef      ETHIF_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (ETHIF_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      ETHIF_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (ETHIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      ETHIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (ETHIF_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      ETHIF_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (ETHIF_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      ETHIF_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (ETHIF_START_SEC_VAR_CLEARED_8)
   #undef      ETHIF_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (ETHIF_STOP_SEC_VAR_CLEARED_8)
   #undef      ETHIF_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (ETHIF_START_SEC_VAR_CLEARED_16)
   #undef      ETHIF_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (ETHIF_STOP_SEC_VAR_CLEARED_16)
   #undef      ETHIF_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (ETHIF_START_SEC_VAR_CLEARED_32)
   #undef      ETHIF_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (ETHIF_STOP_SEC_VAR_CLEARED_32)
   #undef      ETHIF_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (ETHIF_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      ETHIF_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (ETHIF_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      ETHIF_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (ETHIF_START_SEC_VAR_INIT_BOOLEAN)
   #undef      ETHIF_START_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_INIT_BOOLEAN
#elif defined (ETHIF_STOP_SEC_VAR_INIT_BOOLEAN)
   #undef      ETHIF_STOP_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_INIT_BOOLEAN

#elif defined (ETHIF_START_SEC_VAR_INIT_8)
   #undef      ETHIF_START_SEC_VAR_INIT_8
   #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (ETHIF_STOP_SEC_VAR_INIT_8)
   #undef      ETHIF_STOP_SEC_VAR_INIT_8
   #define DEFAULT_STOP_SEC_VAR_INIT_8

#elif defined (ETHIF_START_SEC_VAR_INIT_16)
   #undef      ETHIF_START_SEC_VAR_INIT_16
   #define DEFAULT_START_SEC_VAR_INIT_16
#elif defined (ETHIF_STOP_SEC_VAR_INIT_16)
   #undef      ETHIF_STOP_SEC_VAR_INIT_16
   #define DEFAULT_STOP_SEC_VAR_INIT_16

#elif defined (ETHIF_START_SEC_VAR_INIT_32)
   #undef      ETHIF_START_SEC_VAR_INIT_32
   #define DEFAULT_START_SEC_VAR_INIT_32
#elif defined (ETHIF_STOP_SEC_VAR_INIT_32)
   #undef      ETHIF_STOP_SEC_VAR_INIT_32
   #define DEFAULT_STOP_SEC_VAR_INIT_32

#elif defined (ETHIF_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      ETHIF_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (ETHIF_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      ETHIF_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED

#elif defined (ETHIF_START_SEC_CONST_BOOLEAN)
   #undef      ETHIF_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (ETHIF_STOP_SEC_CONST_BOOLEAN)
   #undef      ETHIF_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (ETHIF_START_SEC_CONST_8)
   #undef      ETHIF_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (ETHIF_STOP_SEC_CONST_8)
   #undef      ETHIF_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (ETHIF_START_SEC_CONST_16)
   #undef      ETHIF_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (ETHIF_STOP_SEC_CONST_16)
   #undef      ETHIF_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

#elif defined (ETHIF_START_SEC_CONST_UNSPECIFIED)
   #undef      ETHIF_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (ETHIF_STOP_SEC_CONST_UNSPECIFIED)
   #undef      ETHIF_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (ETHIF_START_SEC_CODE)
   #undef      ETHIF_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (ETHIF_STOP_SEC_CODE)
   #undef      ETHIF_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE
/*----------------------------------------------------------------------------*/
/*                           J1939TP                                          */
/*----------------------------------------------------------------------------*/
#elif defined (J1939TP_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      J1939TP_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (J1939TP_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      J1939TP_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (J1939TP_START_SEC_VAR_CLEARED_8)
   #undef      J1939TP_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (J1939TP_STOP_SEC_VAR_CLEARED_8)
   #undef      J1939TP_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (J1939TP_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      J1939TP_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (J1939TP_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      J1939TP_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (J1939TP_START_SEC_VAR_NO_INIT_8)
   #undef      J1939TP_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (J1939TP_STOP_SEC_VAR_NO_INIT_8)
   #undef      J1939TP_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (J1939TP_START_SEC_VAR_NO_INIT_16)
   #undef      J1939TP_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (J1939TP_STOP_SEC_VAR_NO_INIT_16)
   #undef      J1939TP_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (J1939TP_START_SEC_VAR_NO_INIT_32)
   #undef      J1939TP_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (J1939TP_STOP_SEC_VAR_NO_INIT_32)
   #undef      J1939TP_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (J1939TP_START_SEC_VAR_SAVED_ZONE_16)
   #undef      J1939TP_START_SEC_VAR_SAVED_ZONE_16
   #define DEFAULT_START_SEC_VAR_SAVED_ZONE_16
#elif defined (J1939TP_STOP_SEC_VAR_SAVED_ZONE_16)
   #undef      J1939TP_STOP_SEC_VAR_SAVED_ZONE_16
   #define DEFAULT_STOP_SEC_VAR_SAVED_ZONE_16

#elif defined (J1939TP_START_SEC_VAR_SAVED_ZONE_8)
   #undef      J1939TP_START_SEC_VAR_SAVED_ZONE_8
   #define DEFAULT_START_SEC_VAR_SAVED_ZONE_8
#elif defined (J1939TP_STOP_SEC_VAR_SAVED_ZONE_8)
   #undef      J1939TP_STOP_SEC_VAR_SAVED_ZONE_8
   #define DEFAULT_STOP_SEC_VAR_SAVED_ZONE_8

#elif defined (J1939TP_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      J1939TP_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (J1939TP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      J1939TP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (J1939TP_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      J1939TP_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
#elif defined (J1939TP_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      J1939TP_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED

#elif defined (J1939TP_START_SEC_CONST_8)
   #undef      J1939TP_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (J1939TP_STOP_SEC_CONST_8)
   #undef      J1939TP_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (J1939TP_START_SEC_CONST_UNSPECIFIED)
   #undef      J1939TP_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (J1939TP_STOP_SEC_CONST_UNSPECIFIED)
   #undef      J1939TP_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (J1939TP_START_SEC_CODE)
   #undef      J1939TP_START_SEC_CODE
   #define     DEFAULT_START_SEC_CODE
#elif defined (J1939TP_STOP_SEC_CODE)
   #undef      J1939TP_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE
/* -------------------------------------------------------------------------- */
/*             DOIP                                                          */
/* -------------------------------------------------------------------------- */

#elif defined (DOIP_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DOIP_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (DOIP_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DOIP_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (DOIP_START_SEC_VAR_NO_INIT_8)
   #undef      DOIP_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (DOIP_STOP_SEC_VAR_NO_INIT_8)
   #undef      DOIP_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (DOIP_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DOIP_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (DOIP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DOIP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (DOIP_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      DOIP_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (DOIP_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      DOIP_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED

#elif defined (DOIP_START_SEC_CONST_8)
   #undef      DOIP_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (DOIP_STOP_SEC_CONST_8)
   #undef      DOIP_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (DOIP_START_SEC_CONST_UNSPECIFIED)
   #undef      DOIP_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DOIP_STOP_SEC_CONST_UNSPECIFIED)
   #undef      DOIP_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DOIP_START_SEC_VAR_UNSPECIFIED)
   #undef      DOIP_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (DOIP_STOP_SEC_VAR_UNSPECIFIED)
   #undef      DOIP_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DOIP_START_SEC_CODE)
   #undef      DOIP_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (DOIP_STOP_SEC_CODE)
   #undef      DOIP_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (DOIP_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      DOIP_START_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (DOIP_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      DOIP_STOP_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN

#elif defined (DOIP_START_SEC_VAR_NO_INIT_32)
   #undef      DOIP_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (DOIP_STOP_SEC_VAR_NO_INIT_32)
   #undef      DOIP_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (DOIP_START_SEC_VAR_NO_INIT_16)
   #undef      DOIP_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (DOIP_STOP_SEC_VAR_NO_INIT_16)
   #undef      DOIP_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

/* -------------------------------------------------------------------------- */
/*                 LinSM                                                      */
/* -------------------------------------------------------------------------- */

   #elif defined (LINSM_START_SEC_CONST_UNSPECIFIED)
   #undef      LINSM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (LINSM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      LINSM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

   #elif defined (LINSM_START_SEC_CONST_8)
   #undef      LINSM_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (LINSM_STOP_SEC_CONST_8)
   #undef      LINSM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

   #elif defined (LINSM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      LINSM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (LINSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      LINSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

  #elif defined (LINSM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINSM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (LINSM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINSM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

  #elif defined (LINSM_START_SEC_VAR_CLEARED_8)
   #undef      LINSM_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (LINSM_STOP_SEC_VAR_CLEARED_8)
   #undef      LINSM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

  #elif defined (LINSM_START_SEC_CODE)
   #undef      LINSM_START_SEC_CODE
   #define     DEFAULT_START_SEC_CODE
#elif defined (LINSM_STOP_SEC_CODE)
   #undef      LINSM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* ---------------------------------------------------------------------------*/
/*                           MEMIF                                            */
/* -------------------------------------------------------------------------- */
#elif defined (MEMIF_START_SEC_CODE)
   #undef MEMIF_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (MEMIF_STOP_SEC_CODE)
   #undef MEMIF_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* ---------------------------------------------------------------------------*/
/*                           WDGIF                                            */
/* -------------------------------------------------------------------------- */
#elif defined (WDGIF_START_SEC_CODE)
   #undef WDGIF_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (WDGIF_STOP_SEC_CODE)
   #undef WDGIF_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (WDGIF_START_SEC_CONST_UNSPECIFIED)
   #undef WDGIF_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (WDGIF_STOP_SEC_CONST_UNSPECIFIED)
   #undef WDGIF_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

/* ---------------------------------------------------------------------------*/
/*                           WDG_39_ACW                                       */
/* -------------------------------------------------------------------------- */
#elif defined (WDG_39_ACW_START_SEC_CODE)
   #undef WDG_39_ACW_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (WDG_39_ACW_STOP_SEC_CODE)
   #undef WDG_39_ACW_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (WDG_39_ACW_START_SEC_VAR_CLEARED_32)
   #undef WDG_39_ACW_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (WDG_39_ACW_STOP_SEC_VAR_CLEARED_32)
   #undef WDG_39_ACW_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (WDG_39_ACW_START_SEC_CONST_8)
   #undef WDG_39_ACW_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (WDG_39_ACW_STOP_SEC_CONST_8)
   #undef WDG_39_ACW_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (WDG_39_ACW_START_SEC_CONST_32)
   #undef WDG_39_ACW_START_SEC_CONST_32
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (WDG_39_ACW_STOP_SEC_CONST_32)
   #undef WDG_39_ACW_STOP_SEC_CONST_32
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (WDG_39_ACW_START_SEC_VAR_UNSPECIFIED)
   #undef WDG_39_ACW_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (WDG_39_ACW_STOP_SEC_VAR_UNSPECIFIED)
   #undef WDG_39_ACW_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (WDG_39_ACW_START_SEC_CONST_UNSPECIFIED)
   #undef WDG_39_ACW_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (WDG_39_ACW_STOP_SEC_CONST_UNSPECIFIED)
   #undef WDG_39_ACW_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/*                             LinNm                                          */
/* -------------------------------------------------------------------------- */
#elif defined (LINNM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINNM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (LINNM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINNM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (LINNM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      LINNM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (LINNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      LINNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (LINNM_START_SEC_CONST_UNSPECIFIED)
   #undef      LINNM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (LINNM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      LINNM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (LINNM_START_SEC_CODE)
   #undef      LINNM_START_SEC_CODE
   #define     DEFAULT_START_SEC_CODE
#elif defined (LINNM_STOP_SEC_CODE)
   #undef      LINNM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

 /* -------------------------------------------------------------------------- */
/*             LinTrcv                                                        */
/* -------------------------------------------------------------------------- */
#elif defined (LINTRCV_7259GE_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINTRCV_7259GE_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (LINTRCV_7259GE_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINTRCV_7259GE_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (LINTRCV_7259GE_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      LINTRCV_7259GE_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (LINTRCV_7259GE_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      LINTRCV_7259GE_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (LINTRCV_7259GE_START_SEC_CONST_UNSPECIFIED)
   #undef      LINTRCV_7259GE_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (LINTRCV_7259GE_STOP_SEC_CONST_UNSPECIFIED)
   #undef      LINTRCV_7259GE_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (LINTRCV_7259GE_START_SEC_CODE)
   #undef      LINTRCV_7259GE_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (LINTRCV_7259GE_STOP_SEC_CODE)
   #undef      LINTRCV_7259GE_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (LINTRCV_7259GE_START_SEC_CODE)
   #undef      LINTRCV_7259GE_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (LINTRCV_7259GE_STOP_SEC_CODE)
   #undef      LINTRCV_7259GE_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/*             FiM                                                            */
/* -------------------------------------------------------------------------- */

#elif defined (FIM_START_SEC_CODE)
   #undef      FIM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (FIM_STOP_SEC_CODE)
   #undef      FIM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (FIM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FIM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (FIM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FIM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (FIM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FIM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (FIM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FIM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (FIM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      FIM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (FIM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      FIM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (FIM_START_SEC_CONST_UNSPECIFIED)
   #undef      FIM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FIM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      FIM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED


/* -------------------------------------------------------------------------- */
/*                 FRSM                                                       */
/* -------------------------------------------------------------------------- */
#elif defined (FRSM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRSM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (FRSM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRSM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

   #elif defined (FRSM_START_SEC_VAR_CLEARED_8)
   #undef      FRSM_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (FRSM_STOP_SEC_VAR_CLEARED_8)
   #undef      FRSM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (FRSM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      FRSM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (FRSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      FRSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (FRSM_START_SEC_VAR_NO_INIT_8)
   #undef      FRSM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (FRSM_STOP_SEC_VAR_NO_INIT_8)
   #undef      FRSM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (FRSM_START_SEC_CONST_UNSPECIFIED)
   #undef      FRSM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRSM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      FRSM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FRSM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRSM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (FRSM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRSM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (FRSM_START_SEC_CODE)
   #undef      FRSM_START_SEC_CODE
   #define     DEFAULT_START_SEC_CODE
#elif defined (FRSM_STOP_SEC_CODE)
   #undef      FRSM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*             FrIf                                                          */
/* -------------------------------------------------------------------------- */
#elif defined (FRIF_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRIF_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (FRIF_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRIF_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (FRIF_START_SEC_CONST_UNSPECIFIED)
   #undef      FRIF_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRIF_STOP_SEC_CONST_UNSPECIFIED)
   #undef      FRIF_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

   #elif defined (FRIF_START_SEC_VAR_NO_INIT_8)
   #undef      FRIF_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (FRIF_STOP_SEC_VAR_NO_INIT_8)
   #undef      FRIF_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (FRIF_START_SEC_VAR_NO_INIT_8)
   #undef      FRIF_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (FRIF_STOP_SEC_VAR_NO_INIT_8)
   #undef      FRIF_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (FRIF_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRIF_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (FRIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (FRIF_START_SEC_VAR_CLEARED_16)
   #undef      FRIF_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (FRIF_STOP_SEC_VAR_CLEARED_16)
   #undef      FRIF_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (FRIF_START_SEC_CONST_8)
   #undef      FRIF_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (FRIF_STOP_SEC_CONST_8)
   #undef      FRIF_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (FRIF_START_SEC_CONST_UNSPECIFIED)
   #undef      FRIF_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRIF_STOP_SEC_CONST_UNSPECIFIED)
   #undef      FRIF_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FRIF_START_SEC_CODE)
   #undef      FRIF_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (FRIF_STOP_SEC_CODE)
   #undef      FRIF_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*             FrTrcv                                                         */
/* -------------------------------------------------------------------------- */
#elif defined (FRTRCV_1080A_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRTRCV_1080A_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_1
#elif defined (FRTRCV_1080A_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRTRCV_1080A_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_1

#elif defined (FRTRCV_1080A_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRTRCV_1080A_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (FRTRCV_1080A_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRTRCV_1080A_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (FRTRCV_1080A_START_SEC_CONST_UNSPECIFIED)
   #undef      FRTRCV_1080A_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRTRCV_1080A_STOP_SEC_CONST_UNSPECIFIED)
   #undef      FRTRCV_1080A_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FRTRCV_1080A_START_SEC_CODE)
   #undef      FRTRCV_1080A_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined FRTRCV_1080A_STOP_SEC_CODE
   #undef      FRTRCV_1080A_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*                 CRC                                                        */
/* -------------------------------------------------------------------------- */

#elif defined (CRC_START_SEC_CONST_8)
   #undef      CRC_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (CRC_STOP_SEC_CONST_8)
   #undef      CRC_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (CRC_START_SEC_CONST_16)
   #undef      CRC_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (CRC_STOP_SEC_CONST_16)
   #undef      CRC_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

#elif defined (CRC_START_SEC_CONST_32)
   #undef      CRC_START_SEC_CONST_32
   #define DEFAULT_START_SEC_CONST_32
#elif defined (CRC_STOP_SEC_CONST_32)
   #undef      CRC_STOP_SEC_CONST_32
   #define DEFAULT_STOP_SEC_CONST_32

#elif defined (CRC_START_SEC_CODE)
   #undef      CRC_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (CRC_STOP_SEC_CODE)
   #undef      CRC_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*             Ea                                                            */
/* -------------------------------------------------------------------------- */

#elif defined (EA_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      EA_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (EA_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      EA_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (EA_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      EA_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
#elif defined (EA_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      EA_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED

#elif defined (EA_START_SEC_NO_INIT_VAR_UNSPECIFIED)
   #undef      EA_START_SEC_NO_INIT_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (EA_STOP_SEC_NO_INIT_VAR_UNSPECIFIED)
   #undef      EA_STOP_SEC_NO_INIT_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (EA_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      EA_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (EA_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      EA_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (EA_START_SEC_NO_INIT_VAR_8)
   #undef      EA_START_SEC_NO_INIT_VAR_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (EA_STOP_SEC_NO_INIT_VAR_8)
   #undef      EA_STOP_SEC_NO_INIT_VAR_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

   #elif defined (EA_START_SEC_NO_INIT_VAR_BOOLEAN)
   #undef      EA_START_SEC_NO_INIT_VAR_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (EA_STOP_SEC_NO_INIT_VAR_BOOLEAN)
   #undef      EA_STOP_SEC_NO_INIT_VAR_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN

#elif defined (EA_START_SEC_NO_INIT_VAR_16)
   #undef      EA_START_SEC_NO_INIT_VAR_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (EA_STOP_SEC_NO_INIT_VAR_16)
   #undef      EA_STOP_SEC_NO_INIT_VAR_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (EA_START_SEC_CODE)
   #undef      EA_START_SEC_CODE
#define     DEFAULT_START_SEC_CODE
#elif defined (EA_STOP_SEC_CODE)
   #undef      EA_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (EA_START_SEC_CONST_UNSPECIFIED)
   #undef      EA_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (EA_STOP_SEC_CONST_UNSPECIFIED)
   #undef      EA_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (EA_START_SEC_CONST_16)
   #undef      EA_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (EA_STOP_SEC_CONST_16)
   #undef      EA_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

/* -------------------------------------------------------------------------- */
/*             FrNm                                                          */
/* -------------------------------------------------------------------------- */

#elif defined (FRNM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRNM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (FRNM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRNM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (FRNM_START_SEC_VAR_CLEARED_8)
   #undef      FRNM_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (FRNM_STOP_SEC_VAR_CLEARED_8)
   #undef      FRNM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (FRNM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      FRNM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (FRNM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      FRNM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (FRNM_START_SEC_VAR_NO_INIT_8)
   #undef      FRNM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (FRNM_STOP_SEC_VAR_NO_INIT_8)
   #undef      FRNM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (FRNM_START_SEC_VAR_NO_INIT_16)
   #undef      FRNM_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (FRNM_STOP_SEC_VAR_NO_INIT_16)
   #undef      FRNM_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (FRNM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRNM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (FRNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (FRNM_START_SEC_CONST_8)
   #undef      FRNM_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (FRNM_STOP_SEC_CONST_8)
   #undef      FRNM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (FRNM_START_SEC_CONST_UNSPECIFIED)
   #undef      FRNM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRNM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      FRNM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FRNM_START_SEC_VAR_UNSPECIFIED)
   #undef      FRNM_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (FRNM_STOP_SEC_VAR_UNSPECIFIED)
   #undef      FRNM_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FRNM_START_SEC_CODE)
   #undef      FRNM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (FRNM_STOP_SEC_CODE)
   #undef      FRNM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*                 DBG                                                        */
/* -------------------------------------------------------------------------- */

#elif defined (DBG_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DBG_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (DBG_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DBG_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (DBG_START_SEC_CONST_UNSPECIFIED)
   #undef      DBG_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DBG_STOP_SEC_CONST_UNSPECIFIED)
   #undef      DBG_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DBG_START_SEC_CODE)
   #undef      DBG_START_SEC_CODE
    #define     DEFAULT_START_SEC_CODE
#elif defined (DBG_STOP_SEC_CODE)
   #undef      DBG_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (DBG_START_SEC_VAR_CLEARED_8)
   #undef      DBG_START_SEC_VAR_CLEARED_8
    #define     DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (DBG_STOP_SEC_VAR_CLEARED_8)
   #undef      DBG_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (DBG_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      DBG_START_SEC_VAR_CLEARED_UNSPECIFIED
    #define     DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (DBG_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      DBG_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (DBG_START_SEC_CONST_8)
   #undef      DBG_START_SEC_CONST_8
    #define     DEFAULT_START_SEC_CONST_8
#elif defined (DBG_STOP_SEC_CONST_8)
   #undef      DBG_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (DBG_START_SEC_CONST_16)
   #undef      DBG_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (DBG_STOP_SEC_CONST_16)
   #undef      DBG_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

#elif defined (DBG_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DBG_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (DBG_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DBG_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/*                 WDGM                                                       */
/* -------------------------------------------------------------------------- */

#elif defined (WDGM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      WDGM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (WDGM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      WDGM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (WDGM_START_SEC_CONST_UNSPECIFIED)
   #undef      WDGM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (WDGM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      WDGM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (WDGM_START_SEC_CODE)
   #undef      WDGM_START_SEC_CODE
    #define     DEFAULT_START_SEC_CODE
#elif defined (WDGM_STOP_SEC_CODE)
   #undef      WDGM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (WDGM_START_SEC_VAR_CLEARED_8)
   #undef      WDGM_START_SEC_VAR_CLEARED_8
    #define     DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (WDGM_STOP_SEC_VAR_CLEARED_8)
   #undef      WDGM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (WDGM_START_SEC_VAR_CLEARED_16)
   #undef      WDGM_START_SEC_VAR_CLEARED_16
    #define     DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (WDGM_STOP_SEC_VAR_CLEARED_16)
   #undef      WDGM_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (WDGM_START_SEC_VAR_CLEARED_32)
   #undef      WDGM_START_SEC_VAR_CLEARED_32
    #define     DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (WDGM_STOP_SEC_VAR_CLEARED_32)
   #undef      WDGM_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (WDGM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      WDGM_START_SEC_VAR_CLEARED_UNSPECIFIED
    #define     DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (WDGM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      WDGM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (WDGM_START_SEC_CONST_8)
   #undef      WDGM_START_SEC_CONST_8
    #define     DEFAULT_START_SEC_CONST_8
#elif defined (WDGM_STOP_SEC_CONST_8)
   #undef      WDGM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (WDGM_START_SEC_CONST_16)
   #undef      WDGM_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (WDGM_STOP_SEC_CONST_16)
   #undef      WDGM_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

#elif defined (WDGM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      WDGM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (WDGM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      WDGM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/*            NVM                                                             */
/* -------------------------------------------------------------------------- */
#elif defined (NVM_START_SEC_CODE)
   #undef      NVM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (NVM_STOP_SEC_CODE)
   #undef      NVM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (NVM_START_SEC_CONST_UNSPECIFIED)
   #undef      NVM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (NVM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      NVM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (NVM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      NVM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (NVM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      NVM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (NVM_START_SEC_VAR_CLEARED_16)
   #undef      NVM_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (NVM_STOP_SEC_VAR_CLEARED_16)
   #undef      NVM_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (NVM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      NVM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (NVM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      NVM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (NVM_START_SEC_VAR_NO_INIT_32)
   #undef      NVM_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (NVM_STOP_SEC_VAR_NO_INIT_32)
   #undef      NVM_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (NVM_START_SEC_VAR_NO_INIT_16)
   #undef      NVM_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (NVM_STOP_SEC_VAR_NO_INIT_16)
   #undef      NVM_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (NVM_START_SEC_VAR_NO_INIT_8)
   #undef      NVM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (NVM_STOP_SEC_VAR_NO_INIT_8)
   #undef      NVM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (NVM_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
   #undef      NVM_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
#elif defined (NVM_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
   #undef      NVM_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN

#elif defined (NVM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
   #undef      NVM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
#elif defined (NVM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
   #undef      NVM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED

#elif defined (NVM_START_SEC_VAR_POWER_ON_CLEARED_16)
   #undef      NVM_START_SEC_VAR_POWER_ON_CLEARED_16
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_16
#elif defined (NVM_STOP_SEC_VAR_POWER_ON_CLEARED_16)
   #undef      NVM_STOP_SEC_VAR_POWER_ON_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_16

#elif defined (NVM_START_SEC_VAR_POWER_ON_CLEARED_8)
   #undef      NVM_START_SEC_VAR_POWER_ON_CLEARED_8
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_8
#elif defined (NVM_STOP_SEC_VAR_POWER_ON_CLEARED_8)
   #undef      NVM_STOP_SEC_VAR_POWER_ON_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_8

#elif defined (NVM_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      NVM_START_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (NVM_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      NVM_STOP_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN

#elif defined (NVM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      NVM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (NVM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      NVM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (NVM_START_SEC_CONST_8)
   #undef      NVM_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (NVM_STOP_SEC_CONST_8)
   #undef      NVM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (NVM_START_SEC_VAR_INIT_8)
   #undef      NVM_START_SEC_VAR_INIT_8
   #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (NVM_STOP_SEC_VAR_INIT_8)
   #undef      NVM_STOP_SEC_VAR_INIT_8
   #define DEFAULT_STOP_SEC_VAR_INIT_8

   /* -------------------------------------------------------------------------- */
/*             Dem                                                           */
/* -------------------------------------------------------------------------- */
#elif defined (DEM_START_SEC_CONST_BOOLEAN)
   #undef      DEM_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (DEM_STOP_SEC_CONST_BOOLEAN)
   #undef      DEM_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (DEM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
   #undef      DEM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
#elif defined (DEM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
   #undef      DEM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED

#elif defined (DEM_START_SEC_VAR_CLEARED_8)
   #undef      DEM_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (DEM_STOP_SEC_VAR_CLEARED_8)
   #undef      DEM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (DEM_START_SEC_VAR_CLEARED_16)
   #undef      DEM_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (DEM_STOP_SEC_VAR_CLEARED_16)
   #undef      DEM_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (DEM_START_SEC_VAR_CLEARED_32)
   #undef      DEM_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (DEM_STOP_SEC_VAR_CLEARED_32)
   #undef      DEM_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (DEM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DEM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (DEM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DEM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (DEM_START_SEC_VAR_NO_INIT_8)
   #undef      DEM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (DEM_STOP_SEC_VAR_NO_INIT_8)
   #undef      DEM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (DEM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DEM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (DEM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DEM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED


#elif defined (DEM_START_SEC_CONST_UNSPECIFIED)
   #undef      DEM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DEM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      DEM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DEM_START_SEC_CODE)
   #undef      DEM_START_SEC_CODE
   #define     DEFAULT_START_SEC_CODE
#elif defined (DEM_STOP_SEC_CODE)
   #undef      DEM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*                              Det                                           */
/* -------------------------------------------------------------------------- */
#elif defined (DET_START_SEC_VAR_NO_INIT_16)
   #undef      DET_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (DET_STOP_SEC_VAR_NO_INIT_16)
   #undef      DET_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (DET_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DET_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (DET_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DET_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (DET_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      DET_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (DET_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      DET_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (DET_START_SEC_CONST_UNSPECIFIED)
   #undef      DET_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DET_STOP_SEC_CONST_UNSPECIFIED)
   #undef      DET_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DET_START_SEC_CODE)
   #undef      DET_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (DET_STOP_SEC_CODE)
   #undef      DET_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*             FrTp                                                          */
/* -------------------------------------------------------------------------- */

#elif defined (FRTP_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRTP_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (FRTP_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRTP_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (FRTP_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      FRTP_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define FRTP_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (FRTP_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      FRTP_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define FRTP_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (FRTP_START_SEC_VAR_NO_INIT_8)
   #undef      FRTP_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (FRTP_STOP_SEC_VAR_NO_INIT_8)
   #undef      FRTP_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (FRTP_START_SEC_VAR_CLEARED_8)
   #undef      FRTP_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (FRTP_STOP_SEC_VAR_CLEARED_8)
   #undef      FRTP_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (FRTP_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRTP_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (FRTP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRTP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (FRTP_START_SEC_VAR_CLEARED_16)
   #undef      FRTP_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (FRTP_STOP_SEC_VAR_CLEARED_16)
   #undef      FRTP_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (FRTP_START_SEC_CONST_8)
   #undef      FRTP_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (FRTP_STOP_SEC_CONST_8)
   #undef      FRTP_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (FRTP_START_SEC_CONST_UNSPECIFIED)
   #undef      FRTP_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRTP_STOP_SEC_CONST_UNSPECIFIED)
   #undef      FRTP_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FRTP_START_SEC_CODE)
   #undef      FRTP_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (FRTP_STOP_SEC_CODE)
   #undef      FRTP_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*                 DCM                                                      */
/* -------------------------------------------------------------------------- */
#elif defined (DCM_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
   #undef      DCM_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
#elif defined (DCM_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
   #undef      DCM_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN

#elif defined (DCM_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      DCM_START_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (DCM_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      DCM_STOP_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN

#elif defined (DCM_START_SEC_VAR_NO_INIT_8)
   #undef      DCM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (DCM_STOP_SEC_VAR_NO_INIT_8)
   #undef      DCM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (DCM_START_SEC_VAR_NO_INIT_16)
   #undef      DCM_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (DCM_STOP_SEC_VAR_NO_INIT_16)
   #undef      DCM_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (DCM_START_SEC_VAR_NO_INIT_32)
   #undef      DCM_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (DCM_STOP_SEC_VAR_NO_INIT_32)
   #undef      DCM_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (DCM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DCM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (DCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (DCM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DCM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (DCM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DCM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (DCM_START_SEC_VAR_CLEARED_8)
   #undef      DCM_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (DCM_STOP_SEC_VAR_CLEARED_8)
   #undef      DCM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (DCM_START_SEC_VAR_CLEARED_16)
   #undef      DCM_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (DCM_STOP_SEC_VAR_CLEARED_16)
   #undef      DCM_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (DCM_START_SEC_VAR_CLEARED_32)
   #undef      DCM_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (DCM_STOP_SEC_VAR_CLEARED_32)
   #undef      DCM_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (DCM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      DCM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (DCM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      DCM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (DCM_START_SEC_VAR_INIT_BOOLEAN)
   #undef      DCM_START_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_INIT_BOOLEAN
#elif defined (DCM_STOP_SEC_VAR_INIT_BOOLEAN)
   #undef      DCM_STOP_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_INIT_BOOLEAN

#elif defined (DCM_START_SEC_VAR_INIT_8)
   #undef      DCM_START_SEC_VAR_INIT_8
   #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (DCM_STOP_SEC_VAR_INIT_8)
   #undef      DCM_STOP_SEC_VAR_INIT_8
   #define DEFAULT_STOP_SEC_VAR_INIT_8

#elif defined (DCM_START_SEC_VAR_INIT_16)
   #undef      DCM_START_SEC_VAR_INIT_16
   #define DEFAULT_START_SEC_VAR_INIT_16
#elif defined (DCM_STOP_SEC_VAR_INIT_16)
   #undef      DCM_STOP_SEC_VAR_INIT_16
   #define DEFAULT_STOP_SEC_VAR_INIT_16

#elif defined (DCM_START_SEC_VAR_INIT_32)
   #undef      DCM_START_SEC_VAR_INIT_32
   #define DEFAULT_START_SEC_VAR_INIT_32
#elif defined (DCM_STOP_SEC_VAR_INIT_32)
   #undef      DCM_STOP_SEC_VAR_INIT_32
   #define DEFAULT_STOP_SEC_VAR_INIT_32

#elif defined (DCM_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      DCM_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (DCM_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      DCM_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED

#elif defined (DCM_START_SEC_CONST_BOOLEAN)
   #undef      DCM_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (DCM_STOP_SEC_CONST_BOOLEAN)
   #undef      DCM_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (DCM_START_SEC_CONST_8)
   #undef      DCM_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (DCM_STOP_SEC_CONST_8)
   #undef      DCM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (DCM_START_SEC_CONST_16)
   #undef      DCM_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (DCM_STOP_SEC_CONST_16)
   #undef      DCM_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

#elif defined (DCM_START_SEC_CONST_UNSPECIFIED)
   #undef      DCM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DCM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      DCM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DCM_START_SEC_CODE)
   #undef      DCM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (DCM_STOP_SEC_CODE)
   #undef      DCM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE
   
#elif defined (DCM_START_SEC_CALLOUT_CODE)
   #undef      DCM_START_SEC_CALLOUT_CODE
     #define     DEFAULT_START_SEC_CODE
#elif defined (DCM_STOP_SEC_CALLOUT_CODE)
   #undef      DCM_STOP_SEC_CALLOUT_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*             Xcp                                                           */
/* -------------------------------------------------------------------------- */
#elif defined (XCP_START_SEC_VAR_CLEARED_8)
   #undef      XCP_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (XCP_STOP_SEC_VAR_CLEARED_8)
   #undef      XCP_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (XCP_START_SEC_VAR_CLEARED_16)
   #undef      XCP_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (XCP_STOP_SEC_VAR_CLEARED_16)
   #undef      XCP_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (XCP_START_SEC_CONST_8)
   #undef      XCP_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (XCP_STOP_SEC_CONST_8)
   #undef      XCP_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (XCP_START_SEC_VAR_CLEARED_32)
   #undef      XCP_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (XCP_STOP_SEC_VAR_CLEARED_32)
   #undef      XCP_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (XCP_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      XCP_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (XCP_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      XCP_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (XCP_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
   #undef      XCP_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
#elif defined (XCP_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
   #undef      XCP_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN

#elif defined (XCP_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      XCP_START_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (XCP_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      XCP_STOP_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN

#elif defined (XCP_START_SEC_VAR_NO_INIT_8)
   #undef      XCP_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (XCP_STOP_SEC_VAR_NO_INIT_8)
   #undef      XCP_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (XCP_START_SEC_VAR_NO_INIT_32)
   #undef      XCP_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (XCP_STOP_SEC_VAR_NO_INIT_32)
   #undef      XCP_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (XCP_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      XCP_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (XCP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      XCP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (XCP_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      XCP_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (XCP_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      XCP_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED  

#elif defined (XCP_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      XCP_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (XCP_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      XCP_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (XCP_START_SEC_CONST_UNSPECIFIED)
   #undef      XCP_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (XCP_STOP_SEC_CONST_UNSPECIFIED)
   #undef      XCP_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (XCP_START_SEC_CODE)
   #undef      XCP_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (XCP_STOP_SEC_CODE)
   #undef      XCP_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (XCP_START_SEC_VAR_POWER_ON_CLEARED_8)
   #undef      XCP_START_SEC_VAR_POWER_ON_CLEARED_8
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_8
#elif defined (XCP_STOP_SEC_VAR_POWER_ON_CLEARED_8)
   #undef      XCP_STOP_SEC_VAR_POWER_ON_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_8
   
#elif defined (XCP_START_SEC_VAR_POWER_ON_CLEARED_16)
   #undef      XCP_START_SEC_VAR_POWER_ON_CLEARED_16
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_16
#elif defined (XCP_STOP_SEC_VAR_POWER_ON_CLEARED_16)
   #undef      XCP_STOP_SEC_VAR_POWER_ON_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_16

#elif defined (XCP_START_SEC_VAR_POWER_ON_CLEARED_32)
   #undef      XCP_START_SEC_VAR_POWER_ON_CLEARED_32
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_32
#elif defined (XCP_STOP_SEC_VAR_POWER_ON_CLEARED_32)
   #undef      XCP_STOP_SEC_VAR_POWER_ON_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_32
   
#elif defined (XCP_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
   #undef      XCP_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
#elif defined (XCP_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
   #undef      XCP_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
   
#elif defined (XCP_START_SEC_VAR_POWER_ON_INIT_8)
   #undef      XCP_START_SEC_VAR_POWER_ON_INIT_8
   #define DEFAULT_START_SEC_VAR_POWER_ON_INIT_8
#elif defined (XCP_STOP_SEC_VAR_POWER_ON_INIT_8)
   #undef      XCP_STOP_SEC_VAR_POWER_ON_INIT_8
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_8
   
      #elif defined (XCP_START_SEC_VAR_POWER_ON_INIT_16)
   #undef      XCP_START_SEC_VAR_POWER_ON_INIT_16
   #define DEFAULT_START_SEC_VAR_POWER_ON_INIT_16
#elif defined (XCP_STOP_SEC_VAR_POWER_ON_INIT_16)
   #undef      XCP_STOP_SEC_VAR_POWER_ON_INIT_16
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_16
   
   #elif defined (XCP_START_SEC_VAR_INIT_8)
   #undef      XCP_START_SEC_VAR_INIT_8
   #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (XCP_STOP_SEC_VAR_INIT_8)
   #undef      XCP_STOP_SEC_VAR_INIT_8
   #define DEFAULT_STOP_SEC_VAR_INIT_8
/* -------------------------------------------------------------------------- */
/*             FrTrcv                                                         */
/* -------------------------------------------------------------------------- */
#elif defined (FRTRCV_1080A_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRTRCV_1080A_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_1
#elif defined (FRTRCV_1080A_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRTRCV_1080A_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_1

#elif defined (FRTRCV_1080A_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRTRCV_1080A_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (FRTRCV_1080A_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRTRCV_1080A_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (FRTRCV_1080A_START_SEC_CONST_UNSPECIFIED)
   #undef      FRTRCV_1080A_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRTRCV_1080A_STOP_SEC_CONST_UNSPECIFIED)
   #undef      FRTRCV_1080A_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FRTRCV_1080A_START_SEC_CODE)
   #undef      FRTRCV_1080A_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined FRTRCV_1080A_STOP_SEC_CODE
   #undef      FRTRCV_1080A_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE
/*************************** Stack section ************************************/

/******************************END*********************************************/
/* -------------------------------------------------------------------------- */
/* End of module section mapping                                              */
/* -------------------------------------------------------------------------- */
#elif defined(IPDUM_MODULE_ACTIVE) || defined(COMM_MODULE_ACTIVE) || \
  defined(COM_MODULE_ACTIVE) || defined(NM_MODULE_ACTIVE) || \
  defined(CANTP_MODULE_ACTIVE) || defined(CANSM_MODULE_ACTIVE) || \
  defined(PDUR_MODULE_ACTIVE) || defined(BSWM_MODULE_ACTIVE) || \
  defined(ECUM_MODULE_ACTIVE) || defined(CANNM_MODULE_ACTIVE) || \
  defined(CANIF_MODULE_ACTIVE)

#else
  #error "MemMap.h: No valid section define found"

#endif  /* START_WITH_IF */


/*******************************************************************************
**                      Default section mapping                               **
*******************************************************************************/
/* general start of #elif chain whith #if                                     */
#if defined (START_WITH_IF)

/* -------------------------------------------------------------------------- */
/* RAM variables initialized with zero on reset                               */
/* -------------------------------------------------------------------------- */
 #elif defined (DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN)
    #undef      DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
 #elif defined (DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN)
    #undef      DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

 #elif defined (DEFAULT_START_SEC_VAR_CLEARED_8)
    #undef      DEFAULT_START_SEC_VAR_CLEARED_8
 #elif defined (DEFAULT_STOP_SEC_VAR_CLEARED_8)
    #undef      DEFAULT_STOP_SEC_VAR_CLEARED_8

 #elif defined (DEFAULT_START_SEC_VAR_CLEARED_16)
    #undef      DEFAULT_START_SEC_VAR_CLEARED_16
 #elif defined (DEFAULT_STOP_SEC_VAR_CLEARED_16)
    #undef      DEFAULT_STOP_SEC_VAR_CLEARED_16

 #elif defined (DEFAULT_START_SEC_VAR_CLEARED_32)
    #undef      DEFAULT_START_SEC_VAR_CLEARED_32
 #elif defined (DEFAULT_STOP_SEC_VAR_CLEARED_32)
    #undef      DEFAULT_STOP_SEC_VAR_CLEARED_32

 #elif defined (DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED)
    #undef      DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
 #elif defined (DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
    #undef      DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

 #elif defined (DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
    #undef      DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
 #elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
    #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN

 #elif defined (DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_8)
    #undef      DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_8
 #elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_8)
    #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_8

 #elif defined (DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_16)
    #undef      DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_16
 #elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_16)
    #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_16

 #elif defined (DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_32)
    #undef      DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_32
 #elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_32)
    #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_32

 #elif defined (DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
  #elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED

  #elif defined (DEFAULT_START_SEC_VAR_FAST_CLEARED_BOOLEAN)
     #undef      DEFAULT_START_SEC_VAR_FAST_CLEARED_BOOLEAN
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_CLEARED_BOOLEAN)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_CLEARED_BOOLEAN

  #elif defined (DEFAULT_START_SEC_VAR_FAST_CLEARED_8)
     #undef      DEFAULT_START_SEC_VAR_FAST_CLEARED_8
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_CLEARED_8)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_CLEARED_8

  #elif defined (DEFAULT_START_SEC_VAR_FAST_CLEARED_16)
     #undef      DEFAULT_START_SEC_VAR_FAST_CLEARED_16
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_CLEARED_16)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_CLEARED_16

  #elif defined (DEFAULT_START_SEC_VAR_FAST_CLEARED_32)
     #undef      DEFAULT_START_SEC_VAR_FAST_CLEARED_32
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_CLEARED_32)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_CLEARED_32

  #elif defined (DEFAULT_START_SEC_VAR_FAST_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_START_SEC_VAR_FAST_CLEARED_UNSPECIFIED
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_CLEARED_UNSPECIFIED

  #elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_BOOLEAN)
     #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_BOOLEAN
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_BOOLEAN)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_BOOLEAN

  #elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_8)
     #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_8
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_8)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_8

  #elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_16)
     #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_16
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_16)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_16

  #elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_32)
     #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_32
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_32)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_32

  #elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_UNSPECIFIED
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_UNSPECIFIED

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_CLEARED_BOOLEAN)
     #undef      DEFAULT_START_SEC_VAR_SLOW_CLEARED_BOOLEAN
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_BOOLEAN)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_BOOLEAN

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_CLEARED_8)
     #undef      DEFAULT_START_SEC_VAR_SLOW_CLEARED_8
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_8)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_8

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_CLEARED_16)
     #undef      DEFAULT_START_SEC_VAR_SLOW_CLEARED_16
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_16)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_16

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_CLEARED_32)
     #undef      DEFAULT_START_SEC_VAR_SLOW_CLEARED_32
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_32)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_32

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_START_SEC_VAR_SLOW_CLEARED_UNSPECIFIED
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_UNSPECIFIED

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_BOOLEAN)
     #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_BOOLEAN
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_BOOLEAN)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_BOOLEAN

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_8)
     #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_8
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_8)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_8

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_16)
     #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_16
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_16)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_16

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_32)
     #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_32
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_32)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_32

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_UNSPECIFIED
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_UNSPECIFIED

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_BOOLEAN)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_BOOLEAN
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_BOOLEAN)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_BOOLEAN

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_8)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_8
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_8)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_8

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_16)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_16
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_16)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_16

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_32)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_32
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_32)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_32

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_UNSPECIFIED
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_UNSPECIFIED

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_BOOLEAN)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_BOOLEAN
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_BOOLEAN)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_BOOLEAN

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_8)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_8
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_8)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_8

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_16)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_16
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_16)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_16

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_32)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_32
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_32)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_32

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_UNSPECIFIED
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/* RAM variables initialized                                                  */
/* -------------------------------------------------------------------------- */

#elif defined (DEFAULT_START_SEC_VAR_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_INIT_BOOLEAN
#elif defined (DEFAULT_STOP_SEC_VAR_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_INIT_8
#elif defined (DEFAULT_STOP_SEC_VAR_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_INIT_8


#elif defined (DEFAULT_START_SEC_VAR_INIT_16)
   #undef      DEFAULT_START_SEC_VAR_INIT_16
#elif defined (DEFAULT_STOP_SEC_VAR_INIT_16)
   #undef      DEFAULT_STOP_SEC_VAR_INIT_16


#elif defined (DEFAULT_START_SEC_VAR_INIT_32)
   #undef      DEFAULT_START_SEC_VAR_INIT_32
#elif defined (DEFAULT_STOP_SEC_VAR_INIT_32)
   #undef      DEFAULT_STOP_SEC_VAR_INIT_32


#elif defined (DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_VAR_POWER_ON_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_POWER_ON_INIT_BOOLEAN
#elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_POWER_ON_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_POWER_ON_INIT_8
#elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_8


#elif defined (DEFAULT_START_SEC_VAR_POWER_ON_INIT_16)
   #undef      DEFAULT_START_SEC_VAR_POWER_ON_INIT_16
#elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_16)
   #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_16


#elif defined (DEFAULT_START_SEC_VAR_POWER_ON_INIT_32)
   #undef      DEFAULT_START_SEC_VAR_POWER_ON_INIT_32
#elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_32)
   #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_32


#elif defined (DEFAULT_START_SEC_VAR_POWER_ON_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_POWER_ON_INIT_UNSPECIFIED
#elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_UNSPECIFIED

#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_INIT_BOOLEAN
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_INIT_8)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_INIT_8
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_8)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_8


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_INIT_16)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_INIT_16
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_16)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_16


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_INIT_32)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_INIT_32
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_32)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_32


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_INIT_UNSPECIFIED
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_BOOLEAN
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_8)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_8
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_8)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_8


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_16)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_16
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_16)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_16


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_32)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_32
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_32)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_32


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_UNSPECIFIED
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_UNSPECIFIED

#elif defined (DEFAULT_START_SEC_VAR_FAST_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_FAST_INIT_BOOLEAN
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_FAST_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_FAST_INIT_8
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_INIT_8


#elif defined (DEFAULT_START_SEC_VAR_FAST_INIT_16)
   #undef      DEFAULT_START_SEC_VAR_FAST_INIT_16
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_INIT_16)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_INIT_16


#elif defined (DEFAULT_START_SEC_VAR_FAST_INIT_32)
   #undef      DEFAULT_START_SEC_VAR_FAST_INIT_32
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_INIT_32)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_INIT_32


#elif defined (DEFAULT_START_SEC_VAR_FAST_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_FAST_INIT_UNSPECIFIED
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_INIT_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_BOOLEAN
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_8
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_8


#elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_16)
   #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_16
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_16)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_16


#elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_32)
   #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_32
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_32)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_32


#elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_UNSPECIFIED
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_VAR_SLOW_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_SLOW_INIT_BOOLEAN
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_SLOW_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_SLOW_INIT_8
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_INIT_8


#elif defined (DEFAULT_START_SEC_VAR_SLOW_INIT_16)
   #undef      DEFAULT_START_SEC_VAR_SLOW_INIT_16
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_INIT_16)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_INIT_16


#elif defined (DEFAULT_START_SEC_VAR_SLOW_INIT_32)
   #undef      DEFAULT_START_SEC_VAR_SLOW_INIT_32
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_INIT_32)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_INIT_32


#elif defined (DEFAULT_START_SEC_VAR_SLOW_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_SLOW_INIT_UNSPECIFIED
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_INIT_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_BOOLEAN
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_8
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_8


#elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_16)
   #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_16
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_16)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_16


#elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_32)
   #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_32
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_32)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_32


#elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_UNSPECIFIED
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_UNSPECIFIED


/*----------------------------------------------------------------------------*/
/*                                    APPL RAM DATA                           */
/*----------------------------------------------------------------------------*/

/* -------------------------------------------------------------------------- */
/* RAM variables not initialized                                              */
/* -------------------------------------------------------------------------- */

#elif defined (DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_NO_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (DEFAULT_STOP_SEC_VAR_NO_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_NO_INIT_8


#elif defined (DEFAULT_START_SEC_VAR_NO_INIT_16)
   #undef      DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (DEFAULT_STOP_SEC_VAR_NO_INIT_16)
   #undef      DEFAULT_STOP_SEC_VAR_NO_INIT_16


#elif defined (DEFAULT_START_SEC_VAR_NO_INIT_32)
   #undef      DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (DEFAULT_STOP_SEC_VAR_NO_INIT_32)
   #undef      DEFAULT_STOP_SEC_VAR_NO_INIT_32


#elif defined (DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (DEFAULT_START_SEC_VAR_SLOW_NO_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_SLOW_NO_INIT_BOOLEAN
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_SLOW_NO_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_SLOW_NO_INIT_8
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_8


#elif defined (DEFAULT_START_SEC_VAR_SLOW_NO_INIT_16)
   #undef      DEFAULT_START_SEC_VAR_SLOW_NO_INIT_16
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_16)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_16


#elif defined (DEFAULT_START_SEC_VAR_SLOW_NO_INIT_32)
   #undef      DEFAULT_START_SEC_VAR_SLOW_NO_INIT_32
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_32)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_32


#elif defined (DEFAULT_START_SEC_VAR_SLOW_NO_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_SLOW_NO_INIT_UNSPECIFIED
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_BOOLEAN
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_8)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_8
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_8)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_8

#elif defined (DEFAULT_START_SEC_VAR_NO_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (DEFAULT_STOP_SEC_VAR_NO_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_16)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_16
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_16)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_16


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_32)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_32
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_32)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_32


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_UNSPECIFIED
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_VAR_FAST_NO_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_FAST_NO_INIT_BOOLEAN
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_FAST_NO_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_FAST_NO_INIT_8
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_8


#elif defined (DEFAULT_START_SEC_VAR_FAST_NO_INIT_16)
   #undef      DEFAULT_START_SEC_VAR_FAST_NO_INIT_16
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_16)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_16


#elif defined (DEFAULT_START_SEC_VAR_FAST_NO_INIT_32)
   #undef      DEFAULT_START_SEC_VAR_FAST_NO_INIT_32
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_32)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_32


#elif defined (DEFAULT_START_SEC_VAR_FAST_NO_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_FAST_NO_INIT_UNSPECIFIED
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_VAR_SAVED_ZONE_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_SAVED_ZONE_BOOLEAN
#elif defined (DEFAULT_STOP_SEC_VAR_SAVED_ZONE_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_SAVED_ZONE_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_SAVED_ZONE_8)
   #undef      DEFAULT_START_SEC_VAR_SAVED_ZONE_8
#elif defined (DEFAULT_STOP_SEC_VAR_SAVED_ZONE_8)
   #undef      DEFAULT_STOP_SEC_VAR_SAVED_ZONE_8


#elif defined (DEFAULT_START_SEC_VAR_SAVED_ZONE_16)
   #undef      DEFAULT_START_SEC_VAR_SAVED_ZONE_16
#elif defined (DEFAULT_STOP_SEC_VAR_SAVED_ZONE_16)
   #undef      DEFAULT_STOP_SEC_VAR_SAVED_ZONE_16


#elif defined (DEFAULT_START_SEC_VAR_SAVED_ZONE_32)
   #undef      DEFAULT_START_SEC_VAR_SAVED_ZONE_32
#elif defined (DEFAULT_STOP_SEC_VAR_SAVED_ZONE_32)
   #undef      DEFAULT_STOP_SEC_VAR_SAVED_ZONE_32


#elif defined (DEFAULT_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
#elif defined (DEFAULT_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED


/* -------------------------------------------------------------------------- */
/* ROM constants                                                              */
/* -------------------------------------------------------------------------- */

#elif defined (DEFAULT_START_SEC_CONST_BOOLEAN)
   #undef      DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (DEFAULT_STOP_SEC_CONST_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_CONST_BOOLEAN


#elif defined (DEFAULT_START_SEC_CONST_8)
   #undef      DEFAULT_START_SEC_CONST_8
#elif defined (DEFAULT_STOP_SEC_CONST_8)
   #undef      DEFAULT_STOP_SEC_CONST_8


#elif defined (DEFAULT_START_SEC_CONST_16)
   #undef      DEFAULT_START_SEC_CONST_16
#elif defined (DEFAULT_STOP_SEC_CONST_16)
   #undef      DEFAULT_STOP_SEC_CONST_16


#elif defined (DEFAULT_START_SEC_CONST_32)
   #undef      DEFAULT_START_SEC_CONST_32
#elif defined (DEFAULT_STOP_SEC_CONST_32)
   #undef      DEFAULT_STOP_SEC_CONST_32


#elif defined (DEFAULT_START_SEC_CONST_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DEFAULT_STOP_SEC_CONST_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_CONST_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_CALIB_BOOLEAN)
   #undef      DEFAULT_START_SEC_CALIB_BOOLEAN
#elif defined (DEFAULT_STOP_SEC_CALIB_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_CALIB_BOOLEAN


#elif defined (DEFAULT_START_SEC_CALIB_8)
   #undef      DEFAULT_START_SEC_CALIB_8
#elif defined (DEFAULT_STOP_SEC_CALIB_8)
   #undef      DEFAULT_STOP_SEC_CALIB_8


#elif defined (DEFAULT_START_SEC_CALIB_16)
   #undef      DEFAULT_START_SEC_CALIB_16
#elif defined (DEFAULT_STOP_SEC_CALIB_16)
   #undef      DEFAULT_STOP_SEC_CALIB_16


#elif defined (DEFAULT_START_SEC_CALIB_32)
   #undef      DEFAULT_START_SEC_CALIB_32
#elif defined (DEFAULT_STOP_SEC_CALIB_32)
   #undef      DEFAULT_STOP_SEC_CALIB_32


#elif defined (DEFAULT_START_SEC_CALIB_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_CALIB_UNSPECIFIED
#elif defined (DEFAULT_STOP_SEC_CALIB_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_CALIB_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_CARTO_BOOLEAN)
   #undef      DEFAULT_START_SEC_CARTO_BOOLEAN
#elif defined (DEFAULT_STOP_SEC_CARTO_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_CARTO_BOOLEAN


#elif defined (DEFAULT_START_SEC_CARTO_8)
   #undef      DEFAULT_START_SEC_CARTO_8
#elif defined (DEFAULT_STOP_SEC_CARTO_8)
   #undef      DEFAULT_STOP_SEC_CARTO_8


#elif defined (DEFAULT_START_SEC_CARTO_16)
   #undef      DEFAULT_START_SEC_CARTO_16
#elif defined (DEFAULT_STOP_SEC_CARTO_16)
   #undef      DEFAULT_STOP_SEC_CARTO_16


#elif defined (DEFAULT_START_SEC_CARTO_32)
   #undef      DEFAULT_START_SEC_CARTO_32
#elif defined (DEFAULT_STOP_SEC_CARTO_32)
   #undef      DEFAULT_STOP_SEC_CARTO_32


#elif defined (DEFAULT_START_SEC_CARTO_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_CARTO_UNSPECIFIED
#elif defined (DEFAULT_STOP_SEC_CARTO_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_CARTO_UNSPECIFIED



#elif defined (DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN)
   #undef      DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
#elif defined (DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN

#elif defined (DEFAULT_START_SEC_CONFIG_DATA_8)
   #undef      DEFAULT_START_SEC_CONFIG_DATA_8
#elif defined (DEFAULT_STOP_SEC_CONFIG_DATA_8)
   #undef      DEFAULT_STOP_SEC_CONFIG_DATA_8


#elif defined (DEFAULT_START_SEC_CONFIG_DATA_16)
   #undef      DEFAULT_START_SEC_CONFIG_DATA_16
#elif defined (DEFAULT_STOP_SEC_CONFIG_DATA_16)
   #undef      DEFAULT_STOP_SEC_CONFIG_DATA_16


#elif defined (DEFAULT_START_SEC_CONFIG_DATA_32)
   #undef      DEFAULT_START_SEC_CONFIG_DATA_32
#elif defined (DEFAULT_STOP_SEC_CONFIG_DATA_32)
   #undef      DEFAULT_STOP_SEC_CONFIG_DATA_32


#elif defined (DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_BOOLEAN)
   #undef      DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_BOOLEAN
#elif defined (DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_BOOLEAN


#elif defined (DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_8)
   #undef      DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_8
#elif defined (DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_8)
   #undef      DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_8


#elif defined (DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_16)
   #undef      DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_16
#elif defined (DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_16)
   #undef      DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_16


#elif defined (DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_32)
   #undef      DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_32
#elif defined (DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_32)
   #undef      DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_32


#elif defined (DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_UNSPECIFIED
#elif defined (DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/* ROM code                                                                   */
/* -------------------------------------------------------------------------- */
#elif defined (DEFAULT_START_SEC_CODE)
   #undef      DEFAULT_START_SEC_CODE
#elif defined (DEFAULT_STOP_SEC_CODE)
   #undef      DEFAULT_STOP_SEC_CODE


#elif defined (DEFAULT_START_SEC_CALLOUT_CODE)
   #undef      DEFAULT_START_SEC_CALLOUT_CODE
#elif defined (DEFAULT_STOP_SEC_CALLOUT_CODE)
   #undef      DEFAULT_STOP_SEC_CALLOUT_CODE


#elif defined (DEFAULT_START_SEC_CODE_FAST)
   #undef      DEFAULT_START_SEC_CODE_FAST
#elif defined (DEFAULT_STOP_SEC_CODE_FAST)
   #undef      DEFAULT_STOP_SEC_CODE_FAST


#elif defined (DEFAULT_START_SEC_CODE_SLOW)
   #undef      DEFAULT_START_SEC_CODE_SLOW
#elif defined (DEFAULT_STOP_SEC_CODE_SLOW)
   #undef      DEFAULT_STOP_SEC_CODE_SLOW


#elif defined (DEFAULT_START_SEC_CODE_LIB)
   #undef      DEFAULT_START_SEC_CODE_LIB
#elif defined (DEFAULT_STOP_SEC_CODE_LIB)
   #undef      DEFAULT_STOP_SEC_CODE_LIB

/* ---------------------------------------------------------------------------*/
/* End of default section mapping                                             */
/* ---------------------------------------------------------------------------*/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#endif  /* START_WITH_IF */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
