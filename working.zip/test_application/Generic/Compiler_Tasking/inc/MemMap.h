/*******************************************************************************
**  (C) 2012 KPIT Cummins Infosystems Limited, Hyundai Motor Company,         **
**  Hyundai MOBIS Company and KEFICO Corporation                              **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: MemMap.h                                                      **
**                                                                            **
**  TARGET    : TC27x                                                         **
**                                                                            **
**  PRODUCT   : AUTOSAR BSW R4.0.3 Modules                                    **
**                                                                            **
**  PURPOSE   : Provision for sections for memory mapping.                    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: yes                                          **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: yes                                       **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By     Description                                 **
********************************************************************************
** 1.0.5     10-Jun-2015   JH.Jung EcuM related macros are added              **
** 1.0.4     09-Jun-2015   SONGCY  EEP related macros are added               **
** 1.0.3     09-Mar-2015   Sinil   Wdg related macros are added               **
** 1.0.2     25-Feb-2015   SW.Lee  TcpIp related macros are added             **
** 1.0.1     16-Jan-2015   Sinil  WDGM_START_SEC_VAR_CLEARED_32 added         **
** 1.0.0     09-Sep-2012   MKT    Initial Version                             **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR specification version information */
#define MEMMAP_AR_MAJOR_VERSION   4
#define MEMMAP_AR_MINOR_VERSION   0
#define MEMMAP_AR_PATCH_VERSION   3

/* File version information */
#define MEMMAP_SW_MAJOR_VERSION   1
#define MEMMAP_SW_MINOR_VERSION   0

/*******************************************************************************
**                      Global Symbols                                        **
*******************************************************************************/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Module section mapping                                **
*******************************************************************************/
/*
 * The symbol 'START_WITH_IF' is undefined.
 *
 * Thus, the preprocessor continues searching for defined symbols.
 * This first #ifdef makes integration of delivered parts of MemMap.h
 * easier because every supplier starts with #elif
 */
#if defined (START_WITH_IF)
/* -------------------------------------------------------------------------- */
/*                                 OS                                         */
/* -------------------------------------------------------------------------- */

    /*  No INIT Var Section */

#elif defined (OS_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      OS_START_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (OS_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      OS_STOP_SEC_VAR_NO_INIT_BOOLEAN


#elif defined (OS_START_SEC_VAR_NO_INIT_8)
   #undef      OS_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (OS_STOP_SEC_VAR_NO_INIT_8)
   #undef      OS_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (OS_START_SEC_VAR_NO_INIT_16)
   #undef      OS_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (OS_STOP_SEC_VAR_NO_INIT_16)
   #undef      OS_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (OS_START_SEC_VAR_NO_INIT_32)
   #undef      OS_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (OS_STOP_SEC_VAR_NO_INIT_32)
   #undef      OS_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (OS_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      OS_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (OS_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      OS_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NOINIT_UNSPECIFIED

	 /*  Zero INIT Var Section */
#elif defined (OS_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      OS_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (OS_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      OS_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (OS_START_SEC_VAR_CLEARED_8)
   #undef      OS_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (OS_STOP_SEC_VAR_CLEARED_8)
   #undef      OS_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (OS_START_SEC_VAR_CLEARED_16)
   #undef      OS_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (OS_STOP_SEC_VAR_CLEARED_16)
   #undef      OS_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (OS_START_SEC_VAR_CLEARED_32)
   #undef      OS_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (OS_STOP_SEC_VAR_CLEARED_32)
   #undef      OS_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (OS_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      OS_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (OS_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      OS_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED


	  /* INIT Var Section */

#elif defined (OS_START_SEC_VAR_INIT_BOOLEAN)
   #undef      OS_START_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_INIT_BOOLEAN
#elif defined (OS_STOP_SEC_VAR_INIT_BOOLEAN)
   #undef      OS_STOP_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_INIT_BOOLEAN

#elif defined (OS_START_SEC_VAR_INIT_8)
   #undef      OS_START_SEC_VAR_INIT_8
   #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (OS_STOP_SEC_VAR_INIT_8)
   #undef      OS_STOP_SEC_VAR_INIT_8
   #define DEFAULT_STOP_SEC_VAR_INIT_8

#elif defined (OS_START_SEC_VAR_INIT_16)
   #undef      OS_START_SEC_VAR_INIT_16
   #define DEFAULT_START_SEC_VAR_INIT_16
#elif defined (OS_STOP_SEC_VAR_INIT_16)
   #undef      OS_STOP_SEC_VAR_INIT_16
   #define DEFAULT_STOP_SEC_VAR_INIT_16

#elif defined (OS_START_SEC_VAR_INIT_32)
   #undef      OS_START_SEC_VAR_INIT_32
   #define DEFAULT_START_SEC_VAR_INIT_32
#elif defined (OS_STOP_SEC_VAR_INIT_32)
   #undef      OS_STOP_SEC_VAR_INIT_32
   #define DEFAULT_STOP_SEC_VAR_INIT_32

#elif defined (OS_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      OS_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (OS_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      OS_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED
   #elif defined (ECUCPARTITION1_START_SEC_VAR_INIT_8)
   #undef      ECUCPARTITION1_START_SEC_VAR_INIT_8
   #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (ECUCPARTITION1_STOP_SEC_VAR_INIT_8)
   #undef      ECUCPARTITION1_STOP_SEC_VAR_INIT_8
   #define DEFAULT_STOP_SEC_VAR_INIT_8

  #elif defined (ECUCPARTITION1_START_SEC_VAR_INIT_8)
    #undef      ECUCPARTITION1_START_SEC_VAR_INIT_8
  __attribute__((section(".data.APP1_INIT_RAM_UNSPECIFIED")))
#elif defined (ECUCPARTITION1_STOP_SEC_VAR_INIT_8)
  #undef      ECUCPARTITION1_STOP_SEC_VAR_INIT_8
  #define DEFAULT_STOP_SEC_VAR_INIT_8
  #elif defined (ECUCPARTITION1_START_SEC_VAR_INIT_8)
    #undef      ECUCPARTITION1_START_SEC_VAR_INIT_8
  __attribute__((section(".data.APP1_INIT_RAM_UNSPECIFIED")))
#elif defined (ECUCPARTITION1_STOP_SEC_VAR_INIT_8)
  #undef      ECUCPARTITION1_STOP_SEC_VAR_INIT_8
  #define DEFAULT_STOP_SEC_VAR_INIT_8
  
  #elif defined (APP0_START_SEC_CODE)
    #undef      APP0_START_SEC_CODE
  __attribute__((section(".text.APP0_ROM_CODE")))
#elif defined (APP0_STOP_SEC_CODE)
  #undef      APP0_STOP_SEC_CODE
  #define DEFAULT_STOP_SEC_VAR_INIT_8  

  #elif defined (APP1_START_SEC_CODE)
    #undef      APP1_START_SEC_CODE
  __attribute__((section(".text.APP1_ROM_CODE")))
#elif defined (APP1_STOP_SEC_CODE)
  #undef      APP1_STOP_SEC_CODE
  #define DEFAULT_STOP_SEC_VAR_INIT_8
  #elif defined (APP2_START_SEC_CODE)
    #undef      APP2_START_SEC_CODE
  __attribute__((section(".text.APP2_ROM_CODE")))
#elif defined (APP2_STOP_SEC_CODE)
  #undef      APP2_STOP_SEC_CODE
  #define DEFAULT_STOP_SEC_VAR_INIT_8

  #elif defined (APP3_START_SEC_CODE)
  #undef      APP3_START_SEC_CODE
  __attribute__((section(".text.APP3_ROM_CODE")))
#elif defined (APP3_STOP_SEC_CODE)
  #undef      APP3_STOP_SEC_CODE
  #define DEFAULT_STOP_SEC_VAR_INIT_8
  
  #elif defined (APP_START_SEC_LIB_CODE)
    #undef      APP_START_SEC_LIB_CODE
  __attribute__((section(".text.LIB_CODE")))
#elif defined (APP_STOP_SEC_LIB_CODE)
  #undef      APP_STOP_SEC_LIB_CODE
  #define DEFAULT_STOP_SEC_VAR_INIT_8

  #elif defined (ECUCPARTITION1_START_SEC_VAR_INIT_16)
   #undef      ECUCPARTITION1_START_SEC_VAR_INIT_16
   __attribute__((section(".data.APP1_INIT_RAM_UNSPECIFIED")))
#elif defined (ECUCPARTITION1_STOP_SEC_VAR_INIT_16)
   #undef      ECUCPARTITION1_STOP_SEC_VAR_INIT_16
   #define DEFAULT_STOP_SEC_VAR_INIT_16

#elif defined (ECUCPARTITION1_START_SEC_VAR_INIT_32)
   #undef      ECUCPARTITION1_START_SEC_VAR_INIT_32
   __attribute__((section(".data.APP1_INIT_RAM_UNSPECIFIED")))
#elif defined (ECUCPARTITION1_STOP_SEC_VAR_INIT_32)
   #undef      ECUCPARTITION1_STOP_SEC_VAR_INIT_32
   #define DEFAULT_STOP_SEC_VAR_INIT_32

#elif defined (ECUCPARTITION1_START_SEC_VAR_INIT_16)
   #undef      ECUCPARTITION1_START_SEC_VAR_INIT_16
   #define DEFAULT_START_SEC_VAR_INIT_16
#elif defined (ECUCPARTITION1_STOP_SEC_VAR_INIT_16)
   #undef      ECUCPARTITION1_STOP_SEC_VAR_INIT_16
   #define DEFAULT_STOP_SEC_VAR_INIT_16

#elif defined (ECUCPARTITION1_START_SEC_VAR_INIT_32)
   #undef      ECUCPARTITION1_START_SEC_VAR_INIT_32
   #define DEFAULT_START_SEC_VAR_INIT_32
#elif defined (ECUCPARTITION1_STOP_SEC_VAR_INIT_32)
   #undef      ECUCPARTITION1_STOP_SEC_VAR_INIT_32
   #define DEFAULT_STOP_SEC_VAR_INIT_32

#elif defined (ECUCPARTITION1_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      ECUCPARTITION1_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (ECUCPARTITION1_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      ECUCPARTITION1_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED

	/* Fast Var Section */

#elif defined (OS_START_SEC_VAR_FAST_BOOLEAN)
   #undef      OS_START_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_START_SEC_VAR_FAST_BOOLEAN
#elif defined (OS_STOP_SEC_VAR_FAST_BOOLEAN)
   #undef      OS_STOP_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_FAST_BOOLEAN

#elif defined (OS_START_SEC_VAR_FAST_8)
   #undef      OS_START_SEC_VAR_FAST_8
   #define DEFAULT_START_SEC_VAR_FAST_8
#elif defined (OS_STOP_SEC_VAR_FAST_8)
   #undef      OS_STOP_SEC_VAR_FAST_8
   #define DEFAULT_STOP_SEC_VAR_FAST_8

#elif defined (OS_START_SEC_VAR_FAST_16)
   #undef      OS_START_SEC_VAR_FAST_16
   #define DEFAULT_START_SEC_VAR_FAST_16
#elif defined (OS_STOP_SEC_VAR_FAST_16)
   #undef      OS_STOP_SEC_VAR_FAST_16
   #define DEFAULT_STOP_SEC_VAR_FAST_16

#elif defined (OS_START_SEC_VAR_FAST_32)
   #undef      OS_START_SEC_VAR_FAST_32
   #define DEFAULT_START_SEC_VAR_FAST_32
#elif defined (OS_STOP_SEC_VAR_FAST_32)
   #undef      OS_STOP_SEC_VAR_FAST_32
   #define DEFAULT_STOP_SEC_VAR_FAST_32

#elif defined (OS_START_SEC_VAR_FAST_UNSPECIFIED)
   #undef      OS_START_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_FAST_UNSPECIFIED
#elif defined (OS_STOP_SEC_VAR_FAST_UNSPECIFIED)
   #undef      OS_STOP_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_FAST_UNSPECIFIED

   /* Constant Variable section */

#elif defined (OS_START_SEC_CONST_BOOLEAN)
   #undef      OS_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (OS_STOP_SEC_CONST_BOOLEAN)
   #undef      OS_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (OS_START_SEC_CONST_8)
   #undef      OS_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (OS_STOP_SEC_CONST_8)
   #undef      OS_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (OS_START_SEC_CONST_16)
   #undef      OS_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (OS_STOP_SEC_CONST_16)
   #undef      OS_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

#elif defined (OS_START_SEC_CONST_32)
   #undef      OS_START_SEC_CONST_32
   #define DEFAULT_START_SEC_CONST_32
#elif defined (OS_STOP_SEC_CONST_32)
   #undef      OS_STOP_SEC_CONST_32
   #define DEFAULT_STOP_SEC_CONST_32

#elif defined (OS_START_SEC_CONST_UNSPECIFIED)
   #undef      OS_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (OS_STOP_SEC_CONST_UNSPECIFIED)
   #undef      OS_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

	 /* Config Data Section */

#elif defined (OS_START_SEC_CONFIG_DATA_BOOLEAN)
   #undef      OS_START_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
#elif defined (OS_STOP_SEC_CONFIG_DATA_BOOLEAN)
   #undef      OS_STOP_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN

#elif defined (OS_START_SEC_CONFIG_DATA_8)
   #undef      OS_START_SEC_CONFIG_DATA_8
   #define DEFAULT_START_SEC_CONFIG_DATA_8
#elif defined (OS_STOP_SEC_CONFIG_DATA_8)
   #undef      OS_STOP_SEC_CONFIG_DATA_8
   #define DEFAULT_STOP_SEC_CONFIG_DATA_8

#elif defined (OS_START_SEC_CONFIG_DATA_16)
   #undef      OS_START_SEC_CONFIG_DATA_16
   #define DEFAULT_START_SEC_CONFIG_DATA_16
#elif defined (OS_STOP_SEC_CONFIG_DATA_16)
   #undef      OS_STOP_SEC_CONFIG_DATA_16
   #define DEFAULT_STOP_SEC_CONFIG_DATA_16

#elif defined (OS_START_SEC_CONFIG_DATA_32)
   #undef      OS_START_SEC_CONFIG_DATA_32
   #define DEFAULT_START_SEC_CONFIG_DATA_32
#elif defined (OS_STOP_SEC_CONFIG_DATA_32)
   #undef      OS_STOP_SEC_CONFIG_DATA_32
   #define DEFAULT_STOP_SEC_CONFIG_DATA_32

#elif defined (OS_START_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      OS_START_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (OS_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      OS_STOP_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED

#elif defined (OS_START_SEC_SHARE_RAM_DATA_UNSPECIFIED)
   #undef      OS_START_SEC_SHARE_RAM_DATA_UNSPECIFIED
   __attribute__((section(".bss.SHARE_RAM_CLEARED_UNSPECIFIED")))
#elif defined (OS_STOP_SEC_SHARE_RAM_DATA_UNSPECIFIED)
   #undef      OS_STOP_SEC_SHARE_RAM_DATA_UNSPECIFIED
#elif defined (OS_START_SEC_SHARE_RAM_INIT_DATA_UNSPECIFIED)
   #undef      OS_START_SEC_SHARE_RAM_INIT_DATA_UNSPECIFIED
   __attribute__((section(".data.SHARE_RAM_INIT_UNSPECIFIED")))
#elif defined (OS_STOP_SEC_SHARE_RAM_INIT_DATA_UNSPECIFIED)
   #undef      OS_STOP_SEC_SHARE_RAM_INIT_DATA_UNSPECIFIED

#elif defined (OS_START_SEC_APP0_RAM_DATA_UNSPECIFIED)
   #undef      OS_START_SEC_APP0_RAM_DATA_UNSPECIFIED
  __attribute__((section(".bss.APP0_RAM_CLEARED_UNSPECIFIED")))
#elif defined (OS_STOP_SEC_APP0_RAM_DATA_UNSPECIFIED)
   #undef      OS_STOP_SEC_APP0_RAM_DATA_UNSPECIFIED

#elif defined (OS_START_SEC_APP_RO_DATA_UNSPECIFIED)
   #undef      OS_START_SEC_APP_RO_DATA_UNSPECIFIED
  __attribute__((section(".bss.APP_RO_DATA_UNSPECIFIED")))
#elif defined (OS_STOP_SEC_APP_RO_DATA_UNSPECIFIED)
   #undef      OS_STOP_SEC_APP_RO_DATA_UNSPECIFIED

#elif defined (OS_START_SEC_APP2_RAM_DATA_UNSPECIFIED)
   #undef      OS_START_SEC_APP2_RAM_DATA_UNSPECIFIED
  __attribute__((section(".bss.APP2_RAM_CLEARED_UNSPECIFIED")))
#elif defined (OS_STOP_SEC_APP2_RAM_DATA_UNSPECIFIED)
   #undef      OS_STOP_SEC_APP2_RAM_DATA_UNSPECIFIED


	#elif defined (OS_START_SEC_APP1_RAM_DATA_UNSPECIFIED)
	   #undef      OS_START_SEC_APP1_RAM_DATA_UNSPECIFIED
	   __attribute__((section(".bss.APP1_RAM_CLEARED_UNSPECIFIED")))
	#elif defined (OS_STOP_SEC_APP1_RAM_DATA_UNSPECIFIED)
	   #undef      OS_STOP_SEC_APP1_RAM_DATA_UNSPECIFIED

	#elif defined (OS_START_SEC_CODE)
	   #undef      OS_START_SEC_CODE
	__attribute__((section(".text.OS_CODE")))
	#elif defined (OS_STOP_SEC_CODE)
	   #undef      OS_STOP_SEC_CODE
	   #define DEFAULT_STOP_SEC_CODE
   
   
      #elif defined (OS_START_SEC_APP0_ROM_DATA_UNSPECIFIED)
   #undef      OS_START_SEC_APP0_ROM_DATA_UNSPECIFIED
  __attribute__((section(".text.APP0_ROM_CLEARED_UNSPECIFIED")))
#elif defined (OS_STOP_SEC_APP0_ROM_DATA_UNSPECIFIED)
   #undef      OS_STOP_SEC_APP0_ROM_DATA_UNSPECIFIED

   #elif defined (OS_START_SEC_APP1_ROM_DATA_UNSPECIFIED)
   #undef      OS_START_SEC_APP1_ROM_DATA_UNSPECIFIED
  __attribute__((section(".text.APP1_ROM_CLEARED_UNSPECIFIED")))
#elif defined (OS_STOP_SEC_APP1_ROM_DATA_UNSPECIFIED)
   #undef      OS_STOP_SEC_APP1_ROM_DATA_UNSPECIFIED   
   
   #elif defined (OS_START_SEC_APP2_ROM_DATA_UNSPECIFIED)
   #undef      OS_START_SEC_APP2_ROM_DATA_UNSPECIFIED
  __attribute__((section(".text.APP2_ROM_CLEARED_UNSPECIFIED")))
#elif defined (OS_STOP_SEC_APP2_ROM_DATA_UNSPECIFIED)
   #undef      OS_STOP_SEC_APP2_ROM_DATA_UNSPECIFIED 
   
      #elif defined (OS_START_SEC_APP3_ROM_DATA_UNSPECIFIED)
   #undef      OS_START_SEC_APP3_ROM_DATA_UNSPECIFIED
  __attribute__((section(".text.APP3_ROM_CLEARED_UNSPECIFIED")))
#elif defined (OS_STOP_SEC_APP3_ROM_DATA_UNSPECIFIED)
   #undef      OS_STOP_SEC_APP3_ROM_DATA_UNSPECIFIED 


/* -------------------------------------------------------------------------- */
/*                                 Eep                                        */
/* -------------------------------------------------------------------------- */
 
   #elif defined (EEP_START_SEC_CODE)
   #undef      EEP_START_SEC_CODE
    //__attribute__((section(".text.EEP_CODE")))
   #pragma section code "EEP_CODE"
   #elif defined (EEP_STOP_SEC_CODE)
   #undef      EEP_STOP_SEC_CODE
   
   #elif defined (EEP_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      EEP_START_SEC_VAR_CLEARED_BOOLEAN
   //__attribute__((section(".text.EEP_CODE")))
   #pragma section code "EEP_RAM_POWER_CLEARED_BOOLEAN"
   #elif defined (EEP_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      EEP_STOP_SEC_VAR_CLEARED_BOOLEAN
   
   #elif defined (EEP_START_SEC_VAR_CLEARED_8)
   #undef      EEP_START_SEC_VAR_CLEARED_8
   // __attribute__((section(".text.GTM_CODE")))
   #pragma section code "EEP_RAM_CLEARED_8"
   #elif defined (EEP_STOP_SEC_VAR_CLEARED_8)
   #undef      EEP_STOP_SEC_VAR_CLEARED_8

   #elif defined (EEP_START_SEC_VAR_CLEARED_16)
   #undef      EEP_START_SEC_VAR_CLEARED_16
   #pragma section code "EEP_RAM_CLEARED_16"
   #elif defined (EEP_STOP_SEC_VAR_CLEARED_16)
   #undef      EEP_STOP_SEC_VAR_CLEARED_16
   
   #elif defined (EEP_START_SEC_VAR_CLEARED_32)
   #undef      EEP_START_SEC_VAR_CLEARED_32
   #pragma section code "EEP_RAM_CLEARED_32"
   #elif defined (EEP_STOP_SEC_VAR_CLEARED_32)
   #undef      EEP_STOP_SEC_VAR_CLEARED_32
   
   #elif defined (EEP_START_SEC_CONST_UNSPECIFIED)
   #undef      EEP_START_SEC_CONST_UNSPECIFIED
   #pragma section code "EEP_CONST_ROM_UNSPECIFIED"
   #elif defined (EEP_STOP_SEC_CONST_UNSPECIFIED)
   #undef      EEP_STOP_SEC_CONST_UNSPECIFIED  
   
   /* -------------------------------------------------------------------------- */
/*                 CAL                                                        */
/* -------------------------------------------------------------------------- */
#elif defined (CAL_START_SEC_CODE)
   #undef      CAL_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (CAL_STOP_SEC_CODE)
   #undef      CAL_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (CAL_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CAL_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (CAL_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CAL_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (CAL_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CAL_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (CAL_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CAL_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (CAL_START_SEC_CONST_UNSPECIFIED)
   #undef      CAL_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (CAL_STOP_SEC_CONST_UNSPECIFIED)
   #undef      CAL_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED
/* -------------------------------------------------------------------------- */
/*                 CSM                                                        */
/* -------------------------------------------------------------------------- */
#elif defined (CSM_START_SEC_CODE)
   #undef      CSM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (CSM_STOP_SEC_CODE)
   #undef      CSM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (CSM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CSM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (CSM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CSM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (CSM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CSM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (CSM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CSM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (CSM_START_SEC_CONST_UNSPECIFIED)
   #undef      CSM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (CSM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      CSM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/*             LinIf                                                          */
/* -------------------------------------------------------------------------- */

#elif defined (LINIF_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINIF_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (LINIF_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINIF_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (LINIF_START_SEC_DBTOC_CONST_UNSPECIFIED)
   #undef      LINIF_START_SEC_DBTOC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_DBTOC_CONST_UNSPECIFIED
#elif defined (LINIF_STOP_SEC_DBTOC_CONST_UNSPECIFIED)
   #undef      LINIF_STOP_SEC_DBTOC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_DBTOC_CONST_UNSPECIFIED

#elif defined (LINIF_START_SEC_CONST_UNSPECIFIED)
   #undef      LINIF_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (LINIF_STOP_SEC_CONST_UNSPECIFIED)
   #undef      LINIF_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

   #elif defined (LINIF_START_SEC_VAR_NO_INIT_8)
   #undef      LINIF_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (LINIF_STOP_SEC_VAR_NO_INIT_8)
   #undef      LINIF_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (LINIF_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      LINIF_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (LINIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      LINIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (LINIF_START_SEC_CONST_8)
   #undef      LINIF_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (LINIF_STOP_SEC_CONST_8)
   #undef      LINIF_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (LINIF_START_SEC_CONST_UNSPECIFIED)
   #undef      LINIF_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (LINIF_STOP_SEC_CONST_UNSPECIFIED)
   #undef      LINIF_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (LINIF_START_SEC_CODE)
   #undef      LINIF_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (LINIF_STOP_SEC_CODE)
   #undef      LINIF_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (LINIF_START_SEC_CODE)
   #undef      LINIF_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (LINIF_STOP_SEC_CODE)
   #undef      LINIF_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*             LinTp                                                          */
/* -------------------------------------------------------------------------- */

#elif defined (LINTP_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINTP_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (LINTP_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINTP_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (LINTP_START_SEC_VAR_NO_INIT_8)
   #undef      LINTP_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (LINTP_STOP_SEC_VAR_NO_INIT_8)
   #undef      LINTP_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (LINTP_START_SEC_CONST_UNSPECIFIED)
   #undef      LINTP_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (LINTP_STOP_SEC_CONST_UNSPECIFIED)
   #undef      LINTP_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

   #elif defined (LINTP_START_SEC_VAR_NO_INIT_8)
   #undef      LINTP_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (LINTP_STOP_SEC_VAR_NO_INIT_8)
   #undef      LINTP_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (LINTP_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      LINTP_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (LINTP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      LINTP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (LINTP_START_SEC_CONST_8)
   #undef      LINTP_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (LINTP_STOP_SEC_CONST_8)
   #undef      LINTP_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (LINTP_START_SEC_CONST_UNSPECIFIED)
   #undef      LINTP_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (LINTP_STOP_SEC_CONST_UNSPECIFIED)
   #undef      LINTP_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (LINTP_START_SEC_CODE)
   #undef      LINTP_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (LINTP_STOP_SEC_CODE)
   #undef      LINTP_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (LINTP_START_SEC_VAR_CLEARED_16)
   #undef      LINTP_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (LINTP_STOP_SEC_VAR_CLEARED_16)
   #undef      LINTP_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (LINTP_START_SEC_DBTOC_CONST_UNSPECIFIED)
   #undef      LINTP_START_SEC_DBTOC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_DBTOC_CONST_UNSPECIFIED
#elif defined (LINTP_STOP_SEC_DBTOC_CONST_UNSPECIFIED)
   #undef      LINTP_STOP_SEC_DBTOC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_DBTOC_CONST_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/*                 ETHIF                                                      */
/* -------------------------------------------------------------------------- */
#elif defined (ETHIF_START_SEC_CODE)
   #undef      ETHIF_START_SEC_CODE
   #pragma section code "ETHIF_CODE"
   #pragma section farrom "ETHIF_ROM_CONST_UNSPECIFIED"
   #pragma section farbss "ETHIF_RAM_VAR_CLEARED_UNSPECIFIED"
   #pragma section fardata "ETHIF_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (ETHIF_STOP_SEC_CODE)
   #undef      ETHIF_STOP_SEC_CODE
   #pragma section fardata restore
   #pragma section farbss restore
   #pragma section farrom restore
   #pragma section code restore

#elif defined (ETHIF_START_SEC_VAR_CLEARED_8)
   #undef      ETHIF_START_SEC_VAR_CLEARED_8
   #pragma section all "ETHIF_RAM_VAR_CLEARED_8"
#elif defined (ETHIF_STOP_SEC_VAR_CLEARED_8)
   #undef      ETHIF_STOP_SEC_VAR_CLEARED_8
   #pragma section all restore

#elif defined (ETHIF_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      ETHIF_START_SEC_VAR_CLEARED_UNSPECIFIED
   #pragma section all "ETHIF_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (ETHIF_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      ETHIF_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #pragma section all restore

#elif defined (ETHIF_START_SEC_CONST_8)
   #undef      ETHIF_START_SEC_CONST_8
   #pragma section all "ETHIF_ROM_CONST_8"
#elif defined (ETHIF_STOP_SEC_CONST_8)
   #undef      ETHIF_STOP_SEC_CONST_8
   #pragma section all restore

#elif defined (ETHIF_START_SEC_CONST_UNSPECIFIED)
   #undef      ETHIF_START_SEC_CONST_UNSPECIFIED
   #pragma section all "ETHIF_ROM_CONST_UNSPECIFIED"
#elif defined (ETHIF_STOP_SEC_CONST_UNSPECIFIED)
   #undef      ETHIF_STOP_SEC_CONST_UNSPECIFIED
   #pragma section all restore

/* -------------------------------------------------------------------------- */
/*                 ETHSM                                                      */
/* -------------------------------------------------------------------------- */
#elif defined (ETHSM_START_SEC_CODE)
   #undef      ETHSM_START_SEC_CODE
   #pragma section code "ETHSM_CODE"
   #pragma section farrom "ETHSM_ROM_CONST_UNSPECIFIED"
   #pragma section farbss "ETHSM_RAM_VAR_CLEARED_UNSPECIFIED"
   #pragma section fardata "ETHSM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (ETHSM_STOP_SEC_CODE)
   #undef      ETHSM_STOP_SEC_CODE
   #pragma section fardata restore
   #pragma section farbss restore
   #pragma section farrom restore
   #pragma section code restore

#elif defined (ETHSM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      ETHSM_START_SEC_VAR_CLEARED_BOOLEAN
   #pragma section all "ETHSM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (ETHSM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      ETHSM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #pragma section all restore

#elif defined (ETHSM_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      ETHSM_START_SEC_VAR_INIT_UNSPECIFIED
   #pragma section all "ETHSM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (ETHSM_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      ETHSM_STOP_SEC_VAR_INIT_UNSPECIFIED
   #pragma section all restore

#elif defined (ETHSM_START_SEC_CONST_8)
   #undef      ETHSM_START_SEC_CONST_8
   #pragma section all "ETHSM_ROM_CONST_8"
#elif defined (ETHSM_STOP_SEC_CONST_8)
   #undef      ETHSM_STOP_SEC_CONST_8
   #pragma section all restore

#elif defined (ETHSM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      ETHSM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #pragma section all "ETHSM_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (ETHSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      ETHSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #pragma section all restore

#elif defined (ETHSM_START_SEC_CONST_UNSPECIFIED)
   #undef      ETHSM_START_SEC_CONST_UNSPECIFIED
   #pragma section all "ETHSM_ROM_CONST_UNSPECIFIED"
#elif defined (ETHSM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      ETHSM_STOP_SEC_CONST_UNSPECIFIED
   #pragma section all restore

/* -------------------------------------------------------------------------- */
/*                 ETHTRCV                                                    */
/* -------------------------------------------------------------------------- */
#elif defined (ETHTRCV_PEF7071_START_SEC_CODE)
   #undef      ETHTRCV_PEF7071_START_SEC_CODE
   #pragma section code "ETHTRCV_CODE"
   #pragma section farrom "ETHTRCV_ROM_CONST_UNSPECIFIED"
   #pragma section farbss "ETHTRCV_RAM_VAR_CLEARED_UNSPECIFIED"
   #pragma section fardata "ETHTRCV_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (ETHTRCV_PEF7071_STOP_SEC_CODE)
   #undef      ETHTRCV_PEF7071_STOP_SEC_CODE
   #pragma section fardata restore
   #pragma section farbss restore
   #pragma section farrom restore
   #pragma section code restore

#elif defined (ETHTRCV_PEF7071_START_SEC_CONST_UNSPECIFIED)
   #undef      ETHTRCV_PEF7071_START_SEC_CONST_UNSPECIFIED
   #pragma section all "ETHTRCV_ROM_CONST_UNSPECIFIED"
#elif defined (ETHTRCV_PEF7071_STOP_SEC_CONST_UNSPECIFIED)
   #undef      ETHTRCV_PEF7071_STOP_SEC_CONST_UNSPECIFIED
   #pragma section all restore

#elif defined (ETHTRCV_PEF7071_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      ETHTRCV_PEF7071_START_SEC_VAR_CLEARED_UNSPECIFIED
   #pragma section all "ETHTRCV_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (ETHTRCV_PEF7071_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      ETHTRCV_PEF7071_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #pragma section all restore

#elif defined (ETHTRCV_PEF7071_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      ETHTRCV_PEF7071_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #pragma section all "ETHTRCV_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (ETHTRCV_PEF7071_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      ETHTRCV_PEF7071_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #pragma section all restore

/* -------------------------------------------------------------------------- */
/*                 SOAD                                                      */
/* -------------------------------------------------------------------------- */
#elif defined (SOAD_START_SEC_CODE)
   #undef      SOAD_START_SEC_CODE
   #pragma section code "SOAD_CODE"
   #pragma section farrom "SOAD_ROM_CONST_UNSPECIFIED"
   #pragma section farbss "SOAD_RAM_VAR_CLEARED_UNSPECIFIED"
   #pragma section fardata "SOAD_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (SOAD_STOP_SEC_CODE)
   #undef      SOAD_STOP_SEC_CODE
   #pragma section fardata restore
   #pragma section farbss restore
   #pragma section farrom restore
   #pragma section code restore

#elif defined (SOAD_START_SEC_VAR_CLEARED_8)
   #undef      SOAD_START_SEC_VAR_CLEARED_8
   #pragma section all "SOAD_RAM_VAR_CLEARED_8"
#elif defined (SOAD_STOP_SEC_VAR_CLEARED_8)
   #undef      SOAD_STOP_SEC_VAR_CLEARED_8
   #pragma section all restore

#elif defined (SOAD_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      SOAD_START_SEC_VAR_CLEARED_UNSPECIFIED
   #pragma section all "SOAD_RAM_VAR_CLEARED_UNSPECIFIED"
#elif defined (SOAD_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      SOAD_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #pragma section all restore

#elif defined (SOAD_START_SEC_CONST_UNSPECIFIED)
   #undef      SOAD_START_SEC_CONST_UNSPECIFIED
   #pragma section all "SOAD_ROM_CONST_UNSPECIFIED"
#elif defined (SOAD_STOP_SEC_CONST_UNSPECIFIED)
   #undef      SOAD_STOP_SEC_CONST_UNSPECIFIED
   #pragma section all restore

/* -------------------------------------------------------------------------- */
/*             DOIP                                                        */
/* -------------------------------------------------------------------------- */
#elif defined (DOIP_START_SEC_CODE)
   #undef      DOIP_START_SEC_CODE
   #pragma section code "DOIP_CODE"
   #pragma section farrom "DOIP_ROM_CONST_UNSPECIFIED"
   #pragma section farbss "DOIP_RAM_VAR_CLEARED_UNSPECIFIED"
   #pragma section fardata "DOIP_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (DOIP_STOP_SEC_CODE)
   #undef      DOIP_STOP_SEC_CODE
   #pragma section fardata restore
   #pragma section farbss restore
   #pragma section farrom restore
   #pragma section code restore

#elif defined (DOIP_START_SEC_CONST_UNSPECIFIED)
   #undef      DOIP_START_SEC_CONST_UNSPECIFIED
   #pragma section all "DOIP_ROM_CONST_ROM_UNSPECIFIED"
#elif defined (DOIP_STOP_SEC_CONST_UNSPECIFIED)
   #undef      DOIP_STOP_SEC_CONST_UNSPECIFIED
   #pragma section all restore

#elif defined (DOIP_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      DOIP_START_SEC_VAR_INIT_UNSPECIFIED
   #pragma section all "DOIP_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (DOIP_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      DOIP_STOP_SEC_VAR_INIT_UNSPECIFIED
   #pragma section all restore

#elif defined (DOIP_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DOIP_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #pragma section all "DOIP_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (DOIP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DOIP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #pragma section all restore

#elif defined (DOIP_START_SEC_VAR_NO_INIT_8)
   #undef      DOIP_START_SEC_VAR_NO_INIT_8
   #pragma section all "DOIP_RAM_VAR_NO_INIT_8"
#elif defined (DOIP_STOP_SEC_VAR_NO_INIT_8)
   #undef      DOIP_STOP_SEC_VAR_NO_INIT_8
   #pragma section all restore

#elif defined (DOIP_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DOIP_START_SEC_VAR_CLEARED_BOOLEAN
	 #pragma section all "DOIP_RAM_CLEARED_BOOLEAN"
#elif defined (DOIP_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DOIP_STOP_SEC_VAR_CLEARED_BOOLEAN
   #pragma section all restore
   
/* -------------------------------------------------------------------------- */
/*                SD                                                          */
/* -------------------------------------------------------------------------- */
#elif defined (SD_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      SD_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (SD_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      SD_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (SD_START_SEC_VAR_NO_INIT_8)
   #undef      SD_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (SD_STOP_SEC_VAR_NO_INIT_8)
   #undef      SD_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (SD_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      SD_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (SD_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      SD_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (SD_START_SEC_CONST_8)
   #undef      SD_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (SD_STOP_SEC_CONST_8)
   #undef      SD_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (SD_START_SEC_CONST_UNSPECIFIED)
   #undef      SD_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (SD_STOP_SEC_CONST_UNSPECIFIED)
   #undef      SD_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (SD_START_SEC_VAR_UNSPECIFIED)
   #undef      SD_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (SD_STOP_SEC_VAR_UNSPECIFIED)
   #undef      SD_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (SD_START_SEC_CODE)
   #undef      SD_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (SD_STOP_SEC_CODE)
   #undef      SD_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (SD_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      SD_START_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (SD_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      SD_STOP_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN
   
#elif defined (SD_START_SEC_VAR_NO_INIT_32)
   #undef      SD_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (SD_STOP_SEC_VAR_NO_INIT_32)
   #undef      SD_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32
 
#elif defined (SD_START_SEC_VAR_NO_INIT_16)
   #undef      SD_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (SD_STOP_SEC_VAR_NO_INIT_16)
   #undef      SD_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16    

/* -------------------------------------------------------------------------- */
/*             TcpIp                                                           */
/* -------------------------------------------------------------------------- */
#elif defined (TCPIP_START_SEC_VAR_CLEARED_1)
   #undef      TCPIP_START_SEC_VAR_CLEARED_1
   #define DEFAULT_START_SEC_VAR_CLEARED_1
#elif defined (TCPIP_STOP_SEC_VAR_CLEARED_1)
   #undef      TCPIP_STOP_SEC_VAR_CLEARED_1
   #define DEFAULT_STOP_SEC_VAR_CLEARED_1
   
#elif defined (TCPIP_START_SEC_VAR_CLEARED_8)
   #undef      TCPIP_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (TCPIP_STOP_SEC_VAR_CLEARED_8)
   #undef      TCPIP_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8
   
#elif defined (TCPIP_START_SEC_VAR_CLEARED_16)
   #undef      TCPIP_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (TCPIP_STOP_SEC_VAR_CLEARED_16)
   #undef      TCPIP_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16 
   
#elif defined (TCPIP_START_SEC_VAR_CLEARED_32)
   #undef      TCPIP_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (TCPIP_STOP_SEC_VAR_CLEARED_32)
   #undef      TCPIP_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32  

#elif defined (TCPIP_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      TCPIP_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (TCPIP_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      TCPIP_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED     

#elif defined (TCPIP_START_SEC_VAR_INIT_1)
   #undef      TCPIP_START_SEC_VAR_INIT_1
   #define DEFAULT_START_SEC_VAR_INIT_1
#elif defined (TCPIP_STOP_SEC_VAR_INIT_1)
   #undef      TCPIP_STOP_SEC_VAR_INIT_1
   #define DEFAULT_STOP_SEC_VAR_INIT_1
   
#elif defined (TCPIP_START_SEC_VAR_INIT_8)
   #undef      TCPIP_START_SEC_VAR_INIT_8
   #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (TCPIP_STOP_SEC_VAR_INIT_8)
   #undef      TCPIP_STOP_SEC_VAR_INIT_8
   #define DEFAULT_STOP_SEC_VAR_INIT_8
   
#elif defined (TCPIP_START_SEC_VAR_INIT_16)
   #undef      TCPIP_START_SEC_VAR_INIT_16
   #define DEFAULT_START_SEC_VAR_INIT_16
#elif defined (TCPIP_STOP_SEC_VAR_INIT_16)
   #undef      TCPIP_STOP_SEC_VAR_INIT_16
   #define DEFAULT_STOP_SEC_VAR_INIT_16
   
#elif defined (TCPIP_START_SEC_VAR_INIT_32)
   #undef      TCPIP_START_SEC_VAR_INIT_32
   #define DEFAULT_START_SEC_VAR_INIT_32
#elif defined (TCPIP_STOP_SEC_VAR_INIT_32)
   #undef      TCPIP_STOP_SEC_VAR_INIT_32
   #define DEFAULT_STOP_SEC_VAR_INIT_32
   
#elif defined (TCPIP_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      TCPIP_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (TCPIP_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      TCPIP_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED   
   
#elif defined (TCPIP_START_SEC_VAR_NOINIT_1)
   #undef      TCPIP_START_SEC_VAR_NOINIT_1
   #define DEFAULT_START_SEC_VAR_NOINIT_1
#elif defined (TCPIP_STOP_SEC_VAR_NOINIT_1)
   #undef      TCPIP_STOP_SEC_VAR_NOINIT_1
   #define DEFAULT_STOP_SEC_VAR_NOINIT_1  
   
#elif defined (TCPIP_START_SEC_VAR_NOINIT_8)
   #undef      TCPIP_START_SEC_VAR_NOINIT_8
   #define DEFAULT_START_SEC_VAR_NOINIT_8
#elif defined (TCPIP_STOP_SEC_VAR_NOINIT_8)
   #undef      TCPIP_STOP_SEC_VAR_NOINIT_8
   #define DEFAULT_STOP_SEC_VAR_NOINIT_8

#elif defined (TCPIP_START_SEC_VAR_NOINIT_16)
   #undef      TCPIP_START_SEC_VAR_NOINIT_16
   #define DEFAULT_START_SEC_VAR_NOINIT_16
#elif defined (TCPIP_STOP_SEC_VAR_NOINIT_16)
   #undef      TCPIP_STOP_SEC_VAR_NOINIT_16
   #define DEFAULT_STOP_SEC_VAR_NOINIT_16
   
#elif defined (TCPIP_START_SEC_VAR_NOINIT_32)
   #undef      TCPIP_START_SEC_VAR_NOINIT_32
   #define DEFAULT_START_SEC_VAR_NOINIT_32
#elif defined (TCPIP_STOP_SEC_VAR_NOINIT_32)
   #undef      TCPIP_STOP_SEC_VAR_NOINIT_32
   #define DEFAULT_STOP_SEC_VAR_NOINIT_32   
   
#elif defined (TCPIP_START_SEC_VAR_NOINIT_UNSPECIFIED)
   #undef      TCPIP_START_SEC_VAR_NOINIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NOINIT_UNSPECIFIED
#elif defined (TCPIP_STOP_SEC_VAR_NOINIT_UNSPECIFIED)
   #undef      TCPIP_STOP_SEC_VAR_NOINIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NOINIT_UNSPECIFIED

#elif defined (TCPIP_START_SEC_CONST_1)
   #undef      TCPIP_START_SEC_CONST_1
   #define DEFAULT_START_SEC_CONST_1
#elif defined (TCPIP_STOP_SEC_CONST_1)
   #undef      TCPIP_STOP_SEC_CONST_1
   #define DEFAULT_STOP_SEC_CONST_1
   
#elif defined (TCPIP_START_SEC_CONST_8)
   #undef      TCPIP_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (TCPIP_STOP_SEC_CONST_8)
   #undef      TCPIP_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8
   
#elif defined (TCPIP_START_SEC_CONST_16)
   #undef      TCPIP_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (TCPIP_STOP_SEC_CONST_16)
   #undef      TCPIP_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16   
   
#elif defined (TCPIP_START_SEC_CONST_32)
   #undef      TCPIP_START_SEC_CONST_32
   #define DEFAULT_START_SEC_CONST_32
#elif defined (TCPIP_STOP_SEC_CONST_32)
   #undef      TCPIP_STOP_SEC_CONST_32
   #define DEFAULT_STOP_SEC_CONST_32    

#elif defined (TCPIP_START_SEC_CONST_UNSPECIFIED)
   #undef      TCPIP_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (TCPIP_STOP_SEC_CONST_UNSPECIFIED)
   #undef      TCPIP_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (TCPIP_START_SEC_CODE)
   #undef      TCPIP_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (TCPIP_STOP_SEC_CODE)
   #undef      TCPIP_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE  
  

/* -------------------------------------------------------------------------- */
/*             UDPNM                                                          */
/* -------------------------------------------------------------------------- */
#elif defined (UDPNM_START_SEC_CODE)
   #undef      UDPNM_START_SEC_CODE
   #pragma section code "UDPNM_CODE"
   #pragma section farrom "UDPNM_ROM_CONST_UNSPECIFIED"
   #pragma section farbss "UDPNM_RAM_VAR_CLEARED_UNSPECIFIED"
   #pragma section fardata "UDPNM_RAM_VAR_INIT_UNSPECIFIED"
#elif defined (UDPNM_STOP_SEC_CODE)
   #undef      UDPNM_STOP_SEC_CODE
   #pragma section fardata restore
   #pragma section farbss restore
   #pragma section farrom restore
   #pragma section code restore

#elif defined (UDPNM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      UDPNM_START_SEC_VAR_CLEARED_BOOLEAN
   #pragma section all "UDPNM_RAM_VAR_CLEARED_BOOLEAN"
#elif defined (UDPNM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      UDPNM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #pragma section all restore

#elif defined (UDPNM_START_SEC_VAR_UNSPECIFIED)
   #undef      UDPNM_START_SEC_VAR_UNSPECIFIED
   #pragma section all "UDPNM_RAM_VAR_UNSPECIFIED"
#elif defined (UDPNM_STOP_SEC_VAR_UNSPECIFIED)
   #undef      UDPNM_STOP_SEC_VAR_UNSPECIFIED
   #pragma section all restore

#elif defined (UDPNM_START_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED)
   #undef      UDPNM_START_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED
   #pragma section all "UDPNM_DBTOC_CONFIG_CONST_UNSPECIFIED"
#elif defined (UDPNM_STOP_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED)
   #undef      UDPNM_STOP_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED
   #pragma section all restore

#elif defined (UDPNM_START_SEC_VAR_NO_INIT_8)
   #undef      UDPNM_START_SEC_VAR_NO_INIT_8
   #pragma section all "UDPNM_RAM_VAR_NO_INIT_8"
#elif defined (UDPNM_STOP_SEC_VAR_NO_INIT_8)
   #undef      UDPNM_STOP_SEC_VAR_NO_INIT_8
   #pragma section all restore

#elif defined (UDPNM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      UDPNM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #pragma section all "UDPNM_RAM_VAR_NO_INIT_UNSPECIFIED"
#elif defined (UDPNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      UDPNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #pragma section all restore

#elif defined (UDPNM_START_SEC_CONST_8)
   #undef      UDPNM_START_SEC_CONST_8
   #pragma section all "UDPNM_ROM_CONST_8"
#elif defined (UDPNM_STOP_SEC_CONST_8)
   #undef      UDPNM_STOP_SEC_CONST_8
   #pragma section all restore

#elif defined (UDPNM_START_SEC_CONST_UNSPECIFIED)
   #undef      UDPNM_START_SEC_CONST_UNSPECIFIED
   #pragma section all "UDPNM_ROM_CONST_UNSPECIFIED"
#elif defined (UDPNM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      UDPNM_STOP_SEC_CONST_UNSPECIFIED
   #pragma section all restore

/* -------------------------------------------------------------------------- */
/*                    COM                                                     */
/* -------------------------------------------------------------------------- */
#elif defined (COM_START_SEC_CONST_8)
  #undef      COM_START_SEC_CONST_8
  #define DEFAULT_START_SEC_CONST_8
#elif defined (COM_STOP_SEC_CONST_8)
  #undef      COM_STOP_SEC_CONST_8
  #define DEFAULT_STOP_SEC_CONST_8

#elif defined (COM_START_SEC_CONST_16)
  #undef      COM_START_SEC_CONST_16
  #define DEFAULT_START_SEC_CONST_16
#elif defined (COM_STOP_SEC_CONST_16)
  #undef      COM_STOP_SEC_CONST_16
  #define DEFAULT_STOP_SEC_CONST_16

#elif defined (COM_START_SEC_CONST_32)
  #undef      COM_START_SEC_CONST_32
  #define DEFAULT_START_SEC_CONST_32
#elif defined (COM_STOP_SEC_CONST_32)
  #undef      COM_STOP_SEC_CONST_32
  #define DEFAULT_STOP_SEC_CONST_32

#elif defined (COM_START_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef      COM_START_SEC_VAR_CLEARED_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (COM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
  #undef      COM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (COM_START_SEC_VAR_CLEARED_8)
  #undef      COM_START_SEC_VAR_CLEARED_8
  #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (COM_STOP_SEC_VAR_CLEARED_8)
  #undef      COM_STOP_SEC_VAR_CLEARED_8
  #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (COM_START_SEC_VAR_CLEARED_16)
  #undef      COM_START_SEC_VAR_CLEARED_16
  #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (COM_STOP_SEC_VAR_CLEARED_16)
  #undef      COM_STOP_SEC_VAR_CLEARED_16
  #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (COM_START_SEC_CONST_UNSPECIFIED)
  #undef      COM_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (COM_STOP_SEC_CONST_UNSPECIFIED)
  #undef      COM_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (COM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef      COM_START_SEC_VAR_NO_INIT_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (COM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
  #undef      COM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (COM_START_SEC_VAR_NO_INIT_8)
  #undef      COM_START_SEC_VAR_NO_INIT_8
  #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (COM_STOP_SEC_VAR_NO_INIT_8)
  #undef      COM_STOP_SEC_VAR_NO_INIT_8
  #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (COM_START_SEC_VAR_NO_INIT_16)
  #undef      COM_START_SEC_VAR_NO_INIT_16
  #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (COM_STOP_SEC_VAR_NO_INIT_16)
  #undef      COM_STOP_SEC_VAR_NO_INIT_16
  #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (COM_START_SEC_VAR_NO_INIT_32)
  #undef      COM_START_SEC_VAR_NO_INIT_32
  #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (COM_STOP_SEC_VAR_NO_INIT_32)
  #undef      COM_STOP_SEC_VAR_NO_INIT_32
  #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (COM_START_SEC_CODE)
  #undef      COM_START_SEC_CODE
  #define     DEFAULT_START_SEC_CODE
#elif defined (COM_STOP_SEC_CODE)
  #undef      COM_STOP_SEC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (COM_START_SEC_APPL_CODE)
  #undef      COM_START_SEC_APPL_CODE
  #define     DEFAULT_START_SEC_CODE
#elif defined (COM_STOP_SEC_APPL_CODE)
  #undef      COM_STOP_SEC_APPL_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (COM_START_SEC_VAR_CLEARED_BOOLEAN)
  #undef      COM_START_SEC_VAR_CLEARED_BOOLEAN
  #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (COM_STOP_SEC_VAR_CLEARED_BOOLEAN)
  #undef      COM_STOP_SEC_VAR_CLEARED_BOOLEAN
  #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (COM_START_SEC_CONFIG_VAR_NO_INIT_8)
  #undef      COM_START_SEC_CONFIG_VAR_NO_INIT_8
  #define DEFAULT_START_SEC_CONFIG_VAR_NO_INIT_8
#elif defined (COM_STOP_SEC_CONFIG_VAR_NO_INIT_8)
  #undef      COM_STOP_SEC_CONFIG_VAR_NO_INIT_8
  #define DEFAULT_STOP_SEC_CONFIG_VAR_NO_INIT_8

#elif defined (COM_START_SEC_VAR_INIT_8)
  #undef      COM_START_SEC_VAR_INIT_8
  #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (COM_STOP_SEC_VAR_INIT_8)
  #undef      COM_STOP_SEC_VAR_INIT_8
  #define DEFAULT_STOP_SEC_VAR_INIT_8

#elif defined (COM_START_SEC_VAR_INIT_16)
  #undef      COM_START_SEC_VAR_INIT_16
  #define DEFAULT_START_SEC_VAR_INIT_16
#elif defined (COM_STOP_SEC_VAR_INIT_16)
  #undef      COM_STOP_SEC_VAR_INIT_16
  #define DEFAULT_STOP_SEC_VAR_INIT_16

#elif defined (COM_START_SEC_VAR_INIT_32)
  #undef      COM_START_SEC_VAR_INIT_32
  #define DEFAULT_START_SEC_VAR_INIT_32
#elif defined (COM_STOP_SEC_VAR_INIT_32)
  #undef      COM_STOP_SEC_VAR_INIT_32
  #define DEFAULT_STOP_SEC_VAR_INIT_32

#elif defined (COM_START_SEC_VAR_INIT_UNSPECIFIED)
  #undef      COM_START_SEC_VAR_INIT_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (COM_STOP_SEC_VAR_INIT_UNSPECIFIED)
  #undef      COM_STOP_SEC_VAR_INIT_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/*             PduR                                                           */
/* -------------------------------------------------------------------------- */
   #elif defined (PDUR_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      PDUR_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_PDUR_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (PDUR_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_PDUR_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
/* Section name shall be PDUR_START_SEC_CONFIG_NO_INIT_VAR_8 */
#elif defined (PDUR_START_SEC_CONFIG_VAR_NO_INIT_8)
   #undef      PDUR_START_SEC_CONFIG_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_CONFIG_VAR_NO_INIT_8
/* Section name shall be PDUR_STOP_SEC_CONFIG_NO_INIT_VAR_8 */
#elif defined (PDUR_STOP_SEC_CONFIG_VAR_NO_INIT_8)
   #undef      PDUR_STOP_SEC_CONFIG_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_CONFIG_VAR_NO_INIT_8

#elif defined (PDUR_START_SEC_VAR_INIT_8)
   #undef      PDUR_START_SEC_VAR_INIT_8
   #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (PDUR_STOP_SEC_VAR_INIT_8)
   #undef      PDUR_STOP_SEC_VAR_INIT_8
   #define DEFAULT_STOP_SEC_VAR_INIT_8

#elif defined (PDUR_START_SEC_VAR_NO_INIT_16)
   #undef      PDUR_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (PDUR_STOP_SEC_VAR_NO_INIT_16)
   #undef      PDUR_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

/* Section name shall be PDUR_START_SEC_VAR_NO_INIT_8 */
#elif defined (PDUR_START_SEC_VAR_NO_INIT_8)
   #undef      PDUR_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
/* Section name shall be PDUR_STOP_SEC_VAR_NO_INIT_8 */
#elif defined (PDUR_STOP_SEC_VAR_NO_INIT_8)
   #undef      PDUR_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (PDUR_START_SEC_CONFIG_VAR_CLEARED_8)
   #undef      PDUR_START_SEC_CONFIG_VAR_CLEARED_8
   #define DEFAULT_START_SEC_CONFIG_VAR_CLEARED_8
#elif defined (PDUR_STOP_SEC_CONFIG_VAR_CLEARED_8)
   #undef      PDUR_STOP_SEC_CONFIG_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_CONFIG_VAR_CLEARED_8

#elif defined (PDUR_START_SEC_CONFIG_CONST_8)
   #undef      PDUR_START_SEC_CONFIG_CONST_8
   #define DEFAULT_START_SEC_CONFIG_CONST_8
#elif defined (PDUR_STOP_SEC_CONFIG_CONST_8)
   #undef      PDUR_STOP_SEC_CONFIG_CONST_8
   #define DEFAULT_STOP_SEC_CONFIG_CONST_8

 #elif defined (PDUR_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      PDUR_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (PDUR_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      PDUR_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (PDUR_START_SEC_VAR_CLEARED_8)
   #undef      PDUR_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (PDUR_STOP_SEC_VAR_CLEARED_8)
   #undef      PDUR_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (PDUR_START_SEC_CONST_8)
   #undef      PDUR_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (PDUR_STOP_SEC_CONST_8)
   #undef      PDUR_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (PDUR_START_SEC_VAR_CLEARED_32)
   #undef      PDUR_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (PDUR_STOP_SEC_VAR_CLEARED_32)
   #undef      PDUR_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32
   #elif defined (PDUR_START_SEC_VAR_INIT_32)
   #undef      PDUR_START_SEC_VAR_INIT_32
   #define DEFAULT_START_SEC_VAR_INIT_32
#elif defined (PDUR_STOP_SEC_VAR_INIT_32)
   #undef      PDUR_STOP_SEC_VAR_INIT_32
   #define DEFAULT_STOP_SEC_VAR_INIT_32

#elif defined (PDUR_START_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED)
   #undef      PDUR_START_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED
#elif defined (PDUR_STOP_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_DBTOC_CONFIG_CONST_UNSPECIFIED

#elif defined (PDUR_START_SEC_CONFIG_CONST_UNSPECIFIED)
   #undef      PDUR_START_SEC_CONFIG_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_CONST_UNSPECIFIED
#elif defined (PDUR_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_CONFIG_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_CONST_UNSPECIFIED

/* Section name shall be PDUR_START_SEC_CONFIG_VAR_NO_INIT_UNSPECIFIED */
#elif defined (PDUR_START_SEC_CONFIG_VAR_NO_INIT_UNSPECIFIED)
   #undef      PDUR_START_SEC_CONFIG_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_VAR_NO_INIT_UNSPECIFIED
/* Section name shall be PDUR_STOP_SEC_CONFIG_VAR_NO_INIT_UNSPECIFIED */
#elif defined (PDUR_STOP_SEC_CONFIG_VAR_NO_INIT_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_CONFIG_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_VAR_NO_INIT_UNSPECIFIED

#elif defined (PDUR_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      PDUR_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (PDUR_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (PDUR_START_SEC_CONFIG_VAR_CLEARED_UNSPECIFIED)
   #undef      PDUR_START_SEC_CONFIG_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_VAR_CLEARED_UNSPECIFIED
#elif defined (PDUR_STOP_SEC_CONFIG_VAR_CLEARED_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_CONFIG_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_VAR_CLEARED_UNSPECIFIED

#elif defined (PDUR_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      PDUR_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (PDUR_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (PDUR_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      PDUR_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (PDUR_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

/* Section name shall be PDUR_START_SEC_VAR_NO_INIT_UNSPECIFIED */
#elif defined (PDUR_START_SEC_VAR_UNSPECIFIED)
   #undef      PDUR_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
/* Section name shall be PDUR_STOP_SEC_VAR_NO_INIT_UNSPECIFIED */
#elif defined (PDUR_STOP_SEC_VAR_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED
   /* Section name shall be PDUR_START_SEC_VAR_INIT_UNSPECIFIED */
#elif defined (PDUR_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      PDUR_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
/* Section name shall be PDUR_STOP_SEC_VAR_INIT_UNSPECIFIED */
#elif defined (PDUR_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED

#elif defined (PDUR_START_SEC_CONST_UNSPECIFIED)
   #undef      PDUR_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (PDUR_STOP_SEC_CONST_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (PDUR_START_SEC_CODE)
   #undef      PDUR_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (PDUR_STOP_SEC_CODE)
   #undef      PDUR_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (PDUR_START_SEC_CODE)
   #undef      PDUR_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (PDUR_STOP_SEC_CODE)
   #undef      PDUR_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*             Dem                                                           */
/* -------------------------------------------------------------------------- */
#elif defined (DEM_START_SEC_CONST_BOOLEAN)
   #undef      DEM_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (DEM_STOP_SEC_CONST_BOOLEAN)
   #undef      DEM_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (DEM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
   #undef      DEM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
#elif defined (DEM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
   #undef      DEM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED

#elif defined (DEM_START_SEC_VAR_CLEARED_8)
   #undef      DEM_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (DEM_STOP_SEC_VAR_CLEARED_8)
   #undef      DEM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (DEM_START_SEC_VAR_CLEARED_16)
   #undef      DEM_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (DEM_STOP_SEC_VAR_CLEARED_16)
   #undef      DEM_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (DEM_START_SEC_VAR_CLEARED_32)
   #undef      DEM_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (DEM_STOP_SEC_VAR_CLEARED_32)
   #undef      DEM_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (DEM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DEM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (DEM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DEM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (DEM_START_SEC_VAR_NO_INIT_8)
   #undef      DEM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (DEM_STOP_SEC_VAR_NO_INIT_8)
   #undef      DEM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (DEM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DEM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (DEM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DEM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED


#elif defined (DEM_START_SEC_CONST_UNSPECIFIED)
   #undef      DEM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DEM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      DEM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DEM_START_SEC_CODE)
   #undef      DEM_START_SEC_CODE
   #define     DEFAULT_START_SEC_CODE
#elif defined (DEM_STOP_SEC_CODE)
   #undef      DEM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*                                CANTP                                       */
/* -------------------------------------------------------------------------- */
 #elif defined (CANTP_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANTP_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (CANTP_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANTP_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

 #elif defined (CANTP_START_SEC_VAR_CLEARED_8)
   #undef      CANTP_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
 #elif defined (CANTP_STOP_SEC_VAR_CLEARED_8)
   #undef      CANTP_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (CANTP_START_SEC_CONST_8)
   #undef      CANTP_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (CANTP_STOP_SEC_CONST_8)
   #undef      CANTP_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

 #elif defined (CANTP_START_SEC_VAR_CLEARED_16)
   #undef      CANTP_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (CANTP_STOP_SEC_VAR_CLEARED_16)
   #undef      CANTP_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

   #elif defined (CANTP_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      CANTP_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (CANTP_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      CANTP_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

 #elif defined (CANTP_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CANTP_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
 #elif defined (CANTP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CANTP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (CANTP_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      CANTP_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (CANTP_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      CANTP_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED

#elif defined (CANTP_START_SEC_CONST_UNSPECIFIED)
   #undef      CANTP_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (CANTP_STOP_SEC_CONST_UNSPECIFIED)
   #undef      CANTP_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (CANTP_START_SEC_CODE)
   #undef      CANTP_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (CANTP_STOP_SEC_CODE)
   #undef      CANTP_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

   /* -------------------------------------------------------------------------- */
/*                           RamTst                                           */
/* -------------------------------------------------------------------------- */

#elif defined (RAMTST_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      RAMTST_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (RAMTST_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      RAMTST_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (RAMTST_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      RAMTST_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (RAMTST_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      RAMTST_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (RAMTST_START_SEC_CONST_UNSPECIFIED)
   #undef      RAMTST_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (RAMTST_STOP_SEC_CONST_UNSPECIFIED)
   #undef      RAMTST_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (RAMTST_START_SEC_CODE)
   #undef      RAMTST_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (RAMTST_STOP_SEC_CODE)
   #undef      RAMTST_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (RAMTST_START_SEC_VAR_CLEARED_8)
   #undef      RAMTST_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (RAMTST_STOP_SEC_VAR_CLEARED_8)
   #undef      RAMTST_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8
/* -------------------------------------------------------------------------- */
/*             FrNm                                                          */
/* -------------------------------------------------------------------------- */

#elif defined (FRNM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRNM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (FRNM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRNM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN
   
#elif defined (FRNM_START_SEC_VAR_CLEARED_8)
   #undef      FRNM_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (FRNM_STOP_SEC_VAR_CLEARED_8)
   #undef      FRNM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8   
   
#elif defined (FRNM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      FRNM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (FRNM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      FRNM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED  

#elif defined (FRNM_START_SEC_VAR_NO_INIT_8)
   #undef      FRNM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (FRNM_STOP_SEC_VAR_NO_INIT_8)
   #undef      FRNM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (FRNM_START_SEC_VAR_NO_INIT_16)
   #undef      FRNM_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (FRNM_STOP_SEC_VAR_NO_INIT_16)
   #undef      FRNM_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16
   
#elif defined (FRNM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRNM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (FRNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (FRNM_START_SEC_CONST_8)
   #undef      FRNM_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (FRNM_STOP_SEC_CONST_8)
   #undef      FRNM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (FRNM_START_SEC_CONST_UNSPECIFIED)
   #undef      FRNM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRNM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      FRNM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FRNM_START_SEC_VAR_UNSPECIFIED)
   #undef      FRNM_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (FRNM_STOP_SEC_VAR_UNSPECIFIED)
   #undef      FRNM_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FRNM_START_SEC_CODE)
   #undef      FRNM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (FRNM_STOP_SEC_CODE)
   #undef      FRNM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

 /* -------------------------------------------------------------------------- */
/*             LinTrcv                                                        */
/* -------------------------------------------------------------------------- */
#elif defined (LINTRCV_7259GE_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINTRCV_7259GE_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (LINTRCV_7259GE_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINTRCV_7259GE_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (LINTRCV_7259GE_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      LINTRCV_7259GE_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (LINTRCV_7259GE_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      LINTRCV_7259GE_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (LINTRCV_7259GE_START_SEC_CONST_UNSPECIFIED)
   #undef      LINTRCV_7259GE_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (LINTRCV_7259GE_STOP_SEC_CONST_UNSPECIFIED)
   #undef      LINTRCV_7259GE_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (LINTRCV_7259GE_START_SEC_CODE)
   #undef      LINTRCV_7259GE_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (LINTRCV_7259GE_STOP_SEC_CODE)
   #undef      LINTRCV_7259GE_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (LINTRCV_7259GE_START_SEC_CODE)
   #undef      LINTRCV_7259GE_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (LINTRCV_7259GE_STOP_SEC_CODE)
   #undef      LINTRCV_7259GE_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE


/* -------------------------------------------------------------------------- */
/*             StbM                                                           */
/* -------------------------------------------------------------------------- */

#elif defined (STBM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      STBM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (STBM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      STBM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (STBM_START_SEC_VAR_CLEARED_8)
   #undef      STBM_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (STBM_STOP_SEC_VAR_CLEARED_8)
   #undef      STBM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (STBM_START_SEC_VAR_CLEARED_16)
   #undef      STBM_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (STBM_STOP_SEC_VAR_CLEARED_16)
   #undef      STBM_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (STBM_START_SEC_VAR_CLEARED_32)
   #undef      STBM_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (STBM_STOP_SEC_VAR_CLEARED_32)
   #undef      STBM_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (STBM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      STBM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (STBM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      STBM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (STBM_START_SEC_VAR_INIT_BOOLEAN)
   #undef      STBM_START_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_INIT_BOOLEAN
#elif defined (STBM_STOP_SEC_VAR_INIT_BOOLEAN)
   #undef      STBM_STOP_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_INIT_BOOLEAN

#elif defined (STBM_START_SEC_VAR_INIT_8)
   #undef      STBM_START_SEC_VAR_INIT_8
   #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (STBM_STOP_SEC_VAR_INIT_8)
   #undef      STBM_STOP_SEC_VAR_INIT_8
   #define DEFAULT_STOP_SEC_VAR_INIT_8

#elif defined (STBM_START_SEC_VAR_INIT_16)
   #undef      STBM_START_SEC_VAR_INIT_16
   #define DEFAULT_START_SEC_VAR_INIT_16
#elif defined (STBM_STOP_SEC_VAR_INIT_16)
   #undef      STBM_STOP_SEC_VAR_INIT_16
   #define DEFAULT_STOP_SEC_VAR_INIT_16

#elif defined (STBM_START_SEC_VAR_INIT_32)
   #undef      STBM_START_SEC_VAR_INIT_32
   #define DEFAULT_START_SEC_VAR_INIT_32
#elif defined (STBM_STOP_SEC_VAR_INIT_32)
   #undef      STBM_STOP_SEC_VAR_INIT_32
   #define DEFAULT_STOP_SEC_VAR_INIT_32

#elif defined (STBM_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      STBM_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (STBM_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      STBM_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED

#elif defined (STBM_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      STBM_START_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (STBM_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      STBM_STOP_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN

#elif defined (STBM_START_SEC_VAR_NO_INIT_8)
   #undef      STBM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (STBM_STOP_SEC_VAR_NO_INIT_8)
   #undef      STBM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (STBM_START_SEC_VAR_NO_INIT_16)
   #undef      STBM_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (STBM_STOP_SEC_VAR_NO_INIT_16)
   #undef      STBM_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (STBM_START_SEC_VAR_NO_INIT_32)
   #undef      STBM_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (STBM_STOP_SEC_VAR_NO_INIT_32)
   #undef      STBM_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (STBM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      STBM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (STBM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      STBM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (STBM_START_SEC_CONST_BOOLEAN)
   #undef      STBM_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (STBM_STOP_SEC_CONST_BOOLEAN)
   #undef      STBM_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (STBM_START_SEC_CONST_8)
   #undef      STBM_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (STBM_STOP_SEC_CONST_8)
   #undef      STBM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (STBM_START_SEC_CONST_16)
   #undef      STBM_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (STBM_STOP_SEC_CONST_16)
   #undef      STBM_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

#elif defined (STBM_START_SEC_CONST_32)
   #undef      STBM_START_SEC_CONST_32
   #define DEFAULT_START_SEC_CONST_32
#elif defined (STBM_STOP_SEC_CONST_32)
   #undef      STBM_STOP_SEC_CONST_32
   #define DEFAULT_STOP_SEC_CONST_32

#elif defined (STBM_START_SEC_CONST_UNSPECIFIED)
   #undef      STBM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (STBM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      STBM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (STBM_START_SEC_CODE)
   #undef      STBM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (STBM_STOP_SEC_CODE)
   #undef      STBM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*                 DLT                                                        */
/* -------------------------------------------------------------------------- */
#elif defined (DLT_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DLT_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (DLT_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DLT_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (DLT_START_SEC_VAR_CLEARED_8)
   #undef      DLT_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (DLT_STOP_SEC_VAR_CLEARED_8)
   #undef      DLT_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (DLT_START_SEC_VAR_CLEARED_16)
   #undef      DLT_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (DLT_STOP_SEC_VAR_CLEARED_16)
   #undef      DLT_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (DLT_START_SEC_VAR_CLEARED_32)
   #undef      DLT_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (DLT_STOP_SEC_VAR_CLEARED_32)
   #undef      DLT_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (DLT_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      DLT_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (DLT_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      DLT_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (DLT_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      DLT_START_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (DLT_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      DLT_STOP_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN

#elif defined (DLT_START_SEC_VAR_NO_INIT_8)
   #undef      DLT_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (DLT_STOP_SEC_VAR_NO_INIT_8)
   #undef      DLT_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (DLT_START_SEC_VAR_NO_INIT_16)
   #undef      DLT_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (DLT_STOP_SEC_VAR_NO_INIT_16)
   #undef      DLT_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (DLT_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DLT_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (DLT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DLT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (DLT_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      DLT_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
#elif defined (DLT_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      DLT_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED

#elif defined (DLT_START_SEC_CONST_UNSPECIFIED)
   #undef      DLT_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DLT_STOP_SEC_CONST_UNSPECIFIED)
   #undef      DLT_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DLT_START_SEC_CODE)
   #undef      DLT_START_SEC_CODE
   #define     DEFAULT_START_SEC_CODE
#elif defined (DLT_STOP_SEC_CODE)
   #undef      DLT_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE
/* -------------------------------------------------------------------------- */
/*             IpduM                                                          */
/* -------------------------------------------------------------------------- */
#elif defined (IPDUM_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      IPDUM_START_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (IPDUM_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      IPDUM_STOP_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN

#elif defined (IPDUM_START_SEC_VAR_NO_INIT_8)
   #undef      IPDUM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (IPDUM_STOP_SEC_VAR_NO_INIT_8)
   #undef      IPDUM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (IPDUM_START_SEC_VAR_NO_INIT_16)
   #undef      IPDUM_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (IPDUM_STOP_SEC_VAR_NO_INIT_16)
   #undef      IPDUM_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (IPDUM_START_SEC_VAR_NO_INIT_32)
   #undef      IPDUM_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (IPDUM_STOP_SEC_VAR_NO_INIT_32)
   #undef      IPDUM_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (IPDUM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      IPDUM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (IPDUM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      IPDUM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (IPDUM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      IPDUM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (IPDUM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      IPDUM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (IPDUM_START_SEC_VAR_CLEARED_8)
   #undef      IPDUM_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (IPDUM_STOP_SEC_VAR_CLEARED_8)
   #undef      IPDUM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (IPDUM_START_SEC_VAR_CLEARED_16)
   #undef      IPDUM_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (IPDUM_STOP_SEC_VAR_CLEARED_16)
   #undef      IPDUM_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (IPDUM_START_SEC_VAR_CLEARED_32)
   #undef      IPDUM_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (IPDUM_STOP_SEC_VAR_CLEARED_32)
   #undef      IPDUM_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (IPDUM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      IPDUM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (IPDUM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      IPDUM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (IPDUM_START_SEC_VAR_INIT_BOOLEAN)
   #undef      IPDUM_START_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_INIT_BOOLEAN
#elif defined (IPDUM_STOP_SEC_VAR_INIT_BOOLEAN)
   #undef      IPDUM_STOP_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_INIT_BOOLEAN

#elif defined (IPDUM_START_SEC_VAR_INIT_8)
   #undef      IPDUM_START_SEC_VAR_INIT_8
   #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (IPDUM_STOP_SEC_VAR_INIT_8)
   #undef      IPDUM_STOP_SEC_VAR_INIT_8
   #define DEFAULT_STOP_SEC_VAR_INIT_8

#elif defined (IPDUM_START_SEC_VAR_INIT_16)
   #undef      IPDUM_START_SEC_VAR_INIT_16
   #define DEFAULT_START_SEC_VAR_INIT_16
#elif defined (IPDUM_STOP_SEC_VAR_INIT_16)
   #undef      IPDUM_STOP_SEC_VAR_INIT_16
   #define DEFAULT_STOP_SEC_VAR_INIT_16

#elif defined (IPDUM_START_SEC_VAR_INIT_32)
   #undef      IPDUM_START_SEC_VAR_INIT_32
   #define DEFAULT_START_SEC_VAR_INIT_32
#elif defined (IPDUM_STOP_SEC_VAR_INIT_32)
   #undef      IPDUM_STOP_SEC_VAR_INIT_32
   #define DEFAULT_STOP_SEC_VAR_INIT_32

#elif defined (IPDUM_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      IPDUM_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (IPDUM_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      IPDUM_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED

#elif defined (IPDUM_START_SEC_CONST_BOOLEAN)
   #undef      IPDUM_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (IPDUM_STOP_SEC_CONST_BOOLEAN)
   #undef      IPDUM_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (IPDUM_START_SEC_CONST_8)
   #undef      IPDUM_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (IPDUM_STOP_SEC_CONST_8)
   #undef      IPDUM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (IPDUM_START_SEC_CONST_16)
   #undef      IPDUM_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (IPDUM_STOP_SEC_CONST_16)
   #undef      IPDUM_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

#elif defined (IPDUM_START_SEC_CONST_UNSPECIFIED)
   #undef      IPDUM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (IPDUM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      IPDUM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (IPDUM_START_SEC_CODE)
   #undef      IPDUM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (IPDUM_STOP_SEC_CODE)
   #undef      IPDUM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*                           CANSM                                            */
/* -------------------------------------------------------------------------- */
#elif defined (CANSM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANSM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (CANSM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANSM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (CANSM_START_SEC_CONST_8)
   #undef      CANSM_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (CANSM_STOP_SEC_CONST_8)
   #undef      CANSM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (CANSM_START_SEC_VAR_CLEARED_8)
   #undef      CANSM_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (CANSM_STOP_SEC_VAR_CLEARED_8)
   #undef      CANSM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (CANSM_START_SEC_VAR_NO_INIT_8)
   #undef      CANSM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (CANSM_STOP_SEC_VAR_NO_INIT_8)
   #undef      CANSM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (CANSM_START_SEC_CONST_UNSPECIFIED)
   #undef      CANSM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (CANSM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      CANSM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (CANSM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CANSM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (CANSM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CANSM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (CANSM_START_SEC_CODE)
   #undef      CANSM_START_SEC_CODE
   #define     DEFAULT_START_SEC_CODE
#elif defined (CANSM_STOP_SEC_CODE)
   #undef      CANSM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (CANSM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      CANSM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (CANSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      CANSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED
/* -------------------------------------------------------------------------- */
/*                           OSEKNM                                            */
/* -------------------------------------------------------------------------- */
#elif defined (OSEKNM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      OSEKNM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (OSEKNM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      OSEKNM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (OSEKNM_START_SEC_CONST_8)
   #undef      OSEKNM_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (OSEKNM_STOP_SEC_CONST_8)
   #undef      OSEKNM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (OSEKNM_START_SEC_VAR_CLEARED_8)
   #undef      OSEKNM_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (OSEKNM_STOP_SEC_VAR_CLEARED_8)
   #undef      OSEKNM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (OSEKNM_START_SEC_VAR_NO_INIT_8)
   #undef      OSEKNM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (OSEKNM_STOP_SEC_VAR_NO_INIT_8)
   #undef      OSEKNM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (OSEKNM_START_SEC_CONST_UNSPECIFIED)
   #undef      OSEKNM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (OSEKNM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      OSEKNM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (OSEKNM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      OSEKNM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (OSEKNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      OSEKNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (OSEKNM_START_SEC_CODE)
   #undef      OSEKNM_START_SEC_CODE
   #define     DEFAULT_START_SEC_CODE
#elif defined (OSEKNM_STOP_SEC_CODE)
   #undef      OSEKNM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (OSEKNM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      OSEKNM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (OSEKNM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      OSEKNM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED
/* -------------------------------------------------------------------------- */
/*             CanNm                                                          */
/* -------------------------------------------------------------------------- */

#elif defined (CANNM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANNM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (CANNM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANNM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (CANNM_START_SEC_VAR_NO_INIT_8)
   #undef      CANNM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (CANNM_STOP_SEC_VAR_NO_INIT_8)
   #undef      CANNM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (CANNM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CANNM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (CANNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CANNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (CANNM_START_SEC_CONST_8)
   #undef      CANNM_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (CANNM_STOP_SEC_CONST_8)
   #undef      CANNM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (CANNM_START_SEC_CONST_UNSPECIFIED)
   #undef      CANNM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (CANNM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      CANNM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (CANNM_START_SEC_VAR_UNSPECIFIED)
   #undef      CANNM_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (CANNM_STOP_SEC_VAR_UNSPECIFIED)
   #undef      CANNM_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (CANNM_START_SEC_CODE)
   #undef      CANNM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (CANNM_STOP_SEC_CODE)
   #undef      CANNM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE
   
/* -------------------------------------------------------------------------- */
/*                 CAN Transceiver                                            */
/* -------------------------------------------------------------------------- */

#elif defined (CANTRCV_START_SEC_CODE)
   #undef      CANTRCV_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE

#elif defined (CANTRCV_STOP_SEC_CODE)
   #undef      CANTRCV_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (CANTRCV_START_SEC_CONST_UNSPECIFIED)
   #undef      CANTRCV_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED

#elif defined (CANTRCV_STOP_SEC_CONST_UNSPECIFIED)
   #undef      CANTRCV_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (CANTRCV_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANTRCV_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (CANTRCV_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANTRCV_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (CANTRCV_START_SEC_VAR_CLEARED_8)
   #undef      CANTRCV_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (CANTRCV_STOP_SEC_VAR_CLEARED_8)
   #undef      CANTRCV_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8
   
#elif defined (CANTRCV_START_SEC_VAR_CLEARED_16)
   #undef      CANTRCV_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (CANTRCV_STOP_SEC_VAR_CLEARED_16)
   #undef      CANTRCV_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16
   
#elif defined (CANTRCV_START_SEC_VAR_CLEARED_32)
   #undef      CANTRCV_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (CANTRCV_STOP_SEC_VAR_CLEARED_32)
   #undef      CANTRCV_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32
   
/* -------------------------------------------------------------------------- */
/*                 General CAN Transceiver                                    */
/* -------------------------------------------------------------------------- */

#elif defined (CANTRCV_START_SEC_CODE)
   #undef      CANTRCV_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE

#elif defined (CANTRCV_STOP_SEC_CODE)
   #undef      CANTRCV_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (CANTRCV_START_SEC_CONST_UNSPECIFIED)
   #undef      CANTRCV_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED

#elif defined (CANTRCV_STOP_SEC_CONST_UNSPECIFIED)
   #undef      CANTRCV_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (CANTRCV_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANTRCV_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (CANTRCV_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANTRCV_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (CANTRCV_START_SEC_VAR_CLEARED_8)
   #undef      CANTRCV_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (CANTRCV_STOP_SEC_VAR_CLEARED_8)
   #undef      CANTRCV_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

/*----------------------------------------------------------------------------*/
/*                           E2E                                              */
/*----------------------------------------------------------------------------*/

  #elif defined (E2E_START_SEC_VAR_NO_INIT_1)
   #undef      E2E_START_SEC_VAR_NO_INIT_1
   #define DEFAULT_START_SEC_VAR_NO_INIT_1
#elif defined (E2E_STOP_SEC_VAR_NO_INIT_1)
   #undef      E2E_STOP_SEC_VAR_NO_INIT_1
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_1

#elif defined (E2E_START_SEC_VAR_NO_INIT_8)
   #undef      E2E_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (E2E_STOP_SEC_VAR_NO_INIT_8)
   #undef      E2E_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (E2E_START_SEC_VAR_NO_INIT_16)
   #undef      E2E_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (E2E_STOP_SEC_VAR_NO_INIT_16)
   #undef      E2E_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (E2E_START_SEC_VAR_NO_INIT_32)
   #undef      E2E_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (E2E_STOP_SEC_VAR_NO_INIT_32)
   #undef      E2E_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (E2E_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      E2E_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (E2E_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      E2E_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (E2E_START_SEC_VAR_CLEARED_1)
   #undef      E2E_START_SEC_VAR_CLEARED_1
   #define DEFAULT_START_SEC_VAR_CLEARED_1
#elif defined (E2E_STOP_SEC_VAR_CLEARED_1)
   #undef      E2E_STOP_SEC_VAR_CLEARED_1
   #define DEFAULT_STOP_SEC_VAR_CLEARED_1

#elif defined (E2E_START_SEC_VAR_CLEARED_8)
   #undef      E2E_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (E2E_STOP_SEC_VAR_CLEARED_8)
   #undef      E2E_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (E2E_START_SEC_VAR_CLEARED_16)
   #undef      E2E_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (E2E_STOP_SEC_VAR_CLEARED_16)
   #undef      E2E_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (E2E_START_SEC_VAR_CLEARED_32)
   #undef      E2E_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (E2E_STOP_SEC_VAR_CLEARED_32)
   #undef      E2E_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (E2E_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      E2E_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (E2E_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      E2E_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (E2E_START_SEC_VAR_INIT_1)
   #undef      E2E_START_SEC_VAR_INIT_1
   #define DEFAULT_START_SEC_VAR_INIT_1
#elif defined (E2E_STOP_SEC_VAR_INIT_1)
   #undef      E2E_STOP_SEC_VAR_INIT_1
   #define DEFAULT_STOP_SEC_VAR_INIT_1

#elif defined (E2E_START_SEC_VAR_INIT_8)
   #undef      E2E_START_SEC_VAR_INIT_8
   #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (E2E_STOP_SEC_VAR_INIT_8)
   #undef      E2E_STOP_SEC_VAR_INIT_8
   #define DEFAULT_STOP_SEC_VAR_INIT_8

#elif defined (E2E_START_SEC_VAR_INIT_16)
   #undef      E2E_START_SEC_VAR_INIT_16
   #define DEFAULT_START_SEC_VAR_INIT_16
#elif defined (E2E_STOP_SEC_VAR_INIT_16)
   #undef      E2E_STOP_SEC_VAR_INIT_16
   #define DEFAULT_STOP_SEC_VAR_INIT_16

#elif defined (E2E_START_SEC_VAR_INIT_32)
   #undef      E2E_START_SEC_VAR_INIT_32
   #define DEFAULT_START_SEC_VAR_INIT_32
#elif defined (E2E_STOP_SEC_VAR_INIT_32)
   #undef      E2E_STOP_SEC_VAR_INIT_32
   #define DEFAULT_STOP_SEC_VAR_INIT_32

#elif defined (E2E_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      E2E_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (E2E_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      E2E_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED

#elif defined (E2E_START_SEC_CONST_1)
   #undef      E2E_START_SEC_CONST_1
   #define DEFAULT_START_SEC_CONST_1
#elif defined (E2E_STOP_SEC_CONST_1)
   #undef      E2E_STOP_SEC_CONST_1
   #define DEFAULT_STOP_SEC_CONST_1

#elif defined (E2E_START_SEC_CONST_8)
   #undef      E2E_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (E2E_STOP_SEC_CONST_8)
   #undef      E2E_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (E2E_START_SEC_CONST_16)
   #undef      E2E_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (E2E_STOP_SEC_CONST_16)
   #undef      E2E_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

#elif defined (E2E_START_SEC_CONST_UNSPECIFIED)
   #undef      E2E_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (E2E_STOP_SEC_CONST_UNSPECIFIED)
   #undef      E2E_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (E2E_START_SEC_CODE)
   #undef      E2E_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (E2E_STOP_SEC_CODE)
   #undef      E2E_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/*----------------------------------------------------------------------------*/
/*                           J1939TP                                          */
/*----------------------------------------------------------------------------*/
#elif defined (J1939TP_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      J1939TP_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (J1939TP_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      J1939TP_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (J1939TP_START_SEC_VAR_CLEARED_8)
   #undef      J1939TP_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (J1939TP_STOP_SEC_VAR_CLEARED_8)
   #undef      J1939TP_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (J1939TP_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      J1939TP_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (J1939TP_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      J1939TP_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (J1939TP_START_SEC_VAR_NO_INIT_8)
   #undef      J1939TP_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (J1939TP_STOP_SEC_VAR_NO_INIT_8)
   #undef      J1939TP_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (J1939TP_START_SEC_VAR_NO_INIT_16)
   #undef      J1939TP_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (J1939TP_STOP_SEC_VAR_NO_INIT_16)
   #undef      J1939TP_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (J1939TP_START_SEC_VAR_NO_INIT_32)
   #undef      J1939TP_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (J1939TP_STOP_SEC_VAR_NO_INIT_32)
   #undef      J1939TP_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (J1939TP_START_SEC_VAR_SAVED_ZONE_16)
   #undef      J1939TP_START_SEC_VAR_SAVED_ZONE_16
   #define DEFAULT_START_SEC_VAR_SAVED_ZONE_16
#elif defined (J1939TP_STOP_SEC_VAR_SAVED_ZONE_16)
   #undef      J1939TP_STOP_SEC_VAR_SAVED_ZONE_16
   #define DEFAULT_STOP_SEC_VAR_SAVED_ZONE_16

#elif defined (J1939TP_START_SEC_VAR_SAVED_ZONE_8)
   #undef      J1939TP_START_SEC_VAR_SAVED_ZONE_8
   #define DEFAULT_START_SEC_VAR_SAVED_ZONE_8
#elif defined (J1939TP_STOP_SEC_VAR_SAVED_ZONE_8)
   #undef      J1939TP_STOP_SEC_VAR_SAVED_ZONE_8
   #define DEFAULT_STOP_SEC_VAR_SAVED_ZONE_8

#elif defined (J1939TP_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      J1939TP_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (J1939TP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      J1939TP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (J1939TP_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      J1939TP_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
#elif defined (J1939TP_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      J1939TP_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED

#elif defined (J1939TP_START_SEC_CONST_8)
   #undef      J1939TP_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (J1939TP_STOP_SEC_CONST_8)
   #undef      J1939TP_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (J1939TP_START_SEC_CONST_UNSPECIFIED)
   #undef      J1939TP_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (J1939TP_STOP_SEC_CONST_UNSPECIFIED)
   #undef      J1939TP_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (J1939TP_START_SEC_CODE)
   #undef      J1939TP_START_SEC_CODE
   #define     DEFAULT_START_SEC_CODE
#elif defined (J1939TP_STOP_SEC_CODE)
   #undef      J1939TP_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

   
   
/* -------------------------------------------------------------------------- */
/*                 LinSM                                                      */
/* -------------------------------------------------------------------------- */

   #elif defined (LINSM_START_SEC_CONST_UNSPECIFIED)
   #undef      LINSM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (LINSM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      LINSM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

   #elif defined (LINSM_START_SEC_CONST_8)
   #undef      LINSM_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (LINSM_STOP_SEC_CONST_8)
   #undef      LINSM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

   #elif defined (LINSM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      LINSM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (LINSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      LINSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

  #elif defined (LINSM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINSM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (LINSM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINSM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

  #elif defined (LINSM_START_SEC_VAR_CLEARED_8)
   #undef      LINSM_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (LINSM_STOP_SEC_VAR_CLEARED_8)
   #undef      LINSM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

  #elif defined (LINSM_START_SEC_CODE)
   #undef      LINSM_START_SEC_CODE
   #define     DEFAULT_START_SEC_CODE
#elif defined (LINSM_STOP_SEC_CODE)
   #undef      LINSM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* ---------------------------------------------------------------------------*/
/*                           MEMIF                                            */
/* -------------------------------------------------------------------------- */
#elif defined (MEMIF_START_SEC_CODE)
   #undef MEMIF_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (MEMIF_STOP_SEC_CODE)
   #undef MEMIF_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* ---------------------------------------------------------------------------*/
/*                           WDGIF                                            */
/* -------------------------------------------------------------------------- */
#elif defined (WDGIF_START_SEC_CODE)
   #undef WDGIF_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (WDGIF_STOP_SEC_CODE)
   #undef WDGIF_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (WDGIF_START_SEC_CONST_UNSPECIFIED)
   #undef WDGIF_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (WDGIF_STOP_SEC_CONST_UNSPECIFIED)
   #undef WDGIF_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

/* ---------------------------------------------------------------------------*/
/*                           WDG_39_ACW                                       */
/* -------------------------------------------------------------------------- */
#elif defined (WDG_39_ACW_START_SEC_CODE)
   #undef WDG_39_ACW_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (WDG_39_ACW_STOP_SEC_CODE)
   #undef WDG_39_ACW_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (WDG_39_ACW_START_SEC_VAR_CLEARED_32)
   #undef WDG_39_ACW_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (WDG_39_ACW_STOP_SEC_VAR_CLEARED_32)
   #undef WDG_39_ACW_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (WDG_39_ACW_START_SEC_CONST_8)
   #undef WDG_39_ACW_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (WDG_39_ACW_STOP_SEC_CONST_8)
   #undef WDG_39_ACW_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (WDG_39_ACW_START_SEC_CONST_32)
   #undef WDG_39_ACW_START_SEC_CONST_32
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (WDG_39_ACW_STOP_SEC_CONST_32)
   #undef WDG_39_ACW_STOP_SEC_CONST_32
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (WDG_39_ACW_START_SEC_VAR_UNSPECIFIED)
   #undef WDG_39_ACW_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (WDG_39_ACW_STOP_SEC_VAR_UNSPECIFIED)
   #undef WDG_39_ACW_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (WDG_39_ACW_START_SEC_CONST_UNSPECIFIED)
   #undef WDG_39_ACW_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (WDG_39_ACW_STOP_SEC_CONST_UNSPECIFIED)
   #undef WDG_39_ACW_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/*                             LinNm                                          */
/* -------------------------------------------------------------------------- */
#elif defined (LINNM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINNM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (LINNM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      LINNM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (LINNM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      LINNM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (LINNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      LINNM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (LINNM_START_SEC_CONST_UNSPECIFIED)
   #undef      LINNM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (LINNM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      LINNM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (LINNM_START_SEC_CODE)
   #undef      LINNM_START_SEC_CODE
   #define     DEFAULT_START_SEC_CODE
#elif defined (LINNM_STOP_SEC_CODE)
   #undef      LINNM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

 /* -------------------------------------------------------------------------- */
/*             FiM                                                            */
/* -------------------------------------------------------------------------- */

#elif defined (FIM_START_SEC_CODE)
   #undef      FIM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (FIM_STOP_SEC_CODE)
   #undef      FIM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (FIM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FIM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (FIM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FIM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (FIM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FIM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (FIM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FIM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (FIM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      FIM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (FIM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      FIM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (FIM_START_SEC_CONST_UNSPECIFIED)
   #undef      FIM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FIM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      FIM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED


/* -------------------------------------------------------------------------- */
/*                 FRSM                                                       */
/* -------------------------------------------------------------------------- */
#elif defined (FRSM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRSM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (FRSM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRSM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

   #elif defined (FRSM_START_SEC_VAR_CLEARED_8)
   #undef      FRSM_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (FRSM_STOP_SEC_VAR_CLEARED_8)
   #undef      FRSM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (FRSM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      FRSM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (FRSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      FRSM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (FRSM_START_SEC_VAR_NO_INIT_8)
   #undef      FRSM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (FRSM_STOP_SEC_VAR_NO_INIT_8)
   #undef      FRSM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (FRSM_START_SEC_CONST_UNSPECIFIED)
   #undef      FRSM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRSM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      FRSM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FRSM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRSM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (FRSM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRSM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (FRSM_START_SEC_CODE)
   #undef      FRSM_START_SEC_CODE
   #define     DEFAULT_START_SEC_CODE
#elif defined (FRSM_STOP_SEC_CODE)
   #undef      FRSM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*             FrIf                                                          */
/* -------------------------------------------------------------------------- */
#elif defined (FRIF_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRIF_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (FRIF_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRIF_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (FRIF_START_SEC_CONST_UNSPECIFIED)
   #undef      FRIF_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRIF_STOP_SEC_CONST_UNSPECIFIED)
   #undef      FRIF_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

   #elif defined (FRIF_START_SEC_VAR_NO_INIT_8)
   #undef      FRIF_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (FRIF_STOP_SEC_VAR_NO_INIT_8)
   #undef      FRIF_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (FRIF_START_SEC_VAR_NO_INIT_8)
   #undef      FRIF_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (FRIF_STOP_SEC_VAR_NO_INIT_8)
   #undef      FRIF_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (FRIF_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRIF_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (FRIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (FRIF_START_SEC_VAR_CLEARED_16)
   #undef      FRIF_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (FRIF_STOP_SEC_VAR_CLEARED_16)
   #undef      FRIF_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (FRIF_START_SEC_CONST_8)
   #undef      FRIF_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (FRIF_STOP_SEC_CONST_8)
   #undef      FRIF_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (FRIF_START_SEC_CONST_UNSPECIFIED)
   #undef      FRIF_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRIF_STOP_SEC_CONST_UNSPECIFIED)
   #undef      FRIF_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FRIF_START_SEC_CODE)
   #undef      FRIF_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (FRIF_STOP_SEC_CODE)
   #undef      FRIF_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*             FrTrcv                                                         */
/* -------------------------------------------------------------------------- */
#elif defined (FRTRCV_1080A_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRTRCV_1080A_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_1
#elif defined (FRTRCV_1080A_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRTRCV_1080A_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_1

#elif defined (FRTRCV_1080A_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRTRCV_1080A_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (FRTRCV_1080A_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRTRCV_1080A_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (FRTRCV_1080A_START_SEC_CONST_UNSPECIFIED)
   #undef      FRTRCV_1080A_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRTRCV_1080A_STOP_SEC_CONST_UNSPECIFIED)
   #undef      FRTRCV_1080A_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FRTRCV_1080A_START_SEC_CODE)
   #undef      FRTRCV_1080A_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined FRTRCV_1080A_STOP_SEC_CODE
   #undef      FRTRCV_1080A_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE
/* -------------------------------------------------------------------------- */
/*                 CANIF                                                      */
/* -------------------------------------------------------------------------- */

#elif defined (CANIF_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANIF_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (CANIF_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      CANIF_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (CANIF_START_SEC_VAR_CLEARED_8)
   #undef      CANIF_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (CANIF_STOP_SEC_VAR_CLEARED_8)
   #undef      CANIF_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (CANIF_START_SEC_VAR_NO_INIT_8)
   #undef      CANIF_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (CANIF_STOP_SEC_VAR_NO_INIT_8)
   #undef      CANIF_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (CANIF_START_SEC_CONST_8)
   #undef      CANIF_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (CANIF_STOP_SEC_CONST_8)
   #undef      CANIF_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

 #elif defined (CANIF_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      CANIF_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (CANIF_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      CANIF_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED


#elif defined (CANIF_START_SEC_CONFIG_VAR_NO_INIT_UNSPECIFIED)
   #undef      CANIF_START_SEC_CONFIG_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_VAR_NO_INIT_UNSPECIFIED
#elif defined (CANIF_STOP_SEC_CONFIG_VAR_NO_INIT_UNSPECIFIED)
   #undef      CANIF_STOP_SEC_CONFIG_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_VAR_NO_INIT_UNSPECIFIED

#elif defined (CANIF_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CANIF_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (CANIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CANIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (CANIF_START_SEC_CONFIG_VAR_NO_INIT_8)
   #undef      CANIF_START_SEC_CONFIG_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_CONFIG_VAR_NO_INIT_8
#elif defined (CANIF_STOP_SEC_CONFIG_VAR_NO_INIT_8)
   #undef      CANIF_STOP_SEC_CONFIG_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_CONFIG_VAR_NO_INIT_8

#elif defined (CANIF_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      CANIF_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (CANIF_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      CANIF_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (CANIF_START_SEC_CONFIG_VAR_CLEARED_UNSPECIFIED)
   #undef      CANIF_START_SEC_CONFIG_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_VAR_CLEARED_UNSPECIFIED
#elif defined (CANIF_STOP_SEC_CONFIG_VAR_CLEARED_UNSPECIFIED)
   #undef      CANIF_STOP_SEC_CONFIG_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_VAR_CLEARED_UNSPECIFIED

#elif defined (CANIF_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CANIF_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (CANIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      CANIF_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (CANIF_START_SEC_CONFIG_CONST_UNSPECIFIED)
   #undef      CANIF_START_SEC_CONFIG_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_CONST_UNSPECIFIED
#elif defined (CANIF_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
   #undef      CANIF_STOP_SEC_CONFIG_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_CONST_UNSPECIFIED

#elif defined (CANIF_START_SEC_CONST_UNSPECIFIED)
   #undef      CANIF_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (CANIF_STOP_SEC_CONST_UNSPECIFIED)
   #undef      CANIF_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

 #elif defined (CANIF_START_SEC_CODE)
   #undef      CANIF_START_SEC_CODE
     #define     DEFAULT_START_SEC_CODE
#elif defined (CANIF_STOP_SEC_CODE)
   #undef      CANIF_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE


/* -------------------------------------------------------------------------- */
/*                 BswM                                                       */
/* -------------------------------------------------------------------------- */

#elif defined (BSWM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      BSWM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (BSWM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      BSWM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (BSWM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      BSWM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (BSWM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      BSWM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (BSWM_START_SEC_CONST_UNSPECIFIED)
   #undef      BSWM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (BSWM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      BSWM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (BSWM_START_SEC_CODE)
   #undef      BSWM_START_SEC_CODE
     #define     DEFAULT_START_SEC_CODE
#elif defined (BSWM_STOP_SEC_CODE)
   #undef      BSWM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (BSWM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      BSWM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (BSWM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      BSWM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED
/* -------------------------------------------------------------------------- */
/*             ComM                                                           */
/* -------------------------------------------------------------------------- */

#elif defined (COMM_START_SEC_VAR_POWER_ON_CLEARED_8)
   #undef      COMM_START_SEC_VAR_POWER_ON_CLEARED_8
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_8
#elif defined (COMM_STOP_SEC_VAR_POWER_ON_CLEARED_8)
   #undef      COMM_STOP_SEC_VAR_POWER_ON_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_8

#elif defined (COMM_START_SEC_VAR_POWER_ON_CLEARED_16)
   #undef      COMM_START_SEC_VAR_POWER_ON_CLEARED_16
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_16
#elif defined (COMM_STOP_SEC_VAR_POWER_ON_CLEARED_16)
   #undef      COMM_STOP_SEC_VAR_POWER_ON_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_16

#elif defined (COMM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
   #undef      COMM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
#elif defined (COMM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
   #undef      COMM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED

#elif defined (COMM_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
   #undef      COMM_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
#elif defined (COMM_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
   #undef      COMM_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN

#elif defined (COMM_START_SEC_VAR_CLEARED_8)
   #undef      COMM_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (COMM_STOP_SEC_VAR_CLEARED_8)
   #undef      COMM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (COMM_START_SEC_VAR_CLEARED_16)
   #undef      COMM_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (COMM_STOP_SEC_VAR_CLEARED_16)
   #undef      COMM_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (COMM_START_SEC_VAR_CLEARED_32)
   #undef      COMM_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (COMM_STOP_SEC_VAR_CLEARED_32)
   #undef      COMM_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32
   
#elif defined (COMM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      COMM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (COMM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      COMM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (COMM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      COMM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (COMM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      COMM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (COMM_START_SEC_VAR_NO_INIT_8)
   #undef      COMM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (COMM_STOP_SEC_VAR_NO_INIT_8)
   #undef      COMM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (COMM_START_SEC_VAR_NO_INIT_16)
   #undef      COMM_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (COMM_STOP_SEC_VAR_NO_INIT_16)
   #undef      COMM_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (COMM_START_SEC_VAR_NO_INIT_32)
   #undef      COMM_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (COMM_STOP_SEC_VAR_NO_INIT_32)
   #undef      COMM_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (COMM_START_SEC_VAR_SAVED_ZONE_16)
   #undef      COMM_START_SEC_VAR_SAVED_ZONE_16
   #define DEFAULT_START_SEC_VAR_SAVED_ZONE_16
#elif defined (COMM_STOP_SEC_VAR_SAVED_ZONE_16)
   #undef      COMM_STOP_SEC_VAR_SAVED_ZONE_16
   #define DEFAULT_STOP_SEC_VAR_SAVED_ZONE_16

#elif defined (COMM_START_SEC_VAR_SAVED_ZONE_8)
   #undef      COMM_START_SEC_VAR_SAVED_ZONE_8
   #define DEFAULT_START_SEC_VAR_SAVED_ZONE_8
#elif defined (COMM_STOP_SEC_VAR_SAVED_ZONE_8)
   #undef      COMM_STOP_SEC_VAR_SAVED_ZONE_8
   #define DEFAULT_STOP_SEC_VAR_SAVED_ZONE_8

#elif defined (COMM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      COMM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (COMM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      COMM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (COMM_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      COMM_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
#elif defined (COMM_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      COMM_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED

#elif defined (COMM_START_SEC_CONST_8)
   #undef      COMM_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (COMM_STOP_SEC_CONST_8)
   #undef      COMM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (COMM_START_SEC_CONST_UNSPECIFIED)
   #undef      COMM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (COMM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      COMM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (COMM_START_SEC_CODE)
   #undef      COMM_START_SEC_CODE
   #define     DEFAULT_START_SEC_CODE
#elif defined (COMM_STOP_SEC_CODE)
   #undef      COMM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE
/* -------------------------------------------------------------------------- */
/*                 CRC                                                        */
/* -------------------------------------------------------------------------- */

#elif defined (CRC_START_SEC_CONST_8)
   #undef      CRC_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (CRC_STOP_SEC_CONST_8)
   #undef      CRC_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (CRC_START_SEC_CONST_16)
   #undef      CRC_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (CRC_STOP_SEC_CONST_16)
   #undef      CRC_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

#elif defined (CRC_START_SEC_CONST_32)
   #undef      CRC_START_SEC_CONST_32
   #define DEFAULT_START_SEC_CONST_32
#elif defined (CRC_STOP_SEC_CONST_32)
   #undef      CRC_STOP_SEC_CONST_32
   #define DEFAULT_STOP_SEC_CONST_32

#elif defined (CRC_START_SEC_CODE)
   #undef      CRC_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (CRC_STOP_SEC_CODE)
   #undef      CRC_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE
/* -------------------------------------------------------------------------- */
/*             Ea                                                            */
/* -------------------------------------------------------------------------- */

#elif defined (EA_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      EA_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (EA_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      EA_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (EA_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      EA_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
#elif defined (EA_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      EA_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED

#elif defined (EA_START_SEC_NO_INIT_VAR_UNSPECIFIED)
   #undef      EA_START_SEC_NO_INIT_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (EA_STOP_SEC_NO_INIT_VAR_UNSPECIFIED)
   #undef      EA_STOP_SEC_NO_INIT_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (EA_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      EA_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (EA_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      EA_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (EA_START_SEC_NO_INIT_VAR_8)
   #undef      EA_START_SEC_NO_INIT_VAR_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (EA_STOP_SEC_NO_INIT_VAR_8)
   #undef      EA_STOP_SEC_NO_INIT_VAR_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

   #elif defined (EA_START_SEC_NO_INIT_VAR_BOOLEAN)
   #undef      EA_START_SEC_NO_INIT_VAR_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (EA_STOP_SEC_NO_INIT_VAR_BOOLEAN)
   #undef      EA_STOP_SEC_NO_INIT_VAR_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN

#elif defined (EA_START_SEC_NO_INIT_VAR_16)
   #undef      EA_START_SEC_NO_INIT_VAR_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (EA_STOP_SEC_NO_INIT_VAR_16)
   #undef      EA_STOP_SEC_NO_INIT_VAR_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (EA_START_SEC_CODE)
   #undef      EA_START_SEC_CODE
#define     DEFAULT_START_SEC_CODE
#elif defined (EA_STOP_SEC_CODE)
   #undef      EA_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (EA_START_SEC_CONST_UNSPECIFIED)
   #undef      EA_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (EA_STOP_SEC_CONST_UNSPECIFIED)
   #undef      EA_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (EA_START_SEC_CONST_16)
   #undef      EA_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (EA_STOP_SEC_CONST_16)
   #undef      EA_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

/* -------------------------------------------------------------------------- */
/*                 NM                                                      */
/* -------------------------------------------------------------------------- */

#elif defined (NM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      NM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (NM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      NM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (NM_START_SEC_VAR_NO_INIT_8)
   #undef      NM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (NM_STOP_SEC_VAR_NO_INIT_8)
   #undef      NM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8

#elif defined (NM_START_SEC_VAR_POWER_ON_INIT_8)
   #undef      NM_START_SEC_VAR_POWER_ON_INIT_8
   #define DEFAULT_START_SEC_VAR_POWER_ON_INIT_8
#elif defined (NM_STOP_SEC_VAR_POWER_ON_INIT_8)
   #undef      NM_STOP_SEC_VAR_POWER_ON_INIT_8
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_8

#elif defined (NM_START_SEC_VAR_CLEARED_16)
   #undef      NM_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (NM_STOP_SEC_VAR_CLEARED_16)
   #undef      NM_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (NM_START_SEC_VAR_POWER_ON_INIT_16)
   #undef      NM_START_SEC_VAR_POWER_ON_INIT_16
   #define DEFAULT_START_SEC_VAR_POWER_ON_INIT_16
#elif defined (NM_STOP_SEC_VAR_POWER_ON_INIT_16)
   #undef      NM_STOP_SEC_VAR_POWER_ON_INIT_16
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_16

#elif defined (NM_START_SEC_CONST_UNSPECIFIED)
   #undef      NM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (NM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      NM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (NM_START_SEC_CODE)
   #undef      NM_START_SEC_CODE
    #define     DEFAULT_START_SEC_CODE
#elif defined (NM_STOP_SEC_CODE)
   #undef      NM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE
/* -------------------------------------------------------------------------- */
/*                 EcuM                                                       */
/* -------------------------------------------------------------------------- */

#elif defined (ECUM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      ECUM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (ECUM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      ECUM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (ECUM_START_SEC_VAR_CLEARED_8)
   #undef      ECUM_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (ECUM_STOP_SEC_VAR_CLEARED_8)
   #undef      ECUM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (ECUM_START_SEC_VAR_CLEARED_32)
   #undef      ECUM_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (ECUM_STOP_SEC_VAR_CLEARED_32)
   #undef      ECUM_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (ECUM_START_SEC_VAR_CLEARED_16)
   #undef      ECUM_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (ECUM_STOP_SEC_VAR_CLEARED_16)
   #undef      ECUM_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (ECUM_START_SEC_VAR_NO_INIT_8)
   #undef      ECUM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (ECUM_STOP_SEC_VAR_NO_INIT_8)
   #undef      ECUM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (ECUM_START_SEC_VAR_POWER_ON_CLEARED_16)
   #undef      ECUM_START_SEC_VAR_POWER_ON_CLEARED_16
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_16
#elif defined (ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_16)
   #undef      ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_16

#elif defined (ECUM_START_SEC_VAR_POWER_ON_CLEARED_32)
   #undef      ECUM_START_SEC_VAR_POWER_ON_CLEARED_32
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_32
#elif defined (ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_32)
   #undef      ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_32

#elif defined (ECUM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
   #undef      ECUM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
#elif defined (ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
   #undef      ECUM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED


#elif defined (ECUM_START_SEC_CONST_32)
   #undef      ECUM_START_SEC_CONST_32
   #define DEFAULT_START_SEC_CONST_32
#elif defined (ECUM_STOP_SEC_CONST_32)
   #undef      ECUM_STOP_SEC_CONST_32
   #define DEFAULT_STOP_SEC_CONST_32


#elif defined (ECUM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      ECUM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (ECUM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      ECUM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (ECUM_START_SEC_CONST_UNSPECIFIED)
   #undef      ECUM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (ECUM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      ECUM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED



#elif defined (ECUM_START_SEC_CODE)
   #undef      ECUM_START_SEC_CODE
     #define     DEFAULT_START_SEC_CODE
#elif defined (ECUM_STOP_SEC_CODE)
   #undef      ECUM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (ECUM_START_SEC_CALLOUT_CODE)
   #undef      ECUM_START_SEC_CALLOUT_CODE
     #define     DEFAULT_START_SEC_CODE
#elif defined (ECUM_STOP_SEC_CALLOUT_CODE)
   #undef      ECUM_STOP_SEC_CALLOUT_CODE
   #define DEFAULT_STOP_SEC_CODE



#elif defined (ECUM_START_SEC_CONST_8)
   #undef      ECUM_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (ECUM_STOP_SEC_CONST_8)
   #undef      ECUM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (ECUM_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      ECUM_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
#elif defined (ECUM_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      ECUM_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED

#elif defined (ECUM_START_SEC_CONFIG_DATA_UNSPECIFIED)
  #undef      ECUM_START_SEC_CONFIG_DATA_UNSPECIFIED
  #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (ECUM_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
  #undef      ECUM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/*                 DBG                                                        */
/* -------------------------------------------------------------------------- */

#elif defined (DBG_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DBG_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (DBG_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DBG_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (DBG_START_SEC_CONST_UNSPECIFIED)
   #undef      DBG_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DBG_STOP_SEC_CONST_UNSPECIFIED)
   #undef      DBG_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DBG_START_SEC_CODE)
   #undef      DBG_START_SEC_CODE
    #define     DEFAULT_START_SEC_CODE
#elif defined (DBG_STOP_SEC_CODE)
   #undef      DBG_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (DBG_START_SEC_VAR_CLEARED_8)
   #undef      DBG_START_SEC_VAR_CLEARED_8
    #define     DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (DBG_STOP_SEC_VAR_CLEARED_8)
   #undef      DBG_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (DBG_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      DBG_START_SEC_VAR_CLEARED_UNSPECIFIED
    #define     DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (DBG_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      DBG_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (DBG_START_SEC_CONST_8)
   #undef      DBG_START_SEC_CONST_8
    #define     DEFAULT_START_SEC_CONST_8
#elif defined (DBG_STOP_SEC_CONST_8)
   #undef      DBG_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (DBG_START_SEC_CONST_16)
   #undef      DBG_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (DBG_STOP_SEC_CONST_16)
   #undef      DBG_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

#elif defined (DBG_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DBG_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (DBG_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DBG_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/*            NVM                                                             */
/* -------------------------------------------------------------------------- */
#elif defined (NVM_START_SEC_CODE)
   #undef      NVM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (NVM_STOP_SEC_CODE)
   #undef      NVM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (NVM_START_SEC_CONST_UNSPECIFIED)
   #undef      NVM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (NVM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      NVM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (NVM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      NVM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (NVM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      NVM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (NVM_START_SEC_VAR_CLEARED_16)
   #undef      NVM_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (NVM_STOP_SEC_VAR_CLEARED_16)
   #undef      NVM_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (NVM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      NVM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (NVM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      NVM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (NVM_START_SEC_VAR_NO_INIT_32)
   #undef      NVM_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (NVM_STOP_SEC_VAR_NO_INIT_32)
   #undef      NVM_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (NVM_START_SEC_VAR_NO_INIT_16)
   #undef      NVM_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (NVM_STOP_SEC_VAR_NO_INIT_16)
   #undef      NVM_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (NVM_START_SEC_VAR_NO_INIT_8)
   #undef      NVM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (NVM_STOP_SEC_VAR_NO_INIT_8)
   #undef      NVM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (NVM_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
   #undef      NVM_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
#elif defined (NVM_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
   #undef      NVM_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN

#elif defined (NVM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
   #undef      NVM_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
#elif defined (NVM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
   #undef      NVM_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED

#elif defined (NVM_START_SEC_VAR_POWER_ON_CLEARED_16)
   #undef      NVM_START_SEC_VAR_POWER_ON_CLEARED_16
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_16
#elif defined (NVM_STOP_SEC_VAR_POWER_ON_CLEARED_16)
   #undef      NVM_STOP_SEC_VAR_POWER_ON_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_16

#elif defined (NVM_START_SEC_VAR_POWER_ON_CLEARED_8)
   #undef      NVM_START_SEC_VAR_POWER_ON_CLEARED_8
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_8
#elif defined (NVM_STOP_SEC_VAR_POWER_ON_CLEARED_8)
   #undef      NVM_STOP_SEC_VAR_POWER_ON_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_8

#elif defined (NVM_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      NVM_START_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (NVM_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      NVM_STOP_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN

#elif defined (NVM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      NVM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (NVM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      NVM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (NVM_START_SEC_CONST_8)
   #undef      NVM_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (NVM_STOP_SEC_CONST_8)
   #undef      NVM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8
   
#elif defined (NVM_START_SEC_CONST_16)
   #undef      NVM_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (NVM_STOP_SEC_CONST_16)
   #undef      NVM_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16
   
#elif defined (NVM_START_SEC_VAR_INIT_8)
   #undef      NVM_START_SEC_VAR_INIT_8
   #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (NVM_STOP_SEC_VAR_INIT_8)
   #undef      NVM_STOP_SEC_VAR_INIT_8
   #define DEFAULT_STOP_SEC_VAR_INIT_8
/* -------------------------------------------------------------------------- */
/*                              Det                                           */
/* -------------------------------------------------------------------------- */
#elif defined (DET_START_SEC_VAR_NO_INIT_16)
   #undef      DET_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (DET_STOP_SEC_VAR_NO_INIT_16)
   #undef      DET_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (DET_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DET_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (DET_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DET_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (DET_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      DET_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (DET_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      DET_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (DET_START_SEC_CONST_UNSPECIFIED)
   #undef      DET_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DET_STOP_SEC_CONST_UNSPECIFIED)
   #undef      DET_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DET_START_SEC_CODE)
   #undef      DET_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (DET_STOP_SEC_CODE)
   #undef      DET_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*             FrTp                                                          */
/* -------------------------------------------------------------------------- */

#elif defined (FRTP_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRTP_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (FRTP_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      FRTP_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (FRTP_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      FRTP_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define FRTP_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (FRTP_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      FRTP_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define FRTP_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (FRTP_START_SEC_VAR_NO_INIT_8)
   #undef      FRTP_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (FRTP_STOP_SEC_VAR_NO_INIT_8)
   #undef      FRTP_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (FRTP_START_SEC_VAR_CLEARED_8)
   #undef      FRTP_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (FRTP_STOP_SEC_VAR_CLEARED_8)
   #undef      FRTP_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (FRTP_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRTP_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (FRTP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      FRTP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (FRTP_START_SEC_VAR_CLEARED_16)
   #undef      FRTP_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (FRTP_STOP_SEC_VAR_CLEARED_16)
   #undef      FRTP_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (FRTP_START_SEC_CONST_8)
   #undef      FRTP_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (FRTP_STOP_SEC_CONST_8)
   #undef      FRTP_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (FRTP_START_SEC_CONST_UNSPECIFIED)
   #undef      FRTP_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRTP_STOP_SEC_CONST_UNSPECIFIED)
   #undef      FRTP_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FRTP_START_SEC_CODE)
   #undef      FRTP_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (FRTP_STOP_SEC_CODE)
   #undef      FRTP_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*                 WDGM                                                       */
/* -------------------------------------------------------------------------- */

#elif defined (WDGM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      WDGM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (WDGM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      WDGM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (WDGM_START_SEC_CONST_UNSPECIFIED)
   #undef      WDGM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (WDGM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      WDGM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (WDGM_START_SEC_CODE)
   #undef      WDGM_START_SEC_CODE
    #define     DEFAULT_START_SEC_CODE
#elif defined (WDGM_STOP_SEC_CODE)
   #undef      WDGM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (WDGM_START_SEC_VAR_CLEARED_8)
   #undef      WDGM_START_SEC_VAR_CLEARED_8
    #define     DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (WDGM_STOP_SEC_VAR_CLEARED_8)
   #undef      WDGM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (WDGM_START_SEC_VAR_CLEARED_16)
   #undef      WDGM_START_SEC_VAR_CLEARED_16
    #define     DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (WDGM_STOP_SEC_VAR_CLEARED_16)
   #undef      WDGM_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (WDGM_START_SEC_VAR_CLEARED_32)
   #undef      WDGM_START_SEC_VAR_CLEARED_32
    #define     DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (WDGM_STOP_SEC_VAR_CLEARED_32)
   #undef      WDGM_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (WDGM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      WDGM_START_SEC_VAR_CLEARED_UNSPECIFIED
    #define     DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (WDGM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      WDGM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (WDGM_START_SEC_CONST_8)
   #undef      WDGM_START_SEC_CONST_8
    #define     DEFAULT_START_SEC_CONST_8
#elif defined (WDGM_STOP_SEC_CONST_8)
   #undef      WDGM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (WDGM_START_SEC_CONST_16)
   #undef      WDGM_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (WDGM_STOP_SEC_CONST_16)
   #undef      WDGM_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

#elif defined (WDGM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      WDGM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (WDGM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      WDGM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/*                 DCM                                                      */
/* -------------------------------------------------------------------------- */
#elif defined (DCM_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
   #undef      DCM_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
#elif defined (DCM_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
   #undef      DCM_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN

#elif defined (DCM_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      DCM_START_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (DCM_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      DCM_STOP_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN

#elif defined (DCM_START_SEC_VAR_NO_INIT_8)
   #undef      DCM_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (DCM_STOP_SEC_VAR_NO_INIT_8)
   #undef      DCM_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (DCM_START_SEC_VAR_NO_INIT_16)
   #undef      DCM_START_SEC_VAR_NO_INIT_16
   #define DEFAULT_START_SEC_VAR_NO_INIT_16
#elif defined (DCM_STOP_SEC_VAR_NO_INIT_16)
   #undef      DCM_STOP_SEC_VAR_NO_INIT_16
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_16

#elif defined (DCM_START_SEC_VAR_NO_INIT_32)
   #undef      DCM_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (DCM_STOP_SEC_VAR_NO_INIT_32)
   #undef      DCM_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (DCM_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DCM_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (DCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (DCM_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DCM_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (DCM_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      DCM_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (DCM_START_SEC_VAR_CLEARED_8)
   #undef      DCM_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (DCM_STOP_SEC_VAR_CLEARED_8)
   #undef      DCM_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (DCM_START_SEC_VAR_CLEARED_16)
   #undef      DCM_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (DCM_STOP_SEC_VAR_CLEARED_16)
   #undef      DCM_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (DCM_START_SEC_VAR_CLEARED_32)
   #undef      DCM_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (DCM_STOP_SEC_VAR_CLEARED_32)
   #undef      DCM_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (DCM_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      DCM_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (DCM_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      DCM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (DCM_START_SEC_VAR_INIT_BOOLEAN)
   #undef      DCM_START_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_INIT_BOOLEAN
#elif defined (DCM_STOP_SEC_VAR_INIT_BOOLEAN)
   #undef      DCM_STOP_SEC_VAR_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_INIT_BOOLEAN

#elif defined (DCM_START_SEC_VAR_INIT_8)
   #undef      DCM_START_SEC_VAR_INIT_8
   #define DEFAULT_START_SEC_VAR_INIT_8
#elif defined (DCM_STOP_SEC_VAR_INIT_8)
   #undef      DCM_STOP_SEC_VAR_INIT_8
   #define DEFAULT_STOP_SEC_VAR_INIT_8

#elif defined (DCM_START_SEC_VAR_INIT_16)
   #undef      DCM_START_SEC_VAR_INIT_16
   #define DEFAULT_START_SEC_VAR_INIT_16
#elif defined (DCM_STOP_SEC_VAR_INIT_16)
   #undef      DCM_STOP_SEC_VAR_INIT_16
   #define DEFAULT_STOP_SEC_VAR_INIT_16

#elif defined (DCM_START_SEC_VAR_INIT_32)
   #undef      DCM_START_SEC_VAR_INIT_32
   #define DEFAULT_START_SEC_VAR_INIT_32
#elif defined (DCM_STOP_SEC_VAR_INIT_32)
   #undef      DCM_STOP_SEC_VAR_INIT_32
   #define DEFAULT_STOP_SEC_VAR_INIT_32

#elif defined (DCM_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      DCM_START_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
#elif defined (DCM_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      DCM_STOP_SEC_VAR_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED

#elif defined (DCM_START_SEC_CONST_BOOLEAN)
   #undef      DCM_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (DCM_STOP_SEC_CONST_BOOLEAN)
   #undef      DCM_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (DCM_START_SEC_CONST_8)
   #undef      DCM_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (DCM_STOP_SEC_CONST_8)
   #undef      DCM_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (DCM_START_SEC_CONST_16)
   #undef      DCM_START_SEC_CONST_16
   #define DEFAULT_START_SEC_CONST_16
#elif defined (DCM_STOP_SEC_CONST_16)
   #undef      DCM_STOP_SEC_CONST_16
   #define DEFAULT_STOP_SEC_CONST_16

#elif defined (DCM_START_SEC_CONST_UNSPECIFIED)
   #undef      DCM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DCM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      DCM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DCM_START_SEC_CODE)
   #undef      DCM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (DCM_STOP_SEC_CODE)
   #undef      DCM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*             Xcp                                                           */
/* -------------------------------------------------------------------------- */
#elif defined (XCP_START_SEC_VAR_CLEARED_8)
   #undef      XCP_START_SEC_VAR_CLEARED_8
   #define DEFAULT_START_SEC_VAR_CLEARED_8
#elif defined (XCP_STOP_SEC_VAR_CLEARED_8)
   #undef      XCP_STOP_SEC_VAR_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_CLEARED_8

#elif defined (XCP_START_SEC_VAR_CLEARED_16)
   #undef      XCP_START_SEC_VAR_CLEARED_16
   #define DEFAULT_START_SEC_VAR_CLEARED_16
#elif defined (XCP_STOP_SEC_VAR_CLEARED_16)
   #undef      XCP_STOP_SEC_VAR_CLEARED_16
   #define DEFAULT_STOP_SEC_VAR_CLEARED_16

#elif defined (XCP_START_SEC_CONST_8)
   #undef      XCP_START_SEC_CONST_8
   #define DEFAULT_START_SEC_CONST_8
#elif defined (XCP_STOP_SEC_CONST_8)
   #undef      XCP_STOP_SEC_CONST_8
   #define DEFAULT_STOP_SEC_CONST_8

#elif defined (XCP_START_SEC_VAR_CLEARED_32)
   #undef      XCP_START_SEC_VAR_CLEARED_32
   #define DEFAULT_START_SEC_VAR_CLEARED_32
#elif defined (XCP_STOP_SEC_VAR_CLEARED_32)
   #undef      XCP_STOP_SEC_VAR_CLEARED_32
   #define DEFAULT_STOP_SEC_VAR_CLEARED_32

#elif defined (XCP_START_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      XCP_START_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
#elif defined (XCP_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
   #undef      XCP_STOP_SEC_VAR_CLEARED_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

#elif defined (XCP_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
   #undef      XCP_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
#elif defined (XCP_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
   #undef      XCP_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN

#elif defined (XCP_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      XCP_START_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
#elif defined (XCP_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      XCP_STOP_SEC_VAR_NO_INIT_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN

#elif defined (XCP_START_SEC_VAR_NO_INIT_8)
   #undef      XCP_START_SEC_VAR_NO_INIT_8
   #define DEFAULT_START_SEC_VAR_NO_INIT_8
#elif defined (XCP_STOP_SEC_VAR_NO_INIT_8)
   #undef      XCP_STOP_SEC_VAR_NO_INIT_8
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (XCP_START_SEC_VAR_NO_INIT_32)
   #undef      XCP_START_SEC_VAR_NO_INIT_32
   #define DEFAULT_START_SEC_VAR_NO_INIT_32
#elif defined (XCP_STOP_SEC_VAR_NO_INIT_32)
   #undef      XCP_STOP_SEC_VAR_NO_INIT_32
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_32

#elif defined (XCP_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      XCP_START_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#elif defined (XCP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      XCP_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (XCP_START_SEC_VAR_CLEARED_BOOLEAN)
   #undef      XCP_START_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
#elif defined (XCP_STOP_SEC_VAR_CLEARED_BOOLEAN)
   #undef      XCP_STOP_SEC_VAR_CLEARED_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

#elif defined (XCP_START_SEC_CONST_UNSPECIFIED)
   #undef      XCP_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (XCP_STOP_SEC_CONST_UNSPECIFIED)
   #undef      XCP_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (XCP_START_SEC_CODE)
   #undef      XCP_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (XCP_STOP_SEC_CODE)
   #undef      XCP_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (XCP_START_SEC_VAR_POWER_ON_CLEARED_8)
   #undef      XCP_START_SEC_VAR_POWER_ON_CLEARED_8
   #define DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_8
#elif defined (XCP_STOP_SEC_VAR_POWER_ON_CLEARED_8)
   #undef      XCP_STOP_SEC_VAR_POWER_ON_CLEARED_8
   #define DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_8
/*************************** Stack section ************************************/

/******************************END*********************************************/
/* -------------------------------------------------------------------------- */
/* End of module section mapping                                              */
/* -------------------------------------------------------------------------- */
#else
  #error "MemMap.h: No valid section define found"
#endif  /* START_WITH_IF */


/*******************************************************************************
**                      Default section mapping                               **
*******************************************************************************/
/* general start of #elif chain whith #if                                     */
#if defined (START_WITH_IF)

/* -------------------------------------------------------------------------- */
/* RAM variables initialized with zero on reset                               */
/* -------------------------------------------------------------------------- */
 #elif defined (DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN)
    #undef      DEFAULT_START_SEC_VAR_CLEARED_BOOLEAN
__attribute__((section(".bss.RAM_CLEARED_1"))) 
 #elif defined (DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN)
    #undef      DEFAULT_STOP_SEC_VAR_CLEARED_BOOLEAN

 #elif defined (DEFAULT_START_SEC_VAR_CLEARED_8)
    #undef      DEFAULT_START_SEC_VAR_CLEARED_8
    #pragma section farbss "RAM_CLEARED_8"
 #elif defined (DEFAULT_STOP_SEC_VAR_CLEARED_8)
    #undef      DEFAULT_STOP_SEC_VAR_CLEARED_8

 #elif defined (DEFAULT_START_SEC_VAR_CLEARED_16)
    #undef      DEFAULT_START_SEC_VAR_CLEARED_16
    #pragma section farbss "RAM_CLEARED_16"
 #elif defined (DEFAULT_STOP_SEC_VAR_CLEARED_16)
    #undef      DEFAULT_STOP_SEC_VAR_CLEARED_16

 #elif defined (DEFAULT_START_SEC_VAR_CLEARED_32)
    #undef      DEFAULT_START_SEC_VAR_CLEARED_32
    #pragma section farbss "RAM_CLEARED_32"
 #elif defined (DEFAULT_STOP_SEC_VAR_CLEARED_32)
    #undef      DEFAULT_STOP_SEC_VAR_CLEARED_32

 #elif defined (DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED)
    #undef      DEFAULT_START_SEC_VAR_CLEARED_UNSPECIFIED
    #pragma section farbss "RAM_CLEARED_UNSPECIFIED"
 #elif defined (DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED)
    #undef      DEFAULT_STOP_SEC_VAR_CLEARED_UNSPECIFIED

 #elif defined (DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
    #undef      DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_BOOLEAN
    #pragma section farbss "RAM_CLEARED_1"
 #elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN)
    #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_BOOLEAN

 #elif defined (DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_8)
    #undef      DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_8
    #pragma section farbss "RAM_CLEARED_8"
 #elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_8)
    #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_8

 #elif defined (DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_16)
    #undef      DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_16
    #pragma section farbss "RAM_CLEARED_16"
 #elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_16)
    #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_16

 #elif defined (DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_32)
    #undef      DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_32
    #pragma section farbss "RAM_CLEARED_32"
 #elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_32)
    #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_32

 #elif defined (DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_START_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED
    #pragma section farbss "RAM_CLEARED_UNSPECIFIED"
  #elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_CLEARED_UNSPECIFIED

  #elif defined (DEFAULT_START_SEC_VAR_FAST_CLEARED_BOOLEAN)
     #undef      DEFAULT_START_SEC_VAR_FAST_CLEARED_BOOLEAN
    #pragma section farbss "RAM_CLEARED_1"
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_CLEARED_BOOLEAN)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_CLEARED_BOOLEAN

  #elif defined (DEFAULT_START_SEC_VAR_FAST_CLEARED_8)
     #undef      DEFAULT_START_SEC_VAR_FAST_CLEARED_8
    #pragma section farbss "RAM_CLEARED_8"
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_CLEARED_8)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_CLEARED_8

  #elif defined (DEFAULT_START_SEC_VAR_FAST_CLEARED_16)
     #undef      DEFAULT_START_SEC_VAR_FAST_CLEARED_16
    #pragma section farbss "RAM_CLEARED_16"
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_CLEARED_16)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_CLEARED_16

  #elif defined (DEFAULT_START_SEC_VAR_FAST_CLEARED_32)
     #undef      DEFAULT_START_SEC_VAR_FAST_CLEARED_32
    #pragma section farbss "RAM_CLEARED_32"
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_CLEARED_32)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_CLEARED_32

  #elif defined (DEFAULT_START_SEC_VAR_FAST_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_START_SEC_VAR_FAST_CLEARED_UNSPECIFIED
    #pragma section farbss "RAM_CLEARED_UNSPECIFIED"
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_CLEARED_UNSPECIFIED

  #elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_BOOLEAN)
     #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_BOOLEAN
    #pragma section farbss "RAM_CLEARED_1"
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_BOOLEAN)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_BOOLEAN

  #elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_8)
     #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_8
    #pragma section farbss "RAM_CLEARED_8"
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_8)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_8

  #elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_16)
     #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_16
    #pragma section farbss "RAM_CLEARED_16"
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_16)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_16

  #elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_32)
     #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_32
    #pragma section farbss "RAM_CLEARED_32"
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_32)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_32

  #elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_CLEARED_UNSPECIFIED
    #pragma section farbss "RAM_CLEARED_UNSPECIFIED"
  #elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_CLEARED_UNSPECIFIED

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_CLEARED_BOOLEAN)
     #undef      DEFAULT_START_SEC_VAR_SLOW_CLEARED_BOOLEAN
    #pragma section farbss "RAM_CLEARED_1"
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_BOOLEAN)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_BOOLEAN

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_CLEARED_8)
     #undef      DEFAULT_START_SEC_VAR_SLOW_CLEARED_8
    #pragma section farbss "RAM_CLEARED_8"
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_8)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_8

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_CLEARED_16)
     #undef      DEFAULT_START_SEC_VAR_SLOW_CLEARED_16
    #pragma section farbss "RAM_CLEARED_16"
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_16)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_16

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_CLEARED_32)
     #undef      DEFAULT_START_SEC_VAR_SLOW_CLEARED_32
    #pragma section farbss "RAM_CLEARED_32"
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_32)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_32

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_START_SEC_VAR_SLOW_CLEARED_UNSPECIFIED
    #pragma section farbss "RAM_CLEARED_UNSPECIFIED"
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_CLEARED_UNSPECIFIED

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_BOOLEAN)
     #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_BOOLEAN
    #pragma section farbss "RAM_CLEARED_1"
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_BOOLEAN)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_BOOLEAN

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_8)
     #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_8
    #pragma section farbss "RAM_CLEARED_8"
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_8)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_8

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_16)
     #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_16
    #pragma section farbss "RAM_CLEARED_16"
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_16)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_16

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_32)
     #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_32
    #pragma section farbss "RAM_CLEARED_32"
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_32)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_32

  #elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_CLEARED_UNSPECIFIED
    #pragma section farbss "RAM_CLEARED_UNSPECIFIED"
  #elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_CLEARED_UNSPECIFIED

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_BOOLEAN)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_BOOLEAN
    #pragma section farbss "RAM_CLEARED_1"
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_BOOLEAN)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_BOOLEAN

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_8)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_8
    #pragma section farbss "RAM_CLEARED_8"
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_8)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_8

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_16)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_16
    #pragma section farbss "RAM_CLEARED_16"
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_16)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_16

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_32)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_32
    #pragma section farbss "RAM_CLEARED_32"
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_32)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_32

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_CLEARED_UNSPECIFIED
    #pragma section farbss "RAM_CLEARED_UNSPECIFIED"
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_CLEARED_UNSPECIFIED

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_BOOLEAN)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_BOOLEAN
    #pragma section farbss "RAM_CLEARED_1"
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_BOOLEAN)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_BOOLEAN

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_8)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_8
    #pragma section farbss "RAM_CLEARED_8"
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_8)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_8

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_16)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_16
    #pragma section farbss "RAM_CLEARED_16"
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_16)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_16

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_32)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_32
    #pragma section farbss "RAM_CLEARED_32"
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_32)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_32

  #elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_CLEARED_UNSPECIFIED
    #pragma section farbss "RAM_CLEARED_UNSPECIFIED"
  #elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_UNSPECIFIED)
     #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_CLEARED_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/* RAM variables initialized                                                  */
/* -------------------------------------------------------------------------- */

#elif defined (DEFAULT_START_SEC_VAR_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_INIT_BOOLEAN
   #pragma section fardata "RAM_INIT_1"
#elif defined (DEFAULT_STOP_SEC_VAR_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_INIT_8
   #pragma section fardata "RAM_INIT_8"
#elif defined (DEFAULT_STOP_SEC_VAR_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_INIT_8


#elif defined (DEFAULT_START_SEC_VAR_INIT_16)
   #undef      DEFAULT_START_SEC_VAR_INIT_16
   #pragma section fardata "RAM_INIT_16"
#elif defined (DEFAULT_STOP_SEC_VAR_INIT_16)
   #undef      DEFAULT_STOP_SEC_VAR_INIT_16


#elif defined (DEFAULT_START_SEC_VAR_INIT_32)
   #undef      DEFAULT_START_SEC_VAR_INIT_32
   #pragma section fardata "RAM_INIT_32"
#elif defined (DEFAULT_STOP_SEC_VAR_INIT_32)
   #undef      DEFAULT_STOP_SEC_VAR_INIT_32


#elif defined (DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_INIT_UNSPECIFIED
   #pragma section fardata "RAM_INIT_UNSPECIFIED"
#elif defined (DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_INIT_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_VAR_POWER_ON_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_POWER_ON_INIT_BOOLEAN
   #pragma section fardata "RAM_INIT_1"
#elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_POWER_ON_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_POWER_ON_INIT_8
   #pragma section fardata "RAM_INIT_8"
#elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_8


#elif defined (DEFAULT_START_SEC_VAR_POWER_ON_INIT_16)
   #undef      DEFAULT_START_SEC_VAR_POWER_ON_INIT_16
   #pragma section fardata "RAM_INIT_16"
#elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_16)
   #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_16


#elif defined (DEFAULT_START_SEC_VAR_POWER_ON_INIT_32)
   #undef      DEFAULT_START_SEC_VAR_POWER_ON_INIT_32
   #pragma section fardata "RAM_INIT_32"
#elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_32)
   #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_32


#elif defined (DEFAULT_START_SEC_VAR_POWER_ON_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_POWER_ON_INIT_UNSPECIFIED
   #pragma section fardata "RAM_INIT_UNSPECIFIED"
#elif defined (DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_POWER_ON_INIT_UNSPECIFIED

#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_INIT_BOOLEAN
   #pragma section fardata "RAM_INIT_1"
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_INIT_8)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_INIT_8
   #pragma section fardata "RAM_INIT_8"
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_8)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_8


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_INIT_16)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_INIT_16
   #pragma section fardata "RAM_INIT_16"
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_16)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_16


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_INIT_32)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_INIT_32
   #pragma section fardata "RAM_INIT_32"
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_32)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_32


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_INIT_UNSPECIFIED
   #pragma section fardata "RAM_INIT_UNSPECIFIED"
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_INIT_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_BOOLEAN
   #pragma section fardata "RAM_INIT_1"
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_8)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_8
   #pragma section fardata "RAM_INIT_8"
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_8)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_8


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_16)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_16
   #pragma section fardata "RAM_INIT_16"
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_16)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_16


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_32)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_32
   #pragma section fardata "RAM_INIT_32"
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_32)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_32


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_POWER_ON_INIT_UNSPECIFIED
   #pragma section fardata "RAM_INIT_UNSPECIFIED"
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_POWER_ON_INIT_UNSPECIFIED

#elif defined (DEFAULT_START_SEC_VAR_FAST_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_FAST_INIT_BOOLEAN
   #pragma section fardata "RAM_INIT_1"
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_FAST_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_FAST_INIT_8
   #pragma section fardata "RAM_INIT_8"
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_INIT_8


#elif defined (DEFAULT_START_SEC_VAR_FAST_INIT_16)
   #undef      DEFAULT_START_SEC_VAR_FAST_INIT_16
   #pragma section fardata "RAM_INIT_16"
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_INIT_16)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_INIT_16


#elif defined (DEFAULT_START_SEC_VAR_FAST_INIT_32)
   #undef      DEFAULT_START_SEC_VAR_FAST_INIT_32
   #pragma section fardata "RAM_INIT_32"
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_INIT_32)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_INIT_32


#elif defined (DEFAULT_START_SEC_VAR_FAST_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_FAST_INIT_UNSPECIFIED
   #pragma section fardata "RAM_INIT_UNSPECIFIED"
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_INIT_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_BOOLEAN
   #pragma section fardata "RAM_INIT_1"
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_8
   #pragma section fardata "RAM_INIT_8"
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_8


#elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_16)
   #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_16
   #pragma section fardata "RAM_INIT_16"
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_16)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_16


#elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_32)
   #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_32
   #pragma section fardata "RAM_INIT_32"
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_32)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_32


#elif defined (DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_FAST_POWER_ON_INIT_UNSPECIFIED
   #pragma section fardata "RAM_INIT_UNSPECIFIED"
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_POWER_ON_INIT_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_VAR_SLOW_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_SLOW_INIT_BOOLEAN
   #pragma section fardata "RAM_INIT_1"
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_SLOW_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_SLOW_INIT_8
   #pragma section fardata "RAM_INIT_8"
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_INIT_8


#elif defined (DEFAULT_START_SEC_VAR_SLOW_INIT_16)
   #undef      DEFAULT_START_SEC_VAR_SLOW_INIT_16
   #pragma section fardata "RAM_INIT_16"
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_INIT_16)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_INIT_16


#elif defined (DEFAULT_START_SEC_VAR_SLOW_INIT_32)
   #undef      DEFAULT_START_SEC_VAR_SLOW_INIT_32
   #pragma section fardata "RAM_INIT_32"
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_INIT_32)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_INIT_32


#elif defined (DEFAULT_START_SEC_VAR_SLOW_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_SLOW_INIT_UNSPECIFIED
   #pragma section fardata "RAM_INIT_UNSPECIFIED"
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_INIT_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_BOOLEAN
   #pragma section fardata "RAM_INIT_1"
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_8
   #pragma section fardata "RAM_INIT_8"
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_8


#elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_16)
   #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_16
   #pragma section fardata "RAM_INIT_16"
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_16)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_16


#elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_32)
   #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_32
   #pragma section fardata "RAM_INIT_32"
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_32)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_32


#elif defined (DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_SLOW_POWER_ON_INIT_UNSPECIFIED
   #pragma section fardata "RAM_INIT_UNSPECIFIED"
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_POWER_ON_INIT_UNSPECIFIED


/*----------------------------------------------------------------------------*/
/*                                    APPL RAM DATA                           */
/*----------------------------------------------------------------------------*/

/* -------------------------------------------------------------------------- */
/* RAM variables not initialized                                              */
/* -------------------------------------------------------------------------- */

#elif defined (DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_NO_INIT_BOOLEAN
    #pragma section farnoclear "NOINIT_RAM_1"
#elif defined (DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_NO_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_NO_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_NO_INIT_8
__attribute__((section(".bss.NOINIT_RAM_8"))) 
    #pragma section farnoclear "NOINIT_RAM_8"
#elif defined (DEFAULT_STOP_SEC_VAR_NO_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_NO_INIT_8


#elif defined (DEFAULT_START_SEC_VAR_NO_INIT_16)
   #undef      DEFAULT_START_SEC_VAR_NO_INIT_16
    #pragma section farnoclear "NOINIT_RAM_16"
#elif defined (DEFAULT_STOP_SEC_VAR_NO_INIT_16)
   #undef      DEFAULT_STOP_SEC_VAR_NO_INIT_16


#elif defined (DEFAULT_START_SEC_VAR_NO_INIT_32)
   #undef      DEFAULT_START_SEC_VAR_NO_INIT_32
    #pragma section farnoclear "NOINIT_RAM_32"
#elif defined (DEFAULT_STOP_SEC_VAR_NO_INIT_32)
   #undef      DEFAULT_STOP_SEC_VAR_NO_INIT_32


#elif defined (DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_NO_INIT_UNSPECIFIED
    #pragma section farnoclear "NOINIT_RAM_UNSPECIFIED"
#elif defined (DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED

#elif defined (DEFAULT_START_SEC_VAR_SLOW_NO_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_SLOW_NO_INIT_BOOLEAN
    #pragma section farnoclear "NOINIT_RAM_1"
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_SLOW_NO_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_SLOW_NO_INIT_8
    #pragma section farnoclear "NOINIT_RAM_8"
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_8


#elif defined (DEFAULT_START_SEC_VAR_SLOW_NO_INIT_16)
   #undef      DEFAULT_START_SEC_VAR_SLOW_NO_INIT_16
    #pragma section farnoclear "NOINIT_RAM_16"
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_16)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_16


#elif defined (DEFAULT_START_SEC_VAR_SLOW_NO_INIT_32)
   #undef      DEFAULT_START_SEC_VAR_SLOW_NO_INIT_32
    #pragma section farnoclear "NOINIT_RAM_32"
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_32)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_32


#elif defined (DEFAULT_START_SEC_VAR_SLOW_NO_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_SLOW_NO_INIT_UNSPECIFIED
    #pragma section farnoclear "NOINIT_RAM_UNSPECIFIED"
#elif defined (DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_SLOW_NO_INIT_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_BOOLEAN
    #pragma section farnoclear "NOINIT_RAM_1"
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_8)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_8
    #pragma section farnoclear "NOINIT_RAM_8"
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_8)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_8

#elif defined (DEFAULT_START_SEC_VAR_NO_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_NO_INIT_8
    #pragma section farnoclear "NOINIT_RAM_8"
#elif defined (DEFAULT_STOP_SEC_VAR_NO_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_NO_INIT_8

#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_16)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_16
    #pragma section farnoclear "NOINIT_RAM_16"
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_16)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_16


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_32)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_32
    #pragma section farnoclear "NOINIT_RAM_32"
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_32)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_32


#elif defined (DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_INTERNAL_VAR_NO_INIT_UNSPECIFIED
    #pragma section farnoclear "NOINIT_RAM_UNSPECIFIED"
#elif defined (DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_INTERNAL_VAR_NO_INIT_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_VAR_FAST_NO_INIT_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_FAST_NO_INIT_BOOLEAN
    #pragma section farnoclear "NOINIT_RAM_1"
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_FAST_NO_INIT_8)
   #undef      DEFAULT_START_SEC_VAR_FAST_NO_INIT_8
    #pragma section farnoclear "NOINIT_RAM_8"
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_8)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_8


#elif defined (DEFAULT_START_SEC_VAR_FAST_NO_INIT_16)
   #undef      DEFAULT_START_SEC_VAR_FAST_NO_INIT_16
    #pragma section farnoclear "NOINIT_RAM_16"
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_16)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_16


#elif defined (DEFAULT_START_SEC_VAR_FAST_NO_INIT_32)
   #undef      DEFAULT_START_SEC_VAR_FAST_NO_INIT_32
    #pragma section farnoclear "NOINIT_RAM_32"
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_32)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_32


#elif defined (DEFAULT_START_SEC_VAR_FAST_NO_INIT_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_FAST_NO_INIT_UNSPECIFIED
    #pragma section farnoclear "NOINIT_RAM_UNSPECIFIED"
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_FAST_NO_INIT_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_VAR_SAVED_ZONE_BOOLEAN)
   #undef      DEFAULT_START_SEC_VAR_SAVED_ZONE_BOOLEAN
    #pragma section farnoclear "NOINIT_RAM_1"
#elif defined (DEFAULT_STOP_SEC_VAR_SAVED_ZONE_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_VAR_SAVED_ZONE_BOOLEAN


#elif defined (DEFAULT_START_SEC_VAR_SAVED_ZONE_8)
   #undef      DEFAULT_START_SEC_VAR_SAVED_ZONE_8
    #pragma section farnoclear "NOINIT_RAM_8"
#elif defined (DEFAULT_STOP_SEC_VAR_SAVED_ZONE_8)
   #undef      DEFAULT_STOP_SEC_VAR_SAVED_ZONE_8


#elif defined (DEFAULT_START_SEC_VAR_SAVED_ZONE_16)
   #undef      DEFAULT_START_SEC_VAR_SAVED_ZONE_16
    #pragma section farnoclear "NOINIT_RAM_16"
#elif defined (DEFAULT_STOP_SEC_VAR_SAVED_ZONE_16)
   #undef      DEFAULT_STOP_SEC_VAR_SAVED_ZONE_16


#elif defined (DEFAULT_START_SEC_VAR_SAVED_ZONE_32)
   #undef      DEFAULT_START_SEC_VAR_SAVED_ZONE_32
    #pragma section farnoclear "NOINIT_RAM_32"
#elif defined (DEFAULT_STOP_SEC_VAR_SAVED_ZONE_32)
   #undef      DEFAULT_STOP_SEC_VAR_SAVED_ZONE_32


#elif defined (DEFAULT_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_VAR_SAVED_ZONE_UNSPECIFIED
    #pragma section farnoclear "NOINIT_RAM_UNSPECIFIED"
#elif defined (DEFAULT_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_VAR_SAVED_ZONE_UNSPECIFIED


/* -------------------------------------------------------------------------- */
/* ROM constants                                                              */
/* -------------------------------------------------------------------------- */

#elif defined (DEFAULT_START_SEC_CONST_BOOLEAN)
   #undef      DEFAULT_START_SEC_CONST_BOOLEAN
#pragma section farrom "CONST_ROM_1"
#elif defined (DEFAULT_STOP_SEC_CONST_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_CONST_BOOLEAN


#elif defined (DEFAULT_START_SEC_CONST_8)
   #undef      DEFAULT_START_SEC_CONST_8
  #pragma section farrom "CONST_ROM_8"
#elif defined (DEFAULT_STOP_SEC_CONST_8)
   #undef      DEFAULT_STOP_SEC_CONST_8


#elif defined (DEFAULT_START_SEC_CONST_16)
   #undef      DEFAULT_START_SEC_CONST_16
  #pragma section farrom "CONST_ROM_16"
#elif defined (DEFAULT_STOP_SEC_CONST_16)
   #undef      DEFAULT_STOP_SEC_CONST_16


#elif defined (DEFAULT_START_SEC_CONST_32)
   #undef      DEFAULT_START_SEC_CONST_32
  #pragma section farrom "CONST_ROM_32"
#elif defined (DEFAULT_STOP_SEC_CONST_32)
   #undef      DEFAULT_STOP_SEC_CONST_32


#elif defined (DEFAULT_START_SEC_CONST_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_CONST_UNSPECIFIED
  #pragma section farrom "CONST_ROM_UNSPECIFIED"
#elif defined (DEFAULT_STOP_SEC_CONST_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_CONST_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_CALIB_BOOLEAN)
   #undef      DEFAULT_START_SEC_CALIB_BOOLEAN
#pragma section farrom "CONST_ROM_1"
#elif defined (DEFAULT_STOP_SEC_CALIB_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_CALIB_BOOLEAN


#elif defined (DEFAULT_START_SEC_CALIB_8)
   #undef      DEFAULT_START_SEC_CALIB_8
  #pragma section farrom "CONST_ROM_8"
#elif defined (DEFAULT_STOP_SEC_CALIB_8)
   #undef      DEFAULT_STOP_SEC_CALIB_8


#elif defined (DEFAULT_START_SEC_CALIB_16)
   #undef      DEFAULT_START_SEC_CALIB_16
  #pragma section farrom "CONST_ROM_16"
#elif defined (DEFAULT_STOP_SEC_CALIB_16)
   #undef      DEFAULT_STOP_SEC_CALIB_16


#elif defined (DEFAULT_START_SEC_CALIB_32)
   #undef      DEFAULT_START_SEC_CALIB_32
  #pragma section farrom "CONST_ROM_32"
#elif defined (DEFAULT_STOP_SEC_CALIB_32)
   #undef      DEFAULT_STOP_SEC_CALIB_32


#elif defined (DEFAULT_START_SEC_CALIB_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_CALIB_UNSPECIFIED
  #pragma section farrom "CONST_ROM_UNSPECIFIED"
#elif defined (DEFAULT_STOP_SEC_CALIB_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_CALIB_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_CARTO_BOOLEAN)
   #undef      DEFAULT_START_SEC_CARTO_BOOLEAN
#pragma section farrom "CONST_ROM_1"
#elif defined (DEFAULT_STOP_SEC_CARTO_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_CARTO_BOOLEAN


#elif defined (DEFAULT_START_SEC_CARTO_8)
   #undef      DEFAULT_START_SEC_CARTO_8
  #pragma section farrom "CONST_ROM_8"
#elif defined (DEFAULT_STOP_SEC_CARTO_8)
   #undef      DEFAULT_STOP_SEC_CARTO_8


#elif defined (DEFAULT_START_SEC_CARTO_16)
   #undef      DEFAULT_START_SEC_CARTO_16
  #pragma section farrom "CONST_ROM_16"
#elif defined (DEFAULT_STOP_SEC_CARTO_16)
   #undef      DEFAULT_STOP_SEC_CARTO_16


#elif defined (DEFAULT_START_SEC_CARTO_32)
   #undef      DEFAULT_START_SEC_CARTO_32
  #pragma section farrom "CONST_ROM_32"
#elif defined (DEFAULT_STOP_SEC_CARTO_32)
   #undef      DEFAULT_STOP_SEC_CARTO_32


#elif defined (DEFAULT_START_SEC_CARTO_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_CARTO_UNSPECIFIED
  #pragma section farrom "CONST_ROM_UNSPECIFIED"
#elif defined (DEFAULT_STOP_SEC_CARTO_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_CARTO_UNSPECIFIED



#elif defined (DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN)
   #undef      DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
#pragma section farrom "CONST_ROM_1"
#elif defined (DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN

#elif defined (DEFAULT_START_SEC_CONFIG_DATA_8)
   #undef      DEFAULT_START_SEC_CONFIG_DATA_8
  #pragma section farrom "CONST_ROM_8"
#elif defined (DEFAULT_STOP_SEC_CONFIG_DATA_8)
   #undef      DEFAULT_STOP_SEC_CONFIG_DATA_8


#elif defined (DEFAULT_START_SEC_CONFIG_DATA_16)
   #undef      DEFAULT_START_SEC_CONFIG_DATA_16
  #pragma section farrom "CONST_ROM_16"
#elif defined (DEFAULT_STOP_SEC_CONFIG_DATA_16)
   #undef      DEFAULT_STOP_SEC_CONFIG_DATA_16


#elif defined (DEFAULT_START_SEC_CONFIG_DATA_32)
   #undef      DEFAULT_START_SEC_CONFIG_DATA_32
  #pragma section farrom "CONST_ROM_32"
#elif defined (DEFAULT_STOP_SEC_CONFIG_DATA_32)
   #undef      DEFAULT_STOP_SEC_CONFIG_DATA_32


#elif defined (DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
  #pragma section farrom "CONST_ROM_UNSPECIFIED"
#elif defined (DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED


#elif defined (DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_BOOLEAN)
   #undef      DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_BOOLEAN
#pragma section farrom "CONST_ROM_1"
#elif defined (DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_BOOLEAN)
   #undef      DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_BOOLEAN


#elif defined (DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_8)
   #undef      DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_8
  #pragma section farrom "CONST_ROM_8"
#elif defined (DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_8)
   #undef      DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_8


#elif defined (DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_16)
   #undef      DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_16
  #pragma section farrom "CONST_ROM_16"
#elif defined (DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_16)
   #undef      DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_16


#elif defined (DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_32)
   #undef      DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_32
  #pragma section farrom "CONST_ROM_32"
#elif defined (DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_32)
   #undef      DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_32


#elif defined (DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_UNSPECIFIED)
   #undef      DEFAULT_START_SEC_CONST_SAVED_RECOVERY_ZONE_UNSPECIFIED
  #pragma section farrom "CONST_ROM_UNSPECIFIED"
#elif defined (DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_UNSPECIFIED)
   #undef      DEFAULT_STOP_SEC_CONST_SAVED_RECOVERY_ZONE_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/* ROM code                                                                   */
/* -------------------------------------------------------------------------- */
#elif defined (DEFAULT_START_SEC_CODE)
   #undef      DEFAULT_START_SEC_CODE
    #pragma section code "DEFAULT_CODE"
#elif defined (DEFAULT_STOP_SEC_CODE)
   #undef      DEFAULT_STOP_SEC_CODE


#elif defined (DEFAULT_START_SEC_CALLOUT_CODE)
   #undef      DEFAULT_START_SEC_CALLOUT_CODE
    #pragma section code "DEFAULT_CALLOUT_CODE"
#elif defined (DEFAULT_STOP_SEC_CALLOUT_CODE)
   #undef      DEFAULT_STOP_SEC_CALLOUT_CODE


#elif defined (DEFAULT_START_SEC_CODE_FAST)
   #undef      DEFAULT_START_SEC_CODE_FAST
    #pragma section code "DEFAULT_FAST_CODE"
#elif defined (DEFAULT_STOP_SEC_CODE_FAST)
   #undef      DEFAULT_STOP_SEC_CODE_FAST


#elif defined (DEFAULT_START_SEC_CODE_SLOW)
   #undef      DEFAULT_START_SEC_CODE_SLOW
  #pragma section code "DEFAULT_SLOW_CODE"
#elif defined (DEFAULT_STOP_SEC_CODE_SLOW)
   #undef      DEFAULT_STOP_SEC_CODE_SLOW


#elif defined (DEFAULT_START_SEC_CODE_LIB)
   #undef      DEFAULT_START_SEC_CODE_LIB
  #pragma section code "DEFAULT_LIB_CODE"
#elif defined (DEFAULT_STOP_SEC_CODE_LIB)
   #undef      DEFAULT_STOP_SEC_CODE_LIB


   
/* ---------------------------------------------------------------------------*/
/* End of default section mapping                                             */
/* ---------------------------------------------------------------------------*/

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#endif  /* START_WITH_IF */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
