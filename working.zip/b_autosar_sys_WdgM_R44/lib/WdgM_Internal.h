/*******************************************************************************
**                                                                            **
**  (C) 2019 HYUNDAI AUTRON Co., Ltd.                                         **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: WdgM_Internal.h                                               **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR WDGM                                                  **
**                                                                            **
**  PURPOSE   : Provision of Prototypes of WdgM module internal functions     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     16-Sep-2019   ThanhNT      Initial version                       **
*******************************************************************************/

/*******************************************************************************
**              PRE-JUSTIFICATION BEGIN (MISRA-C RULE CHECKER)                **
*******************************************************************************/
/* polyspace-begin MISRA-C3:20.1 [Not a Defect] "see MEMMAP003 of AUTOSAR" */

#ifndef WDGM_INTERNAL_H
#define WDGM_INTERNAL_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "WdgM_Types.h"               /* WdgM Types Header file */


/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
#define WDGM_INTERNAL_H_AR_RELEASE_MAJOR_VERSION 0x4u
#define WDGM_INTERNAL_H_AR_RELEASE_MINOR_VERSION 0x4u
#define WDGM_INTERNAL_H_AR_RELEASE_REVISION_VERSION 0x0u
#define WDGM_INTERNAL_H_SW_MAJOR_VERSION 0x1u
#define WDGM_INTERNAL_H_SW_MINOR_VERSION 0x0u
#define WDGM_INTERNAL_H_SW_PATCH_VERSION 0x0u

/*******************************************************************************
**                      File version check                                    **
*******************************************************************************/
#if  ((WDGM_INTERNAL_H_SW_MAJOR_VERSION != WDGM_TYPES_H_SW_MAJOR_VERSION) || \
    (WDGM_INTERNAL_H_SW_MINOR_VERSION != WDGM_TYPES_H_SW_MINOR_VERSION) || \
    (WDGM_INTERNAL_H_SW_PATCH_VERSION != WDGM_TYPES_H_SW_PATCH_VERSION))
#error "Mismatch Sofware Version between WdgM_Internal.h and WdgM_Types.h"
#endif

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#define WDGM_START_SEC_CODE
#include "MemMap.h"
/* polyspace-begin MISRA-C3:20.7 [Not a Defect] 
                                     "below macro does not affect the result" */
extern FUNC(P2CONST(WdgM_ActiveSEType, AUTOMATIC, WDGM_CONST), WDGM_CODE)
  WdgM_SEIDBinarySearch(WdgM_SupervisedEntityIdType ddSEID);
/* polyspace-end MISRA-C3:20.7 */
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"

#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(boolean, WDGM_CODE) WdgM_SEIndexBinarySearch(
  WdgM_SupervisedEntityIdType ddSEID,
  P2VAR(WdgM_SupervisedEntityIndexType, AUTOMATIC, WDGM_DATA) pSEIndex);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"

#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(boolean, WDGM_CODE) WdgM_InternalSetMode(WdgM_ModeType ddMode);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"

#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(void, WDGM_CODE) WdgM_TriggerWdgIf(
  P2CONST(WdgM_ModePropertyType, AUTOMATIC, WDGM_CONST) pMode,
  WdgM_TriggerModeType ddTriggerMode);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"

#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(void, WDGM_CODE) WdgM_ClearActivityFlag(
  P2CONST(WdgM_ModePropertyType, AUTOMATIC, WDGM_CONST) pCurrentMode);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"

#if(WDGM_ENABLE_ALIVE_SUPERVISION == STD_ON)
#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(void, WDGM_CODE) WdgM_PerformAliveIndication(
  WdgM_SupervisedEntityIdType ddSEID, WdgM_CheckpointIdType ddCheckpointID);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"

#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(void, WDGM_CODE) WdgM_PerformAliveSupervision(void);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"
#endif

#if(WDGM_ENABLE_DEADLINE_SUPERVISION == STD_ON)
#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(void, WDGM_CODE) WdgM_PerformDeadlineSupervision(
  WdgM_SupervisedEntityIdType ddSEID, WdgM_CheckpointIdType ddCheckpointID,
  WdgM_SupervisedEntityIndexType ddSEArrayIndex);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"
#endif

#if(WDGM_ENABLE_INTERNAL_TRANSITION == STD_ON)
#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(void, WDGM_CODE) WdgM_PerformIntLogicalSupervision(
  WdgM_CheckpointIdType ddCheckpointID,
  WdgM_SupervisedEntityIndexType ddSEArrayIndex);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"
#endif

#if(WDGM_ENABLE_EXTERNAL_TRANSITION == STD_ON)
#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(void, WDGM_CODE) WdgM_PerformExtLogicalSupervision(
  WdgM_SupervisedEntityIdType ddSEID, WdgM_CheckpointIdType ddCheckpointID,
  WdgM_SupervisedEntityIndexType ddSEArrayIndex);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"
#endif

#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(void, WDGM_CODE) WdgM_EvaluateLocalStatus(
  P2VAR(boolean, AUTOMATIC, WDGM_DATA) pSEFailedFlag,
  P2VAR(boolean, AUTOMATIC, WDGM_DATA) pSEExpiredFlag);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"

#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(void, WDGM_CODE) WdgM_EvaluateGlobalStatus(
  boolean blSEFailedFlag, boolean blSEExpiredFlag);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"

#if WDGM_PRECOMPILE_ENABLED == STD_OFF
#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(boolean, WDGM_CODE) WdgM_ValidateConfig(
  CONST(uint8, AUTOMATIC) ddServiceId,
  P2CONST(WdgM_ConfigType, WDGM_CONST, WDGM_CONST) pConfigPtr);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"
#endif

#endif /* WDGM_INTERNAL_H */

/*******************************************************************************
**               PRE-JUSTIFICATION END (MISRA-C RULE CHECKER)                 **
*******************************************************************************/
/* polyspace-end MISRA-C3:20.1 */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
