/*******************************************************************************
**                                                                            **
**  (C) 2019 HYUNDAI AUTRON Co., Ltd.                                         **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: WdgM.h                                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR WDGM                                                  **
**                                                                            **
**  PURPOSE   : Header file to publish Watchdog Manager function prototypes   **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     16-Sep-2019   ThanhNT      Initial version                       **
** 1.0.1     23-Sep-2019   ThanhNT      Added function prototypes             **
*******************************************************************************/

/*******************************************************************************
**              PRE-JUSTIFICATION BEGIN (MISRA-C RULE CHECKER)                **
*******************************************************************************/
/* polyspace-begin MISRA-C3:20.1 [Not a Defect] "see MEMMAP003 of AUTOSAR" */

#ifndef WDGM_H
#define WDGM_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "WdgM_Types.h"               /* WdgM Types Header file */
#include "WdgM_Ram.h"                 /* WdgM Ram header file */
#include "Std_Types.h"                /* Standars types Header file */

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
#define WDGM_H_AR_RELEASE_MAJOR_VERSION 0x4u
#define WDGM_H_AR_RELEASE_MINOR_VERSION 0x4u
#define WDGM_H_AR_RELEASE_REVISION_VERSION 0x0u
#define WDGM_H_SW_MAJOR_VERSION 0x1u
#define WDGM_H_SW_MINOR_VERSION 0x0u
#define WDGM_H_SW_PATCH_VERSION 0x0u

/*******************************************************************************
**                      File version check                                    **
*******************************************************************************/
#if  ((WDGM_H_SW_MAJOR_VERSION != WDGM_TYPES_H_SW_MAJOR_VERSION) || \
    (WDGM_H_SW_MINOR_VERSION != WDGM_TYPES_H_SW_MINOR_VERSION) || \
    (WDGM_H_SW_PATCH_VERSION != WDGM_TYPES_H_SW_PATCH_VERSION))
#error "Mismatch Sofware Version between WdgM.h and WdgM_Types.h"
#endif

#if  ((WDGM_H_AR_RELEASE_MAJOR_VERSION != STD_AR_RELEASE_MAJOR_VERSION) || \
    (WDGM_H_AR_RELEASE_MINOR_VERSION != STD_AR_RELEASE_MINOR_VERSION))
#error "Mismatch Autosar Version between WdgM.h and Std_Types.h"
#endif
/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
#define WDGM_UNINITIALIZED                        ((boolean)0x00)
#define WDGM_INITIALIZED                          ((boolean)0x01)

/*******************************************************************************
**                      Service IDs                                           **
*******************************************************************************/
/* polyspace-begin MISRA-C3:2.5 [Not a Defect] 
                              "macro is used according to user configuration" */
/* Service Id of WdgM_Init */
#define WDGM_INIT_SID                             ((uint8)0x00)
/* Service Id of WdgM_DeInit */
#define WDGM_DEINIT_SID                           ((uint8)0x01)
/* Service Id of WdgM_GetVersionInfo */
#define WDGM_GETVERSIONINFO_SID                   ((uint8)0x02)
/* Service Id of WdgM_SetMode */
#define WDGM_SETMODE_SID                          ((uint8)0x03)
/* Service Id of WdgM_GetMode */
#define WDGM_GETMODE_SID                          ((uint8)0x0b)
/* Service Id of WdgM_CheckpointReached */
#define WDGM_CHECKPOINTREACHED_SID                ((uint8)0x0e)
/* Service Id of WdgM_GetAliveSupevisionStatus */
#define WDGM_GETLOCALSTATUS_SID                   ((uint8)0x0c)
/* Service Id of WdgM_GetGlobalStatus */
#define WDGM_GETGLOBALSTATUS_SID                  ((uint8)0x0d)
/* Service Id of WdgM_GetGlobalStatus */
#define WDGM_PERFORMRESET_SID                     ((uint8)0x0f)
/* Service Id of WdgM_GetFirstExpiredSEID */
#define WDGM_GETFIRSTEXPIRED_SEID_SID             ((uint8)0x10)
/* Service Id of WdgM_Mainfunction */
#define WDGM_MAINFUNCTION_SID                     ((uint8)0x08)
/* polyspace-end MISRA-C3:2.5 */

/*******************************************************************************
**                                  Macros                                    **
*******************************************************************************/
/* polyspace-begin MISRA-C3:D4.9 [Not a Defect] 
                                    "macro is used for improving performance" */
/* polyspace-begin MISRA-C3:2.5 [Not a Defect] 
                              "macro is used according to user configuration" */
/* avoid violation of unused varialbe */
#define WDGM_UNUSED(x)                   if((uint32)(x) != (uint32)WDGM_ZERO) {}

/* avoid violation of unused pointere */
#define WDGM_UNUSED_PTR(x)               if((x) != NULL_PTR) {}
/* polyspace-end MISRA-C3:D4.9 */
/* polyspace-end<MISRA-C3:2.5 */

/*******************************************************************************
**                         Global Data Types                                  **
*******************************************************************************/

/*******************************************************************************
**                       Function Prototypes                                  **
*******************************************************************************/
#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(void, WDGM_CODE) WdgM_Init
  (P2CONST(WdgM_ConfigType, AUTOMATIC, WDGM_APPL_CONST) pConfigPtr);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"

#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(void, WDGM_CODE) WdgM_DeInit(void);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"

#if(WDGM_VERSION_INFO_API == STD_ON)
#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(void, WDGM_CODE) WdgM_GetVersionInfo(
  P2VAR(Std_VersionInfoType, AUTOMATIC, WDGM_APPL_DATA) pVersionInfo);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"
#endif

#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(Std_ReturnType, WDGM_CODE) WdgM_SetMode(
  WdgM_ModeType ddMode);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"

#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(Std_ReturnType, WDGM_CODE) WdgM_GetMode(
  P2VAR(WdgM_ModeType, WDGM_DATA, WDGM_APPL_DATA) pMode);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"

#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(Std_ReturnType, WDGM_CODE) WdgM_CheckpointReached(
  WdgM_SupervisedEntityIdType ddSEID, WdgM_CheckpointIdType ddCheckpointID);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"

#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(Std_ReturnType, WDGM_CODE) WdgM_GetLocalStatus(
  WdgM_SupervisedEntityIdType ddSEID,
  P2VAR(WdgM_LocalStatusType, WDGM_DATA, WDGM_APPL_DATA) pStatus);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"

#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(Std_ReturnType, WDGM_CODE) WdgM_GetGlobalStatus
  (P2VAR(WdgM_GlobalStatusType, WDGM_DATA, WDGM_APPL_DATA) pStatus);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"

#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(void, WDGM_CODE) WdgM_PerformReset(void);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"

#define WDGM_START_SEC_CODE
#include "MemMap.h"
extern FUNC(Std_ReturnType, WDGM_CODE) WdgM_GetFirstExpiredSEID(
  P2VAR(WdgM_SupervisedEntityIdType, WDGM_DATA, WDGM_APPL_DATA) pSEID);
#define WDGM_STOP_SEC_CODE
#include "MemMap.h"

#endif /* WDGM_H */

/*******************************************************************************
**               PRE-JUSTIFICATION END (MISRA-C RULE CHECKER)                 **
*******************************************************************************/
/* polyspace-end MISRA-C3:20.1 */

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
