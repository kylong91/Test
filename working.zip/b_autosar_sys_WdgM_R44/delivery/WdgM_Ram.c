/*******************************************************************************
**                                                                            **
**  (C) 2019 HYUNDAI AUTRON Co., Ltd.                                         **
**  Confidential Proprietary Information. Distribution Limited.               **
**  Do Not Copy Without Prior Permission                                      **
**                                                                            **
**  SRC-MODULE: WdgM_Ram.c                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR WDGM                                                  **
**                                                                            **
**  PURPOSE   : Watchdog Manager RAM variable definitions                     **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          By           Description                           **
********************************************************************************
** 1.0.0     16-Sep-2019   ThanhNT      Initial version                       **
*******************************************************************************/

/*******************************************************************************
**              PRE-JUSTIFICATION BEGIN (MISRA-C RULE CHECKER)                **
*******************************************************************************/
/* polyspace-begin MISRA-C3:20.1 [Not a Defect] "see MEMMAP003 of AUTOSAR" */

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "WdgM_Ram.h"         /* WdgM Ram variables header file */

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
#define WDGM_RAM_C_AR_RELEASE_MAJOR_VERSION 0x4u
#define WDGM_RAM_C_AR_RELEASE_MINOR_VERSION 0x4u
#define WDGM_RAM_C_AR_RELEASE_REVISION_VERSION 0x0u
#define WDGM_RAM_C_SW_MAJOR_VERSION 0x1u
#define WDGM_RAM_C_SW_MINOR_VERSION 0x0u
#define WDGM_RAM_C_SW_PATCH_VERSION 0x0u

/*******************************************************************************
**                      File version check                                    **
*******************************************************************************/
#if  ((WDGM_RAM_C_SW_MAJOR_VERSION != WDGM_RAM_H_SW_MAJOR_VERSION) || \
    (WDGM_RAM_C_SW_MINOR_VERSION != WDGM_RAM_H_SW_MINOR_VERSION) || \
    (WDGM_RAM_C_SW_PATCH_VERSION != WDGM_RAM_H_SW_PATCH_VERSION))
#error "Mismatch Sofware Version between WdgM_Ram.c and WdgM_Ram.h"
#endif

/*******************************************************************************
**                       Global Data                                          **
*******************************************************************************/
#define WDGM_START_SEC_VAR_CLEARED_UNSPECIFIED
#include "MemMap.h"
/* Global variable to store the current mode of watchdog manager */
VAR(WdgM_ModeType, WDGM_VAR_POWER_ON_INIT) WdgM_GddCurrentMode;
#define WDGM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
#include "MemMap.h"

#define WDGM_START_SEC_VAR_CLEARED_8
#include "MemMap.h"
VAR(uint8, WDGM_VAR_POWER_ON_INIT) WdgM_GaaSEStatus[WDGM_TOTAL_SES];
#define WDGM_STOP_SEC_VAR_CLEARED_8
#include "MemMap.h"

#define WDGM_START_SEC_VAR_CLEARED_UNSPECIFIED
#include "MemMap.h"
/* Global variable to store the overall supervision status */
VAR(WdgM_GlobalStatusType, WDGM_VAR_POWER_ON_INIT)
  WdgM_GddGlobalSupervisionStatus;
#define WDGM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
#include "MemMap.h"

#define WDGM_START_SEC_VAR_CLEARED_UNSPECIFIED
#include "MemMap.h"
/* Global variable to store the inverse overall supervision status */
VAR(WdgM_GlobalStatusType, WDGM_VAR_POWER_ON_INIT)
  WdgM_GddInvGlobalSupervisionStatus;
#define WDGM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
#include "MemMap.h"

#define WDGM_START_SEC_VAR_CLEARED_BOOLEAN
#include "MemMap.h"
/* Global variable to store first expired SE id status of WdgM */
VAR(boolean, WDGM_VAR_POWER_ON_INIT) WdgM_GblFirstExpSEIDStatus;
#define WDGM_STOP_SEC_VAR_CLEARED_BOOLEAN
#include "MemMap.h"

#define WDGM_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "MemMap.h"
/* Global variable to store the SEID of first expired SE */
VAR(WdgM_SupervisedEntityIdType, WDGM_VAR_NOINIT) WdgM_GddFirstExpiredSEID;
#define WDGM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "MemMap.h"

#define WDGM_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "MemMap.h"
/* Global variable to store the inverse SEID value of first expired SE */
VAR(WdgM_SupervisedEntityIdType, WDGM_VAR_NOINIT) WdgM_GddInvFirstExpiredSEID;
#define WDGM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "MemMap.h"

#define WDGM_START_SEC_VAR_CLEARED_UNSPECIFIED
#include "MemMap.h"
/* Global variable to store the amount of expired supervision cycles for how
  long the blocking of watchdog triggering shall be postponed in a given mode */
VAR(WdgM_ExpSupCycleTolType, WDGM_VAR_POWER_ON_INIT)
  WdgM_GddExpSupervisionCycleCounter;
#define WDGM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
#include "MemMap.h"

#if(WDGM_ENABLE_ALIVE_SUPERVISION == STD_ON)
#define WDGM_START_SEC_VAR_CLEARED_32
#include "MemMap.h"
/* Global variable to store the WdgM_MainFunction call count */
VAR(uint32, WDGM_VAR_POWER_ON_INIT) WdgM_GulFreeRunningCounter;
#define WDGM_STOP_SEC_VAR_CLEARED_32
#include "MemMap.h"

#define WDGM_START_SEC_VAR_CLEARED_UNSPECIFIED
#include "MemMap.h"
/* Global array to store the failed cycles of each supervised entity */
VAR(WdgM_FailureTolType, WDGM_VAR_POWER_ON_INIT)
  WdgM_GddFailedRefCycleCounter[WDGM_TOTAL_SES];
#define WDGM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
#include "MemMap.h"

#define WDGM_START_SEC_VAR_CLEARED_BOOLEAN
#include "MemMap.h"
/* Global variable to store error occurrence in performing alive supervisions */
VAR(boolean, WDGM_VAR_POWER_ON_INIT) WdgM_GaaAlreadyUpdated[WDGM_TOTAL_SES];
#define WDGM_STOP_SEC_VAR_CLEARED_BOOLEAN
#include "MemMap.h"
#endif

#if(WDGM_DEV_ERROR_DETECT == STD_ON)
#define WDGM_START_SEC_VAR_CLEARED_BOOLEAN
#include "MemMap.h"
/* Global variable to store Initialization status of WdgM */
VAR(boolean, WDGM_VAR_POWER_ON_INIT) WdgM_GblModuleInitStatus;
#define WDGM_STOP_SEC_VAR_CLEARED_BOOLEAN
#include "MemMap.h"
#endif

/*******************************************************************************
**               PRE-JUSTIFICATION END (MISRA-C RULE CHECKER)                 **
*******************************************************************************/
/* polyspace-end MISRA-C3:20.1 */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
